/**
 * MediaFetch & MediaSearch ExtendScript Host Bridge
 * Supports both Adobe Premiere Pro and Adobe After Effects
 */

// Embed JSON polyfill for ExtendScript (ECMAScript 3 runtime)
if (typeof JSON !== "object" || !JSON || typeof JSON.stringify !== "function" || typeof JSON.parse !== "function") {
    JSON = {};
}
(function () {
    var rx_one = /^[\],:{}\s]*$/;
    var rx_two = /\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g;
    var rx_three = /"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g;
    var rx_four = /(?:^|:|,)(?:\s*\[)+/g;
    var rx_escapable = /[\\"\u0000-\u001f\u007f-\u009f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g;
    var meta = {
        '\b': '\\b',
        '\t': '\\t',
        '\n': '\\n',
        '\f': '\\f',
        '\r': '\\r',
        '"': '\\"',
        '\\': '\\\\'
    };

    function quote(string) {
        rx_escapable.lastIndex = 0;
        return rx_escapable.test(string)
            ? '"' + string.replace(rx_escapable, function (a) {
                var c = meta[a];
                return typeof c === 'string'
                    ? c
                    : '\\u' + ('0000' + a.charCodeAt(0).toString(16)).slice(-4);
            }) + '"'
            : '"' + string + '"';
    }

    function str(key, holder) {
        var value = holder[key];
        if (value && typeof value === 'object' && typeof value.toJSON === 'function') {
            value = value.toJSON(key);
        }
        switch (typeof value) {
        case 'string':
            return quote(value);
        case 'number':
            return isFinite(value) ? String(value) : 'null';
        case 'boolean':
        case 'null':
            return String(value);
        case 'object':
            if (!value) {
                return 'null';
            }
            var partial = [];
            if (Object.prototype.toString.apply(value) === '[object Array]') {
                var length = value.length;
                for (var i = 0; i < length; i += 1) {
                    partial[i] = str(i, value) || 'null';
                }
                return '[' + partial.join(',') + ']';
            }
            for (var k in value) {
                if (Object.prototype.hasOwnProperty.call(value, k)) {
                    var v = str(k, value);
                    if (v) {
                        partial.push(quote(k) + ':' + v);
                    }
                }
            }
            return '{' + partial.join(',') + '}';
        }
        return 'null';
    }

    if (typeof JSON.stringify !== 'function') {
        JSON.stringify = function (value) {
            return str('', {'': value});
        };
    }

    if (typeof JSON.parse !== 'function') {
        JSON.parse = function (text) {
            var j;
            text = String(text);
            rx_escapable.lastIndex = 0;
            if (rx_escapable.test(text)) {
                text = text.replace(rx_escapable, function (a) {
                    return '\\u' + ('0000' + a.charCodeAt(0).toString(16)).slice(-4);
                });
            }

            if (rx_one.test(
                text
                    .replace(rx_two, '@')
                    .replace(rx_three, ']')
                    .replace(rx_four, '')
            )) {
                j = eval('(' + text + ')');
                return j;
            }
            try {
                return eval('(' + text + ')');
            } catch (e) {
                throw new SyntaxError('JSON.parse: ' + e.message);
            }
        };
    }
})();

var MediaFetchHost = (function () {
    try {
        var initLog = new File("C:/Users/pc/AppData/Local/MediaFetch/logs/hostscript_debug.log");
        initLog.open("a");
        initLog.writeln("=== HOSTSCRIPT INITIALIZED AT " + (new Date()).toString() + " ===");
        initLog.close();
    } catch (_) {}

    if (typeof String.prototype.trim !== "function") {
        String.prototype.trim = function () {
            return this.replace(/^\s+|\s+$/g, "");
        };
    }

    function sanitizeFolderName(raw) {
        if (!raw) return "";
        var s = String(raw);
        var forbidden = ["\\", "/", ":", "\"", "*", "?", "<", ">", "|"];
        for (var i = 0; i < forbidden.length; i++) {
            while (s.indexOf(forbidden[i]) !== -1) {
                s = s.replace(forbidden[i], " ");
            }
        }
        return s.replace(/^\s+|\s+$/g, "");
    }

    function safeTrim(raw) {
        if (!raw) return "";
        return String(raw).replace(/^\s+|\s+$/g, "");
    }

    function isPremiere() {
        if (typeof BridgeTalk !== "undefined" && BridgeTalk.appName) {
            return BridgeTalk.appName.toLowerCase().indexOf("premiere") !== -1;
        }
        return (typeof app !== "undefined" && ((app.name && app.name.indexOf("Premiere") !== -1) || (app.project && typeof app.project.importFiles === "function")));
    }

    function isAfterEffects() {
        if (typeof BridgeTalk !== "undefined" && BridgeTalk.appName) {
            return BridgeTalk.appName.toLowerCase().indexOf("aftereffects") !== -1;
        }
        return (typeof app !== "undefined" && ((app.name && app.name.indexOf("After Effects") !== -1) || (typeof FolderItem !== "undefined")));
    }

    function getHostInfo() {
        var info = {
            appName: "Unknown",
            appVersion: "",
            projectOpen: false,
            projectName: "",
            projectPath: "",
            hasActiveTimeline: false
        };

        try {
            if (isPremiere()) {
                info.appName = "premierepro";
                info.appVersion = app.version || "";
                if (app.project) {
                    info.projectOpen = true;
                    var pName = app.project.name;
                    if (!pName && app.project.path) {
                        var pParts = app.project.path.replace(/\\/g, '/').split('/');
                        pName = pParts[pParts.length - 1];
                    }
                    info.projectName = pName || "Active Premiere Project";
                    info.projectPath = app.project.path || "";
                    info.hasActiveTimeline = !!(app.project.activeSequence);
                }
            } else if (isAfterEffects()) {
                info.appName = "aftereffects";
                info.appVersion = app.version || "";
                if (app.project) {
                    info.projectOpen = true;
                    if (app.project.file && app.project.file.exists) {
                        info.projectName = app.project.file.name;
                        info.projectPath = app.project.file.fsName;
                    } else {
                        info.projectName = "Active AE Project";
                        info.projectPath = "";
                    }
                    var activeItem = app.project.activeItem;
                    info.hasActiveTimeline = (activeItem && (activeItem instanceof CompItem));
                }
            }
        } catch (e) {
            info.error = e.toString();
        }

        return JSON.stringify(info);
    }

    function importFileToPremiere(filePath, insertAtPlayhead, optionsJson) {
        try {
            try {
                var debugF = new File("C:/Users/pc/AppData/Local/MediaFetch/logs/hostscript_debug.log");
                debugF.open("a");
                debugF.writeln("=== importFileToPremiere CALLED ===");
                debugF.writeln("time: " + (new Date()).toString());
                debugF.writeln("filePath: " + filePath);
                debugF.writeln("insertAtPlayhead: " + insertAtPlayhead);
                debugF.writeln("optionsJson: " + optionsJson);
                debugF.close();
            } catch (_) {}

            if (!app || !app.project || !app.project.rootItem) {
                return JSON.stringify({
                    success: false,
                    appName: "premierepro",
                    noProject: true,
                    error: "No active project in Premiere Pro. Please open a project first.",
                    filePath: filePath
                });
            }

            var cleanPath = filePath.replace(/\\/g, '/');
            var nativePath = filePath.replace(/\//g, '\\');
            var file = new File(filePath);
            if (!file.exists) file = new File(cleanPath);
            if (!file.exists) file = new File(nativePath);
            if (!file.exists) {
                try { file = new File(File.decode(filePath)); } catch (_) {}
            }
            if (!file.exists) {
                try { file = new File(File.encode(filePath)); } catch (_) {}
            }

            // Stability check: wait until file exists and file size is stable across 2 checks (up to 15s)
            var fileStablePr = false;
            var prevSizePr = -1;
            var startWaitPr = new Date().getTime();
            while (new Date().getTime() - startWaitPr < 15000) {
                if (file.exists && file.length > 0) {
                    var curSize = file.length;
                    if (curSize === prevSizePr) {
                        fileStablePr = true;
                        break;
                    }
                    prevSizePr = curSize;
                }
                try { $.sleep(500); } catch (_) {}
                file = new File(cleanPath);
                if (!file.exists) file = new File(nativePath);
                if (!file.exists) file = new File(filePath);
            }

            if (!file.exists || file.length === 0) {
                return JSON.stringify({
                    success: false,
                    appName: "premierepro",
                    imported: false,
                    insertedToSequence: false,
                    error: "File does not exist or is empty (0 bytes) after stabilization wait: " + filePath,
                    filePath: filePath
                });
            }

        var opts = {};
        if (typeof optionsJson === "string" && optionsJson.length > 0) {
            try { opts = JSON.parse(optionsJson); } catch (_) {}
            if (typeof opts === "string") {
                try { opts = JSON.parse(opts); } catch (_) {}
            }
        } else if (typeof optionsJson === "object" && optionsJson !== null) {
            opts = optionsJson;
        }

        function getOrCreateBin(parentBin, binName) {
            if (!parentBin) return null;
            if (parentBin.children) {
                for (var i = 0; i < parentBin.children.numItems; i++) {
                    var item = parentBin.children[i];
                    if (item && item.type === 2 && item.name === binName) {
                        return item;
                    }
                }
            }
            try {
                if (typeof parentBin.createBin === "function") {
                    return parentBin.createBin(binName);
                }
            } catch (_) {}
            try {
                if (root && typeof root.createBin === "function") {
                    return root.createBin(binName);
                }
            } catch (_) {}
            return parentBin;
        }

        var root = app.project.rootItem;
        var mediaFetchBin = null;
        var cleanPath = filePath.replace(/\\/g, '/');
        var isClipboard = Boolean(opts.isClipboard) || cleanPath.indexOf("Clipboard") !== -1;
        var isSimple = Boolean(opts.isSimplePath || opts.isSimple || (opts.downloadLocationMode === 'simple'));
        var isCustomFlat = Boolean(opts.isCustomFlat || (opts.downloadLocationMode === 'custom_flat'));
        var isCustom = !isSimple && !isCustomFlat && Boolean(opts.isCustomPath || opts.isCustom || (opts.downloadLocationMode === 'custom'));
        var isCloud = Boolean(opts.isCloud || cleanPath.indexOf("Cloud Links") !== -1 || cleanPath.indexOf("Cloud") !== -1);
        var isPlaylist = Boolean(opts.isPlaylist || cleanPath.indexOf("Playlists") !== -1);
        var playlistTitle = sanitizeFolderName(opts.playlistTitle);
        var customFolderName = sanitizeFolderName(opts.customFolderName);
        var subFolderName = safeTrim(opts.subFolderName);

        var ext = cleanPath.split('.').pop().toLowerCase().split('?')[0];
        var isAudio = (ext === 'mp3' || ext === 'wav' || ext === 'm4a' || ext === 'flac' || ext === 'aac' || ext === 'ogg' || ext === 'opus' || ext === 'aiff');
        var isImage = (ext === 'jpg' || ext === 'jpeg' || ext === 'png' || ext === 'webp' || ext === 'gif' || ext === 'bmp' || ext === 'tiff' || ext === 'tif' || ext === 'svg');
        var typeBinName = isAudio ? "Audio" : (isImage ? "Images" : "Video");

        var targetBin = null;

        if (isCustomFlat) {
            // Direct Custom Flat Folder: import directly into custom folder's bin without creating sub-bins
            var pPartsFlat = cleanPath.split('/');
            var parentNameFlat = pPartsFlat.length > 1 ? pPartsFlat[pPartsFlat.length - 2] : "Downloads";
            var rootBinNameFlat = customFolderName || parentNameFlat || "MediaFetch";
            targetBin = getOrCreateBin(root, rootBinNameFlat) || root;
        } else if (isCustom) {
            // Custom folder selected: strictly save into custom folder > Video / Audio / Images bins
            var pParts = cleanPath.split('/');
            var parentName = pParts.length > 1 ? pParts[pParts.length - 2] : "";
            var isStrictThreeFolder = (parentName === "Video" || parentName === "Audio" || parentName === "Images" || parentName === "Image");

            if (isStrictThreeFolder) {
                var grandParentName = pParts.length > 2 ? pParts[pParts.length - 3] : "";
                var customRootBin = grandParentName ? getOrCreateBin(root, grandParentName) : root;
                targetBin = getOrCreateBin(customRootBin || root, typeBinName) || customRootBin;
            } else {
                var rootBinName = customFolderName || (isPlaylist ? (playlistTitle || "Playlist") : (isCloud ? "Cloud Media" : ""));
                if (!rootBinName) {
                    rootBinName = parentName || "Downloads";
                }
                var customRootBin = getOrCreateBin(root, rootBinName);
                if (subFolderName) {
                    var sParts = subFolderName.replace(/\\/g, '/').split('/');
                    var cur = customRootBin;
                    for (var s = 0; s < sParts.length; s++) {
                        if (sParts[s] && sParts[s].length > 0) {
                            cur = getOrCreateBin(cur, sParts[s]);
                        }
                    }
                    targetBin = cur || customRootBin;
                } else {
                    targetBin = getOrCreateBin(customRootBin, typeBinName) || customRootBin;
                }
            }
        } else if (isPlaylist) {
            var mediaFetchBin = getOrCreateBin(root, "MediaFetch");
            var playlistRootBin = getOrCreateBin(mediaFetchBin || root, "Playlists");
            var pName = playlistTitle || customFolderName || "Playlist 1";
            targetBin = getOrCreateBin(playlistRootBin, pName);
        } else if (isCloud) {
            var mediaFetchBin = getOrCreateBin(root, "MediaFetch");
            var cloudRootBin = getOrCreateBin(mediaFetchBin || root, "Cloud Links");
            var cloudFolderBin = getOrCreateBin(cloudRootBin, customFolderName || "Cloud Media");
            if (subFolderName) {
                var sParts2 = subFolderName.replace(/\\/g, '/').split('/');
                var cur2 = cloudFolderBin;
                for (var s2 = 0; s2 < sParts2.length; s2++) {
                    if (sParts2[s2] && sParts2[s2].length > 0) {
                        cur2 = getOrCreateBin(cur2, sParts2[s2]);
                    }
                }
                targetBin = cur2 || cloudFolderBin;
            } else {
                targetBin = cloudFolderBin;
            }
        } else {
            // Simple Project Path (DEFAULT): Project -> MediaFetch -> Video, Audio, Images only
            var mediaFetchBin = getOrCreateBin(root, "MediaFetch");
            targetBin = getOrCreateBin(mediaFetchBin || root, typeBinName) || mediaFetchBin || root;
        }

        // Import into project bin with resilient fallbacks
        var importTarget = targetBin || root;
        var nativePath = file.fsName;
        var cleanPath = file.fsName.replace(/\\/g, '/');

        // Locate newly imported item across project hierarchy
        var rawName = "";
        try {
            if (file.name) rawName = File.decode(file.name);
        } catch (_) {}
        if (!rawName && file.fsName) {
            var fnParts = file.fsName.replace(/\\/g, '/').split('/');
            rawName = fnParts[fnParts.length - 1];
        }
        if (!rawName) rawName = file.name || "";

        var fileNameOnly = rawName.toLowerCase();
        var baseNameOnly = fileNameOnly;
        var dotIdx = fileNameOnly.lastIndexOf('.');
        if (dotIdx > 0) {
            baseNameOnly = fileNameOnly.substring(0, dotIdx);
        }

        var cleanNorm = cleanPath.toLowerCase();
        var nativeNorm = nativePath.toLowerCase();

        function cleanStringForMatch(str) {
            if (!str) return "";
            var s = String(str);
            try { s = File.decode(s); } catch (_) {}
            return s.toLowerCase().replace(/\\/g, '/').replace(/[^\w\d]/g, '');
        }

        var cleanAlphaNorm = cleanStringForMatch(fileNameOnly);
        var baseAlphaNorm = cleanStringForMatch(baseNameOnly);

        // Accurate and strict matching: ensures only THIS exact file or clip name is matched
        function matchProjectItem(it) {
            if (!it || it.type === 2) return false;
            try {
                if (it.getMediaPath) {
                    var p = it.getMediaPath();
                    if (p && p.length > 0) {
                        var pLow = p.toLowerCase();
                        var pClean = pLow.replace(/\\/g, '/');
                        if (pClean === cleanNorm || pLow === nativeNorm) {
                            return true;
                        }
                        var pAlpha = cleanStringForMatch(p);
                        if (pAlpha && cleanAlphaNorm && (pAlpha === cleanAlphaNorm || pAlpha === baseAlphaNorm)) {
                            return true;
                        }
                    }
                }
            } catch (_) {}
            try {
                if (it.name) {
                    var nLow = it.name.toLowerCase();
                    if (nLow === fileNameOnly || nLow === baseNameOnly) return true;
                    var nDot = nLow.lastIndexOf('.');
                    var nBase = nDot > 0 ? nLow.substring(0, nDot) : nLow;
                    if (nBase === baseNameOnly) return true;
                    var nAlpha = cleanStringForMatch(it.name);
                    if (nAlpha && (nAlpha === cleanAlphaNorm || nAlpha === baseAlphaNorm)) return true;
                }
            } catch (_) {}
            return false;
        }

        function scanBinForItem(bin) {
            if (!bin || !bin.children) return null;
            for (var b = 0; b < bin.children.numItems; b++) {
                var it = bin.children[b];
                if (!it) continue;
                if (it.type !== 2) {
                    if (matchProjectItem(it)) return it;
                } else if (it.type === 2) {
                    var f = scanBinForItem(it);
                    if (f) return f;
                }
            }
            return null;
        }

        // Snapshot existing item counts to detect newly imported items instantly
        var prevTargetCount = (importTarget && importTarget.children) ? importTarget.children.numItems : 0;
        var prevRootCount = (root && root.children) ? root.children.numItems : 0;
        var didImport = false;
        var targetItem = null;

        // Check if file is already present with exact path/name in project
        targetItem = scanBinForItem(importTarget) || scanBinForItem(mediaFetchBin) || scanBinForItem(root);

        // Candidate paths: nativePath (Windows backslashes first for C++ importer!), cleanPath (forward slashes)
        var pathsToTry = [nativePath, cleanPath];
        if (filePath !== cleanPath && filePath !== nativePath) {
            pathsToTry.push(filePath);
        }

        // Wait up to 2.5s for file on disk to finish flushing/renaming by OS if needed
        for (var waitDisk = 0; waitDisk < 10 && !file.exists; waitDisk++) {
            try { $.sleep(250); } catch (_) {}
            file = new File(cleanPath);
            if (!file.exists) file = new File(nativePath);
            if (!file.exists) file = new File(filePath);
        }

        // Execute import with retry for OS file locks / antivirus scanning
        if (!targetItem) {
            for (var pIdx = 0; pIdx < pathsToTry.length && !didImport; pIdx++) {
                var curPath = pathsToTry[pIdx];
                for (var lockAttempt = 0; lockAttempt < 5 && !didImport; lockAttempt++) {
                    if (lockAttempt > 0) {
                        try { $.sleep(300); } catch (_) {}
                    }
                    
                    // Attempt A: Import directly into designated targetBin
                    if (importTarget && importTarget !== root) {
                        try {
                            var r1 = app.project.importFiles([curPath], true, importTarget, false);
                            if (r1 === true || r1 === 1) {
                                didImport = true;
                                break;
                            }
                            // In Premiere Pro, importFiles with targetBin often returns false/undefined even when import succeeded
                            if (importTarget.children && importTarget.children.numItems > prevTargetCount) {
                                didImport = true;
                                break;
                            }
                            var itA = scanBinForItem(importTarget);
                            if (itA) {
                                targetItem = itA;
                                didImport = true;
                                break;
                            }
                        } catch (_) {}
                    }

                    // Attempt B: If targetBin was rejected or not populated, import directly into rootItem!
                    // Premiere Pro's C++ importer is 100% reliable when importing to rootItem.
                    // We will move it into importTarget immediately after ingestion detection.
                    if (!didImport && !targetItem) {
                        try {
                            var r2 = app.project.importFiles([curPath], true);
                            if (r2 === true || r2 === 1 || (root && root.children && root.children.numItems > prevRootCount)) {
                                didImport = true;
                                break;
                            }
                        } catch (_) {}
                    }

                    // Attempt C: Numeric flag fallback (suppressUI = 1) only if still not imported
                    if (!didImport && !targetItem) {
                        try {
                            var r3 = (importTarget && importTarget !== root) ?
                                app.project.importFiles([curPath], 1, importTarget, 0) :
                                app.project.importFiles([curPath]);
                            if (r3 === true || r3 === 1 || (importTarget && importTarget.children && importTarget.children.numItems > prevTargetCount) || (root && root.children && root.children.numItems > prevRootCount)) {
                                didImport = true;
                                break;
                            }
                        } catch (_) {}
                    }

                    // Attempt D: Plain importFiles([curPath]) without extra arguments only if still not imported
                    if (!didImport && !targetItem) {
                        try {
                            var r4 = app.project.importFiles([curPath]);
                            if (r4 === true || r4 === 1 || (root && root.children && root.children.numItems > prevRootCount)) {
                                didImport = true;
                                break;
                            }
                        } catch (_) {}
                    }
                }
            }

            // Safe Ingestion Polling:
            // Premiere Pro asynchronously ingests large files in background.
            // Avoid blocking ExtendScript UI thread with 20s sleep which causes CEP evalScript watchdog timeout.
            // Brief poll (max 4 iterations x 250ms = 1s) to attempt immediate sequence insertion / bin move:
            for (var poll = 0; poll < 8 && !targetItem; poll++) {
                try { $.sleep(250); } catch (_) {}

                // 1. Check if item landed in importTarget
                if (importTarget && importTarget.children && importTarget.children.numItems > prevTargetCount) {
                    for (var ci = importTarget.children.numItems - 1; ci >= 0; ci--) {
                        var candidate = importTarget.children[ci];
                        if (candidate && candidate.type !== 2 && matchProjectItem(candidate)) {
                            targetItem = candidate;
                            break;
                        }
                    }
                }

                // 2. Check if Premiere placed it into rootItem instead of importTarget
                if (!targetItem && root && root.children && root.children.numItems > prevRootCount) {
                    for (var ri0 = root.children.numItems - 1; ri0 >= 0; ri0--) {
                        var rCand0 = root.children[ri0];
                        if (rCand0 && rCand0.type !== 2 && matchProjectItem(rCand0)) {
                            targetItem = rCand0;
                            break;
                        }
                    }
                }

                // 3. Resilient deep scan across bins
                if (!targetItem) {
                    targetItem = scanBinForItem(importTarget) || scanBinForItem(mediaFetchBin) || scanBinForItem(root);
                }
            }
        }

        // Guarantee item is moved into targetBin if Premiere imported it to rootItem
        if (targetItem && importTarget && importTarget !== root) {
            try {
                if (typeof targetItem.moveBin === "function") {
                    targetItem.moveBin(importTarget);
                }
            } catch (_) {}
        }

        var isSingleLink = !isPlaylist && !isCloud && !Boolean(opts.isBatch);
        if (opts.isSingleLink !== undefined) {
            isSingleLink = Boolean(opts.isSingleLink);
        }
        if (opts.insertToTimeline !== undefined) {
            insertAtPlayhead = Boolean(opts.insertToTimeline);
        } else if (opts.addToTimeline !== undefined) {
            insertAtPlayhead = Boolean(opts.addToTimeline);
        }
        if (isClipboard) {
            insertAtPlayhead = true;
        } else if (!isSingleLink && !opts.insertToTimeline && !opts.addToTimeline) {
            insertAtPlayhead = false;
        }

        var insertedToSeq = false;
        if (insertAtPlayhead && targetItem) {
            try {
                    var seqName = targetItem.name || "MediaFetch Timeline";
                    var activeSeq = app.project.activeSequence;

                    function getSequenceEndTime(seq) {
                        var maxEndSec = 0;
                        var maxEndTicks = "0";
                        if (!seq) return { seconds: 0, ticks: "0" };
                        try {
                            if (seq.videoTracks) {
                                for (var vt = 0; vt < seq.videoTracks.numTracks; vt++) {
                                    var vTrk = seq.videoTracks[vt];
                                    if (vTrk && vTrk.clips) {
                                        for (var vc = 0; vc < vTrk.clips.numItems; vc++) {
                                            var vClip = vTrk.clips[vc];
                                            if (vClip && vClip.end) {
                                                var es = vClip.end.seconds !== undefined ? vClip.end.seconds : parseFloat(vClip.end);
                                                if (es > maxEndSec) {
                                                    maxEndSec = es;
                                                    if (vClip.end.ticks) maxEndTicks = String(vClip.end.ticks);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            if (seq.audioTracks) {
                                for (var at = 0; at < seq.audioTracks.numTracks; at++) {
                                    var aTrk = seq.audioTracks[at];
                                    if (aTrk && aTrk.clips) {
                                        for (var ac = 0; ac < aTrk.clips.numItems; ac++) {
                                            var aClip = aTrk.clips[ac];
                                            if (aClip && aClip.end) {
                                                var aes = aClip.end.seconds !== undefined ? aClip.end.seconds : parseFloat(aClip.end);
                                                if (aes > maxEndSec) {
                                                    maxEndSec = aes;
                                                    if (aClip.end.ticks) maxEndTicks = String(aClip.end.ticks);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            if (maxEndTicks === "0" && maxEndSec > 0) {
                                maxEndTicks = String(Math.round(maxEndSec * 254016000000));
                            }
                        } catch (_) {}
                        return { seconds: maxEndSec, ticks: maxEndTicks };
                    }

                    function findSmartVideoTrackAndGap(seq, playheadTime) {
                        try {
                            var dbg = new File("C:/Users/pc/AppData/Local/MediaFetch/logs/hostscript_debug.log");
                            dbg.open("a");
                            dbg.writeln("--- findSmartVideoTrackAndGap ---");
                            dbg.writeln("playheadTime: " + playheadTime);
                            if (seq && seq.videoTracks) {
                                dbg.writeln("numTracks: " + seq.videoTracks.numTracks);
                            }
                            dbg.close();
                        } catch (_) {}

                        if (!seq || !seq.videoTracks || seq.videoTracks.numTracks === 0) return null;
                        var numTracks = seq.videoTracks.numTracks;
                        var pSec = 0;
                        if (playheadTime) {
                            if (playheadTime.seconds !== undefined) pSec = playheadTime.seconds;
                            else pSec = parseFloat(playheadTime) || 0;
                        }

                        var minUsableGap = 0.05; // 50 milliseconds
                        var bestTrack = null;
                        var bestGap = Infinity;
                        var bestTrackIndex = -1;

                        // Start scanning from V2 (index 1) upwards to protect V1 base/footage track.
                        // If only 1 track exists (V1 only), scan index 0.
                        var startIdx = numTracks > 1 ? 1 : 0;

                        for (var t = startIdx; t < numTracks; t++) {
                            var trk = seq.videoTracks[t];
                            if (!trk) continue;
                            try {
                                if (trk.isLocked && trk.isLocked()) continue;
                            } catch (_) {}

                            var hasCollision = false;
                            var nextClipStart = Infinity;
                            var numClips = (trk.clips && trk.clips.numItems) ? trk.clips.numItems : 0;

                            for (var c = 0; c < numClips; c++) {
                                var cl = trk.clips[c];
                                if (!cl || !cl.start || !cl.end) continue;
                                var cStart = cl.start.seconds !== undefined ? cl.start.seconds : parseFloat(cl.start);
                                var cEnd = cl.end.seconds !== undefined ? cl.end.seconds : parseFloat(cl.end);

                                if (cStart <= pSec + 0.001 && cEnd > pSec + 0.001) {
                                    hasCollision = true;
                                    break;
                                }

                                if (cStart > pSec + 0.001) {
                                    if (cStart < nextClipStart) {
                                        nextClipStart = cStart;
                                    }
                                }
                            }

                            try {
                                var dbg2 = new File("C:/Users/pc/AppData/Local/MediaFetch/logs/hostscript_debug.log");
                                dbg2.open("a");
                                dbg2.writeln("Track " + t + " name=" + trk.name + " clips=" + numClips + " hasCollision=" + hasCollision + " nextClipStart=" + nextClipStart);
                                dbg2.close();
                            } catch (_) {}

                            if (!hasCollision) {
                                var gap = (nextClipStart !== Infinity) ? (nextClipStart - pSec) : Infinity;
                                if (gap >= minUsableGap) {
                                    bestTrack = trk;
                                    bestGap = gap;
                                    bestTrackIndex = t;
                                    break;
                                }
                            }
                        }

                        // If all V2+ tracks blocked at playhead, check V1 if it has space and is unlocked
                        if (!bestTrack && startIdx > 0) {
                            var v1Trk = seq.videoTracks[0];
                            if (v1Trk) {
                                var v1Locked = false;
                                try { v1Locked = (v1Trk.isLocked && v1Trk.isLocked()); } catch (_) {}
                                if (!v1Locked) {
                                    var v1Collision = false;
                                    var v1NextStart = Infinity;
                                    var v1NumClips = (v1Trk.clips && v1Trk.clips.numItems) ? v1Trk.clips.numItems : 0;
                                    for (var c1 = 0; c1 < v1NumClips; c1++) {
                                        var cl1 = v1Trk.clips[c1];
                                        if (!cl1 || !cl1.start || !cl1.end) continue;
                                        var cs1 = cl1.start.seconds !== undefined ? cl1.start.seconds : parseFloat(cl1.start);
                                        var ce1 = cl1.end.seconds !== undefined ? cl1.end.seconds : parseFloat(cl1.end);
                                        if (cs1 <= pSec + 0.001 && ce1 > pSec + 0.001) {
                                            v1Collision = true;
                                            break;
                                        }
                                        if (cs1 > pSec + 0.001 && cs1 < v1NextStart) {
                                            v1NextStart = cs1;
                                        }
                                    }
                                    if (!v1Collision) {
                                        var v1Gap = (v1NextStart !== Infinity) ? (v1NextStart - pSec) : Infinity;
                                        if (v1Gap >= minUsableGap) {
                                            bestTrack = v1Trk;
                                            bestGap = v1Gap;
                                            bestTrackIndex = 0;
                                        }
                                    }
                                }
                            }
                        }

                        // If ALL existing tracks are colliding at the playhead, add a new track above
                        if (!bestTrack) {
                            try {
                                if (typeof app.enableQE === "function") app.enableQE();
                                if (typeof qe !== "undefined" && qe.project) {
                                    var qSeq = qe.project.getActiveSequence();
                                    if (qSeq && typeof qSeq.addTracks === "function") {
                                        qSeq.addTracks(1, 0, 0, 0, 0);
                                        if (seq.videoTracks.numTracks > numTracks) {
                                            bestTrackIndex = seq.videoTracks.numTracks - 1;
                                            bestTrack = seq.videoTracks[bestTrackIndex];
                                            bestGap = Infinity;
                                        }
                                    }
                                }
                            } catch (_) {}
                            if (!bestTrack) {
                                bestTrackIndex = numTracks - 1;
                                bestTrack = seq.videoTracks[bestTrackIndex];
                                bestGap = Infinity;
                            }
                        }

                        try {
                            var dbg3 = new File("C:/Users/pc/AppData/Local/MediaFetch/logs/hostscript_debug.log");
                            dbg3.open("a");
                            dbg3.writeln("RESULT: bestTrack=" + (bestTrack ? bestTrack.name : "null") + " idx=" + bestTrackIndex + " bestGap=" + bestGap);
                            dbg3.close();
                        } catch (_) {}

                        return { track: bestTrack, gapDuration: bestGap, trackIndex: bestTrackIndex };
                    }

                    function getTargetVideoTrack(seq, playheadTime) {
                        var res = findSmartVideoTrackAndGap(seq, playheadTime);
                        return res ? res.track : null;
                    }

                    function findClearVideoTrack(seq, playheadTime) {
                        if (!seq || !seq.videoTracks || seq.videoTracks.numTracks === 0) return null;
                        var numTracks = seq.videoTracks.numTracks;
                        var pSec = 0;
                        if (playheadTime) {
                            if (playheadTime.seconds !== undefined) pSec = playheadTime.seconds;
                            else pSec = parseFloat(playheadTime) || 0;
                        }

                        try {
                            var dbg = new File("C:/Users/pc/AppData/Local/MediaFetch/logs/hostscript_debug.log");
                            dbg.open("a");
                            dbg.writeln("--- findClearVideoTrack (Top Track Placement) ---");
                            dbg.writeln("playheadTime: " + pSec + ", total video tracks: " + numTracks);
                            dbg.close();
                        } catch (_) {}

                        var bestTrack = null;
                        var bestTrackIndex = -1;

                        // Check the top-most video track (newest / highest layer)
                        var topIdx = numTracks - 1;
                        var topTrk = seq.videoTracks[topIdx];
                        var topLocked = false;
                        try { topLocked = (topTrk && topTrk.isLocked && topTrk.isLocked()); } catch (_) {}

                        if (topTrk && !topLocked) {
                            var hasCollision = false;
                            var hasClipsAfter = false;
                            var numClips = (topTrk.clips && topTrk.clips.numItems) ? topTrk.clips.numItems : 0;

                            for (var c = 0; c < numClips; c++) {
                                var cl = topTrk.clips[c];
                                if (!cl || !cl.start || !cl.end) continue;
                                var cStart = cl.start.seconds !== undefined ? cl.start.seconds : parseFloat(cl.start);
                                var cEnd = cl.end.seconds !== undefined ? cl.end.seconds : parseFloat(cl.end);

                                if (cStart <= pSec + 0.001 && cEnd > pSec + 0.001) {
                                    hasCollision = true;
                                    break;
                                }
                                if (cStart > pSec + 0.001) {
                                    hasClipsAfter = true;
                                    break;
                                }
                            }

                            try {
                                var dbg2 = new File("C:/Users/pc/AppData/Local/MediaFetch/logs/hostscript_debug.log");
                                dbg2.open("a");
                                dbg2.writeln("Top Video Track " + topIdx + " (" + topTrk.name + "): clips=" + numClips + ", collision=" + hasCollision + ", clipsAfter=" + hasClipsAfter);
                                dbg2.close();
                            } catch (_) {}

                            // If top track has space from playhead to infinity, use it!
                            if (!hasCollision && !hasClipsAfter) {
                                bestTrack = topTrk;
                                bestTrackIndex = topIdx;
                            }
                        }

                        // If top track does not have space, CREATE A NEW TOP VIDEO LAYER!
                        if (!bestTrack) {
                            try {
                                if (typeof app.enableQE === "function") app.enableQE();
                                if (typeof qe !== "undefined" && qe.project) {
                                    var qSeq = qe.project.getActiveSequence();
                                    if (qSeq && typeof qSeq.addTracks === "function") {
                                        qSeq.addTracks(1, seq.videoTracks.numTracks, 0, 0, 0);
                                        if (seq.videoTracks.numTracks > numTracks) {
                                            bestTrackIndex = seq.videoTracks.numTracks - 1;
                                            bestTrack = seq.videoTracks[bestTrackIndex];
                                        }
                                    }
                                }
                            } catch (_) {}
                            if (!bestTrack) {
                                bestTrackIndex = numTracks - 1;
                                bestTrack = seq.videoTracks[bestTrackIndex];
                            }
                        }

                        try {
                            var dbg3 = new File("C:/Users/pc/AppData/Local/MediaFetch/logs/hostscript_debug.log");
                            dbg3.open("a");
                            dbg3.writeln("findClearVideoTrack SELECTED: track=" + (bestTrack ? bestTrack.name : "null") + " idx=" + bestTrackIndex);
                            dbg3.close();
                        } catch (_) {}

                        return { track: bestTrack, trackIndex: bestTrackIndex, gapDuration: Infinity };
                    }

                    function findClearAudioTrack(seq, playheadTime) {
                        if (!seq || !seq.audioTracks || seq.audioTracks.numTracks === 0) return null;
                        var numTracks = seq.audioTracks.numTracks;
                        var pSec = 0;
                        if (playheadTime) {
                            if (playheadTime.seconds !== undefined) pSec = playheadTime.seconds;
                            else pSec = parseFloat(playheadTime) || 0;
                        }

                        try {
                            var dbg = new File("C:/Users/pc/AppData/Local/MediaFetch/logs/hostscript_debug.log");
                            dbg.open("a");
                            dbg.writeln("--- findClearAudioTrack (Bottom Track Placement) ---");
                            dbg.writeln("playheadTime: " + pSec + ", total audio tracks: " + numTracks);
                            dbg.close();
                        } catch (_) {}

                        var bestTrack = null;
                        var bestTrackIndex = -1;

                        // Check the bottom-most audio track (newest / lowest layer)
                        var botIdx = numTracks - 1;
                        var botTrk = seq.audioTracks[botIdx];
                        var botLocked = false;
                        try { botLocked = (botTrk && botTrk.isLocked && botTrk.isLocked()); } catch (_) {}

                        if (botTrk && !botLocked) {
                            var hasCollision = false;
                            var hasClipsAfter = false;
                            var numClips = (botTrk.clips && botTrk.clips.numItems) ? botTrk.clips.numItems : 0;

                            for (var c = 0; c < numClips; c++) {
                                var cl = botTrk.clips[c];
                                if (!cl || !cl.start || !cl.end) continue;
                                var cStart = cl.start.seconds !== undefined ? cl.start.seconds : parseFloat(cl.start);
                                var cEnd = cl.end.seconds !== undefined ? cl.end.seconds : parseFloat(cl.end);

                                if (cStart <= pSec + 0.001 && cEnd > pSec + 0.001) {
                                    hasCollision = true;
                                    break;
                                }
                                if (cStart > pSec + 0.001) {
                                    hasClipsAfter = true;
                                    break;
                                }
                            }

                            try {
                                var dbg2 = new File("C:/Users/pc/AppData/Local/MediaFetch/logs/hostscript_debug.log");
                                dbg2.open("a");
                                dbg2.writeln("Bottom Audio Track " + botIdx + " (" + botTrk.name + "): clips=" + numClips + ", collision=" + hasCollision + ", clipsAfter=" + hasClipsAfter);
                                dbg2.close();
                            } catch (_) {}

                            // If bottom track has space from playhead to infinity, use it!
                            if (!hasCollision && !hasClipsAfter) {
                                bestTrack = botTrk;
                                bestTrackIndex = botIdx;
                            }
                        }

                        // If bottom track does not have space, CREATE A NEW STEREO AUDIO LAYER AT BOTTOM!
                        if (!bestTrack) {
                            try {
                                if (typeof app.enableQE === "function") app.enableQE();
                                if (typeof qe !== "undefined" && qe.project) {
                                    var qSeq = qe.project.getActiveSequence();
                                    if (qSeq && typeof qSeq.addTracks === "function") {
                                        qSeq.addTracks(0, 0, 1, 1, seq.audioTracks.numTracks);
                                        if (seq.audioTracks.numTracks > numTracks) {
                                            bestTrackIndex = seq.audioTracks.numTracks - 1;
                                            bestTrack = seq.audioTracks[bestTrackIndex];
                                        }
                                    }
                                }
                            } catch (_) {}
                            if (!bestTrack) {
                                bestTrackIndex = numTracks - 1;
                                bestTrack = seq.audioTracks[bestTrackIndex];
                            }
                        }

                        try {
                            var dbg3 = new File("C:/Users/pc/AppData/Local/MediaFetch/logs/hostscript_debug.log");
                            dbg3.open("a");
                            dbg3.writeln("findClearAudioTrack SELECTED: track=" + (bestTrack ? bestTrack.name : "null") + " idx=" + bestTrackIndex);
                            dbg3.close();
                        } catch (_) {}

                        return { track: bestTrack, trackIndex: bestTrackIndex, gapDuration: Infinity };
                    }

                    function targetTracks(seq, videoTrackIndex, audioTrackIndex) {
                        if (!seq) return;
                        try {
                            if (seq.videoTracks) {
                                for (var vt = 0; vt < seq.videoTracks.numTracks; vt++) {
                                    try {
                                        var trkV = seq.videoTracks[vt];
                                        if (trkV && typeof trkV.setTargeted === "function") {
                                            var shouldTargetV = (videoTrackIndex !== null && videoTrackIndex !== undefined && vt === videoTrackIndex);
                                            if (typeof trkV.isTargeted === "function" && trkV.isTargeted() === shouldTargetV) {
                                                continue;
                                            }
                                            trkV.setTargeted(shouldTargetV);
                                        }
                                    } catch (_) {}
                                }
                            }
                        } catch (_) {}
                        try {
                            if (seq.audioTracks) {
                                for (var at = 0; at < seq.audioTracks.numTracks; at++) {
                                    try {
                                        var trkA = seq.audioTracks[at];
                                        if (trkA && typeof trkA.setTargeted === "function") {
                                            var shouldTargetA = (audioTrackIndex !== null && audioTrackIndex !== undefined && at === audioTrackIndex);
                                            if (typeof trkA.isTargeted === "function" && trkA.isTargeted() === shouldTargetA) {
                                                continue;
                                            }
                                            trkA.setTargeted(shouldTargetA);
                                        }
                                    } catch (_) {}
                                }
                            }
                        } catch (_) {}
                    }

                    function findSmartAudioTrackAndGap(seq, playheadTime) {
                        return findClearAudioTrack(seq, playheadTime);
                    }

                    function getTargetAudioTrack(seq, playheadTime) {
                        var res = findClearAudioTrack(seq, playheadTime);
                        return res ? res.track : null;
                    }

                    // 1. Insert into active timeline if available on new/available track at playhead
                    if (activeSeq) {
                        try {
                            var playhead = activeSeq.getPlayerPosition();
                            var pSec = 0;
                            var timeTicks = "0";
                            if (playhead) {
                                if (playhead.ticks !== undefined && playhead.ticks !== null && String(playhead.ticks).length > 0) {
                                    timeTicks = String(playhead.ticks);
                                }
                                if (playhead.seconds !== undefined) {
                                    pSec = playhead.seconds;
                                    if (timeTicks === "0") timeTicks = String(Math.round(parseFloat(playhead.seconds) * 254016000000));
                                } else {
                                    pSec = parseFloat(playhead) || 0;
                                    if (timeTicks === "0" && pSec > 0) timeTicks = String(Math.round(pSec * 254016000000));
                                }
                            }

                            // Sequential insertion for playlist / batch items:
                            var seqEnd = getSequenceEndTime(activeSeq);
                            if ((isPlaylist || Boolean(opts.isBatch)) && seqEnd.seconds > 0) {
                                pSec = Math.max(pSec, seqEnd.seconds);
                                timeTicks = seqEnd.ticks;
                            }

                            // Try up to 4 attempts (with 250ms sleep) for large media clips to settle in Premiere's cache
                            for (var insTry = 0; insTry < 4 && !insertedToSeq; insTry++) {
                                if (insTry > 0) { try { $.sleep(250); } catch (_) {} }
                                if (isAudio) {
                                    // AUDIO-ONLY MEDIA: MUST LAND ON 100% CLEAR AUDIO TRACK WITH FULL DURATION
                                    var clearAudio = findClearAudioTrack(activeSeq, pSec);
                                    var aTrk = clearAudio ? clearAudio.track : null;
                                    var aIdx = clearAudio ? clearAudio.trackIndex : -1;
                                    if (aTrk) {
                                        targetTracks(activeSeq, null, aIdx);
                                        if (timeTicks && timeTicks !== "0" && typeof aTrk.overwriteClip === "function") {
                                            try { aTrk.overwriteClip(targetItem, timeTicks); insertedToSeq = true; } catch (_) {}
                                        }
                                        if (!insertedToSeq && playhead && typeof aTrk.overwriteClip === "function") {
                                            try { aTrk.overwriteClip(targetItem, playhead); insertedToSeq = true; } catch (_) {}
                                        }
                                        if (!insertedToSeq && timeTicks && timeTicks !== "0") {
                                            try { aTrk.insertClip(targetItem, timeTicks); insertedToSeq = true; } catch (_) {}
                                        }
                                        if (!insertedToSeq && playhead) {
                                            try { aTrk.insertClip(targetItem, playhead); insertedToSeq = true; } catch (_) {}
                                        }
                                        if (!insertedToSeq) { try { aTrk.insertClip(targetItem, pSec); insertedToSeq = true; } catch (_) {} }
                                        if (!insertedToSeq) { try { aTrk.insertClip(targetItem, "0"); insertedToSeq = true; } catch (_) {} }
                                    }
                                } else if (isImage) {
                                    // IMAGE MEDIA ONLY: SMART GAP-FITTING AND AUTO-TRIM DURATION (NEVER FOR VIDEO OR AUDIO)
                                    var smartVideo = findSmartVideoTrackAndGap(activeSeq, pSec);
                                    var vTrk = smartVideo ? smartVideo.track : null;
                                    var vGap = smartVideo ? smartVideo.gapDuration : Infinity;
                                    var vIdx = smartVideo ? smartVideo.trackIndex : -1;

                                    if (vTrk) {
                                        targetTracks(activeSeq, vIdx, null);
                                        var targetDurSec = (vGap !== Infinity && vGap > 0) ? vGap : 5.0;
                                        try {
                                            var tIn = new Time();
                                            tIn.ticks = "0";
                                            try { targetItem.setInPoint(tIn, 4); } catch (_) { try { targetItem.setInPoint(tIn); } catch (_) {} }
                                            var tOut = new Time();
                                            tOut.ticks = String(Math.round(targetDurSec * 254016000000));
                                            try { targetItem.setOutPoint(tOut, 4); } catch (_) { try { targetItem.setOutPoint(tOut); } catch (_) {} }
                                        } catch (_) {}

                                        // OverwriteClip preserves timeline boundaries best
                                        if (vIdx >= 0 && vGap !== Infinity) {
                                            try {
                                                if (typeof app.enableQE === "function") app.enableQE();
                                                if (typeof qe !== "undefined" && qe.project) {
                                                    var qSeq = qe.project.getActiveSequence();
                                                    if (qSeq && typeof qSeq.getVideoTrackAt === "function") {
                                                        var qTrk = qSeq.getVideoTrackAt(vIdx);
                                                        if (qTrk && typeof qTrk.overwriteClip === "function") {
                                                            if (timeTicks && timeTicks !== "0") {
                                                                try { qTrk.overwriteClip(targetItem, timeTicks); insertedToSeq = true; } catch (_) {}
                                                            }
                                                            if (!insertedToSeq) {
                                                                try { qTrk.overwriteClip(targetItem, pSec); insertedToSeq = true; } catch (_) {}
                                                            }
                                                        }
                                                    }
                                                }
                                            } catch (_) {}
                                        }

                                        if (!insertedToSeq && timeTicks && timeTicks !== "0" && typeof vTrk.overwriteClip === "function") {
                                            try { vTrk.overwriteClip(targetItem, timeTicks); insertedToSeq = true; } catch (_) {}
                                        }
                                        if (!insertedToSeq && playhead && typeof vTrk.overwriteClip === "function") {
                                            try { vTrk.overwriteClip(targetItem, playhead); insertedToSeq = true; } catch (_) {}
                                        }
                                        if (!insertedToSeq && timeTicks && timeTicks !== "0") {
                                            try { vTrk.insertClip(targetItem, timeTicks); insertedToSeq = true; } catch (_) {}
                                        }
                                        if (!insertedToSeq && playhead) {
                                            try { vTrk.insertClip(targetItem, playhead); insertedToSeq = true; } catch (_) {}
                                        }
                                        if (!insertedToSeq) {
                                            try { vTrk.insertClip(targetItem, pSec); insertedToSeq = true; } catch (_) {}
                                        }
                                        if (!insertedToSeq) {
                                            try { vTrk.insertClip(targetItem, "0"); insertedToSeq = true; } catch (_) {}
                                        }

                                        try {
                                            var dbgIns = new File("C:/Users/pc/AppData/Local/MediaFetch/logs/hostscript_debug.log");
                                            dbgIns.open("a");
                                            dbgIns.writeln("IMAGE INSERTION: insertedToSeq=" + insertedToSeq + " on track=" + vTrk.name + " vGap=" + vGap);
                                            dbgIns.close();
                                        } catch (_) {}

                                        // Post-placement clamp: ensure newly placed image does not overrun gap!
                                        if (insertedToSeq && vGap !== Infinity && vGap > 0 && vTrk.clips) {
                                            try {
                                                var maxAllowedEnd = pSec + vGap;
                                                for (var cChk = 0; cChk < vTrk.clips.numItems; cChk++) {
                                                    var plClip = vTrk.clips[cChk];
                                                    if (!plClip || !plClip.start || !plClip.end) continue;
                                                    var plStartSec = plClip.start.seconds !== undefined ? plClip.start.seconds : parseFloat(plClip.start);
                                                    if (Math.abs(plStartSec - pSec) < 0.05) {
                                                        var plEndSec = plClip.end.seconds !== undefined ? plClip.end.seconds : parseFloat(plClip.end);
                                                        if (plEndSec > maxAllowedEnd + 0.01) {
                                                            try {
                                                                var eTime = new Time();
                                                                eTime.ticks = String(Math.round(maxAllowedEnd * 254016000000));
                                                                plClip.end = eTime;
                                                            } catch (_) {
                                                                try { plClip.end = maxAllowedEnd; } catch (_) {}
                                                            }
                                                            try {
                                                                var oTime = new Time();
                                                                oTime.ticks = String(Math.round(vGap * 254016000000));
                                                                plClip.outPoint = oTime;
                                                            } catch (_) {}
                                                        }
                                                        break;
                                                    }
                                                }
                                            } catch (_) {}
                                        }
                                    }
                                } else {
                                    // VIDEO MEDIA (With or without Audio)
                                    // MUST IMPORT ONTO TIMELINE THAT IS 100% CLEAR OF BOTH VIDEO AND AUDIO TO THE RIGHT!
                                    // Never trim or cut video or audio length, never overwrite any clips on the right!
                                    var clearVid = findClearVideoTrack(activeSeq, pSec);
                                    var clearAud = findClearAudioTrack(activeSeq, pSec);
                                    var vTrk = clearVid ? clearVid.track : null;
                                    var vIdx = clearVid ? clearVid.trackIndex : -1;
                                    var aIdx = clearAud ? clearAud.trackIndex : -1;

                                    if (vTrk) {
                                        // Target clear video track and clear audio track so both streams land on completely clear tracks!
                                        targetTracks(activeSeq, vIdx, aIdx);

                                        if (timeTicks && timeTicks !== "0" && typeof vTrk.overwriteClip === "function") {
                                            try { vTrk.overwriteClip(targetItem, timeTicks); insertedToSeq = true; } catch (_) {}
                                        }
                                        if (!insertedToSeq && playhead && typeof vTrk.overwriteClip === "function") {
                                            try { vTrk.overwriteClip(targetItem, playhead); insertedToSeq = true; } catch (_) {}
                                        }
                                        if (!insertedToSeq && timeTicks && timeTicks !== "0") {
                                            try { vTrk.insertClip(targetItem, timeTicks); insertedToSeq = true; } catch (_) {}
                                        }
                                        if (!insertedToSeq && playhead) {
                                            try { vTrk.insertClip(targetItem, playhead); insertedToSeq = true; } catch (_) {}
                                        }
                                        if (!insertedToSeq) {
                                            try { vTrk.insertClip(targetItem, pSec); insertedToSeq = true; } catch (_) {}
                                        }
                                        if (!insertedToSeq) {
                                            try { vTrk.insertClip(targetItem, "0"); insertedToSeq = true; } catch (_) {}
                                        }

                                        try {
                                            var dbgVidIns = new File("C:/Users/pc/AppData/Local/MediaFetch/logs/hostscript_debug.log");
                                            dbgVidIns.open("a");
                                            dbgVidIns.writeln("VIDEO INSERTION: insertedToSeq=" + insertedToSeq + " on vTrack=" + vTrk.name + " (idx=" + vIdx + ") aIdx=" + aIdx);
                                            dbgVidIns.close();
                                        } catch (_) {}
                                    }
                                    // ZERO clamping! Preserves 100% full duration of video and audio with zero clip loss.
                                }
                            }

                            if (insertedToSeq && (isPlaylist || Boolean(opts.isBatch))) {
                                try {
                                    var newEnd = getSequenceEndTime(activeSeq);
                                    if (newEnd && newEnd.ticks && newEnd.ticks !== "0") {
                                        if (typeof activeSeq.setPlayerPosition === "function") {
                                            try {
                                                activeSeq.setPlayerPosition(newEnd.ticks);
                                            } catch (_) {
                                                try {
                                                    var tObj = new Time();
                                                    tObj.ticks = newEnd.ticks;
                                                    activeSeq.setPlayerPosition(tObj);
                                                } catch (_) {}
                                            }
                                        }
                                    }
                                } catch (_) {}
                            } else if (insertedToSeq && playhead) {
                                // For single media & clipboard paste: strictly preserve editor's playhead position!
                                try {
                                    if (typeof activeSeq.setPlayerPosition === "function") {
                                        try {
                                            activeSeq.setPlayerPosition(playhead);
                                        } catch (_) {
                                            try {
                                                var tHead = new Time();
                                                tHead.ticks = playhead.ticks || timeTicks;
                                                activeSeq.setPlayerPosition(tHead);
                                            } catch (_) {
                                                try { activeSeq.setPlayerPosition(playhead.ticks || timeTicks); } catch (_) {}
                                            }
                                        }
                                    }
                                } catch (_) {}
                            }
                        } catch (seqInsertErr) {}
                    }

                    // 2. If no active sequence, create from clip (best for video/images)
                    if (!insertedToSeq && !isAudio) {
                        try {
                            if (typeof app.project.createNewSequenceFromClips === "function") {
                                var newSeq = app.project.createNewSequenceFromClips(seqName, [targetItem], targetBin || root);
                                if (newSeq) {
                                    insertedToSeq = true;
                                    // if (app.project.openSequence) app.project.openSequence(newSeq.sequenceID); // Preserved fullscreen panel
                                }
                            }
                        } catch (_) {}
                    }

                    // 3. Generic sequence fallback (supports audio and video)
                    if (!insertedToSeq) {
                        try {
                            if (typeof app.project.createNewSequence === "function") {
                                var createdSeq = app.project.createNewSequence(seqName, "");
                                var seq2 = app.project.activeSequence || createdSeq;
                                if (seq2) {
                                    var s2End = getSequenceEndTime(seq2);
                                    var insTicks = ((isPlaylist || Boolean(opts.isBatch)) && s2End.ticks !== "0") ? s2End.ticks : "0";
                                    var insSec = ((isPlaylist || Boolean(opts.isBatch)) && s2End.seconds > 0) ? s2End.seconds : 0;
                                    if (isAudio && seq2.audioTracks && seq2.audioTracks.numTracks > 0) {
                                        try { seq2.audioTracks[0].insertClip(targetItem, insTicks); insertedToSeq = true; } catch (_) {}
                                        if (!insertedToSeq) { try { seq2.audioTracks[0].insertClip(targetItem, insSec); insertedToSeq = true; } catch (_) {} }
                                        if (!insertedToSeq) { try { seq2.audioTracks[0].insertClip(targetItem, "0"); insertedToSeq = true; } catch (_) {} }
                                    } else if (seq2.videoTracks && seq2.videoTracks.numTracks > 0) {
                                        try { seq2.videoTracks[0].insertClip(targetItem, insTicks); insertedToSeq = true; } catch (_) {}
                                        if (!insertedToSeq) { try { seq2.videoTracks[0].insertClip(targetItem, insSec); insertedToSeq = true; } catch (_) {} }
                                        if (!insertedToSeq) { try { seq2.videoTracks[0].insertClip(targetItem, "0"); insertedToSeq = true; } catch (_) {} }
                                    }
                                    if (insertedToSeq && (isPlaylist || Boolean(opts.isBatch)) && typeof seq2.setPlayerPosition === "function") {
                                        try {
                                            var end2 = getSequenceEndTime(seq2);
                                            if (end2.ticks !== "0") seq2.setPlayerPosition(end2.ticks);
                                        } catch (_) {}
                                    }
                                }
                            }
                        } catch (_) {}
                    }
            } catch (prSeqErr) {}
        }

        var hasImported = Boolean(targetItem) || Boolean(didImport);
        if (!hasImported) {
            return JSON.stringify({
                success: false,
                appName: "premierepro",
                imported: false,
                insertedToSequence: false,
                error: "Premiere Pro could not import media into project bin.",
                filePath: filePath
            });
        }

        return JSON.stringify({
            success: true,
            appName: "premierepro",
            imported: true,
            insertedToSequence: insertedToSeq,
            filePath: filePath
        });
        } catch (pErr) {
            return JSON.stringify({
                success: false,
                appName: "premierepro",
                imported: false,
                insertedToSequence: false,
                error: "Exception in importFileToPremiere: " + pErr.toString(),
                filePath: filePath
            });
        }
    }

    function importFileToAfterEffects(filePath, insertAtPlayhead, optionsJson) {
        if (!app.project) {
            try {
                app.newProject();
            } catch (pErr) {
                return JSON.stringify({
                    success: false,
                    appName: "aftereffects",
                    imported: false,
                    insertedToSequence: false,
                    error: "No active project in After Effects. Please open or create a project first.",
                    filePath: filePath
                });
            }
        }

        var cleanPath = filePath.replace(/\\/g, '/');
        var nativePath = filePath.replace(/\//g, '\\');
        var file = new File(cleanPath);
        if (!file.exists) file = new File(filePath);
        if (!file.exists) file = new File(nativePath);
        if (!file.exists) {
            try { file = new File(File.decode(filePath)); } catch (_) {}
        }
        if (!file.exists) {
            try { file = new File(File.encode(filePath)); } catch (_) {}
        }

        // Stability check: wait until file exists and file size is stable across 2 checks (up to 15s)
        var fileStableAe = false;
        var prevSizeAe = -1;
        var startWaitAe = new Date().getTime();
        while (new Date().getTime() - startWaitAe < 15000) {
            if (file.exists && file.length > 0) {
                var curSizeAe = file.length;
                if (curSizeAe === prevSizeAe) {
                    fileStableAe = true;
                    break;
                }
                prevSizeAe = curSizeAe;
            }
            try { $.sleep(500); } catch (_) {}
            file = new File(cleanPath);
            if (!file.exists) file = new File(filePath);
            if (!file.exists) file = new File(nativePath);
        }

        if (!file.exists || file.length === 0) {
            return JSON.stringify({
                success: false,
                appName: "aftereffects",
                imported: false,
                insertedToSequence: false,
                error: "File does not exist or is empty (0 bytes) after stabilization wait: " + filePath,
                filePath: filePath
            });
        }

        var opts = {};
        if (typeof optionsJson === "string" && optionsJson.length > 0) {
            try { opts = JSON.parse(optionsJson); } catch (_) {}
        } else if (typeof optionsJson === "object" && optionsJson !== null) {
            opts = optionsJson;
        }

        app.beginUndoGroup("MediaFetch: Import Asset");

        try {
            function getOrCreateAeFolder(proj, parentFolder, folderName) {
                for (var i = 1; i <= proj.numItems; i++) {
                    var it = proj.item(i);
                    if (it && (it instanceof FolderItem || it.typeName === "Folder") && it.name === folderName) {
                        if (!parentFolder && (!it.parentFolder || it.parentFolder === proj.rootFolder)) {
                            return it;
                        }
                        if (parentFolder && it.parentFolder === parentFolder) {
                            return it;
                        }
                    }
                }
                var newFolder = proj.items.addFolder(folderName);
                if (parentFolder) {
                    newFolder.parentFolder = parentFolder;
                }
                return newFolder;
            }

            var proj = app.project;
            var cleanPath = filePath.replace(/\\/g, '/');
            var isClipboard = Boolean(opts.isClipboard) || cleanPath.indexOf("Clipboard") !== -1;
            var isSimple = Boolean(opts.isSimplePath || opts.isSimple || (opts.downloadLocationMode === 'simple'));
            var isCustomFlat = Boolean(opts.isCustomFlat || (opts.downloadLocationMode === 'custom_flat'));
            var isCustom = !isSimple && !isCustomFlat && Boolean(opts.isCustomPath || opts.isCustom || (opts.downloadLocationMode === 'custom'));
            var isCloud = Boolean(opts.isCloud || cleanPath.indexOf("Cloud Links") !== -1 || cleanPath.indexOf("Cloud") !== -1);
            var isPlaylist = Boolean(opts.isPlaylist || cleanPath.indexOf("Playlists") !== -1);
            var playlistTitle = sanitizeFolderName(opts.playlistTitle);
            var customFolderName = sanitizeFolderName(opts.customFolderName);
            var subFolderName = safeTrim(opts.subFolderName);

            var ext = cleanPath.split('.').pop().toLowerCase().split('?')[0];
            var isAudio = (ext === 'mp3' || ext === 'wav' || ext === 'm4a' || ext === 'flac' || ext === 'aac' || ext === 'ogg' || ext === 'opus' || ext === 'aiff');
            var isImage = (ext === 'jpg' || ext === 'jpeg' || ext === 'png' || ext === 'webp' || ext === 'gif' || ext === 'bmp' || ext === 'tiff' || ext === 'tif' || ext === 'svg');
            var typeFolderName = isAudio ? "Audio" : (isImage ? "Images" : "Video");

            var targetFolder = null;

            if (isCustomFlat) {
                // Direct Custom Flat Folder: import directly into custom folder without subfolders
                var pPartsFlat = cleanPath.split('/');
                var parentNameFlat = pPartsFlat.length > 1 ? pPartsFlat[pPartsFlat.length - 2] : "Downloads";
                var rootBinNameFlat = customFolderName || parentNameFlat || "MediaFetch";
                targetFolder = getOrCreateAeFolder(proj, null, rootBinNameFlat);
            } else if (isCustom) {
                var pParts = cleanPath.split('/');
                var parentName = pParts.length > 1 ? pParts[pParts.length - 2] : "";
                var isStrictThreeFolder = (parentName === "Video" || parentName === "Audio" || parentName === "Images" || parentName === "Image");

                if (isStrictThreeFolder) {
                    var grandParentName = pParts.length > 2 ? pParts[pParts.length - 3] : "";
                    var customRootFolder = grandParentName ? getOrCreateAeFolder(proj, null, grandParentName) : null;
                    targetFolder = getOrCreateAeFolder(proj, customRootFolder, typeFolderName) || customRootFolder;
                } else {
                    var rootBinName = customFolderName || (isPlaylist ? (playlistTitle || "Playlist") : (isCloud ? "Cloud Media" : ""));
                    if (!rootBinName) {
                        rootBinName = parentName || "Downloads";
                    }
                    var customRootFolder = getOrCreateAeFolder(proj, null, rootBinName);
                    if (subFolderName) {
                        var sParts = subFolderName.replace(/\\/g, '/').split('/');
                        var cur = customRootFolder;
                        for (var s = 0; s < sParts.length; s++) {
                            if (sParts[s] && sParts[s].length > 0) {
                                cur = getOrCreateAeFolder(proj, cur, sParts[s]);
                            }
                        }
                        targetFolder = cur || customRootFolder;
                    } else {
                        targetFolder = getOrCreateAeFolder(proj, customRootFolder, typeFolderName) || customRootFolder;
                    }
                }
            } else if (isPlaylist) {
                var mediaFetchFolder = getOrCreateAeFolder(proj, null, "MediaFetch");
                var playlistRoot = getOrCreateAeFolder(proj, mediaFetchFolder, "Playlists");
                var pName = playlistTitle || customFolderName || "Playlist 1";
                targetFolder = getOrCreateAeFolder(proj, playlistRoot, pName);
            } else if (isCloud) {
                var mediaFetchFolder = getOrCreateAeFolder(proj, null, "MediaFetch");
                var cloudRoot = getOrCreateAeFolder(proj, mediaFetchFolder, "Cloud Links");
                var cloudFolder = getOrCreateAeFolder(proj, cloudRoot, customFolderName || "Cloud Media");
                if (subFolderName) {
                    var sParts3 = subFolderName.replace(/\\/g, '/').split('/');
                    var cur3 = cloudFolder;
                    for (var s3 = 0; s3 < sParts3.length; s3++) {
                        if (sParts3[s3] && sParts3[s3].length > 0) {
                            cur3 = getOrCreateAeFolder(proj, cur3, sParts3[s3]);
                        }
                    }
                    targetFolder = cur3 || cloudFolder;
                } else {
                    targetFolder = cloudFolder;
                }
            } else {
                // Simple Project Path (DEFAULT): Project -> MediaFetch -> Video, Audio, Images only
                var mediaFetchFolder = getOrCreateAeFolder(proj, null, "MediaFetch");
                targetFolder = getOrCreateAeFolder(proj, mediaFetchFolder, typeFolderName) || mediaFetchFolder;
            }

            var importOptions = new ImportOptions();
            importOptions.file = file;
            var footageItem = null;

            // Free fragmented image & frame cache buffers prior to importing high-res/4K footage
            try {
                if (typeof app.purge === "function" && typeof PurgeTarget !== "undefined" && PurgeTarget.IMAGE_CACHES) {
                    app.purge(PurgeTarget.IMAGE_CACHES);
                }
            } catch (pErr) {}

            try {
                footageItem = app.project.importFile(importOptions);
            } catch (impErr) {
                try {
                    var io2 = new ImportOptions();
                    io2.file = new File(file.fsName);
                    footageItem = app.project.importFile(io2);
                } catch (impErr2) {
                    for (var fi = 1; fi <= proj.numItems; fi++) {
                        var it = proj.item(fi);
                        if (it && it.file && it.file.fsName === file.fsName) {
                            footageItem = it;
                            break;
                        }
                    }
                    if (!footageItem) {
                        app.endUndoGroup();
                        return JSON.stringify({
                            success: false,
                            error: "After Effects failed to import file (" + file.name + "): " + impErr.toString()
                        });
                    }
                }
            }
            if (footageItem && targetFolder) {
                try {
                    footageItem.parentFolder = targetFolder;
                } catch (_) {}
            }

            var isSingleLink = !isPlaylist && !isCloud && !Boolean(opts.isBatch);
            if (opts.isSingleLink !== undefined) {
                isSingleLink = Boolean(opts.isSingleLink);
            }
            if (opts.insertToTimeline !== undefined) {
                insertAtPlayhead = Boolean(opts.insertToTimeline);
            } else if (opts.addToTimeline !== undefined) {
                insertAtPlayhead = Boolean(opts.addToTimeline);
            }
            if (isClipboard) {
                insertAtPlayhead = true;
            } else if (!isSingleLink && !opts.insertToTimeline && !opts.addToTimeline) {
                insertAtPlayhead = false;
            }

            var insertedToSeq = false;
            if (insertAtPlayhead && footageItem) {
                try {
                    var comp = app.project.activeItem;
                    if (!comp || !(comp instanceof CompItem)) {
                        for (var cIdx = 1; cIdx <= app.project.numItems; cIdx++) {
                            if (app.project.item(cIdx) instanceof CompItem) {
                                comp = app.project.item(cIdx);
                                break;
                            }
                        }
                    }
                    if (!comp || !(comp instanceof CompItem)) {
                        var w = (footageItem.width && footageItem.width > 0) ? footageItem.width : 1920;
                        var h = (footageItem.height && footageItem.height > 0) ? footageItem.height : 1080;
                        var dur = (footageItem.duration && footageItem.duration > 0) ? footageItem.duration : 30;
                        var fps = (footageItem.frameRate && footageItem.frameRate > 0) ? footageItem.frameRate : 30;
                        var rawName = footageItem.name || "MediaFetch Comp";
                        var dotIdx = rawName.lastIndexOf(".");
                        var cName = (dotIdx > 0) ? rawName.substring(0, dotIdx) : rawName;
                        comp = app.project.items.addComposition(cName, w, h, 1.0, dur, fps);
                    }
                    if (comp && comp instanceof CompItem) {
                        var playheadTime = (comp.time !== undefined && comp.time !== null) ? comp.time : 0;
                        var insertTime = playheadTime;

                        // Sequential insertion for playlist / batch items:
                        if (isPlaylist || Boolean(opts.isBatch)) {
                            var maxEnd = 0;
                            for (var l = 1; l <= comp.layers.length; l++) {
                                var existingLayer = comp.layer(l);
                                if (existingLayer && existingLayer.outPoint && existingLayer.outPoint > maxEnd) {
                                    maxEnd = existingLayer.outPoint;
                                }
                            }
                            if (maxEnd > 0) {
                                insertTime = Math.max(playheadTime, maxEnd);
                            }
                        }

                        // Smart Gap & Duration Detection for After Effects:
                        var minNextInPoint = Infinity;
                        var defaultDur = (footageItem.duration && footageItem.duration > 0) ? footageItem.duration : 5;
                        var targetDur = defaultDur;

                        // Only gap-fit image media: videos and audios keep their full natural length
                        if (isImage && !isPlaylist && !Boolean(opts.isBatch)) {
                            for (var l2 = 1; l2 <= comp.numLayers; l2++) {
                                var exLay = comp.layer(l2);
                                if (!exLay) continue;
                                try {
                                    if (exLay.locked) continue;
                                    var lIn = exLay.inPoint;
                                    if (lIn > playheadTime + 0.05) {
                                        if (lIn < minNextInPoint) {
                                            minNextInPoint = lIn;
                                        }
                                    }
                                } catch (_) {}
                            }
                            if (minNextInPoint !== Infinity && minNextInPoint > playheadTime + 0.05) {
                                var gap = minNextInPoint - playheadTime;
                                if (gap > 0.05) {
                                    targetDur = gap;
                                }
                            }
                        }

                        var layer = comp.layers.add(footageItem);
                        if (layer) {
                            layer.startTime = insertTime;
                            layer.inPoint = insertTime;
                            layer.outPoint = insertTime + targetDur;

                            // Smart layer positioning: don't force top of comp if there are adjustment layers or text titles!
                            var insertBelowIndex = 1;
                            for (var li = 1; li <= comp.numLayers; li++) {
                                var exTop = comp.layer(li);
                                if (exTop && exTop !== layer) {
                                    if (exTop.adjustmentLayer || (typeof TextLayer !== "undefined" && exTop instanceof TextLayer)) {
                                        insertBelowIndex = li + 1;
                                    } else {
                                        break;
                                    }
                                }
                            }
                            if (insertBelowIndex > 1 && insertBelowIndex <= comp.numLayers) {
                                try { layer.moveAfter(comp.layer(insertBelowIndex - 1)); } catch (_) { layer.moveToBeginning(); }
                            } else {
                                layer.moveToBeginning();
                            }

                            insertedToSeq = true;
                            var newEnd = insertTime + targetDur;
                            if (comp.duration < newEnd) {
                                comp.duration = newEnd + 2;
                            }
                            if (isPlaylist || Boolean(opts.isBatch)) {
                                comp.time = newEnd;
                            } else {
                                comp.time = playheadTime;
                            }
                        }
                        // Preserved fullscreen state - do not force-activate viewer during background import
                    }
                } catch (aeSeqErr) {}
            }

            // Clean up transient decoders and memory allocations after import
            try {
                if (typeof app.purge === "function" && typeof PurgeTarget !== "undefined" && PurgeTarget.IMAGE_CACHES) {
                    app.purge(PurgeTarget.IMAGE_CACHES);
                }
            } catch (pErr2) {}

            var hasImportedAe = Boolean(footageItem);
            if (!hasImportedAe) {
                app.endUndoGroup();
                return JSON.stringify({
                    success: false,
                    appName: "aftereffects",
                    imported: false,
                    insertedToSequence: false,
                    error: "After Effects could not import media into project.",
                    filePath: filePath
                });
            }

            app.endUndoGroup();

            return JSON.stringify({
                success: true,
                appName: "aftereffects",
                imported: true,
                insertedToSequence: insertedToSeq,
                filePath: filePath
            });
        } catch (e) {
            app.endUndoGroup();
            return JSON.stringify({
                success: false,
                appName: "aftereffects",
                imported: false,
                insertedToSequence: false,
                error: e.toString(),
                filePath: filePath
            });
        }
    }

    function selectDownloadFolder() {
        try {
            var f = Folder.selectDialog("Select MediaFetch Download Destination Folder");
            return f ? f.fsName : "";
        } catch (e) {
            return "";
        }
    }

    function importMedia(filePath, insertAtPlayhead, optionsJson) {
        try {
            if (isPremiere()) {
                return importFileToPremiere(filePath, insertAtPlayhead, optionsJson);
            } else if (isAfterEffects()) {
                return importFileToAfterEffects(filePath, insertAtPlayhead, optionsJson);
            } else {
                return JSON.stringify({ success: false, error: "Unsupported Adobe host application." });
            }
        } catch (err) {
            return JSON.stringify({ success: false, error: err.toString() });
        }
    }

    function importToTimeline(filePath, optionsJson) {
        return importMedia(filePath, true, optionsJson);
    }

    return {
        getHostInfo: getHostInfo,
        importMedia: importMedia,
        importToTimeline: importToTimeline,
        selectDownloadFolder: selectDownloadFolder
    };
})();

if (typeof $.global !== "undefined") {
    $.global.MediaFetchHost = MediaFetchHost;
    $.global.MediaSearchHost = MediaFetchHost;
}
var MediaSearchHost = MediaFetchHost;
