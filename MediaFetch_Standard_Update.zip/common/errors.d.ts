import { DownloadError } from './types.js';
export declare function classifyError(err: unknown, context?: string): DownloadError;
/**
 * Strips potential tokens, passwords, cookies, and local usernames from diagnostic strings.
 */
export declare function sanitizeErrorDetails(input: string): string;
