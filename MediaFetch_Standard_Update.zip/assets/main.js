(() => {
  var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
    get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
  }) : x)(function(x) {
    if (typeof require !== "undefined") return require.apply(this, arguments);
    throw Error('Dynamic require of "' + x + '" is not supported');
  });

  // src/ui/services/client.ts
  var ServiceClient = class {
    ws;
    port = 48924;
    isConnected = false;
    listeners = [];
    reconnectTimer;
    statusListeners = [];
    constructor(preferredPort = 48924) {
      this.port = preferredPort;
    }
    isOnline() {
      return this.isConnected;
    }
    onStatusChanged(cb) {
      this.statusListeners.push(cb);
      cb(this.isConnected);
    }
    subscribe(listener) {
      this.listeners.push(listener);
      return () => {
        this.listeners = this.listeners.filter((l) => l !== listener);
      };
    }
    notifyStatus(online) {
      this.isConnected = online;
      for (const cb of this.statusListeners) {
        cb(online);
      }
    }
    notifyListeners(msg) {
      for (const l of this.listeners) {
        try {
          l(msg);
        } catch (err) {
          console.error("Error in message listener:", err);
        }
      }
    }
    pendingQueue = [];
    connect() {
      if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
        return;
      }
      try {
        this.ws = new WebSocket(`ws://127.0.0.1:${this.port}`);
        this.ws.onopen = () => {
          var _a;
          console.log("Connected to MediaFetch service daemon.");
          this.notifyStatus(true);
          this.autoStartAttempts = 0;
          if (this.reconnectTimer) {
            clearTimeout(this.reconnectTimer);
            this.reconnectTimer = void 0;
          }
          while (this.pendingQueue.length > 0) {
            const m = this.pendingQueue.shift();
            if (m) {
              try {
                (_a = this.ws) == null ? void 0 : _a.send(JSON.stringify(m));
              } catch (_) {
              }
            }
          }
          try {
            if (typeof window !== "undefined" && window.mediaFetchApp && typeof window.mediaFetchApp.checkPendingImports === "function") {
              window.mediaFetchApp.checkPendingImports();
            }
          } catch (_) {}
        };
        this.ws.onmessage = (event) => {
          try {
            const parsed = JSON.parse(event.data);
            this.notifyListeners(parsed);
          } catch (e) {
            console.error("Failed to parse WebSocket message:", e);
          }
        };
        this.ws.onclose = () => {
          this.notifyStatus(false);
          this.tryAutoStartDaemon();
          this.scheduleReconnect();
        };
        this.ws.onerror = () => {
          this.notifyStatus(false);
          this.tryAutoStartDaemon();
        };
      } catch {
        this.notifyStatus(false);
        this.tryAutoStartDaemon();
        this.scheduleReconnect();
      }
    }
    autoStartAttempts = 0;
    tryAutoStartDaemon(force = false) {
      var _a, _b, _c, _d;
      if (force) this.autoStartAttempts = 0;
      if (this.autoStartAttempts > 5) return;
      this.autoStartAttempts++;
      try {
        if (typeof window !== "undefined") {
          const nodeRequire = window.require || ((_a = window.cep_node) == null ? void 0 : _a.require);
          if (nodeRequire) {
            const path = nodeRequire("path");
            const fs = nodeRequire("fs");
            let proc = null;
            try {
              proc = typeof process !== "undefined" ? process : nodeRequire("process");
            } catch {
            }
            const appData = ((_b = proc == null ? void 0 : proc.env) == null ? void 0 : _b.APPDATA) || "";
            const localAppData = ((_c = proc == null ? void 0 : proc.env) == null ? void 0 : _c.LOCALAPPDATA) || "";
            let extDir = "";
            try {
              if ((_d = window.__adobe_cep__) == null ? void 0 : _d.getSystemPath) {
                extDir = window.__adobe_cep__.getSystemPath("extension");
              } else if (window.CSInterface) {
                extDir = new window.CSInterface().getSystemPath("extension");
              }
            } catch {
            }
            if (!extDir && window.location && window.location.pathname) {
              let p = window.location.pathname.replace(/^[\\\/]([A-Za-z]:)/, "$1");
              extDir = p.substring(0, Math.max(p.lastIndexOf("/"), p.lastIndexOf("\\")));
            }
            const candidates = [
              extDir ? path.join(extDir, "service", "server.bundle.js") : "",
              extDir ? path.join(extDir, "service", "server.js") : "",
              appData ? path.join(appData, "Adobe", "CEP", "extensions", "com.mediafetch.adobe.pro", "service", "server.bundle.js") : "",
              appData ? path.join(appData, "Adobe", "CEP", "extensions", "com.mediafetch.adobe.pro", "service", "server.js") : "",
              localAppData ? path.join(localAppData, "MediaFetchPro", "server.bundle.js") : "",
              localAppData ? path.join(localAppData, "MediaFetchPro", "server.js") : ""
            ].filter(Boolean);
            const nodeExecutables = [
              "C:\\Program Files\\nodejs\\node.exe",
              "C:\\Program Files (x86)\\nodejs\\node.exe",
              "/opt/homebrew/bin/node",
              "/usr/local/bin/node",
              "/usr/bin/node",
              "node"
            ];
            const logDir = localAppData ? path.join(localAppData, "MediaFetch", "logs") : "";
            let outFd = "ignore";
            if (logDir) {
              try { fs.mkdirSync(logDir, { recursive: true }); } catch (_) {}
              try { outFd = fs.openSync(path.join(logDir, "service.log"), "a"); } catch (_) {}
            }
            for (const candidate of candidates) {
              if (fs.existsSync(candidate)) {
                console.log("[MediaFetch] Attempting auto-start from:", candidate);
                try {
                  const cp = nodeRequire("child_process");
                  for (const nodeExe of nodeExecutables) {
                    try {
                      const child = cp.spawn(nodeExe, ["--expose-gc", "--max-old-space-size=512", candidate], {
                        detached: true,
                        stdio: ["ignore", outFd, outFd],
                        windowsHide: true,
                        env: { ...proc == null ? void 0 : proc.env, PORT: "48924" }
                      });
                      child.on("error", (err) => {
                        console.warn(`[MediaFetch] Daemon spawn error on ${nodeExe}:`, err);
                      });
                      child.unref();
                      console.log(`[MediaFetch] Spawned daemon with ${nodeExe}: ${candidate}`);
                      setTimeout(() => this.connect(), 600);
                      setTimeout(() => this.connect(), 1200);
                      return;
                    } catch {
                    }
                  }
                } catch {
                }
              }
            }
          }
        }
      } catch (e) {
        console.warn("[MediaFetch] Auto-start daemon error:", e);
      }
    }
    supervisorInterval = void 0;
    startSupervisor() {
      if (this.supervisorInterval) return;
      this.supervisorInterval = window.setInterval(async () => {
        if (!this.isConnected) {
          this.tryAutoStartDaemon();
          this.connect();
        } else {
          try {
            const res = await fetch(`http://127.0.0.1:${this.port}/api/health`, { cache: "no-store" }).catch(() => null);
            if (!res || !res.ok) {
              console.warn("[MediaFetch] Service health ping failed, attempting restart...");
              this.tryAutoStartDaemon(true);
            }
          } catch (_) {}
        }
      }, 10000);
    }
    scheduleReconnect() {
      if (this.reconnectTimer) return;
      this.reconnectTimer = window.setTimeout(() => {
        this.reconnectTimer = void 0;
        this.connect();
      }, 1200);
    }
    send(msg) {
      msg.edition = "pro";
      if (msg.payload && typeof msg.payload === "object") {
        msg.payload.edition = "pro";
      }
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        try {
          this.ws.send(JSON.stringify(msg));
          return;
        } catch (err) {
          console.warn("[MediaFetch] ws.send error, queueing message:", err);
        }
      }
      this.pendingQueue.push(msg);
      this.connect();
      this.tryAutoStartDaemon(true);
    }
    markItemImported(id, ok, error) {
      this.send({
        type: 'ITEM_IMPORTED',
        payload: { id, ok, error }
      });
    }
    inProcessAnalysisActive = false;
    async runInProcessAnalysis(url, timeoutMs = 25e3) {
      var _a, _b;
      if (this.inProcessAnalysisActive) return;
      if (typeof window === "undefined") return;
      const nodeRequire = window.require || ((_a = window.cep_node) == null ? void 0 : _a.require);
      if (!nodeRequire) return;
      this.inProcessAnalysisActive = true;
      try {
        let extDir = "";
        try {
          if ((_b = window.__adobe_cep__) == null ? void 0 : _b.getSystemPath) {
            extDir = window.__adobe_cep__.getSystemPath("extension");
          } else if (window.CSInterface) {
            extDir = new window.CSInterface().getSystemPath("extension");
          }
        } catch (_) {
        }
        if (!extDir && window.location && window.location.pathname) {
          let p = window.location.pathname.replace(/^[\\\/]([A-Za-z]:)/, "$1");
          extDir = p.substring(0, Math.max(p.lastIndexOf("/"), p.lastIndexOf("\\")));
        }
        const path = nodeRequire("path");
        const fs = nodeRequire("fs");
        const candidates = [
          extDir ? path.join(extDir, "service", "server.bundle.js") : "",
          extDir ? path.join(extDir, "service", "server.js") : "",
          extDir ? path.join(extDir, "service", "analyzer.js") : ""
        ].filter(Boolean);
        let analyzer = null;
        for (const cand of candidates) {
          if (fs.existsSync(cand)) {
            try {
              const mod = nodeRequire(cand);
              if (mod && (mod.metadataAnalyzer || mod.MetadataAnalyzer)) {
                analyzer = mod.metadataAnalyzer || (mod.MetadataAnalyzer ? new mod.MetadataAnalyzer() : null);
                break;
              }
            } catch (_) {
            }
          }
        }
        if (!analyzer) return;
        console.log("[MediaFetch] Running high-speed in-process analysis for:", url);
        this.notifyListeners({ type: "ANALYSIS_STARTED", payload: { url } });
        if (analyzer.isPlaylistUrl(url)) {
          const playlist = await analyzer.analyzePlaylist(url, timeoutMs);
          this.notifyListeners({ type: "PLAYLIST_ANALYSIS_SUCCESS", payload: playlist });
          this.notifyListeners({ type: "PLAYLIST_METADATA_RESULT", payload: playlist });
        } else {
          const meta = await analyzer.analyzeUrl(url, timeoutMs);
          if (meta.isPlaylist || meta.isCarousel || (meta.items && meta.items.length > 1)) {
            this.notifyListeners({ type: "PLAYLIST_ANALYSIS_SUCCESS", payload: meta });
            this.notifyListeners({ type: "PLAYLIST_METADATA_RESULT", payload: meta });
          } else {
            this.notifyListeners({ type: "ANALYSIS_SUCCESS", payload: meta });
            this.notifyListeners({ type: "METADATA_RESULT", payload: meta });
          }
        }
      } catch (err) {
        console.warn("[MediaFetch] In-process analysis notice:", (err == null ? void 0 : err.message) || err);
        this.notifyListeners({
          type: "ANALYSIS_ERROR",
          payload: { url, error: (err == null ? void 0 : err.message) || "Analysis failed", details: err == null ? void 0 : err.details, category: (err == null ? void 0 : err.category) || "EXTRACTION_ERROR" }
        });
      } finally {
        this.inProcessAnalysisActive = false;
      }
    }
    analyzeUrl(url, timeoutMs) {
      this.send({ type: "ANALYZE_URL", payload: { url, timeoutMs } });
      this.runInProcessAnalysis(url, timeoutMs);
    }
    analyzePlaylist(url, timeoutMs) {
      this.send({ type: "ANALYZE_PLAYLIST", payload: { url, timeoutMs } });
      this.runInProcessAnalysis(url, timeoutMs);
    }
    startDownload(url, profile, projectContext, targetDirectory, metadata) {
      const isPro = window.__MF_EDITION__ === "pro" || window.location.pathname.includes(".pro") || document.title.includes("Pro");
      const edition = isPro ? "pro" : "standard";
      const targetHost = getHostAppId() || window.__MF_HOST_ID__ || (typeof hostAdapter !== "undefined" && hostAdapter.hostId) || "ppro";
      this.send({
        type: "START_DOWNLOAD",
        payload: { url, profile, projectContext, targetDirectory, metadata: { ...metadata || {}, edition, targetHost }, edition, targetHost }
      });
    }
    startPlaylistDownload(items, profile, projectContext, targetDirectory, options) {
      const isPro = window.__MF_EDITION__ === "pro" || window.location.pathname.includes(".pro") || document.title.includes("Pro");
      const edition = isPro ? "pro" : "standard";
      const targetHost = getHostAppId() || window.__MF_HOST_ID__ || (typeof hostAdapter !== "undefined" && hostAdapter.hostId) || "ppro";
      this.send({
        type: "START_PLAYLIST_DOWNLOAD",
        payload: {
          items,
          profile,
          projectContext,
          targetDirectory,
          customFolderName: options == null ? void 0 : options.customFolderName,
          preserveSubfolders: options == null ? void 0 : options.preserveSubfolders,
          autoImport: options == null ? void 0 : options.autoImport,
          zipPackage: options == null ? void 0 : options.zipPackage,
          playlistTitle: options == null ? void 0 : options.playlistTitle,
          isCloud: options == null ? void 0 : options.isCloud,
          edition,
          targetHost
        }
      });
    }
    pauseDownload(id) {
      this.send({ type: "PAUSE_DOWNLOAD", payload: { id } });
    }
    resumeDownload(id) {
      this.send({ type: "RESUME_DOWNLOAD", payload: { id } });
    }
    cancelDownload(id) {
      this.send({ type: "CANCEL_DOWNLOAD", payload: { id } });
    }
    retryDownload(id) {
      this.send({ type: "RETRY_DOWNLOAD", payload: { id } });
    }
    clearCompleted() {
      const isPro = window.__MF_EDITION__ === "pro" || window.location.pathname.includes(".pro") || document.title.includes("Pro");
      const edition = isPro ? "pro" : "standard";
      this.send({ type: "CLEAR_COMPLETED", payload: { edition }, edition });
    }
    clearAll() {
      const isPro = window.__MF_EDITION__ === "pro" || window.location.pathname.includes(".pro") || document.title.includes("Pro");
      const edition = isPro ? "pro" : "standard";
      this.send({ type: "CLEAR_ALL", payload: { edition }, edition });
    }
    getSettings() {
      this.send({ type: "GET_SETTINGS" });
    }
    updateSettings(settings) {
      this.send({ type: "UPDATE_SETTINGS", payload: settings });
    }
    getDiagnostics() {
      this.send({ type: "GET_DIAGNOSTICS" });
    }
    runSystemCheck() {
      this.send({ type: "RUN_SYSTEM_CHECK" });
    }
    installDependency(name) {
      this.send({ type: "INSTALL_DEPENDENCY", payload: { name } });
    }
    updateYtDlp() {
      this.send({ type: "UPDATE_YTDLP" });
    }
    getHistory() {
      this.send({ type: "GET_HISTORY" });
    }
    clearHistory() {
      this.send({ type: "CLEAR_HISTORY" });
    }
    removeHistoryItem(id) {
      this.send({ type: "REMOVE_HISTORY_ITEM", payload: { id } });
    }
    checkDuplicate(title, container, targetDirectory) {
      this.send({
        type: "CHECK_DUPLICATE",
        payload: { title, container, targetDirectory }
      });
    }
    openFolderDialog() {
      this.send({ type: "OPEN_FOLDER_DIALOG" });
    }
  };
  var serviceClient = new ServiceClient();

  // src/host/premiere-adapter.ts
  var PremiereHostAdapter = class {
    themeListeners = [];
    async getProjectContext() {
      if (typeof getHostAppId === "function" && getHostAppId() === "aeft") {
        return new AfterEffectsHostAdapter().getProjectContext();
      }
      try {
        const hostInfoResult = await this.evalScript("MediaFetchHost.getHostInfo()");
        if (hostInfoResult && typeof hostInfoResult === "string" && hostInfoResult !== "EvalScript error.") {
          try {
            const parsedHost = JSON.parse(hostInfoResult);
            if (parsedHost && parsedHost.projectPath && parsedHost.projectPath.length > 0) {
              const cleanPath = parsedHost.projectPath.replace(/\\/g, "/");
              const dir = cleanPath.substring(0, cleanPath.lastIndexOf("/"));
              const name = parsedHost.projectName || cleanPath.substring(cleanPath.lastIndexOf("/") + 1) || "Premiere Project";
              return {
                application: "premierepro",
                applicationVersion: parsedHost.appVersion || "26.0",
                projectSaved: true,
                projectName: name,
                projectPath: parsedHost.projectPath,
                projectDirectory: dir.replace(/\//g, "\\")
              };
            }
          } catch (_) {
          }
        }
        const script = `
        (function() {
          try {
            if (app && app.project) {
              var pPath = "";
              if (app.project.path && app.project.path.length > 0) {
                pPath = app.project.path;
              } else if (app.project.documentPath && app.project.documentPath.length > 0) {
                pPath = app.project.documentPath;
              }

              if (pPath && pPath.length > 0) {
                return JSON.stringify({
                  saved: true,
                  path: pPath,
                  name: app.project.name || "Premiere Project",
                  version: app.version || "26.0"
                });
              } else {
                return JSON.stringify({
                  saved: false,
                  name: "Active Premiere Project (Unsaved)",
                  version: app.version || "26.0"
                });
              }
            }
          } catch (err) {
            return JSON.stringify({ saved: false, error: String(err) });
          }
          return JSON.stringify({ saved: false });
        })();
      `;
        const result = await this.evalScript(script);
        if (result && typeof result === "string" && result !== "EvalScript error.") {
          const parsed = JSON.parse(result);
          if (parsed) {
            if (parsed.saved && parsed.path) {
              const cleanPath = parsed.path.replace(/\\/g, "/");
              const dir = cleanPath.substring(0, cleanPath.lastIndexOf("/"));
              const name = cleanPath.substring(cleanPath.lastIndexOf("/") + 1) || parsed.name;
              return {
                application: "premierepro",
                applicationVersion: parsed.version || "26.0",
                projectSaved: true,
                projectName: name,
                projectPath: parsed.path,
                projectDirectory: dir.replace(/\//g, "\\")
              };
            } else if (parsed.name) {
              return {
                application: "premierepro",
                applicationVersion: parsed.version || "26.0",
                projectSaved: false,
                projectName: parsed.name
              };
            }
          }
        }
      } catch (e) {
        console.warn("Error reading Premiere Pro project context:", e);
      }
      return {
        application: "premierepro",
        applicationVersion: "26.0",
        projectSaved: false
      };
    }
    async revealInFinder(filePath) {
      try {
        if (typeof window !== "undefined" && window.require) {
          const cp = window.require("child_process");
          if (cp == null ? void 0 : cp.exec) {
            cp.exec(`explorer.exe /select,"${filePath.replace(/\//g, "\\")}"`);
            return;
          }
        }
      } catch {
      }
      try {
        const script = `
        (function() {
          var f = new File("${filePath.replace(/\\/g, "/")}");
          if (f.exists) {
            f.execute();
          }
        })();
      `;
        await this.evalScript(script);
      } catch {
      }
    }
    async openFile(filePath) {
      await this.revealInFinder(filePath);
    }
    async importToProject(filePath, options) {
      if (typeof getHostAppId === "function" && getHostAppId() === "aeft") {
        return new AfterEffectsHostAdapter().importToProject(filePath, options);
      }
      try {
        const cleanPath = filePath.replace(/\\/g, "/");
        const isCustom = (options == null ? void 0 : options.isCustomPath) ? true : false;
        const isSimple = Boolean((options == null ? void 0 : options.isSimplePath) || (options == null ? void 0 : options.isSimple) || ((_a = (_b = this.settings) == null ? void 0 : _b.downloads) == null ? void 0 : _a.downloadLocationMode) === "simple");
        const isCloud = (options == null ? void 0 : options.isCloud) ? true : false;
        const isPlaylist = (options == null ? void 0 : options.isPlaylist) ? true : false;
        const isBatch = (options == null ? void 0 : options.isBatch) ? true : false;
        const isSingleLink = (options == null ? void 0 : options.isSingleLink) !== void 0 ? options.isSingleLink : !isPlaylist && !isCloud && !isBatch;
        const shouldInsertTimeline = Boolean(((options == null ? void 0 : options.insertToTimeline) || (options == null ? void 0 : options.addToTimeline)) && isSingleLink);
        const playlistTitle = ((options == null ? void 0 : options.playlistTitle) || "").replace(/[\\/:"*?<>|]/g, " ").trim();
        const customFolderName = ((options == null ? void 0 : options.customFolderName) || "").replace(/[\\/:"*?<>|]/g, " ").trim();
        const subFolderName = ((options == null ? void 0 : options.subFolderName) || "").trim();
        const isClipboard = Boolean((options == null ? void 0 : options.isClipboard) || cleanPath.includes("Clipboard"));
        const isSearch = Boolean((options == null ? void 0 : options.isSearch) || cleanPath.includes("/Search/") || cleanPath.includes("\\Search\\") || cleanPath.includes("SerachMediafetch") || cleanPath.includes("SearchMediafetch"));
        const optsObj = {
          downloadLocationMode: (options == null ? void 0 : options.downloadLocationMode) || (isCustom ? "custom" : (isSimple ? "simple" : "project")),
          isCustomPath: isCustom,
          isCustomFlat: Boolean(options == null ? void 0 : options.isCustomFlat),
          isSimplePath: isSimple,
          isSimple: isSimple,
          isCloud,
          isPlaylist,
          isBatch,
          isSingleLink,
          isSearch,
          playlistTitle,
          customFolderName,
          subFolderName,
          isClipboard,
          addToTimeline: shouldInsertTimeline,
          insertToTimeline: shouldInsertTimeline
        };
        const optsJson = JSON.stringify(optsObj);

        // Ensure hostscript.jsx is dynamically evaluated in Premiere ExtendScript engine
        try {
          let extDir = "";
          if (typeof window !== "undefined") {
            if (window.__adobe_cep__ && window.__adobe_cep__.getSystemPath) {
              extDir = window.__adobe_cep__.getSystemPath("extension");
            } else if (window.CSInterface) {
              extDir = new window.CSInterface().getSystemPath("extension");
            }
          }
          if (extDir) {
            const jsxP = (extDir + "/jsx/hostscript.jsx").replace(/\\/g, "/");
            await this.evalScript(`(function(){ try { var f = new File("${jsxP}"); if (f.exists) { $.evalFile(f); return "loaded"; } } catch(e){} return "none"; })()`);
          }
        } catch (_) {}

        try {
          const evalResStr = await this.evalScript(`MediaFetchHost.importMedia(${JSON.stringify(cleanPath)}, ${shouldInsertTimeline ? "true" : "false"}, ${optsJson})`);
          if (evalResStr && evalResStr !== "EvalScript error.") {
            try {
              const parsed = JSON.parse(evalResStr);
              if (parsed && parsed.success && parsed.imported !== false) {
                console.log("[MediaFetch] HostScript importMedia succeeded:", parsed);
                return true;
              }
            } catch (_) {
              if (evalResStr === "true" || evalResStr === true) return true;
            }
          }
        } catch (hErr) {
          console.warn("[MediaFetch] MediaFetchHost.importMedia attempt notice:", hErr);
        }

        const script = `
        (function() {
          try {
            if (!app || !app.project) return "no_project";
            var project = app.project;
            var root = project.rootItem;
            
            function getOrCreateBin(parentBin, binName) {
              if (!parentBin || !parentBin.children) return null;
              for (var i = 0; i < parentBin.children.numItems; i++) {
                var item = parentBin.children[i];
                if (item && item.type === 2 && item.name === binName) {
                  return item;
                }
              }
              try { return parentBin.createBin(binName); } catch (binErr) { return null; }
            }

            var targetPath = "${cleanPath}";
            var isCustom = ${isCustom ? "true" : "false"};
            var isSimple = ${isSimple ? "true" : "false"};
            var isCloud = ${isCloud ? "true" : "false"};
            var isPlaylist = ${isPlaylist ? "true" : "false"};
            var playlistTitle = "${playlistTitle.replace(/"/g, '\\"')}";
            var customFolderName = "${customFolderName.replace(/"/g, '\\"')}";
            var subFolderName = "${subFolderName.replace(/"/g, '\\"').replace(/\\/g, "/")}";

            var targetBin = null;

            if (isCustom) {
              // Custom Directory: create root bin outside MediaFetch named after the selected custom folder
              var rootBinName = customFolderName || (isPlaylist ? (playlistTitle || "Playlist") : (isCloud ? "Cloud Media" : ""));
              if (!rootBinName) {
                var pParts = targetPath.split('/');
                rootBinName = pParts.length > 1 ? pParts[pParts.length - 2] : "Downloads";
              }
              var customRootBin = getOrCreateBin(root, rootBinName);
              if (subFolderName) {
                var sParts = subFolderName.split('/');
                var cur = customRootBin;
                for (var s = 0; s < sParts.length; s++) {
                  if (sParts[s] && sParts[s].length > 0) {
                    cur = getOrCreateBin(cur, sParts[s]);
                  }
                }
                targetBin = cur || customRootBin;
              } else {
                targetBin = customRootBin;
              }
            } else if (isSimple || (!isCloud && !isPlaylist && (targetPath.indexOf("/MediaFetch/Video/") !== -1 || targetPath.indexOf("/MediaFetch/Audio/") !== -1 || targetPath.indexOf("/MediaFetch/Images/") !== -1 || /MediaFetch[\/\\](Video|Audio|Images?)[\/\\]/i.test(targetPath)))) {
              // Simple Project Path: Project -> MediaFetch -> Video, Audio, Images only
              var mediaFetchBin = getOrCreateBin(root, "MediaFetch");
              var parts = targetPath.split('.');
              var ext = parts.length > 1 ? parts[parts.length - 1].toLowerCase().split('?')[0] : '';
              var isAudio = (ext === 'mp3' || ext === 'wav' || ext === 'm4a' || ext === 'flac' || ext === 'aac' || ext === 'ogg' || ext === 'opus' || ext === 'aiff');
              var isImage = (ext === 'jpg' || ext === 'jpeg' || ext === 'png' || ext === 'webp' || ext === 'gif' || ext === 'bmp' || ext === 'tiff' || ext === 'tif' || ext === 'svg');
              var typeBinName = isAudio ? "Audio" : (isImage ? "Images" : "Video");
              targetBin = getOrCreateBin(mediaFetchBin, typeBinName) || mediaFetchBin;
            } else {
              // Default Project Path: inside root "MediaFetch" bin
              var mediaFetchBin = getOrCreateBin(root, "MediaFetch");

              if (isCloud) {
                // MediaFetch -> Cloud Links -> [Cloud Folder Name] -> [Subfolders]
                var cloudRootBin = getOrCreateBin(mediaFetchBin, "Cloud Links");
                var cloudFolderBin = getOrCreateBin(cloudRootBin, customFolderName || "Cloud Media");
                if (subFolderName) {
                  var sParts = subFolderName.split('/');
                  var cur = cloudFolderBin;
                  for (var s = 0; s < sParts.length; s++) {
                    if (sParts[s] && sParts[s].length > 0) {
                      cur = getOrCreateBin(cur, sParts[s]);
                    }
                  }
                  targetBin = cur || cloudFolderBin;
                } else {
                  targetBin = cloudFolderBin;
                }
              } else if (isPlaylist) {
                // MediaFetch -> Playlists -> [Playlist Name]
                var playlistRootBin = getOrCreateBin(mediaFetchBin, "Playlists");
                var pName = playlistTitle || customFolderName || "Playlist 1";
                targetBin = getOrCreateBin(playlistRootBin, pName);
              } else {
                // Single link or Search or Clipboard
                var isClipboard = ${isClipboard ? "true" : "false"} || targetPath.indexOf("Clipboard") !== -1;
                var isSearch = ${options && options.isSearch ? "true" : "false"} || 
                               targetPath.indexOf("SerachMediafetch") !== -1 || 
                               targetPath.indexOf("SearchMediafetch") !== -1 || 
                               targetPath.indexOf("/Search/") !== -1 || 
                               targetPath.indexOf("\\Search\\") !== -1 || 
                               targetPath.indexOf("MediaFetch Assets") !== -1 || 
                               targetPath.indexOf("MediaSearch Assets") !== -1;
                var categoryBinName = isClipboard ? "Clipboard" : (isSearch ? "Search" : "Link");
                var categoryBin = getOrCreateBin(mediaFetchBin, categoryBinName);

                var parts = targetPath.split('.');
                var ext = parts.length > 1 ? parts[parts.length - 1].toLowerCase().split('?')[0] : '';
                var isAudio = (ext === 'mp3' || ext === 'wav' || ext === 'm4a' || ext === 'flac' || ext === 'aac' || ext === 'ogg' || ext === 'opus' || ext === 'aiff');
                var isImage = (ext === 'jpg' || ext === 'jpeg' || ext === 'png' || ext === 'webp' || ext === 'gif' || ext === 'bmp' || ext === 'tiff' || ext === 'tif' || ext === 'svg');
                var typeBinName = isAudio ? "Audio" : (isImage ? "Images" : "Video");
                targetBin = getOrCreateBin(categoryBin, typeBinName) || categoryBin;
              }
            }

            if (!targetBin) targetBin = root;
            var mediaF = new File(targetPath);
            var nativePath = mediaF.fsName;
            var rawName = "";
            try {
              if (mediaF.name) rawName = File.decode(mediaF.name);
            } catch (_) {}
            if (!rawName && mediaF.fsName) {
              var fnParts = mediaF.fsName.replace(/\\/g, '/').split('/');
              rawName = fnParts[fnParts.length - 1];
            }
            if (!rawName) rawName = mediaF.name || "";

            var fileNameOnly = rawName.toLowerCase();
            var baseNameOnly = fileNameOnly;
            var dotIdx = fileNameOnly.lastIndexOf('.');
            if (dotIdx > 0) {
              baseNameOnly = fileNameOnly.substring(0, dotIdx);
            }

            var cleanNorm = cleanPath.toLowerCase();
            var nativeNorm = nativePath.toLowerCase();

            function cleanStrMatch(str) {
              if (!str) return "";
              var s = String(str);
              try { s = File.decode(s); } catch (_) {}
              return s.toLowerCase().replace(/\\/g, '/').replace(/[^\w\d]/g, '');
            }

            var cleanAlphaNorm = cleanStrMatch(fileNameOnly);
            var baseAlphaNorm = cleanStrMatch(baseNameOnly);

            // Check if file is already imported in targetBin to avoid duplicates (unless timeline insertion requested)
            if (!${shouldInsertTimeline ? "true" : "false"}) {
              if (targetBin && targetBin.children) {
                for (var k = 0; k < targetBin.children.numItems; k++) {
                  var ch = targetBin.children[k];
                  try {
                    if (ch && ch.getMediaPath && (ch.getMediaPath() === targetPath || ch.getMediaPath() === nativePath)) {
                      return "true";
                    }
                  } catch (_) {}
                }
              }
            }

            // Import file into target type bin (with resilient arguments and item detection)
            function matchItem(ci) {
              if (!ci || ci.type === 2) return false;
              try {
                if (ci.getMediaPath) {
                  var mp = ci.getMediaPath();
                  if (mp && mp.length > 0) {
                    var mpNorm = mp.replace(/\\/g, '/').toLowerCase();
                    var tpNorm = targetPath.replace(/\\/g, '/').toLowerCase();
                    if (mpNorm === tpNorm || mp.toLowerCase() === nativeNorm) return true;
                    var mpAlpha = cleanStrMatch(mp);
                    if (mpAlpha && cleanAlphaNorm && (mpAlpha === cleanAlphaNorm || mpAlpha === baseAlphaNorm)) return true;
                  }
                }
              } catch (_) {}
              try {
                if (ci.name) {
                  var nLow = ci.name.toLowerCase();
                  if (nLow === fileNameOnly || nLow === baseNameOnly) return true;
                  var dot = nLow.lastIndexOf('.');
                  var nBase = dot > 0 ? nLow.substring(0, dot) : nLow;
                  if (nBase === baseNameOnly) return true;
                  var nAlpha = cleanStrMatch(ci.name);
                  if (nAlpha && (nAlpha === cleanAlphaNorm || nAlpha === baseAlphaNorm)) return true;
                }
              } catch (_) {}
              return false;
            }

            function scanBin(bin) {
              if (!bin || !bin.children) return null;
              for (var i = 0; i < bin.children.numItems; i++) {
                var it = bin.children[i];
                if (!it) continue;
                if (it.type !== 2) {
                  if (matchItem(it)) return it;
                } else if (it.type === 2) {
                  var f = scanBin(it);
                  if (f) return f;
                }
              }
              return null;
            }

            var prevTargetCount = (targetBin && targetBin.children) ? targetBin.children.numItems : 0;
            var prevRootCount = (root && root.children) ? root.children.numItems : 0;
            var didImportFallback = false;
            var targetItem = null;

            var pathsToTry = [cleanPath, nativePath];
            if (targetPath !== cleanPath && targetPath !== nativePath) {
              pathsToTry.push(targetPath);
            }

            // Attempt 1: Import directly into targetBin or root with lock retries
            for (var p1 = 0; p1 < pathsToTry.length && !didImportFallback; p1++) {
              var pPath1 = pathsToTry[p1];
              for (var lockAttempt = 0; lockAttempt < 5 && !didImportFallback; lockAttempt++) {
                if (lockAttempt > 0) { try { $.sleep(300); } catch (_) {} }
                
                // Try targetBin first
                if (targetBin && targetBin !== root) {
                  try {
                    var r1 = project.importFiles([pPath1], true, targetBin, false);
                    if (r1 !== false && r1 !== null) {
                      didImportFallback = true;
                      break;
                    }
                  } catch (_) {}
                }

                // If targetBin rejected or failed, import directly into root!
                try {
                  var r2 = project.importFiles([pPath1], true);
                  if (r2 !== false && r2 !== null) {
                    didImportFallback = true;
                    break;
                  }
                } catch (_) {}

                // Flag fallback
                try {
                  var r3 = (targetBin && targetBin !== root) ?
                    project.importFiles([pPath1], 1, targetBin, 0) :
                    project.importFiles([pPath1]);
                  if (r3 !== false && r3 !== null) {
                    didImportFallback = true;
                    break;
                  }
                } catch (_) {}

                // Plain importFiles
                try {
                  var r4 = project.importFiles([pPath1]);
                  if (r4 !== false && r4 !== null) {
                    didImportFallback = true;
                    break;
                  }
                } catch (_) {}
              }
            }

            // Safe Ingestion Polling: wait max 1s (4 x 250ms) to avoid CEP evalScript watchdog timeout
            for (var poll = 0; poll < 4 && !targetItem; poll++) {
              try { $.sleep(250); } catch (_) {}
              if (targetBin && targetBin.children && targetBin.children.numItems > prevTargetCount) {
                for (var ci = targetBin.children.numItems - 1; ci >= 0; ci--) {
                  var cand = targetBin.children[ci];
                  if (cand && cand.type !== 2 && matchItem(cand)) {
                    targetItem = cand;
                    break;
                  }
                }
              }
              if (!targetItem && root && root.children && root.children.numItems > prevRootCount) {
                for (var ri0 = root.children.numItems - 1; ri0 >= 0; ri0--) {
                  var rCand0 = root.children[ri0];
                  if (rCand0 && rCand0.type !== 2 && matchItem(rCand0)) {
                    targetItem = rCand0;
                    break;
                  }
                }
              }
              if (!targetItem) {
                targetItem = scanBin(targetBin) || scanBin(root);
              }
            }

            // Move item into targetBin if it was imported to root
            if (targetItem && targetBin && targetBin !== root) {
              try {
                if (typeof targetItem.moveBin === 'function') {
                  targetItem.moveBin(targetBin);
                }
              } catch (_) {}
            }


            var success = Boolean(targetItem) || Boolean(didImportFallback);

            if (success) {
                try {
                if (targetItem && ${shouldInsertTimeline ? "true" : "false"}) {
                  var sName = targetItem.name || "MediaFetch Timeline";
                  var insertedToSeq = false;
                  var aSeq = project.activeSequence;

                  function getTargetVideoTrack(seq, playheadTime) {
                    if (!seq || !seq.videoTracks || seq.videoTracks.numTracks === 0) return null;
                    var numTracks = seq.videoTracks.numTracks;
                    for (var t = 0; t < numTracks; t++) {
                      var trk = seq.videoTracks[t];
                      if (trk && trk.clips && trk.clips.numItems === 0) return trk;
                    }
                    var pSec = (playheadTime && playheadTime.seconds !== undefined) ? playheadTime.seconds : (parseFloat(playheadTime) || 0);
                    for (var t2 = numTracks - 1; t2 >= 0; t2--) {
                      var trk2 = seq.videoTracks[t2];
                      if (!trk2 || !trk2.clips) continue;
                      var collision = false;
                      for (var c = 0; c < trk2.clips.numItems; c++) {
                        var cl = trk2.clips[c];
                        if (cl && cl.start && cl.end && cl.start.seconds <= pSec && cl.end.seconds > pSec) {
                          collision = true;
                          break;
                        }
                      }
                      if (!collision) return trk2;
                    }
                    return seq.videoTracks[numTracks - 1];
                  }

                  function getTargetAudioTrack(seq, playheadTime) {
                    if (!seq || !seq.audioTracks || seq.audioTracks.numTracks === 0) return null;
                    var numTracks = seq.audioTracks.numTracks;
                    for (var t = 0; t < numTracks; t++) {
                      var trk = seq.audioTracks[t];
                      if (trk && trk.clips && trk.clips.numItems === 0) return trk;
                    }
                    var pSec = (playheadTime && playheadTime.seconds !== undefined) ? playheadTime.seconds : (parseFloat(playheadTime) || 0);
                    for (var t2 = numTracks - 1; t2 >= 0; t2--) {
                      var trk2 = seq.audioTracks[t2];
                      if (!trk2 || !trk2.clips) continue;
                      var collision = false;
                      for (var c = 0; c < trk2.clips.numItems; c++) {
                        var cl = trk2.clips[c];
                        if (cl && cl.start && cl.end && cl.start.seconds <= pSec && cl.end.seconds > pSec) {
                          collision = true;
                          break;
                        }
                      }
                      if (!collision) return trk2;
                    }
                    return seq.audioTracks[numTracks - 1];
                  }

                  // 1. Insert directly into active sequence timeline at playhead position
                  if (aSeq) {
                    var pPos = aSeq.getPlayerPosition();
                    var pTicks = "0";
                    if (pPos) {
                      if (pPos.ticks !== undefined && pPos.ticks !== null && String(pPos.ticks).length > 0) {
                        pTicks = String(pPos.ticks);
                      } else if (pPos.seconds !== undefined) {
                        pTicks = String(Math.round(parseFloat(pPos.seconds) * 254016000000));
                      }
                    }
                    for (var insTry = 0; insTry < 4 && !insertedToSeq; insTry++) {
                      if (insTry > 0) { try { $.sleep(250); } catch (_) {} }
                      if (isAudio) {
                        var aTrk = getTargetAudioTrack(aSeq, pPos);
                        if (aTrk) {
                          if (pPos) { try { aTrk.insertClip(targetItem, pPos); insertedToSeq = true; } catch (_) {} }
                          if (!insertedToSeq) { try { aTrk.insertClip(targetItem, pTicks); insertedToSeq = true; } catch (_) {} }
                          if (!insertedToSeq && pPos && typeof aTrk.overwriteClip === "function") {
                            try { aTrk.overwriteClip(targetItem, pPos); insertedToSeq = true; } catch (_) {}
                          }
                          if (!insertedToSeq && typeof aTrk.overwriteClip === "function") {
                            try { aTrk.overwriteClip(targetItem, pTicks); insertedToSeq = true; } catch (_) {}
                          }
                          if (!insertedToSeq) { try { aTrk.insertClip(targetItem, "0"); insertedToSeq = true; } catch (_) {} }
                        }
                      } else {
                        var vTrk = getTargetVideoTrack(aSeq, pPos);
                        if (vTrk) {
                          if (pPos) { try { vTrk.insertClip(targetItem, pPos); insertedToSeq = true; } catch (_) {} }
                          if (!insertedToSeq) { try { vTrk.insertClip(targetItem, pTicks); insertedToSeq = true; } catch (_) {} }
                          if (!insertedToSeq && pPos && typeof vTrk.overwriteClip === "function") {
                            try { vTrk.overwriteClip(targetItem, pPos); insertedToSeq = true; } catch (_) {}
                          }
                          if (!insertedToSeq && typeof vTrk.overwriteClip === "function") {
                            try { vTrk.overwriteClip(targetItem, pTicks); insertedToSeq = true; } catch (_) {}
                          }
                          if (!insertedToSeq) { try { vTrk.insertClip(targetItem, "0"); insertedToSeq = true; } catch (_) {} }
                        }
                      }
                    }
                  }

                  // 2. Fallback: if no active sequence, create one
                  if (!insertedToSeq) {
                    if (typeof project.createNewSequenceFromClips === "function") {
                      var ns = project.createNewSequenceFromClips(sName, [targetItem], targetBin);
                      if (ns) {
                        insertedToSeq = true;
                        if (project.openSequence) project.openSequence(ns.sequenceID);
                      }
                    }
                  }
                  if (!insertedToSeq && typeof project.createNewSequence === "function") {
                    project.createNewSequence(sName, "");
                    var ns2 = project.activeSequence;
                    if (ns2) {
                      if (isAudio && ns2.audioTracks && ns2.audioTracks.numTracks > 0) {
                        ns2.audioTracks[0].insertClip(targetItem, "0");
                        insertedToSeq = true;
                      } else if (ns2.videoTracks && ns2.videoTracks.numTracks > 0) {
                        ns2.videoTracks[0].insertClip(targetItem, "0");
                        insertedToSeq = true;
                      }
                    }
                  }
                }
              } catch (_) {}
            }
            return success ? "true" : "false";
          } catch (err) {
            return "error: " + err;
          }
        })();
      `;
        const res = await this.evalScript(script);
        console.log("[Premiere importToProject result]:", res);
        return res === "true" || res === true;
      } catch {
        return false;
      }
    }
    getHostTheme() {
      var _a, _b;
      if (typeof window !== "undefined" && window.__adobe_cep__) {
        try {
          const skin = (_a = window.__adobe_cep__.getHostEnvironment()) == null ? void 0 : _a.appSkinInfo;
          if ((_b = skin == null ? void 0 : skin.panelBackgroundColor) == null ? void 0 : _b.color) {
            const r = skin.panelBackgroundColor.color.red;
            if (r < 50) return "darkest";
            if (r < 100) return "dark";
            if (r > 200) return "lightest";
            return "light";
          }
        } catch {
        }
      }
      return "dark";
    }
    onThemeChanged(callback) {
      this.themeListeners.push(callback);
      if (typeof window !== "undefined" && window.__adobe_cep__) {
        try {
          window.__adobe_cep__.addEventListener("com.adobe.csxs.events.ThemeChanged", () => {
            callback(this.getHostTheme());
          });
        } catch {
        }
      }
    }
    evalScript(script) {
      return new Promise((resolve) => {
        let resolved = false;
        const timer = setTimeout(() => {
          if (!resolved) {
            resolved = true;
            resolve(null);
          }
        }, 120000);
        try {
          if (typeof window !== "undefined" && window.__adobe_cep__) {
            window.__adobe_cep__.evalScript(script, (result) => {
              if (!resolved) {
                resolved = true;
                clearTimeout(timer);
                resolve(result);
              }
            });
            return;
          }
          if (typeof window !== "undefined" && window.CSInterface) {
            const cs = new window.CSInterface();
            cs.evalScript(script, (result) => {
              if (!resolved) {
                resolved = true;
                clearTimeout(timer);
                resolve(result);
              }
            });
            return;
          }
        } catch (e) {
          console.warn("evalScript error:", e);
        }
        if (!resolved) {
          resolved = true;
          clearTimeout(timer);
          resolve(null);
        }
      });
    }
  };

  // src/host/ae-adapter.ts
  var AfterEffectsHostAdapter = class {
    themeListeners = [];
    async getProjectContext() {
      if (typeof getHostAppId === "function" && getHostAppId() === "ppro") {
        return new PremiereHostAdapter().getProjectContext();
      }
      try {
        const hostInfoResult = await this.evalScript("MediaFetchHost.getHostInfo()");
        if (hostInfoResult && typeof hostInfoResult === "string" && hostInfoResult !== "EvalScript error.") {
          try {
            const parsedHost = JSON.parse(hostInfoResult);
            if (parsedHost && parsedHost.projectPath && parsedHost.projectPath.length > 0) {
              const cleanPath = parsedHost.projectPath.replace(/\\/g, "/");
              const dir = cleanPath.substring(0, cleanPath.lastIndexOf("/"));
              const name = parsedHost.projectName || cleanPath.substring(cleanPath.lastIndexOf("/") + 1) || "After Effects Project";
              return {
                application: "aftereffects",
                applicationVersion: parsedHost.appVersion || "26.0",
                projectSaved: true,
                projectName: name,
                projectPath: parsedHost.projectPath,
                projectDirectory: dir.replace(/\//g, "\\")
              };
            }
          } catch (_) {
          }
        }
        const script = `
        (function() {
          try {
            if (app && app.project) {
              if (app.project.file && app.project.file.exists) {
                return JSON.stringify({
                  saved: true,
                  path: app.project.file.fsName,
                  name: app.project.file.displayName || "After Effects Project",
                  version: app.version || "26.0"
                });
              } else {
                return JSON.stringify({
                  saved: false,
                  name: "Active AE Project (Unsaved)",
                  version: app.version || "26.0"
                });
              }
            }
          } catch (err) {
            return JSON.stringify({ saved: false, error: String(err) });
          }
          return JSON.stringify({ saved: false });
        })();
      `;
        const result = await this.evalScript(script);
        if (result && typeof result === "string" && result !== "EvalScript error.") {
          const parsed = JSON.parse(result);
          if (parsed) {
            if (parsed.saved && parsed.path) {
              const cleanPath = parsed.path.replace(/\\/g, "/");
              const dir = cleanPath.substring(0, cleanPath.lastIndexOf("/"));
              const name = cleanPath.substring(cleanPath.lastIndexOf("/") + 1) || parsed.name;
              return {
                application: "aftereffects",
                applicationVersion: parsed.version || "26.0",
                projectSaved: true,
                projectName: name,
                projectPath: parsed.path,
                projectDirectory: dir.replace(/\//g, "\\")
              };
            } else if (parsed.name) {
              return {
                application: "aftereffects",
                applicationVersion: parsed.version || "26.0",
                projectSaved: false,
                projectName: parsed.name
              };
            }
          }
        }
      } catch (e) {
        console.warn("Error reading After Effects project context:", e);
      }
      return {
        application: "aftereffects",
        applicationVersion: "26.0",
        projectSaved: false
      };
    }
    async revealInFinder(filePath) {
      try {
        if (typeof window !== "undefined" && window.require) {
          const cp = window.require("child_process");
          if (cp == null ? void 0 : cp.exec) {
            cp.exec(`explorer.exe /select,"${filePath.replace(/\//g, "\\")}"`);
            return;
          }
        }
      } catch {
      }
      try {
        const script = `
        (function() {
          var f = new File("${filePath.replace(/\\/g, "/")}");
          if (f.exists) {
            f.execute();
          }
        })();
      `;
        await this.evalScript(script);
      } catch {
      }
    }
    async openFile(filePath) {
      await this.revealInFinder(filePath);
    }
    async importToProject(filePath, options) {
      if (typeof getHostAppId === "function" && getHostAppId() === "ppro") {
        return new PremiereHostAdapter().importToProject(filePath, options);
      }
      try {
        var _a, _b;
        const cleanPath = filePath.replace(/\\/g, "/");
        const isCustom = (options == null ? void 0 : options.isCustomPath) ? true : false;
        const isSimple = Boolean((options == null ? void 0 : options.isSimplePath) || (options == null ? void 0 : options.isSimple) || ((_a = (_b = this.settings) == null ? void 0 : _b.downloads) == null ? void 0 : _a.downloadLocationMode) === "simple");
        const isCloud = (options == null ? void 0 : options.isCloud) ? true : false;
        const isPlaylist = (options == null ? void 0 : options.isPlaylist) ? true : false;
        const isBatch = (options == null ? void 0 : options.isBatch) ? true : false;
        const isSingleLink = (options == null ? void 0 : options.isSingleLink) !== void 0 ? options.isSingleLink : !isPlaylist && !isCloud && !isBatch;
        const shouldInsertTimeline = Boolean((options == null ? void 0 : options.insertToTimeline) || (options == null ? void 0 : options.addToTimeline));
        const playlistTitle = ((options == null ? void 0 : options.playlistTitle) || "").replace(/[\\/:"*?<>|]/g, " ").trim();
        const customFolderName = ((options == null ? void 0 : options.customFolderName) || "").replace(/[\\/:"*?<>|]/g, " ").trim();
        const subFolderName = ((options == null ? void 0 : options.subFolderName) || "").trim();
        const isClipboard = Boolean((options == null ? void 0 : options.isClipboard) || cleanPath.includes("Clipboard"));
        const isSearch = Boolean((options == null ? void 0 : options.isSearch) || cleanPath.includes("/Search/") || cleanPath.includes("\\Search\\") || cleanPath.includes("SerachMediafetch") || cleanPath.includes("SearchMediafetch"));
        const optsJson = JSON.stringify({
          downloadLocationMode: (options == null ? void 0 : options.downloadLocationMode) || (isCustom ? "custom" : (isSimple ? "simple" : "project")),
          isCustomPath: isCustom,
          isCustomFlat: Boolean(options == null ? void 0 : options.isCustomFlat),
          isSimplePath: isSimple,
          isSimple: isSimple,
          isCloud,
          isPlaylist,
          isBatch,
          isSingleLink,
          isSearch,
          playlistTitle,
          customFolderName,
          subFolderName,
          isClipboard,
          addToTimeline: shouldInsertTimeline,
          insertToTimeline: shouldInsertTimeline
        });

        try {
          const evalResStr = await this.evalScript(`MediaFetchHost.importMedia(${JSON.stringify(cleanPath)}, ${shouldInsertTimeline ? "true" : "false"}, ${optsJson})`);
          if (evalResStr && evalResStr !== "EvalScript error.") {
            try {
              const parsed = JSON.parse(evalResStr);
              if (parsed && parsed.success && parsed.imported !== false) {
                console.log("[MediaFetch] AE HostScript importMedia succeeded:", parsed);
                return true;
              }
            } catch (_) {
              if (evalResStr === "true" || evalResStr === true) return true;
            }
          }
        } catch (hErr) {
          console.warn("[MediaFetch] AE MediaFetchHost.importMedia attempt notice:", hErr);
        }

        const script = `
        (function() {
          try {
            if (typeof app === "undefined" || !app.project) return "no_project";
            var proj = app.project;
            
            function getOrCreateAeFolder(proj, parentFolder, folderName) {
              for (var i = 1; i <= proj.numItems; i++) {
                var it = proj.item(i);
                if (it && (it instanceof FolderItem || it.typeName === "Folder") && it.name === folderName) {
                  if (!parentFolder && (!it.parentFolder || it.parentFolder === proj.rootFolder)) {
                    return it;
                  }
                  if (parentFolder && it.parentFolder === parentFolder) {
                    return it;
                  }
                }
              }
              var newFolder = null;
              try {
                newFolder = proj.items.addFolder(folderName);
                if (parentFolder && newFolder) {
                  newFolder.parentFolder = parentFolder;
                }
              } catch (_) {}
              return newFolder;
            }

            var targetPath = "${cleanPath}";
            var isCustom = ${isCustom ? "true" : "false"};
            var isSimple = ${isSimple ? "true" : "false"};
            var isCloud = ${isCloud ? "true" : "false"};
            var isPlaylist = ${isPlaylist ? "true" : "false"};
            var playlistTitle = "${playlistTitle.replace(/"/g, '\\"')}";
            var customFolderName = "${customFolderName.replace(/"/g, '\\"')}";
            var subFolderName = "${subFolderName.replace(/"/g, '\\"').replace(/\\/g, "/")}";

            var targetFolder = null;

            if (isCustom) {
              // Custom Directory: create root bin outside MediaFetch named after the selected custom folder
              var rootBinName = customFolderName || (isPlaylist ? (playlistTitle || "Playlist") : (isCloud ? "Cloud Media" : ""));
              if (!rootBinName) {
                var pParts = targetPath.split('/');
                rootBinName = pParts.length > 1 ? pParts[pParts.length - 2] : "Downloads";
              }
              var customRootFolder = getOrCreateAeFolder(proj, null, rootBinName);
              if (subFolderName) {
                var sParts = subFolderName.split('/');
                var cur = customRootFolder;
                for (var s = 0; s < sParts.length; s++) {
                  if (sParts[s] && sParts[s].length > 0) {
                    cur = getOrCreateAeFolder(proj, cur, sParts[s]);
                  }
                }
                targetFolder = cur || customRootFolder;
              } else {
                targetFolder = customRootFolder;
              }
            } else if (isSimple || (!isCloud && !isPlaylist && (targetPath.indexOf("/MediaFetch/Video/") !== -1 || targetPath.indexOf("/MediaFetch/Audio/") !== -1 || targetPath.indexOf("/MediaFetch/Images/") !== -1 || /MediaFetch[\/\\](Video|Audio|Images?)[\/\\]/i.test(targetPath)))) {
              // Simple Project Path: Project -> MediaFetch -> Video, Audio, Images only
              var mediaFetchFolder = getOrCreateAeFolder(proj, null, "MediaFetch");
              var parts = targetPath.split('.');
              var ext = parts.length > 1 ? parts[parts.length - 1].toLowerCase().split('?')[0] : '';
              var isAudio = (ext === 'mp3' || ext === 'wav' || ext === 'm4a' || ext === 'flac' || ext === 'aac' || ext === 'ogg' || ext === 'opus' || ext === 'aiff');
              var isImage = (ext === 'jpg' || ext === 'jpeg' || ext === 'png' || ext === 'webp' || ext === 'gif' || ext === 'bmp' || ext === 'tiff' || ext === 'tif' || ext === 'svg');
              var typeFolderName = isAudio ? "Audio" : (isImage ? "Images" : "Video");
              targetFolder = getOrCreateAeFolder(proj, mediaFetchFolder, typeFolderName) || mediaFetchFolder;
            } else {
              // Default Project Path: inside root "MediaFetch" bin
              var mediaFetchFolder = getOrCreateAeFolder(proj, null, "MediaFetch");

              if (isCloud) {
                // MediaFetch -> Cloud Links -> [Cloud Folder Name] -> [Subfolders]
                var cloudRoot = getOrCreateAeFolder(proj, mediaFetchFolder, "Cloud Links");
                var cloudFolder = getOrCreateAeFolder(proj, cloudRoot, customFolderName || "Cloud Media");
                if (subFolderName) {
                  var sParts = subFolderName.split('/');
                  var cur = cloudFolder;
                  for (var s = 0; s < sParts.length; s++) {
                    if (sParts[s] && sParts[s].length > 0) {
                      cur = getOrCreateAeFolder(proj, cur, sParts[s]);
                    }
                  }
                  targetFolder = cur || cloudFolder;
                } else {
                  targetFolder = cloudFolder;
                }
              } else if (isPlaylist) {
                // MediaFetch -> Playlists -> [Playlist Name]
                var playlistRoot = getOrCreateAeFolder(proj, mediaFetchFolder, "Playlists");
                var pName = playlistTitle || customFolderName || "Playlist 1";
                targetFolder = getOrCreateAeFolder(proj, playlistRoot, pName);
              } else {
                // Single link or Search or Clipboard
                var isClipboard = ${isClipboard ? "true" : "false"} || targetPath.indexOf("Clipboard") !== -1;
                var isSearch = targetPath.indexOf("SerachMediafetch") !== -1 || 
                               targetPath.indexOf("MediaFetch Assets") !== -1 || 
                               targetPath.indexOf("MediaSearch Assets") !== -1;
                var categoryFolderName = isClipboard ? "Clipboard" : (isSearch ? "SerachMediafetch" : "LinkMediaFetch");
                var categoryFolder = getOrCreateAeFolder(proj, mediaFetchFolder, categoryFolderName);

                var parts = targetPath.split('.');
                var ext = parts.length > 1 ? parts[parts.length - 1].toLowerCase().split('?')[0] : '';
                var isAudio = (ext === 'mp3' || ext === 'wav' || ext === 'm4a' || ext === 'flac' || ext === 'aac' || ext === 'ogg' || ext === 'opus' || ext === 'aiff');
                var isImage = (ext === 'jpg' || ext === 'jpeg' || ext === 'png' || ext === 'webp' || ext === 'gif' || ext === 'bmp' || ext === 'tiff' || ext === 'tif' || ext === 'svg');
                var typeFolderName = isAudio ? "Audio" : (isImage ? "Images" : "Video");
                targetFolder = getOrCreateAeFolder(proj, categoryFolder, typeFolderName) || categoryFolder;
              }
            }

            var mediaFile = new File(targetPath);
            if (!mediaFile.exists) {
              mediaFile = new File(targetPath.replace(/\//g, '\\'));
            }
            if (!mediaFile.exists) {
              return "file_not_found: " + targetPath;
            }

            // Check if file is ALREADY imported in project (only return early if not inserting to timeline)
            if (!${shouldInsertTimeline ? "true" : "false"}) {
              for (var j = 1; j <= proj.numItems; j++) {
                var existingItem = proj.item(j);
                if (existingItem && existingItem.file && existingItem.file.fsName === mediaFile.fsName) {
                  return "true";
                }
              }
            }

            // Import media into target folder
            var importedItem = null;
            try {
              var io = new ImportOptions();
              io.file = mediaFile;
              importedItem = proj.importFile(io);
            } catch (_) {
              try {
                for (var j2 = 1; j2 <= proj.numItems; j2++) {
                  var ex = proj.item(j2);
                  if (ex && ex.file && ex.file.fsName === mediaFile.fsName) {
                    importedItem = ex;
                    break;
                  }
                }
              } catch (_) {}
            }
            if (importedItem) {
              importedItem.parentFolder = targetFolder || proj.rootFolder;
              if (${shouldInsertTimeline ? "true" : "false"}) {
                try {
                  var comp = proj.activeItem;
                  if (!comp || !(comp instanceof CompItem)) {
                    for (var cIdx = 1; cIdx <= proj.numItems; cIdx++) {
                      if (proj.item(cIdx) instanceof CompItem) {
                        comp = proj.item(cIdx);
                        break;
                      }
                    }
                  }
                  if (!comp || !(comp instanceof CompItem)) {
                    var w = (importedItem.width && importedItem.width > 0) ? importedItem.width : 1920;
                    var h = (importedItem.height && importedItem.height > 0) ? importedItem.height : 1080;
                    var dur = (importedItem.duration && importedItem.duration > 0) ? importedItem.duration : 30;
                    var fps = (importedItem.frameRate && importedItem.frameRate > 0) ? importedItem.frameRate : 30;
                    var rawName = importedItem.name || "MediaFetch Comp";
                    var dotIdx = rawName.lastIndexOf(".");
                    var cName = (dotIdx > 0) ? rawName.substring(0, dotIdx) : rawName;
                    comp = proj.items.addComposition(cName, w, h, 1.0, dur, fps);
                  }
                  if (comp && comp instanceof CompItem) {
                    var playheadTime = (comp.time !== undefined && comp.time !== null) ? comp.time : 0;
                    var layer = comp.layers.add(importedItem);
                    if (layer) {
                      layer.startTime = playheadTime;
                      layer.moveToBeginning();
                    }
                    if (typeof comp.openInViewer === "function") comp.openInViewer();
                  }
                } catch (_) {}
              }
              return "true";
            }
            return "cannot_import";
          } catch (err) {
            return "error: " + err;
          }
        })();
      `;
        const res = await this.evalScript(script);
        console.log("[AfterEffects importToProject result]:", res);
        return res === "true" || res === true;
      } catch {
        return false;
      }
    }
    getHostTheme() {
      var _a, _b;
      if (typeof window !== "undefined" && window.__adobe_cep__) {
        try {
          const skin = (_a = window.__adobe_cep__.getHostEnvironment()) == null ? void 0 : _a.appSkinInfo;
          if ((_b = skin == null ? void 0 : skin.panelBackgroundColor) == null ? void 0 : _b.color) {
            const r = skin.panelBackgroundColor.color.red;
            if (r < 50) return "darkest";
            if (r < 100) return "dark";
            if (r > 200) return "lightest";
            return "light";
          }
        } catch {
        }
      }
      return "dark";
    }
    onThemeChanged(callback) {
      this.themeListeners.push(callback);
      if (typeof window !== "undefined" && window.__adobe_cep__) {
        try {
          window.__adobe_cep__.addEventListener("com.adobe.csxs.events.ThemeChanged", () => {
            callback(this.getHostTheme());
          });
        } catch {
        }
      }
    }
    evalScript(script) {
      return new Promise((resolve) => {
        let resolved = false;
        const timer = setTimeout(() => {
          if (!resolved) {
            resolved = true;
            resolve(null);
          }
        }, 120000);
        try {
          if (typeof window !== "undefined" && window.__adobe_cep__) {
            window.__adobe_cep__.evalScript(script, (result) => {
              if (!resolved) {
                resolved = true;
                clearTimeout(timer);
                resolve(result);
              }
            });
            return;
          }
          if (typeof window !== "undefined" && window.CSInterface) {
            const cs = new window.CSInterface();
            cs.evalScript(script, (result) => {
              if (!resolved) {
                resolved = true;
                clearTimeout(timer);
                resolve(result);
              }
            });
            return;
          }
        } catch (e) {
          console.warn("evalScript error:", e);
        }
        if (!resolved) {
          resolved = true;
          clearTimeout(timer);
          resolve(null);
        }
      });
    }
  };

  // src/host/host-detector.ts
  var StandaloneHostAdapter = class {
    async getProjectContext() {
      return {
        application: "standalone",
        applicationVersion: "1.0.0",
        projectSaved: false
      };
    }
    async revealInFinder(filePath) {
      console.log("Reveal in finder:", filePath);
    }
    async openFile(filePath) {
      console.log("Open file:", filePath);
    }
    async importToProject(filePath) {
      console.log("Import to project (standalone):", filePath);
      return false;
    }
    getHostTheme() {
      return "dark";
    }
    onThemeChanged(callback) {
    }
  };
  function getHostAppId() {
    if (typeof window !== "undefined") {
      if (window.__adobe_cep__) {
        try {
          const raw = window.__adobe_cep__.getHostEnvironment();
          const obj = typeof raw === "string" ? JSON.parse(raw) : raw;
          const aid = ((obj && obj.appId) || "").toLowerCase();
          if (aid.includes("pr")) return "ppro";
          if (aid.includes("ae") || aid.includes("fx")) return "aeft";
        } catch (_) {}
      }
      if (window.CSInterface) {
        try {
          const cs = new window.CSInterface();
          const env = cs.getHostEnvironment();
          const aid = ((env && env.appId) || "").toLowerCase();
          if (aid.includes("pr")) return "ppro";
          if (aid.includes("ae") || aid.includes("fx")) return "aeft";
        } catch (_) {}
      }
      if (window.__MF_HOST_ID__ && (window.__MF_HOST_ID__ === "ppro" || window.__MF_HOST_ID__ === "aeft")) {
        return window.__MF_HOST_ID__;
      }
      if (typeof hostAdapter !== "undefined" && hostAdapter && hostAdapter.hostId) {
        return hostAdapter.hostId;
      }
    }
    return "";
  }
  function createHostAdapter() {
    let hostId = "";
    if (typeof window !== "undefined") {
      if (window.__adobe_cep__) {
        try {
          const rawEnv = window.__adobe_cep__.getHostEnvironment();
          if (typeof rawEnv === "string") {
            try {
              const parsed = JSON.parse(rawEnv);
              hostId = (parsed.appId || "").toLowerCase();
            } catch {}
          } else if (rawEnv && typeof rawEnv === "object") {
            hostId = (rawEnv.appId || "").toLowerCase();
          }
          console.log("[HostDetector] Detected CEP host ID:", hostId);
        } catch (e) {
          console.warn("[HostDetector] Error reading CEP environment:", e);
        }
      }
      if (!hostId && window.CSInterface) {
        try {
          const cs = new window.CSInterface();
          const env = cs.getHostEnvironment();
          hostId = ((env && env.appId) || "").toLowerCase();
        } catch (_) {}
      }
      if (hostId.includes("pr") || hostId.includes("premiere")) {
        const adapter = new PremiereHostAdapter();
        adapter.hostId = "ppro";
        window.__MF_HOST_ID__ = "ppro";
        return adapter;
      } else if (hostId.includes("ae") || hostId.includes("fx") || hostId.includes("aftereffects")) {
        const adapter = new AfterEffectsHostAdapter();
        adapter.hostId = "aeft";
        window.__MF_HOST_ID__ = "aeft";
        return adapter;
      }
      if (window.require) {
        try {
          const uxp = window.require("uxp");
          const host = uxp == null ? void 0 : uxp.host;
          const hostName = ((host == null ? void 0 : host.name) || "").toLowerCase();
          if (hostName.includes("premiere") || hostName.includes("pr")) {
            const adapter = new PremiereHostAdapter();
            adapter.hostId = "ppro";
            window.__MF_HOST_ID__ = "ppro";
            return adapter;
          } else if (hostName.includes("aftereffects") || hostName.includes("ae") || hostName.includes("fx")) {
            const adapter = new AfterEffectsHostAdapter();
            adapter.hostId = "aeft";
            window.__MF_HOST_ID__ = "aeft";
            return adapter;
          }
        } catch {}
      }
    }
    const title = (typeof document !== "undefined" && document.title ? document.title : "").toLowerCase();
    if (title.includes("ae") || title.includes("after effects")) {
      const fallbackAe = new AfterEffectsHostAdapter();
      fallbackAe.hostId = "aeft";
      window.__MF_HOST_ID__ = "aeft";
      return fallbackAe;
    }
    const fallbackPr = new PremiereHostAdapter();
    fallbackPr.hostId = "ppro";
    window.__MF_HOST_ID__ = "ppro";
    return fallbackPr;
  }
  var hostAdapter = createHostAdapter();

  // src/ui/app.ts
  var ICONS = {
    PAUSE: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="6" y="4" width="4" height="16"></rect><rect x="14" y="4" width="4" height="16"></rect></svg>',
    PLAY: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>',
    CLOSE: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>',
    RETRY: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M23 4v6h-6"></path><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path></svg>',
    FOLDER: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>',
    SEARCH: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>',
    CHECK: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>',
    PROJECT: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="12" y1="18" x2="12" y2="12"></line><line x1="9" y1="15" x2="15" y2="15"></line></svg>'
  };
  var MediaFetchApp = class {
    projectContext = {
      application: "standalone",
      applicationVersion: "1.0.0",
      projectSaved: false
    };
    currentMode = "video-audio";
    currentMetadata = null;
    currentPlaylist = null;
    queue = [];
    settings = null;
    history = [];
    isAnalyzing = false;
    analysisTimeout;
    pendingDownloadParams = null;
    toastTimeout = null;
    processedImportItemIds = /* @__PURE__ */ new Set();
    importSweepInterval = null;
    playlistCustomTargetDir = "";
    constructor() {
      if (typeof window !== "undefined") {
        window.mediaFetchApp = this;
      }
      this.init();
    }
    async init() {
      this.bindDomEvents();
      this.setupTheme();
      this.setupServiceClient();
      this.updateDropdownsForMode(this.currentMode);
      this.updateProjectStatusUI();
      this.autoStartServiceIfInCep();
      serviceClient.connect();
      if (typeof serviceClient.startSupervisor === "function") {
        serviceClient.startSupervisor();
      }
      setTimeout(() => {
        const urlInput = document.getElementById("url-input");
        urlInput == null ? void 0 : urlInput.focus();
      }, 100);
      this.refreshProjectContext();
      window.addEventListener("focus", () => {
        this.refreshProjectContext();
        this.checkPendingImports();
      });
      document.addEventListener("visibilitychange", () => {
        if (document.visibilityState === "visible") {
          this.refreshProjectContext();
          this.checkPendingImports();
        }
      });
      setInterval(() => {
        if (document.visibilityState === "visible") {
          this.checkPendingImports();
        }
      }, 5000);
    }
    async refreshProjectContext() {
      try {
        this.projectContext = await hostAdapter.getProjectContext();
        this.updateProjectStatusUI();
      } catch (e) {
        console.warn("Failed to resolve host project context:", e);
        this.updateProjectStatusUI();
      }
    }
    autoStartServiceIfInCep() {
      var _a, _b, _c, _d;
      try {
        if (typeof window === "undefined") return;
        const nodeRequire = window.require || ((_a = window.cep_node) == null ? void 0 : _a.require) || (typeof __require !== "undefined" ? __require : null);
        let proc = null;
        try {
          proc = typeof process !== "undefined" ? process : nodeRequire ? nodeRequire("process") : null;
        } catch {
        }
        const appData = ((_b = proc == null ? void 0 : proc.env) == null ? void 0 : _b.APPDATA) || "";
        const localAppData = ((_c = proc == null ? void 0 : proc.env) == null ? void 0 : _c.LOCALAPPDATA) || "";
        let extDir = "";
        try {
          if ((_d = window.__adobe_cep__) == null ? void 0 : _d.getSystemPath) {
            extDir = window.__adobe_cep__.getSystemPath("extension");
          } else if (window.CSInterface) {
            extDir = new window.CSInterface().getSystemPath("extension");
          }
        } catch {
        }
        if (!extDir && typeof window.location !== "undefined" && window.location.pathname) {
          let p = window.location.pathname.replace(/^[\\\/]([A-Za-z]:)/, "$1");
          extDir = p.substring(0, Math.max(p.lastIndexOf("/"), p.lastIndexOf("\\")));
        }
        const candidatePaths = [
          extDir ? `${extDir}/service/server.bundle.js`.replace(/\//g, "\\") : "",
          extDir ? `${extDir}/service/server.js`.replace(/\//g, "\\") : "",
          appData ? `${appData}\\Adobe\\CEP\\extensions\\com.mediafetch.adobe.pro\\service\\server.bundle.js` : "",
          appData ? `${appData}\\Adobe\\CEP\\extensions\\com.mediafetch.adobe.pro\\service\\server.js` : "",
          appData ? `${appData}\\Adobe\\CEP\\extensions\\com.mediafetch.adobe\\service\\server.bundle.js` : "",
          appData ? `${appData}\\Adobe\\CEP\\extensions\\com.mediafetch.adobe\\service\\server.js` : "",
          localAppData ? `${localAppData}\\MediaFetchPro\\server.bundle.js` : "",
          localAppData ? `${localAppData}\\MediaFetchPro\\server.js` : ""
        ].filter(Boolean);
        const nodeExeCandidates = [
          "C:\\Program Files\\nodejs\\node.exe",
          "C:\\Program Files (x86)\\nodejs\\node.exe",
          "/opt/homebrew/bin/node",
          "/usr/local/bin/node",
          "/usr/bin/node",
          "node"
        ];
        const logDir = localAppData ? `${localAppData}\\MediaFetch\\logs` : "";
        let outFd = "ignore";
        if (nodeRequire && logDir) {
          try {
            const fs = nodeRequire("fs");
            fs.mkdirSync(logDir, { recursive: true });
            outFd = fs.openSync(`${logDir}\\service.log`, "a");
          } catch (_) {}
        }
        const startServiceScript = (scriptPath) => {
          if (nodeRequire) {
            try {
              const cp = nodeRequire("child_process");
              for (const nodeExe of nodeExeCandidates) {
                try {
                  const child = cp.spawn(nodeExe, ["--expose-gc", "--max-old-space-size=512", scriptPath], {
                    detached: true,
                    stdio: ["ignore", outFd, outFd],
                    windowsHide: true,
                    env: { ...proc == null ? void 0 : proc.env, PORT: "48924" }
                  });
                  child.on("error", (err) => {
                    console.warn(`[MediaFetch] Daemon spawn error on ${nodeExe}:`, err);
                  });
                  child.unref();
                  console.log(`[MediaFetch Pro] Daemon spawned with ${nodeExe}: ${scriptPath}`);
                  setTimeout(() => serviceClient.connect(), 800);
                  return true;
                } catch {
                }
              }
            } catch {
            }
          }
          if ((_b2 = (_a2 = window.cep) == null ? void 0 : _a2.process) == null ? void 0 : _b2.createProcess) {
            try {
              for (const nodeExe of nodeExeCandidates) {
                const res = window.cep.process.createProcess(nodeExe, scriptPath);
                if (res && res.err === 0) {
                  console.log(`[MediaFetch Pro] CEP createProcess spawned daemon: ${nodeExe}`);
                  setTimeout(() => serviceClient.connect(), 800);
                  return true;
                }
              }
            } catch {
            }
          }
          return false;
        };
        if (nodeRequire) {
          try {
            const http = nodeRequire("http");
            const req = http.get("http://127.0.0.1:48924/health", (res) => {
              if (res.statusCode === 200) {
                console.log("[MediaFetch Pro] Service already running on port 48924.");
                serviceClient.connect();
              }
            });
            req.on("error", () => {
              for (const scriptPath of candidatePaths) {
                if (startServiceScript(scriptPath)) break;
              }
            });
            return;
          } catch {
          }
        }
        for (const scriptPath of candidatePaths) {
          if (startServiceScript(scriptPath)) break;
        }
      } catch (e) {
        console.warn("[MediaFetch] autoStartService error:", e);
      }
    }
    setupTheme() {
      const applyTheme = (themeName) => {
        document.body.classList.remove("theme-light", "theme-darkest");
        if (themeName === "light" || themeName === "lightest") {
          document.body.classList.add("theme-light");
        } else if (themeName === "darkest") {
          document.body.classList.add("theme-darkest");
        }
      };
      this.applyTheme = applyTheme;
      window.__applyTheme = applyTheme;
      hostAdapter.onThemeChanged((theme) => {
        var _a;
        if (((_a = this.settings) == null ? void 0 : _a.general.theme) === "host") {
          applyTheme(theme);
        }
      });
      const initialHostTheme = hostAdapter.getHostTheme();
      applyTheme(initialHostTheme);
    }
    showHeaderToast(message, durationMs = 6e3, onRetry = null) {
      const toast = document.getElementById("header-alert-toast");
      const textEl = document.getElementById("header-alert-text");
      if (!toast || !textEl) return;
      if (this.toastTimeout) {
        clearTimeout(this.toastTimeout);
        this.toastTimeout = null;
      }
      textEl.textContent = message;
      let retryBtn = document.getElementById("header-alert-retry-btn");
      if (onRetry && typeof onRetry === "function") {
        if (!retryBtn) {
          retryBtn = document.createElement("button");
          retryBtn.id = "header-alert-retry-btn";
          retryBtn.textContent = "Retry";
          retryBtn.style.cssText = "margin-left: 10px; padding: 2px 8px; font-size: 11px; background: rgba(255,255,255,0.2); border: 1px solid rgba(255,255,255,0.4); border-radius: 4px; color: #fff; cursor: pointer;";
          toast.appendChild(retryBtn);
        }
        retryBtn.style.display = "inline-block";
        retryBtn.onclick = (e) => {
          e.stopPropagation();
          toast.style.display = "none";
          try { onRetry(); } catch (_) {}
        };
      } else if (retryBtn) {
        retryBtn.style.display = "none";
      }
      toast.style.display = "flex";
      this.toastTimeout = setTimeout(() => {
        toast.style.display = "none";
        this.toastTimeout = null;
      }, durationMs);
    }
    dismissHeaderToast() {
      const toast = document.getElementById("header-alert-toast");
      if (toast) toast.style.display = "none";
      if (this.toastTimeout) {
        clearTimeout(this.toastTimeout);
        this.toastTimeout = null;
      }
    }
    dismissHeaderToastIf(keyword) {
      const textEl = document.getElementById("header-alert-text");
      if (textEl && textEl.textContent && textEl.textContent.includes(keyword)) {
        this.dismissHeaderToast();
      }
    }
    pendingFolderCallback = null;
    selectFolderModern(callback) {
      var _a;
      try {
        const cepFs = (_a = window.cep) == null ? void 0 : _a.fs;
        if (cepFs && typeof cepFs.showOpenDialogEx === "function") {
          const res = cepFs.showOpenDialogEx(false, true, "Select MediaFetch Destination Folder", "", []);
          if (res && res.data && res.data.length > 0 && res.data[0]) {
            callback(res.data[0]);
            return;
          } else if (res && Array.isArray(res.data)) {
            return;
          }
        }
        if (cepFs && typeof cepFs.showOpenDialog === "function") {
          const res = cepFs.showOpenDialog(false, true, "Select MediaFetch Destination Folder", "", []);
          if (res && res.data && res.data.length > 0 && res.data[0]) {
            callback(res.data[0]);
            return;
          } else if (res && Array.isArray(res.data)) {
            return;
          }
        }
      } catch (e) {
        console.warn("[MediaFetch Pro] CEP showOpenDialog failed:", e);
      }
      try {
        if (this.csInterface && typeof this.csInterface.evalScript === "function") {
          this.csInterface.evalScript("selectDownloadFolder()", (res) => {
            const cleaned = (res || "").trim();
            if (cleaned && cleaned !== "undefined" && cleaned !== "null" && cleaned !== "false") {
              callback(cleaned);
            }
          });
          return;
        }
      } catch (e) {
        console.warn("[MediaFetch Pro] ExtendScript selectDownloadFolder failed:", e);
      }
      this.pendingFolderCallback = callback;
      serviceClient.openFolderDialog();
    }
    updateProjectStatusUI() {
      const label = document.getElementById("project-status-label");
      const targetDirDisplay = document.getElementById("target-dir-display");
      if (!label) return;
      const pName = this.projectContext.projectName;
      const isSaved = this.projectContext.projectSaved && this.projectContext.projectDirectory;
      const appName = this.projectContext.application;
      if (pName && pName !== "standalone" && pName !== "Unknown") {
        label.textContent = `Project: ${pName}${isSaved ? "" : " (Active)"}`;
        label.title = isSaved ? this.projectContext.projectDirectory : "Active Project - Downloads route to default MediaFetch folder";
        if (targetDirDisplay) {
          targetDirDisplay.textContent = isSaved ? `Target: ${this.projectContext.projectDirectory}\\MediaFetch\\` : "Target: Downloads\\MediaFetch\\";
        }
      } else if (isSaved) {
        label.textContent = `Project: ${this.projectContext.projectName || "Active"}`;
        label.title = this.projectContext.projectDirectory;
        if (targetDirDisplay) {
          targetDirDisplay.textContent = `Target: ${this.projectContext.projectDirectory}\\MediaFetch\\`;
        }
      } else {
        const hostLabel = appName && appName !== "standalone" ? `${appName === "premierepro" ? "Premiere Pro" : "After Effects"} (Active)` : "Active / Default Bin";
        label.textContent = `Project: ${hostLabel}`;
        label.title = "Downloads saved to Downloads\\MediaFetch and auto-imported into host project";
        if (targetDirDisplay) {
          targetDirDisplay.textContent = "Target: Downloads\\MediaFetch\\";
        }
      }
    }
    setVideoModesLocked(isLocked, reasonText) {
      const videoAudioBtn = document.getElementById("mode-video-audio");
      const videoOnlyBtn = document.getElementById("mode-video-only");
      [videoAudioBtn, videoOnlyBtn].forEach((btn) => {
        if (!btn) return;
        if (isLocked) {
          btn.setAttribute("disabled", "true");
          btn.style.opacity = "0.35";
          btn.style.pointerEvents = "none";
          btn.title = reasonText || "Video options are disabled for audio-only platforms";
        } else {
          btn.removeAttribute("disabled");
          btn.style.opacity = "1";
          btn.style.pointerEvents = "auto";
          btn.title = "";
        }
      });
      if (isLocked && (this.currentMode === "video-audio" || this.currentMode === "video-only")) {
        this.updateDropdownsForMode("audio-only");
      }
    }
    checkUrlForPlatform(url) {
      const isSpotify = /spotify\.(?:com|link)/i.test(url);
      const isAudioPlatform = isSpotify || /(?:music\.apple\.com|itunes\.apple\.com|gaana\.com|jiosaavn\.com|wynk\.in|soundcloud\.com|deezer\.com|bandcamp\.com|tidal\.com|audiomack\.com|qobuz\.com|music\.amazon|mixcloud\.com|iheart\.com)/i.test(url);
      const isTikTokAudio = /tiktok\.com\/music\//i.test(url);
      const isExplicitAudio = isAudioPlatform || isTikTokAudio;
      if (isExplicitAudio) {
        this.setVideoModesLocked(true, "Video options are disabled for audio-only platforms");
      } else {
        this.setVideoModesLocked(false);
        const isKnownVideoPlatform = /tiktok\.com|youtube\.com|youtu\.be|instagram\.com|vimeo\.com|twitter\.com|x\.com|facebook\.com|fb\.watch|threads\.net/i.test(url);
        if (isKnownVideoPlatform && (this.currentMode === "audio-only" || this.currentMode === "image")) {
          this.updateDropdownsForMode("video-audio");
        }
      }
    }
    updateDropdownsForMode(mode) {
      this.currentMode = mode;
      document.querySelectorAll(".mode-icon-group .segment-icon-btn, .segment-btn[data-mode]").forEach((btn) => {
        const bMode = btn.getAttribute("data-mode");
        if (bMode === mode) {
          btn.classList.add("active");
        } else {
          btn.classList.remove("active");
        }
      });
      const badge = document.getElementById("current-mode-badge");
      if (badge) {
        if (mode === "audio-only") {
          badge.textContent = "Audio Only";
          badge.style.background = "#8e44ad";
        } else if (mode === "video-only") {
          badge.textContent = "Video Only";
          badge.style.background = "#d35400";
        } else if (mode === "image") {
          badge.textContent = "Photo / Cover";
          badge.style.background = "#27ae60";
        } else {
          badge.textContent = "Video + Audio";
          badge.style.background = "#1473e6";
        }
      }
      const profileSelect = document.getElementById("profile-select");
      const formatSelect = document.getElementById("format-select");
      const formatGroup = document.getElementById("format-select-group");
      const formatLabel = document.getElementById("format-select-label");
      if (!profileSelect || !formatSelect) return;
      profileSelect.innerHTML = "";
      formatSelect.innerHTML = "";
      if (mode === "image") {
        if (formatSelect) {
          formatSelect.disabled = false;
          formatSelect.title = "";
        }
        if (formatGroup) {
          formatGroup.style.opacity = "1";
          formatGroup.style.pointerEvents = "auto";
        }
        if (formatLabel) formatLabel.textContent = "Format / Container";
        profileSelect.appendChild(new Option("Original Thumbnail (Max Resolution / Ultra HD)", "image-orig", true, true));
        profileSelect.appendChild(new Option("Full HD Cover Art (1080p)", "image-1080p"));
        profileSelect.appendChild(new Option("WebP Cover Art (Compact)", "image-webp"));
        profileSelect.appendChild(new Option("Lossless PNG Cover Art", "image-png"));
        formatSelect.appendChild(new Option("JPG Image", "jpg", true, true));
        formatSelect.appendChild(new Option("PNG Image", "png"));
        formatSelect.appendChild(new Option("WEBP Image", "webp"));
      } else if (mode === "audio-only") {
        if (formatSelect) {
          formatSelect.disabled = true;
          formatSelect.title = "Format is automatically determined by your selected Quality Profile.";
        }
        if (formatGroup) {
          formatGroup.style.opacity = "0.45";
          formatGroup.style.pointerEvents = "none";
        }
        if (formatLabel) formatLabel.textContent = "Format / Container (Auto-locked by Quality Profile)";
        profileSelect.appendChild(new Option("Best Audio Quality (Auto)", "best-audio", true, true));
        profileSelect.appendChild(new Option("MP3 Studio Master (320 kbps High Quality)", "audio-mp3-320"));
        profileSelect.appendChild(new Option("MP3 Standard (192 kbps)", "audio-mp3-192"));
        profileSelect.appendChild(new Option("MP3 Data Saver / Low Compressed (128 kbps)", "audio-mp3-128"));
        profileSelect.appendChild(new Option("M4A (AAC 256 kbps)", "audio-m4a"));
        profileSelect.appendChild(new Option("WAV (Uncompressed Studio Audio 1411 kbps)", "audio-wav"));
        profileSelect.appendChild(new Option("FLAC (Lossless Audio)", "audio-flac"));
        profileSelect.appendChild(new Option("Audio Only (Native Stream)", "audio-only"));
        formatSelect.appendChild(new Option("MP3 (Auto from Profile)", "mp3", true, true));
        formatSelect.appendChild(new Option("M4A (Auto from Profile)", "m4a"));
        formatSelect.appendChild(new Option("WAV (Auto from Profile)", "wav"));
        formatSelect.appendChild(new Option("FLAC (Auto from Profile)", "flac"));
        profileSelect.onchange = () => {
          const pVal = profileSelect.value;
          if (pVal === "audio-wav") formatSelect.value = "wav";
          else if (pVal === "audio-flac") formatSelect.value = "flac";
          else if (pVal === "audio-m4a") formatSelect.value = "m4a";
          else formatSelect.value = "mp3";
        };
      } else if (mode === "video-only") {
        if (formatSelect) {
          formatSelect.disabled = false;
          formatSelect.title = "";
        }
        if (formatGroup) {
          formatGroup.style.opacity = "1";
          formatGroup.style.pointerEvents = "auto";
        }
        if (formatLabel) formatLabel.textContent = "Format / Container";
        profileSelect.appendChild(new Option("1080p Full HD (1080p) \u2022 Recommended (Fast & Balanced)", "video-1080p", true, true));
        profileSelect.appendChild(new Option("Best Video Only (Auto-Optimized)", "video-only"));
        profileSelect.appendChild(new Option("4K Ultra HD (2160p) \u2022 Studio Master (Slower \u2022 Largest File)", "video-4k"));
        profileSelect.appendChild(new Option("1440p Quad HD (2K) \u2022 High Quality (Moderate Speed)", "video-1440p"));
        profileSelect.appendChild(new Option("720p HD (720p) \u2022 Very Fast (Light File)", "video-720p"));
        profileSelect.appendChild(new Option("480p SD \u2022 Super Fast / Instant (Small File)", "video-480p"));
        profileSelect.appendChild(new Option("360p SD \u2022 Ultra Compact (Tiny File)", "video-360p"));
        formatSelect.appendChild(new Option("MP4 (H.264 / AAC - Recommended for Adobe)", "mp4", true, true));
        formatSelect.appendChild(new Option("MOV (QuickTime)", "mov"));
        formatSelect.appendChild(new Option("MKV (Matroska)", "mkv"));
        formatSelect.appendChild(new Option("WEBM (VP9 / Opus)", "webm"));
      } else {
        if (formatSelect) {
          formatSelect.disabled = false;
          formatSelect.title = "";
        }
        if (formatGroup) {
          formatGroup.style.opacity = "1";
          formatGroup.style.pointerEvents = "auto";
        }
        if (formatLabel) formatLabel.textContent = "Format / Container";
        profileSelect.appendChild(new Option("1080p Full HD (1080p) \u2022 Recommended (Fast & Balanced)", "video-1080p", true, true));
        profileSelect.appendChild(new Option("Best Available Quality (Auto-Optimized)", "best-available"));
        profileSelect.appendChild(new Option("4K Ultra HD (2160p) \u2022 Studio Master (Slower \u2022 Largest File)", "video-4k"));
        profileSelect.appendChild(new Option("1440p Quad HD (2K) \u2022 High Quality (Moderate Speed)", "video-1440p"));
        profileSelect.appendChild(new Option("720p HD (720p) \u2022 Very Fast (Light File)", "video-720p"));
        profileSelect.appendChild(new Option("480p SD \u2022 Super Fast / Instant (Small File)", "video-480p"));
        profileSelect.appendChild(new Option("360p SD \u2022 Ultra Compact (Tiny File)", "video-360p"));
        formatSelect.appendChild(new Option("MP4 (H.264 / AAC - Recommended for Adobe)", "mp4", true, true));
        formatSelect.appendChild(new Option("MOV (Apple ProRes / QuickTime)", "mov"));
        formatSelect.appendChild(new Option("MKV (Matroska)", "mkv"));
        formatSelect.appendChild(new Option("WEBM (VP9 / Opus)", "webm"));
      }
    }
    setupServiceClient() {
      serviceClient.onStatusChanged((online) => {
        const dot = document.getElementById("connection-dot");
        if (dot) {
          dot.className = `connection-dot ${online ? "online" : "offline"}`;
          dot.title = online ? "MediaFetch Pro service connected (Port 48924)" : "Service offline (Click Diagnostics to check)";
        }
        if (online && Array.isArray(this.queue)) {
          for (const it of this.queue) {
            if (it && it.status === "completed" && it.importStatus === "pending" && (it.outputPath || it.downloadedPath)) {
              this.importCompletedItem(it);
            }
          }
        }
      });
      if (this.importSweepInterval) clearInterval(this.importSweepInterval);
      this.importSweepInterval = setInterval(() => {
        if (serviceClient.isOnline() && Array.isArray(this.queue)) {
          for (const it of this.queue) {
            if (it && it.status === "completed" && it.importStatus === "pending" && (it.outputPath || it.downloadedPath)) {
              this.importCompletedItem(it);
            }
          }
        }
      }, 5000);
      serviceClient.subscribe((msg) => {
        var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _A, _B;
        switch (msg.type) {
          case "ANALYSIS_STARTED":
            this.setAnalysisLoading(true);
            break;
          case "ANALYSIS_SUCCESS":
          case "METADATA_RESULT":
            this.setAnalysisLoading(false);
            if (((_a = msg.payload) == null ? void 0 : _a.isPlaylist) || ((_b = msg.payload) == null ? void 0 : _b.isCarousel) || (((_c = msg.payload) == null ? void 0 : _c.items) && msg.payload.items.length > 1)) {
              this.renderPlaylistModal(msg.payload);
            } else {
              this.renderMediaCard(msg.payload);
            }
            break;
          case "ANALYSIS_ERROR":
          case "ANALYSIS_FAILED":
            this.setAnalysisLoading(false);
            this.showUrlError(`${msg.payload.error || "Media analysis failed"} (${msg.payload.category || "ERROR"})`, msg.payload.category);
            break;
          case "PLAYLIST_ANALYSIS_SUCCESS":
          case "PLAYLIST_METADATA_RESULT":
            this.setAnalysisLoading(false);
            this.renderPlaylistModal(msg.payload);
            break;
          case "PLAYLIST_ANALYSIS_ERROR":
          case "PLAYLIST_ANALYSIS_FAILED":
            this.setAnalysisLoading(false);
            this.showUrlError(`Playlist extraction failed: ${msg.payload.error}`);
            break;
          case "QUEUE_UPDATED":
            this.queue = msg.payload;
            this.renderQueue();
            if (Array.isArray(this.queue)) {
              for (const it of this.queue) {
                if (it && it.status === "completed" && it.importStatus === "pending" && (it.outputPath || it.downloadedPath)) {
                  this.importCompletedItem(it);
                }
              }
            }
            break;
          case "DOWNLOAD_PROGRESS": {
            const idx = this.queue.findIndex((i) => i.id === msg.payload.id);
            if (idx >= 0) {
              this.queue[idx] = msg.payload.item;
              this.updateQueueItemDOM(msg.payload.item);
            }
            break;
          }
          case "DOWNLOAD_COMPLETED": {
            console.log("[MediaFetch] Panel received DOWNLOAD_COMPLETED for item:", msg.payload.id || ((_c = msg.payload.item) == null ? void 0 : _c.id));
            const idx = this.queue.findIndex((i) => i.id === msg.payload.id);
            if (idx >= 0) {
              this.queue[idx] = msg.payload.item;
              this.updateQueueItemDOM(msg.payload.item);
            }
            this.importCompletedItem(msg.payload.item);
            break;
          }
          case "DOWNLOAD_FAILED": {
            const idx = this.queue.findIndex((i) => i.id === msg.payload.id);
            if (idx >= 0) {
              this.queue[idx] = msg.payload.item;
              this.updateQueueItemDOM(msg.payload.item);
            }
            break;
          }
          case "SETTINGS_LOADED": {
            this.settings = msg.payload;
            this.populateSettingsForm(msg.payload);
            if (msg.payload && msg.payload.general) {
              if (msg.payload.general.theme && typeof this.applyTheme === "function") {
                if (msg.payload.general.theme === "host") {
                  this.applyTheme(hostAdapter.getHostTheme());
                } else {
                  this.applyTheme(msg.payload.general.theme);
                }
              }
              if (msg.payload.general.customThemeColor) {
                if (typeof window.applyCustomThemeColor === "function") {
                  window.applyCustomThemeColor(msg.payload.general.customThemeColor, false);
                }
              } else if (msg.payload.general.customThemeColor === "") {
                if (typeof window.resetCustomTheme === "function") {
                  window.resetCustomTheme(false);
                }
              }
              if (msg.payload.general.glassTheme && typeof window.applyGlassTheme === "function") {
                window.applyGlassTheme(msg.payload.general.glassTheme, false);
              } else if (msg.payload.general.iconTheme && typeof window.applyIconTheme === "function") {
                window.applyIconTheme(msg.payload.general.iconTheme, false);
              }
              if (msg.payload.general.ambientEnabled !== undefined && typeof window.applyAmbientGradient === "function") {
                window.applyAmbientGradient(
                  msg.payload.general.ambientEnabled,
                  msg.payload.general.ambientPreset || "crimson",
                  msg.payload.general.ambientC1 || "#0A84FF",
                  msg.payload.general.ambientC2 || "#E11D48",
                  false
                );
              }
              if (msg.payload.general.lowRamMode !== undefined && typeof window.handleLowRamMode === "function") {
                const curLowRam = localStorage.getItem("mediafetch_low_ram_mode") === "true";
                if (curLowRam !== !!msg.payload.general.lowRamMode) {
                  window.handleLowRamMode(!!msg.payload.general.lowRamMode, false);
                }
              }
            }
            if (msg.payload && msg.payload.downloads && msg.payload.downloads.clipboardFormat) {
              try {
                localStorage.setItem("mf_clipboard_img_format", msg.payload.downloads.clipboardFormat);
                const hf = document.getElementById("select-clipboard-format");
                if (hf) hf.value = msg.payload.downloads.clipboardFormat;
                const sf = document.getElementById("setting-clipboard-format");
                if (sf) sf.value = msg.payload.downloads.clipboardFormat;
              } catch (_) {}
            }
            break;
          }
          case "DIAGNOSTICS_RESULT":
            this.renderDiagnostics(msg.payload);
            this.updateSetupWizardStatus(msg.payload);
            break;
          case "HISTORY_LOADED":
            this.history = msg.payload;
            this.renderHistoryList();
            break;
          case "DUPLICATE_CHECK_RESULT":
            if (msg.payload.exists && this.pendingDownloadParams) {
              this.showDuplicateModal(msg.payload.existingFilePath || "");
            } else if (this.pendingDownloadParams) {
              this.executePendingDownload();
            }
            break;
          case "DEPENDENCY_INSTALL_PROGRESS":
            this.showInstallProgress(msg.payload);
            break;
          case "DEPENDENCY_INSTALL_RESULT":
            this.handleInstallResult(msg.payload);
            break;
          case "ZIP_PACKAGE_COMPLETED": {
            const zipPath = ((_A = msg.payload) == null ? void 0 : _A.zipPath) || msg.zipPath;
            if (zipPath) {
              const fileName = zipPath.split(/[\\\/]/).pop();
              this.showHeaderToast(`ZIP Archive created: ${fileName}`, 7e3);
            }
            break;
          }
          case "FOLDER_SELECTED": {
            const folder = (_B = msg.payload) == null ? void 0 : _B.folderPath;
            if (folder && this.pendingFolderCallback) {
              this.pendingFolderCallback(folder);
              this.pendingFolderCallback = null;
            }
            break;
          }
        }
      });
    }
    importCompletedItem(item) {
      var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m;
      if (!item || !item.id) return;
      if (this.processedImportItemIds.has(item.id)) return;
      if (item.status !== "completed" || item.importStatus !== "pending") return;

      const targetFilePath = item.outputPath || item.downloadedPath;
      if (!targetFilePath) return;

      const itemEdition = item.edition;
      const isPro = window.__MF_EDITION__ === "pro" || window.location.pathname.includes(".pro") || document.title.includes("Pro");
      const myEdition = isPro ? "pro" : "standard";
      if (itemEdition && itemEdition !== myEdition) return;

      const itemTargetHost = item.targetHost;
      const myHost = getHostAppId() || window.__MF_HOST_ID__ || (typeof hostAdapter !== "undefined" && hostAdapter.hostId);
      if (itemTargetHost && myHost && (itemTargetHost === "ppro" || itemTargetHost === "aeft") && (myHost === "ppro" || myHost === "aeft") && itemTargetHost !== myHost) {
        return;
      }

      this.processedImportItemIds.add(item.id);

      const mainAutoImportChk = document.getElementById("main-auto-import-chk");
      const mainAutoTimelineChk = document.getElementById("main-auto-timeline-chk");
      const autoImportEnabled = mainAutoImportChk ? mainAutoImportChk.checked : (localStorage.getItem("mf_auto_import_proj") !== "false");
      const autoTimelineEnabled = mainAutoTimelineChk ? mainAutoTimelineChk.checked : (localStorage.getItem("mf_auto_import_tl") === "true");
      const isZip = Boolean(item.zipPackage || ((_a = item.metadata) == null ? void 0 : _a.zipPackage));
      const itemAutoImport = !isZip && item.autoImport !== false && ((_b = item.metadata) == null ? void 0 : _b.autoImport) !== false;

      if (!itemAutoImport || (!autoImportEnabled && !autoTimelineEnabled)) {
        serviceClient.markItemImported(item.id, true);
        return;
      }

      const startTime = Date.now();
      console.log(`[MediaFetch] importCompletedItem started for item: ${item.id}`, { targetFilePath });

      const locMode = ((_d = (_c = this.settings) == null ? void 0 : _c.downloads) == null ? void 0 : _d.downloadLocationMode) || "project";
      const isCustomLocation = locMode === "custom" || locMode === "custom_flat" || Boolean(item.targetDirectory);
      const isCustomFlatLocation = locMode === "custom_flat";
      const isSimpleLocation = locMode === "simple";
      const isCloud = Boolean(item.isCloud || ((_e = item.metadata) == null ? void 0 : _e.isCloud) || ((_f = item.customFolderName) == null ? void 0 : _f.toLowerCase().includes("cloud")) || ((_h = (_g = item.metadata) == null ? void 0 : _g.uploader) == null ? void 0 : _h.toLowerCase().includes("cloud")));
      const isPlaylist = Boolean(item.isPlaylist || ((_i = item.metadata) == null ? void 0 : _i.isPlaylist) || item.playlistTitle);
      const isBatch = Boolean(item.isBatch || ((_j = item.metadata) == null ? void 0 : _j.isBatch));
      const isSearch = Boolean(item.isSearch || (item.metadata && item.metadata.isSearch) || item.source === "search" || (targetFilePath && (targetFilePath.indexOf("/Search/") !== -1 || targetFilePath.indexOf("\\Search\\") !== -1 || targetFilePath.indexOf("SerachMediafetch") !== -1 || targetFilePath.indexOf("SearchMediafetch") !== -1)));
      const isSingleLink = !isPlaylist && !isCloud && !isBatch;
      const playlistTitle = item.playlistTitle || ((_k = item.metadata) == null ? void 0 : _k.playlistTitle) || "";
      const customFolderName = item.customFolderName || ((_l = item.metadata) == null ? void 0 : _l.customFolderName) || "";
      const subFolderName = item.subFolderName || ((_m = item.metadata) == null ? void 0 : _m.subFolderName) || "";

      hostAdapter.importToProject(targetFilePath, {
        downloadLocationMode: locMode,
        isCustomPath: isCustomLocation,
        isCustomFlat: isCustomFlatLocation,
        isSimplePath: isSimpleLocation,
        isSimple: isSimpleLocation,
        isCloud,
        isPlaylist,
        isSingleLink,
        isSearch,
        playlistTitle,
        customFolderName,
        subFolderName,
        addToTimeline: autoTimelineEnabled,
        insertToTimeline: autoTimelineEnabled
      }).then((success) => {
        const elapsedMs = Date.now() - startTime;
        console.log(`[MediaFetch] importCompletedItem ended for item: ${item.id} (elapsed: ${elapsedMs}ms, result: ${success ? "success" : "failed"})`);
        if (success) {
          serviceClient.markItemImported(item.id, true);
          this.showHeaderToast("Imported media into Project bin" + (autoTimelineEnabled ? " and timeline" : "") + "!", 4000);
        } else {
          serviceClient.markItemImported(item.id, false, "Import returned false");
          this.showHeaderToast("Auto-import failed for " + (item.title || "media"), 6000, () => {
            this.processedImportItemIds.delete(item.id);
            this.importCompletedItem(item);
          });
        }
      }).catch((err) => {
        const elapsedMs = Date.now() - startTime;
        console.warn(`[MediaFetch] importCompletedItem ended for item: ${item.id} (elapsed: ${elapsedMs}ms, result: failed, error: ${err})`);
        serviceClient.markItemImported(item.id, false, String(err));
        this.showHeaderToast("Auto-import failed: " + ((err == null ? void 0 : err.message) || err), 6000, () => {
          this.processedImportItemIds.delete(item.id);
          this.importCompletedItem(item);
        });
      });
    }
    isCheckingPendingImports = false;
    async checkPendingImports() {
      if (this.isCheckingPendingImports) return;
      this.isCheckingPendingImports = true;
      try {
        const res = await fetch(`http://127.0.0.1:${serviceClient.port || 48924}/api/pending-imports`).catch(() => null);
        if (res && res.ok) {
          const data = await res.json().catch(() => null);
          if (data && Array.isArray(data.items)) {
            for (const item of data.items) {
              if (!item.imported && !this.processedImportItemIds.has(item.id)) {
                console.log(`[MediaFetch] Catching up pending import for item ${item.id}`);
                this.importCompletedItem(item);
              }
            }
          }
        }
      } catch (err) {
        console.warn('[MediaFetch] checkPendingImports error:', err);
      } finally {
        this.isCheckingPendingImports = false;
      }
    }
    bindDomEvents() {
      var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _A, _B, _C, _D, _E, _F, _G;
      const urlInput = document.getElementById("url-input");
      const onUrlChanged = (val) => {
        const trimmed = (val || "").trim();
        if (this.currentMetadata && this.currentMetadata.url !== trimmed && this.currentMetadata.webpage_url !== trimmed) {
          this.currentMetadata = null;
          const cardSection = document.getElementById("media-card-section");
          if (cardSection) cardSection.style.display = "none";
        }
        this.checkUrlForPlatform(trimmed);
      };
      urlInput == null ? void 0 : urlInput.addEventListener("input", (e) => onUrlChanged(e.target.value));
      urlInput == null ? void 0 : urlInput.addEventListener("paste", () => setTimeout(() => onUrlChanged((urlInput == null ? void 0 : urlInput.value) || ""), 50));
      document.querySelectorAll(".mode-icon-group .segment-icon-btn, .segment-btn[data-mode]").forEach((btn) => {
        btn.addEventListener("click", (e) => {
          document.querySelectorAll(".mode-icon-group .segment-icon-btn, .segment-btn[data-mode]").forEach((b) => b.classList.remove("active"));
          const target = e.currentTarget;
          target.classList.add("active");
          const mode = target.getAttribute("data-mode") || "video-audio";
          this.updateDropdownsForMode(mode);
        });
      });
      const cardFormatSelect = document.getElementById("format-select");
      cardFormatSelect == null ? void 0 : cardFormatSelect.addEventListener("change", () => {
        const val = (cardFormatSelect.value || "").toLowerCase();
        if (["mp4", "mov", "mkv", "webm"].includes(val)) {
          if (this.currentMode === "audio-only") {
            this.updateDropdownsForMode("video-audio");
          }
        } else if (["mp3", "wav", "m4a", "flac"].includes(val)) {
          if (this.currentMode === "video-audio" || this.currentMode === "video-only") {
            this.updateDropdownsForMode("audio-only");
          }
        }
      });
      const cardProfileSelect = document.getElementById("profile-select");
      cardProfileSelect == null ? void 0 : cardProfileSelect.addEventListener("change", () => {
        const pVal = cardProfileSelect.value || "";
        const is4K = pVal === "res-2160" || pVal === "video-4k" || pVal.includes("2160");
        if (is4K) {
          this.showHeaderToast(
            "4K Ultra HD selected: Studio quality master. Note: 4K files take a bit longer to download and optimize.",
            4500
          );
        } else {
          this.dismissHeaderToastIf("4K");
        }
      });
      (_a = document.getElementById("btn-close-header-alert")) == null ? void 0 : _a.addEventListener("click", () => {
        this.dismissHeaderToast();
      });
      const mainTimelineChk = document.getElementById("main-auto-timeline-chk");
      if (mainTimelineChk) {
        mainTimelineChk.addEventListener("change", () => {
          if (mainTimelineChk.checked) {
            const mainProjChk = document.getElementById("main-auto-import-chk");
            if (mainProjChk && !mainProjChk.checked) {
              mainProjChk.checked = true;
            }
            this.showHeaderToast(
              "Auto-Timeline: Files will import directly into your active timeline/top layer. Import may cause a brief pause.",
              6e3
            );
          } else {
            this.dismissHeaderToastIf("Auto-Timeline");
          }
        });
      }
      (_b = document.getElementById("setting-location-mode")) == null ? void 0 : _b.addEventListener("change", () => {
        this.updateDownloadLocationModeUI();
      });
      (_c = document.getElementById("btn-browse-custom-location")) == null ? void 0 : _c.addEventListener("click", () => {
        const modeSel = document.getElementById("setting-location-mode");
        if (modeSel && modeSel.value !== "custom") {
          modeSel.value = "custom";
          this.updateDownloadLocationModeUI();
        }
        this.selectFolderModern((folderPath) => {
          const input = document.getElementById("setting-custom-location");
          if (input) input.value = folderPath;
          if (modeSel) modeSel.value = "custom";
          this.updateDownloadLocationModeUI();
        });
      });
      (_d = document.getElementById("target-dir-display")) == null ? void 0 : _d.addEventListener("click", () => {
        this.selectFolderModern((folderPath) => {
          var _a2;
          serviceClient.updateSettings({
            downloads: {
              ...(_a2 = this.settings) == null ? void 0 : _a2.downloads,
              downloadLocationMode: "custom",
              customLocation: folderPath
            }
          });
          const targetDirDisplay = document.getElementById("target-dir-display");
          if (targetDirDisplay) {
            targetDirDisplay.textContent = `Target: ${folderPath}`;
          }
          const customLocInput = document.getElementById("setting-custom-location");
          if (customLocInput) customLocInput.value = folderPath;
          const modeSel = document.getElementById("setting-location-mode");
          if (modeSel) modeSel.value = "custom";
          this.updateDownloadLocationModeUI();
        });
      });
      (_e = document.getElementById("btn-analyze")) == null ? void 0 : _e.addEventListener("click", () => this.handleAnalyze());
      urlInput == null ? void 0 : urlInput.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
          this.handleAnalyze();
        }
      });
      (_f = document.getElementById("btn-paste")) == null ? void 0 : _f.addEventListener("click", async () => {
        await this.handlePasteAction();
        onUrlChanged((urlInput == null ? void 0 : urlInput.value) || "");
      });
      (_g = document.getElementById("btn-paste-url")) == null ? void 0 : _g.addEventListener("click", async () => {
        await this.handlePasteAction();
        onUrlChanged((urlInput == null ? void 0 : urlInput.value) || "");
      });
      (_h = document.getElementById("btn-close-card")) == null ? void 0 : _h.addEventListener("click", () => {
        const card = document.getElementById("media-card-section");
        if (card) card.style.display = "none";
        this.currentMetadata = null;
      });
      (_i = document.getElementById("btn-download-action")) == null ? void 0 : _i.addEventListener("click", async () => {
        await this.refreshProjectContext();
        this.handleDownloadClick();
      });
      (_j = document.getElementById("btn-pause-all")) == null ? void 0 : _j.addEventListener("click", () => {
        for (const item of this.queue) {
          if (item.status === "downloading" || item.status === "waiting") {
            serviceClient.pauseDownload(item.id);
          }
        }
        serviceClient.send({ type: "PAUSE_DOWNLOAD", payload: {} });
      });
      (_k = document.getElementById("btn-resume-all")) == null ? void 0 : _k.addEventListener("click", () => {
        let count = 0;
        for (const item of this.queue) {
          if (item.status === "paused" || item.status === "failed" || item.status === "downloading") {
            serviceClient.resumeDownload(item.id);
            count++;
          }
        }
        serviceClient.send({ type: "RESUME_DOWNLOAD", payload: {} });
      });
      (_l = document.getElementById("btn-clear-completed")) == null ? void 0 : _l.addEventListener("click", () => {
        serviceClient.clearCompleted();
        this.queue = this.queue.filter((i) => i.status === "downloading" || i.status === "waiting");
        this.renderQueue();
      });
      const queueContainer = document.getElementById("queue-container");
      queueContainer == null ? void 0 : queueContainer.addEventListener("click", (e) => {
        var _a2, _b2, _c2, _d2, _e2, _f2, _g2, _h2, _i2, _j2, _k2, _l2, _m2;
        const btn = e.target.closest("button");
        if (!btn) return;
        const itemEl = btn.closest(".queue-item");
        const itemId = (_a2 = itemEl == null ? void 0 : itemEl.id) == null ? void 0 : _a2.replace("q-item-", "");
        if (!itemId) return;
        if (btn.classList.contains("btn-pause")) {
          serviceClient.pauseDownload(itemId);
        } else if (btn.classList.contains("btn-resume")) {
          serviceClient.resumeDownload(itemId);
        } else if (btn.classList.contains("btn-cancel")) {
          serviceClient.cancelDownload(itemId);
          this.queue = this.queue.filter((i) => i.id !== itemId);
          this.renderQueue();
        } else if (btn.classList.contains("btn-retry")) {
          serviceClient.retryDownload(itemId);
        } else if (btn.classList.contains("btn-reveal")) {
          const item = this.queue.find((i) => i.id === itemId);
          if (item == null ? void 0 : item.outputPath) hostAdapter.revealInFinder(item.outputPath);
        } else if (btn.classList.contains("btn-import")) {
          const item = this.queue.find((i) => i.id === itemId);
          const targetPath = (item == null ? void 0 : item.outputPath) || (item == null ? void 0 : item.downloadedPath);
          if (targetPath) {
            btn.setAttribute("disabled", "true");
            btn.style.opacity = "0.5";
            this.showHeaderToast(`Importing "${(item == null ? void 0 : item.title) || "media"}" to Project Panel...`, 3e3);
            const locMode = ((_c2 = (_b2 = this.settings) == null ? void 0 : _b2.downloads) == null ? void 0 : _c2.downloadLocationMode) || "project";
            const isCustomFlatLocation = locMode === "custom_flat";
            const isCustomLocation = locMode === "custom" || isCustomFlatLocation;
            const isSimpleLocation = locMode === "simple";
            const isCloud = Boolean((item == null ? void 0 : item.isCloud) || ((_d2 = item == null ? void 0 : item.metadata) == null ? void 0 : _d2.isCloud) || ((_e2 = item == null ? void 0 : item.customFolderName) == null ? void 0 : _e2.toLowerCase().includes("cloud")) || ((_g2 = (_f2 = item == null ? void 0 : item.metadata) == null ? void 0 : _f2.uploader) == null ? void 0 : _g2.toLowerCase().includes("cloud")));
            const isPlaylist = Boolean((item == null ? void 0 : item.isPlaylist) || ((_h2 = item == null ? void 0 : item.metadata) == null ? void 0 : _h2.isPlaylist) || (item == null ? void 0 : item.playlistTitle));
            const isBatch = Boolean((item == null ? void 0 : item.isBatch) || ((_i2 = item == null ? void 0 : item.metadata) == null ? void 0 : _i2.isBatch));
            const isSearch = Boolean((item == null ? void 0 : item.isSearch) || ((item == null ? void 0 : item.metadata) && item.metadata.isSearch) || (item == null ? void 0 : item.source) === "search" || (targetPath && (targetPath.indexOf("/Search/") !== -1 || targetPath.indexOf("\\Search\\") !== -1 || targetPath.indexOf("SerachMediafetch") !== -1 || targetPath.indexOf("SearchMediafetch") !== -1)));
            const isSingleLink = !isPlaylist && !isCloud && !isBatch;
            const autoTimelineEnabled = ((_j2 = document.getElementById("main-auto-timeline-chk")) == null ? void 0 : _j2.checked) || (localStorage.getItem("mf_auto_import_tl") === "true");
            hostAdapter.importToProject(targetPath, {
              downloadLocationMode: locMode,
              isCustomPath: isCustomLocation,
              isCustomFlat: isCustomFlatLocation,
              isSimplePath: isSimpleLocation,
              isSimple: isSimpleLocation,
              isCloud,
              isPlaylist,
              isSingleLink,
              isSearch,
              playlistTitle: (item == null ? void 0 : item.playlistTitle) || ((_k2 = item == null ? void 0 : item.metadata) == null ? void 0 : _k2.playlistTitle) || "",
              customFolderName: (item == null ? void 0 : item.customFolderName) || ((_l2 = item == null ? void 0 : item.metadata) == null ? void 0 : _l2.customFolderName) || "",
              subFolderName: (item == null ? void 0 : item.subFolderName) || ((_m2 = item == null ? void 0 : item.metadata) == null ? void 0 : _m2.subFolderName) || "",
              addToTimeline: autoTimelineEnabled && isSingleLink,
              insertToTimeline: autoTimelineEnabled && isSingleLink
            }).then((success) => {
              btn.removeAttribute("disabled");
              btn.style.opacity = "1";
              if (success) {
                this.showHeaderToast(`Imported "${(item == null ? void 0 : item.title) || "media"}" into Project bin${autoTimelineEnabled ? " and Timeline" : ""}!`, 4e3);
              } else {
                this.showHeaderToast("Could not import media to Project Panel. Please ensure project bin is unlocked or retry.", 5000);
              }
            }).catch((err) => {
              btn.removeAttribute("disabled");
              btn.style.opacity = "1";
              console.error("[MediaFetch] Manual import error:", err);
              this.showHeaderToast("Import failed: " + ((err == null ? void 0 : err.message) || err), 5e3);
            });
          } else {
            this.showHeaderToast("Media file path not found on disk.", 4e3);
          }
        }
      });
      const openUnifiedSettings = () => {
        var _a2;
        serviceClient.getSettings();
        serviceClient.getDiagnostics();
        if (typeof window.Settings !== "undefined") {
          const s = window.Settings.load();
          const pexelsInput = document.getElementById("setting-studio-pexels-key");
          const pixabayInput = document.getElementById("setting-studio-pixabay-key");
          const unsplashInput = document.getElementById("setting-studio-unsplash-key");
          const giphyInput = document.getElementById("setting-studio-giphy-key");
          const timelineCheck = document.getElementById("setting-studio-auto-timeline");
          if (pexelsInput) pexelsInput.value = s.pexelsApiKey || "";
          if (pixabayInput) pixabayInput.value = s.pixabayApiKey || "";
          if (unsplashInput) unsplashInput.value = s.unsplashApiKey || "";
          if (giphyInput) giphyInput.value = s.giphyApiKey || "";
          if (timelineCheck) timelineCheck.checked = s.autoInsertTimeline !== false;
        }
        if (typeof ((_a2 = window.MediaFetchLicense) == null ? void 0 : _a2.updateBadge) === "function") {
          window.MediaFetchLicense.updateBadge();
        }
        this.openModal("modal-settings");
      };
      (_m = document.getElementById("btn-top-settings")) == null ? void 0 : _m.addEventListener("click", openUnifiedSettings);
      (_n = document.getElementById("btn-settings")) == null ? void 0 : _n.addEventListener("click", openUnifiedSettings);
      (_o = document.getElementById("btn-clipboard-paste")) == null ? void 0 : _o.addEventListener("click", async () => {
        var _a2;
        const btn = document.getElementById("btn-clipboard-paste");
        if (btn) {
          btn.style.opacity = "0.5";
          btn.style.pointerEvents = "none";
        }
        try {
          let imported = false;
          try {
            this.projectContext = await hostAdapter.getProjectContext();
          } catch (_) {
          }
          let activeProjDir = ((_a2 = this.projectContext) == null ? void 0 : _a2.projectDirectory) || "";
          if (!activeProjDir && typeof window.CSInterface !== "undefined") {
            try {
              const cs = new window.CSInterface();
              const hInfoStr = await new Promise((res) => cs.evalScript("MediaFetchHost.getHostInfo()", res));
              const hInfo = JSON.parse(hInfoStr);
              if (hInfo && hInfo.projectPath) {
                const pClean = hInfo.projectPath.replace(/\\/g, "/");
                activeProjDir = pClean.substring(0, pClean.lastIndexOf("/")).replace(/\//g, "\\");
              }
            } catch (_) {
            }
          }
          if (!activeProjDir && typeof window.__adobe_cep__ !== "undefined") {
            try {
              const hInfoStr = await new Promise((res) => {
                window.__adobe_cep__.evalScript("MediaFetchHost.getHostInfo()", res);
              });
              const hInfo = JSON.parse(hInfoStr);
              if (hInfo && hInfo.projectPath) {
                const pClean = hInfo.projectPath.replace(/\\/g, "/");
                activeProjDir = pClean.substring(0, pClean.lastIndexOf("/")).replace(/\//g, "\\");
              }
            } catch (_) {
            }
          }
          if (activeProjDir) {
            try {
              serviceClient.send({
                type: "UPDATE_PROJECT_CONTEXT",
                payload: { projectDirectory: activeProjDir }
              });
            } catch (_) {
            }
          }
          const port = window.__MF_PORT__ || 48924;
          const formatSelectEl = document.getElementById("select-clipboard-format");
          const formatPref = (formatSelectEl == null ? void 0 : formatSelectEl.value) || localStorage.getItem("mf_clipboard_img_format") || "png";
          const queryParam = `?format=${encodeURIComponent(formatPref)}` + (activeProjDir ? `&projectDir=${encodeURIComponent(activeProjDir)}` : "");
          let data = null;
          try {
            const res = await fetch(`http://127.0.0.1:${port}/api/clipboard/paste-media${queryParam}`);
            data = await res.json();
          } catch (_) {
            try {
              const res = await fetch(`http://127.0.0.1:48924/api/clipboard/paste-media${queryParam}`);
              data = await res.json();
            } catch (e) {
              console.warn("[MediaFetch] Could not reach clipboard service:", e);
            }
          }
          if (data && data.success) {
            if (data.type === "image" || data.type === "file") {
              // Paste IMG: Always import into Project Bin AND Timeline both (unchangeable default)
              const shouldInsertTimeline = true;
              const shouldImportProject = true;

              let importOk = false;
              importOk = await hostAdapter.importToProject(data.filePath, {
                isSingleLink: true,
                addToTimeline: true,
                insertToTimeline: true,
                isClipboard: true,
                projectDirectory: activeProjDir
              });
              if (!importOk && typeof window !== "undefined") {
                try {
                  const cs = window.CSInterface ? new window.CSInterface() : null;
                  const evalFn = cs ? ((s, cb) => cs.evalScript(s, cb)) : (window.__adobe_cep__ ? ((s, cb) => window.__adobe_cep__.evalScript(s, cb)) : null);
                  if (evalFn) {
                    const cleanP = data.filePath.replace(/\\/g, "/");
                    const optsStr = JSON.stringify({ isClipboard: true, isSingleLink: true, addToTimeline: true, insertToTimeline: true });
                    const rawRes = await new Promise((r) => evalFn(`MediaFetchHost.importMedia(${JSON.stringify(cleanP)}, true, ${JSON.stringify(optsStr)})`, r));
                    if (rawRes && rawRes !== "EvalScript error.") {
                      try {
                        const p = JSON.parse(rawRes);
                        if (p && p.success) importOk = true;
                      } catch (_) {
                        if (rawRes === "true" || rawRes === true) importOk = true;
                      }
                    }
                  }
                } catch (_) {}
              }
              const fmtLabel = (formatPref === 'jpg' ? 'JPEG' : formatPref.toUpperCase());
              if (importOk) {
                this.showHeaderToast(`Pasted "${data.fileName || "image"}" (${fmtLabel}) into Project & Timeline!`, 5e3);
              } else {
                this.showHeaderToast(`Extracted "${data.fileName || "media"}" (${fmtLabel}) to disk (open an Adobe sequence/project to auto-import).`, 5e3);
              }
              imported = true;
            } else if (data.type === "text" && data.text) {
              const urlInput2 = document.getElementById("url-input");
              if (urlInput2) {
                urlInput2.value = data.text;
                urlInput2.dispatchEvent(new Event("input", { bubbles: true }));
                this.showHeaderToast("Pasted link from clipboard!", 4e3);
                imported = true;
              }
            }
          }
          if (!imported) {
            this.showHeaderToast("Clipboard has no image or media. Copy an image or screenshot first!", 4e3);
          }
        } catch (err) {
          console.warn("[MediaFetch] Clipboard paste error:", err);
          this.showHeaderToast("Clipboard paste failed: " + ((err == null ? void 0 : err.message) || "Error"), 4e3);
        } finally {
          if (btn) {
            btn.style.opacity = "1";
            btn.style.pointerEvents = "auto";
          }
        }
      });
      const initSavedFormat = localStorage.getItem("mf_clipboard_img_format") || "png";
      const hdrFormatEl = document.getElementById("select-clipboard-format");
      const dlgFormatEl = document.getElementById("setting-clipboard-format");
      if (hdrFormatEl) hdrFormatEl.value = initSavedFormat;
      if (dlgFormatEl) dlgFormatEl.value = initSavedFormat;
      if (hdrFormatEl) {
        hdrFormatEl.addEventListener("change", (e) => {
          const val = e.target.value;
          localStorage.setItem("mf_clipboard_img_format", val);
          const sf = document.getElementById("setting-clipboard-format");
          if (sf) sf.value = val;
        });
      }
      if (dlgFormatEl) {
        dlgFormatEl.addEventListener("change", (e) => {
          const val = e.target.value;
          localStorage.setItem("mf_clipboard_img_format", val);
          const hf = document.getElementById("select-clipboard-format");
          if (hf) hf.value = val;
        });
      }
      (_p = document.getElementById("btn-history")) == null ? void 0 : _p.addEventListener("click", () => {
        serviceClient.getHistory();
        this.openModal("modal-history");
      });
      (_q = document.getElementById("btn-diagnostics")) == null ? void 0 : _q.addEventListener("click", () => {
        serviceClient.getDiagnostics();
        this.openModal("modal-diagnostics");
      });
      (_r = document.getElementById("btn-setup-wizard-trigger")) == null ? void 0 : _r.addEventListener("click", () => {
        this.closeModal("modal-diagnostics");
        this.openModal("modal-setup");
        serviceClient.runSystemCheck();
      });
      document.querySelectorAll(".modal-close-btn").forEach((btn) => {
        btn.addEventListener("click", (e) => {
          const overlay = e.target.closest(".modal-overlay");
          if (overlay) overlay.classList.remove("active");
        });
      });
      const modalApiGuide = document.getElementById("modal-api-guide");
      const btnOpenApiGuide = document.getElementById("btn-open-api-guide");
      const btnCloseApiGuide = document.getElementById("btn-close-api-guide");
      const btnDoneApiGuide = document.getElementById("btn-done-api-guide");
      const closeApiGuide = () => {
        if (modalApiGuide) {
          modalApiGuide.style.display = "none";
          modalApiGuide.classList.remove("active");
        }
      };
      btnOpenApiGuide == null ? void 0 : btnOpenApiGuide.addEventListener("click", () => {
        if (modalApiGuide) {
          modalApiGuide.style.display = "flex";
          modalApiGuide.classList.add("active");
        }
      });
      btnCloseApiGuide == null ? void 0 : btnCloseApiGuide.addEventListener("click", closeApiGuide);
      btnDoneApiGuide == null ? void 0 : btnDoneApiGuide.addEventListener("click", closeApiGuide);
      document.querySelectorAll(".btn-api-external-link").forEach((linkBtn) => {
        linkBtn.addEventListener("click", (e) => {
          var _a2, _b2;
          const u = e.currentTarget.getAttribute("data-url");
          if (u) {
            if (window.__adobe_cep__ && typeof window.__adobe_cep__.openURLInDefaultBrowser === "function") {
              window.__adobe_cep__.openURLInDefaultBrowser(u);
            } else if ((_b2 = (_a2 = window.cep) == null ? void 0 : _a2.util) == null ? void 0 : _b2.openURLInDefaultBrowser) {
              window.cep.util.openURLInDefaultBrowser(u);
            } else {
              window.open(u, "_blank");
            }
          }
        });
      });
      document.querySelectorAll(".tab-btn").forEach((btn) => {
        btn.addEventListener("click", (e) => {
          const targetTab = e.currentTarget.getAttribute("data-tab");
          document.querySelectorAll(".tab-btn").forEach((b) => b.classList.remove("active"));
          document.querySelectorAll(".tab-pane").forEach((p) => p.style.display = "none");
          e.currentTarget.classList.add("active");
          if (targetTab) {
            const pane = document.getElementById(targetTab);
            if (pane) pane.style.display = "block";
          }
        });
      });
      const themeSelectEl = document.getElementById("setting-theme");
      if (themeSelectEl) {
        themeSelectEl.addEventListener("change", (e) => {
          const val = e.target.value;
          if (typeof this.applyTheme === "function") {
            if (val === "host") {
              this.applyTheme(hostAdapter.getHostTheme());
            } else {
              this.applyTheme(val);
            }
          }
          serviceClient.updateSettings({
            general: {
              theme: val
            }
          });
        });
      }
      (_s = document.getElementById("btn-save-settings")) == null ? void 0 : _s.addEventListener("click", () => {
        this.saveSettingsFromForm();
        this.closeModal("modal-settings");
      });
      (_t = document.getElementById("btn-update-ytdlp")) == null ? void 0 : _t.addEventListener("click", () => {
        const btn = document.getElementById("btn-update-ytdlp");
        const statusEl = document.getElementById("engine-update-status");
        if (btn) {
          btn.disabled = true;
          btn.textContent = "Checking for updates...";
        }
        if (statusEl) {
          statusEl.style.display = "block";
          statusEl.style.color = "var(--text-secondary, #aaa)";
          statusEl.textContent = "Connecting to official yt-dlp repository...";
        }
        serviceClient.updateYtDlp();
      });
      (_u = document.getElementById("btn-setup-install-all")) == null ? void 0 : _u.addEventListener("click", () => {
        const progRow = document.getElementById("setup-progress-row");
        if (progRow) progRow.style.display = "flex";
        serviceClient.installDependency("all");
      });
      (_v = document.getElementById("btn-dup-cancel")) == null ? void 0 : _v.addEventListener("click", () => {
        this.pendingDownloadParams = null;
        this.closeModal("modal-duplicate");
      });
      (_w = document.getElementById("btn-dup-use-existing")) == null ? void 0 : _w.addEventListener("click", () => {
        this.pendingDownloadParams = null;
        this.closeModal("modal-duplicate");
      });
      (_x = document.getElementById("btn-dup-download-new")) == null ? void 0 : _x.addEventListener("click", () => {
        this.closeModal("modal-duplicate");
        this.executePendingDownload();
      });
      (_y = document.getElementById("btn-playlist-select-all")) == null ? void 0 : _y.addEventListener("click", () => {
        document.querySelectorAll(".playlist-checkbox").forEach((cb) => cb.checked = true);
        this.updatePlaylistSelectedCount();
      });
      (_z = document.getElementById("btn-playlist-deselect-all")) == null ? void 0 : _z.addEventListener("click", () => {
        document.querySelectorAll(".playlist-checkbox").forEach((cb) => cb.checked = false);
        this.updatePlaylistSelectedCount();
      });
      document.querySelectorAll('input[name="playlist-mode"]').forEach((r) => {
        r.addEventListener("change", (e) => {
          const val = e.target.value;
          const wrapper = document.getElementById("playlist-items-wrapper");
          if (wrapper) {
            wrapper.style.display = val === "selected" ? "block" : "none";
          }
          if (val === "all") {
            document.querySelectorAll(".playlist-checkbox").forEach((cb) => cb.checked = true);
          }
          this.updatePlaylistSelectedCount();
        });
      });
      (_A = document.getElementById("btn-playlist-confirm-download")) == null ? void 0 : _A.addEventListener("click", () => {
        this.handlePlaylistDownloadSubmit();
      });
      (_B = document.getElementById("btn-playlist-browse-folder")) == null ? void 0 : _B.addEventListener("click", () => {
        this.selectFolderModern((folderPath) => {
          this.playlistCustomTargetDir = folderPath;
          const pathEl = document.getElementById("playlist-destination-path");
          if (pathEl) pathEl.textContent = folderPath;
        });
      });
      const zipCb = document.getElementById("playlist-zip-package-cb");
      const autoImportCb = document.getElementById("playlist-auto-import-cb");
      const autoImportLabel = autoImportCb == null ? void 0 : autoImportCb.closest("label");
      zipCb == null ? void 0 : zipCb.addEventListener("change", () => {
        if (zipCb.checked) {
          if (autoImportCb) {
            autoImportCb.checked = false;
            autoImportCb.disabled = true;
          }
          if (autoImportLabel) {
            autoImportLabel.style.opacity = "0.45";
            autoImportLabel.title = "Auto-import is disabled when packaging as ZIP archive";
          }
        } else {
          if (autoImportCb) {
            autoImportCb.disabled = false;
          }
          if (autoImportLabel) {
            autoImportLabel.style.opacity = "1";
            autoImportLabel.title = "";
          }
        }
      });
      autoImportCb == null ? void 0 : autoImportCb.addEventListener("change", () => {
        if (autoImportCb.checked && zipCb) {
          zipCb.checked = false;
        }
      });
      (_C = document.getElementById("btn-link-preview-play")) == null ? void 0 : _C.addEventListener("click", (e) => {
        e.stopPropagation();
        this.openMediaPreview(this.currentMetadata);
      });
      (_D = document.getElementById("link-downloader-thumb-box")) == null ? void 0 : _D.addEventListener("click", () => {
        this.openMediaPreview(this.currentMetadata);
      });
      (_E = document.getElementById("btn-close-media-preview")) == null ? void 0 : _E.addEventListener("click", () => {
        this.closeMediaPreview();
      });
      const toggleTrimBtn = document.getElementById("btn-toggle-trim");
      if (toggleTrimBtn) {
        toggleTrimBtn.onclick = (e) => {
          if (typeof window.toggleTrimPanel === "function") {
            window.toggleTrimPanel(e);
          }
        };
      }
      document.querySelectorAll(".modal-overlay").forEach((overlay) => {
        overlay.addEventListener("click", (e) => {
          if (e.target === overlay) {
            const id = overlay.id;
            if (id === "modal-media-preview") {
              this.closeMediaPreview();
            } else {
              this.closeModal(id);
            }
          }
        });
      });
      (_F = document.getElementById("btn-clear-history")) == null ? void 0 : _F.addEventListener("click", () => {
        serviceClient.clearHistory();
      });
      (_G = document.getElementById("history-search-input")) == null ? void 0 : _G.addEventListener("input", (e) => {
        const query = e.target.value;
        this.renderHistoryList(query);
      });
    }
    closeCard() {
      const card = document.getElementById("media-card-section");
      if (card) card.style.display = "none";
      this.currentMetadata = null;
    }
    async handlePasteAction() {
      const urlInput = document.getElementById("url-input");
      const pasteBtn = document.getElementById("btn-paste-url");
      if (!urlInput) return;
      let text = "";
      try {
        const nodeReq = window.require;
        if (nodeReq) {
          const cp = nodeReq("child_process");
          if (typeof process !== "undefined" && process.platform === "win32") {
            text = (cp.execSync("powershell.exe -NoProfile -Command Get-Clipboard", { encoding: "utf8", timeout: 2e3, windowsHide: true }) || "").trim();
          } else if (typeof process !== "undefined" && process.platform === "darwin") {
            text = (cp.execSync("pbpaste", { encoding: "utf8", timeout: 1500 }) || "").trim();
          }
        }
      } catch (_) {
      }
      if (!text) {
        try {
          const resp = await fetch("http://127.0.0.1:48924/api/clipboard");
          const data = await resp.json();
          if (data && data.success && data.text) {
            text = data.text.trim();
          }
        } catch (_) {
        }
      }
      if (!text) {
        try {
          if (navigator.clipboard && navigator.clipboard.readText) {
            const clip = await navigator.clipboard.readText();
            if (clip && clip.trim().length > 0) {
              text = clip.trim();
            }
          }
        } catch (_) {
        }
      }
      if (!text) {
        try {
          urlInput.focus();
          urlInput.select();
          const success = document.execCommand("paste");
          if (success && urlInput.value && urlInput.value.trim().length > 0) {
            text = urlInput.value.trim();
          }
        } catch (_) {
        }
      }
      if (text && text.trim().length > 0) {
        urlInput.value = text.trim();
        this.hideUrlError();
        urlInput.dispatchEvent(new Event("input", { bubbles: true }));
        if (pasteBtn) {
          const origHtml = pasteBtn.innerHTML;
          pasteBtn.innerHTML = `<span style="color:#00d1b2; font-weight:700; display:inline-flex; align-items:center; gap:4px;">${ICONS.CHECK} Pasted</span>`;
          setTimeout(() => {
            pasteBtn.innerHTML = origHtml;
          }, 1200);
        }
        return;
      }
      urlInput.focus();
      this.showUrlError("Press Ctrl+V to paste into the URL box.");
    }
    get isPro() {
      return window.__MF_EDITION__ === "pro" || window.location.pathname.includes(".pro") || document.title.includes("Pro");
    }
    isCloudUrl(url) {
      const lower = (url || "").toLowerCase();
      return lower.includes("drive.google.com") || lower.includes("dropbox.com") || lower.includes("1drv.ms") || lower.includes("onedrive.live.com") || lower.includes("sharepoint.com") || lower.includes("box.com") || lower.includes("mega.nz");
    }
    isPlaylistUrl(url) {
      const lower = (url || "").toLowerCase();
      const isAppleTrack = (lower.includes("music.apple.com") || lower.includes("itunes.apple.com")) && (lower.includes("?i=") || lower.includes("&i=") || lower.includes("?track=") || lower.includes("&track="));
      if (isAppleTrack) return false;
      return lower.includes("list=") || lower.includes("/playlist") || lower.includes("/sets/") || lower.includes("/album/") || lower.includes("spotify.") && (lower.includes("/playlist/") || lower.includes("/album/") || lower.includes("/artist/")) || lower.includes("drive.google.com/drive/folders/") || lower.includes("drive.google.com/drive/u/") || lower.includes("drive.google.com/folderview") || lower.includes("dropbox.com") && (lower.includes("/scl/fo/") || lower.includes("/sh/") || lower.includes("/folder/")) || lower.includes("1drv.ms") || lower.includes("onedrive.live.com") || lower.includes("sharepoint.com") || lower.includes("box.com/s/") || lower.includes("box.com/folder/") || lower.includes("mega.nz/folder/") || lower.includes("mega.nz/#f!") || lower.includes("pinterest.") && lower.includes("/boards/") || lower.includes("instagram.com/p/") || lower.includes("instagram.com/reel/") || lower.includes("instagram.com/reels/") || lower.includes("instagram.com/stories/") || lower.includes("behance.net/gallery/") || lower.includes("threads.net/") || lower.includes("threads.com/") || lower.includes("linkedin.com/posts/") || lower.includes("linkedin.com/feed/update/");
    }
    handleAnalyze() {
      var _a;
      const input = document.getElementById("url-input");
      const url = (_a = input == null ? void 0 : input.value) == null ? void 0 : _a.trim();
      this.hideUrlError();
      if (!url) {
        this.showUrlError("Please enter or paste a valid media URL.");
        return;
      }
      if (!this.isPro && this.isCloudUrl(url)) {
        this.showUrlError("Cloud links (Google Drive, Dropbox, OneDrive, Mega) are exclusive to MediaFetch Pro. Upgrade to MediaFetch Pro to download cloud storage files.");
        this.showHeaderToast("Cloud links are exclusive to MediaFetch Pro", 5e3);
        return;
      }
      this.setAnalysisLoading(true);
      if (this.analysisTimeout) clearTimeout(this.analysisTimeout);
      this.analysisTimeout = window.setTimeout(() => {
        if (this.isAnalyzing) {
          this.setAnalysisLoading(false);
          this.showUrlError("Analysis timed out. Please verify your internet connection or check that the URL is public.");
        }
      }, 75e3);
      if (this.isPlaylistUrl(url)) {
        serviceClient.analyzePlaylist(url);
        return;
      }
      serviceClient.analyzeUrl(url);
    }
    setAnalysisLoading(loading) {
      this.isAnalyzing = loading;
      if (!loading && this.analysisTimeout) {
        clearTimeout(this.analysisTimeout);
        this.analysisTimeout = void 0;
      }
      const btn = document.getElementById("btn-analyze");
      const text = document.getElementById("analyze-btn-text");
      if (btn) {
        btn.disabled = loading;
      }
      if (text) {
        text.textContent = loading ? "Analyzing\u2026" : "Analyze";
      }
    }
    showUrlError(msg, category) {
      const el = document.getElementById("url-error-msg");
      if (el) {
        const isAuthReq = category === "AUTHENTICATION_REQUIRED" || 
          (typeof msg === "string" && (
            msg.includes("AUTHENTICATION_REQUIRED") || 
            msg.includes("ERR_AUTH_REQUIRED") || 
            msg.toLowerCase().includes("authentication") || 
            msg.toLowerCase().includes("cookie") || 
            msg.toLowerCase().includes("age-restricted") || 
            msg.toLowerCase().includes("confirm your age") || 
            msg.toLowerCase().includes("sign in") || 
            msg.toLowerCase().includes("inappropriate for some users") || 
            msg.toLowerCase().includes("subscription")
          ));
        if (isAuthReq) {
          el.innerHTML = `<div style="display:flex; flex-wrap:wrap; align-items:center; gap:8px; justify-content:center;"><span>${msg}</span><button type="button" id="btn-quick-cookie-guide" style="padding:3px 10px; font-size:11px; font-weight:700; background:var(--accent-primary, #10b981); color:#fff; border:none; border-radius:4px; cursor:pointer; display:inline-flex; align-items:center; gap:4px; box-shadow:0 2px 8px rgba(0,0,0,0.3);"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>Open Cookie Guide</button></div>`;
          const quickBtn = document.getElementById("btn-quick-cookie-guide");
          if (quickBtn) {
            quickBtn.onclick = (e) => {
              e.preventDefault();
              e.stopPropagation();
              const modalGuide = document.getElementById("modal-cookie-guide");
              if (modalGuide) {
                modalGuide.classList.add("active");
                modalGuide.style.display = "flex";
              }
            };
          }
        } else {
          el.textContent = msg;
        }
        el.style.display = "block";
      }
    }
    hideUrlError() {
      const el = document.getElementById("url-error-msg");
      if (el) {
        el.style.display = "none";
        el.textContent = "";
      }
    }
    renderMediaCard(meta) {
      this.currentMetadata = meta;
      if (meta.isUpcoming) {
        this.setVideoModesLocked(false);
        this.updateDropdownsForMode("image");
      } else {
        const isAudioOnly = meta.mediaType === "audio" || meta.isAudioOnly || (!meta.hasVideo && meta.hasAudio);
        if (isAudioOnly) {
          this.setVideoModesLocked(true, "Video options are disabled for this audio media");
          if (this.currentMode !== "audio-only" && this.currentMode !== "image") {
            this.updateDropdownsForMode("audio-only");
          }
        } else if (meta.mediaType === "image" || meta.isImage) {
          this.setVideoModesLocked(false);
          if (this.currentMode !== "image") this.updateDropdownsForMode("image");
        } else {
          this.setVideoModesLocked(false);
          if (this.currentMode === "audio-only") {
            this.updateDropdownsForMode("video-audio");
          }
        }
      }
      const cardSection = document.getElementById("media-card-section");
      if (!cardSection) return;
      cardSection.style.display = "block";
      const titleEl = document.getElementById("media-card-title");
      const uploaderEl = document.getElementById("media-uploader-name");
      const extractorEl = document.getElementById("media-extractor-tag");
      const thumbImg = document.getElementById("media-thumb-img");
      const durationTag = document.getElementById("media-duration-tag");
      const resTag = document.getElementById("media-resolutions-tag");
      if (resTag) resTag.textContent = "";
      const availableResolutions = meta.availableResolutions || [];
      const realResolutions = availableResolutions.filter((r) => r >= 144 && r <= 2160);
      if (titleEl) titleEl.textContent = meta.title;
      if (uploaderEl) uploaderEl.textContent = meta.uploader || meta.channel || "Unknown Creator";
      if (extractorEl) extractorEl.textContent = meta.extractor || "Web";
      if (thumbImg) {
        thumbImg.src = meta.thumbnail || "";
        thumbImg.onerror = () => {
          if (thumbImg.src && thumbImg.src.includes("maxresdefault.jpg")) {
            thumbImg.src = thumbImg.src.replace("maxresdefault.jpg", "hqdefault.jpg");
          }
        };
      }
      if (durationTag) {
        if (meta.isUpcoming) {
          durationTag.textContent = "UPCOMING";
        } else if (meta.mediaType === "image" || meta.isImage) {
          durationTag.textContent = "PHOTO";
        } else if (meta.duration && meta.duration > 0) {
          durationTag.textContent = this.formatDuration(meta.duration);
        } else {
          durationTag.textContent = (meta.mediaType === "audio") ? "AUDIO" : (meta.mediaType === "video" ? "VIDEO" : "00:00");
        }
      }
      if (meta.mediaType === "video" && (!meta.duration || meta.duration <= 0) && (meta.directStreamUrl || meta.url)) {
        try {
          const probeTarget = meta.directStreamUrl || (meta.url && meta.url.includes(".mp4") ? meta.url : "");
          if (probeTarget) {
            const probeVid = document.createElement("video");
            probeVid.preload = "metadata";
            probeVid.src = probeTarget;
            probeVid.onloadedmetadata = () => {
              if (probeVid.duration && !isNaN(probeVid.duration) && probeVid.duration > 0) {
                meta.duration = Math.round(probeVid.duration);
                if (durationTag) durationTag.textContent = this.formatDuration(meta.duration);
              }
            };
          }
        } catch (_) {}
      }
      if (meta.isUpcoming) {
        if (resTag) resTag.textContent = "⏳ Upcoming Premiere / Live Event • HD Cover Photo is Ready to Download";
        this.showHeaderToast("Upcoming broadcast detected. High-res Photo / Cover is ready to download.", 6000);
      } else {
        if (resTag) {
          if (realResolutions.length > 0) {
            resTag.textContent = `Available Stream Resolutions: ${realResolutions.map((r) => r + "p").join(", ")}`;
          } else {
            resTag.textContent = meta.resolution || (meta.mediaType === "audio" ? "Audio Stream" : "High Quality Stream");
          }
        }
        if (realResolutions.length > 0) {
          const profileSelect = document.getElementById("profile-select");
          if (profileSelect && this.currentMode !== "audio-only") {
            profileSelect.innerHTML = "";
            const has4K = realResolutions.some((r) => r >= 2160);
            const has1080 = realResolutions.includes(1080);
            const recommendedRes = has1080 ? 1080 : realResolutions.find((r) => r <= 1080) || realResolutions[realResolutions.length - 1];
            for (const res of realResolutions) {
              let label = "";
              const isRec = res === recommendedRes;
              if (res >= 2160) {
                label = `4K Ultra HD (2160p) \u2022 Studio Master (Slower \u2022 Largest File)`;
              } else if (res >= 1440) {
                label = `1440p Quad HD (2K) \u2022 High Quality (Moderate Speed)`;
              } else if (res >= 1080) {
                label = isRec ? `1080p Full HD \u2022 Recommended (Fast & Balanced)` : `1080p Full HD \u2022 Standard (Fast & Balanced)`;
              } else if (res >= 720) {
                label = isRec ? `720p HD \u2022 Recommended (Light File)` : `720p HD \u2022 Very Fast (Light File)`;
              } else if (res >= 480) {
                label = isRec ? `480p SD \u2022 Recommended (Standard Quality)` : `480p SD \u2022 Lightweight (Fast Download)`;
              } else {
                label = isRec ? `${res}p \u2022 Recommended (Small File)` : `${res}p \u2022 Super Fast / Instant (Small File)`;
              }
              const opt = new Option(label, `res-${res}`, isRec, isRec);
              profileSelect.appendChild(opt);
            }
            if (has4K) {
              this.showHeaderToast(
                "4K Ultra HD is available for this video! Auto-selected 1080p for fast editing. Select 4K in Quality Profile if you need master resolution.",
                7e3
              );
            }
            profileSelect.dispatchEvent(new Event("change"));
          }
        }
      }
      const carouselWrapper = document.getElementById("media-carousel-wrapper");
      const carouselTrack = document.getElementById("carousel-track");
      const carouselCount = document.getElementById("carousel-slide-count");
      const btnCarouselDownloadAll = document.getElementById("btn-carousel-download-all");
      if (meta.carouselSlides && meta.carouselSlides.length > 0) {
        if (carouselWrapper) carouselWrapper.style.display = "block";
        if (carouselCount) carouselCount.textContent = String(meta.carouselSlides.length);
        if (carouselTrack) {
          carouselTrack.innerHTML = "";
          meta.carouselSlides.forEach((slide) => {
            var _a;
            const slideCard = document.createElement("div");
            slideCard.style.cssText = "position: relative; flex: 0 0 85px; height: 110px; border-radius: 4px; overflow: hidden; background: #222; border: 1px solid #444; display: flex; flex-direction: column;";
            const isVid = slide.mediaType === "video";
            slideCard.innerHTML = `
            <div style="position: relative; flex: 1; overflow: hidden;">
              <img src="${slide.thumbnail || slide.url}" style="width: 100%; height: 100%; object-fit: cover;" onerror="this.src='data:image/svg+xml;utf8,<svg xmlns=\\'http://www.w3.org/2000/svg\\' width=\\'85\\' height=\\'80\\' fill=\\'%23333\\'><rect width=\\'100%\\' height=\\'100%\\'/></svg>'">
              <span style="position: absolute; top: 2px; left: 2px; background: rgba(0,0,0,0.7); font-size: 8px; padding: 1px 4px; border-radius: 3px; color: #fff;">#${slide.slideIndex} ${isVid ? "VIDEO" : "IMAGE"}</span>
            </div>
            <button class="btn btn-primary btn-sm btn-slide-import" style="border-radius: 0; font-size: 9px; padding: 3px 2px; text-align: center; width: 100%; cursor: pointer;" title="Download & Import Slide #${slide.slideIndex}">
              Import
            </button>
          `;
            (_a = slideCard.querySelector(".btn-slide-import")) == null ? void 0 : _a.addEventListener("click", () => {
              this.handleDirectSlideDownload(slide, meta);
            });
            carouselTrack.appendChild(slideCard);
          });
        }
        if (btnCarouselDownloadAll) {
          btnCarouselDownloadAll.onclick = () => {
            this.handleDownloadAllSlides(meta);
          };
        }
      } else {
        if (carouselWrapper) carouselWrapper.style.display = "none";
        if (carouselTrack) carouselTrack.innerHTML = "";
      }
    }
    handleDirectSlideDownload(slide, meta) {
      const isVid = slide.mediaType === "video";
      const profile = {
        type: isVid ? "video" : "image",
        presetId: isVid ? "video-1080p" : "best-available",
        label: isVid ? `Slide #${slide.slideIndex} Video` : `Slide #${slide.slideIndex} Photo`,
        container: isVid ? "mp4" : "jpg",
        remuxToMp4: isVid
      };
      serviceClient.startDownload(slide.url, profile, this.projectContext, void 0, {
        title: `${meta.title || "Slide"} - Slide ${slide.slideIndex}`,
        thumbnail: slide.thumbnail || slide.url
      });
    }
    handleDownloadAllSlides(meta) {
      if (!meta.carouselSlides || meta.carouselSlides.length === 0) return;
      for (const slide of meta.carouselSlides) {
        this.handleDirectSlideDownload(slide, meta);
      }
    }
    renderPlaylistModal(playlist) {
      var _a, _b, _c, _d, _e, _f;
      this.currentPlaylist = playlist;
      this.playlistCustomTargetDir = "";
      const isCloud = Boolean(
        playlist.isCloud || playlist.uploader && playlist.uploader.toLowerCase().includes("cloud") || playlist.url && (playlist.url.includes("drive.google.com") || playlist.url.includes("dropbox.com") || playlist.url.includes("onedrive") || playlist.url.includes("1drv.ms") || playlist.url.includes("mega.nz"))
      );
      const titleEl = document.getElementById("playlist-title");
      const countEl = document.getElementById("playlist-count");
      const uploaderEl = document.getElementById("playlist-uploader");
      const allCountEl = document.getElementById("playlist-all-count");
      const listContainer = document.getElementById("playlist-items-list");
      if (titleEl) titleEl.textContent = playlist.title;
      if (countEl) countEl.textContent = `${playlist.itemCount} items`;
      if (uploaderEl) uploaderEl.textContent = playlist.uploader || (isCloud ? "Cloud Storage" : "Creator");
      if (allCountEl) allCountEl.textContent = String(playlist.itemCount);
      const modalTitleHeader = document.getElementById("modal-playlist-title-header");
      if (modalTitleHeader) modalTitleHeader.textContent = isCloud ? "Cloud Folder Detected" : "Playlist Detected";
      const itemsHeaderLabel = document.getElementById("playlist-items-header-label");
      if (itemsHeaderLabel) itemsHeaderLabel.textContent = isCloud ? "Cloud Files" : "Playlist Items";
      const modeAllLabel = document.getElementById("playlist-mode-all-label");
      if (modeAllLabel) {
        modeAllLabel.innerHTML = isCloud ? `<strong>Download All Files</strong> in this folder (<span id="playlist-all-count">${playlist.itemCount}</span> files)` : `<strong>Download All Items</strong> in this playlist (<span id="playlist-all-count">${playlist.itemCount}</span> items)`;
      }
      const cloudStructureWrapper = document.getElementById("cloud-folder-structure-wrapper");
      if (cloudStructureWrapper) {
        cloudStructureWrapper.style.display = isCloud ? "block" : "none";
      }
      const folderNameInput = document.getElementById("playlist-folder-name");
      if (folderNameInput) {
        const plTitle = (playlist.title || "").trim();
        const defaultName = plTitle && plTitle !== "Playlist" && plTitle !== "Media Playlist" ? plTitle : playlist.uploader && !playlist.uploader.toLowerCase().includes("creator") ? `${playlist.uploader} - Playlist` : isCloud ? "Cloud Media" : "Media Playlist";
        folderNameInput.value = defaultName;
      }
      const destPathEl = document.getElementById("playlist-destination-path");
      if (destPathEl) {
        const projDir = (_a = this.projectContext) == null ? void 0 : _a.projectDirectory;
        if (projDir) {
          destPathEl.textContent = `${projDir}\\MediaFetch\\`;
        } else if ((((_c = (_b = this.settings) == null ? void 0 : _b.downloads) == null ? void 0 : _c.downloadLocationMode) === "custom" || ((_c = (_b = this.settings) == null ? void 0 : _b.downloads) == null ? void 0 : _c.downloadLocationMode) === "custom_flat") && ((_e = (_d = this.settings) == null ? void 0 : _d.downloads) == null ? void 0 : _e.customLocation)) {
          destPathEl.textContent = this.settings.downloads.customLocation;
        } else {
          destPathEl.textContent = "Active Adobe Project Folder";
        }
      }
      const modalZipCb = document.getElementById("playlist-zip-package-cb");
      const modalAutoImportCb = document.getElementById("playlist-auto-import-cb");
      const modalAutoImportLabel = modalAutoImportCb == null ? void 0 : modalAutoImportCb.closest("label");
      if (modalZipCb) {
        modalZipCb.checked = false;
        modalZipCb.onchange = () => {
          if (modalZipCb.checked) {
            if (modalAutoImportCb) {
              modalAutoImportCb.checked = false;
              modalAutoImportCb.disabled = true;
            }
            if (modalAutoImportLabel) {
              modalAutoImportLabel.style.opacity = "0.5";
              modalAutoImportLabel.title = "Cannot auto-import ZIP files into Adobe timeline";
            }
          } else {
            if (modalAutoImportCb) {
              modalAutoImportCb.disabled = false;
              modalAutoImportCb.checked = true;
            }
            if (modalAutoImportLabel) {
              modalAutoImportLabel.style.opacity = "1";
              modalAutoImportLabel.title = "";
            }
          }
        };
      }
      if (modalAutoImportCb) {
        modalAutoImportCb.checked = true;
        modalAutoImportCb.disabled = false;
        modalAutoImportCb.onchange = () => {
          if (modalAutoImportCb.checked && modalZipCb) {
            modalZipCb.checked = false;
          }
        };
      }
      if (modalAutoImportLabel) {
        modalAutoImportLabel.style.opacity = "1";
        modalAutoImportLabel.title = "";
      }
      const singleVideoWrapper = document.getElementById("playlist-single-video-wrapper");
      const hasSingleVideoInPlaylist = Boolean(
        playlist.url && (playlist.url.includes("v=") || playlist.url.includes("/watch/")) && playlist.url.includes("list=")
      );
      if (singleVideoWrapper) {
        singleVideoWrapper.style.display = hasSingleVideoInPlaylist ? "block" : "none";
      }
      const isSpotify = playlist.uploader && playlist.uploader.toLowerCase().includes("spotify") || playlist.title && playlist.title.toLowerCase().includes("spotify") || playlist.url && playlist.url.toLowerCase().includes("spotify") || playlist.items.some((it) => it.url && it.url.toLowerCase().includes("spotify"));
      const qualityPicker = document.getElementById("playlist-quality-picker");
      if (qualityPicker) {
        qualityPicker.innerHTML = "";
        if (isSpotify) {
          qualityPicker.appendChild(new Option("MP3 Studio Master (320 kbps High Quality Audio)", "audio_mp3_320", true, true));
          qualityPicker.appendChild(new Option("MP3 Standard (192 kbps Clean Audio)", "audio_mp3_192"));
          qualityPicker.appendChild(new Option("MP3 Data Saver (128 kbps Low Compressed)", "audio_mp3_128"));
          qualityPicker.appendChild(new Option("Lossless WAV (48kHz Uncompressed Audio)", "audio_wav"));
          qualityPicker.appendChild(new Option("High-Res Album Cover Art", "image_cover"));
        } else {
          let maxKnownHeight = 0;
          let hasKnownHeight = false;
          for (const it of playlist.items) {
            const h = it.height || it.resolution || 0;
            if (typeof h === "number" && h > 0) {
              hasKnownHeight = true;
              if (h > maxKnownHeight) maxKnownHeight = h;
            }
          }
          const isSub1080Only = hasKnownHeight && maxKnownHeight > 0 && maxKnownHeight < 1080;
          const recQuality = isSub1080Only ? maxKnownHeight <= 480 ? "480p" : "720p" : "1080p";
          if (isCloud) {
            qualityPicker.appendChild(new Option(recQuality === "1080p" ? "1080p Full HD Video / Native Files \u2022 Recommended" : "1080p Full HD Video / Native Files", "1080p", recQuality === "1080p", recQuality === "1080p"));
            qualityPicker.appendChild(new Option("4K Ultra HD Video (Master Quality)", "4k"));
            qualityPicker.appendChild(new Option(recQuality === "720p" ? "720p HD Video \u2022 Recommended" : "720p HD Video \u2022 High Speed", "720p", recQuality === "720p", recQuality === "720p"));
            qualityPicker.appendChild(new Option(recQuality === "480p" ? "480p SD Video \u2022 Recommended" : "480p SD Video \u2022 Fast", "480p", recQuality === "480p", recQuality === "480p"));
            qualityPicker.appendChild(new Option("MP3 Studio Master (320 kbps Audio)", "audio_mp3_320"));
            qualityPicker.appendChild(new Option("Lossless WAV (48kHz Uncompressed Audio)", "audio_wav"));
          } else {
            qualityPicker.appendChild(new Option(recQuality === "1080p" ? "1080p Full HD Video \u2022 Recommended (Fast & Balanced)" : "1080p Full HD Video \u2022 Standard (Fast & Balanced)", "1080p", recQuality === "1080p", recQuality === "1080p"));
            qualityPicker.appendChild(new Option("4K Ultra HD Video (2160p) \u2022 Studio Quality (Slower)", "4k"));
            qualityPicker.appendChild(new Option(recQuality === "720p" ? "720p HD Video \u2022 Recommended (Light File)" : "720p HD Video \u2022 High Speed (Light File)", "720p", recQuality === "720p", recQuality === "720p"));
            qualityPicker.appendChild(new Option(recQuality === "480p" ? "480p SD Video \u2022 Recommended (Small File)" : "480p Standard Definition \u2022 Fast", "480p", recQuality === "480p", recQuality === "480p"));
            qualityPicker.appendChild(new Option("MP3 Studio Master (320 kbps Audio)", "audio_mp3_320"));
            qualityPicker.appendChild(new Option("MP3 Data Saver (128 kbps Audio)", "audio_mp3_128"));
            qualityPicker.appendChild(new Option("Lossless WAV (48kHz Uncompressed Audio)", "audio_wav"));
            qualityPicker.appendChild(new Option("Video Cover Art / Thumbnail", "image_cover"));
          }
        }
      }
      if (listContainer) {
        listContainer.innerHTML = "";
        let targetVideoId = null;
        if (playlist.url) {
          try {
            const parsedUrl = new URL(playlist.url);
            targetVideoId = parsedUrl.searchParams.get("v");
          } catch (_) {
          }
          if (!targetVideoId) {
            const vMatch = playlist.url.match(/(?:v=|\/watch\/|\/embed\/|youtu\.be\/)([a-zA-Z0-9_-]{11})/);
            if (vMatch) targetVideoId = vMatch[1];
          }
        }
        const hasMatchingSong = Boolean(
          targetVideoId && playlist.items.some((it) => {
            return it.id && (it.id === targetVideoId || String(it.id).includes(targetVideoId)) || it.url && (it.url.includes(`v=${targetVideoId}`) || it.url.includes(targetVideoId));
          })
        );
        for (const it of playlist.items) {
          const row = document.createElement("div");
          row.className = "playlist-item-row";
          row.style.cssText = "display:flex; align-items:center; gap:6px; font-size:11px; padding:3px 4px; border-bottom:1px solid var(--border-subtle);";
          // Determine media type (image, audio, or video)
          const rawType = ((it.type || it.mediaType || "").toLowerCase());
          const urlStr = String(it.url || it.downloadTarget || it.directStreamUrl || "");
          const titleStr = String(it.title || "");

          let itemType = "video";
          if (
            rawType === "image" || rawType === "photo" || it.isImage ||
            /\.(jpe?g|png|webp|gif|bmp|svg|avif)($|\?)/i.test(urlStr) ||
            /\.(jpe?g|png|webp|gif|bmp|svg|avif)($|\?)/i.test(titleStr) ||
            /(?:image|photo|wallpaper|artwork)/i.test(it.resolution || "") ||
            playlist.isPinterest
          ) {
            itemType = "image";
          } else if (
            rawType === "audio" || it.isAudio ||
            isSpotify || playlist.isAppleMusic ||
            /\.(mp3|wav|m4a|aac|flac|ogg|opus|aiff)($|\?)/i.test(urlStr) ||
            /\.(mp3|wav|m4a|aac|flac|ogg|opus|aiff)($|\?)/i.test(titleStr) ||
            urlStr.includes("spotify.com") || urlStr.includes("music.apple.com") || urlStr.includes("p.scdn.co")
          ) {
            itemType = "audio";
          } else {
            itemType = "video";
          }

          let durationBadge = "";
          if (it.duration && it.duration > 0) {
            durationBadge = this.formatDuration(it.duration);
          } else if (itemType === "image") {
            durationBadge = "PHOTO";
          } else {
            const extMatch = it.title.match(/\.([0-9a-z]+)$/i);
            durationBadge = extMatch ? extMatch[1].toUpperCase() : isCloud ? "CLOUD FILE" : "";
          }

          const isCurrentSong = Boolean(
            hasMatchingSong && targetVideoId && (it.id && (it.id === targetVideoId || String(it.id).includes(targetVideoId)) || it.url && (it.url.includes(`v=${targetVideoId}`) || it.url.includes(targetVideoId)))
          );
          const isChecked = hasMatchingSong ? isCurrentSong : true;
          const currentSongBadge = isCurrentSong ? '<span style="color:#0a84ff; font-weight:700; font-size:9.5px; background:rgba(10,132,255,0.18); border:1px solid rgba(10,132,255,0.35); padding:1px 5px; border-radius:3px; white-space:nowrap;">Current Video</span>' : "";

          let typeBadge = "";
          if (itemType === "image") {
            typeBadge = '<span style="color:#00e5c9; font-weight:800; font-size:9.5px; background:rgba(0,229,201,0.15); border:1px solid rgba(0,229,201,0.4); padding:1px 5px; border-radius:3px; white-space:nowrap; letter-spacing:0.5px;">IMG</span>';
          } else if (itemType === "audio") {
            typeBadge = '<span style="color:#a855f7; font-weight:800; font-size:9.5px; background:rgba(168,85,247,0.15); border:1px solid rgba(168,85,247,0.4); padding:1px 5px; border-radius:3px; white-space:nowrap; letter-spacing:0.5px;">AUD</span>';
          } else {
            typeBadge = '<span style="color:#3b82f6; font-weight:800; font-size:9.5px; background:rgba(59,130,246,0.15); border:1px solid rgba(59,130,246,0.4); padding:1px 5px; border-radius:3px; white-space:nowrap; letter-spacing:0.5px;">VID</span>';
          }

          row.innerHTML = `
          <input type="checkbox" class="playlist-checkbox" data-url="${it.url}" data-title="${it.title.replace(/"/g, "&quot;")}" data-thumb="${it.thumbnail || ""}" data-dur="${it.duration || 0}" data-sub="${it.subFolderName || ""}" data-query="${it.downloadQuery || ""}" data-uploader="${it.uploader || it.channel || ""}" data-type="${itemType}" ${isChecked ? "checked" : ""} style="cursor:pointer;">
          <span style="color:var(--text-muted); font-size:10px; width:20px;">#${it.index}</span>
          ${typeBadge}
          <span style="flex:1; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; cursor:pointer;" class="playlist-item-title" title="${it.title}">${it.title}</span>
          ${currentSongBadge}
          ${durationBadge ? `<span style="color:var(--text-muted); font-size:9.5px; background:rgba(255,255,255,0.06); padding:1px 5px; border-radius:3px; white-space:nowrap;">${durationBadge}</span>` : ""}
          <button type="button" class="btn-playlist-preview" title="Preview in player" style="background:rgba(255,255,255,0.08); border:1px solid rgba(255,255,255,0.18); color:#e0e0e0; border-radius:4px; padding:2px 6px; cursor:pointer; font-size:10px; display:inline-flex; align-items:center; gap:3px;">
            <svg width="9" height="9" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg> Preview
          </button>
        `;
          const cb = row.querySelector(".playlist-checkbox");
          cb == null ? void 0 : cb.addEventListener("change", () => this.updatePlaylistSelectedCount());
          const titleSpan = row.querySelector(".playlist-item-title");
          titleSpan == null ? void 0 : titleSpan.addEventListener("click", () => {
            if (cb) {
              cb.checked = !cb.checked;
              this.updatePlaylistSelectedCount();
            }
          });
          const previewBtn = row.querySelector(".btn-playlist-preview");
          previewBtn == null ? void 0 : previewBtn.addEventListener("click", (e) => {
            e.preventDefault();
            e.stopPropagation();
            const streamTarget = it.directStreamUrl || it.audioPreviewUrl || it.downloadTarget || it.url;
            const itemAsMeta = {
              id: it.id || "pl_" + Date.now(),
              url: it.url,
              title: it.title,
              thumbnail: it.thumbnail,
              duration: it.duration || 0,
              uploader: it.uploader || it.channel || playlist.uploader || "Creator",
              mediaType: itemType,
              type: itemType,
              audioPreviewUrl: it.audioPreviewUrl || (itemType === 'audio' ? streamTarget : ''),
              embedUrl: it.embedUrl || "",
              directStreamUrl: streamTarget,
              downloadTarget: it.downloadTarget || it.url,
              formats: it.formats || []
            };
            this.openMediaPreview(itemAsMeta);
          });
          listContainer.appendChild(row);
        }
        if (hasMatchingSong) {
          const radioSelected = document.querySelector('input[name="playlist-mode"][value="selected"]');
          if (radioSelected) radioSelected.checked = true;
          const itemsWrapper = document.getElementById("playlist-items-wrapper");
          if (itemsWrapper) itemsWrapper.style.display = "block";
        }
      }
      this.updatePlaylistSelectedCount();
      this.openModal("modal-playlist");
    }
    updatePlaylistSelectedCount() {
      const checked = document.querySelectorAll(".playlist-checkbox:checked");
      const selCountEl = document.getElementById("playlist-selected-count");
      if (selCountEl) selCountEl.textContent = String(checked.length);
      const radioSelCount = document.getElementById("playlist-selected-radio-count");
      if (radioSelCount) radioSelCount.textContent = String(checked.length);
    }
    async handlePlaylistDownloadSubmit() {
      var _a, _b, _c, _d, _e, _f, _g, _h;
      if (!this.currentPlaylist) return;
      if (typeof ((_a = window.MediaFetchLicense) == null ? void 0 : _a.isAuthorized) === "function") {
        if (!window.MediaFetchLicense.isAuthorized()) {
          (_c = (_b = window.MediaFetchLicense).showModal) == null ? void 0 : _c.call(_b, "A valid commercial license is required to download media.");
          return;
        }
      }
      const qualityPicker = document.getElementById("playlist-quality-picker");
      const chosenQuality = (qualityPicker == null ? void 0 : qualityPicker.value) || "1080p";
      let profileType = "video";
      let selectedPresetId = "video-1080p";
      let container = "mp4";
      let label = "1080p Full HD Video (Batch)";
      if (chosenQuality === "4k") {
        profileType = "video";
        selectedPresetId = "video-4k";
        container = "mp4";
        label = "4K Ultra HD Video (Batch)";
      } else if (chosenQuality === "720p") {
        profileType = "video";
        selectedPresetId = "video-720p";
        container = "mp4";
        label = "720p HD Video (Batch)";
      } else if (chosenQuality === "480p") {
        profileType = "video";
        selectedPresetId = "video-480p";
        container = "mp4";
        label = "480p SD Video (Batch)";
      } else if (chosenQuality === "audio_mp3_320") {
        profileType = "audio";
        selectedPresetId = "audio-mp3-320";
        container = "mp3";
        label = "MP3 Studio Master 320kbps (Batch)";
      } else if (chosenQuality === "audio_mp3_192") {
        profileType = "audio";
        selectedPresetId = "audio-mp3-192";
        container = "mp3";
        label = "MP3 Standard 192kbps (Batch)";
      } else if (chosenQuality === "audio_mp3_128") {
        profileType = "audio";
        selectedPresetId = "audio-mp3-128";
        container = "mp3";
        label = "MP3 Data Saver 128kbps (Batch)";
      } else if (chosenQuality === "audio_wav") {
        profileType = "audio";
        selectedPresetId = "audio-wav";
        container = "wav";
        label = "Lossless WAV Audio (Batch)";
      } else if (chosenQuality === "image_cover") {
        profileType = "image";
        selectedPresetId = "image-orig";
        container = "jpg";
        label = "Cover Art (Batch)";
      } else {
        profileType = "video";
        selectedPresetId = "video-1080p";
        container = "mp4";
        label = "1080p Full HD Video (Batch)";
      }
      const profile = {
        type: profileType,
        presetId: selectedPresetId,
        label,
        container,
        remuxToMp4: container === "mp4"
      };
      const mode = ((_d = document.querySelector('input[name="playlist-mode"]:checked')) == null ? void 0 : _d.value) || "all";
      let selectedItems = [];
      if (mode === "single") {
        const first = this.currentPlaylist.items[0];
        if (first) {
          selectedItems = [{
            url: first.url,
            title: first.title,
            thumbnail: first.thumbnail,
            duration: first.duration,
            subFolderName: first.subFolderName,
            downloadQuery: first.downloadQuery,
            uploader: first.uploader || first.channel
          }];
        }
      } else {
        document.querySelectorAll(".playlist-checkbox:checked").forEach((cb) => {
          const el = cb;
          const itType = el.getAttribute("data-type") || void 0;
          selectedItems.push({
            url: el.getAttribute("data-url") || "",
            title: el.getAttribute("data-title") || "Video",
            thumbnail: el.getAttribute("data-thumb") || void 0,
            duration: parseFloat(el.getAttribute("data-dur") || "0") || void 0,
            subFolderName: el.getAttribute("data-sub") || void 0,
            downloadQuery: el.getAttribute("data-query") || void 0,
            uploader: el.getAttribute("data-uploader") || void 0,
            type: itType,
            mediaType: itType
          });
        });
      }
      if (selectedItems.length === 0) {
        alert("Please select at least one item to download.");
        return;
      }
      const isCloud = Boolean(
        this.currentPlaylist.isCloud || this.currentPlaylist.uploader && this.currentPlaylist.uploader.toLowerCase().includes("cloud") || this.currentPlaylist.url && (this.currentPlaylist.url.includes("drive.google.com") || this.currentPlaylist.url.includes("dropbox.com") || this.currentPlaylist.url.includes("onedrive") || this.currentPlaylist.url.includes("1drv.ms") || this.currentPlaylist.url.includes("mega.nz"))
      );
      const folderNameInput = document.getElementById("playlist-folder-name");
      const customFolderName = ((_e = folderNameInput == null ? void 0 : folderNameInput.value) == null ? void 0 : _e.trim()) || this.currentPlaylist.title || (isCloud ? "Cloud Media" : "Media Playlist");
      const structureMode = (_f = document.querySelector('input[name="cloud-structure-mode"]:checked')) == null ? void 0 : _f.value;
      const preserveSubfolders = structureMode !== "flatten";
      const zipPackage = ((_g = document.getElementById("playlist-zip-package-cb")) == null ? void 0 : _g.checked) || false;
      const autoImport = zipPackage ? false : ((_h = document.getElementById("playlist-auto-import-cb")) == null ? void 0 : _h.checked) !== false;
      try {
        this.projectContext = await hostAdapter.getProjectContext();
      } catch (_) {
      }
      serviceClient.startPlaylistDownload(
        selectedItems,
        profile,
        this.projectContext,
        this.playlistCustomTargetDir || void 0,
        {
          customFolderName,
          preserveSubfolders,
          autoImport,
          zipPackage,
          playlistTitle: this.currentPlaylist.title,
          isCloud
        }
      );
      this.closeModal("modal-playlist");
      const input = document.getElementById("url-input");
      if (input) input.value = "";
      this.showHeaderToast(`Added ${selectedItems.length} items to download queue`, 5e3);
    }
    async handleDownloadClick() {
      var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n;
      try {
        this.projectContext = await hostAdapter.getProjectContext();
      } catch (_) {
      }
      if (typeof ((_a = window.MediaFetchLicense) == null ? void 0 : _a.isAuthorized) === "function") {
        if (!window.MediaFetchLicense.isAuthorized()) {
          (_c = (_b = window.MediaFetchLicense).showModal) == null ? void 0 : _c.call(_b, "A valid commercial license is required to download media.");
          return;
        }
      }
      const urlInput = document.getElementById("url-input");
      const rawInput = ((_d = urlInput == null ? void 0 : urlInput.value) == null ? void 0 : _d.trim()) || "";
      if (!rawInput) {
        this.showUrlError("Please enter or paste a media URL before downloading.");
        return;
      }
      const urls = rawInput.split(/[\r\n,\s]+/).map((u) => u.trim()).filter((u) => u.startsWith("http://") || u.startsWith("https://"));
      if (urls.length === 0) {
        this.showUrlError("Please enter a valid http/https URL.");
        return;
      }
      if (!this.isPro && urls.some((u) => this.isCloudUrl(u))) {
        this.showUrlError("Cloud links (Google Drive, Dropbox, OneDrive, Mega) are exclusive to MediaFetch Pro. Upgrade to MediaFetch Pro to download cloud storage files.");
        this.showHeaderToast("Cloud links are exclusive to MediaFetch Pro", 5e3);
        return;
      }
      const profileSelect = document.getElementById("profile-select");
      const formatSelect = document.getElementById("format-select");
      const selectedPresetId = (profileSelect == null ? void 0 : profileSelect.value) || "best-available";
      const rawFormatValue = ((formatSelect == null ? void 0 : formatSelect.value) || "").toLowerCase();
      const isExplicitVideoContainer = ["mp4", "mov", "webm", "mkv", "avi"].includes(rawFormatValue);
      const isExplicitAudioContainer = ["mp3", "wav", "m4a", "flac", "aac", "ogg"].includes(rawFormatValue);
      const isImageMode = this.currentMode === "image" || selectedPresetId.startsWith("image") || Boolean((_h = this.currentMetadata) == null ? void 0 : _h.isUpcoming);
      let profileType = isImageMode ? "image" : this.currentMode === "audio-only" || selectedPresetId.startsWith("audio") ? "audio" : this.currentMode === "video-only" ? "video-only" : "video";
      if ((_j = this.currentMetadata) == null ? void 0 : _j.isUpcoming) {
        profileType = "image";
        this.showHeaderToast("Downloading high-res cover thumbnail for upcoming broadcast...", 4e3);
      } else if (isExplicitVideoContainer) {
        if (profileType === "audio") {
          profileType = this.currentMode === "video-only" ? "video-only" : "video";
        }
      } else if (isExplicitAudioContainer && !isImageMode) {
        profileType = "audio";
      }
      const customFilenameInput = document.getElementById("custom-filename-input");
      const customFilename = ((_e = customFilenameInput == null ? void 0 : customFilenameInput.value) == null ? void 0 : _e.trim()) || void 0;
      const trimStartInput = document.getElementById("trim-start-input");
      const trimEndInput = document.getElementById("trim-end-input");
      const rawStart = ((_f = trimStartInput == null ? void 0 : trimStartInput.value) == null ? void 0 : _f.trim()) || void 0;
      const rawEnd = ((_g = trimEndInput == null ? void 0 : trimEndInput.value) == null ? void 0 : _g.trim()) || void 0;
      let timeRange;
      if (rawStart || rawEnd) {
        const sSec = this.parseTimeToSec(rawStart);
        const eSec = this.parseTimeToSec(rawEnd);
        const start = rawStart ? this.formatDuration(sSec) : "00:00:00";
        const end = rawEnd ? this.formatDuration(eSec) : void 0;
        timeRange = { start, end };
      }
      let container = rawFormatValue || (profileType === "audio" ? "mp3" : profileType === "image" ? "jpg" : "mp4");
      if (isExplicitVideoContainer) {
        container = rawFormatValue;
      } else if (selectedPresetId === "audio-wav" || rawFormatValue === "wav") {
        container = "wav";
      } else if (selectedPresetId === "audio-flac" || rawFormatValue === "flac") {
        container = "flac";
      } else if (selectedPresetId === "audio-m4a" || rawFormatValue === "m4a") {
        container = "m4a";
      } else if (selectedPresetId.startsWith("audio-mp3") || rawFormatValue === "mp3") {
        container = "mp3";
      }
      let explicitResolution;
      if (typeof selectedPresetId === "string" && selectedPresetId.startsWith("res-")) {
        const parsed = parseInt(selectedPresetId.replace("res-", ""), 10);
        if (!isNaN(parsed) && parsed > 0) explicitResolution = parsed;
      } else if (selectedPresetId === "video-4k") explicitResolution = 2160;
      else if (selectedPresetId === "video-1440p") explicitResolution = 1440;
      else if (selectedPresetId === "video-1080p") explicitResolution = 1080;
      else if (selectedPresetId === "video-720p") explicitResolution = 720;
      else if (selectedPresetId === "video-480p") explicitResolution = 480;
      else if (selectedPresetId === "video-360p") explicitResolution = 360;
      const baseProfile = {
        type: profileType,
        presetId: selectedPresetId,
        resolution: explicitResolution,
        label: ((_h = profileSelect == null ? void 0 : profileSelect.selectedOptions[0]) == null ? void 0 : _h.text) || (profileType === "audio" ? "Audio Download" : profileType === "video-only" ? "Video Only Download" : "Video Download"),
        container,
        remuxToMp4: container === "mp4",
        customFilename,
        timeRange
      };
      let targetDirectory = void 0;
      const modeInput = document.getElementById("setting-location-mode");
      const activeLocMode = (modeInput == null ? void 0 : modeInput.value) || ((_j = (_i = this.settings) == null ? void 0 : _i.downloads) == null ? void 0 : _j.downloadLocationMode) || "project";
      if (activeLocMode === "custom" || activeLocMode === "custom_flat") {
        const customInput = document.getElementById("setting-custom-location");
        const customPath = ((_k = customInput == null ? void 0 : customInput.value) == null ? void 0 : _k.trim()) || ((_n = (_m = (_l = this.settings) == null ? void 0 : _l.downloads) == null ? void 0 : _m.customLocation) == null ? void 0 : _n.trim());
        if (customPath) {
          targetDirectory = customPath;
        }
      }
      if (urls.length > 1) {
        for (const singleUrl of urls) {
          serviceClient.startDownload(singleUrl, { ...baseProfile }, this.projectContext, targetDirectory);
        }
        urlInput.value = "";
        this.closeCard();
        return;
      }
      const url = urls[0];
      const isMatchingMeta = Boolean(this.currentMetadata && (
        this.currentMetadata.url === url ||
        this.currentMetadata.webpage_url === url ||
        this.currentMetadata.id && url.includes(this.currentMetadata.id) ||
        url.replace(/https?:\/\/(www\.)?/, "").split("?")[0].replace(/\/$/, "") === (this.currentMetadata.url || "").replace(/https?:\/\/(www\.)?/, "").split("?")[0].replace(/\/$/, "")
      ));
      if (isMatchingMeta && this.currentMetadata) {
        if (this.currentMetadata.isPlaylist || this.currentMetadata.isCarousel || (this.currentMetadata.items && this.currentMetadata.items.length > 1) || (this.currentMetadata.carouselSlides && this.currentMetadata.carouselSlides.length > 1)) {
          const rawItems = this.currentMetadata.items || this.currentMetadata.carouselSlides || [];
          this.renderPlaylistModal({
            id: this.currentMetadata.id || "multi_" + Date.now(),
            url: this.currentMetadata.url || url,
            title: this.currentMetadata.title || "Multi-Media Project",
            uploader: this.currentMetadata.uploader || "Creator",
            itemCount: rawItems.length,
            items: rawItems.map((s, idx) => {
              var _a2, _b2;
              return {
                id: s.id || `item_${idx + 1}`,
                title: s.title || `${((_a2 = this.currentMetadata) == null ? void 0 : _a2.title) || "Item"} (${s.slideIndex || idx + 1})`,
                url: s.url,
                thumbnail: s.thumbnail || s.url,
                duration: s.duration || 0,
                downloadQuery: s.downloadQuery || s.url,
                downloadTarget: s.downloadTarget || s.url,
                directStreamUrl: s.directStreamUrl || s.url,
                type: s.type || s.mediaType || "video",
                mediaType: s.mediaType || s.type || "video",
                uploader: s.uploader || ((_b2 = this.currentMetadata) == null ? void 0 : _b2.uploader)
              };
            })
          });
          return;
        }
      } else {
        const isMatchingPlaylist = Boolean(this.currentPlaylist && (
          this.currentPlaylist.url === url ||
          this.currentPlaylist.webpage_url === url ||
          url.replace(/https?:\/\/(www\.)?/, "").split("?")[0].replace(/\/$/, "") === (this.currentPlaylist.url || "").replace(/https?:\/\/(www\.)?/, "").split("?")[0].replace(/\/$/, "")
        ));
        if (isMatchingPlaylist && this.currentPlaylist) {
          this.renderPlaylistModal(this.currentPlaylist);
          return;
        }
        if (this.isPlaylistUrl(url)) {
          this.setAnalysisLoading(true);
          if (url.includes("instagram.com/p/") || url.includes("instagram.com/reel/") || url.includes("instagram.com/reels/") || url.includes("threads.net/") || url.includes("threads.com/") || url.includes("behance.net/gallery/")) {
            serviceClient.analyzeUrl(url);
          } else {
            serviceClient.analyzePlaylist(url);
          }
          return;
        }
      }
      const validMeta = isMatchingMeta ? this.currentMetadata : null;
      const title = (validMeta == null ? void 0 : validMeta.title) || "";
      this.pendingDownloadParams = {
        url,
        profile: baseProfile,
        projectContext: this.projectContext,
        targetDirectory,
        metadata: validMeta ? {
          ...validMeta,
          title,
          thumbnail: validMeta.thumbnail,
          duration: validMeta.duration,
          downloadQuery: validMeta.downloadQuery,
          uploader: validMeta.uploader || validMeta.channel,
          directStreamUrl: validMeta.directStreamUrl,
          downloadTarget: validMeta.downloadTarget,
          directAudioUrl: validMeta.directAudioUrl,
          formats: validMeta.formats,
          platform: validMeta.platform,
          mediaType: validMeta.mediaType
        } : void 0
      };
      this.executePendingDownload();
    }
    executePendingDownload() {
      if (!this.pendingDownloadParams) return;
      serviceClient.startDownload(
        this.pendingDownloadParams.url,
        this.pendingDownloadParams.profile,
        this.pendingDownloadParams.projectContext,
        this.pendingDownloadParams.targetDirectory,
        this.pendingDownloadParams.metadata
      );
      this.pendingDownloadParams = null;
      const input = document.getElementById("url-input");
      if (input) input.value = "";
      const card = document.getElementById("media-card-section");
      if (card) card.style.display = "none";
      this.showHeaderToast("Added item to download queue", 4e3);
    }
    getVisibleQueue() {
      const isPro = window.__MF_EDITION__ === "pro" || window.location.pathname.includes(".pro") || document.title.includes("Pro");
      const myEdition = isPro ? "pro" : "standard";
      return (this.queue || []).filter((item) => {
        if (!item) return false;
        if (!item.edition) {
          return myEdition === "pro";
        }
        return item.edition === myEdition;
      });
    }
    renderQueue() {
      const container = document.getElementById("queue-container");
      const countEl = document.getElementById("queue-count");
      if (!container) return;
      const visibleItems = this.getVisibleQueue();
      if (countEl) countEl.textContent = String(visibleItems.length);
      if (visibleItems.length === 0) {
        container.innerHTML = '<div class="queue-empty-state">No active downloads. Paste a URL and click Download to start.</div>';
        return;
      }
      container.innerHTML = "";
      for (const item of visibleItems) {
        container.appendChild(this.createQueueItemElement(item));
      }
    }
    createQueueItemElement(item) {
      const el = document.createElement("div");
      el.className = "queue-item";
      el.id = `q-item-${item.id}`;
      el.setAttribute("data-status", item.status);
      const badgeClass = `badge-${item.status}`;
      const fillClass = item.status === "completed" ? "success" : item.status === "failed" ? "error" : "";
      const statsText = this.formatQueueItemStats(item);
      el.innerHTML = `
      <div class="queue-item-header">
        <span class="queue-item-title" title="${item.title}">${item.title}</span>
        <span class="queue-item-badge ${badgeClass}">${item.status}</span>
      </div>
      <div class="progress-bar-container">
        <div class="progress-bar-fill ${fillClass}" style="width: ${item.progress}%;"></div>
      </div>
      <div class="queue-item-stats">
        <span class="item-stats-text">${statsText}</span>
        <div class="queue-item-actions">
          ${this.renderItemActionButtons(item)}
        </div>
      </div>
    `;
      this.bindItemActionEvents(el, item);
      return el;
    }
    renderItemActionButtons(item) {
      if (item.status === "downloading" || item.status === "waiting") {
        return `
        <button class="btn btn-icon btn-sm btn-pause" title="Pause">${ICONS.PAUSE}</button>
        <button class="btn btn-icon btn-sm btn-cancel" title="Cancel">${ICONS.CLOSE}</button>
      `;
      } else if (item.status === "paused") {
        return `
        <button class="btn btn-icon btn-sm btn-resume" title="Resume">${ICONS.PLAY}</button>
        <button class="btn btn-icon btn-sm btn-cancel" title="Cancel">${ICONS.CLOSE}</button>
      `;
      } else if (item.status === "failed") {
        return `
        <button class="btn btn-icon btn-sm btn-retry" title="Retry">${ICONS.RETRY}</button>
        <button class="btn btn-icon btn-sm btn-cancel" title="Remove">${ICONS.CLOSE}</button>
      `;
      } else if (item.status === "completed") {
        return `
        <button class="btn btn-icon btn-sm btn-import" title="Import to Project Panel">${ICONS.PROJECT}</button>
        <button class="btn btn-icon btn-sm btn-reveal" title="Show in Folder">${ICONS.FOLDER}</button>
        <button class="btn btn-icon btn-sm btn-retry" title="Retry / Re-download">${ICONS.RETRY}</button>
      `;
      }
      return `<button class="btn btn-icon btn-sm btn-cancel" title="Remove">${ICONS.CLOSE}</button>`;
    }
    bindItemActionEvents(_el, _item) {
    }
    updateQueueItemDOM(item) {
      if (typeof window !== "undefined" && window.requestAnimationFrame) {
        window.requestAnimationFrame(() => this._applyQueueItemDOM(item));
      } else {
        this._applyQueueItemDOM(item);
      }
    }
    _applyQueueItemDOM(item) {
      const existing = document.getElementById(`q-item-${item.id}`);
      if (existing) {
        const title = existing.querySelector(".queue-item-title");
        const badge = existing.querySelector(".queue-item-badge");
        const fill = existing.querySelector(".progress-bar-fill");
        const stats = existing.querySelector(".item-stats-text");
        if (title && item.title) {
          title.textContent = item.title;
          title.title = item.title;
        }
        if (badge) {
          badge.className = `queue-item-badge badge-${item.status}`;
          badge.textContent = item.status;
        }
        if (fill) {
          fill.style.width = `${item.progress}%`;
          fill.className = `progress-bar-fill ${item.status === "completed" ? "success" : item.status === "failed" ? "error" : ""}`;
        }
        if (stats) {
          stats.textContent = this.formatQueueItemStats(item);
        }
        const prevStatus = existing.getAttribute("data-status");
        if (prevStatus !== item.status) {
          existing.setAttribute("data-status", item.status);
          const actions = existing.querySelector(".queue-item-actions");
          if (actions) {
            actions.innerHTML = this.renderItemActionButtons(item);
            this.bindItemActionEvents(existing, item);
          }
        }
      } else {
        this.renderQueue();
      }
    }
    formatQueueItemStats(item) {
      if (!item) return "";
      if (item.status !== "downloading") {
        return item.stageDescription || (item.status ? item.status.toUpperCase() : "");
      }
      const hasBytes = typeof item.downloadedBytes === "number" && item.downloadedBytes > 0;
      const downMB = hasBytes ? (item.downloadedBytes / (1024 * 1024)).toFixed(1) : "";
      const totalMB = (typeof item.totalBytes === "number" && item.totalBytes > 0) ? (item.totalBytes / (1024 * 1024)).toFixed(1) + " MB" : (hasBytes ? "…" : "");
      const speed = item.speed ? `${item.speed}` : "";
      const eta = item.eta ? ` \xB7 ETA ${item.eta}` : "";
      const isPostProcess = item.stageDescription && (
        item.stageDescription.toLowerCase().includes("merg") ||
        item.stageDescription.toLowerCase().includes("remux") ||
        item.stageDescription.toLowerCase().includes("transcod") ||
        item.stageDescription.toLowerCase().includes("almost ready") ||
        item.stageDescription.toLowerCase().includes("ffmpeg") ||
        item.stageDescription.toLowerCase().includes("finaliz") ||
        item.stageDescription.toLowerCase().includes("optimi")
      );
      if (isPostProcess) {
        return `${item.stageDescription}${eta}`;
      }
      if (hasBytes) {
        const mbStr = totalMB ? `${downMB} MB / ${totalMB}` : `${downMB} MB`;
        return `${mbStr}${speed ? ` \xB7 ${speed}` : ""}${eta}`;
      }
      if (speed) {
        return `Downloading \xB7 ${speed}${eta}`;
      }
      const pct = (typeof item.progress === "number" && item.progress > 0) ? ` (${Math.round(item.progress)}%)` : "";
      return `${item.stageDescription || "Connecting to media server..."}${pct}`;
    }
    renderDiagnostics(diag) {
      var _a, _b, _c, _d;
      const osEl = document.getElementById("diag-os");
      const nodeEl = document.getElementById("diag-node");
      const adobeEl = document.getElementById("diag-adobe");
      const portEl = document.getElementById("diag-port");
      const ytdlpEl = document.getElementById("diag-ytdlp");
      const ffmpegEl = document.getElementById("diag-ffmpeg");
      const logsBox = document.getElementById("diag-logs-box");
      if (osEl) osEl.textContent = diag.os;
      if (nodeEl) nodeEl.textContent = diag.nodeVersion;
      if (adobeEl) adobeEl.textContent = `${diag.adobeApp || "Adobe App"} (${diag.adobeVersion || "Auto"})`;
      if (portEl) portEl.textContent = String(diag.servicePort);
      if (ytdlpEl) ytdlpEl.textContent = diag.ytdlp.available ? `v${diag.ytdlp.version || "OK"}` : "Missing";
      if (ffmpegEl) ffmpegEl.textContent = diag.ffmpeg.available ? `v${diag.ffmpeg.version || "OK"}` : "Missing";
      const engineYtDlp = document.getElementById("engine-ytdlp-ver");
      const engineFfmpeg = document.getElementById("engine-ffmpeg-ver");
      if (engineYtDlp) {
        engineYtDlp.textContent = ((_a = diag.ytdlp) == null ? void 0 : _a.available) ? `v${diag.ytdlp.version || "OK"}` : "Missing / Not Installed";
        engineYtDlp.style.color = ((_b = diag.ytdlp) == null ? void 0 : _b.available) ? "var(--status-success, #22c55e)" : "var(--status-error, #ef4444)";
      }
      if (engineFfmpeg) {
        engineFfmpeg.textContent = ((_c = diag.ffmpeg) == null ? void 0 : _c.available) ? `v${diag.ffmpeg.version || "OK"}` : "Missing / Not Installed";
        engineFfmpeg.style.color = ((_d = diag.ffmpeg) == null ? void 0 : _d.available) ? "var(--status-success, #22c55e)" : "var(--status-error, #ef4444)";
      }
      fetch(`http://127.0.0.1:${diag.servicePort}/api/diagnostics/logs`).then((r) => r.json()).then((data) => {
        if (logsBox && Array.isArray(data.logs)) {
          logsBox.textContent = data.logs.join("\n");
          logsBox.scrollTop = logsBox.scrollHeight;
        }
      }).catch(() => {
      });
    }
    updateSetupWizardStatus(diag) {
      const ytdlpStat = document.getElementById("setup-status-ytdlp");
      const ffmpegStat = document.getElementById("setup-status-ffmpeg");
      if (ytdlpStat) {
        ytdlpStat.textContent = diag.ytdlp.available ? `Ready (v${diag.ytdlp.version || ""})` : "Missing";
        ytdlpStat.style.color = diag.ytdlp.available ? "var(--status-success)" : "var(--status-error)";
      }
      if (ffmpegStat) {
        ffmpegStat.textContent = diag.ffmpeg.available ? `Ready (${diag.ffmpeg.version || ""})` : "Missing";
        ffmpegStat.style.color = diag.ffmpeg.available ? "var(--status-success)" : "var(--status-error)";
      }
      const installBtn = document.getElementById("btn-setup-install-all");
      if (installBtn) {
        if (diag.ytdlp.available && diag.ffmpeg.available) {
          installBtn.textContent = "All Components Ready";
          installBtn.disabled = true;
        } else {
          installBtn.textContent = "Install Missing Components";
          installBtn.disabled = false;
        }
      }
    }
    showInstallProgress(payload) {
      const progRow = document.getElementById("setup-progress-row");
      const progLabel = document.getElementById("setup-progress-label");
      const progFill = document.getElementById("setup-progress-fill");
      if (progRow) progRow.style.display = "flex";
      if (progLabel) progLabel.textContent = `[${payload.name}] ${payload.message}`;
      if (progFill) progFill.style.width = `${payload.progress}%`;
      const engineStatus = document.getElementById("engine-update-status");
      if (engineStatus) {
        engineStatus.style.display = "block";
        engineStatus.style.color = "var(--text-secondary, #aaa)";
        engineStatus.textContent = payload.message || "Updating yt-dlp engine...";
      }
    }
    handleInstallResult(payload) {
      const progLabel = document.getElementById("setup-progress-label");
      if (progLabel) {
        if (payload.success) {
          progLabel.textContent = `${payload.name} installation completed successfully.`;
        } else {
          progLabel.textContent = `Failed to install ${payload.name}: ${payload.error}`;
        }
      }
      const btnUpdate = document.getElementById("btn-update-ytdlp");
      if (btnUpdate) {
        btnUpdate.disabled = false;
        btnUpdate.textContent = "Check & Update yt-dlp";
      }
      const engineStatus = document.getElementById("engine-update-status");
      if (engineStatus) {
        engineStatus.style.display = "block";
        if (payload.success) {
          engineStatus.style.color = "var(--status-success, #22c55e)";
          engineStatus.textContent = payload.message || "yt-dlp is up to date!";
        } else {
          engineStatus.style.color = "var(--status-error, #ef4444)";
          engineStatus.textContent = `Update notice: ${payload.error || "Check network connection"}`;
        }
      }
      serviceClient.runSystemCheck();
      serviceClient.getDiagnostics();
    }
    updateDownloadLocationModeUI() {
      var _a;
      const modeSel = document.getElementById("setting-location-mode");
      const customLoc = document.getElementById("setting-custom-location");
      const customBrowseBtn = document.getElementById("btn-browse-custom-location");
      const customGroup = document.getElementById("setting-custom-location-group") || ((_a = customLoc == null ? void 0 : customLoc.parentElement) == null ? void 0 : _a.parentElement);
      const isCustom = (modeSel == null ? void 0 : modeSel.value) === "custom" || (modeSel == null ? void 0 : modeSel.value) === "custom_flat";
      if (customLoc) customLoc.disabled = !isCustom;
      if (customBrowseBtn) customBrowseBtn.disabled = !isCustom;
      if (customGroup) {
        customGroup.style.display = isCustom ? "block" : "none";
        customGroup.style.opacity = isCustom ? "1" : "0.45";
        customGroup.style.pointerEvents = isCustom ? "auto" : "none";
      }
    }
    populateSettingsForm(s) {
      const themeSel = document.getElementById("setting-theme");
      const autoImportChk = document.getElementById("setting-auto-import");
      const confirmChk = document.getElementById("setting-confirm-overwrite");
      const cleanupChk = document.getElementById("setting-auto-cleanup");
      const modeSel = document.getElementById("setting-location-mode");
      const playlistSel = document.getElementById("setting-playlist-behavior");
      const customLoc = document.getElementById("setting-custom-location");
      const concSel = document.getElementById("setting-concurrency");
      const retriesSel = document.getElementById("setting-max-retries");
      const timeoutInput = document.getElementById("setting-timeout");
      const debugChk = document.getElementById("setting-debug-logging");
      const cookiesSel = document.getElementById("setting-browser-cookies");
      if (themeSel) themeSel.value = s.general.theme;
      if (autoImportChk) autoImportChk.checked = s.general.autoImportToProject ?? true;
      if (confirmChk) confirmChk.checked = s.general.confirmOverwrite;
      if (cleanupChk) cleanupChk.checked = s.general.autoCleanupTemp;
      if (modeSel) modeSel.value = s.downloads.downloadLocationMode;
      if (playlistSel) playlistSel.value = s.downloads.playlistBehavior || "ask";
      if (customLoc) customLoc.value = s.downloads.customLocation;
      if (concSel) concSel.value = String(s.downloads.concurrency);
      if (retriesSel) retriesSel.value = String(s.downloads.maxRetries);
      if (timeoutInput) timeoutInput.value = String(s.advanced.networkTimeoutMs);
      if (debugChk) debugChk.checked = s.advanced.debugLogging;
      if (cookiesSel) cookiesSel.value = s.engine.browserCookies || "none";
      const clipFormatSel = document.getElementById("setting-clipboard-format");
      const headerClipSel = document.getElementById("select-clipboard-format");
      const curClipFormat = ((_a = s.downloads) == null ? void 0 : _a.clipboardFormat) || localStorage.getItem("mf_clipboard_img_format") || "png";
      if (clipFormatSel) clipFormatSel.value = curClipFormat;
      if (headerClipSel) headerClipSel.value = curClipFormat;
      this.updateDownloadLocationModeUI();
    }
    saveSettingsFromForm() {
      var _a;
      const themeSel = document.getElementById("setting-theme");
      const autoImportChk = document.getElementById("setting-auto-import");
      const confirmChk = document.getElementById("setting-confirm-overwrite");
      const cleanupChk = document.getElementById("setting-auto-cleanup");
      const modeSel = document.getElementById("setting-location-mode");
      const playlistSel = document.getElementById("setting-playlist-behavior");
      const customLoc = document.getElementById("setting-custom-location");
      const concSel = document.getElementById("setting-concurrency");
      const retriesSel = document.getElementById("setting-max-retries");
      const timeoutInput = document.getElementById("setting-timeout");
      const debugChk = document.getElementById("setting-debug-logging");
      const cookiesSel = document.getElementById("setting-browser-cookies");
      const updated = {
        general: {
          theme: (themeSel == null ? void 0 : themeSel.value) || "host",
          customThemeColor: localStorage.getItem('mediafetch_custom_theme_color') || "",
          notifications: true,
          confirmOverwrite: (confirmChk == null ? void 0 : confirmChk.checked) ?? true,
          autoCleanupTemp: (cleanupChk == null ? void 0 : cleanupChk.checked) ?? true,
          autoImportToProject: (autoImportChk == null ? void 0 : autoImportChk.checked) ?? true
        },
        downloads: {
          defaultPreset: "best-available",
          downloadLocationMode: (modeSel == null ? void 0 : modeSel.value) || "project",
          customLocation: (customLoc == null ? void 0 : customLoc.value) || "",
          concurrency: parseInt((concSel == null ? void 0 : concSel.value) || "2", 10),
          maxRetries: parseInt((retriesSel == null ? void 0 : retriesSel.value) || "3", 10),
          retryDelayMs: 2e3,
          filenamePattern: "%(title)s.%(ext)s",
          playlistBehavior: (playlistSel == null ? void 0 : playlistSel.value) || "ask",
          clipboardFormat: (() => {
            const el = document.getElementById("setting-clipboard-format");
            const val = (el == null ? void 0 : el.value) || localStorage.getItem("mf_clipboard_img_format") || "png";
            localStorage.setItem("mf_clipboard_img_format", val);
            const hf = document.getElementById("select-clipboard-format");
            if (hf) hf.value = val;
            return val;
          })()
        },
        engine: {
          autoUpdate: true,
          browserCookies: (cookiesSel == null ? void 0 : cookiesSel.value) || "none"
        },
        advanced: {
          networkTimeoutMs: parseInt((timeoutInput == null ? void 0 : timeoutInput.value) || "30000", 10),
          debugLogging: (debugChk == null ? void 0 : debugChk.checked) ?? false
        }
      };
      serviceClient.updateSettings(updated);
      if (typeof window.Settings !== "undefined") {
        const pexelsInput = document.getElementById("setting-studio-pexels-key");
        const pixabayInput = document.getElementById("setting-studio-pixabay-key");
        const unsplashInput = document.getElementById("setting-studio-unsplash-key");
        const giphyInput = document.getElementById("setting-studio-giphy-key");
        window.Settings.save({
          downloadFolder: ((modeSel == null ? void 0 : modeSel.value) === "custom" || (modeSel == null ? void 0 : modeSel.value) === "custom_flat") ? ((_a = customLoc == null ? void 0 : customLoc.value) == null ? void 0 : _a.trim()) || "" : "",
          downloadLocationMode: (modeSel == null ? void 0 : modeSel.value) || "project",
          pexelsApiKey: pexelsInput ? pexelsInput.value.trim() : "",
          pixabayApiKey: pixabayInput ? pixabayInput.value.trim() : "",
          unsplashApiKey: unsplashInput ? unsplashInput.value.trim() : "",
          giphyApiKey: giphyInput ? giphyInput.value.trim() : "",
          glassTheme: localStorage.getItem("mediafetch_glass_theme") || "frosted",
          customThemeColor: localStorage.getItem("mediafetch_custom_theme_color") || "#0A84FF",
          ambientEnabled: localStorage.getItem("mediafetch_ambient_enabled") === "true",
          ambientPreset: localStorage.getItem("mediafetch_ambient_preset") || "crimson",
          ambientC1: localStorage.getItem("mediafetch_ambient_c1") || "#0A84FF",
          ambientC2: localStorage.getItem("mediafetch_ambient_c2") || "#E11D48",
          autoInsertTimeline: false
        });
      }
    }
    renderHistoryList(filterQuery = "") {
      var _a, _b, _c;
      const container = document.getElementById("history-list-container");
      if (!container) return;
      const isPro = window.__MF_EDITION__ === "pro" || window.location.pathname.includes(".pro") || document.title.includes("Pro");
      const myEdition = isPro ? "pro" : "standard";
      const filtered = this.history.filter((h) => {
        const matchEdition = !h.edition || h.edition === myEdition;
        const matchQuery = !filterQuery || h.title.toLowerCase().includes(filterQuery) || h.url.toLowerCase().includes(filterQuery);
        return matchEdition && matchQuery;
      });
      if (filtered.length === 0) {
        container.innerHTML = '<div style="font-size:11px; color:var(--text-muted); padding:12px; text-align:center;">No history records found.</div>';
        return;
      }
      container.innerHTML = "";
      for (const h of filtered) {
        const row = document.createElement("div");
        row.className = "queue-item";
        const dateStr = new Date(h.date).toLocaleDateString();
        const mb = (h.fileSize / (1024 * 1024)).toFixed(1);
        row.innerHTML = `
        <div class="queue-item-header">
          <span class="queue-item-title" title="${h.title}">${h.title}</span>
          <span class="queue-item-badge badge-completed">${h.profileName}</span>
        </div>
        <div class="queue-item-stats">
          <span>${dateStr} \xB7 ${mb} MB</span>
          <div class="queue-item-actions">
            <button class="btn btn-icon btn-sm btn-hist-reveal" title="Show in Folder">${ICONS.FOLDER}</button>
            <button class="btn btn-icon btn-sm btn-hist-redl" title="Download Again">${ICONS.RETRY}</button>
            <button class="btn btn-icon btn-sm btn-hist-del" title="Delete from history">${ICONS.CLOSE}</button>
          </div>
        </div>
      `;
        (_a = row.querySelector(".btn-hist-reveal")) == null ? void 0 : _a.addEventListener("click", () => hostAdapter.revealInFinder(h.outputPath));
        (_b = row.querySelector(".btn-hist-redl")) == null ? void 0 : _b.addEventListener("click", () => {
          const input = document.getElementById("url-input");
          if (input) {
            input.value = h.url;
            this.closeModal("modal-history");
            this.handleAnalyze();
          }
        });
        (_c = row.querySelector(".btn-hist-del")) == null ? void 0 : _c.addEventListener("click", () => serviceClient.removeHistoryItem(h.id));
        container.appendChild(row);
      }
    }
    showDuplicateModal(filePath) {
      const pathEl = document.getElementById("dup-file-path");
      if (pathEl) pathEl.textContent = filePath;
      this.openModal("modal-duplicate");
    }
    openModal(id) {
      const m = document.getElementById(id);
      if (m) m.classList.add("active");
    }
    closeModal(id) {
      if (id === "modal-media-preview") {
        const viewport = document.getElementById("media-preview-viewport");
        if (viewport) viewport.innerHTML = "";
      }
      const m = document.getElementById(id);
      if (m) m.classList.remove("active");
    }
    openMediaPreview(meta) {
      var _a, _b, _c;
      if (!meta) return;
      const url = meta.url || "";
      const activeItem = meta.items && meta.items.length > 0 ? meta.items[0] : meta;
      const isAppleMusic = Boolean(meta.isAppleMusic || /music\.apple\.com|itunes\.apple\.com/i.test(url));
      const isSpotify = Boolean(meta.isSpotify || /spotify\.com/i.test(url));
      const isTikTokAudio = /tiktok\.com\/music\//i.test(url);
      const isExplicitAudio = meta.mediaType === "audio" || meta.type === "audio" || activeItem.type === "audio" || activeItem.mediaType === "audio" || isSpotify || isAppleMusic || isTikTokAudio;
      const isExplicitImage = !isExplicitAudio && (meta.mediaType === "image" || meta.type === "image" || activeItem.type === "image" || activeItem.mediaType === "image" || meta.isImage || activeItem.isImage || meta.isGif || activeItem.isGif || /\.(jpe?g|png|webp|gif|bmp|svg|avif)($|\?)/i.test(url));
      const isExplicitVideo = !isExplicitAudio && !isExplicitImage;

      const embedUrl = isExplicitVideo ? (meta.embedUrl || activeItem.embedUrl || "") : "";
      const streamUrl = (meta.platform === "tiktok" ? ((meta.formats && meta.formats.find((f) => f.formatId === "tiktok_sd_nowm" || f.quality === "720")) ? meta.formats.find((f) => f.formatId === "tiktok_sd_nowm" || f.quality === "720").url : (meta.previewUrl || meta.directStreamUrl)) : (meta.directStreamUrl || activeItem.directStreamUrl || meta.downloadTarget || activeItem.downloadTarget || ""));
      const audioPreview = isExplicitAudio ? (activeItem.audioPreviewUrl || meta.audioPreviewUrl || activeItem.previewUrl || meta.previewUrl || streamUrl) : "";
      const theaterItem = {
        id: meta.id || "preview_" + Date.now(),
        videoId: isExplicitAudio ? "" : meta.id || activeItem.id,
        title: activeItem.title || meta.title,
        author: activeItem.uploader || meta.uploader || meta.channel || "Media Creator",
        uploader: activeItem.uploader || meta.uploader || meta.channel || "Media Creator",
        thumbnail: activeItem.thumbnail || meta.thumbnail,
        pageUrl: meta.url,
        sourceUrl: activeItem.url || meta.url,
        url: activeItem.url || meta.url,
        source: isAppleMusic ? "apple_music" : isSpotify ? "spotify" : meta.platform || meta.extractor || "media",
        platform: isAppleMusic ? "apple_music" : isSpotify ? "spotify" : meta.platform || "",
        isAppleMusic,
        isSpotify,
        type: isExplicitAudio ? "audio" : isExplicitImage ? "image" : "video",
        mediaType: isExplicitAudio ? "audio" : isExplicitImage ? "image" : "video",
        isImage: isExplicitImage,
        isGif: Boolean(meta.isGif || activeItem.isGif),
        audioPreviewUrl: audioPreview,
        previewUrl: isExplicitAudio ? audioPreview : embedUrl || streamUrl,
        hoverPreviewUrl: isExplicitAudio ? audioPreview : streamUrl,
        embedUrl,
        directStreamUrl: streamUrl,
        downloadFormats: meta.formats || activeItem.formats || []
      };
      if (typeof window.openTheaterPreview === "function") {
        try {
          window.openTheaterPreview(theaterItem);
          return;
        } catch (err) {
          console.warn("Theater player delegate error:", err);
        }
      }
      const titleEl = document.getElementById("media-preview-title");
      const authorEl = document.getElementById("media-preview-author");
      const viewport = document.getElementById("media-preview-viewport");
      const openBrowserBtn = document.getElementById("btn-open-preview-browser");
      if (titleEl) titleEl.textContent = activeItem.title || meta.title || "Media Preview";
      if (authorEl) {
        const isImg = meta.mediaType === "image" || meta.isImage || (activeItem && activeItem.mediaType === "image");
        const durStr = isImg ? "PHOTO" : (meta.duration && meta.duration > 0 ? this.formatDuration(meta.duration) : "");
        authorEl.textContent = `${activeItem.uploader || meta.uploader || meta.channel || "Media"}${durStr ? " \u2022 " + durStr : ""}`;
      }
      if (openBrowserBtn) {
        openBrowserBtn.onclick = () => {
          var _a2, _b2;
          const u = meta.url;
          if (u) {
            if (window.__adobe_cep__ && typeof window.__adobe_cep__.openURLInDefaultBrowser === "function") {
              window.__adobe_cep__.openURLInDefaultBrowser(u);
            } else if ((_b2 = (_a2 = window.cep) == null ? void 0 : _a2.util) == null ? void 0 : _b2.openURLInDefaultBrowser) {
              window.cep.util.openURLInDefaultBrowser(u);
            } else {
              window.open(u, "_blank");
            }
          }
        };
      }
      if (viewport) {
        viewport.innerHTML = "";
        const isYouTube = !isAudio && (url.includes("youtube.com") || url.includes("youtu.be"));
        if (isAppleMusic) {
          const audioUrl = audioPreview;
          if (audioUrl) {
            viewport.innerHTML = `
            <div style="display:flex; flex-direction:column; align-items:center; justify-content:center; gap:14px; padding:20px; text-align:center; height:100%;">
              <img src="${activeItem.thumbnail || meta.thumbnail || ""}" style="width:120px; height:120px; border-radius:8px; object-fit:cover; box-shadow:0 8px 24px rgba(0,0,0,0.6);" alt="Cover">
              <div style="display:flex; flex-direction:column; gap:4px;">
                <span style="font-size:13px; font-weight:700; color:#fff;">${activeItem.title || meta.title || "Apple Music Track"}</span>
                <span style="font-size:11px; color:#ff4d55; font-weight:600;">${activeItem.uploader || meta.uploader || meta.channel || "Artist"} \u2022 Apple Music</span>
              </div>
              <audio src="${audioUrl}" controls autoplay style="width:90%; max-width:320px; margin-top:6px;"></audio>
            </div>
          `;
          } else {
            viewport.innerHTML = `<div style="display:flex; flex-direction:column; align-items:center; justify-content:center; gap:8px; padding:20px; color:#aaa;"><span>Apple Music track ready for download</span></div>`;
          }
        } else if (isYouTube) {
          let ytId = meta.id;
          if (!ytId || ytId.length !== 11) {
            const match = url.match(/(?:v=|youtu\.be\/|embed\/|live\/)([a-zA-Z0-9_-]{11})/);
            if (match) ytId = match[1];
          }
          if (ytId) {
            viewport.innerHTML = `<iframe src="http://127.0.0.1:48924/youtube-player.html?v=${encodeURIComponent(ytId)}&autoplay=1" style="width:100%; height:100%; border:none;" allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen></iframe>`;
          } else {
            viewport.innerHTML = `<div style="display:flex; flex-direction:column; align-items:center; justify-content:center; gap:8px; padding:20px; color:#aaa;"><span>Preview ready</span><button class="btn btn-primary btn-sm" id="btn-play-yt-browser" style="display:inline-flex; align-items:center; gap:5px;">${ICONS.PLAY} Play in Browser</button></div>`;
            (_c = document.getElementById("btn-play-yt-browser")) == null ? void 0 : _c.addEventListener("click", () => {
              var _a2;
              if ((_a2 = window.__adobe_cep__) == null ? void 0 : _a2.openURLInDefaultBrowser) window.__adobe_cep__.openURLInDefaultBrowser(url);
              else window.open(url, "_blank");
            });
          }
        } else if (isSpotify) {
          const trackMatch = url.match(/track\/([a-zA-Z0-9]+)/);
          const sId = trackMatch ? trackMatch[1] : meta.id;
          if (sId) {
            viewport.innerHTML = `<iframe src="https://open.spotify.com/embed/track/${sId}?utm_source=generator" width="100%" height="100%" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"></iframe>`;
          }
        } else if (embedUrl) {
          viewport.innerHTML = `<iframe src="${embedUrl}" style="width:100%; height:100%; border:none;" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen></iframe>`;
        } else {
          let resolvedStreamUrl = streamUrl;
          if (!resolvedStreamUrl && meta.formats && meta.formats.length > 0) {
            const streamFormat = meta.formats.find((f) => f.url && (f.hasAudioAndVideo || f.ext === "mp4" && f.vcodec !== "none"));
            if (streamFormat) resolvedStreamUrl = streamFormat.url;
          }
          const isDirectPlayable = resolvedStreamUrl && (
            meta.platform === "tiktok" ||
            /mime_type=video_mp4|tiktokcdn|tiktok/i.test(resolvedStreamUrl) ||
            /\.(mp4|webm|m3u8|mov|ogg)($|\?)/i.test(resolvedStreamUrl) ||
            meta.mediaType === "video" ||
            meta.type === "video"
          );
          if (resolvedStreamUrl && isDirectPlayable) {
            viewport.innerHTML = `<video src="${resolvedStreamUrl}" controls autoplay playsinline style="width:100%; height:100%; object-fit:contain;"></video>`;
            const vEl = viewport.querySelector("video");
            if (vEl) {
              vEl.onloadedmetadata = () => {
                if (vEl.duration && !isNaN(vEl.duration) && vEl.duration > 0 && (!meta.duration || meta.duration <= 0)) {
                  meta.duration = Math.round(vEl.duration);
                  if (authorEl) {
                    authorEl.textContent = `${activeItem.uploader || meta.uploader || meta.channel || "Media"} \u2022 ${this.formatDuration(meta.duration)}`;
                  }
                  const dt = document.getElementById("media-duration-tag");
                  if (dt) dt.textContent = this.formatDuration(meta.duration);
                }
              };
            }
          } else {
            viewport.innerHTML = `
            <div style="display:flex; flex-direction:column; align-items:center; justify-content:center; gap:10px; padding:20px; text-align:center; color:#ddd;">
              <div style="width:28px; height:28px; border:3px solid #00d1b2; border-top-color:transparent; border-radius:50%; animation:spin 0.8s linear infinite;"></div>
              <span style="font-size:12px; font-weight:600; color:#00d1b2;">Resolving stream preview...</span>
            </div>
          `;
            fetch(`http://127.0.0.1:48924/api/stream-url?v=${encodeURIComponent(url)}`).then((r) => r.json()).then((data) => {
              if (data && data.success && data.streamUrl) {
                viewport.innerHTML = `<video src="${data.streamUrl}" controls autoplay playsinline style="width:100%; height:100%; object-fit:contain;"></video>`;
                const vEl = viewport.querySelector("video");
                if (vEl) {
                  vEl.onloadedmetadata = () => {
                    if (vEl.duration && !isNaN(vEl.duration) && vEl.duration > 0 && (!meta.duration || meta.duration <= 0)) {
                      meta.duration = Math.round(vEl.duration);
                      if (authorEl) {
                        authorEl.textContent = `${activeItem.uploader || meta.uploader || meta.channel || "Media"} \u2022 ${this.formatDuration(meta.duration)}`;
                      }
                      const dt = document.getElementById("media-duration-tag");
                      if (dt) dt.textContent = this.formatDuration(meta.duration);
                    }
                  };
                }
              } else {
                throw new Error("Stream URL not found");
              }
            }).catch(() => {
              var _a2;
              viewport.innerHTML = `
                <div style="display:flex; flex-direction:column; align-items:center; justify-content:center; gap:8px; padding:16px; text-align:center;">
                  <img src="${meta.thumbnail || ""}" style="max-height:140px; border-radius:4px; box-shadow:0 4px 12px rgba(0,0,0,0.5);" alt="Thumb">
                  <span style="font-size:11px; color:#bbb;">Click below to stream in default browser</span>
                  <button type="button" class="btn btn-primary btn-sm" id="btn-play-external" style="padding:4px 12px; font-weight:600; display:inline-flex; align-items:center; gap:5px;">${ICONS.PLAY} Watch Stream</button>
                </div>
              `;
              (_a2 = document.getElementById("btn-play-external")) == null ? void 0 : _a2.addEventListener("click", () => {
                var _a3, _b2;
                if (window.__adobe_cep__ && typeof window.__adobe_cep__.openURLInDefaultBrowser === "function") {
                  window.__adobe_cep__.openURLInDefaultBrowser(url);
                } else if ((_b2 = (_a3 = window.cep) == null ? void 0 : _a3.util) == null ? void 0 : _b2.openURLInDefaultBrowser) {
                  window.cep.util.openURLInDefaultBrowser(url);
                } else {
                  window.open(url, "_blank");
                }
              });
            });
          }
        }
      }
      this.openModal("modal-media-preview");
    }
    closeMediaPreview() {
      const viewport = document.getElementById("media-preview-viewport");
      if (viewport) viewport.innerHTML = "";
      this.closeModal("modal-media-preview");
    }
    parseTimeToSec(txt) {
      if (!txt) return 0;
      const clean = txt.trim();
      if (!clean) return 0;
      const parts = clean.split(":").map((p) => parseFloat(p.trim()) || 0);
      if (parts.length >= 3) {
        let sec = parts[0] * 3600 + parts[1] * 60 + parts[2];
        if (parts.length >= 4) sec += parts[3] / 30;
        return sec;
      }
      if (parts.length === 2) return parts[0] * 60 + parts[1];
      if (parts.length === 1) return parts[0];
      return 0;
    }
    formatDuration(seconds) {
      if (!seconds || seconds <= 0) return "00:00";
      const h = Math.floor(seconds / 3600);
      const m = Math.floor(seconds % 3600 / 60);
      const s = Math.floor(seconds % 60);
      if (h > 0) {
        return `${h.toString().padStart(2, "0")}:${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
      }
      return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
    }
    loadUrlIntoDownloader(targetUrl, options = {}) {
      if (!targetUrl) return;

      // 1. Switch to Link Downloader view
      const modeBtnDownload = document.getElementById("mode-btn-download");
      if (modeBtnDownload) modeBtnDownload.click();

      // 2. Clear old state completely
      this.currentMetadata = null;
      this.currentPlaylist = null;
      this.pendingDownloadParams = null;

      // 3. Reset trimmer and custom inputs
      if (typeof window.resetTrim === "function") window.resetTrim();
      const filenameInput = document.getElementById("custom-filename-input");
      if (filenameInput) filenameInput.value = "";

      // 4. Hide old media card
      const cardSection = document.getElementById("media-card-section");
      if (cardSection) cardSection.style.display = "none";

      // 5. Select appropriate mode button
      if (options.isAudio) {
        const audioBtn = document.getElementById("mode-audio-only");
        if (audioBtn) audioBtn.click();
      } else if (options.isVideo) {
        const videoBtn = document.getElementById("mode-video-audio");
        if (videoBtn) videoBtn.click();
      }

      // 6. Autofill URL input field
      const urlInput = document.getElementById("url-input");
      if (urlInput) {
        urlInput.value = targetUrl;
        urlInput.dispatchEvent(new Event("input", { bubbles: true }));
        urlInput.dispatchEvent(new Event("change", { bubbles: true }));
        urlInput.focus();
      }

      // 7. Open trimmer if requested
      if (options.openTrimmer) {
        const trimPanel = document.getElementById("trim-inputs-panel");
        const trimArrow = document.getElementById("trim-toggle-arrow");
        if (trimPanel) {
          trimPanel.style.display = "flex";
          if (trimArrow) trimArrow.textContent = "\u25BC";
        }
      }

      // 8. Auto-trigger analysis for the new URL immediately
      setTimeout(() => {
        this.handleAnalyze();
      }, 120);
    }
  };

  if (typeof window !== "undefined") {
    window.addEventListener("message", (e) => {
      try {
        if (e.data && e.data.type === "MF_OPEN_BROWSER" && e.data.url) {
          if (window.__adobe_cep__ && typeof window.__adobe_cep__.openURLInDefaultBrowser === "function") {
            window.__adobe_cep__.openURLInDefaultBrowser(e.data.url);
          } else if (window.cep && window.cep.util && typeof window.cep.util.openURLInDefaultBrowser === "function") {
            window.cep.util.openURLInDefaultBrowser(e.data.url);
          } else {
            window.open(e.data.url, "_blank");
          }
        }
      } catch (_) {}
    });
  }

  if (typeof document !== "undefined") {
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", () => new MediaFetchApp());
    } else {
      new MediaFetchApp();
    }
  }
})();
