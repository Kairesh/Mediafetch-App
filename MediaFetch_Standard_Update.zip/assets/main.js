(() => {
  var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
    get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
  }) : x)(function(x) {
    if (typeof require !== "undefined") return require.apply(this, arguments);
    throw Error('Dynamic require of "' + x + '" is not supported');
  });

  // src/ui/services/client.ts
  var ServiceClient = class {
    ws;
    port = 48923;
    isConnected = false;
    listeners = [];
    reconnectTimer;
    statusListeners = [];
    constructor(preferredPort = 48923) {
      this.port = preferredPort;
    }
    isOnline() {
      return this.isConnected;
    }
    onStatusChanged(cb) {
      this.statusListeners.push(cb);
      cb(this.isConnected);
    }
    subscribe(listener) {
      this.listeners.push(listener);
      return () => {
        this.listeners = this.listeners.filter((l) => l !== listener);
      };
    }
    notifyStatus(online) {
      this.isConnected = online;
      for (const cb of this.statusListeners) {
        cb(online);
      }
    }
    notifyListeners(msg) {
      for (const l of this.listeners) {
        try {
          l(msg);
        } catch (err) {
          console.error("Error in message listener:", err);
        }
      }
    }
    connect() {
      if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
        return;
      }
      try {
        this.ws = new WebSocket(`ws://127.0.0.1:${this.port}`);
        this.ws.onopen = () => {
          console.log("Connected to MediaFetch service daemon.");
          this.notifyStatus(true);
          if (this.reconnectTimer) {
            clearTimeout(this.reconnectTimer);
            this.reconnectTimer = void 0;
          }
        };
        this.ws.onmessage = (event) => {
          try {
            const parsed = JSON.parse(event.data);
            this.notifyListeners(parsed);
          } catch (e) {
            console.error("Failed to parse WebSocket message:", e);
          }
        };
        this.ws.onclose = () => {
          this.notifyStatus(false);
          this.tryAutoStartDaemon();
          this.scheduleReconnect();
        };
        this.ws.onerror = () => {
          this.notifyStatus(false);
          this.tryAutoStartDaemon();
        };
      } catch {
        this.notifyStatus(false);
        this.tryAutoStartDaemon();
        this.scheduleReconnect();
      }
    }
    autoStartAttempts = 0;
    tryAutoStartDaemon() {
      if (this.autoStartAttempts > 3) return;
      this.autoStartAttempts++;
      try {
        if (typeof window !== "undefined") {
          const nodeRequire = window.require || window.cep_node?.require;
          if (nodeRequire) {
            const path = nodeRequire("path");
            const fs = nodeRequire("fs");
            let proc = null;
            try {
              proc = typeof process !== "undefined" ? process : nodeRequire("process");
            } catch {
            }
            const appData = proc?.env?.APPDATA || "";
            const localAppData = proc?.env?.LOCALAPPDATA || "";
            let extDir = "";
            try {
              if (window.__adobe_cep__?.getSystemPath) {
                extDir = window.__adobe_cep__.getSystemPath("extension");
              } else if (window.CSInterface) {
                extDir = new window.CSInterface().getSystemPath("extension");
              }
            } catch {
            }
            if (!extDir && window.location && window.location.pathname) {
              let p = window.location.pathname.replace(/^[\\\/]([A-Za-z]:)/, "$1");
              extDir = p.substring(0, Math.max(p.lastIndexOf("/"), p.lastIndexOf("\\")));
            }
            const candidates = [
              extDir ? path.join(extDir, "service", "server.js") : "",
              extDir ? path.join(extDir, "service", "server.bundle.js") : "",
              appData ? path.join(appData, "Adobe", "CEP", "extensions", "com.mediafetch.adobe", "service", "server.js") : "",
              localAppData ? path.join(localAppData, "MediaFetch", "server.js") : ""
            ].filter(Boolean);
            const nodeExecutables = [
              "C:\\Program Files\\nodejs\\node.exe",
              "C:\\Program Files (x86)\\nodejs\\node.exe",
              "node"
            ];
            for (const candidate of candidates) {
              if (fs.existsSync(candidate)) {
                console.log("[MediaFetch] Attempting auto-start from:", candidate);
                try {
                  nodeRequire(candidate);
                  console.log("[MediaFetch] Started service in-process.");
                  setTimeout(() => this.connect(), 500);
                  return;
                } catch {
                }
                try {
                  const cp = nodeRequire("child_process");
                  for (const nodeExe of nodeExecutables) {
                    try {
                      const child = cp.spawn(nodeExe, ["--max-old-space-size=48", "--optimize-for-size", candidate], {
                        detached: true,
                        stdio: "ignore",
                        windowsHide: true
                      });
                      child.unref();
                      console.log(`[MediaFetch] Spawned daemon with ${nodeExe}: ${candidate}`);
                      setTimeout(() => this.connect(), 800);
                      return;
                    } catch {
                    }
                  }
                } catch {
                }
              }
            }
          }
        }
      } catch (e) {
        console.warn("[MediaFetch] Auto-start daemon error:", e);
      }
    }
    scheduleReconnect() {
      if (this.reconnectTimer) return;
      this.reconnectTimer = window.setTimeout(() => {
        this.reconnectTimer = void 0;
        this.connect();
      }, 1500);
    }
    send(msg) {
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        msg.edition = "standard";
        if (msg.payload && typeof msg.payload === "object") {
          msg.payload.edition = "standard";
        }
        this.ws.send(JSON.stringify(msg));
      } else {
        console.warn("Cannot send message: service not connected.");
      }
    }
    analyzeUrl(url, timeoutMs) {
      this.send({ type: "ANALYZE_URL", payload: { url, timeoutMs } });
    }
    analyzePlaylist(url) {
      this.send({ type: "ANALYZE_PLAYLIST", payload: { url } });
    }
    startDownload(url, profile, projectContext, targetDirectory, metadata) {
      const isPro = window.__MF_EDITION__ === "pro" || window.location.pathname.includes(".pro") || document.title.includes("Pro");
      const edition = isPro ? "pro" : "standard";
      this.send({
        type: "START_DOWNLOAD",
        payload: { url, profile, projectContext, targetDirectory, metadata: { ...metadata || {}, edition }, edition }
      });
    }
    startPlaylistDownload(items, profile, projectContext, targetDirectory, options) {
      const isPro = window.__MF_EDITION__ === "pro" || window.location.pathname.includes(".pro") || document.title.includes("Pro");
      const edition = isPro ? "pro" : "standard";
      this.send({
        type: "START_PLAYLIST_DOWNLOAD",
        payload: {
          items,
          profile,
          projectContext,
          targetDirectory,
          customFolderName: options?.customFolderName,
          preserveSubfolders: options?.preserveSubfolders,
          autoImport: options?.autoImport,
          zipPackage: options?.zipPackage,
          playlistTitle: options?.playlistTitle,
          isCloud: options?.isCloud,
          edition
        }
      });
    }
    pauseDownload(id) {
      this.send({ type: "PAUSE_DOWNLOAD", payload: { id } });
    }
    resumeDownload(id) {
      this.send({ type: "RESUME_DOWNLOAD", payload: { id } });
    }
    cancelDownload(id) {
      this.send({ type: "CANCEL_DOWNLOAD", payload: { id } });
    }
    retryDownload(id) {
      this.send({ type: "RETRY_DOWNLOAD", payload: { id } });
    }
    clearCompleted() {
      const isPro = window.__MF_EDITION__ === "pro" || window.location.pathname.includes(".pro") || document.title.includes("Pro");
      const edition = isPro ? "pro" : "standard";
      this.send({ type: "CLEAR_COMPLETED", payload: { edition }, edition });
    }
    clearAll() {
      const isPro = window.__MF_EDITION__ === "pro" || window.location.pathname.includes(".pro") || document.title.includes("Pro");
      const edition = isPro ? "pro" : "standard";
      this.send({ type: "CLEAR_ALL", payload: { edition }, edition });
    }
    getSettings() {
      this.send({ type: "GET_SETTINGS" });
    }
    updateSettings(settings) {
      this.send({ type: "UPDATE_SETTINGS", payload: settings });
    }
    getDiagnostics() {
      this.send({ type: "GET_DIAGNOSTICS" });
    }
    runSystemCheck() {
      this.send({ type: "RUN_SYSTEM_CHECK" });
    }
    installDependency(name) {
      this.send({ type: "INSTALL_DEPENDENCY", payload: { name } });
    }
    updateYtDlp() {
      this.send({ type: "UPDATE_YTDLP" });
    }
    getHistory() {
      this.send({ type: "GET_HISTORY" });
    }
    clearHistory() {
      this.send({ type: "CLEAR_HISTORY" });
    }
    removeHistoryItem(id) {
      this.send({ type: "REMOVE_HISTORY_ITEM", payload: { id } });
    }
    checkDuplicate(title, container, targetDirectory) {
      this.send({
        type: "CHECK_DUPLICATE",
        payload: { title, container, targetDirectory }
      });
    }
    openFolderDialog() {
      this.send({ type: "OPEN_FOLDER_DIALOG" });
    }
  };
  var serviceClient = new ServiceClient();

  // src/host/premiere-adapter.ts
  var PremiereHostAdapter = class {
    themeListeners = [];
    async getProjectContext() {
      try {
        const script = `
        (function() {
          try {
            if (app && app.project) {
              var pPath = "";
              if (app.project.path && app.project.path.length > 0) {
                pPath = app.project.path;
              } else if (app.project.documentPath && app.project.documentPath.length > 0) {
                pPath = app.project.documentPath;
              }

              if (pPath && pPath.length > 0) {
                return JSON.stringify({
                  saved: true,
                  path: pPath,
                  name: app.project.name || "Premiere Project",
                  version: app.version || "26.0"
                });
              } else {
                return JSON.stringify({
                  saved: false,
                  name: "Active Premiere Project (Unsaved)",
                  version: app.version || "26.0"
                });
              }
            }
          } catch (err) {
            return JSON.stringify({ saved: false, error: String(err) });
          }
          return JSON.stringify({ saved: false });
        })();
      `;
        const result = await this.evalScript(script);
        if (result && typeof result === "string" && result !== "EvalScript error.") {
          const parsed = JSON.parse(result);
          if (parsed) {
            if (parsed.saved && parsed.path) {
              const cleanPath = parsed.path.replace(/\\/g, "/");
              const dir = cleanPath.substring(0, cleanPath.lastIndexOf("/"));
              const name = cleanPath.substring(cleanPath.lastIndexOf("/") + 1) || parsed.name;
              return {
                application: "premierepro",
                applicationVersion: parsed.version || "26.0",
                projectSaved: true,
                projectName: name,
                projectPath: parsed.path,
                projectDirectory: dir.replace(/\//g, "\\")
              };
            } else if (parsed.name) {
              return {
                application: "premierepro",
                applicationVersion: parsed.version || "26.0",
                projectSaved: false,
                projectName: parsed.name
              };
            }
          }
        }
      } catch (e) {
        console.warn("Error reading Premiere Pro project context:", e);
      }
      return {
        application: "premierepro",
        applicationVersion: "26.0",
        projectSaved: false
      };
    }
    async revealInFinder(filePath) {
      try {
        if (typeof window !== "undefined" && window.require) {
          const cp = window.require("child_process");
          if (cp?.exec) {
            cp.exec(`explorer.exe /select,"${filePath.replace(/\//g, "\\")}"`);
            return;
          }
        }
      } catch {
      }
      try {
        const script = `
        (function() {
          var f = new File("${filePath.replace(/\\/g, "/")}");
          if (f.exists) {
            f.execute();
          }
        })();
      `;
        await this.evalScript(script);
      } catch {
      }
    }
    async openFile(filePath) {
      await this.revealInFinder(filePath);
    }
    async importToProject(filePath, options) {
      try {
        const cleanPath = filePath.replace(/\\/g, "/");
        const isCustom = options?.isCustomPath ? true : false;
        const isCloud = options?.isCloud ? true : false;
        const isPlaylist = options?.isPlaylist ? true : false;
        const playlistTitle = (options?.playlistTitle || "").replace(/[\\/:"*?<>|]/g, " ").trim();
        const customFolderName = (options?.customFolderName || "").replace(/[\\/:"*?<>|]/g, " ").trim();
        const subFolderName = (options?.subFolderName || "").trim();
        const script = `
        (function() {
          try {
            if (!app || !app.project) return "no_project";
            var project = app.project;
            var root = project.rootItem;
            
            function getOrCreateBin(parentBin, binName) {
              if (!parentBin || !parentBin.children) return null;
              for (var i = 0; i < parentBin.children.numItems; i++) {
                var item = parentBin.children[i];
                if (item && item.type === 2 && item.name === binName) {
                  return item;
                }
              }
              return parentBin.createBin(binName);
            }

            var targetPath = "${cleanPath}";
            var isCustom = ${isCustom ? "true" : "false"};
            var isCloud = ${isCloud ? "true" : "false"};
            var isPlaylist = ${isPlaylist ? "true" : "false"};
            var playlistTitle = "${playlistTitle.replace(/"/g, '\\"')}";
            var customFolderName = "${customFolderName.replace(/"/g, '\\"')}";
            var subFolderName = "${subFolderName.replace(/"/g, '\\"').replace(/\\/g, "/")}";

            var targetBin = null;

            if (isCustom) {
              // Custom Directory: create root bin outside MediaFetch named after the selected custom folder
              var rootBinName = customFolderName || (isPlaylist ? (playlistTitle || "Playlist") : (isCloud ? "Cloud Media" : ""));
              if (!rootBinName) {
                var pParts = targetPath.split('/');
                rootBinName = pParts.length > 1 ? pParts[pParts.length - 2] : "Downloads";
              }
              var customRootBin = getOrCreateBin(root, rootBinName);
              if (subFolderName) {
                var sParts = subFolderName.split('/');
                var cur = customRootBin;
                for (var s = 0; s < sParts.length; s++) {
                  if (sParts[s] && sParts[s].length > 0) {
                    cur = getOrCreateBin(cur, sParts[s]);
                  }
                }
                targetBin = cur || customRootBin;
              } else {
                targetBin = customRootBin;
              }
            } else {
              // Default Project Path: inside root "MediaFetch" bin
              var mediaFetchBin = getOrCreateBin(root, "MediaFetch");

              if (isCloud) {
                // MediaFetch -> Cloud Links -> [Cloud Folder Name] -> [Subfolders]
                var cloudRootBin = getOrCreateBin(mediaFetchBin, "Cloud Links");
                var cloudFolderBin = getOrCreateBin(cloudRootBin, customFolderName || "Cloud Media");
                if (subFolderName) {
                  var sParts = subFolderName.split('/');
                  var cur = cloudFolderBin;
                  for (var s = 0; s < sParts.length; s++) {
                    if (sParts[s] && sParts[s].length > 0) {
                      cur = getOrCreateBin(cur, sParts[s]);
                    }
                  }
                  targetBin = cur || cloudFolderBin;
                } else {
                  targetBin = cloudFolderBin;
                }
              } else if (isPlaylist) {
                // MediaFetch -> Playlists -> [Playlist Name]
                var playlistRootBin = getOrCreateBin(mediaFetchBin, "Playlists");
                var pName = playlistTitle || customFolderName || "Playlist 1";
                targetBin = getOrCreateBin(playlistRootBin, pName);
              } else {
                // Single link or Search
                var isSearch = targetPath.indexOf("SerachMediafetch") !== -1 || 
                               targetPath.indexOf("MediaFetch Assets") !== -1 || 
                               targetPath.indexOf("MediaSearch Assets") !== -1;
                var categoryBinName = isSearch ? "SerachMediafetch" : "LinkMediaFetch";
                var categoryBin = getOrCreateBin(mediaFetchBin, categoryBinName);

                var parts = targetPath.split('.');
                var ext = parts.length > 1 ? parts[parts.length - 1].toLowerCase().split('?')[0] : '';
                var isAudio = (ext === 'mp3' || ext === 'wav' || ext === 'm4a' || ext === 'flac' || ext === 'aac' || ext === 'ogg' || ext === 'opus' || ext === 'aiff');
                var isImage = (ext === 'jpg' || ext === 'jpeg' || ext === 'png' || ext === 'webp' || ext === 'gif' || ext === 'bmp' || ext === 'tiff' || ext === 'tif' || ext === 'svg');
                var typeBinName = isAudio ? "Audio" : (isImage ? "Image" : "Video");
                targetBin = getOrCreateBin(categoryBin, typeBinName) || categoryBin;
              }
            }

            if (!targetBin) targetBin = root;

            // Check if file is already imported in targetBin to avoid duplicates
            if (targetBin && targetBin.children) {
              for (var k = 0; k < targetBin.children.numItems; k++) {
                var ch = targetBin.children[k];
                try {
                  if (ch && ch.getMediaPath && (ch.getMediaPath() === targetPath || ch.getMediaPath() === "${filePath.replace(/\\/g, "\\\\")}")) {
                    return "true";
                  }
                } catch (_) {}
              }
            }

            // Import file into target type bin
            var success = project.importFiles([targetPath], true, targetBin, false);
            if (success && ${options?.insertToTimeline ? "true" : "false"}) {
              try {
                var targetItem = null;
                var cleanNorm = targetPath.replace(/\\/g, '/').toLowerCase();
                for (var ti = 0; ti < targetBin.children.numItems; ti++) {
                  var ci = targetBin.children[ti];
                  if (ci && ci.getMediaPath && ci.getMediaPath().replace(/\\/g, '/').toLowerCase() === cleanNorm) {
                    targetItem = ci;
                    break;
                  }
                }
                if (targetItem) {
                  var sName = targetItem.name || "MediaFetch Timeline";
                  var createdSeq = false;
                  if (typeof project.createNewSequenceFromClips === "function") {
                    var ns = project.createNewSequenceFromClips(sName, [targetItem], targetBin);
                    if (ns) {
                      createdSeq = true;
                      if (project.openSequence) project.openSequence(ns.sequenceID);
                    }
                  }
                  if (!createdSeq) {
                    var aSeq = project.activeSequence;
                    if (aSeq) {
                      var pPos = aSeq.getPlayerPosition();
                      if (isAudio && aSeq.audioTracks && aSeq.audioTracks.numTracks > 0) {
                        aSeq.audioTracks[0].insertClip(targetItem, pPos);
                      } else if (aSeq.videoTracks && aSeq.videoTracks.numTracks > 0) {
                        aSeq.videoTracks[0].insertClip(targetItem, pPos);
                      }
                    } else if (typeof project.createNewSequence === "function") {
                      project.createNewSequence(sName, "");
                      var ns2 = project.activeSequence;
                      if (ns2) {
                        if (isAudio && ns2.audioTracks && ns2.audioTracks.numTracks > 0) {
                          ns2.audioTracks[0].insertClip(targetItem, "0");
                        } else if (ns2.videoTracks && ns2.videoTracks.numTracks > 0) {
                          ns2.videoTracks[0].insertClip(targetItem, "0");
                        }
                      }
                    }
                  }
                }
              } catch (_) {}
            }
            return success ? "true" : "false";
          } catch (err) {
            return "error: " + err;
          }
        })();
      `;
        const res = await this.evalScript(script);
        console.log("[Premiere importToProject result]:", res);
        return res === "true" || res === true;
      } catch {
        return false;
      }
    }
    getHostTheme() {
      if (typeof window !== "undefined" && window.__adobe_cep__) {
        try {
          const skin = window.__adobe_cep__.getHostEnvironment()?.appSkinInfo;
          if (skin?.panelBackgroundColor?.color) {
            const r = skin.panelBackgroundColor.color.red;
            if (r < 50) return "darkest";
            if (r < 100) return "dark";
            if (r > 200) return "lightest";
            return "light";
          }
        } catch {
        }
      }
      return "dark";
    }
    onThemeChanged(callback) {
      this.themeListeners.push(callback);
      if (typeof window !== "undefined" && window.__adobe_cep__) {
        try {
          window.__adobe_cep__.addEventListener("com.adobe.csxs.events.ThemeChanged", () => {
            callback(this.getHostTheme());
          });
        } catch {
        }
      }
    }
    evalScript(script) {
      return new Promise((resolve) => {
        let resolved = false;
        const timer = setTimeout(() => {
          if (!resolved) {
            resolved = true;
            resolve(null);
          }
        }, 1200);
        try {
          if (typeof window !== "undefined" && window.__adobe_cep__) {
            window.__adobe_cep__.evalScript(script, (result) => {
              if (!resolved) {
                resolved = true;
                clearTimeout(timer);
                resolve(result);
              }
            });
            return;
          }
          if (typeof window !== "undefined" && window.CSInterface) {
            const cs = new window.CSInterface();
            cs.evalScript(script, (result) => {
              if (!resolved) {
                resolved = true;
                clearTimeout(timer);
                resolve(result);
              }
            });
            return;
          }
        } catch (e) {
          console.warn("evalScript error:", e);
        }
        if (!resolved) {
          resolved = true;
          clearTimeout(timer);
          resolve(null);
        }
      });
    }
  };

  // src/host/ae-adapter.ts
  var AfterEffectsHostAdapter = class {
    themeListeners = [];
    async getProjectContext() {
      try {
        const script = `
        (function() {
          try {
            if (app && app.project) {
              if (app.project.file && app.project.file.exists) {
                return JSON.stringify({
                  saved: true,
                  path: app.project.file.fsName,
                  name: app.project.file.displayName || "After Effects Project",
                  version: app.version || "26.0"
                });
              } else {
                return JSON.stringify({
                  saved: false,
                  name: "Active AE Project (Unsaved)",
                  version: app.version || "26.0"
                });
              }
            }
          } catch (err) {
            return JSON.stringify({ saved: false, error: String(err) });
          }
          return JSON.stringify({ saved: false });
        })();
      `;
        const result = await this.evalScript(script);
        if (result && typeof result === "string" && result !== "EvalScript error.") {
          const parsed = JSON.parse(result);
          if (parsed) {
            if (parsed.saved && parsed.path) {
              const cleanPath = parsed.path.replace(/\\/g, "/");
              const dir = cleanPath.substring(0, cleanPath.lastIndexOf("/"));
              const name = cleanPath.substring(cleanPath.lastIndexOf("/") + 1) || parsed.name;
              return {
                application: "aftereffects",
                applicationVersion: parsed.version || "26.0",
                projectSaved: true,
                projectName: name,
                projectPath: parsed.path,
                projectDirectory: dir.replace(/\//g, "\\")
              };
            } else if (parsed.name) {
              return {
                application: "aftereffects",
                applicationVersion: parsed.version || "26.0",
                projectSaved: false,
                projectName: parsed.name
              };
            }
          }
        }
      } catch (e) {
        console.warn("Error reading After Effects project context:", e);
      }
      return {
        application: "aftereffects",
        applicationVersion: "26.0",
        projectSaved: false
      };
    }
    async revealInFinder(filePath) {
      try {
        if (typeof window !== "undefined" && window.require) {
          const cp = window.require("child_process");
          if (cp?.exec) {
            cp.exec(`explorer.exe /select,"${filePath.replace(/\//g, "\\")}"`);
            return;
          }
        }
      } catch {
      }
      try {
        const script = `
        (function() {
          var f = new File("${filePath.replace(/\\/g, "/")}");
          if (f.exists) {
            f.execute();
          }
        })();
      `;
        await this.evalScript(script);
      } catch {
      }
    }
    async openFile(filePath) {
      await this.revealInFinder(filePath);
    }
    async importToProject(filePath, options) {
      try {
        const cleanPath = filePath.replace(/\\/g, "/");
        const isCustom = options?.isCustomPath ? true : false;
        const isCloud = options?.isCloud ? true : false;
        const isPlaylist = options?.isPlaylist ? true : false;
        const playlistTitle = (options?.playlistTitle || "").replace(/[\\/:"*?<>|]/g, " ").trim();
        const customFolderName = (options?.customFolderName || "").replace(/[\\/:"*?<>|]/g, " ").trim();
        const subFolderName = (options?.subFolderName || "").trim();
        const script = `
        (function() {
          try {
            if (typeof app === "undefined" || !app.project) return "no_project";
            var proj = app.project;
            
            function getOrCreateAeFolder(proj, parentFolder, folderName) {
              for (var i = 1; i <= proj.numItems; i++) {
                var it = proj.item(i);
                if (it && (it instanceof FolderItem || it.typeName === "Folder") && it.name === folderName) {
                  if (!parentFolder && (!it.parentFolder || it.parentFolder === proj.rootFolder)) {
                    return it;
                  }
                  if (parentFolder && it.parentFolder === parentFolder) {
                    return it;
                  }
                }
              }
              var newFolder = proj.items.addFolder(folderName);
              if (parentFolder) {
                newFolder.parentFolder = parentFolder;
              }
              return newFolder;
            }

            var targetPath = "${cleanPath}";
            var isCustom = ${isCustom ? "true" : "false"};
            var isCloud = ${isCloud ? "true" : "false"};
            var isPlaylist = ${isPlaylist ? "true" : "false"};
            var playlistTitle = "${playlistTitle.replace(/"/g, '\\"')}";
            var customFolderName = "${customFolderName.replace(/"/g, '\\"')}";
            var subFolderName = "${subFolderName.replace(/"/g, '\\"').replace(/\\/g, "/")}";

            var targetFolder = null;

            if (isCustom) {
              // Custom Directory: create root bin outside MediaFetch named after the selected custom folder
              var rootBinName = customFolderName || (isPlaylist ? (playlistTitle || "Playlist") : (isCloud ? "Cloud Media" : ""));
              if (!rootBinName) {
                var pParts = targetPath.split('/');
                rootBinName = pParts.length > 1 ? pParts[pParts.length - 2] : "Downloads";
              }
              var customRootFolder = getOrCreateAeFolder(proj, null, rootBinName);
              if (subFolderName) {
                var sParts = subFolderName.split('/');
                var cur = customRootFolder;
                for (var s = 0; s < sParts.length; s++) {
                  if (sParts[s] && sParts[s].length > 0) {
                    cur = getOrCreateAeFolder(proj, cur, sParts[s]);
                  }
                }
                targetFolder = cur || customRootFolder;
              } else {
                targetFolder = customRootFolder;
              }
            } else {
              // Default Project Path: inside root "MediaFetch" bin
              var mediaFetchFolder = getOrCreateAeFolder(proj, null, "MediaFetch");

              if (isCloud) {
                // MediaFetch -> Cloud Links -> [Cloud Folder Name] -> [Subfolders]
                var cloudRoot = getOrCreateAeFolder(proj, mediaFetchFolder, "Cloud Links");
                var cloudFolder = getOrCreateAeFolder(proj, cloudRoot, customFolderName || "Cloud Media");
                if (subFolderName) {
                  var sParts = subFolderName.split('/');
                  var cur = cloudFolder;
                  for (var s = 0; s < sParts.length; s++) {
                    if (sParts[s] && sParts[s].length > 0) {
                      cur = getOrCreateAeFolder(proj, cur, sParts[s]);
                    }
                  }
                  targetFolder = cur || cloudFolder;
                } else {
                  targetFolder = cloudFolder;
                }
              } else if (isPlaylist) {
                // MediaFetch -> Playlists -> [Playlist Name]
                var playlistRoot = getOrCreateAeFolder(proj, mediaFetchFolder, "Playlists");
                var pName = playlistTitle || customFolderName || "Playlist 1";
                targetFolder = getOrCreateAeFolder(proj, playlistRoot, pName);
              } else {
                // Single link or Search
                var isSearch = targetPath.indexOf("SerachMediafetch") !== -1 || 
                               targetPath.indexOf("MediaFetch Assets") !== -1 || 
                               targetPath.indexOf("MediaSearch Assets") !== -1;
                var categoryFolderName = isSearch ? "SerachMediafetch" : "LinkMediaFetch";
                var categoryFolder = getOrCreateAeFolder(proj, mediaFetchFolder, categoryFolderName);

                var parts = targetPath.split('.');
                var ext = parts.length > 1 ? parts[parts.length - 1].toLowerCase().split('?')[0] : '';
                var isAudio = (ext === 'mp3' || ext === 'wav' || ext === 'm4a' || ext === 'flac' || ext === 'aac' || ext === 'ogg' || ext === 'opus' || ext === 'aiff');
                var isImage = (ext === 'jpg' || ext === 'jpeg' || ext === 'png' || ext === 'webp' || ext === 'gif' || ext === 'bmp' || ext === 'tiff' || ext === 'tif' || ext === 'svg');
                var typeFolderName = isAudio ? "Audio" : (isImage ? "Image" : "Video");
                targetFolder = getOrCreateAeFolder(proj, categoryFolder, typeFolderName) || categoryFolder;
              }
            }

            // Locate media file
            var mediaFile = new File(targetPath);
            if (!mediaFile.exists) {
              mediaFile = new File("${filePath.replace(/\\/g, "\\\\")}");
            }
            if (!mediaFile.exists) {
              return "file_not_found: " + targetPath;
            }

            // Check if file is ALREADY imported in project
            for (var j = 1; j <= proj.numItems; j++) {
              var existingItem = proj.item(j);
              if (existingItem && existingItem.file && existingItem.file.fsName === mediaFile.fsName) {
                return "true";
              }
            }

            // Import media into target folder
            var io = new ImportOptions();
            io.file = mediaFile;
            var importedItem = proj.importFile(io);
            if (importedItem) {
              importedItem.parentFolder = targetFolder || proj.rootFolder;
              if (${options?.insertToTimeline ? "true" : "false"}) {
                try {
                  var comp = proj.activeItem;
                  if (!comp || !(comp instanceof CompItem)) {
                    for (var cIdx = 1; cIdx <= proj.numItems; cIdx++) {
                      if (proj.item(cIdx) instanceof CompItem) {
                        comp = proj.item(cIdx);
                        break;
                      }
                    }
                  }
                  if (!comp || !(comp instanceof CompItem)) {
                    var w = (importedItem.width && importedItem.width > 0) ? importedItem.width : 1920;
                    var h = (importedItem.height && importedItem.height > 0) ? importedItem.height : 1080;
                    var dur = (importedItem.duration && importedItem.duration > 0) ? importedItem.duration : 30;
                    var fps = (importedItem.frameRate && importedItem.frameRate > 0) ? importedItem.frameRate : 30;
                    var rawName = importedItem.name || "MediaFetch Comp";
                    var dotIdx = rawName.lastIndexOf(".");
                    var cName = (dotIdx > 0) ? rawName.substring(0, dotIdx) : rawName;
                    comp = proj.items.addComposition(cName, w, h, 1.0, dur, fps);
                  }
                  if (comp && comp instanceof CompItem) {
                    var layer = comp.layers.add(importedItem);
                    if (layer) {
                      layer.moveToBeginning();
                    }
                  }
                } catch (_) {}
              }
              return "true";
            }
            return "cannot_import";
          } catch (err) {
            return "error: " + err;
          }
        })();
      `;
        const res = await this.evalScript(script);
        console.log("[AfterEffects importToProject result]:", res);
        return res === "true" || res === true;
      } catch {
        return false;
      }
    }
    getHostTheme() {
      if (typeof window !== "undefined" && window.__adobe_cep__) {
        try {
          const skin = window.__adobe_cep__.getHostEnvironment()?.appSkinInfo;
          if (skin?.panelBackgroundColor?.color) {
            const r = skin.panelBackgroundColor.color.red;
            if (r < 50) return "darkest";
            if (r < 100) return "dark";
            if (r > 200) return "lightest";
            return "light";
          }
        } catch {
        }
      }
      return "dark";
    }
    onThemeChanged(callback) {
      this.themeListeners.push(callback);
      if (typeof window !== "undefined" && window.__adobe_cep__) {
        try {
          window.__adobe_cep__.addEventListener("com.adobe.csxs.events.ThemeChanged", () => {
            callback(this.getHostTheme());
          });
        } catch {
        }
      }
    }
    evalScript(script) {
      return new Promise((resolve) => {
        let resolved = false;
        const timer = setTimeout(() => {
          if (!resolved) {
            resolved = true;
            resolve(null);
          }
        }, 1200);
        try {
          if (typeof window !== "undefined" && window.__adobe_cep__) {
            window.__adobe_cep__.evalScript(script, (result) => {
              if (!resolved) {
                resolved = true;
                clearTimeout(timer);
                resolve(result);
              }
            });
            return;
          }
          if (typeof window !== "undefined" && window.CSInterface) {
            const cs = new window.CSInterface();
            cs.evalScript(script, (result) => {
              if (!resolved) {
                resolved = true;
                clearTimeout(timer);
                resolve(result);
              }
            });
            return;
          }
        } catch (e) {
          console.warn("evalScript error:", e);
        }
        if (!resolved) {
          resolved = true;
          clearTimeout(timer);
          resolve(null);
        }
      });
    }
  };

  // src/host/host-detector.ts
  var StandaloneHostAdapter = class {
    async getProjectContext() {
      return {
        application: "standalone",
        applicationVersion: "1.0.0",
        projectSaved: false
      };
    }
    async revealInFinder(filePath) {
      console.log("Reveal in finder:", filePath);
    }
    async openFile(filePath) {
      console.log("Open file:", filePath);
    }
    async importToProject(filePath) {
      console.log("Import to project (standalone):", filePath);
      return false;
    }
    getHostTheme() {
      return "dark";
    }
    onThemeChanged(callback) {
    }
  };
  function createHostAdapter() {
    if (typeof window !== "undefined") {
      if (window.__adobe_cep__) {
        try {
          let hostId = "";
          const rawEnv = window.__adobe_cep__.getHostEnvironment();
          if (typeof rawEnv === "string") {
            try {
              const parsed = JSON.parse(rawEnv);
              hostId = (parsed.appId || "").toLowerCase();
            } catch {
            }
          } else if (rawEnv && typeof rawEnv === "object") {
            hostId = (rawEnv.appId || "").toLowerCase();
          }
          console.log("[HostDetector] Detected CEP host ID:", hostId);
          if (hostId === "ppro" || hostId.includes("premiere")) {
            return new PremiereHostAdapter();
          } else {
            return new AfterEffectsHostAdapter();
          }
        } catch (e) {
          console.warn("[HostDetector] Error reading CEP environment:", e);
          return new AfterEffectsHostAdapter();
        }
      }
      if (window.require) {
        try {
          const uxp = window.require("uxp");
          const host = uxp?.host;
          const hostName = (host?.name || "").toLowerCase();
          if (hostName.includes("premiere")) {
            return new PremiereHostAdapter();
          } else if (hostName.includes("aftereffects")) {
            return new AfterEffectsHostAdapter();
          }
        } catch {
        }
      }
    }
    return new StandaloneHostAdapter();
  }
  var hostAdapter = createHostAdapter();

  // src/ui/app.ts
  var MediaFetchApp = class {
    projectContext = {
      application: "standalone",
      applicationVersion: "1.0.0",
      projectSaved: false
    };
    currentMode = "video-audio";
    currentMetadata = null;
    currentPlaylist = null;
    queue = [];
    settings = null;
    history = [];
    isAnalyzing = false;
    analysisTimeout;
    pendingDownloadParams = null;
    toastTimeout = null;
    recentImportedPaths = /* @__PURE__ */ new Map();
    playlistCustomTargetDir = "";
    constructor() {
      this.init();
    }
    async init() {
      this.bindDomEvents();
      this.setupTheme();
      this.setupServiceClient();
      this.updateDropdownsForMode(this.currentMode);
      this.updateProjectStatusUI();
      this.autoStartServiceIfInCep();
      serviceClient.connect();
      setTimeout(() => {
        const urlInput = document.getElementById("url-input");
        urlInput?.focus();
      }, 100);
      this.refreshProjectContext();
      window.addEventListener("focus", () => this.refreshProjectContext());
    }
    async refreshProjectContext() {
      try {
        this.projectContext = await hostAdapter.getProjectContext();
        this.updateProjectStatusUI();
      } catch (e) {
        console.warn("Failed to resolve host project context:", e);
        this.updateProjectStatusUI();
      }
    }
    autoStartServiceIfInCep() {
      try {
        if (typeof window === "undefined") return;
        const nodeRequire = window.require || window.cep_node?.require || (typeof __require !== "undefined" ? __require : null);
        let proc = null;
        try {
          proc = typeof process !== "undefined" ? process : nodeRequire ? nodeRequire("process") : null;
        } catch {
        }
        const appData = proc?.env?.APPDATA || "";
        const localAppData = proc?.env?.LOCALAPPDATA || "";
        let extDir = "";
        try {
          if (window.__adobe_cep__?.getSystemPath) {
            extDir = window.__adobe_cep__.getSystemPath("extension");
          } else if (window.CSInterface) {
            extDir = new window.CSInterface().getSystemPath("extension");
          }
        } catch {
        }
        if (!extDir && typeof window.location !== "undefined" && window.location.pathname) {
          let p = window.location.pathname.replace(/^[\\\/]([A-Za-z]:)/, "$1");
          extDir = p.substring(0, Math.max(p.lastIndexOf("/"), p.lastIndexOf("\\")));
        }
        const candidatePaths = [
          extDir ? `${extDir}/service/server.bundle.js`.replace(/\//g, "\\") : "",
          extDir ? `${extDir}/service/server.js`.replace(/\//g, "\\") : "",
          appData ? `${appData}\\Adobe\\CEP\\extensions\\com.mediafetch.adobe\\service\\server.bundle.js` : "",
          appData ? `${appData}\\Adobe\\CEP\\extensions\\com.mediafetch.adobe\\service\\server.js` : "",
          appData ? `${appData}\\Adobe\\CEP\\extensions\\com.mediafetch.adobe.pro\\service\\server.bundle.js` : "",
          appData ? `${appData}\\Adobe\\CEP\\extensions\\com.mediafetch.adobe.pro\\service\\server.js` : "",
          localAppData ? `${localAppData}\\MediaFetch\\server.bundle.js` : "",
          localAppData ? `${localAppData}\\MediaFetch\\server.js` : ""
        ].filter(Boolean);
        const nodeExeCandidates = [
          "C:\\Program Files\\nodejs\\node.exe",
          "C:\\Program Files (x86)\\nodejs\\node.exe",
          "node"
        ];
        const startServiceScript = (scriptPath) => {
          if (nodeRequire) {
            try {
              nodeRequire(scriptPath);
              console.log(`[MediaFetch] In-process service started: ${scriptPath}`);
              setTimeout(() => serviceClient.connect(), 500);
              return true;
            } catch (e) {
              console.warn("[MediaFetch] In-process require failed, trying spawn:", e);
            }
            try {
              const cp = nodeRequire("child_process");
              for (const nodeExe of nodeExeCandidates) {
                try {
                  const child = cp.spawn(nodeExe, ["--max-old-space-size=48", "--optimize-for-size", scriptPath], {
                    detached: true,
                    stdio: "ignore",
                    windowsHide: true
                  });
                  child.unref();
                  console.log(`[MediaFetch] Daemon spawned with ${nodeExe}: ${scriptPath}`);
                  setTimeout(() => serviceClient.connect(), 800);
                  return true;
                } catch {
                }
              }
            } catch {
            }
          }
          if (window.cep?.process?.createProcess) {
            try {
              for (const nodeExe of nodeExeCandidates) {
                const res = window.cep.process.createProcess(nodeExe, scriptPath);
                if (res && res.err === 0) {
                  console.log(`[MediaFetch] CEP createProcess spawned daemon: ${nodeExe}`);
                  setTimeout(() => serviceClient.connect(), 800);
                  return true;
                }
              }
            } catch {
            }
          }
          return false;
        };
        if (nodeRequire) {
          try {
            const http = nodeRequire("http");
            const req = http.get("http://127.0.0.1:48923/health", (res) => {
              if (res.statusCode === 200) {
                console.log("[MediaFetch] Service already running on port 48923.");
                serviceClient.connect();
              }
            });
            req.on("error", () => {
              for (const scriptPath of candidatePaths) {
                if (startServiceScript(scriptPath)) break;
              }
            });
            return;
          } catch {
          }
        }
        for (const scriptPath of candidatePaths) {
          if (startServiceScript(scriptPath)) break;
        }
      } catch (e) {
        console.warn("[MediaFetch] autoStartService error:", e);
      }
    }
    setupTheme() {
      const applyTheme = (themeName) => {
        document.body.classList.remove("theme-light", "theme-darkest");
        if (themeName === "light" || themeName === "lightest") {
          document.body.classList.add("theme-light");
        } else if (themeName === "darkest") {
          document.body.classList.add("theme-darkest");
        }
      };
      hostAdapter.onThemeChanged((theme) => {
        if (this.settings?.general.theme === "host") {
          applyTheme(theme);
        }
      });
      const initialHostTheme = hostAdapter.getHostTheme();
      applyTheme(initialHostTheme);
    }
    showHeaderToast(message, durationMs = 6e3) {
      const toast = document.getElementById("header-alert-toast");
      const textEl = document.getElementById("header-alert-text");
      if (!toast || !textEl) return;
      if (this.toastTimeout) {
        clearTimeout(this.toastTimeout);
        this.toastTimeout = null;
      }
      textEl.textContent = message;
      toast.style.display = "flex";
      this.toastTimeout = setTimeout(() => {
        toast.style.display = "none";
        this.toastTimeout = null;
      }, durationMs);
    }
    dismissHeaderToast() {
      const toast = document.getElementById("header-alert-toast");
      if (toast) toast.style.display = "none";
      if (this.toastTimeout) {
        clearTimeout(this.toastTimeout);
        this.toastTimeout = null;
      }
    }
    dismissHeaderToastIf(keyword) {
      const textEl = document.getElementById("header-alert-text");
      if (textEl && textEl.textContent && textEl.textContent.includes(keyword)) {
        this.dismissHeaderToast();
      }
    }
    pendingFolderCallback = null;
    selectFolderModern(callback) {
      try {
        const cepFs = window.cep?.fs;
        if (cepFs && typeof cepFs.showOpenDialogEx === "function") {
          const res = cepFs.showOpenDialogEx(false, true, "Select MediaFetch Destination Folder", "", []);
          if (res && res.data && res.data.length > 0 && res.data[0]) {
            callback(res.data[0]);
            return;
          } else if (res && Array.isArray(res.data)) {
            return;
          }
        }
        if (cepFs && typeof cepFs.showOpenDialog === "function") {
          const res = cepFs.showOpenDialog(false, true, "Select MediaFetch Destination Folder", "", []);
          if (res && res.data && res.data.length > 0 && res.data[0]) {
            callback(res.data[0]);
            return;
          } else if (res && Array.isArray(res.data)) {
            return;
          }
        }
      } catch (e) {
        console.warn("[MediaFetch] CEP showOpenDialog failed:", e);
      }
      try {
        if (this.csInterface && typeof this.csInterface.evalScript === "function") {
          this.csInterface.evalScript("selectDownloadFolder()", (res) => {
            const cleaned = (res || "").trim();
            if (cleaned && cleaned !== "undefined" && cleaned !== "null" && cleaned !== "false") {
              callback(cleaned);
            }
          });
          return;
        }
      } catch (e) {
        console.warn("[MediaFetch] ExtendScript selectDownloadFolder failed:", e);
      }
      this.pendingFolderCallback = callback;
      serviceClient.openFolderDialog();
    }
    updateProjectStatusUI() {
      const label = document.getElementById("project-status-label");
      const targetDirDisplay = document.getElementById("target-dir-display");
      if (!label) return;
      const pName = this.projectContext.projectName;
      const isSaved = this.projectContext.projectSaved && this.projectContext.projectDirectory;
      const appName = this.projectContext.application;
      if (pName && pName !== "standalone" && pName !== "Unknown") {
        label.textContent = `Project: ${pName}${isSaved ? "" : " (Active)"}`;
        label.title = isSaved ? this.projectContext.projectDirectory : "Active Project - Downloads route to default MediaFetch folder";
        if (targetDirDisplay) {
          targetDirDisplay.textContent = isSaved ? `Target: ${this.projectContext.projectDirectory}\\MediaFetch\\` : "Target: Downloads\\MediaFetch\\";
        }
      } else if (isSaved) {
        label.textContent = `Project: ${this.projectContext.projectName || "Active"}`;
        label.title = this.projectContext.projectDirectory;
        if (targetDirDisplay) {
          targetDirDisplay.textContent = `Target: ${this.projectContext.projectDirectory}\\MediaFetch\\`;
        }
      } else {
        const hostLabel = appName && appName !== "standalone" ? `${appName === "premierepro" ? "Premiere Pro" : "After Effects"} (Active)` : "Active / Default Bin";
        label.textContent = `Project: ${hostLabel}`;
        label.title = "Downloads saved to Downloads\\MediaFetch and auto-imported into host project";
        if (targetDirDisplay) {
          targetDirDisplay.textContent = "Target: Downloads\\MediaFetch\\";
        }
      }
    }
    checkUrlForPlatform(url) {
      const isSpotify = /spotify\.(?:com|link)/i.test(url);
      const videoAudioBtn = document.getElementById("mode-video-audio");
      const videoOnlyBtn = document.getElementById("mode-video-only");
      if (isSpotify) {
        if (videoAudioBtn) videoAudioBtn.style.display = "none";
        if (videoOnlyBtn) videoOnlyBtn.style.display = "none";
        if (this.currentMode === "video-audio" || this.currentMode === "video-only") {
          this.updateDropdownsForMode("audio-only");
        }
      } else {
        if (videoAudioBtn) videoAudioBtn.style.display = "inline-flex";
        if (videoOnlyBtn) videoOnlyBtn.style.display = "inline-flex";
      }
    }
    updateDropdownsForMode(mode) {
      this.currentMode = mode;
      document.querySelectorAll(".mode-icon-group .segment-icon-btn, .segment-btn[data-mode]").forEach((btn) => {
        const bMode = btn.getAttribute("data-mode");
        if (bMode === mode) {
          btn.classList.add("active");
        } else {
          btn.classList.remove("active");
        }
      });
      const badge = document.getElementById("current-mode-badge");
      if (badge) {
        if (mode === "audio-only") {
          badge.textContent = "\u{1F3B5} Audio Only";
          badge.style.background = "#8e44ad";
        } else if (mode === "video-only") {
          badge.textContent = "\u{1F4F9} Video Only";
          badge.style.background = "#d35400";
        } else if (mode === "image") {
          badge.textContent = "\u{1F5BC}\uFE0F Photo / Cover";
          badge.style.background = "#27ae60";
        } else {
          badge.textContent = "\u{1F3AC} Video + Audio";
          badge.style.background = "#1473e6";
        }
      }
      const profileSelect = document.getElementById("profile-select");
      const formatSelect = document.getElementById("format-select");
      const formatGroup = document.getElementById("format-select-group");
      const formatLabel = document.getElementById("format-select-label");
      if (!profileSelect || !formatSelect) return;
      profileSelect.innerHTML = "";
      formatSelect.innerHTML = "";
      if (mode === "image") {
        if (formatSelect) {
          formatSelect.disabled = false;
          formatSelect.title = "";
        }
        if (formatGroup) {
          formatGroup.style.opacity = "1";
          formatGroup.style.pointerEvents = "auto";
        }
        if (formatLabel) formatLabel.textContent = "Format / Container";
        profileSelect.appendChild(new Option("\u{1F5BC}\uFE0F Original Thumbnail (Max Resolution / Ultra HD)", "image-orig", true, true));
        profileSelect.appendChild(new Option("\u{1F5BC}\uFE0F Full HD Cover Art (1080p)", "image-1080p"));
        profileSelect.appendChild(new Option("\u{1F5BC}\uFE0F WebP Cover Art (Compact)", "image-webp"));
        profileSelect.appendChild(new Option("\u{1F5BC}\uFE0F Lossless PNG Cover Art", "image-png"));
        formatSelect.appendChild(new Option("JPG Image", "jpg", true, true));
        formatSelect.appendChild(new Option("PNG Image", "png"));
        formatSelect.appendChild(new Option("WEBP Image", "webp"));
      } else if (mode === "audio-only") {
        if (formatSelect) {
          formatSelect.disabled = true;
          formatSelect.title = "Format is automatically determined by your selected Quality Profile.";
        }
        if (formatGroup) {
          formatGroup.style.opacity = "0.45";
          formatGroup.style.pointerEvents = "none";
        }
        if (formatLabel) formatLabel.textContent = "Format / Container (Auto-locked by Quality Profile)";
        profileSelect.appendChild(new Option("\u{1F3B5} Best Audio Quality (Auto)", "best-audio", true, true));
        profileSelect.appendChild(new Option("\u{1F3B5} MP3 Studio Master (320 kbps High Quality)", "audio-mp3-320"));
        profileSelect.appendChild(new Option("\u{1F3B5} MP3 Standard (192 kbps)", "audio-mp3-192"));
        profileSelect.appendChild(new Option("\u{1F3B5} MP3 Data Saver / Low Compressed (128 kbps)", "audio-mp3-128"));
        profileSelect.appendChild(new Option("\u{1F3B5} M4A (AAC 256 kbps)", "audio-m4a"));
        profileSelect.appendChild(new Option("\u{1F3B5} WAV (Uncompressed Studio Audio 1411 kbps)", "audio-wav"));
        profileSelect.appendChild(new Option("\u{1F3B5} FLAC (Lossless Audio)", "audio-flac"));
        profileSelect.appendChild(new Option("\u{1F3B5} Audio Only (Native Stream)", "audio-only"));
        formatSelect.appendChild(new Option("MP3 (Auto from Profile)", "mp3", true, true));
        formatSelect.appendChild(new Option("M4A (Auto from Profile)", "m4a"));
        formatSelect.appendChild(new Option("WAV (Auto from Profile)", "wav"));
        formatSelect.appendChild(new Option("FLAC (Auto from Profile)", "flac"));
        profileSelect.onchange = () => {
          const pVal = profileSelect.value;
          if (pVal === "audio-wav") formatSelect.value = "wav";
          else if (pVal === "audio-flac") formatSelect.value = "flac";
          else if (pVal === "audio-m4a") formatSelect.value = "m4a";
          else formatSelect.value = "mp3";
        };
      } else if (mode === "video-only") {
        if (formatSelect) {
          formatSelect.disabled = false;
          formatSelect.title = "";
        }
        if (formatGroup) {
          formatGroup.style.opacity = "1";
          formatGroup.style.pointerEvents = "auto";
        }
        if (formatLabel) formatLabel.textContent = "Format / Container";
        profileSelect.appendChild(new Option("\u{1F4F9} 1080p Full HD (1080p) \u2022 Recommended (Fast & Balanced)", "video-1080p", true, true));
        profileSelect.appendChild(new Option("\u{1F4F9} Best Video Only (Auto-Optimized)", "video-only"));
        profileSelect.appendChild(new Option("\u{1F4F9} 4K Ultra HD (2160p) \u2022 Studio Master (Slower \u2022 Largest File)", "video-4k"));
        profileSelect.appendChild(new Option("\u{1F4F9} 1440p Quad HD (2K) \u2022 High Quality (Moderate Speed)", "video-1440p"));
        profileSelect.appendChild(new Option("\u{1F4F9} 720p HD (720p) \u2022 Very Fast (Light File)", "video-720p"));
        profileSelect.appendChild(new Option("\u{1F4F9} 480p SD \u2022 Super Fast / Instant (Small File)", "video-480p"));
        formatSelect.appendChild(new Option("MP4 (H.264 / AAC - Recommended for Adobe)", "mp4", true, true));
        formatSelect.appendChild(new Option("MOV (QuickTime)", "mov"));
        formatSelect.appendChild(new Option("MKV (Matroska)", "mkv"));
        formatSelect.appendChild(new Option("WEBM (VP9 / Opus)", "webm"));
      } else {
        if (formatSelect) {
          formatSelect.disabled = false;
          formatSelect.title = "";
        }
        if (formatGroup) {
          formatGroup.style.opacity = "1";
          formatGroup.style.pointerEvents = "auto";
        }
        if (formatLabel) formatLabel.textContent = "Format / Container";
        profileSelect.appendChild(new Option("\u{1F3AC} 1080p Full HD (1080p) \u2022 Recommended (Fast & Balanced)", "video-1080p", true, true));
        profileSelect.appendChild(new Option("\u{1F3AC} Best Available Quality (Auto-Optimized)", "best-available"));
        profileSelect.appendChild(new Option("\u{1F3AC} 4K Ultra HD (2160p) \u2022 Studio Master (Slower \u2022 Largest File)", "video-4k"));
        profileSelect.appendChild(new Option("\u{1F3AC} 1440p Quad HD (2K) \u2022 High Quality (Moderate Speed)", "video-1440p"));
        profileSelect.appendChild(new Option("\u{1F3AC} 720p HD (720p) \u2022 Very Fast (Light File)", "video-720p"));
        profileSelect.appendChild(new Option("\u{1F3AC} 480p SD \u2022 Super Fast / Instant (Small File)", "video-480p"));
        formatSelect.appendChild(new Option("MP4 (H.264 / AAC - Recommended for Adobe)", "mp4", true, true));
        formatSelect.appendChild(new Option("MOV (Apple ProRes / QuickTime)", "mov"));
        formatSelect.appendChild(new Option("MKV (Matroska)", "mkv"));
        formatSelect.appendChild(new Option("WEBM (VP9 / Opus)", "webm"));
      }
    }
    setupServiceClient() {
      serviceClient.onStatusChanged((online) => {
        const dot = document.getElementById("connection-dot");
        if (dot) {
          dot.className = `connection-dot ${online ? "online" : "offline"}`;
          dot.title = online ? "MediaFetch service connected (Port 48923)" : "Service offline (Click Diagnostics to check)";
        }
      });
      serviceClient.subscribe((msg) => {
        switch (msg.type) {
          case "ANALYSIS_STARTED":
            this.setAnalysisLoading(true);
            break;
          case "ANALYSIS_SUCCESS":
          case "METADATA_RESULT":
            this.setAnalysisLoading(false);
            if (msg.payload?.isPlaylist || msg.payload?.isCarousel) {
              this.renderPlaylistModal(msg.payload);
            } else {
              this.renderMediaCard(msg.payload);
            }
            break;
          case "ANALYSIS_ERROR":
          case "ANALYSIS_FAILED":
            this.setAnalysisLoading(false);
            this.showUrlError(`${msg.payload.error || "Media analysis failed"} (${msg.payload.category || "ERROR"})`);
            break;
          case "PLAYLIST_ANALYSIS_SUCCESS":
          case "PLAYLIST_METADATA_RESULT":
            this.setAnalysisLoading(false);
            this.renderPlaylistModal(msg.payload);
            break;
          case "PLAYLIST_ANALYSIS_ERROR":
          case "PLAYLIST_ANALYSIS_FAILED":
            this.setAnalysisLoading(false);
            this.showUrlError(`Playlist extraction failed: ${msg.payload.error}`);
            break;
          case "QUEUE_UPDATED":
            this.queue = msg.payload;
            this.renderQueue();
            break;
          case "DOWNLOAD_PROGRESS": {
            const idx = this.queue.findIndex((i) => i.id === msg.payload.id);
            if (idx >= 0) {
              this.queue[idx] = msg.payload.item;
              this.updateQueueItemDOM(msg.payload.item);
            }
            break;
          }
          case "DOWNLOAD_COMPLETED": {
            const itemEdition = msg.payload.item?.edition || msg.payload.historyEntry?.edition;
            const isPro = window.__MF_EDITION__ === "pro" || window.location.pathname.includes(".pro") || document.title.includes("Pro");
            const myEdition = isPro ? "pro" : "standard";
            if (itemEdition && itemEdition !== myEdition) {
              break;
            }
            const idx = this.queue.findIndex((i) => i.id === msg.payload.id);
            if (idx >= 0) {
              this.queue[idx] = msg.payload.item;
              this.updateQueueItemDOM(msg.payload.item);
            }
            const targetFilePath = msg.payload.item?.outputPath || msg.payload.item?.downloadedPath || msg.payload.historyEntry?.outputPath;
            const mainAutoImportChk = document.getElementById("main-auto-import-chk");
            const autoImportEnabled = mainAutoImportChk ? mainAutoImportChk.checked : this.settings?.general?.autoImportToProject ?? true;
            const isZip = Boolean(msg.payload.item?.zipPackage || msg.payload.item?.metadata?.zipPackage);
            const itemAutoImport = !isZip && msg.payload.item?.autoImport !== false && msg.payload.item?.metadata?.autoImport !== false;
            if (targetFilePath && autoImportEnabled && itemAutoImport) {
              const now = Date.now();
              const lastImportTime = this.recentImportedPaths.get(targetFilePath) || 0;
              if (now - lastImportTime < 5e3) {
                console.log("[MediaFetch] Skipping duplicate auto-import for recently imported file:", targetFilePath);
                break;
              }
              this.recentImportedPaths.set(targetFilePath, now);
              const item = msg.payload.item;
              const isCustomLocation = this.settings?.downloads?.downloadLocationMode === "custom" || Boolean(item?.targetDirectory);
              const isCloud = Boolean(item?.isCloud || item?.metadata?.isCloud || item?.customFolderName?.toLowerCase().includes("cloud") || item?.metadata?.uploader?.toLowerCase().includes("cloud"));
              const isPlaylist = Boolean(item?.isPlaylist || item?.metadata?.isPlaylist || item?.playlistTitle);
              const playlistTitle = item?.playlistTitle || item?.metadata?.playlistTitle || "";
              const customFolderName = item?.customFolderName || item?.metadata?.customFolderName || "";
              const subFolderName = item?.subFolderName || item?.metadata?.subFolderName || "";
              console.log("[MediaFetch] Triggering auto-import into Adobe project bin:", targetFilePath, { isCustomLocation, isCloud, isPlaylist, playlistTitle, customFolderName, subFolderName });
              hostAdapter.importToProject(targetFilePath, {
                isCustomPath: isCustomLocation,
                isCloud,
                isPlaylist,
                playlistTitle,
                customFolderName,
                subFolderName,
                insertToTimeline: false
              }).then((success) => {
                console.log("[MediaFetch] Auto-import completed with status:", success);
              }).catch((err) => {
                console.warn("[MediaFetch] Auto-import error:", err);
              });
            }
            break;
          }
          case "DOWNLOAD_FAILED": {
            const idx = this.queue.findIndex((i) => i.id === msg.payload.id);
            if (idx >= 0) {
              this.queue[idx] = msg.payload.item;
              this.updateQueueItemDOM(msg.payload.item);
            }
            break;
          }
          case "SETTINGS_LOADED":
            this.settings = msg.payload;
            this.populateSettingsForm(msg.payload);
            break;
          case "DIAGNOSTICS_RESULT":
            this.renderDiagnostics(msg.payload);
            this.updateSetupWizardStatus(msg.payload);
            break;
          case "HISTORY_LOADED":
            this.history = msg.payload;
            this.renderHistoryList();
            break;
          case "DUPLICATE_CHECK_RESULT":
            if (msg.payload.exists && this.pendingDownloadParams) {
              this.showDuplicateModal(msg.payload.existingFilePath || "");
            } else if (this.pendingDownloadParams) {
              this.executePendingDownload();
            }
            break;
          case "DEPENDENCY_INSTALL_PROGRESS":
            this.showInstallProgress(msg.payload);
            break;
          case "DEPENDENCY_INSTALL_RESULT":
            this.handleInstallResult(msg.payload);
            break;
          case "ZIP_PACKAGE_COMPLETED": {
            const zipPath = msg.payload?.zipPath || msg.zipPath;
            if (zipPath) {
              const fileName = zipPath.split(/[\\\/]/).pop();
              this.showHeaderToast(`\u{1F4E6} ZIP Archive created: ${fileName}`, 7e3);
            }
            break;
          }
          case "FOLDER_SELECTED": {
            const folder = msg.payload?.folderPath;
            if (folder && this.pendingFolderCallback) {
              this.pendingFolderCallback(folder);
              this.pendingFolderCallback = null;
            }
            break;
          }
        }
      });
    }
    bindDomEvents() {
      const urlInput = document.getElementById("url-input");
      const onUrlChanged = (val) => {
        const trimmed = (val || "").trim();
        if (this.currentMetadata && this.currentMetadata.url !== trimmed && this.currentMetadata.webpage_url !== trimmed) {
          this.currentMetadata = null;
          const cardSection = document.getElementById("media-card-section");
          if (cardSection) cardSection.style.display = "none";
        }
        this.checkUrlForPlatform(trimmed);
      };
      urlInput?.addEventListener("input", (e) => onUrlChanged(e.target.value));
      urlInput?.addEventListener("paste", () => setTimeout(() => onUrlChanged(urlInput?.value || ""), 50));
      document.querySelectorAll(".mode-icon-group .segment-icon-btn, .segment-btn[data-mode]").forEach((btn) => {
        btn.addEventListener("click", (e) => {
          document.querySelectorAll(".mode-icon-group .segment-icon-btn, .segment-btn[data-mode]").forEach((b) => b.classList.remove("active"));
          const target = e.currentTarget;
          target.classList.add("active");
          const mode = target.getAttribute("data-mode") || "video-audio";
          this.updateDropdownsForMode(mode);
        });
      });
      const cardFormatSelect = document.getElementById("format-select");
      cardFormatSelect?.addEventListener("change", () => {
        const val = (cardFormatSelect.value || "").toLowerCase();
        if (["mp4", "mov", "mkv", "webm"].includes(val)) {
          if (this.currentMode === "audio-only") {
            this.updateDropdownsForMode("video-audio");
          }
        } else if (["mp3", "wav", "m4a", "flac"].includes(val)) {
          if (this.currentMode === "video-audio" || this.currentMode === "video-only") {
            this.updateDropdownsForMode("audio-only");
          }
        }
      });
      const cardProfileSelect = document.getElementById("profile-select");
      cardProfileSelect?.addEventListener("change", () => {
        const pVal = cardProfileSelect.value || "";
        const is4K = pVal === "res-2160" || pVal === "video-4k" || pVal.includes("2160");
        if (is4K) {
          this.showHeaderToast(
            "\u26A1 4K Ultra HD selected: Studio quality master. Note: 4K files take a bit longer to download and optimize.",
            4500
          );
        } else {
          this.dismissHeaderToastIf("4K");
        }
      });
      document.getElementById("btn-close-header-alert")?.addEventListener("click", () => {
        this.dismissHeaderToast();
      });
      document.getElementById("setting-location-mode")?.addEventListener("change", () => {
        this.updateDownloadLocationModeUI();
      });
      document.getElementById("btn-browse-custom-location")?.addEventListener("click", () => {
        const modeSel = document.getElementById("setting-location-mode");
        if (modeSel && modeSel.value !== "custom") {
          modeSel.value = "custom";
          this.updateDownloadLocationModeUI();
        }
        this.selectFolderModern((folderPath) => {
          const input = document.getElementById("setting-custom-location");
          if (input) input.value = folderPath;
          if (modeSel) modeSel.value = "custom";
          this.updateDownloadLocationModeUI();
        });
      });
      document.getElementById("target-dir-display")?.addEventListener("click", () => {
        this.selectFolderModern((folderPath) => {
          serviceClient.updateSettings({
            downloads: {
              ...this.settings?.downloads,
              downloadLocationMode: "custom",
              customLocation: folderPath
            }
          });
          const targetDirDisplay = document.getElementById("target-dir-display");
          if (targetDirDisplay) {
            targetDirDisplay.textContent = `Target: ${folderPath}`;
          }
          const customLocInput = document.getElementById("setting-custom-location");
          if (customLocInput) customLocInput.value = folderPath;
          const modeSel = document.getElementById("setting-location-mode");
          if (modeSel) modeSel.value = "custom";
          this.updateDownloadLocationModeUI();
        });
      });
      document.getElementById("btn-analyze")?.addEventListener("click", () => this.handleAnalyze());
      urlInput?.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
          this.handleAnalyze();
        }
      });
      document.getElementById("btn-paste")?.addEventListener("click", async () => {
        await this.handlePasteAction();
        onUrlChanged(urlInput?.value || "");
      });
      document.getElementById("btn-paste-url")?.addEventListener("click", async () => {
        await this.handlePasteAction();
        onUrlChanged(urlInput?.value || "");
      });
      document.getElementById("btn-close-card")?.addEventListener("click", () => {
        const card = document.getElementById("media-card-section");
        if (card) card.style.display = "none";
        this.currentMetadata = null;
      });
      document.getElementById("btn-download-action")?.addEventListener("click", async () => {
        await this.refreshProjectContext();
        this.handleDownloadClick();
      });
      document.getElementById("btn-resume-all")?.addEventListener("click", () => {
        let count = 0;
        for (const item of this.queue) {
          if (item.status === "paused" || item.status === "failed" || item.status === "downloading") {
            serviceClient.resumeDownload(item.id);
            count++;
          }
        }
        serviceClient.send({ type: "RESUME_DOWNLOAD", payload: {} });
      });
      document.getElementById("btn-clear-completed")?.addEventListener("click", () => {
        serviceClient.clearCompleted();
        this.queue = this.queue.filter((i) => i.status === "downloading" || i.status === "waiting");
        this.renderQueue();
      });
      const queueContainer = document.getElementById("queue-container");
      queueContainer?.addEventListener("click", (e) => {
        const btn = e.target.closest("button");
        if (!btn) return;
        const itemEl = btn.closest(".queue-item");
        const itemId = itemEl?.id?.replace("q-item-", "");
        if (!itemId) return;
        if (btn.classList.contains("btn-pause")) {
          serviceClient.pauseDownload(itemId);
        } else if (btn.classList.contains("btn-resume")) {
          serviceClient.resumeDownload(itemId);
        } else if (btn.classList.contains("btn-cancel")) {
          serviceClient.cancelDownload(itemId);
          this.queue = this.queue.filter((i) => i.id !== itemId);
          this.renderQueue();
        } else if (btn.classList.contains("btn-retry")) {
          serviceClient.retryDownload(itemId);
        } else if (btn.classList.contains("btn-reveal")) {
          const item = this.queue.find((i) => i.id === itemId);
          if (item?.outputPath) hostAdapter.revealInFinder(item.outputPath);
        } else if (btn.classList.contains("btn-import")) {
          const item = this.queue.find((i) => i.id === itemId);
          if (item?.outputPath) {
            const isCustomLocation = this.settings?.downloads?.downloadLocationMode === "custom" || Boolean(item?.targetDirectory);
            const isCloud = Boolean(item?.isCloud || item?.metadata?.isCloud || item?.customFolderName?.toLowerCase().includes("cloud") || item?.metadata?.uploader?.toLowerCase().includes("cloud"));
            const isPlaylist = Boolean(item?.isPlaylist || item?.metadata?.isPlaylist || item?.playlistTitle);
            hostAdapter.importToProject(item.outputPath, {
              isCustomPath: isCustomLocation,
              isCloud,
              isPlaylist,
              playlistTitle: item?.playlistTitle || item?.metadata?.playlistTitle || "",
              customFolderName: item?.customFolderName || item?.metadata?.customFolderName || "",
              subFolderName: item?.subFolderName || item?.metadata?.subFolderName || ""
            });
          }
        }
      });
      const openUnifiedSettings = () => {
        serviceClient.getSettings();
        serviceClient.getDiagnostics();
        if (typeof window.Settings !== "undefined") {
          const s = window.Settings.load();
          const pexelsInput = document.getElementById("setting-studio-pexels-key");
          const pixabayInput = document.getElementById("setting-studio-pixabay-key");
          const unsplashInput = document.getElementById("setting-studio-unsplash-key");
          const giphyInput = document.getElementById("setting-studio-giphy-key");
          const timelineCheck = document.getElementById("setting-studio-auto-timeline");
          if (pexelsInput) pexelsInput.value = s.pexelsApiKey || "";
          if (pixabayInput) pixabayInput.value = s.pixabayApiKey || "";
          if (unsplashInput) unsplashInput.value = s.unsplashApiKey || "";
          if (giphyInput) giphyInput.value = s.giphyApiKey || "";
          if (timelineCheck) timelineCheck.checked = s.autoInsertTimeline !== false;
        }
        if (typeof window.MediaFetchLicense?.updateBadge === "function") {
          window.MediaFetchLicense.updateBadge();
        }
        this.openModal("modal-settings");
      };
      document.getElementById("btn-top-settings")?.addEventListener("click", openUnifiedSettings);
      document.getElementById("btn-settings")?.addEventListener("click", openUnifiedSettings);
      document.getElementById("btn-history")?.addEventListener("click", () => {
        serviceClient.getHistory();
        this.openModal("modal-history");
      });
      document.getElementById("btn-diagnostics")?.addEventListener("click", () => {
        serviceClient.getDiagnostics();
        this.openModal("modal-diagnostics");
      });
      document.getElementById("btn-setup-wizard-trigger")?.addEventListener("click", () => {
        this.closeModal("modal-diagnostics");
        this.openModal("modal-setup");
        serviceClient.runSystemCheck();
      });
      document.querySelectorAll(".modal-close-btn").forEach((btn) => {
        btn.addEventListener("click", (e) => {
          const overlay = e.target.closest(".modal-overlay");
          if (overlay) overlay.classList.remove("active");
        });
      });
      document.querySelectorAll(".tab-btn").forEach((btn) => {
        btn.addEventListener("click", (e) => {
          const targetTab = e.currentTarget.getAttribute("data-tab");
          document.querySelectorAll(".tab-btn").forEach((b) => b.classList.remove("active"));
          document.querySelectorAll(".tab-pane").forEach((p) => p.style.display = "none");
          e.currentTarget.classList.add("active");
          if (targetTab) {
            const pane = document.getElementById(targetTab);
            if (pane) pane.style.display = "block";
          }
        });
      });
      document.getElementById("btn-save-settings")?.addEventListener("click", () => {
        this.saveSettingsFromForm();
        this.closeModal("modal-settings");
      });
      document.getElementById("btn-update-ytdlp")?.addEventListener("click", () => {
        const btn = document.getElementById("btn-update-ytdlp");
        const statusEl = document.getElementById("engine-update-status");
        if (btn) {
          btn.disabled = true;
          btn.textContent = "\u23F3 Checking for updates...";
        }
        if (statusEl) {
          statusEl.style.display = "block";
          statusEl.style.color = "var(--text-secondary, #aaa)";
          statusEl.textContent = "Connecting to official yt-dlp repository...";
        }
        serviceClient.updateYtDlp();
      });
      document.getElementById("btn-setup-install-all")?.addEventListener("click", () => {
        const progRow = document.getElementById("setup-progress-row");
        if (progRow) progRow.style.display = "flex";
        serviceClient.installDependency("all");
      });
      document.getElementById("btn-dup-cancel")?.addEventListener("click", () => {
        this.pendingDownloadParams = null;
        this.closeModal("modal-duplicate");
      });
      document.getElementById("btn-dup-use-existing")?.addEventListener("click", () => {
        this.pendingDownloadParams = null;
        this.closeModal("modal-duplicate");
      });
      document.getElementById("btn-dup-download-new")?.addEventListener("click", () => {
        this.closeModal("modal-duplicate");
        this.executePendingDownload();
      });
      document.getElementById("btn-playlist-select-all")?.addEventListener("click", () => {
        document.querySelectorAll(".playlist-checkbox").forEach((cb) => cb.checked = true);
        this.updatePlaylistSelectedCount();
      });
      document.getElementById("btn-playlist-deselect-all")?.addEventListener("click", () => {
        document.querySelectorAll(".playlist-checkbox").forEach((cb) => cb.checked = false);
        this.updatePlaylistSelectedCount();
      });
      document.querySelectorAll('input[name="playlist-mode"]').forEach((r) => {
        r.addEventListener("change", (e) => {
          const val = e.target.value;
          const wrapper = document.getElementById("playlist-items-wrapper");
          if (wrapper) {
            wrapper.style.display = val === "selected" ? "block" : "none";
          }
          if (val === "all") {
            document.querySelectorAll(".playlist-checkbox").forEach((cb) => cb.checked = true);
          }
          this.updatePlaylistSelectedCount();
        });
      });
      document.getElementById("btn-playlist-confirm-download")?.addEventListener("click", () => {
        this.handlePlaylistDownloadSubmit();
      });
      document.getElementById("btn-playlist-browse-folder")?.addEventListener("click", () => {
        this.selectFolderModern((folderPath) => {
          this.playlistCustomTargetDir = folderPath;
          const pathEl = document.getElementById("playlist-destination-path");
          if (pathEl) pathEl.textContent = folderPath;
        });
      });
      const zipCb = document.getElementById("playlist-zip-package-cb");
      const autoImportCb = document.getElementById("playlist-auto-import-cb");
      const autoImportLabel = autoImportCb?.closest("label");
      zipCb?.addEventListener("change", () => {
        if (zipCb.checked) {
          if (autoImportCb) {
            autoImportCb.checked = false;
            autoImportCb.disabled = true;
          }
          if (autoImportLabel) {
            autoImportLabel.style.opacity = "0.45";
            autoImportLabel.title = "Auto-import is disabled when packaging as ZIP archive";
          }
        } else {
          if (autoImportCb) {
            autoImportCb.disabled = false;
          }
          if (autoImportLabel) {
            autoImportLabel.style.opacity = "1";
            autoImportLabel.title = "";
          }
        }
      });
      autoImportCb?.addEventListener("change", () => {
        if (autoImportCb.checked && zipCb) {
          zipCb.checked = false;
        }
      });
      document.getElementById("btn-close-media-preview")?.addEventListener("click", () => {
        this.closeMediaPreview();
      });
      const toggleTrimBtn = document.getElementById("btn-toggle-trim");
      if (toggleTrimBtn) {
        toggleTrimBtn.onclick = (e) => {
          if (typeof window.toggleTrimPanel === "function") {
            window.toggleTrimPanel(e);
          }
        };
      }
      document.querySelectorAll(".modal-overlay").forEach((overlay) => {
        overlay.addEventListener("click", (e) => {
          if (e.target === overlay) {
            const id = overlay.id;
            if (id === "modal-media-preview") {
              this.closeMediaPreview();
            } else {
              this.closeModal(id);
            }
          }
        });
      });
      document.getElementById("btn-clear-history")?.addEventListener("click", () => {
        serviceClient.clearHistory();
      });
      document.getElementById("history-search-input")?.addEventListener("input", (e) => {
        const query = e.target.value;
        this.renderHistoryList(query);
      });
    }
    closeCard() {
      const card = document.getElementById("media-card-section");
      if (card) card.style.display = "none";
      this.currentMetadata = null;
    }
    async handlePasteAction() {
      const urlInput = document.getElementById("url-input");
      if (!urlInput) return;
      try {
        if (navigator.clipboard && navigator.clipboard.readText) {
          const text = await navigator.clipboard.readText();
          if (text && text.trim().length > 0) {
            urlInput.value = text.trim();
            this.hideUrlError();
            return;
          }
        }
      } catch {
      }
      try {
        urlInput.focus();
        urlInput.select();
        const success = document.execCommand("paste");
        if (success && urlInput.value) {
          this.hideUrlError();
          return;
        }
      } catch {
      }
      urlInput.focus();
      this.showUrlError("Press Ctrl+V to paste into the URL box.");
    }
    isCloudUrl(url) {
      if (!url) return false;
      const lower = url.toLowerCase();
      return lower.includes("drive.google.com") || lower.includes("dropbox.com") || lower.includes("1drv.ms") || lower.includes("onedrive.live.com") || lower.includes("sharepoint.com") || lower.includes("box.com") || lower.includes("mega.nz") || lower.includes("wetransfer.com") || lower.includes("mediafire.com") || lower.includes("icloud.com");
    }
    isPlaylistUrl(url) {
      const lower = (url || "").toLowerCase();
      return lower.includes("list=") || lower.includes("/playlist") || lower.includes("/sets/") || lower.includes("/album/") || lower.includes("spotify.") && (lower.includes("/playlist/") || lower.includes("/album/") || lower.includes("/artist/")) || lower.includes("pinterest.") && lower.includes("/boards/") || lower.includes("instagram.com/p/") || lower.includes("instagram.com/reel/") || lower.includes("instagram.com/reels/") || lower.includes("instagram.com/stories/");
    }
    handleAnalyze() {
      const input = document.getElementById("url-input");
      const url = input?.value?.trim();
      this.hideUrlError();
      if (!url) {
        this.showUrlError("Please enter or paste a valid media URL.");
        return;
      }
      if (this.isCloudUrl(url)) {
        this.showUrlError("Cloud storage links (Google Drive, Dropbox, OneDrive, Mega) are exclusive to MediaFetch Pro. Upgrade to MediaFetch Pro to download cloud files and folders.");
        return;
      }
      this.setAnalysisLoading(true);
      if (this.analysisTimeout) clearTimeout(this.analysisTimeout);
      this.analysisTimeout = window.setTimeout(() => {
        if (this.isAnalyzing) {
          this.setAnalysisLoading(false);
          this.showUrlError("Analysis timed out. You can still click Download to Project directly.");
        }
      }, 6e4);
      if (this.isPlaylistUrl(url)) {
        serviceClient.analyzePlaylist(url);
        return;
      }
      serviceClient.analyzeUrl(url);
    }
    setAnalysisLoading(loading) {
      this.isAnalyzing = loading;
      if (!loading && this.analysisTimeout) {
        clearTimeout(this.analysisTimeout);
        this.analysisTimeout = void 0;
      }
      const btn = document.getElementById("btn-analyze");
      const text = document.getElementById("analyze-btn-text");
      if (btn) {
        btn.disabled = loading;
      }
      if (text) {
        text.textContent = loading ? "Analyzing\u2026" : "\u{1F50D} Analyze";
      }
    }
    showUrlError(msg) {
      const el = document.getElementById("url-error-msg");
      if (el) {
        el.textContent = msg;
        el.style.display = "block";
      }
    }
    hideUrlError() {
      const el = document.getElementById("url-error-msg");
      if (el) {
        el.style.display = "none";
        el.textContent = "";
      }
    }
    renderMediaCard(meta) {
      this.currentMetadata = meta;
      const cardSection = document.getElementById("media-card-section");
      if (!cardSection) return;
      cardSection.style.display = "block";
      const titleEl = document.getElementById("media-card-title");
      const uploaderEl = document.getElementById("media-uploader-name");
      const extractorEl = document.getElementById("media-extractor-tag");
      const thumbImg = document.getElementById("media-thumb-img");
      const durationTag = document.getElementById("media-duration-tag");
      const resTag = document.getElementById("media-resolutions-tag");
      if (titleEl) titleEl.textContent = meta.title;
      if (uploaderEl) uploaderEl.textContent = meta.uploader || meta.channel || "Unknown Creator";
      if (extractorEl) extractorEl.textContent = meta.extractor || "Web";
      if (thumbImg) thumbImg.src = meta.thumbnail || "";
      if (durationTag) durationTag.textContent = this.formatDuration(meta.duration);
      const availableResolutions = Array.isArray(meta?.availableResolutions) ? meta.availableResolutions : [];
      if (resTag && availableResolutions.length > 0) {
        const realResolutions = availableResolutions.filter((r) => r >= 144 && r <= 2160);
        resTag.textContent = `Available Stream Resolutions: ${realResolutions.map((r) => r + "p").join(", ")}`;
        const profileSelect = document.getElementById("profile-select");
        if (profileSelect && this.currentMode !== "audio-only") {
          profileSelect.innerHTML = "";
          const has4K = realResolutions.some((r) => r >= 2160);
          const has1080 = realResolutions.includes(1080);
          const recommendedRes = has1080 ? 1080 : realResolutions.find((r) => r <= 1080) || realResolutions[realResolutions.length - 1];
          for (const res of realResolutions) {
            let label = "";
            const isRec = res === recommendedRes;
            if (res >= 2160) {
              label = `\u{1F3AC} 4K Ultra HD (${res}p) \u2022 Studio Master (Slower \u2022 Largest File)`;
            } else if (res >= 1440) {
              label = `\u{1F3AC} 1440p Quad HD (${res}p) \u2022 2K Sharp (Moderate Speed)`;
            } else if (res >= 1080) {
              label = isRec ? `\u{1F3AC} 1080p Full HD (${res}p) \u2022 Recommended (Fast & Balanced)` : `\u{1F3AC} 1080p Full HD (${res}p) \u2022 Standard (Fast & Balanced)`;
            } else if (res >= 720) {
              label = isRec ? `\u{1F3AC} 720p HD (${res}p) \u2022 Recommended (Light File)` : `\u{1F3AC} 720p HD (${res}p) \u2022 Very Fast (Light File)`;
            } else {
              label = isRec ? `\u{1F3AC} ${res}p \u2022 Recommended (Small File)` : `\u{1F3AC} ${res}p \u2022 Super Fast / Instant (Small File)`;
            }
            const opt = new Option(label, `res-${res}`, isRec, isRec);
            profileSelect.appendChild(opt);
          }
          if (has4K) {
            this.showHeaderToast(
              "\u26A1 4K Ultra HD is available for this video! Auto-selected 1080p for fast editing. Select 4K in Quality Profile if you need master resolution.",
              7e3
            );
          }
          profileSelect.dispatchEvent(new Event("change"));
        }
      }
      const carouselWrapper = document.getElementById("media-carousel-wrapper");
      const carouselTrack = document.getElementById("carousel-track");
      const carouselCount = document.getElementById("carousel-slide-count");
      const btnCarouselDownloadAll = document.getElementById("btn-carousel-download-all");
      if (meta.carouselSlides && meta.carouselSlides.length > 0) {
        if (carouselWrapper) carouselWrapper.style.display = "block";
        if (carouselCount) carouselCount.textContent = String(meta.carouselSlides.length);
        if (carouselTrack) {
          carouselTrack.innerHTML = "";
          meta.carouselSlides.forEach((slide) => {
            const slideCard = document.createElement("div");
            slideCard.style.cssText = "position: relative; flex: 0 0 85px; height: 110px; border-radius: 4px; overflow: hidden; background: #222; border: 1px solid #444; display: flex; flex-direction: column;";
            const isVid = slide.mediaType === "video";
            slideCard.innerHTML = `
            <div style="position: relative; flex: 1; overflow: hidden;">
              <img src="${slide.thumbnail || slide.url}" style="width: 100%; height: 100%; object-fit: cover;" onerror="this.src='data:image/svg+xml;utf8,<svg xmlns=\\'http://www.w3.org/2000/svg\\' width=\\'85\\' height=\\'80\\' fill=\\'%23333\\'><rect width=\\'100%\\' height=\\'100%\\'/></svg>'">
              <span style="position: absolute; top: 2px; left: 2px; background: rgba(0,0,0,0.7); font-size: 8px; padding: 1px 4px; border-radius: 3px; color: #fff;">#${slide.slideIndex} ${isVid ? "\u{1F3AC}" : "\u{1F4F8}"}</span>
            </div>
            <button class="btn btn-primary btn-sm btn-slide-import" style="border-radius: 0; font-size: 9px; padding: 3px 2px; text-align: center; width: 100%; cursor: pointer;" title="Download & Import Slide #${slide.slideIndex}">
              \u2B07 Import
            </button>
          `;
            slideCard.querySelector(".btn-slide-import")?.addEventListener("click", () => {
              this.handleDirectSlideDownload(slide, meta);
            });
            carouselTrack.appendChild(slideCard);
          });
        }
        if (btnCarouselDownloadAll) {
          btnCarouselDownloadAll.onclick = () => {
            this.handleDownloadAllSlides(meta);
          };
        }
      } else {
        if (carouselWrapper) carouselWrapper.style.display = "none";
        if (carouselTrack) carouselTrack.innerHTML = "";
      }
    }
    handleDirectSlideDownload(slide, meta) {
      const isVid = slide.mediaType === "video";
      const profile = {
        type: isVid ? "video" : "image",
        presetId: isVid ? "video-1080p" : "best-available",
        label: isVid ? `Slide #${slide.slideIndex} Video` : `Slide #${slide.slideIndex} Photo`,
        container: isVid ? "mp4" : "jpg",
        remuxToMp4: isVid
      };
      serviceClient.startDownload(slide.url, profile, this.projectContext, void 0, {
        title: `${meta.title || "Slide"} - Slide ${slide.slideIndex}`,
        thumbnail: slide.thumbnail || slide.url
      });
    }
    handleDownloadAllSlides(meta) {
      if (!meta.carouselSlides || meta.carouselSlides.length === 0) return;
      for (const slide of meta.carouselSlides) {
        this.handleDirectSlideDownload(slide, meta);
      }
    }
    renderPlaylistModal(playlist) {
      this.currentPlaylist = playlist;
      this.playlistCustomTargetDir = "";
      const isCloud = Boolean(
        playlist.isCloud || playlist.uploader && playlist.uploader.toLowerCase().includes("cloud") || playlist.url && (playlist.url.includes("drive.google.com") || playlist.url.includes("dropbox.com") || playlist.url.includes("onedrive") || playlist.url.includes("1drv.ms") || playlist.url.includes("mega.nz"))
      );
      if (isCloud) {
        this.closeModal("modal-playlist");
        this.showUrlError("Cloud folder downloads (Google Drive, Dropbox, OneDrive, Mega) are exclusive to MediaFetch Pro. Upgrade to MediaFetch Pro to download cloud folders and files.");
        return;
      }
      const titleEl = document.getElementById("playlist-title");
      const countEl = document.getElementById("playlist-count");
      const uploaderEl = document.getElementById("playlist-uploader");
      const allCountEl = document.getElementById("playlist-all-count");
      const listContainer = document.getElementById("playlist-items-list");
      if (titleEl) titleEl.textContent = playlist.title;
      if (countEl) countEl.textContent = `${playlist.itemCount} items`;
      if (uploaderEl) uploaderEl.textContent = playlist.uploader || (isCloud ? "Cloud Storage" : "Creator");
      if (allCountEl) allCountEl.textContent = String(playlist.itemCount);
      const modalTitleHeader = document.getElementById("modal-playlist-title-header");
      if (modalTitleHeader) modalTitleHeader.textContent = isCloud ? "Cloud Folder Detected" : "Playlist Detected";
      const itemsHeaderLabel = document.getElementById("playlist-items-header-label");
      if (itemsHeaderLabel) itemsHeaderLabel.textContent = isCloud ? "Cloud Files" : "Playlist Items";
      const modeAllLabel = document.getElementById("playlist-mode-all-label");
      if (modeAllLabel) {
        modeAllLabel.innerHTML = isCloud ? `<strong>Download All Files</strong> in this folder (<span id="playlist-all-count">${playlist.itemCount}</span> files)` : `<strong>Download All Items</strong> in this playlist (<span id="playlist-all-count">${playlist.itemCount}</span> items)`;
      }
      const cloudStructureWrapper = document.getElementById("cloud-folder-structure-wrapper");
      if (cloudStructureWrapper) {
        cloudStructureWrapper.style.display = isCloud ? "block" : "none";
      }
      const folderNameInput = document.getElementById("playlist-folder-name");
      if (folderNameInput) {
        const plTitle = (playlist.title || "").trim();
        const defaultName = plTitle && plTitle !== "Playlist" && plTitle !== "Media Playlist" ? plTitle : playlist.uploader && !playlist.uploader.toLowerCase().includes("creator") ? `${playlist.uploader} - Playlist` : isCloud ? "Cloud Media" : "Media Playlist";
        folderNameInput.value = defaultName;
      }
      const destPathEl = document.getElementById("playlist-destination-path");
      if (destPathEl) {
        const projDir = this.projectContext?.projectDirectory;
        if (projDir) {
          destPathEl.textContent = `${projDir}\\MediaFetch\\`;
        } else if (this.settings?.downloads?.downloadLocationMode === "custom" && this.settings?.downloads?.customLocation) {
          destPathEl.textContent = this.settings.downloads.customLocation;
        } else {
          destPathEl.textContent = "Active Adobe Project Folder";
        }
      }
      const modalZipCb = document.getElementById("playlist-zip-package-cb");
      const modalAutoImportCb = document.getElementById("playlist-auto-import-cb");
      const modalAutoImportLabel = modalAutoImportCb?.closest("label");
      if (modalZipCb) {
        modalZipCb.checked = false;
        modalZipCb.onchange = () => {
          if (modalZipCb.checked) {
            if (modalAutoImportCb) {
              modalAutoImportCb.checked = false;
              modalAutoImportCb.disabled = true;
            }
            if (modalAutoImportLabel) {
              modalAutoImportLabel.style.opacity = "0.5";
              modalAutoImportLabel.title = "Cannot auto-import ZIP files into Adobe timeline";
            }
          } else {
            if (modalAutoImportCb) {
              modalAutoImportCb.disabled = false;
              modalAutoImportCb.checked = true;
            }
            if (modalAutoImportLabel) {
              modalAutoImportLabel.style.opacity = "1";
              modalAutoImportLabel.title = "";
            }
          }
        };
      }
      if (modalAutoImportCb) {
        modalAutoImportCb.checked = true;
        modalAutoImportCb.disabled = false;
        modalAutoImportCb.onchange = () => {
          if (modalAutoImportCb.checked && modalZipCb) {
            modalZipCb.checked = false;
          }
        };
      }
      if (modalAutoImportLabel) {
        modalAutoImportLabel.style.opacity = "1";
        modalAutoImportLabel.title = "";
      }
      const singleVideoWrapper = document.getElementById("playlist-single-video-wrapper");
      const hasSingleVideoInPlaylist = Boolean(
        playlist.url && (playlist.url.includes("v=") || playlist.url.includes("/watch/")) && playlist.url.includes("list=")
      );
      if (singleVideoWrapper) {
        singleVideoWrapper.style.display = hasSingleVideoInPlaylist ? "block" : "none";
      }
      const isSpotify = playlist.uploader && playlist.uploader.toLowerCase().includes("spotify") || playlist.title && playlist.title.toLowerCase().includes("spotify") || playlist.url && playlist.url.toLowerCase().includes("spotify") || playlist.items.some((it) => it.url && it.url.toLowerCase().includes("spotify"));
      const qualityPicker = document.getElementById("playlist-quality-picker");
      if (qualityPicker) {
        qualityPicker.innerHTML = "";
        if (isSpotify) {
          qualityPicker.appendChild(new Option("\u{1F3B5} MP3 Studio Master (320 kbps High Quality Audio)", "audio_mp3_320", true, true));
          qualityPicker.appendChild(new Option("\u{1F3B5} MP3 Standard (192 kbps Clean Audio)", "audio_mp3_192"));
          qualityPicker.appendChild(new Option("\u{1F3B5} MP3 Data Saver (128 kbps Low Compressed)", "audio_mp3_128"));
          qualityPicker.appendChild(new Option("\u{1F3BC} Lossless WAV (48kHz Uncompressed Audio)", "audio_wav"));
          qualityPicker.appendChild(new Option("\u{1F5BC}\uFE0F High-Res Album Cover Art", "image_cover"));
        } else {
          let maxKnownHeight = 0;
          let hasKnownHeight = false;
          for (const it of playlist.items) {
            const h = it.height || it.resolution || 0;
            if (typeof h === "number" && h > 0) {
              hasKnownHeight = true;
              if (h > maxKnownHeight) maxKnownHeight = h;
            }
          }
          const isSub1080Only = hasKnownHeight && maxKnownHeight > 0 && maxKnownHeight < 1080;
          const recQuality = isSub1080Only ? maxKnownHeight <= 480 ? "480p" : "720p" : "1080p";
          if (isCloud) {
            qualityPicker.appendChild(new Option(recQuality === "1080p" ? "\u{1F3AC} 1080p Full HD Video / Native Files \u2022 Recommended" : "\u{1F3AC} 1080p Full HD Video / Native Files", "1080p", recQuality === "1080p", recQuality === "1080p"));
            qualityPicker.appendChild(new Option("\u{1F3AC} 4K Ultra HD Video (Master Quality)", "4k"));
            qualityPicker.appendChild(new Option(recQuality === "720p" ? "\u{1F3AC} 720p HD Video \u2022 Recommended" : "\u{1F3AC} 720p HD Video \u2022 High Speed", "720p", recQuality === "720p", recQuality === "720p"));
            qualityPicker.appendChild(new Option(recQuality === "480p" ? "\u{1F3AC} 480p SD Video \u2022 Recommended" : "\u{1F3AC} 480p SD Video \u2022 Fast", "480p", recQuality === "480p", recQuality === "480p"));
            qualityPicker.appendChild(new Option("\u{1F3B5} MP3 Studio Master (320 kbps Audio)", "audio_mp3_320"));
            qualityPicker.appendChild(new Option("\u{1F3BC} Lossless WAV (48kHz Uncompressed Audio)", "audio_wav"));
          } else {
            qualityPicker.appendChild(new Option(recQuality === "1080p" ? "\u{1F3AC} 1080p Full HD Video \u2022 Recommended (Fast & Balanced)" : "\u{1F3AC} 1080p Full HD Video \u2022 Standard (Fast & Balanced)", "1080p", recQuality === "1080p", recQuality === "1080p"));
            qualityPicker.appendChild(new Option("\u{1F3AC} 4K Ultra HD Video (2160p) \u2022 Studio Quality (Slower)", "4k"));
            qualityPicker.appendChild(new Option(recQuality === "720p" ? "\u{1F3AC} 720p HD Video \u2022 Recommended (Light File)" : "\u{1F3AC} 720p HD Video \u2022 High Speed (Light File)", "720p", recQuality === "720p", recQuality === "720p"));
            qualityPicker.appendChild(new Option(recQuality === "480p" ? "\u{1F3AC} 480p SD Video \u2022 Recommended (Small File)" : "\u{1F3AC} 480p Standard Definition \u2022 Fast", "480p", recQuality === "480p", recQuality === "480p"));
            qualityPicker.appendChild(new Option("\u{1F3B5} MP3 Studio Master (320 kbps Audio)", "audio_mp3_320"));
            qualityPicker.appendChild(new Option("\u{1F3B5} MP3 Data Saver (128 kbps Audio)", "audio_mp3_128"));
            qualityPicker.appendChild(new Option("\u{1F3BC} Lossless WAV (48kHz Uncompressed Audio)", "audio_wav"));
            qualityPicker.appendChild(new Option("\u{1F5BC}\uFE0F Video Cover Art / Thumbnail", "image_cover"));
          }
        }
      }
      if (listContainer) {
        listContainer.innerHTML = "";
        for (const it of playlist.items) {
          const row = document.createElement("label");
          row.style.cssText = "display:flex; align-items:center; gap:6px; font-size:11px; padding:3px; border-bottom:1px solid var(--border-subtle); cursor:pointer;";
          let durationBadge = "";
          if (it.duration && it.duration > 0) {
            durationBadge = this.formatDuration(it.duration);
          } else {
            const extMatch = it.title.match(/\.([0-9a-z]+)$/i);
            durationBadge = extMatch ? extMatch[1].toUpperCase() : isCloud ? "CLOUD FILE" : "MEDIA";
          }
          row.innerHTML = `
          <input type="checkbox" class="playlist-checkbox" data-url="${it.url}" data-title="${it.title.replace(/"/g, "&quot;")}" data-thumb="${it.thumbnail || ""}" data-dur="${it.duration || 0}" data-sub="${it.subFolderName || ""}" data-query="${it.downloadQuery || ""}" data-uploader="${it.uploader || it.channel || ""}" checked>
          <span style="color:var(--text-muted); font-size:10px; width:20px;">#${it.index}</span>
          <span style="flex:1; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;" title="${it.title}">${it.title}</span>
          <span style="color:var(--text-muted); font-size:9.5px; background:rgba(255,255,255,0.06); padding:1px 5px; border-radius:3px; white-space:nowrap;">${durationBadge}</span>
        `;
          row.querySelector("input")?.addEventListener("change", () => this.updatePlaylistSelectedCount());
          listContainer.appendChild(row);
        }
      }
      this.updatePlaylistSelectedCount();
      this.openModal("modal-playlist");
    }
    updatePlaylistSelectedCount() {
      const checked = document.querySelectorAll(".playlist-checkbox:checked");
      const selCountEl = document.getElementById("playlist-selected-count");
      if (selCountEl) selCountEl.textContent = String(checked.length);
      const radioSelCount = document.getElementById("playlist-selected-radio-count");
      if (radioSelCount) radioSelCount.textContent = String(checked.length);
    }
    async handlePlaylistDownloadSubmit() {
      if (!this.currentPlaylist) return;
      if (typeof window.MediaFetchLicense?.isAuthorized === "function") {
        if (!window.MediaFetchLicense.isAuthorized()) {
          window.MediaFetchLicense.showModal?.("A valid commercial license is required to download media.");
          return;
        }
      }
      const qualityPicker = document.getElementById("playlist-quality-picker");
      const chosenQuality = qualityPicker?.value || "1080p";
      let profileType = "video";
      let selectedPresetId = "video-1080p";
      let container = "mp4";
      let label = "\u{1F3AC} 1080p Full HD Video (Batch)";
      if (chosenQuality === "4k") {
        profileType = "video";
        selectedPresetId = "video-4k";
        container = "mp4";
        label = "\u{1F3AC} 4K Ultra HD Video (Batch)";
      } else if (chosenQuality === "720p") {
        profileType = "video";
        selectedPresetId = "video-720p";
        container = "mp4";
        label = "\u{1F3AC} 720p HD Video (Batch)";
      } else if (chosenQuality === "480p") {
        profileType = "video";
        selectedPresetId = "video-480p";
        container = "mp4";
        label = "\u{1F3AC} 480p SD Video (Batch)";
      } else if (chosenQuality === "audio_mp3_320") {
        profileType = "audio";
        selectedPresetId = "audio-mp3-320";
        container = "mp3";
        label = "\u{1F3B5} MP3 Studio Master 320kbps (Batch)";
      } else if (chosenQuality === "audio_mp3_192") {
        profileType = "audio";
        selectedPresetId = "audio-mp3-192";
        container = "mp3";
        label = "\u{1F3B5} MP3 Standard 192kbps (Batch)";
      } else if (chosenQuality === "audio_mp3_128") {
        profileType = "audio";
        selectedPresetId = "audio-mp3-128";
        container = "mp3";
        label = "\u{1F3B5} MP3 Data Saver 128kbps (Batch)";
      } else if (chosenQuality === "audio_wav") {
        profileType = "audio";
        selectedPresetId = "audio-wav";
        container = "wav";
        label = "\u{1F3B5} Lossless WAV Audio (Batch)";
      } else if (chosenQuality === "image_cover") {
        profileType = "image";
        selectedPresetId = "image-orig";
        container = "jpg";
        label = "\u{1F5BC}\uFE0F Cover Art (Batch)";
      } else {
        profileType = "video";
        selectedPresetId = "video-1080p";
        container = "mp4";
        label = "\u{1F3AC} 1080p Full HD Video (Batch)";
      }
      const profile = {
        type: profileType,
        presetId: selectedPresetId,
        label,
        container,
        remuxToMp4: container === "mp4"
      };
      const mode = document.querySelector('input[name="playlist-mode"]:checked')?.value || "all";
      let selectedItems = [];
      if (mode === "single") {
        const first = this.currentPlaylist.items[0];
        if (first) {
          selectedItems = [{
            url: first.url,
            title: first.title,
            thumbnail: first.thumbnail,
            duration: first.duration,
            subFolderName: first.subFolderName,
            downloadQuery: first.downloadQuery,
            uploader: first.uploader || first.channel
          }];
        }
      } else {
        document.querySelectorAll(".playlist-checkbox:checked").forEach((cb) => {
          const el = cb;
          selectedItems.push({
            url: el.getAttribute("data-url") || "",
            title: el.getAttribute("data-title") || "Video",
            thumbnail: el.getAttribute("data-thumb") || void 0,
            duration: parseFloat(el.getAttribute("data-dur") || "0") || void 0,
            subFolderName: el.getAttribute("data-sub") || void 0,
            downloadQuery: el.getAttribute("data-query") || void 0,
            uploader: el.getAttribute("data-uploader") || void 0
          });
        });
      }
      if (selectedItems.length === 0) {
        alert("Please select at least one item to download.");
        return;
      }
      const isCloud = Boolean(
        this.currentPlaylist.isCloud || this.currentPlaylist.uploader && this.currentPlaylist.uploader.toLowerCase().includes("cloud") || this.currentPlaylist.url && (this.currentPlaylist.url.includes("drive.google.com") || this.currentPlaylist.url.includes("dropbox.com") || this.currentPlaylist.url.includes("onedrive") || this.currentPlaylist.url.includes("1drv.ms") || this.currentPlaylist.url.includes("mega.nz"))
      );
      const folderNameInput = document.getElementById("playlist-folder-name");
      const customFolderName = folderNameInput?.value?.trim() || this.currentPlaylist.title || (isCloud ? "Cloud Media" : "Media Playlist");
      const structureMode = document.querySelector('input[name="cloud-structure-mode"]:checked')?.value;
      const preserveSubfolders = structureMode !== "flatten";
      const zipPackage = document.getElementById("playlist-zip-package-cb")?.checked || false;
      const autoImport = zipPackage ? false : document.getElementById("playlist-auto-import-cb")?.checked !== false;
      try {
        this.projectContext = await hostAdapter.getProjectContext();
      } catch (_) {
      }
      serviceClient.startPlaylistDownload(
        selectedItems,
        profile,
        this.projectContext,
        this.playlistCustomTargetDir || void 0,
        {
          customFolderName,
          preserveSubfolders,
          autoImport,
          zipPackage,
          playlistTitle: this.currentPlaylist.title,
          isCloud
        }
      );
      this.closeModal("modal-playlist");
      const input = document.getElementById("url-input");
      if (input) input.value = "";
      this.showHeaderToast(`\u{1F4E5} Added ${selectedItems.length} items to download queue`, 5e3);
    }
    async handleDownloadClick() {
      try {
        this.projectContext = await hostAdapter.getProjectContext();
      } catch (_) {
      }
      if (typeof window.MediaFetchLicense?.isAuthorized === "function") {
        if (!window.MediaFetchLicense.isAuthorized()) {
          window.MediaFetchLicense.showModal?.("A valid commercial license is required to download media.");
          return;
        }
      }
      const urlInput = document.getElementById("url-input");
      const rawInput = urlInput?.value?.trim() || "";
      if (!rawInput) {
        this.showUrlError("Please enter or paste a media URL before downloading.");
        return;
      }
      const urls = rawInput.split(/[\r\n,\s]+/).map((u) => u.trim()).filter((u) => u.startsWith("http://") || u.startsWith("https://"));
      if (urls.length === 0) {
        this.showUrlError("Please enter a valid http/https URL.");
        return;
      }
      const profileSelect = document.getElementById("profile-select");
      const formatSelect = document.getElementById("format-select");
      const selectedPresetId = profileSelect?.value || "best-available";
      const rawFormatValue = (formatSelect?.value || "").toLowerCase();
      const isExplicitVideoContainer = ["mp4", "mov", "webm", "mkv", "avi"].includes(rawFormatValue);
      const isExplicitAudioContainer = ["mp3", "wav", "m4a", "flac", "aac", "ogg"].includes(rawFormatValue);
      const isImageMode = this.currentMode === "image" || selectedPresetId.startsWith("image");
      let profileType = isImageMode ? "image" : this.currentMode === "audio-only" || selectedPresetId.startsWith("audio") ? "audio" : this.currentMode === "video-only" ? "video-only" : "video";
      if (isExplicitVideoContainer) {
        if (profileType === "audio") {
          profileType = this.currentMode === "video-only" ? "video-only" : "video";
        }
      } else if (isExplicitAudioContainer && !isImageMode) {
        profileType = "audio";
      }
      const customFilenameInput = document.getElementById("custom-filename-input");
      const customFilename = customFilenameInput?.value?.trim() || void 0;
      const trimStartInput = document.getElementById("trim-start-input");
      const trimEndInput = document.getElementById("trim-end-input");
      const rawStart = trimStartInput?.value?.trim() || void 0;
      const rawEnd = trimEndInput?.value?.trim() || void 0;
      let timeRange;
      if (rawStart || rawEnd) {
        const sSec = this.parseTimeToSec(rawStart);
        const eSec = this.parseTimeToSec(rawEnd);
        const start = rawStart ? this.formatDuration(sSec) : "00:00:00";
        const end = rawEnd ? this.formatDuration(eSec) : void 0;
        timeRange = { start, end };
      }
      let container = rawFormatValue || (profileType === "audio" ? "mp3" : profileType === "image" ? "jpg" : "mp4");
      if (isExplicitVideoContainer) {
        container = rawFormatValue;
      } else if (selectedPresetId === "audio-wav" || rawFormatValue === "wav") {
        container = "wav";
      } else if (selectedPresetId === "audio-flac" || rawFormatValue === "flac") {
        container = "flac";
      } else if (selectedPresetId === "audio-m4a" || rawFormatValue === "m4a") {
        container = "m4a";
      } else if (selectedPresetId.startsWith("audio-mp3") || rawFormatValue === "mp3") {
        container = "mp3";
      }
      let explicitResolution;
      if (typeof selectedPresetId === "string" && selectedPresetId.startsWith("res-")) {
        const parsed = parseInt(selectedPresetId.replace("res-", ""), 10);
        if (!isNaN(parsed) && parsed > 0) explicitResolution = parsed;
      } else if (selectedPresetId === "video-4k") explicitResolution = 2160;
      else if (selectedPresetId === "video-1440p") explicitResolution = 1440;
      else if (selectedPresetId === "video-1080p") explicitResolution = 1080;
      else if (selectedPresetId === "video-720p") explicitResolution = 720;
      else if (selectedPresetId === "video-480p") explicitResolution = 480;
      const baseProfile = {
        type: profileType,
        presetId: selectedPresetId,
        resolution: explicitResolution,
        label: profileSelect?.selectedOptions[0]?.text || (profileType === "audio" ? "Audio Download" : profileType === "video-only" ? "Video Only Download" : "Video Download"),
        container,
        remuxToMp4: container === "mp4",
        customFilename,
        timeRange
      };
      let targetDirectory = void 0;
      const modeInput = document.getElementById("setting-location-mode");
      const activeLocMode = modeInput?.value || this.settings?.downloads?.downloadLocationMode || "project";
      if (activeLocMode === "custom") {
        const customInput = document.getElementById("setting-custom-location");
        const customPath = customInput?.value?.trim() || this.settings?.downloads?.customLocation?.trim();
        if (customPath) {
          targetDirectory = customPath;
        }
      }
      if (urls.length > 1) {
        if (urls.some((u) => this.isCloudUrl(u))) {
          this.showUrlError("Cloud link downloads (Google Drive, Dropbox, OneDrive, Mega) are exclusive to MediaFetch Pro. Upgrade to MediaFetch Pro to download cloud files and folders.");
          return;
        }
        for (const singleUrl of urls) {
          serviceClient.startDownload(singleUrl, { ...baseProfile }, this.projectContext, targetDirectory);
        }
        urlInput.value = "";
        this.closeCard();
        return;
      }
      const url = urls[0];
      if (this.isCloudUrl(url)) {
        this.showUrlError("Cloud link downloads (Google Drive, Dropbox, OneDrive, Mega) are exclusive to MediaFetch Pro. Upgrade to MediaFetch Pro to download cloud files and folders.");
        return;
      }
      if (this.currentMetadata && (this.currentMetadata.url === url || this.currentMetadata.webpage_url === url)) {
        if (this.currentMetadata.isCarousel || this.currentMetadata.carouselSlides && this.currentMetadata.carouselSlides.length > 1) {
          const slides = this.currentMetadata.carouselSlides || [];
          this.renderPlaylistModal({
            id: this.currentMetadata.id || "carousel_" + Date.now(),
            url: this.currentMetadata.url,
            title: this.currentMetadata.title || "Instagram Carousel",
            uploader: this.currentMetadata.uploader || "@Instagram",
            itemCount: slides.length,
            items: slides.map((s, idx) => ({
              id: `slide_${idx + 1}`,
              title: s.title || `${this.currentMetadata?.title || "Slide"} (Slide ${s.slideIndex || idx + 1})`,
              url: s.url,
              thumbnail: s.thumbnail || s.url,
              duration: s.duration || 0,
              downloadQuery: s.url,
              uploader: this.currentMetadata?.uploader
            }))
          });
          return;
        }
      }
      if (this.currentPlaylist && (this.currentPlaylist.url === url || this.currentPlaylist.webpage_url === url)) {
        this.renderPlaylistModal(this.currentPlaylist);
        return;
      }
      if (this.isPlaylistUrl(url)) {
        this.setAnalysisLoading(true);
        if (url.includes("instagram.com/p/") || url.includes("instagram.com/reel/")) {
          serviceClient.analyzeUrl(url);
        } else {
          serviceClient.analyzePlaylist(url);
        }
        return;
      }
      const isMatchingMeta = this.currentMetadata && (this.currentMetadata.url === url || this.currentMetadata.webpage_url === url);
      const validMeta = isMatchingMeta ? this.currentMetadata : null;
      const title = validMeta?.title || "";
      this.pendingDownloadParams = {
        url,
        profile: baseProfile,
        projectContext: this.projectContext,
        targetDirectory,
        metadata: validMeta ? {
          title,
          thumbnail: validMeta.thumbnail,
          duration: validMeta.duration,
          downloadQuery: validMeta.downloadQuery,
          uploader: validMeta.uploader || validMeta.channel
        } : void 0
      };
      this.executePendingDownload();
    }
    executePendingDownload() {
      if (!this.pendingDownloadParams) return;
      serviceClient.startDownload(
        this.pendingDownloadParams.url,
        this.pendingDownloadParams.profile,
        this.pendingDownloadParams.projectContext,
        this.pendingDownloadParams.targetDirectory,
        this.pendingDownloadParams.metadata
      );
      this.pendingDownloadParams = null;
      const input = document.getElementById("url-input");
      if (input) input.value = "";
      const card = document.getElementById("media-card-section");
      if (card) card.style.display = "none";
      this.showHeaderToast("\u{1F4E5} Added item to download queue", 4e3);
    }
    getVisibleQueue() {
      const isPro = window.__MF_EDITION__ === "pro" || window.location.pathname.includes(".pro") || document.title.includes("Pro");
      const myEdition = isPro ? "pro" : "standard";
      return (this.queue || []).filter((item) => {
        if (!item) return false;
        if (!item.edition) {
          return myEdition === "pro";
        }
        return item.edition === myEdition;
      });
    }
    renderQueue() {
      const container = document.getElementById("queue-container");
      const countEl = document.getElementById("queue-count");
      if (!container) return;
      const visibleItems = this.getVisibleQueue();
      if (countEl) countEl.textContent = String(visibleItems.length);
      if (visibleItems.length === 0) {
        container.innerHTML = '<div class="queue-empty-state">No active downloads. Paste a URL and click Download to start.</div>';
        return;
      }
      container.innerHTML = "";
      for (const item of visibleItems) {
        container.appendChild(this.createQueueItemElement(item));
      }
    }
    createQueueItemElement(item) {
      const el = document.createElement("div");
      el.className = "queue-item";
      el.id = `q-item-${item.id}`;
      el.setAttribute("data-status", item.status);
      const badgeClass = `badge-${item.status}`;
      const fillClass = item.status === "completed" ? "success" : item.status === "failed" ? "error" : "";
      let statsText = item.stageDescription || item.status.toUpperCase();
      if (item.status === "downloading") {
        const downMB = (item.downloadedBytes / (1024 * 1024)).toFixed(1);
        const totalMB = item.totalBytes > 0 ? (item.totalBytes / (1024 * 1024)).toFixed(1) + " MB" : "\u2026";
        const speed = item.speed || "";
        const eta = item.eta ? ` \xB7 ETA ${item.eta}` : "";
        const hasMeaningfulStage = item.stageDescription && (item.stageDescription.toLowerCase().includes("process") || item.stageDescription.toLowerCase().includes("trim") || item.stageDescription.toLowerCase().includes("optimi") || item.stageDescription.toLowerCase().includes("remux") || item.stageDescription.toLowerCase().includes("merg") || item.stageDescription.toLowerCase().includes("wait") || item.stageDescription.toLowerCase().includes("start"));
        if (hasMeaningfulStage) {
          statsText = `${item.stageDescription}${speed ? ` \xB7 ${speed}` : ""}${eta}`;
        } else if (item.downloadedBytes > 0 || speed) {
          statsText = `${downMB} MB / ${totalMB} \xB7 ${speed}${eta}`;
        } else {
          statsText = item.stageDescription || "Downloading stream...";
        }
      }
      el.innerHTML = `
      <div class="queue-item-header">
        <span class="queue-item-title" title="${item.title}">${item.title}</span>
        <span class="queue-item-badge ${badgeClass}">${item.status}</span>
      </div>
      <div class="progress-bar-container">
        <div class="progress-bar-fill ${fillClass}" style="width: ${item.progress}%;"></div>
      </div>
      <div class="queue-item-stats">
        <span class="item-stats-text">${statsText}</span>
        <div class="queue-item-actions">
          ${this.renderItemActionButtons(item)}
        </div>
      </div>
    `;
      this.bindItemActionEvents(el, item);
      return el;
    }
    renderItemActionButtons(item) {
      if (item.status === "downloading" || item.status === "waiting") {
        return `
        <button class="btn btn-icon btn-sm btn-pause" title="Pause">\u23F8</button>
        <button class="btn btn-icon btn-sm btn-cancel" title="Cancel">\u2715</button>
      `;
      } else if (item.status === "paused") {
        return `
        <button class="btn btn-icon btn-sm btn-resume" title="Resume">\u25B6</button>
        <button class="btn btn-icon btn-sm btn-cancel" title="Cancel">\u2715</button>
      `;
      } else if (item.status === "failed") {
        return `
        <button class="btn btn-icon btn-sm btn-retry" title="Retry">\u21BB</button>
        <button class="btn btn-icon btn-sm btn-cancel" title="Remove">\u2715</button>
      `;
      } else if (item.status === "completed") {
        return `
        <button class="btn btn-icon btn-sm btn-reveal" title="Show in Folder">\u{1F4C1}</button>
        <button class="btn btn-icon btn-sm btn-import" title="Import to Adobe Workspace Bin">\u{1F4E5}</button>
      `;
      }
      return `<button class="btn btn-icon btn-sm btn-cancel" title="Remove">\u2715</button>`;
    }
    bindItemActionEvents(_el, _item) {
    }
    updateQueueItemDOM(item) {
      if (typeof window !== "undefined" && window.requestAnimationFrame) {
        window.requestAnimationFrame(() => this._applyQueueItemDOM(item));
      } else {
        this._applyQueueItemDOM(item);
      }
    }
    _applyQueueItemDOM(item) {
      const existing = document.getElementById(`q-item-${item.id}`);
      if (existing) {
        const title = existing.querySelector(".queue-item-title");
        const badge = existing.querySelector(".queue-item-badge");
        const fill = existing.querySelector(".progress-bar-fill");
        const stats = existing.querySelector(".item-stats-text");
        if (title && item.title) {
          title.textContent = item.title;
          title.title = item.title;
        }
        if (badge) {
          badge.className = `queue-item-badge badge-${item.status}`;
          badge.textContent = item.status;
        }
        if (fill) {
          fill.style.width = `${item.progress}%`;
          fill.className = `progress-bar-fill ${item.status === "completed" ? "success" : item.status === "failed" ? "error" : ""}`;
        }
        if (stats) {
          let statsText = item.stageDescription || item.status.toUpperCase();
          if (item.status === "downloading") {
            const downMB = (item.downloadedBytes / (1024 * 1024)).toFixed(1);
            const totalMB = item.totalBytes > 0 ? (item.totalBytes / (1024 * 1024)).toFixed(1) + " MB" : "\u2026";
            const speed = item.speed || "";
            const eta = item.eta ? ` \xB7 ETA ${item.eta}` : "";
            const hasMeaningfulStage = item.stageDescription && (item.stageDescription.toLowerCase().includes("process") || item.stageDescription.toLowerCase().includes("trim") || item.stageDescription.toLowerCase().includes("optimi") || item.stageDescription.toLowerCase().includes("remux") || item.stageDescription.toLowerCase().includes("merg") || item.stageDescription.toLowerCase().includes("wait") || item.stageDescription.toLowerCase().includes("start"));
            if (hasMeaningfulStage) {
              statsText = `${item.stageDescription}${speed ? ` \xB7 ${speed}` : ""}${eta}`;
            } else if (item.downloadedBytes > 0 || speed) {
              statsText = `${downMB} MB / ${totalMB} \xB7 ${speed}${eta}`;
            } else {
              statsText = item.stageDescription || "Downloading stream...";
            }
          }
          stats.textContent = statsText;
        }
        const prevStatus = existing.getAttribute("data-status");
        if (prevStatus !== item.status) {
          existing.setAttribute("data-status", item.status);
          const actions = existing.querySelector(".queue-item-actions");
          if (actions) {
            actions.innerHTML = this.renderItemActionButtons(item);
            this.bindItemActionEvents(existing, item);
          }
        }
      } else {
        this.renderQueue();
      }
    }
    renderDiagnostics(diag) {
      const osEl = document.getElementById("diag-os");
      const nodeEl = document.getElementById("diag-node");
      const adobeEl = document.getElementById("diag-adobe");
      const portEl = document.getElementById("diag-port");
      const ytdlpEl = document.getElementById("diag-ytdlp");
      const ffmpegEl = document.getElementById("diag-ffmpeg");
      const logsBox = document.getElementById("diag-logs-box");
      if (osEl) osEl.textContent = diag.os;
      if (nodeEl) nodeEl.textContent = diag.nodeVersion;
      if (adobeEl) adobeEl.textContent = `${diag.adobeApp || "Adobe App"} (${diag.adobeVersion || "Auto"})`;
      if (portEl) portEl.textContent = String(diag.servicePort);
      if (ytdlpEl) ytdlpEl.textContent = diag.ytdlp.available ? `v${diag.ytdlp.version || "OK"}` : "Missing";
      if (ffmpegEl) ffmpegEl.textContent = diag.ffmpeg.available ? `v${diag.ffmpeg.version || "OK"}` : "Missing";
      const engineYtDlp = document.getElementById("engine-ytdlp-ver");
      const engineFfmpeg = document.getElementById("engine-ffmpeg-ver");
      if (engineYtDlp) {
        engineYtDlp.textContent = diag.ytdlp?.available ? `v${diag.ytdlp.version || "OK"}` : "Missing / Not Installed";
        engineYtDlp.style.color = diag.ytdlp?.available ? "var(--status-success, #22c55e)" : "var(--status-error, #ef4444)";
      }
      if (engineFfmpeg) {
        engineFfmpeg.textContent = diag.ffmpeg?.available ? `v${diag.ffmpeg.version || "OK"}` : "Missing / Not Installed";
        engineFfmpeg.style.color = diag.ffmpeg?.available ? "var(--status-success, #22c55e)" : "var(--status-error, #ef4444)";
      }
      fetch(`http://127.0.0.1:${diag.servicePort}/api/diagnostics/logs`).then((r) => r.json()).then((data) => {
        if (logsBox && Array.isArray(data.logs)) {
          logsBox.textContent = data.logs.join("\n");
          logsBox.scrollTop = logsBox.scrollHeight;
        }
      }).catch(() => {
      });
    }
    updateSetupWizardStatus(diag) {
      const ytdlpStat = document.getElementById("setup-status-ytdlp");
      const ffmpegStat = document.getElementById("setup-status-ffmpeg");
      if (ytdlpStat) {
        ytdlpStat.textContent = diag.ytdlp.available ? `\u2713 Ready (v${diag.ytdlp.version || ""})` : "\u2717 Missing";
        ytdlpStat.style.color = diag.ytdlp.available ? "var(--status-success)" : "var(--status-error)";
      }
      if (ffmpegStat) {
        ffmpegStat.textContent = diag.ffmpeg.available ? `\u2713 Ready (${diag.ffmpeg.version || ""})` : "\u2717 Missing";
        ffmpegStat.style.color = diag.ffmpeg.available ? "var(--status-success)" : "var(--status-error)";
      }
      const installBtn = document.getElementById("btn-setup-install-all");
      if (installBtn) {
        if (diag.ytdlp.available && diag.ffmpeg.available) {
          installBtn.textContent = "All Components Ready";
          installBtn.disabled = true;
        } else {
          installBtn.textContent = "Install Missing Components";
          installBtn.disabled = false;
        }
      }
    }
    showInstallProgress(payload) {
      const progRow = document.getElementById("setup-progress-row");
      const progLabel = document.getElementById("setup-progress-label");
      const progFill = document.getElementById("setup-progress-fill");
      if (progRow) progRow.style.display = "flex";
      if (progLabel) progLabel.textContent = `[${payload.name}] ${payload.message}`;
      if (progFill) progFill.style.width = `${payload.progress}%`;
      const engineStatus = document.getElementById("engine-update-status");
      if (engineStatus) {
        engineStatus.style.display = "block";
        engineStatus.style.color = "var(--text-secondary, #aaa)";
        engineStatus.textContent = payload.message || "Updating yt-dlp engine...";
      }
    }
    handleInstallResult(payload) {
      const progLabel = document.getElementById("setup-progress-label");
      if (progLabel) {
        if (payload.success) {
          progLabel.textContent = `\u2713 ${payload.name} installation completed successfully.`;
        } else {
          progLabel.textContent = `\u2717 Failed to install ${payload.name}: ${payload.error}`;
        }
      }
      const btnUpdate = document.getElementById("btn-update-ytdlp");
      if (btnUpdate) {
        btnUpdate.disabled = false;
        btnUpdate.textContent = "\u{1F504} Check & Update yt-dlp";
      }
      const engineStatus = document.getElementById("engine-update-status");
      if (engineStatus) {
        engineStatus.style.display = "block";
        if (payload.success) {
          engineStatus.style.color = "var(--status-success, #22c55e)";
          engineStatus.textContent = payload.message || "\u2713 yt-dlp is up to date!";
        } else {
          engineStatus.style.color = "var(--status-error, #ef4444)";
          engineStatus.textContent = `\u2717 Update notice: ${payload.error || "Check network connection"}`;
        }
      }
      serviceClient.runSystemCheck();
      serviceClient.getDiagnostics();
    }
    updateDownloadLocationModeUI() {
      const modeSel = document.getElementById("setting-location-mode");
      const customLoc = document.getElementById("setting-custom-location");
      const customBrowseBtn = document.getElementById("btn-browse-custom-location");
      const customGroup = document.getElementById("setting-custom-location-group") || customLoc?.parentElement?.parentElement;
      const isCustom = modeSel?.value === "custom";
      if (customLoc) customLoc.disabled = !isCustom;
      if (customBrowseBtn) customBrowseBtn.disabled = !isCustom;
      if (customGroup) {
        customGroup.style.opacity = isCustom ? "1" : "0.45";
        customGroup.style.pointerEvents = isCustom ? "auto" : "none";
      }
    }
    populateSettingsForm(s) {
      const themeSel = document.getElementById("setting-theme");
      const autoImportChk = document.getElementById("setting-auto-import");
      const confirmChk = document.getElementById("setting-confirm-overwrite");
      const cleanupChk = document.getElementById("setting-auto-cleanup");
      const modeSel = document.getElementById("setting-location-mode");
      const playlistSel = document.getElementById("setting-playlist-behavior");
      const customLoc = document.getElementById("setting-custom-location");
      const concSel = document.getElementById("setting-concurrency");
      const retriesSel = document.getElementById("setting-max-retries");
      const timeoutInput = document.getElementById("setting-timeout");
      const debugChk = document.getElementById("setting-debug-logging");
      const cookiesSel = document.getElementById("setting-browser-cookies");
      if (themeSel) themeSel.value = s.general.theme;
      if (autoImportChk) autoImportChk.checked = s.general.autoImportToProject ?? true;
      if (confirmChk) confirmChk.checked = s.general.confirmOverwrite;
      if (cleanupChk) cleanupChk.checked = s.general.autoCleanupTemp;
      if (modeSel) modeSel.value = s.downloads.downloadLocationMode;
      if (playlistSel) playlistSel.value = s.downloads.playlistBehavior || "ask";
      if (customLoc) customLoc.value = s.downloads.customLocation;
      if (concSel) concSel.value = String(s.downloads.concurrency);
      if (retriesSel) retriesSel.value = String(s.downloads.maxRetries);
      if (timeoutInput) timeoutInput.value = String(s.advanced.networkTimeoutMs);
      if (debugChk) debugChk.checked = s.advanced.debugLogging;
      if (cookiesSel) cookiesSel.value = s.engine.browserCookies || "none";
      this.updateDownloadLocationModeUI();
    }
    saveSettingsFromForm() {
      const themeSel = document.getElementById("setting-theme");
      const autoImportChk = document.getElementById("setting-auto-import");
      const confirmChk = document.getElementById("setting-confirm-overwrite");
      const cleanupChk = document.getElementById("setting-auto-cleanup");
      const modeSel = document.getElementById("setting-location-mode");
      const playlistSel = document.getElementById("setting-playlist-behavior");
      const customLoc = document.getElementById("setting-custom-location");
      const concSel = document.getElementById("setting-concurrency");
      const retriesSel = document.getElementById("setting-max-retries");
      const timeoutInput = document.getElementById("setting-timeout");
      const debugChk = document.getElementById("setting-debug-logging");
      const cookiesSel = document.getElementById("setting-browser-cookies");
      const updated = {
        general: {
          theme: themeSel?.value || "host",
          notifications: true,
          confirmOverwrite: confirmChk?.checked ?? true,
          autoCleanupTemp: cleanupChk?.checked ?? true,
          autoImportToProject: autoImportChk?.checked ?? true
        },
        downloads: {
          defaultPreset: "best-available",
          downloadLocationMode: modeSel?.value || "project",
          customLocation: customLoc?.value || "",
          concurrency: parseInt(concSel?.value || "2", 10),
          maxRetries: parseInt(retriesSel?.value || "3", 10),
          retryDelayMs: 2e3,
          filenamePattern: "%(title)s.%(ext)s",
          playlistBehavior: playlistSel?.value || "ask"
        },
        engine: {
          autoUpdate: true,
          browserCookies: cookiesSel?.value || "none"
        },
        advanced: {
          networkTimeoutMs: parseInt(timeoutInput?.value || "30000", 10),
          debugLogging: debugChk?.checked ?? false
        }
      };
      serviceClient.updateSettings(updated);
      if (typeof window.Settings !== "undefined") {
        const pexelsInput = document.getElementById("setting-studio-pexels-key");
        const pixabayInput = document.getElementById("setting-studio-pixabay-key");
        const unsplashInput = document.getElementById("setting-studio-unsplash-key");
        const giphyInput = document.getElementById("setting-studio-giphy-key");
        window.Settings.save({
          downloadFolder: modeSel?.value === "custom" ? customLoc?.value?.trim() || "" : "",
          pexelsApiKey: pexelsInput ? pexelsInput.value.trim() : "",
          pixabayApiKey: pixabayInput ? pixabayInput.value.trim() : "",
          unsplashApiKey: unsplashInput ? unsplashInput.value.trim() : "",
          giphyApiKey: giphyInput ? giphyInput.value.trim() : "",
          autoInsertTimeline: false
        });
      }
    }
    renderHistoryList(filterQuery = "") {
      const container = document.getElementById("history-list-container");
      if (!container) return;
      const isPro = window.__MF_EDITION__ === "pro" || window.location.pathname.includes(".pro") || document.title.includes("Pro");
      const myEdition = isPro ? "pro" : "standard";
      const filtered = this.history.filter((h) => {
        const matchEdition = !h.edition || h.edition === myEdition;
        const matchQuery = !filterQuery || h.title.toLowerCase().includes(filterQuery) || h.url.toLowerCase().includes(filterQuery);
        return matchEdition && matchQuery;
      });
      if (filtered.length === 0) {
        container.innerHTML = '<div style="font-size:11px; color:var(--text-muted); padding:12px; text-align:center;">No history records found.</div>';
        return;
      }
      container.innerHTML = "";
      for (const h of filtered) {
        const row = document.createElement("div");
        row.className = "queue-item";
        const dateStr = new Date(h.date).toLocaleDateString();
        const mb = (h.fileSize / (1024 * 1024)).toFixed(1);
        row.innerHTML = `
        <div class="queue-item-header">
          <span class="queue-item-title" title="${h.title}">${h.title}</span>
          <span class="queue-item-badge badge-completed">${h.profileName}</span>
        </div>
        <div class="queue-item-stats">
          <span>${dateStr} \xB7 ${mb} MB</span>
          <div class="queue-item-actions">
            <button class="btn btn-icon btn-sm btn-hist-reveal" title="Show in Folder">\u{1F4C1}</button>
            <button class="btn btn-icon btn-sm btn-hist-redl" title="Download Again">\u21BB</button>
            <button class="btn btn-icon btn-sm btn-hist-del" title="Delete from history">\u2715</button>
          </div>
        </div>
      `;
        row.querySelector(".btn-hist-reveal")?.addEventListener("click", () => hostAdapter.revealInFinder(h.outputPath));
        row.querySelector(".btn-hist-redl")?.addEventListener("click", () => {
          const input = document.getElementById("url-input");
          if (input) {
            input.value = h.url;
            this.closeModal("modal-history");
            this.handleAnalyze();
          }
        });
        row.querySelector(".btn-hist-del")?.addEventListener("click", () => serviceClient.removeHistoryItem(h.id));
        container.appendChild(row);
      }
    }
    showDuplicateModal(filePath) {
      const pathEl = document.getElementById("dup-file-path");
      if (pathEl) pathEl.textContent = filePath;
      this.openModal("modal-duplicate");
    }
    openModal(id) {
      const m = document.getElementById(id);
      if (m) m.classList.add("active");
    }
    closeModal(id) {
      if (id === "modal-media-preview") {
        const viewport = document.getElementById("media-preview-viewport");
        if (viewport) viewport.innerHTML = "";
      }
      const m = document.getElementById(id);
      if (m) m.classList.remove("active");
    }
    openMediaPreview(meta) {
      if (!meta) return;
      const titleEl = document.getElementById("media-preview-title");
      const authorEl = document.getElementById("media-preview-author");
      const viewport = document.getElementById("media-preview-viewport");
      const openBrowserBtn = document.getElementById("btn-open-preview-browser");
      if (titleEl) titleEl.textContent = meta.title || "Media Preview";
      if (authorEl) {
        authorEl.textContent = `${meta.uploader || meta.channel || "Media"} \u2022 ${this.formatDuration(meta.duration)}`;
      }
      if (openBrowserBtn) {
        openBrowserBtn.onclick = () => {
          const u = meta.url;
          if (u) {
            if (window.__adobe_cep__ && typeof window.__adobe_cep__.openURLInDefaultBrowser === "function") {
              window.__adobe_cep__.openURLInDefaultBrowser(u);
            } else if (window.cep?.util?.openURLInDefaultBrowser) {
              window.cep.util.openURLInDefaultBrowser(u);
            } else {
              window.open(u, "_blank");
            }
          }
        };
      }
      if (viewport) {
        viewport.innerHTML = "";
        const url = meta.url || "";
        const isYouTube = url.includes("youtube.com") || url.includes("youtu.be");
        const isSpotify = url.includes("spotify.com");
        if (isYouTube) {
          let ytId = meta.id;
          if (!ytId || ytId.length !== 11) {
            const match = url.match(/(?:v=|youtu\.be\/|embed\/|live\/)([a-zA-Z0-9_-]{11})/);
            if (match) ytId = match[1];
          }
          if (ytId) {
            viewport.innerHTML = `<iframe src="https://www.youtube-nocookie.com/embed/${ytId}?autoplay=1&rel=0" style="width:100%; height:100%; border:none;" allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen></iframe>`;
          } else {
            viewport.innerHTML = `<div style="display:flex; flex-direction:column; align-items:center; justify-content:center; gap:8px; padding:20px; color:#aaa;"><span>Preview ready</span><button class="btn btn-primary btn-sm" id="btn-play-yt-browser">\u25B6 Play in Browser</button></div>`;
            document.getElementById("btn-play-yt-browser")?.addEventListener("click", () => {
              if (window.__adobe_cep__?.openURLInDefaultBrowser) window.__adobe_cep__.openURLInDefaultBrowser(url);
              else window.open(url, "_blank");
            });
          }
        } else if (isSpotify) {
          const trackMatch = url.match(/track\/([a-zA-Z0-9]+)/);
          const sId = trackMatch ? trackMatch[1] : meta.id;
          if (sId) {
            viewport.innerHTML = `<iframe src="https://open.spotify.com/embed/track/${sId}?utm_source=generator" width="100%" height="100%" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"></iframe>`;
          }
        } else {
          let streamUrl = meta.directStreamUrl || meta.directUrl || "";
          if (!streamUrl && meta.formats && meta.formats.length > 0) {
            const streamFormat = meta.formats.find((f) => f.url && (f.hasAudioAndVideo || f.ext === "mp4" && f.vcodec !== "none"));
            if (streamFormat) streamUrl = streamFormat.url;
          }
          if (streamUrl) {
            viewport.innerHTML = `<video src="${streamUrl}" controls autoplay style="width:100%; height:100%; object-fit:contain;"></video>`;
          } else {
            viewport.innerHTML = `
            <div style="display:flex; flex-direction:column; align-items:center; justify-content:center; gap:8px; padding:16px; text-align:center;">
              <img src="${meta.thumbnail || ""}" style="max-height:140px; border-radius:4px; box-shadow:0 4px 12px rgba(0,0,0,0.5);" alt="Thumb">
              <span style="font-size:11px; color:#bbb;">Click below to stream in default browser</span>
              <button type="button" class="btn btn-primary btn-sm" id="btn-play-external" style="padding:4px 12px; font-weight:600;">\u25B6 Watch Stream</button>
            </div>
          `;
            document.getElementById("btn-play-external")?.addEventListener("click", () => {
              if (window.__adobe_cep__ && typeof window.__adobe_cep__.openURLInDefaultBrowser === "function") {
                window.__adobe_cep__.openURLInDefaultBrowser(url);
              } else if (window.cep?.util?.openURLInDefaultBrowser) {
                window.cep.util.openURLInDefaultBrowser(url);
              } else {
                window.open(url, "_blank");
              }
            });
          }
        }
      }
      this.openModal("modal-media-preview");
    }
    closeMediaPreview() {
      const viewport = document.getElementById("media-preview-viewport");
      if (viewport) viewport.innerHTML = "";
      this.closeModal("modal-media-preview");
    }
    parseTimeToSec(txt) {
      if (!txt) return 0;
      const clean = txt.trim();
      if (!clean) return 0;
      const parts = clean.split(":").map((p) => parseFloat(p.trim()) || 0);
      if (parts.length >= 3) {
        let sec = parts[0] * 3600 + parts[1] * 60 + parts[2];
        if (parts.length >= 4) sec += parts[3] / 30;
        return sec;
      }
      if (parts.length === 2) return parts[0] * 60 + parts[1];
      if (parts.length === 1) return parts[0];
      return 0;
    }
    formatDuration(seconds) {
      if (!seconds || seconds <= 0) return "00:00";
      const h = Math.floor(seconds / 3600);
      const m = Math.floor(seconds % 3600 / 60);
      const s = Math.floor(seconds % 60);
      if (h > 0) {
        return `${h.toString().padStart(2, "0")}:${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
      }
      return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
    }
  };
  if (typeof document !== "undefined") {
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", () => new MediaFetchApp());
    } else {
      new MediaFetchApp();
    }
  }
})();
