import { IHostAdapter, HostImportOptions } from './adapter-interface.js';
import { ProjectContext } from '../common/types.js';
import { getHostAppId } from './host-detector.js';
import { AfterEffectsHostAdapter } from './ae-adapter.js';

export class PremiereHostAdapter implements IHostAdapter {
  private themeListeners: ((theme: string) => void)[] = [];

  public async getProjectContext(): Promise<ProjectContext> {
    if (typeof getHostAppId === 'function' && getHostAppId() === 'aeft') {
      return new AfterEffectsHostAdapter().getProjectContext();
    }
    try {
      // 1. Try preloaded MediaFetchHost.getHostInfo() ExtendScript bridge first
      const hostInfoResult = await this.evalScript('MediaFetchHost.getHostInfo()');
      if (hostInfoResult && typeof hostInfoResult === 'string' && hostInfoResult !== 'EvalScript error.') {
        try {
          const parsedHost = JSON.parse(hostInfoResult);
          if (parsedHost && parsedHost.projectPath && parsedHost.projectPath.length > 0) {
            const cleanPath = parsedHost.projectPath.replace(/\\/g, '/');
            const dir = cleanPath.substring(0, cleanPath.lastIndexOf('/'));
            const name = parsedHost.projectName || cleanPath.substring(cleanPath.lastIndexOf('/') + 1) || 'Premiere Project';
            return {
              application: 'premierepro',
              applicationVersion: parsedHost.appVersion || '26.0',
              projectSaved: true,
              projectName: name,
              projectPath: parsedHost.projectPath,
              projectDirectory: dir.replace(/\//g, '\\')
            };
          }
        } catch (_) {}
      }

      // 2. Direct ExtendScript fallback
      const script = `
        (function() {
          try {
            if (app && app.project) {
              var pPath = "";
              if (app.project.path && app.project.path.length > 0) {
                pPath = app.project.path;
              } else if (app.project.documentPath && app.project.documentPath.length > 0) {
                pPath = app.project.documentPath;
              }

              if (pPath && pPath.length > 0) {
                return JSON.stringify({
                  saved: true,
                  path: pPath,
                  name: app.project.name || "Premiere Project",
                  version: app.version || "26.0"
                });
              } else {
                return JSON.stringify({
                  saved: false,
                  name: "Active Premiere Project (Unsaved)",
                  version: app.version || "26.0"
                });
              }
            }
          } catch (err) {
            return JSON.stringify({ saved: false, error: String(err) });
          }
          return JSON.stringify({ saved: false });
        })();
      `;

      const result = await this.evalScript(script);
      if (result && typeof result === 'string' && result !== 'EvalScript error.') {
          const parsed = JSON.parse(result);
          if (parsed) {
            if (parsed.saved && parsed.path) {
              const cleanPath = parsed.path.replace(/\\/g, '/');
              const dir = cleanPath.substring(0, cleanPath.lastIndexOf('/'));
              const name = cleanPath.substring(cleanPath.lastIndexOf('/') + 1) || parsed.name;
              return {
                application: 'premierepro',
                applicationVersion: parsed.version || '26.0',
                projectSaved: true,
                projectName: name,
                projectPath: parsed.path,
                projectDirectory: dir.replace(/\//g, '\\')
              };
            } else if (parsed.name) {
              return {
                application: 'premierepro',
                applicationVersion: parsed.version || '26.0',
                projectSaved: false,
                projectName: parsed.name
              };
            }
          }
      }
    } catch (e) {
      console.warn('Error reading Premiere Pro project context:', e);
    }

    return {
      application: 'premierepro',
      applicationVersion: '26.0',
      projectSaved: false
    };
  }

  public async revealInFinder(filePath: string): Promise<void> {
    try {
      if (typeof window !== 'undefined' && (window as any).require) {
        const cp = (window as any).require('child_process');
        if (cp?.exec) {
          cp.exec(`explorer.exe /select,"${filePath.replace(/\//g, '\\')}"`);
          return;
        }
      }
    } catch {}

    try {
      const script = `
        (function() {
          var f = new File("${filePath.replace(/\\/g, '/')}");
          if (f.exists) {
            f.execute();
          }
        })();
      `;
      await this.evalScript(script);
    } catch {}
  }

  public async openFile(filePath: string): Promise<void> {
    await this.revealInFinder(filePath);
  }

  public async importToProject(filePath: string, options?: HostImportOptions): Promise<boolean> {
    if (typeof getHostAppId === 'function' && getHostAppId() === 'aeft') {
      return new AfterEffectsHostAdapter().importToProject(filePath, options);
    }
    try {
      const cleanPath = filePath.replace(/\\/g, '/');
      const locMode = options?.downloadLocationMode || (options?.isCustomFlat ? 'custom_flat' : (options?.isCustomPath ? 'custom' : 'simple'));
      const isCustomFlat = locMode === 'custom_flat' || Boolean(options?.isCustomFlat);
      const isCustom = !isCustomFlat && (locMode === 'custom' || Boolean(options?.isCustomPath));
      const isSimple = !isCustom && !isCustomFlat;
      const isCloud = options?.isCloud ? true : false;
      const isPlaylist = options?.isPlaylist ? true : false;
      const isBatch = options?.isBatch ? true : false;
      const isSingleLink = options?.isSingleLink !== undefined ? options.isSingleLink : (!isPlaylist && !isCloud && !isBatch);
      const shouldInsertTimeline = Boolean((options?.insertToTimeline || options?.addToTimeline || options?.isClipboard) && isSingleLink);
      const playlistTitle = (options?.playlistTitle || '').replace(/[\\/:"*?<>|]/g, ' ').trim();
      const customFolderName = (options?.customFolderName || '').replace(/[\\/:"*?<>|]/g, ' ').trim();
      const subFolderName = (options?.subFolderName || '').trim();
      const isClipboard = Boolean(options?.isClipboard || cleanPath.includes('Clipboard'));

      const optsObj = {
        downloadLocationMode: locMode,
        isCustomPath: isCustom,
        isCustomFlat: isCustomFlat,
        isSimplePath: isSimple,
        isSimple: isSimple,
        isCloud,
        isPlaylist,
        isBatch,
        isSingleLink,
        playlistTitle,
        customFolderName,
        subFolderName,
        isClipboard,
        addToTimeline: shouldInsertTimeline,
        insertToTimeline: shouldInsertTimeline
      };
      const optsJson = JSON.stringify(optsObj);

      // Ensure hostscript.jsx is dynamically evaluated in Premiere ExtendScript engine
      try {
        let extDir = '';
        if (typeof window !== 'undefined') {
          if ((window as any).__adobe_cep__?.getSystemPath) {
            extDir = (window as any).__adobe_cep__.getSystemPath('extension');
          } else if ((window as any).CSInterface) {
            extDir = new (window as any).CSInterface().getSystemPath('extension');
          }
        }
        if (extDir) {
          try { extDir = decodeURIComponent(extDir); } catch (_) {}
          extDir = extDir.replace(/^file:[\\\/]+/, '');
          if (/^[\\\/]?[A-Za-z]:/.test(extDir)) {
            extDir = extDir.replace(/^[\\\/]([A-Za-z]:)/, '$1');
          }
          extDir = extDir.replace(/\\/g, '/');
          const jsxP = extDir + '/jsx/hostscript.jsx';
          await this.evalScript(`(function(){ try { var f = new File("${jsxP}"); if (f.exists) { $.evalFile(f); return "loaded"; } } catch(e){} return "none"; })()`);
        }
      } catch (_) {}

      try {
        const evalResStr = await this.evalScript(`MediaFetchHost.importMedia(${JSON.stringify(cleanPath)}, ${shouldInsertTimeline ? 'true' : 'false'}, ${optsJson})`);
        if (evalResStr && evalResStr !== 'EvalScript error.') {
          try {
            const parsed = JSON.parse(evalResStr);
            if (parsed && parsed.success && parsed.imported !== false) {
              console.log('[MediaFetch] HostScript importMedia succeeded:', parsed);
              return true;
            }
          } catch (_) {
            if (evalResStr === 'true' || evalResStr === true) return true;
          }
        }
      } catch (hErr) {
        console.warn('[MediaFetch] MediaFetchHost.importMedia attempt notice:', hErr);
      }

      const script = `
        (function() {
          try {
            if (!app || !app.project) return "no_project";
            var project = app.project;
            var root = project.rootItem;
            
            function getOrCreateBin(parentBin, binName) {
              if (!parentBin || !parentBin.children) return null;
              for (var i = 0; i < parentBin.children.numItems; i++) {
                var item = parentBin.children[i];
                if (item && item.type === 2 && item.name === binName) {
                  return item;
                }
              }
              try { return parentBin.createBin(binName); } catch (binErr) { return null; }
            }

            var targetPath = "${cleanPath}";
            var isCustomFlat = ${isCustomFlat ? 'true' : 'false'};
            var isCustom = ${isCustom ? 'true' : 'false'};
            var isCloud = ${isCloud ? 'true' : 'false'};
            var isPlaylist = ${isPlaylist ? 'true' : 'false'};
            var playlistTitle = "${playlistTitle.replace(/"/g, '\\"')}";
            var customFolderName = "${customFolderName.replace(/"/g, '\\"')}";
            var subFolderName = "${subFolderName.replace(/"/g, '\\"').replace(/\\/g, '/')}";

            var targetBin = null;

            if (isCustomFlat) {
              // Direct Custom Flat Folder
              var pPartsFlat = targetPath.split('/');
              var parentNameFlat = pPartsFlat.length > 1 ? pPartsFlat[pPartsFlat.length - 2] : "Downloads";
              var rootBinNameFlat = customFolderName || parentNameFlat || "Downloads";
              targetBin = getOrCreateBin(root, rootBinNameFlat) || root;
            } else if (isCustom) {
              // Custom Directory: create root bin outside MediaFetch named after the selected custom folder
              var pParts = targetPath.split('/');
              var parentName = pParts.length > 1 ? pParts[pParts.length - 2] : "";
              var isStrictThreeFolder = (parentName === "Video" || parentName === "Audio" || parentName === "Images" || parentName === "Image");
              var parts = targetPath.split('.');
              var ext = parts.length > 1 ? parts[parts.length - 1].toLowerCase().split('?')[0] : '';
              var isAudio = (ext === 'mp3' || ext === 'wav' || ext === 'm4a' || ext === 'flac' || ext === 'aac' || ext === 'ogg' || ext === 'opus' || ext === 'aiff');
              var isImage = (ext === 'jpg' || ext === 'jpeg' || ext === 'png' || ext === 'webp' || ext === 'gif' || ext === 'bmp' || ext === 'tiff' || ext === 'tif' || ext === 'svg');
              var typeBinName = isAudio ? "Audio" : (isImage ? "Images" : "Video");

              if (isStrictThreeFolder) {
                var grandParentName = pParts.length > 2 ? pParts[pParts.length - 3] : "";
                var customRootBin = grandParentName ? getOrCreateBin(root, grandParentName) : root;
                targetBin = getOrCreateBin(customRootBin || root, typeBinName) || customRootBin;
              } else {
                var rootBinName = customFolderName || (isPlaylist ? (playlistTitle || "Playlist") : (isCloud ? "Cloud Media" : ""));
                if (!rootBinName) {
                  rootBinName = parentName || "Downloads";
                }
                var customRootBin = getOrCreateBin(root, rootBinName);
                if (subFolderName) {
                  var sParts = subFolderName.split('/');
                  var cur = customRootBin;
                  for (var s = 0; s < sParts.length; s++) {
                    if (sParts[s] && sParts[s].length > 0) {
                      cur = getOrCreateBin(cur, sParts[s]);
                    }
                  }
                  targetBin = cur || customRootBin;
                } else {
                  targetBin = getOrCreateBin(customRootBin, typeBinName) || customRootBin;
                }
              }
            } else {
              // Default Project Path: inside root "MediaFetch" bin
              var mediaFetchBin = getOrCreateBin(root, "MediaFetch");

              if (isCloud) {
                // MediaFetch -> Cloud Links -> [Cloud Folder Name] -> [Subfolders]
                var cloudRootBin = getOrCreateBin(mediaFetchBin, "Cloud Links");
                var cloudFolderBin = getOrCreateBin(cloudRootBin, customFolderName || "Cloud Media");
                if (subFolderName) {
                  var sParts = subFolderName.split('/');
                  var cur = cloudFolderBin;
                  for (var s = 0; s < sParts.length; s++) {
                    if (sParts[s] && sParts[s].length > 0) {
                      cur = getOrCreateBin(cur, sParts[s]);
                    }
                  }
                  targetBin = cur || cloudFolderBin;
                } else {
                  targetBin = cloudFolderBin;
                }
              } else if (isPlaylist) {
                // MediaFetch -> Playlists -> [Playlist Name]
                var playlistRootBin = getOrCreateBin(mediaFetchBin, "Playlists");
                var pName = playlistTitle || customFolderName || "Playlist 1";
                targetBin = getOrCreateBin(playlistRootBin, pName);
              } else {
                // Single link or Search or Clipboard
                var isClipboard = ${isClipboard ? 'true' : 'false'} || targetPath.indexOf("Clipboard") !== -1;
                var isSearch = targetPath.indexOf("SerachMediafetch") !== -1 || 
                               targetPath.indexOf("MediaFetch Assets") !== -1 || 
                               targetPath.indexOf("MediaSearch Assets") !== -1;
                var categoryBinName = isClipboard ? "Clipboard" : (isSearch ? "SerachMediafetch" : "LinkMediaFetch");
                var categoryBin = getOrCreateBin(mediaFetchBin, categoryBinName);

                var parts = targetPath.split('.');
                var ext = parts.length > 1 ? parts[parts.length - 1].toLowerCase().split('?')[0] : '';
                var isAudio = (ext === 'mp3' || ext === 'wav' || ext === 'm4a' || ext === 'flac' || ext === 'aac' || ext === 'ogg' || ext === 'opus' || ext === 'aiff');
                var isImage = (ext === 'jpg' || ext === 'jpeg' || ext === 'png' || ext === 'webp' || ext === 'gif' || ext === 'bmp' || ext === 'tiff' || ext === 'tif' || ext === 'svg');
                var typeBinName = isAudio ? "Audio" : (isImage ? "Images" : "Video");
                targetBin = getOrCreateBin(categoryBin, typeBinName) || categoryBin;
              }
            }

            if (!targetBin) targetBin = root;

            // Check if file is already imported in targetBin to avoid duplicates (unless timeline insertion requested)
            if (!${shouldInsertTimeline ? 'true' : 'false'}) {
              if (targetBin && targetBin.children) {
                for (var k = 0; k < targetBin.children.numItems; k++) {
                  var ch = targetBin.children[k];
                  try {
                    if (ch && ch.getMediaPath && (ch.getMediaPath() === targetPath || ch.getMediaPath() === "${filePath.replace(/\\/g, '\\\\')}")) {
                      return "true";
                    }
                  } catch (_) {}
                }
              }
            }

            var mediaF = new File(targetPath);
            var nativePath = mediaF.fsName;
            var cleanPath = targetPath.replace(/\\/g, '/');
            var rawName = "";
            try {
              if (mediaF.name) rawName = File.decode(mediaF.name);
            } catch (_) {}
            if (!rawName && mediaF.fsName) {
              var fnParts = mediaF.fsName.replace(/\\/g, '/').split('/');
              rawName = fnParts[fnParts.length - 1];
            }
            if (!rawName) rawName = targetPath.split('/').pop() || "";

            var fileNameOnly = rawName.toLowerCase();
            var baseNameOnly = fileNameOnly;
            var dotIdx = fileNameOnly.lastIndexOf('.');
            if (dotIdx > 0) {
              baseNameOnly = fileNameOnly.substring(0, dotIdx);
            }

            var cleanNorm = cleanPath.toLowerCase();
            var nativeNorm = nativePath.toLowerCase();

            function cleanStrMatch(str) {
              if (!str) return "";
              var s = String(str);
              try { s = File.decode(s); } catch (_) {}
              return s.toLowerCase().replace(/\\/g, '/').replace(/[^\w\d]/g, '');
            }

            var cleanAlphaNorm = cleanStrMatch(fileNameOnly);
            var baseAlphaNorm = cleanStrMatch(baseNameOnly);

            function matchItem(ci) {
              if (!ci || ci.type === 2) return false;
              try {
                if (ci.getMediaPath) {
                  var mp = ci.getMediaPath();
                  if (mp && mp.length > 0) {
                    var mpNorm = mp.replace(/\\/g, '/').toLowerCase();
                    var tpNorm = targetPath.replace(/\\/g, '/').toLowerCase();
                    if (mpNorm === tpNorm || mp.toLowerCase() === nativeNorm) return true;
                    var mpAlpha = cleanStrMatch(mp);
                    if (mpAlpha && cleanAlphaNorm && (mpAlpha === cleanAlphaNorm || mpAlpha === baseAlphaNorm)) return true;
                  }
                }
              } catch (_) {}
              try {
                if (ci.name) {
                  var nLow = ci.name.toLowerCase();
                  if (nLow === fileNameOnly || nLow === baseNameOnly) return true;
                  var dot = nLow.lastIndexOf('.');
                  var nBase = dot > 0 ? nLow.substring(0, dot) : nLow;
                  if (nBase === baseNameOnly) return true;
                  var nAlpha = cleanStrMatch(ci.name);
                  if (nAlpha && (nAlpha === cleanAlphaNorm || nAlpha === baseAlphaNorm)) return true;
                }
              } catch (_) {}
              return false;
            }

            function scanBin(bin) {
              if (!bin || !bin.children) return null;
              for (var i = 0; i < bin.children.numItems; i++) {
                var it = bin.children[i];
                if (!it) continue;
                if (it.type !== 2) {
                  if (matchItem(it)) return it;
                } else if (it.type === 2) {
                  var f = scanBin(it);
                  if (f) return f;
                }
              }
              return null;
            }

            var prevTargetCount = (targetBin && targetBin.children) ? targetBin.children.numItems : 0;
            var prevRootCount = (root && root.children) ? root.children.numItems : 0;
            var didImportFallback = false;
            var targetItem = null;

            var pathsToTry = [cleanPath, nativePath];
            if (targetPath !== cleanPath && targetPath !== nativePath) {
              pathsToTry.push(targetPath);
            }

            // Check if file is already present with exact path
            targetItem = scanBin(targetBin) || scanBin(root);

            if (!targetItem) {
              // Attempt 1: Import directly into targetBin or root with lock retries
              for (var p1 = 0; p1 < pathsToTry.length && !didImportFallback; p1++) {
                var pPath1 = pathsToTry[p1];
                for (var lockAttempt = 0; lockAttempt < 5 && !didImportFallback; lockAttempt++) {
                  if (lockAttempt > 0) { try { $.sleep(300); } catch (_) {} }
                  
                  // Try targetBin first
                  if (targetBin && targetBin !== root) {
                    try {
                      var r1 = project.importFiles([pPath1], true, targetBin, false);
                      if (r1 === true || r1 === 1 || (targetBin.children && targetBin.children.numItems > prevTargetCount)) {
                        didImportFallback = true;
                        break;
                      }
                      var itCheck = scanBin(targetBin);
                      if (itCheck) {
                        targetItem = itCheck;
                        didImportFallback = true;
                        break;
                      }
                    } catch (_) {}
                  }

                  // If targetBin rejected or failed, import directly into root!
                  if (!didImportFallback && !targetItem) {
                    try {
                      var r2 = project.importFiles([pPath1], true);
                      if (r2 === true || r2 === 1 || (root && root.children && root.children.numItems > prevRootCount)) {
                        didImportFallback = true;
                        break;
                      }
                    } catch (_) {}
                  }

                  // Flag fallback
                  if (!didImportFallback && !targetItem) {
                    try {
                      var r3 = (targetBin && targetBin !== root) ?
                        project.importFiles([pPath1], 1, targetBin, 0) :
                        project.importFiles([pPath1]);
                      if (r3 === true || r3 === 1 || (targetBin && targetBin.children && targetBin.children.numItems > prevTargetCount) || (root && root.children && root.children.numItems > prevRootCount)) {
                        didImportFallback = true;
                        break;
                      }
                    } catch (_) {}
                  }

                  // Plain importFiles
                  if (!didImportFallback && !targetItem) {
                    try {
                      var r4 = project.importFiles([pPath1]);
                      if (r4 === true || r4 === 1 || (root && root.children && root.children.numItems > prevRootCount)) {
                        didImportFallback = true;
                        break;
                      }
                    } catch (_) {}
                  }
                }
              }

              // Safe Ingestion Polling: wait max 1s (4 x 250ms) to avoid CEP evalScript watchdog timeout
              for (var poll = 0; poll < 4 && !targetItem; poll++) {
                try { $.sleep(250); } catch (_) {}
                if (targetBin && targetBin.children && targetBin.children.numItems > prevTargetCount) {
                  for (var ci = targetBin.children.numItems - 1; ci >= 0; ci--) {
                    var cand = targetBin.children[ci];
                    if (cand && cand.type !== 2 && matchItem(cand)) {
                      targetItem = cand;
                      break;
                    }
                  }
                }
                if (!targetItem && root && root.children && root.children.numItems > prevRootCount) {
                  for (var ri0 = root.children.numItems - 1; ri0 >= 0; ri0--) {
                    var rCand0 = root.children[ri0];
                    if (rCand0 && rCand0.type !== 2 && matchItem(rCand0)) {
                      targetItem = rCand0;
                      break;
                    }
                  }
                }
                if (!targetItem) {
                  targetItem = scanBin(targetBin) || scanBin(root);
                }
              }
            }

            // Move item into targetBin if it was imported to root
            if (targetItem && targetBin && targetBin !== root) {
              try {
                if (typeof targetItem.moveBin === 'function') {
                  targetItem.moveBin(targetBin);
                }
              } catch (_) {}
            }

            var success = Boolean(targetItem) || Boolean(didImportFallback);

            if (success) {
                try {
                if (targetItem && ${shouldInsertTimeline ? 'true' : 'false'}) {
                  var sName = targetItem.name || "MediaFetch Timeline";
                  var insertedToSeq = false;
                  var aSeq = project.activeSequence;

                  function findSmartVideoTrackAndGap(seq, playheadTime) {
                    if (!seq || !seq.videoTracks || seq.videoTracks.numTracks === 0) return null;
                    var numTracks = seq.videoTracks.numTracks;
                    var pSec = (playheadTime && playheadTime.seconds !== undefined) ? playheadTime.seconds : (parseFloat(playheadTime) || 0);

                    var minUsableGap = 0.05;
                    var bestTrack = null;
                    var bestGap = Infinity;
                    var bestTrackIndex = -1;

                    // Start scanning from V2 (index 1) upwards to protect V1 base/footage track.
                    var startIdx = numTracks > 1 ? 1 : 0;

                    for (var t = startIdx; t < numTracks; t++) {
                      var trk = seq.videoTracks[t];
                      if (!trk) continue;
                      try {
                        if (trk.isLocked && trk.isLocked()) continue;
                      } catch (_) {}

                      var hasCollision = false;
                      var nextClipStart = Infinity;
                      var numClips = (trk.clips && trk.clips.numItems) ? trk.clips.numItems : 0;

                      for (var c = 0; c < numClips; c++) {
                        var cl = trk.clips[c];
                        if (!cl || !cl.start || !cl.end) continue;
                        var cStart = cl.start.seconds !== undefined ? cl.start.seconds : parseFloat(cl.start);
                        var cEnd = cl.end.seconds !== undefined ? cl.end.seconds : parseFloat(cl.end);

                        if (cStart <= pSec + 0.001 && cEnd > pSec + 0.001) {
                          hasCollision = true;
                          break;
                        }

                        if (cStart > pSec + 0.001) {
                          if (cStart < nextClipStart) {
                            nextClipStart = cStart;
                          }
                        }
                      }

                      if (!hasCollision) {
                        var gap = (nextClipStart !== Infinity) ? (nextClipStart - pSec) : Infinity;
                        if (gap >= minUsableGap) {
                          bestTrack = trk;
                          bestGap = gap;
                          bestTrackIndex = t;
                          break;
                        }
                      }
                    }

                    if (!bestTrack && startIdx > 0) {
                      var v1Trk = seq.videoTracks[0];
                      if (v1Trk) {
                        var v1Locked = false;
                        try { v1Locked = (v1Trk.isLocked && v1Trk.isLocked()); } catch (_) {}
                        if (!v1Locked) {
                          var v1Collision = false;
                          var v1NextStart = Infinity;
                          var v1NumClips = (v1Trk.clips && v1Trk.clips.numItems) ? v1Trk.clips.numItems : 0;
                          for (var c1 = 0; c1 < v1NumClips; c1++) {
                            var cl1 = v1Trk.clips[c1];
                            if (!cl1 || !cl1.start || !cl1.end) continue;
                            var cs1 = cl1.start.seconds !== undefined ? cl1.start.seconds : parseFloat(cl1.start);
                            var ce1 = cl1.end.seconds !== undefined ? cl1.end.seconds : parseFloat(cl1.end);
                            if (cs1 <= pSec + 0.001 && ce1 > pSec + 0.001) {
                              v1Collision = true;
                              break;
                            }
                            if (cs1 > pSec + 0.001 && cs1 < v1NextStart) {
                              v1NextStart = cs1;
                            }
                          }
                          if (!v1Collision) {
                            var v1Gap = (v1NextStart !== Infinity) ? (v1NextStart - pSec) : Infinity;
                            if (v1Gap >= minUsableGap) {
                              bestTrack = v1Trk;
                              bestGap = v1Gap;
                              bestTrackIndex = 0;
                            }
                          }
                        }
                      }
                    }

                    if (!bestTrack) {
                      bestTrackIndex = numTracks - 1;
                      bestTrack = seq.videoTracks[bestTrackIndex];
                      bestGap = Infinity;
                    }

                    return { track: bestTrack, gapDuration: bestGap, trackIndex: bestTrackIndex };
                  }

                  function getTargetVideoTrack(seq, playheadTime) {
                    var res = findSmartVideoTrackAndGap(seq, playheadTime);
                    return res ? res.track : null;
                  }

                  function findClearVideoTrack(seq, playheadTime) {
                    if (!seq || !seq.videoTracks || seq.videoTracks.numTracks === 0) return null;
                    var numTracks = seq.videoTracks.numTracks;
                    var pSec = (playheadTime && playheadTime.seconds !== undefined) ? playheadTime.seconds : (parseFloat(playheadTime) || 0);

                    var bestTrack = null;
                    var bestTrackIndex = -1;

                    // Check the top-most video track (newest / highest layer)
                    var topIdx = numTracks - 1;
                    var topTrk = seq.videoTracks[topIdx];
                    var topLocked = false;
                    try { topLocked = (topTrk && topTrk.isLocked && topTrk.isLocked()); } catch (_) {}

                    if (topTrk && !topLocked) {
                      var hasCollision = false;
                      var hasClipsAfter = false;
                      var numClips = (topTrk.clips && topTrk.clips.numItems) ? topTrk.clips.numItems : 0;

                      for (var c = 0; c < numClips; c++) {
                        var cl = topTrk.clips[c];
                        if (!cl || !cl.start || !cl.end) continue;
                        var cStart = cl.start.seconds !== undefined ? cl.start.seconds : parseFloat(cl.start);
                        var cEnd = cl.end.seconds !== undefined ? cl.end.seconds : parseFloat(cl.end);

                        if (cStart <= pSec + 0.001 && cEnd > pSec + 0.001) {
                          hasCollision = true;
                          break;
                        }
                        if (cStart > pSec + 0.001) {
                          hasClipsAfter = true;
                          break;
                        }
                      }

                      // If top track has space from playhead to infinity, use it!
                      if (!hasCollision && !hasClipsAfter) {
                        bestTrack = topTrk;
                        bestTrackIndex = topIdx;
                      }
                    }

                    // If top track does not have space, CREATE A NEW TOP VIDEO LAYER!
                    if (!bestTrack) {
                      try {
                        if (typeof app.enableQE === "function") app.enableQE();
                        if (typeof qe !== "undefined" && qe.project) {
                          var qSeq = qe.project.getActiveSequence();
                          if (qSeq && typeof qSeq.addTracks === "function") {
                            qSeq.addTracks(1, seq.videoTracks.numTracks, 0, 0, 0);
                            if (seq.videoTracks.numTracks > numTracks) {
                              bestTrackIndex = seq.videoTracks.numTracks - 1;
                              bestTrack = seq.videoTracks[bestTrackIndex];
                            }
                          }
                        }
                      } catch (_) {}
                      if (!bestTrack) {
                        bestTrackIndex = numTracks - 1;
                        bestTrack = seq.videoTracks[bestTrackIndex];
                      }
                    }

                    return { track: bestTrack, trackIndex: bestTrackIndex, gapDuration: Infinity };
                  }

                  function findClearAudioTrack(seq, playheadTime) {
                    if (!seq || !seq.audioTracks || seq.audioTracks.numTracks === 0) return null;
                    var numTracks = seq.audioTracks.numTracks;
                    var pSec = (playheadTime && playheadTime.seconds !== undefined) ? playheadTime.seconds : (parseFloat(playheadTime) || 0);

                    var bestTrack = null;
                    var bestTrackIndex = -1;

                    // Check the bottom-most audio track (newest / lowest layer)
                    var botIdx = numTracks - 1;
                    var botTrk = seq.audioTracks[botIdx];
                    var botLocked = false;
                    try { botLocked = (botTrk && botTrk.isLocked && botTrk.isLocked()); } catch (_) {}

                    if (botTrk && !botLocked) {
                      var hasCollision = false;
                      var hasClipsAfter = false;
                      var numClips = (botTrk.clips && botTrk.clips.numItems) ? botTrk.clips.numItems : 0;

                      for (var c = 0; c < numClips; c++) {
                        var cl = botTrk.clips[c];
                        if (!cl || !cl.start || !cl.end) continue;
                        var cStart = cl.start.seconds !== undefined ? cl.start.seconds : parseFloat(cl.start);
                        var cEnd = cl.end.seconds !== undefined ? cl.end.seconds : parseFloat(cl.end);

                        if (cStart <= pSec + 0.001 && cEnd > pSec + 0.001) {
                          hasCollision = true;
                          break;
                        }
                        if (cStart > pSec + 0.001) {
                          hasClipsAfter = true;
                          break;
                        }
                      }

                      // If bottom track has space from playhead to infinity, use it!
                      if (!hasCollision && !hasClipsAfter) {
                        bestTrack = botTrk;
                        bestTrackIndex = botIdx;
                      }
                    }

                    // If bottom track does not have space, CREATE A NEW STEREO AUDIO LAYER AT BOTTOM!
                    if (!bestTrack) {
                      try {
                        if (typeof app.enableQE === "function") app.enableQE();
                        if (typeof qe !== "undefined" && qe.project) {
                          var qSeq = qe.project.getActiveSequence();
                          if (qSeq && typeof qSeq.addTracks === "function") {
                            qSeq.addTracks(0, 0, 1, 1, seq.audioTracks.numTracks);
                            if (seq.audioTracks.numTracks > numTracks) {
                              bestTrackIndex = seq.audioTracks.numTracks - 1;
                              bestTrack = seq.audioTracks[bestTrackIndex];
                            }
                          }
                        }
                      } catch (_) {}
                      if (!bestTrack) {
                        bestTrackIndex = numTracks - 1;
                        bestTrack = seq.audioTracks[bestTrackIndex];
                      }
                    }

                    return { track: bestTrack, trackIndex: bestTrackIndex, gapDuration: Infinity };
                  }

                  function targetTracks(seq, videoTrackIndex, audioTrackIndex) {
                    if (!seq) return;
                    try {
                      if (seq.videoTracks) {
                        for (var vt = 0; vt < seq.videoTracks.numTracks; vt++) {
                          try {
                            if (typeof seq.videoTracks[vt].setTargeted === "function") {
                              seq.videoTracks[vt].setTargeted(videoTrackIndex !== null && videoTrackIndex !== undefined && vt === videoTrackIndex);
                            }
                          } catch (_) {}
                        }
                      }
                    } catch (_) {}
                    try {
                      if (seq.audioTracks) {
                        for (var at = 0; at < seq.audioTracks.numTracks; at++) {
                          try {
                            if (typeof seq.audioTracks[at].setTargeted === "function") {
                              seq.audioTracks[at].setTargeted(audioTrackIndex !== null && audioTrackIndex !== undefined && at === audioTrackIndex);
                            }
                          } catch (_) {}
                        }
                      }
                    } catch (_) {}
                  }

                  function findSmartAudioTrackAndGap(seq, playheadTime) {
                    return findClearAudioTrack(seq, playheadTime);
                  }

                  function getTargetAudioTrack(seq, playheadTime) {
                    var res = findClearAudioTrack(seq, playheadTime);
                    return res ? res.track : null;
                  }

                  // 1. Insert directly into active sequence timeline at playhead position
                  if (aSeq) {
                    var pPos = aSeq.getPlayerPosition();
                    var pTicks = "0";
                    var pSec = 0;
                    if (pPos) {
                      if (pPos.ticks !== undefined && pPos.ticks !== null && String(pPos.ticks).length > 0) {
                        pTicks = String(pPos.ticks);
                      }
                      if (pPos.seconds !== undefined) {
                        pSec = pPos.seconds;
                        if (pTicks === "0") pTicks = String(Math.round(parseFloat(pPos.seconds) * 254016000000));
                      } else {
                        pSec = parseFloat(pPos) || 0;
                        if (pTicks === "0" && pSec > 0) pTicks = String(Math.round(pSec * 254016000000));
                      }
                    }
                    for (var insTry = 0; insTry < 4 && !insertedToSeq; insTry++) {
                      if (insTry > 0) { try { $.sleep(250); } catch (_) {} }
                      if (isAudio) {
                        // AUDIO ONLY: Clear track, full duration
                        var clearAudio = findClearAudioTrack(aSeq, pPos);
                        var aTrk = clearAudio ? clearAudio.track : null;
                        var aIdx = clearAudio ? clearAudio.trackIndex : -1;
                        if (aTrk) {
                          targetTracks(aSeq, null, aIdx);
                          if (pTicks && pTicks !== "0" && typeof aTrk.overwriteClip === "function") {
                            try { aTrk.overwriteClip(targetItem, pTicks); insertedToSeq = true; } catch (_) {}
                          }
                          if (!insertedToSeq && pPos && typeof aTrk.overwriteClip === "function") {
                            try { aTrk.overwriteClip(targetItem, pPos); insertedToSeq = true; } catch (_) {}
                          }
                          if (!insertedToSeq && pPos) { try { aTrk.insertClip(targetItem, pPos); insertedToSeq = true; } catch (_) {} }
                          if (!insertedToSeq && pTicks && pTicks !== "0") { try { aTrk.insertClip(targetItem, pTicks); insertedToSeq = true; } catch (_) {} }
                          if (!insertedToSeq) { try { aTrk.insertClip(targetItem, "0"); insertedToSeq = true; } catch (_) {} }
                        }
                      } else if (isImage) {
                        // IMAGE MEDIA ONLY: Smart gap-fitting & auto-trim duration (NEVER FOR VIDEO OR AUDIO)
                        var smartVideo = findSmartVideoTrackAndGap(aSeq, pPos);
                        var vTrk = smartVideo ? smartVideo.track : null;
                        var vGap = smartVideo ? smartVideo.gapDuration : Infinity;
                        var vIdx = smartVideo ? smartVideo.trackIndex : -1;
                        if (vTrk) {
                          targetTracks(aSeq, vIdx, null);
                          var targetDurSec = (vGap !== Infinity && vGap > 0) ? vGap : 5.0;
                          try {
                            var tIn = new Time();
                            tIn.ticks = "0";
                            try { targetItem.setInPoint(tIn, 4); } catch (_) { try { targetItem.setInPoint(tIn); } catch (_) {} }
                            var tOut = new Time();
                            tOut.ticks = String(Math.round(targetDurSec * 254016000000));
                            try { targetItem.setOutPoint(tOut, 4); } catch (_) { try { targetItem.setOutPoint(tOut); } catch (_) {} }
                          } catch (_) {}

                          // OverwriteClip preserves timeline boundaries best
                          if (vIdx >= 0 && vGap !== Infinity) {
                            try {
                              if (typeof app.enableQE === "function") app.enableQE();
                              if (typeof qe !== "undefined" && qe.project) {
                                var qSeq = qe.project.getActiveSequence();
                                if (qSeq && typeof qSeq.getVideoTrackAt === "function") {
                                  var qTrk = qSeq.getVideoTrackAt(vIdx);
                                  if (qTrk && typeof qTrk.overwriteClip === "function") {
                                    if (pTicks && pTicks !== "0") {
                                      try { qTrk.overwriteClip(targetItem, pTicks); insertedToSeq = true; } catch (_) {}
                                    }
                                    if (!insertedToSeq) {
                                      try { qTrk.overwriteClip(targetItem, pPos); insertedToSeq = true; } catch (_) {}
                                    }
                                  }
                                }
                              }
                            } catch (_) {}
                          }

                          if (!insertedToSeq && pTicks && pTicks !== "0" && typeof vTrk.overwriteClip === "function") {
                            try { vTrk.overwriteClip(targetItem, pTicks); insertedToSeq = true; } catch (_) {}
                          }
                          if (!insertedToSeq && pPos && typeof vTrk.overwriteClip === "function") {
                            try { vTrk.overwriteClip(targetItem, pPos); insertedToSeq = true; } catch (_) {}
                          }
                          if (!insertedToSeq && pTicks && pTicks !== "0") {
                            try { vTrk.insertClip(targetItem, pTicks); insertedToSeq = true; } catch (_) {}
                          }
                          if (!insertedToSeq && pPos) {
                            try { vTrk.insertClip(targetItem, pPos); insertedToSeq = true; } catch (_) {}
                          }
                          if (!insertedToSeq) { try { vTrk.insertClip(targetItem, "0"); insertedToSeq = true; } catch (_) {} }

                          // Clamp image to gap
                          if (insertedToSeq && vGap !== Infinity && vGap > 0 && vTrk.clips) {
                            try {
                              var pSecVal = (pPos && pPos.seconds !== undefined) ? pPos.seconds : (parseFloat(pPos) || 0);
                              var maxAllowedEnd = pSecVal + vGap;
                              for (var cChk = 0; cChk < vTrk.clips.numItems; cChk++) {
                                var plClip = vTrk.clips[cChk];
                                if (!plClip || !plClip.start || !plClip.end) continue;
                                var plStartSec = plClip.start.seconds !== undefined ? plClip.start.seconds : parseFloat(plClip.start);
                                if (Math.abs(plStartSec - pSecVal) < 0.05) {
                                  var plEndSec = plClip.end.seconds !== undefined ? plClip.end.seconds : parseFloat(plClip.end);
                                  if (plEndSec > maxAllowedEnd + 0.01) {
                                    try {
                                      var eTime = new Time();
                                      eTime.ticks = String(Math.round(maxAllowedEnd * 254016000000));
                                      plClip.end = eTime;
                                    } catch (_) {
                                      try { plClip.end = maxAllowedEnd; } catch (_) {}
                                    }
                                    try {
                                      var oTime = new Time();
                                      oTime.ticks = String(Math.round(vGap * 254016000000));
                                      plClip.outPoint = oTime;
                                    } catch (_) {}
                                  }
                                  break;
                                }
                              }
                            } catch (_) {}
                          }
                        }
                      } else {
                        // VIDEO MEDIA: Clear track for both video and audio, full duration, zero clips cut on the right
                        var clearVid = findClearVideoTrack(aSeq, pPos);
                        var clearAud = findClearAudioTrack(aSeq, pPos);
                        var vTrk = clearVid ? clearVid.track : null;
                        var vIdx = clearVid ? clearVid.trackIndex : -1;
                        var aIdx = clearAud ? clearAud.trackIndex : -1;

                        if (vTrk) {
                          targetTracks(aSeq, vIdx, aIdx);
                          if (pTicks && pTicks !== "0" && typeof vTrk.overwriteClip === "function") {
                            try { vTrk.overwriteClip(targetItem, pTicks); insertedToSeq = true; } catch (_) {}
                          }
                          if (!insertedToSeq && pPos && typeof vTrk.overwriteClip === "function") {
                            try { vTrk.overwriteClip(targetItem, pPos); insertedToSeq = true; } catch (_) {}
                          }
                          if (!insertedToSeq && pTicks && pTicks !== "0") {
                            try { vTrk.insertClip(targetItem, pTicks); insertedToSeq = true; } catch (_) {}
                          }
                          if (!insertedToSeq && pPos) {
                            try { vTrk.insertClip(targetItem, pPos); insertedToSeq = true; } catch (_) {}
                          }
                          if (!insertedToSeq) { try { vTrk.insertClip(targetItem, "0"); insertedToSeq = true; } catch (_) {} }
                        }
                      }
                    }
                    if (insertedToSeq && pPos) {
                      try {
                        if (typeof aSeq.setPlayerPosition === 'function') {
                          try {
                            aSeq.setPlayerPosition(pPos);
                          } catch (_) {
                            try {
                              var tOrig = new Time();
                              tOrig.ticks = pTicks;
                              aSeq.setPlayerPosition(tOrig);
                            } catch (_) {
                              try { aSeq.setPlayerPosition(pTicks); } catch (_) {}
                            }
                          }
                        }
                      } catch (_) {}
                    }
                  }

                  // 2. Fallback: if no active sequence, create one
                  if (!insertedToSeq) {
                    if (typeof project.createNewSequenceFromClips === "function") {
                      var ns = project.createNewSequenceFromClips(sName, [targetItem], targetBin);
                      if (ns) {
                        insertedToSeq = true;
                        if (project.openSequence) project.openSequence(ns.sequenceID);
                      }
                    }
                    if (insertedToSeq && pPos) {
                      try {
                        if (typeof aSeq.setPlayerPosition === 'function') {
                          try {
                            aSeq.setPlayerPosition(pPos);
                          } catch (_) {
                            try {
                              var tOrig = new Time();
                              tOrig.ticks = pTicks;
                              aSeq.setPlayerPosition(tOrig);
                            } catch (_) {
                              try { aSeq.setPlayerPosition(pTicks); } catch (_) {}
                            }
                          }
                        }
                      } catch (_) {}
                    }
                  }
                }
              } catch (_) {}
            }
            return success ? "true" : "false";
          } catch (err) {
            return "error: " + err;
          }
        })();
      `;
      const res = await this.evalScript(script);
      console.log('[Premiere importToProject result]:', res);
      return res === 'true' || res === true;
    } catch {
      return false;
    }
  }

  public getHostTheme(): 'dark' | 'light' | 'darkest' | 'lightest' {
    if (typeof window !== 'undefined' && (window as any).__adobe_cep__) {
      try {
        const skin = (window as any).__adobe_cep__.getHostEnvironment()?.appSkinInfo;
        if (skin?.panelBackgroundColor?.color) {
          const r = skin.panelBackgroundColor.color.red;
          if (r < 50) return 'darkest';
          if (r < 100) return 'dark';
          if (r > 200) return 'lightest';
          return 'light';
        }
      } catch {}
    }
    return 'dark';
  }

  public onThemeChanged(callback: (theme: string) => void): void {
    this.themeListeners.push(callback);
    if (typeof window !== 'undefined' && (window as any).__adobe_cep__) {
      try {
        (window as any).__adobe_cep__.addEventListener('com.adobe.csxs.events.ThemeChanged', () => {
          callback(this.getHostTheme());
        });
      } catch {}
    }
  }

  private evalScript(script: string): Promise<any> {
    return new Promise((resolve) => {
      let resolved = false;
      const timer = setTimeout(() => {
        if (!resolved) {
          resolved = true;
          resolve(null);
        }
      }, 120000);

      try {
        if (typeof window !== 'undefined' && (window as any).__adobe_cep__) {
          (window as any).__adobe_cep__.evalScript(script, (result: any) => {
            if (!resolved) {
              resolved = true;
              clearTimeout(timer);
              resolve(result);
            }
          });
          return;
        }
        if (typeof window !== 'undefined' && (window as any).CSInterface) {
          const cs = new (window as any).CSInterface();
          cs.evalScript(script, (result: any) => {
            if (!resolved) {
              resolved = true;
              clearTimeout(timer);
              resolve(result);
            }
          });
          return;
        }
      } catch (e) {
        console.warn('evalScript error:', e);
      }
      if (!resolved) {
        resolved = true;
        clearTimeout(timer);
        resolve(null);
      }
    });
  }
}
