import { ProjectContext } from '../common/types.js';

export interface HostImportOptions {
  isPlaylist?: boolean;
  playlistTitle?: string;
  isCloud?: boolean;
  customFolderName?: string;
  subFolderName?: string;
  isCustomPath?: boolean;
  isCustomFlat?: boolean;
  isSimplePath?: boolean;
  isSimple?: boolean;
  downloadLocationMode?: string;
  category?: 'link' | 'search' | 'playlist' | 'cloud';
  insertToTimeline?: boolean;
  addToTimeline?: boolean;
  isSingleLink?: boolean;
  isBatch?: boolean;
  isSearch?: boolean;
  isClipboard?: boolean;
}

export interface IHostAdapter {
  getProjectContext(): Promise<ProjectContext>;
  revealInFinder(filePath: string): Promise<void>;
  openFile(filePath: string): Promise<void>;
  importToProject(filePath: string, options?: HostImportOptions): Promise<boolean>;
  getHostTheme(): 'dark' | 'light' | 'darkest' | 'lightest';
  onThemeChanged(callback: (theme: string) => void): void;
}
