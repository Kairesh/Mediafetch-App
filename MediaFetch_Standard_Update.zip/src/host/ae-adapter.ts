import { IHostAdapter, HostImportOptions } from './adapter-interface.js';
import { ProjectContext } from '../common/types.js';

export class AfterEffectsHostAdapter implements IHostAdapter {
  private themeListeners: ((theme: string) => void)[] = [];

  public async getProjectContext(): Promise<ProjectContext> {
    try {
      const script = `
        (function() {
          try {
            if (app && app.project) {
              if (app.project.file && app.project.file.exists) {
                return JSON.stringify({
                  saved: true,
                  path: app.project.file.fsName,
                  name: app.project.file.displayName || "After Effects Project",
                  version: app.version || "26.0"
                });
              } else {
                return JSON.stringify({
                  saved: false,
                  name: "Active AE Project (Unsaved)",
                  version: app.version || "26.0"
                });
              }
            }
          } catch (err) {
            return JSON.stringify({ saved: false, error: String(err) });
          }
          return JSON.stringify({ saved: false });
        })();
      `;

      const result = await this.evalScript(script);
      if (result && typeof result === 'string' && result !== 'EvalScript error.') {
          const parsed = JSON.parse(result);
          if (parsed) {
            if (parsed.saved && parsed.path) {
              const cleanPath = parsed.path.replace(/\\/g, '/');
              const dir = cleanPath.substring(0, cleanPath.lastIndexOf('/'));
              const name = cleanPath.substring(cleanPath.lastIndexOf('/') + 1) || parsed.name;
              return {
                application: 'aftereffects',
                applicationVersion: parsed.version || '26.0',
                projectSaved: true,
                projectName: name,
                projectPath: parsed.path,
                projectDirectory: dir.replace(/\//g, '\\')
              };
            } else if (parsed.name) {
              return {
                application: 'aftereffects',
                applicationVersion: parsed.version || '26.0',
                projectSaved: false,
                projectName: parsed.name
              };
            }
          }
      }
    } catch (e) {
      console.warn('Error reading After Effects project context:', e);
    }

    return {
      application: 'aftereffects',
      applicationVersion: '26.0',
      projectSaved: false
    };
  }

  public async revealInFinder(filePath: string): Promise<void> {
    try {
      if (typeof window !== 'undefined' && (window as any).require) {
        const cp = (window as any).require('child_process');
        if (cp?.exec) {
          cp.exec(`explorer.exe /select,"${filePath.replace(/\//g, '\\')}"`);
          return;
        }
      }
    } catch {}

    try {
      const script = `
        (function() {
          var f = new File("${filePath.replace(/\\/g, '/')}");
          if (f.exists) {
            f.execute();
          }
        })();
      `;
      await this.evalScript(script);
    } catch {}
  }

  public async openFile(filePath: string): Promise<void> {
    await this.revealInFinder(filePath);
  }

  public async importToProject(filePath: string, options?: HostImportOptions): Promise<boolean> {
    try {
      const cleanPath = filePath.replace(/\\/g, '/');
      const isCustom = options?.isCustomPath ? true : false;
      const isCloud = options?.isCloud ? true : false;
      const isPlaylist = options?.isPlaylist ? true : false;
      const isBatch = options?.isBatch ? true : false;
      const isSingleLink = options?.isSingleLink !== undefined ? options.isSingleLink : (!isPlaylist && !isCloud && !isBatch);
      const shouldInsertTimeline = Boolean(options?.insertToTimeline && isSingleLink);
      const playlistTitle = (options?.playlistTitle || '').replace(/[\\/:"*?<>|]/g, ' ').trim();
      const customFolderName = (options?.customFolderName || '').replace(/[\\/:"*?<>|]/g, ' ').trim();
      const subFolderName = (options?.subFolderName || '').trim();

      const script = `
        (function() {
          try {
            if (typeof app === "undefined" || !app.project) return "no_project";
            var proj = app.project;
            
            function getOrCreateAeFolder(proj, parentFolder, folderName) {
              for (var i = 1; i <= proj.numItems; i++) {
                var it = proj.item(i);
                if (it && (it instanceof FolderItem || it.typeName === "Folder") && it.name === folderName) {
                  if (!parentFolder && (!it.parentFolder || it.parentFolder === proj.rootFolder)) {
                    return it;
                  }
                  if (parentFolder && it.parentFolder === parentFolder) {
                    return it;
                  }
                }
              }
              var newFolder = proj.items.addFolder(folderName);
              if (parentFolder) {
                newFolder.parentFolder = parentFolder;
              }
              return newFolder;
            }

            var targetPath = "${cleanPath}";
            var isCustom = ${isCustom ? 'true' : 'false'};
            var isCloud = ${isCloud ? 'true' : 'false'};
            var isPlaylist = ${isPlaylist ? 'true' : 'false'};
            var playlistTitle = "${playlistTitle.replace(/"/g, '\\"')}";
            var customFolderName = "${customFolderName.replace(/"/g, '\\"')}";
            var subFolderName = "${subFolderName.replace(/"/g, '\\"').replace(/\\/g, '/')}";

            var targetFolder = null;

            if (isCustom) {
              // Custom Directory: create root bin outside MediaFetch named after the selected custom folder
              var rootBinName = customFolderName || (isPlaylist ? (playlistTitle || "Playlist") : (isCloud ? "Cloud Media" : ""));
              if (!rootBinName) {
                var pParts = targetPath.split('/');
                rootBinName = pParts.length > 1 ? pParts[pParts.length - 2] : "Downloads";
              }
              var customRootFolder = getOrCreateAeFolder(proj, null, rootBinName);
              if (subFolderName) {
                var sParts = subFolderName.split('/');
                var cur = customRootFolder;
                for (var s = 0; s < sParts.length; s++) {
                  if (sParts[s] && sParts[s].length > 0) {
                    cur = getOrCreateAeFolder(proj, cur, sParts[s]);
                  }
                }
                targetFolder = cur || customRootFolder;
              } else {
                targetFolder = customRootFolder;
              }
            } else {
              // Default Project Path: inside root "MediaFetch" bin
              var mediaFetchFolder = getOrCreateAeFolder(proj, null, "MediaFetch");

              if (isCloud) {
                // MediaFetch -> Cloud Links -> [Cloud Folder Name] -> [Subfolders]
                var cloudRoot = getOrCreateAeFolder(proj, mediaFetchFolder, "Cloud Links");
                var cloudFolder = getOrCreateAeFolder(proj, cloudRoot, customFolderName || "Cloud Media");
                if (subFolderName) {
                  var sParts = subFolderName.split('/');
                  var cur = cloudFolder;
                  for (var s = 0; s < sParts.length; s++) {
                    if (sParts[s] && sParts[s].length > 0) {
                      cur = getOrCreateAeFolder(proj, cur, sParts[s]);
                    }
                  }
                  targetFolder = cur || cloudFolder;
                } else {
                  targetFolder = cloudFolder;
                }
              } else if (isPlaylist) {
                // MediaFetch -> Playlists -> [Playlist Name]
                var playlistRoot = getOrCreateAeFolder(proj, mediaFetchFolder, "Playlists");
                var pName = playlistTitle || customFolderName || "Playlist 1";
                targetFolder = getOrCreateAeFolder(proj, playlistRoot, pName);
              } else {
                // Single link or Search
                var isSearch = targetPath.indexOf("SerachMediafetch") !== -1 || 
                               targetPath.indexOf("MediaFetch Assets") !== -1 || 
                               targetPath.indexOf("MediaSearch Assets") !== -1;
                var categoryFolderName = isSearch ? "SerachMediafetch" : "LinkMediaFetch";
                var categoryFolder = getOrCreateAeFolder(proj, mediaFetchFolder, categoryFolderName);

                var parts = targetPath.split('.');
                var ext = parts.length > 1 ? parts[parts.length - 1].toLowerCase().split('?')[0] : '';
                var isAudio = (ext === 'mp3' || ext === 'wav' || ext === 'm4a' || ext === 'flac' || ext === 'aac' || ext === 'ogg' || ext === 'opus' || ext === 'aiff');
                var isImage = (ext === 'jpg' || ext === 'jpeg' || ext === 'png' || ext === 'webp' || ext === 'gif' || ext === 'bmp' || ext === 'tiff' || ext === 'tif' || ext === 'svg');
                var typeFolderName = isAudio ? "Audio" : (isImage ? "Image" : "Video");
                targetFolder = getOrCreateAeFolder(proj, categoryFolder, typeFolderName) || categoryFolder;
              }
            }

            // Locate media file
            var mediaFile = new File(targetPath);
            if (!mediaFile.exists) {
              mediaFile = new File("${filePath.replace(/\\/g, '\\\\')}");
            }
            if (!mediaFile.exists) {
              return "file_not_found: " + targetPath;
            }

            // Check if file is ALREADY imported in project
            for (var j = 1; j <= proj.numItems; j++) {
              var existingItem = proj.item(j);
              if (existingItem && existingItem.file && existingItem.file.fsName === mediaFile.fsName) {
                return "true";
              }
            }

            // Import media into target folder
            var io = new ImportOptions();
            io.file = mediaFile;
            var importedItem = proj.importFile(io);
            if (importedItem) {
              importedItem.parentFolder = targetFolder || proj.rootFolder;
              if (${shouldInsertTimeline ? 'true' : 'false'}) {
                try {
                  var comp = proj.activeItem;
                  if (!comp || !(comp instanceof CompItem)) {
                    for (var cIdx = 1; cIdx <= proj.numItems; cIdx++) {
                      if (proj.item(cIdx) instanceof CompItem) {
                        comp = proj.item(cIdx);
                        break;
                      }
                    }
                  }
                  if (!comp || !(comp instanceof CompItem)) {
                    var w = (importedItem.width && importedItem.width > 0) ? importedItem.width : 1920;
                    var h = (importedItem.height && importedItem.height > 0) ? importedItem.height : 1080;
                    var dur = (importedItem.duration && importedItem.duration > 0) ? importedItem.duration : 30;
                    var fps = (importedItem.frameRate && importedItem.frameRate > 0) ? importedItem.frameRate : 30;
                    var rawName = importedItem.name || "MediaFetch Comp";
                    var dotIdx = rawName.lastIndexOf(".");
                    var cName = (dotIdx > 0) ? rawName.substring(0, dotIdx) : rawName;
                    comp = proj.items.addComposition(cName, w, h, 1.0, dur, fps);
                  }
                  if (comp && comp instanceof CompItem) {
                    var playheadTime = (comp.time !== undefined && comp.time !== null) ? comp.time : 0;
                    var layer = comp.layers.add(importedItem);
                    if (layer) {
                      layer.startTime = playheadTime;
                      layer.moveToBeginning();
                    }
                  }
                } catch (_) {}
              }
              return "true";
            }
            return "cannot_import";
          } catch (err) {
            return "error: " + err;
          }
        })();
      `;
      const res = await this.evalScript(script);
      console.log('[AfterEffects importToProject result]:', res);
      return res === 'true' || res === true;
    } catch {
      return false;
    }
  }

  public getHostTheme(): 'dark' | 'light' | 'darkest' | 'lightest' {
    if (typeof window !== 'undefined' && (window as any).__adobe_cep__) {
      try {
        const skin = (window as any).__adobe_cep__.getHostEnvironment()?.appSkinInfo;
        if (skin?.panelBackgroundColor?.color) {
          const r = skin.panelBackgroundColor.color.red;
          if (r < 50) return 'darkest';
          if (r < 100) return 'dark';
          if (r > 200) return 'lightest';
          return 'light';
        }
      } catch {}
    }
    return 'dark';
  }

  public onThemeChanged(callback: (theme: string) => void): void {
    this.themeListeners.push(callback);
    if (typeof window !== 'undefined' && (window as any).__adobe_cep__) {
      try {
        (window as any).__adobe_cep__.addEventListener('com.adobe.csxs.events.ThemeChanged', () => {
          callback(this.getHostTheme());
        });
      } catch {}
    }
  }

  private evalScript(script: string): Promise<any> {
    return new Promise((resolve) => {
      let resolved = false;
      const timer = setTimeout(() => {
        if (!resolved) {
          resolved = true;
          resolve(null);
        }
      }, 1200);

      try {
        if (typeof window !== 'undefined' && (window as any).__adobe_cep__) {
          (window as any).__adobe_cep__.evalScript(script, (result: any) => {
            if (!resolved) {
              resolved = true;
              clearTimeout(timer);
              resolve(result);
            }
          });
          return;
        }
        if (typeof window !== 'undefined' && (window as any).CSInterface) {
          const cs = new (window as any).CSInterface();
          cs.evalScript(script, (result: any) => {
            if (!resolved) {
              resolved = true;
              clearTimeout(timer);
              resolve(result);
            }
          });
          return;
        }
      } catch (e) {
        console.warn('evalScript error:', e);
      }
      if (!resolved) {
        resolved = true;
        clearTimeout(timer);
        resolve(null);
      }
    });
  }
}
