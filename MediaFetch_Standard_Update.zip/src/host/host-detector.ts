import { IHostAdapter } from './adapter-interface.js';
import { PremiereHostAdapter } from './premiere-adapter.js';
import { AfterEffectsHostAdapter } from './ae-adapter.js';
import { ProjectContext } from '../common/types.js';

export class StandaloneHostAdapter implements IHostAdapter {
  public async getProjectContext(): Promise<ProjectContext> {
    return {
      application: 'standalone',
      applicationVersion: '1.0.0',
      projectSaved: false
    };
  }

  public async revealInFinder(filePath: string): Promise<void> {
    console.log('Reveal in finder:', filePath);
  }

  public async openFile(filePath: string): Promise<void> {
    console.log('Open file:', filePath);
  }

  public async importToProject(filePath: string): Promise<boolean> {
    console.log('Import to project (standalone):', filePath);
    return false;
  }

  public getHostTheme(): 'dark' | 'light' | 'darkest' | 'lightest' {
    return 'dark';
  }

  public onThemeChanged(callback: (theme: string) => void): void {
    // No-op for standalone browser
  }
}

export function createHostAdapter(): IHostAdapter {
  if (typeof window !== 'undefined') {
    // 1. Check Adobe CEP native environment
    if ((window as any).__adobe_cep__) {
      try {
        let hostId = '';
        const rawEnv = (window as any).__adobe_cep__.getHostEnvironment();
        if (typeof rawEnv === 'string') {
          try {
            const parsed = JSON.parse(rawEnv);
            hostId = (parsed.appId || '').toLowerCase();
          } catch {}
        } else if (rawEnv && typeof rawEnv === 'object') {
          hostId = (rawEnv.appId || '').toLowerCase();
        }

        console.log('[HostDetector] Detected CEP host ID:', hostId);

        if (hostId === 'ppro' || hostId.includes('premiere')) {
          return new PremiereHostAdapter();
        } else {
          // Default to After Effects adapter for AEFT, AEBX, or any CEP host
          return new AfterEffectsHostAdapter();
        }
      } catch (e) {
        console.warn('[HostDetector] Error reading CEP environment:', e);
        return new AfterEffectsHostAdapter();
      }
    }

    // 2. Check Adobe UXP environment
    if ((window as any).require) {
      try {
        const uxp = (window as any).require('uxp');
        const host = uxp?.host;
        const hostName = (host?.name || '').toLowerCase();
        if (hostName.includes('premiere')) {
          return new PremiereHostAdapter();
        } else if (hostName.includes('aftereffects')) {
          return new AfterEffectsHostAdapter();
        }
      } catch {}
    }
  }

  return new StandaloneHostAdapter();
}

export const hostAdapter = createHostAdapter();
