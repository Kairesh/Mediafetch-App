import { DownloadItem, DownloadError } from '../common/types.js';
export declare class RetryManager {
    private activeTimers;
    /**
     * Calculates exponential backoff delay in milliseconds.
     */
    calculateDelay(retryCount: number, baseDelayMs?: number, maxDelayMs?: number): number;
    /**
     * Checks whether a failed download item should be retried.
     */
    shouldRetry(item: DownloadItem, error?: DownloadError): boolean;
    /**
     * Schedules a retry with exponential backoff.
     */
    scheduleRetry(item: DownloadItem, onExecute: () => void, baseDelayMs?: number): number;
    cancelScheduledRetry(itemId: string): void;
    clearAll(): void;
}
export declare const retryManager: RetryManager;
