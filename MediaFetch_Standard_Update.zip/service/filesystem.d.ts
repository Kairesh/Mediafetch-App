import { ProjectContext, MediaFetchSettings } from '../common/types.js';
export declare class FilesystemManager {
    /**
     * Sanitizes a title string into a cross-platform safe filename.
     * Preserves Unicode characters while removing illegal OS characters and reserved names.
     */
    sanitizeFilename(title: string, ext?: string): string;
    /**
     * Resolves the target download directory based on project state and settings.
     */
    resolveTargetDirectory(projectContext?: ProjectContext, customOverride?: string, settings?: MediaFetchSettings): {
        targetDir: string;
        mode: string;
        isProjectFolder: boolean;
    };
    /**
     * Checks if a file already exists in target directory.
     */
    checkDuplicate(targetDir: string, filename: string): {
        exists: boolean;
        filePath: string;
        size: number;
    };
    /**
     * Resolves unique filename by incrementing Title (1).ext, Title (2).ext if collision exists.
     */
    resolveUniqueFilename(targetDir: string, desiredFilename: string): string;
    /**
     * Gets staging path inside .temp subfolder.
     */
    getTempStagingPath(targetDir: string, downloadId: string, ext?: string): string;
    /**
     * Verifies downloaded file and moves atomically to final path.
     */
    finalizeDownloadedFile(tempFilePath: string, targetDirectory: string, desiredFilename: string, overwrite?: boolean): {
        finalPath: string;
        fileSize: number;
    };
    ensureDirExists(dirPath: string): void;
    verifyWritePermission(dirPath: string): boolean;
}
export declare const filesystemManager: FilesystemManager;
