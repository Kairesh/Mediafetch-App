import { execFile } from 'child_process';
import { promisify } from 'util';
import https from 'https';
import http from 'http';
import fs from 'fs';
import path from 'path';
import os from 'os';
import { classifyError } from '../common/errors.js';
import { dependencyManager } from './dependencies.js';
import { settingsManager } from './settings.js';
import { logger } from './logger.js';
import { youtubeTokenManager } from './youtubeToken.js';

const execFileAsync = promisify(execFile);

function fetchHtml(targetUrl, headers = {}, maxRedirects = 5) {
  return new Promise((resolve, reject) => {
    if (maxRedirects <= 0) return reject(new Error('Too many redirects'));
    const client = targetUrl.startsWith('https:') ? https : http;
    const req = client.get(targetUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        ...headers
      }
    }, res => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        let next = res.headers.location;
        if (!next.startsWith('http')) {
          try {
            const u = new URL(targetUrl);
            next = u.origin + next;
          } catch (e) {
            return reject(e);
          }
        }
        return fetchHtml(next, headers, maxRedirects - 1).then(resolve, reject);
      }
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve({ statusCode: res.statusCode, body: data, finalUrl: targetUrl }));
    });
    req.on('error', reject);
    req.setTimeout(15000, () => {
      req.destroy();
      reject(new Error('HTTP request timed out'));
    });
  });
}

function fetchSmartHtml(targetUrl, headers = {}, maxRedirects = 5) {
  const fallbackUas = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
    'DuckDuckBot/1.0; (+http://duckduckgo.com/duckduckbot.html)',
    'Mozilla/5.0 (compatible; Discordbot/2.0; +https://discordapp.com)',
    'facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)'
  ];

  function tryUa(idx) {
    if (idx >= fallbackUas.length) {
      return Promise.reject(new Error('Failed to retrieve webpage HTML across all headers'));
    }
    const reqHeaders = { 'User-Agent': fallbackUas[idx], ...headers };
    return fetchHtml(targetUrl, reqHeaders, maxRedirects).then((res) => {
      if ((res.statusCode === 202 || res.statusCode === 403 || res.statusCode === 503) && idx + 1 < fallbackUas.length) {
        return tryUa(idx + 1);
      }
      return res;
    }).catch((err) => {
      if (idx + 1 < fallbackUas.length) return tryUa(idx + 1);
      throw err;
    });
  }

  return tryUa(0);
}

function findBrowserExecutable() {
  const candidates = [
    'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
    '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
    '/usr/bin/google-chrome',
    '/usr/bin/chromium-browser',
    '/usr/bin/chromium'
  ];
  for (const c of candidates) {
    if (fs.existsSync(c)) return c;
  }
  return null;
}

async function dumpHeadlessDom(targetUrl, timeoutMs = 25000) {
  const browser = findBrowserExecutable();
  if (!browser) return null;
  try {
    const { stdout } = await execFileAsync(browser, [
      '--headless',
      '--disable-gpu',
      '--no-sandbox',
      '--disable-dev-shm-usage',
      '--dump-dom',
      targetUrl
    ], { timeout: timeoutMs, windowsHide: true, maxBuffer: 10 * 1024 * 1024 });
    return stdout || '';
  } catch (err) {
    logger.warn('dumpHeadlessDom failed:', err.message);
    return null;
  }
}

async function probeMp4Duration(fileId, timeoutMs = 2500) {
  if (!fileId) return 0;
  return new Promise((resolve) => {
    let resolved = false;
    const finish = (val) => {
      if (!resolved) {
        resolved = true;
        resolve(val);
      }
    };
    const timer = setTimeout(() => finish(0), timeoutMs);

    function doRequest(targetUrl, redirectsLeft = 3) {
      if (redirectsLeft < 0) return finish(0);
      try {
        const parsed = new URL(targetUrl);
        const client = parsed.protocol === 'http:' ? http : https;
        const req = client.get(targetUrl, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
            'Range': 'bytes=0-262144'
          }
        }, (res) => {
          if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
            let next = res.headers.location;
            if (!next.startsWith('http')) {
              try { next = new URL(next, targetUrl).href; } catch { return finish(0); }
            }
            return doRequest(next, redirectsLeft - 1);
          }
          const chunks = [];
          res.on('data', (c) => chunks.push(c));
          res.on('end', () => {
            clearTimeout(timer);
            const buf = Buffer.concat(chunks);
            if (buf.length >= 32) {
              const mvhdIdx = buf.indexOf(Buffer.from('mvhd'));
              if (mvhdIdx !== -1 && mvhdIdx + 24 <= buf.length) {
                const version = buf[mvhdIdx + 4];
                if (version === 0) {
                  const timescale = buf.readUInt32BE(mvhdIdx + 16);
                  const duration = buf.readUInt32BE(mvhdIdx + 20);
                  if (timescale > 0 && duration > 0) {
                    return finish(Math.round(duration / timescale));
                  }
                } else if (version === 1 && mvhdIdx + 36 <= buf.length) {
                  const timescale = buf.readUInt32BE(mvhdIdx + 24);
                  const durHi = buf.readUInt32BE(mvhdIdx + 28);
                  const durLo = buf.readUInt32BE(mvhdIdx + 32);
                  const duration = durHi * 4294967296 + durLo;
                  if (timescale > 0 && duration > 0) {
                    return finish(Math.round(duration / timescale));
                  }
                }
              }
            }
            finish(0);
          });
          res.on('error', () => finish(0));
        });
        req.on('error', () => finish(0));
        req.setTimeout(timeoutMs, () => {
          try { req.destroy(); } catch (_) {}
          finish(0);
        });
      } catch (_) {
        finish(0);
      }
    }

    doRequest(`https://drive.usercontent.google.com/download?id=${fileId}&export=download`);
  });
}

export class MetadataAnalyzer {
  isValidUrl(urlStr) {
    try {
      const parsed = new URL(urlStr);
      return parsed.protocol === 'http:' || parsed.protocol === 'https:';
    } catch {
      return false;
    }
  }

  isPlaylistUrl(urlStr) {
    if (!this.isValidUrl(urlStr)) return false;
    const lower = urlStr.toLowerCase();
    const isAppleTrack = (lower.includes('music.apple.com') || lower.includes('itunes.apple.com')) && (lower.includes('?i=') || lower.includes('&i=') || lower.includes('?track=') || lower.includes('&track='));
    if (isAppleTrack) return false;
    return lower.includes('playlist?list=') || 
           lower.includes('&list=') || 
           lower.includes('?list=') || 
           lower.includes('/sets/') || 
           lower.includes('/album/') || 
           (lower.includes('spotify.') && (lower.includes('/playlist/') || lower.includes('/album/') || lower.includes('/artist/'))) ||
           lower.includes('drive.google.com/drive/folders/') ||
           lower.includes('drive.google.com/drive/u/') ||
           lower.includes('drive.google.com/folderview') ||
           (lower.includes('dropbox.com') && (lower.includes('/scl/fo/') || lower.includes('/sh/') || lower.includes('/folder/'))) ||
           lower.includes('1drv.ms') ||
           lower.includes('onedrive.live.com') ||
           lower.includes('sharepoint.com') ||
           lower.includes('box.com/s/') ||
           lower.includes('box.com/folder/') ||
           lower.includes('mega.nz/folder/') ||
           lower.includes('mega.nz/#f!') ||
           (lower.includes('pinterest.') && lower.includes('/boards/'));
  }

  isSpotifyPlaylistUrl(urlStr) {
    if (!this.isValidUrl(urlStr)) return false;
    return /spotify\.(?:com|link).*(?:\/playlist\/|\/album\/|\/artist\/)/i.test(urlStr);
  }

  async parseGoogleDriveFolderRecursive(folderId, folderPath = '', depth = 0, maxDepth = 8, visited = new Set()) {
    if (!folderId || depth > maxDepth || visited.has(folderId)) {
      return { title: folderPath, items: [], folders: [] };
    }
    visited.add(folderId);
    const folderUrl = `https://drive.google.com/drive/folders/${folderId}`;

    let html = '';
    try {
      const res = await fetchHtml(folderUrl, {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9'
      });
      html = res.body;
      if (res.statusCode === 404) {
        throw new Error('Google Drive folder not found (404). Please verify the link or ensure it is set to "Anyone with the link can view".');
      }
      if (res.statusCode === 403 || res.statusCode === 401) {
        throw new Error('Google Drive access denied (403). Set folder sharing to "Anyone with the link can view".');
      }
    } catch (e) {
      if (depth === 0) {
        throw e;
      }
      logger.warn(`Failed to fetch Drive folder ${folderId}:`, e);
      return { title: folderPath, items: [], folders: [] };
    }

    let folderTitle = folderPath;
    if (!folderTitle) {
      const tMatch = html.match(/<title>([^<]+?)(?:\s*–\s*Google\s*Drive)?<\/title>/i);
      if (tMatch) folderTitle = tMatch[1].trim();
    }
    if (!folderTitle) folderTitle = 'Google Drive Folder';

    const ivdMatch = html.match(/window\['_DRIVE_ivd'\]\s*=\s*'([^']+)'/);
    if (!ivdMatch) {
      if (depth === 0) {
        if (html.includes('404') || html.includes('Not Found') || html.includes('Error 404')) {
          throw new Error('Google Drive folder not found (404). Please verify the link is valid and public.');
        }
        if (html.includes('accounts.google.com/ServiceLogin') || html.includes('Sign in - Google Accounts')) {
          throw new Error('Google Drive folder requires sign-in. Change sharing to "Anyone with the link can view".');
        }
      }
      return { title: folderTitle, items: [], folders: [] };
    }

    let rawItems = [];
    try {
      const rawStr = ivdMatch[1];
      const unescaped = rawStr.replace(/\\x([0-9A-Fa-f]{2})/g, (_, hex) => String.fromCharCode(parseInt(hex, 16)));
      const parsed = JSON.parse(unescaped);
      rawItems = parsed[0] || [];
    } catch (e) {
      logger.warn(`Failed to parse _DRIVE_ivd for folder ${folderId}:`, e);
      return { title: folderTitle, items: [], folders: [] };
    }

    const directFiles = [];
    const subFolderDefs = [];

    for (let idx = 0; idx < rawItems.length; idx++) {
      const item = rawItems[idx];
      const itemId = item[0];
      if (!itemId) continue;
      const itemName = item[2] || `File_${idx + 1}`;
      const mime = item[3] || 'video/mp4';

      if (mime === 'application/vnd.google-apps.folder') {
        subFolderDefs.push({ id: itemId, name: itemName });
      } else {
        const isVideo = mime.startsWith('video') || /\.(mp4|mov|mkv|webm|avi|flv|m4v)$/i.test(itemName);
        const isAudio = mime.startsWith('audio') || /\.(mp3|wav|m4a|aac|flac|ogg)$/i.test(itemName);
        const isImage = mime.startsWith('image') || /\.(jpg|jpeg|png|webp|gif|bmp)$/i.test(itemName);
        const directUrl = `https://drive.google.com/uc?export=download&id=${itemId}`;
        const thumbUrl = `https://drive.google.com/thumbnail?id=${itemId}&sz=w800`;

        const hMatch = itemName.match(/(\d{3,4})p/i);
        let detectedH = 0;
        if (hMatch) {
          detectedH = parseInt(hMatch[1], 10);
        } else if (/\b4k\b/i.test(itemName) || /\b2160\b/.test(itemName)) {
          detectedH = 2160;
        } else if (/\b1440\b/.test(itemName) || /\b2k\b/i.test(itemName)) {
          detectedH = 1440;
        } else if (/\b1080\b/.test(itemName)) {
          detectedH = 1080;
        } else if (/\b720\b/.test(itemName)) {
          detectedH = 720;
        } else if (/\b480\b/.test(itemName)) {
          detectedH = 480;
        }

        directFiles.push({
          id: itemId,
          title: itemName,
          author: 'Google Drive',
          duration: 0,
          thumbnail: thumbUrl,
          url: directUrl,
          directUrl: directUrl,
          mediaType: isVideo ? 'video' : (isAudio ? 'audio' : (isImage ? 'image' : 'video')),
          height: detectedH,
          resolution: detectedH ? `${detectedH}p` : undefined,
          subFolderId: folderId,
          subFolderName: folderPath || folderTitle
        });
      }
    }

    // Duration is left at 0 for instant, lightweight cloud parsing without CPU spikes or network lag

    // Recurse into subfolders up to maxDepth 8 in parallel
    const childResults = await Promise.all(subFolderDefs.map(async (sub) => {
      const nextPath = folderPath ? `${folderPath} / ${sub.name}` : sub.name;
      const subRes = await this.parseGoogleDriveFolderRecursive(sub.id, nextPath, depth + 1, maxDepth, visited);
      if (subRes.items.length > 0 || subRes.folders.length > 0) {
        return {
          id: sub.id,
          name: nextPath,
          items: subRes.items,
          folders: subRes.folders
        };
      }
      return null;
    }));
    const childFolders = childResults.filter(Boolean);

    return {
      title: folderTitle,
      items: directFiles,
      folders: childFolders
    };
  }

  async analyzePlaylist(url, timeoutMs = 35000) {
    // 0. Google Drive Shared Folder Scraper (Footages & Multi-Files & Subfolders)
    if (url.includes('drive.google.com') && (url.includes('/folders/') || url.includes('folderview') || url.includes('/drive/u/'))) {
      logger.info(`Analyzing Google Drive shared folder: ${url}`);
      try {
        const fMatch = url.match(/folders\/([a-zA-Z0-9_-]+)/);
        const idMatch = url.match(/[?&]id=([a-zA-Z0-9_-]+)/);
        const folderId = fMatch ? fMatch[1] : (idMatch ? idMatch[1] : '');

        const tree = await this.parseGoogleDriveFolderRecursive(folderId, '', 0, 8);

        const allFlatItems = [];
        const folderGroups = [];

        // Direct files in root folder (if any)
        if (tree.items.length > 0) {
          folderGroups.push({
            id: folderId,
            name: tree.title || 'Main Folder',
            items: tree.items
          });
          allFlatItems.push(...tree.items);
        }

        // Subfolders recursive collection
        function collectSubfolders(subGroupList) {
          for (const grp of subGroupList) {
            if (grp.items && grp.items.length > 0) {
              folderGroups.push({
                id: grp.id,
                name: grp.name,
                items: grp.items
              });
              allFlatItems.push(...grp.items);
            }
            if (grp.folders && grp.folders.length > 0) {
              collectSubfolders(grp.folders);
            }
          }
        }
        collectSubfolders(tree.folders);

        if (allFlatItems.length > 0) {
          // Assign 1-based sequential indices
          allFlatItems.forEach((it, idx) => {
            it.index = idx + 1;
          });

          return {
            id: folderId || 'drive_folder',
            title: tree.title || 'Google Drive Folder',
            uploader: 'Google Drive',
            thumbnail: allFlatItems[0]?.thumbnail || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800',
            url,
            itemCount: allFlatItems.length,
            items: allFlatItems,
            folders: folderGroups.length > 0 ? folderGroups : [{
              id: folderId || 'root',
              name: tree.title || 'Files',
              items: allFlatItems
            }]
          };
        }
        throw new Error('No media files found in this Google Drive folder.');
      } catch (err) {
        logger.error('Failed to parse Google Drive folder:', err);
        throw err;
      }
    }

    // 1. Spotify Playlist / Album / Artist Scraper
    if (this.isSpotifyPlaylistUrl(url)) {
      logger.info(`Analyzing Spotify playlist/album/artist: ${url}`);
      try {
        const idMatch = url.match(/(playlist|album|artist)\/([a-zA-Z0-9]+)/);
        const type = idMatch ? idMatch[1] : 'playlist';
        const id = idMatch ? idMatch[2] : '';
        if (id) {
          const embedUrl = `https://open.spotify.com/embed/${type}/${id}`;
          const { body: html } = await fetchHtml(embedUrl);
          const nextDataMatch = html.match(/<script id="__NEXT_DATA__" type="application\/json">([\s\S]+?)<\/script>/);
          if (nextDataMatch) {
            const nextData = JSON.parse(nextDataMatch[1]);
            const entity = nextData.props?.pageProps?.state?.data?.entity;
            if (entity) {
              const isArtist = entity.type === 'artist' || type === 'artist';
              const playlistTitle = isArtist 
                ? `${entity.name || 'Artist'} - Top Tracks` 
                : (entity.name || entity.title || 'Spotify Playlist');
              const coverImg = entity.coverArt?.sources?.[0]?.url || 
                entity.visualIdentity?.image?.[1]?.url || 
                entity.visualIdentity?.image?.[0]?.url || 
                'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800';
              const rawTracks = entity.trackList || [];
              const defaultArtist = entity.name || entity.subtitle || 'Artist';
              const items = rawTracks.map((t, idx) => {
                const trackTitle = t.title || `Track ${idx + 1}`;
                const trackArtist = t.subtitle || defaultArtist;
                const durSec = t.duration ? Math.round(t.duration / 1000) : 180;
                const trackUri = t.uri ? t.uri.replace('spotify:track:', 'https://open.spotify.com/track/') : url;
                const fullTitle = trackArtist ? `${trackTitle} - ${trackArtist}`.trim() : trackTitle;
                const searchQuery = `ytsearch1:${trackTitle} ${trackArtist} audio`.trim();
                return {
                  id: t.id || t.uid || `spotify_${idx}`,
                  url: trackUri,
                  title: fullTitle,
                  duration: durSec,
                  thumbnail: coverImg,
                  channel: trackArtist,
                  uploader: trackArtist,
                  downloadQuery: searchQuery,
                  index: idx + 1
                };
              });
              return {
                id: id,
                url,
                title: playlistTitle,
                uploader: isArtist ? entity.name : (entity.subtitle || 'Spotify'),
                itemCount: items.length,
                items,
                thumbnail: coverImg
              };
            }
          }
        }
      } catch (spErr) {
        logger.warn('Spotify playlist embed scraper notice:', spErr);
      }
    }

    // 1B. Apple Music Album / Playlist Scraper
    if (this.isAppleMusicAlbumUrl(url)) {
      logger.info(`Analyzing Apple Music album/playlist: ${url}`);
      try {
        const idMatch = url.match(/(?:album|playlist)\/[^/]+\/(\d+)/i) || url.match(/\/(\d+)(?:\?|$)/);
        const colId = idMatch ? idMatch[1] : '';
        if (colId) {
          const itunesApi = `https://itunes.apple.com/lookup?id=${colId}&entity=song`;
          const { body: itunesBody } = await fetchHtml(itunesApi);
          const data = JSON.parse(itunesBody);
          if (data && data.results && data.results.length > 0) {
            const col = data.results[0];
            const playlistTitle = col.collectionName || 'Apple Music Album';
            const defaultArtist = col.artistName || 'Artist';
            const coverImg = (col.artworkUrl100 || '').replace('100x100bb', '600x600bb') || 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800';
            const rawTracks = data.results.slice(1).filter(r => r.wrapperType === 'track');
            const items = rawTracks.map((t, idx) => {
              const trackTitle = t.trackName || `Track ${idx + 1}`;
              const trackArtist = t.artistName || defaultArtist;
              const durSec = t.trackTimeMillis ? Math.round(t.trackTimeMillis / 1000) : 180;
              const trackUri = t.trackViewUrl || url;
              const fullTitle = trackArtist ? `${trackTitle} - ${trackArtist}`.trim() : trackTitle;
              const searchQuery = `ytsearch1:${trackTitle} ${trackArtist} audio`.trim();
              return {
                id: t.trackId ? String(t.trackId) : `apple_${idx}`,
                url: trackUri,
                title: fullTitle,
                duration: durSec,
                thumbnail: (t.artworkUrl100 || coverImg).replace('100x100bb', '600x600bb'),
                channel: trackArtist,
                uploader: trackArtist,
                downloadQuery: searchQuery,
                index: idx + 1,
                directStreamUrl: t.previewUrl || '',
                audioPreviewUrl: t.previewUrl || '',
                platform: 'apple_music',
                isAppleMusic: true,
                type: 'audio'
              };
            });
            return {
              id: colId,
              url,
              title: playlistTitle,
              uploader: defaultArtist,
              itemCount: items.length,
              items,
              thumbnail: coverImg
            };
          }
        }
      } catch (appleErr) {
        logger.warn('Apple Music playlist scraper notice:', appleErr);
      }
    }

    // 2. Standard YouTube / Generic Playlist via yt-dlp
    logger.info(`Analyzing playlist with yt-dlp: ${url}`);
    const ytdlpPath = await dependencyManager.getYtDlpExecutablePath();
    const ytArgs = await youtubeTokenManager.getYtDlpExtractorArgs(url);
    const args = [
      '--flat-playlist',
      '--playlist-items', '1:50',
      '--dump-single-json',
      '--no-check-certificates',
      '--prefer-free-formats',
      ...ytArgs,
      '--add-header', 'User-Agent:Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
      url
    ];

    try {
      const { stdout } = await execFileAsync(ytdlpPath, args, {
        windowsHide: true,
        timeout: timeoutMs,
        maxBuffer: 50 * 1024 * 1024
      });
      const raw = JSON.parse(stdout);
      const items = (raw.entries || []).map((entry, index) => {
        let entryUrl = entry.url || entry.webpage_url || '';
        if (entry.id && (!entryUrl || !entryUrl.startsWith('http'))) {
          entryUrl = `https://www.youtube.com/watch?v=${entry.id}`;
        }
        if (!entryUrl) entryUrl = url;
        const entryTitle = entry.title || `Track ${index + 1}`;

        const hMatch = entryTitle.match(/(\d{3,4})p/i);
        let detectedH = entry.height || 0;
        if (!detectedH && hMatch) {
          detectedH = parseInt(hMatch[1], 10);
        } else if (!detectedH) {
          if (/\b4k\b/i.test(entryTitle) || /\b2160\b/.test(entryTitle)) detectedH = 2160;
          else if (/\b1440\b/.test(entryTitle) || /\b2k\b/i.test(entryTitle)) detectedH = 1440;
          else if (/\b1080\b/.test(entryTitle)) detectedH = 1080;
          else if (/\b720\b/.test(entryTitle)) detectedH = 720;
          else if (/\b480\b/.test(entryTitle)) detectedH = 480;
        }

        return {
          id: entry.id || `item_${index}`,
          url: entryUrl,
          downloadQuery: entryUrl,
          title: entryTitle,
          duration: entry.duration || 0,
          thumbnail: entry.thumbnail || entry.thumbnails?.[0]?.url,
          channel: entry.uploader || entry.channel || '',
          uploader: entry.uploader || entry.channel || '',
          index: index + 1,
          height: detectedH,
          resolution: detectedH ? `${detectedH}p` : undefined
        };
      });

      // Sample first item to detect true resolution if no items had detectable heights
      if (items.length > 0 && items[0].url && !items.some((it) => it.height > 0)) {
        try {
          const sampleArgs = [
            '--dump-single-json',
            '--skip-download',
            '--no-warnings',
            '--no-playlist',
            ...ytArgs,
            items[0].url
          ];
          const sampleProc = await execFileAsync(ytdlpPath, sampleArgs, { windowsHide: true, timeout: 6000 });
          const sampleRaw = JSON.parse(sampleProc.stdout);
          const sampleHeights = (sampleRaw.formats || []).map((f) => f.height).filter((h) => typeof h === 'number' && h > 0);
          if (sampleHeights.length > 0) {
            const maxH = Math.max(...sampleHeights);
            items[0].height = maxH;
            items[0].resolution = `${maxH}p`;
          }
        } catch (_) {}
      }

      const rawTitle = (raw.title || raw.playlist_title || raw.playlist || raw.name || '').trim();
      const firstUploader = items[0]?.uploader || items[0]?.channel || raw.uploader || raw.channel || '';
      let finalTitle = rawTitle;
      if (!finalTitle || finalTitle === 'NA' || finalTitle === '[NA]' || finalTitle.toLowerCase() === 'playlist') {
        finalTitle = firstUploader ? `${firstUploader} - Playlist` : (raw.id ? `Playlist_${raw.id}` : 'Media Playlist');
      }

      return {
        id: raw.id || 'playlist',
        url,
        title: finalTitle,
        uploader: raw.uploader || raw.channel || firstUploader || 'YouTube',
        itemCount: items.length,
        items,
        thumbnail: raw.thumbnails?.[0]?.url || (items[0]?.thumbnail || '')
      };
    } catch (err) {
      logger.error('Playlist analysis failed:', err);
      // Fallback: If playlist extraction fails/times out, but the URL has an individual video ID (e.g. ?v=... or /watch?v=... or shorts/...),
      // try single video analysis and wrap it as a 1-item playlist so the user is never blocked!
      const vMatch = url.match(/(?:v=|\/watch\/|\/embed\/|youtu\.be\/|shorts\/)([a-zA-Z0-9_-]{11})/);
      if (vMatch && vMatch[1]) {
        try {
          logger.info(`Playlist analysis failed, attempting fallback to single video for ID ${vMatch[1]}`);
          const singleUrl = `https://www.youtube.com/watch?v=${vMatch[1]}`;
          const singleMeta = await this.analyzeUrl(singleUrl, 15000);
          if (singleMeta) {
            return {
              id: vMatch[1],
              url,
              title: singleMeta.title || 'YouTube Media',
              uploader: singleMeta.uploader || 'YouTube',
              itemCount: 1,
              items: [{
                id: singleMeta.id || vMatch[1],
                url: singleUrl,
                title: singleMeta.title || 'YouTube Media',
                duration: singleMeta.duration || 0,
                thumbnail: singleMeta.thumbnail || '',
                channel: singleMeta.uploader || '',
                uploader: singleMeta.uploader || '',
                index: 1,
                height: singleMeta.height || 0,
                resolution: singleMeta.resolution || (singleMeta.height ? `${singleMeta.height}p` : undefined)
              }],
              thumbnail: singleMeta.thumbnail || ''
            };
          }
        } catch (singleErr) {
          logger.warn('Single video fallback after playlist failure failed:', singleErr);
        }
      }
      throw classifyError(err, 'Failed to analyze playlist');
    }
  }

  isThreadsUrl(urlStr) {
    if (!this.isValidUrl(urlStr)) return false;
    return /threads\.(?:net|com)/i.test(urlStr);
  }

  isSpotifyUrl(urlStr) {
    if (!this.isValidUrl(urlStr)) return false;
    return /spotify\.(?:com|link)/i.test(urlStr);
  }

  isAppleMusicUrl(urlStr) {
    if (!this.isValidUrl(urlStr)) return false;
    return /music\.apple\.com|itunes\.apple\.com/i.test(urlStr);
  }

  isAppleMusicAlbumUrl(urlStr) {
    if (!this.isValidUrl(urlStr)) return false;
    // An album/playlist link on apple music without an individual song selection (?i= or ?track=)
    const isApple = /music\.apple\.com|itunes\.apple\.com/i.test(urlStr);
    if (!isApple) return false;
    const isSingleTrack = /[?&](?:i|track)=(\d+)/i.test(urlStr);
    return !isSingleTrack && /(?:\/album\/|\/playlist\/)/i.test(urlStr);
  }

  isBehanceUrl(urlStr) {
    if (!this.isValidUrl(urlStr)) return false;
    return /behance\.(?:net|com)/i.test(urlStr);
  }

  isDribbbleUrl(urlStr) {
    if (!this.isValidUrl(urlStr)) return false;
    return /dribbble\.com/i.test(urlStr);
  }

  isArtStationUrl(urlStr) {
    if (!this.isValidUrl(urlStr)) return false;
    return /artstation\.com/i.test(urlStr);
  }

  isFiverrUrl(urlStr) {
    if (!this.isValidUrl(urlStr)) return false;
    return /fiverr\.com/i.test(urlStr);
  }

  isPinterestUrl(urlStr) {
    if (!this.isValidUrl(urlStr)) return false;
    const lower = urlStr.toLowerCase();
    return lower.includes('pinterest.com') || lower.includes('pin.it');
  }

  async expandPinterestUrl(urlStr) {
    if (!urlStr || !urlStr.includes('pin.it')) return urlStr;
    try {
      const res = await fetchHtml(urlStr);
      if (res.finalUrl && !res.finalUrl.includes('pin.it')) {
        return res.finalUrl;
      }
    } catch (e) {
      logger.warn('[Analyzer] Failed to expand pin.it with fetchHtml:', e.message);
    }
    return urlStr;
  }

  async analyzeThreads(url, timeoutMs = 20000) {
    logger.info(`Analyzing Threads post: ${url}`);
    try {
      const { body: html, finalUrl } = await fetchHtml(url, {
        'User-Agent': 'facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)'
      });

      let ogVideo = html.match(/<meta[^>]+property=["']og:video(?::secure_url)?["'][^>]+content=["']([^"']+)["']/i)?.[1]?.replace(/&amp;/g, '&');
      const ogTitle = html.match(/<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']/i)?.[1];
      const ogDesc = html.match(/<meta[^>]+property=["']og:description["'][^>]+content=["']([^"']+)["']/i)?.[1];
      const ogImage = html.match(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i)?.[1]?.replace(/&amp;/g, '&');

      let videoUrl = ogVideo || '';
      if (!videoUrl) {
        const clean = html.replace(/\\u0025/g, '%').replace(/\\u0026/g, '&').replace(/\\\//g, '/').replace(/&amp;/g, '&');
        const vids = clean.match(/https:\/\/[a-zA-Z0-9.\-_]+(?:fbcdn\.net|cdninstagram\.com)[^"\'><\s\\]+?\.mp4[^"\'><\s\\]*/g) || [];
        const valid = vids.filter(v => !v.includes('rsrc.php') && v.includes('oh=') && v.includes('oe='));
        if (valid.length > 0) {
          videoUrl = valid[0];
        } else if (vids.length > 0) {
          videoUrl = vids.find(v => !v.includes('rsrc.php')) || '';
        }
      }

      let author = 'Threads Creator';
      let title = 'Threads Post';
      let thumbnail = ogImage || 'https://images.unsplash.com/photo-1611605698335-8b1569810432?w=800';

      const urlAuthorMatch = (finalUrl || url).match(/@([a-zA-Z0-9._]+)/);
      if (urlAuthorMatch) {
        author = '@' + urlAuthorMatch[1];
      } else if (ogTitle) {
        const aMatch = ogTitle.match(/@([a-zA-Z0-9._]+)/);
        if (aMatch) author = '@' + aMatch[1];
      }

      if (ogDesc) {
        let cleanDesc = ogDesc
          .replace(/&amp;/g, '&')
          .replace(/&#x[0-9a-fA-F]+;/g, ' ')
          .replace(/&#[0-9]+;/g, ' ')
          .replace(/&quot;/g, '"')
          .replace(/https?:\/\/\S+/g, '')
          .trim();
        const firstLine = cleanDesc.split(/[\r\n]+/)[0]?.trim();
        if (firstLine && firstLine.length >= 3) {
          title = firstLine.length > 120 ? firstLine.substring(0, 117) + '...' : firstLine;
        } else if (cleanDesc.length >= 3) {
          title = cleanDesc.length > 120 ? cleanDesc.substring(0, 117) + '...' : cleanDesc;
        }
      }

      const isGenericThreadsTitle = !title || 
        title === 'Threads Post' ||
        title.toLowerCase().includes('log in') || 
        title.toLowerCase().includes('login') || 
        title.toLowerCase().includes('join threads') || 
        title.toLowerCase().includes('sign up');

      if (isGenericThreadsTitle) {
        title = (author && author !== 'Threads Creator') ? `Threads Video (${author})` : 'Threads Video';
      }

      const scMatch = (finalUrl || url).match(/post\/([a-zA-Z0-9_-]+)/) || url.match(/share\/([a-zA-Z0-9_-]+)/);
      const shortcode = scMatch ? scMatch[1] : '';

      const hasVideo = !!videoUrl;
      const formats = [];
      if (hasVideo) {
        formats.push({
          formatId: 'threads-best',
          ext: 'mp4',
          resolution: '1080x1920',
          height: 1080,
          width: 1920,
          vcodec: 'h264',
          acodec: 'aac',
          isAudioOnly: false,
          isVideoOnly: false,
          hasAudioAndVideo: true,
          qualityLabel: '1080p Full HD',
          url: videoUrl
        });
        formats.push({
          formatId: 'threads-720p',
          ext: 'mp4',
          resolution: '720x1280',
          height: 720,
          width: 1280,
          vcodec: 'h264',
          acodec: 'aac',
          isAudioOnly: false,
          isVideoOnly: false,
          hasAudioAndVideo: true,
          qualityLabel: '720p HD',
          url: videoUrl
        });
        formats.push({
          formatId: 'threads-audio',
          ext: 'mp3',
          isAudioOnly: true,
          isVideoOnly: false,
          hasAudioAndVideo: false,
          qualityLabel: 'Audio (MP3 320kbps)',
          url: videoUrl
        });
      } else if (ogImage) {
        formats.push({
          formatId: 'threads-image',
          ext: 'jpg',
          resolution: 'Original Photo',
          isAudioOnly: false,
          isVideoOnly: false,
          hasAudioAndVideo: false,
          qualityLabel: 'Original Photo (JPG)',
          url: ogImage
        });
      }

      return {
        id: shortcode || ('threads_' + Date.now()),
        url,
        directStreamUrl: videoUrl || ogImage,
        title,
        thumbnail,
        duration: hasVideo ? 30 : 0,
        uploader: author,
        channel: author,
        description: ogDesc,
        extractor: 'Threads',
        formats,
        availableResolutions: hasVideo ? [1080, 720] : [],
        hasAudio: hasVideo,
        hasVideo,
        hasImage: !hasVideo && !!ogImage,
        defaultProfile: {
          type: hasVideo ? 'video' : 'image',
          presetId: hasVideo ? 'best-available' : 'original-image',
          label: hasVideo ? 'Best Available Quality (Universal H.264)' : 'Original Photo (JPG)',
          container: hasVideo ? 'mp4' : 'jpg',
          remuxToMp4: hasVideo
        }
      };
    } catch (err) {
      logger.error('Threads analysis failed:', err);
      throw classifyError(err, 'Failed to analyze Threads media');
    }
  }

  async analyzeSpotify(url, timeoutMs = 35000) {
    if (this.isSpotifyPlaylistUrl(url)) {
      return await this.analyzePlaylist(url, timeoutMs);
    }
    logger.info(`Analyzing Spotify track: ${url}`);
    try {
      let trackTitle = '';
      let artist = '';
      let thumbnail = '';
      let durationSec = 0;
      const trackIdMatch = url.match(/track\/([a-zA-Z0-9]+)/);
      const trackId = trackIdMatch ? trackIdMatch[1] : '';

      // 1. Fetch Spotify SSR with bot crawler User-Agent (instant & reliable)
      try {
        const { body: ssrHtml, statusCode: ssrStatus } = await fetchHtml(url, {
          'User-Agent': 'facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)'
        });
        if (ssrStatus === 200) {
          const ogTitleMatch = ssrHtml.match(/<meta property=["']og:title["'] content=["']([^"']+)["']/i);
          const ogDescMatch = ssrHtml.match(/<meta property=["']og:description["'] content=["']([^"']+)["']/i);
          const ogImageMatch = ssrHtml.match(/<meta property=["']og:image["'] content=["']([^"']+)["']/i);
          const durationMatch = ssrHtml.match(/<meta property=["']music:duration["'] content=["']([^"']+)["']/i);

          if (ogTitleMatch && ogTitleMatch[1] && !ogTitleMatch[1].startsWith('Spotify')) {
            trackTitle = ogTitleMatch[1];
          }
          if (ogDescMatch && ogDescMatch[1]) {
            const parts = ogDescMatch[1].split('·').map(s => s.trim());
            if (parts.length > 0 && parts[0]) artist = parts[0];
          }
          if (ogImageMatch && ogImageMatch[1]) {
            thumbnail = ogImageMatch[1];
          }
          if (durationMatch && durationMatch[1]) {
            durationSec = parseInt(durationMatch[1], 10);
          }
        }
      } catch (ssrErr) {
        logger.warn('Spotify SSR scraper notice:', ssrErr);
      }

      // 2. Fetch Spotify Embed for artist and exact duration
      if (trackId) {
        try {
          const embedUrl = `https://open.spotify.com/embed/track/${trackId}`;
          const { body: embedHtml } = await fetchHtml(embedUrl);
          const nextDataMatch = embedHtml.match(/<script id="__NEXT_DATA__" type="application\/json">([\s\S]+?)<\/script>/);
          if (nextDataMatch) {
            const nextData = JSON.parse(nextDataMatch[1]);
            const entity = nextData.props?.pageProps?.state?.data?.entity;
            if (entity) {
              if (entity.name && (!trackTitle || trackTitle === 'Spotify Track')) {
                trackTitle = entity.name;
              }
              if (entity.artists && Array.isArray(entity.artists) && entity.artists.length > 0) {
                artist = entity.artists.map((a) => a.name).filter(Boolean).join(', ');
              }
              if (entity.duration) {
                durationSec = Math.round(entity.duration / 1000);
              }
              const coverImg = entity.visualIdentity?.image?.[1]?.url ||
                               entity.visualIdentity?.image?.[0]?.url ||
                               entity.coverArt?.sources?.[0]?.url;
              if (coverImg && (!thumbnail || thumbnail.includes('unsplash'))) {
                thumbnail = coverImg;
              }
            }
          }
        } catch (embErr) {
          logger.warn('Spotify embed parse notice:', embErr);
        }
      }

      // 3. Fallback to Spotify oEmbed
      if (!trackTitle) {
        try {
          const oembedUrl = `https://open.spotify.com/oembed?url=${encodeURIComponent(url)}`;
          const { body: oembedJson } = await fetchHtml(oembedUrl);
          const oembed = JSON.parse(oembedJson);
          if (oembed.title) trackTitle = oembed.title;
          if (oembed.thumbnail_url && !thumbnail) thumbnail = oembed.thumbnail_url;
        } catch (oeErr) {
          logger.warn('Spotify oembed notice:', oeErr);
        }
      }

      if (!trackTitle || trackTitle === 'Spotify Track') {
        throw new Error('This Spotify track could not be found, is region-locked, or has been removed from Spotify.');
      }
      if (!artist) artist = 'Spotify';
      if (!thumbnail) thumbnail = 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800';
      if (!durationSec) durationSec = 180;

      // 4. Search and pair YouTube high-fidelity audio stream
      const query = `ytsearch1:${trackTitle} ${artist} audio`.trim();
      logger.info(`Pairing Spotify track with YouTube stream query: ${query}`);
      const ytdlpPath = await dependencyManager.getYtDlpExecutablePath();
      const ytArgs = await youtubeTokenManager.getYtDlpExtractorArgs(url);
      const args = [
        '--dump-single-json',
        '--no-playlist',
        '--no-check-certificates',
        '--prefer-free-formats',
        ...ytArgs,
        '--add-header', 'User-Agent:Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        query
      ];

      let meta;
      try {
        const { stdout } = await execFileAsync(ytdlpPath, args, {
          windowsHide: true,
          timeout: Math.min(timeoutMs, 15000),
          maxBuffer: 30 * 1024 * 1024
        });
        const raw = JSON.parse(stdout);
        const entry = (raw.entries && raw.entries.length > 0) ? raw.entries[0] : raw;
        meta = this.parseYtDlpOutput(url, entry);
      } catch (ytSearchErr) {
        logger.warn('YouTube pairing search notice during Spotify analysis:', ytSearchErr.message);
        meta = {
          id: trackId || 'spotify_track',
          url,
          title: trackTitle,
          formats: [{
            format_id: 'audio_mp3_320',
            ext: 'mp3',
            resolution: 'audio only',
            note: 'MP3 320kbps High Quality Audio'
          }],
          duration: durationSec || 180,
          thumbnail
        };
      }

      meta.id = trackId || (meta.id || 'spotify_track');
      meta.url = url;
      meta.title = trackTitle;
      meta.thumbnail = thumbnail;
      meta.uploader = artist;
      meta.channel = artist;
      meta.extractor = 'Spotify';
      meta.platform = 'spotify';
      meta.isSpotify = true;
      meta.duration = durationSec > 0 ? durationSec : meta.duration;
      meta.downloadQuery = query;
      meta.downloadTarget = meta.webpage_url || query;
      delete meta.directStreamUrl;
      meta.defaultProfile = {
        type: 'audio',
        presetId: 'best-audio',
        label: 'Best Audio Quality (MP3 320kbps)',
        container: 'mp3'
      };

      return meta;
    } catch (err) {
      logger.error('Spotify analysis failed:', err);
      throw classifyError(err, 'Failed to analyze Spotify song');
    }
  }

  async analyzeAppleMusic(url, timeoutMs = 35000) {
    if (this.isAppleMusicAlbumUrl(url)) {
      return await this.analyzePlaylist(url, timeoutMs);
    }
    logger.info(`Analyzing Apple Music song: ${url}`);
    try {
      let trackTitle = '';
      let artist = '';
      let thumbnail = '';
      let durationSec = 180;
      let trackId = '';
      let previewUrl = '';

      // Check ?i=1537031094 or /album/.../1537030727?i=...
      const iMatch = url.match(/[?&](?:i|track)=(\d+)/i);
      if (iMatch) {
        trackId = iMatch[1];
      } else {
        const idMatch = url.match(/\/(\d+)(?:\?|$)/);
        if (idMatch) trackId = idMatch[1];
      }

      if (trackId) {
        try {
          const itunesApi = `https://itunes.apple.com/lookup?id=${trackId}`;
          const { body: itunesBody } = await fetchHtml(itunesApi);
          const data = JSON.parse(itunesBody);
          if (data && data.results && data.results.length > 0) {
            const item = data.results[0];
            trackTitle = item.trackName || item.collectionName || '';
            artist = item.artistName || '';
            thumbnail = (item.artworkUrl100 || '').replace('100x100bb', '600x600bb');
            if (item.trackTimeMillis) {
              durationSec = Math.round(item.trackTimeMillis / 1000);
            }
            if (item.previewUrl) {
              previewUrl = item.previewUrl;
            }
          }
        } catch (itErr) {
          logger.warn('iTunes lookup error for Apple Music:', itErr);
        }
      }

      // Fallback via OpenGraph tags on Apple Music URL
      if (!trackTitle) {
        try {
          const { body: html } = await fetchHtml(url, {
            'User-Agent': 'facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)'
          });
          const ogTitle = html.match(/<meta property=["']og:title["'] content=["']([^"']+)["']/i)?.[1];
          const ogDesc = html.match(/<meta property=["']og:description["'] content=["']([^"']+)["']/i)?.[1];
          const ogImg = html.match(/<meta property=["']og:image["'] content=["']([^"']+)["']/i)?.[1];
          if (ogTitle) trackTitle = ogTitle;
          if (ogDesc && !artist) {
            const parts = ogDesc.split('·').map(s => s.trim());
            if (parts.length > 0) artist = parts[0];
          }
          if (ogImg && !thumbnail) thumbnail = ogImg;
        } catch (ogErr) {
          logger.warn('Apple Music OG tag fallback notice:', ogErr);
        }
      }

      if (!trackTitle) {
        throw new Error('This Apple Music song could not be found or previewed.');
      }
      if (!artist) artist = 'Apple Music';
      if (!thumbnail) thumbnail = 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800';

      const query = `ytsearch1:${trackTitle} ${artist} audio`.trim();
      logger.info(`Pairing Apple Music track with YouTube audio query: ${query}`);

      const ytdlpPath = await dependencyManager.getYtDlpExecutablePath();
      const ytArgs = await youtubeTokenManager.getYtDlpExtractorArgs(url);
      const args = [
        '--dump-single-json',
        '--no-playlist',
        '--no-check-certificates',
        '--prefer-free-formats',
        ...ytArgs,
        '--add-header', 'User-Agent:Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        query
      ];

      let meta;
      try {
        const { stdout } = await execFileAsync(ytdlpPath, args, {
          windowsHide: true,
          timeout: Math.min(timeoutMs, 15000),
          maxBuffer: 30 * 1024 * 1024
        });
        const raw = JSON.parse(stdout);
        const entry = (raw.entries && raw.entries.length > 0) ? raw.entries[0] : raw;
        meta = this.parseYtDlpOutput(url, entry);
      } catch (ytSearchErr) {
        logger.warn('YouTube pairing notice during Apple Music analysis:', ytSearchErr.message);
        meta = {
          id: trackId || 'apple_music_track',
          url,
          title: trackTitle,
          formats: [{
            format_id: 'audio_mp3_320',
            ext: 'mp3',
            resolution: 'audio only',
            note: 'MP3 320kbps High Quality Audio'
          }],
          duration: durationSec || 180,
          thumbnail
        };
      }

      meta.id = trackId || (meta.id || 'apple_music_track');
      meta.url = url;
      meta.title = trackTitle;
      meta.thumbnail = thumbnail;
      meta.uploader = artist;
      meta.channel = artist;
      meta.extractor = 'AppleMusic';
      meta.platform = 'apple_music';
      meta.isAppleMusic = true;
      meta.mediaType = 'audio';
      meta.duration = durationSec > 0 ? durationSec : meta.duration;
      meta.downloadQuery = query;
      meta.downloadTarget = meta.webpage_url || query;
      if (previewUrl) {
        meta.directStreamUrl = previewUrl;
        meta.audioPreviewUrl = previewUrl;
        meta.previewUrl = previewUrl;
      }
      meta.defaultProfile = {
        type: 'audio',
        presetId: 'best-audio',
        label: 'Best Audio Quality (MP3 320kbps)',
        container: 'mp3'
      };

      return meta;
    } catch (err) {
      logger.error('Apple Music analysis failed:', err);
      throw classifyError(err, 'Failed to analyze Apple Music song');
    }
  }

  async fetchBehanceHtml(url) {
    const fetchWithHeader = (ua, cookie = '') => {
      return new Promise((resolve) => {
        const u = new URL(url);
        const req = https.request({
          hostname: u.hostname,
          path: u.pathname + u.search,
          method: 'GET',
          headers: {
            'User-Agent': ua,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.9',
            ...(cookie ? { 'Cookie': cookie } : {})
          }
        }, (res) => {
          let b = '';
          res.on('data', (c) => b += c);
          res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: b }));
        });
        req.on('error', () => resolve({ status: 500, body: '' }));
        req.end();
      });
    };

    // Stage 1: Discordbot challenge bypass
    const botUa = 'Mozilla/5.0 (compatible; Discordbot/2.0; +https://discordapp.com)';
    let res = await fetchWithHeader(botUa);
    if (res.body && res.body.includes('beconfig-store_state')) {
      return res.body;
    }

    const cookieMatch = (res.body || '').match(/js_challenge_value=([a-f0-9]+)/);
    if (cookieMatch) {
      const challengeCookie = `js_challenge_value=${cookieMatch[1]}`;
      const res2 = await fetchWithHeader(botUa, challengeCookie);
      if (res2.body && res2.body.includes('beconfig-store_state')) {
        return res2.body;
      }
    }

    // Stage 2: facebookexternalhit fallback
    const fbUa = 'facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)';
    let fbRes = await fetchWithHeader(fbUa);
    const fbCookieMatch = (fbRes.body || '').match(/js_challenge_value=([a-f0-9]+)/);
    if (fbCookieMatch) {
      const challengeCookie = `js_challenge_value=${fbCookieMatch[1]}`;
      const fbRes2 = await fetchWithHeader(fbUa, challengeCookie);
      if (fbRes2.body && fbRes2.body.includes('beconfig-store_state')) {
        return fbRes2.body;
      }
    }

    // Stage 3: DuckDuckBot fallback
    const ddgUa = 'DuckDuckBot/1.0; (+http://duckduckgo.com/duckduckbot.html)';
    let ddgRes = await fetchWithHeader(ddgUa);
    return ddgRes.body || res.body || '';
  }

  async analyzeBehance(url, timeoutMs = 35000) {
    logger.info(`Analyzing Behance URL: ${url}`);
    try {
      const html = await this.fetchBehanceHtml(url);
      if (!html || !html.includes('beconfig-store_state')) {
        throw new Error('Could not retrieve Behance media content.');
      }

      const jsonStr = html.split('id="beconfig-store_state">')[1].split('</script>')[0];
      const raw = JSON.parse(jsonStr);
      const proj = raw.project?.project;
      if (!proj) throw new Error('Behance project details not found.');

      const title = proj.name || proj.title || 'Behance Media';
      const uploader = (proj.owners && proj.owners.length > 0)
        ? (proj.owners[0].displayName || proj.owners[0].display_name || proj.owners[0].first_name || 'Behance Creator')
        : 'Behance Creator';
      const thumbnail = proj.covers?.['808'] || proj.covers?.['404'] || proj.covers?.['original'] || '';

      const mediaItems = [];
      let itemIndex = 1;

      for (const m of (proj.modules || [])) {
        // 1. Direct VideoModule
        if (m.__typename === 'VideoModule' && m.videoData?.renditions?.length) {
          const bestRendition = m.videoData.renditions.slice().sort((a, b) => (b.height || 0) - (a.height || 0))[0];
          mediaItems.push({
            id: `behance_v_${m.id || itemIndex}`,
            index: itemIndex++,
            title: `${title} - Part ${itemIndex - 1}`,
            url: bestRendition.url,
            downloadTarget: bestRendition.url,
            directStreamUrl: bestRendition.url,
            thumbnail: m.thumbnail || thumbnail,
            uploader,
            type: 'video',
            resolution: `${bestRendition.height || 1080}p`
          });
        }

        // 2. Embedded Video Module (Vimeo, YouTube, etc.)
        const embedHtml = m.originalEmbed || m.embed || m.fluidEmbed || '';
        if (embedHtml) {
          const srcMatch = embedHtml.match(/src=["']([^"']+)["']/i);
          if (srcMatch && srcMatch[1]) {
            let embedSrc = srcMatch[1].replace(/&amp;/g, '&');
            const vimeoId = embedSrc.match(/vimeo\.com\/(?:video\/)?(\d+)/i)?.[1];
            let targetUrl = embedSrc;
            if (vimeoId) {
              targetUrl = `https://vimeo.com/${vimeoId}`;
            }
            const ytId = embedSrc.match(/(?:youtube\.com\/(?:embed\/|watch\?v=)|youtu\.be\/)([a-zA-Z0-9_-]{11})/i)?.[1];
            if (ytId) {
              targetUrl = `https://www.youtube.com/watch?v=${ytId}`;
            }

            const hMatch = embedHtml.match(/height=["'](\d+)["']/i);
            const h = hMatch ? parseInt(hMatch[1], 10) : 1080;

            mediaItems.push({
              id: `behance_embed_${m.id || itemIndex}`,
              index: itemIndex++,
              title: `${title} - Video ${itemIndex - 1}`,
              url: targetUrl,
              downloadTarget: targetUrl,
              embedUrl: embedSrc,
              thumbnail,
              uploader,
              type: 'video',
              resolution: `${h}p`
            });
          }
        }

        // 3. ImageModule (high-res images)
        if (m.__typename === 'ImageModule' && (m.sizes?.original || m.sizes?.max_1920 || m.sizes?.max_1200)) {
          const imgUrl = m.sizes.original || m.sizes.max_1920 || m.sizes.max_1200;
          mediaItems.push({
            id: `behance_img_${m.id || itemIndex}`,
            index: itemIndex++,
            title: `${title} - Image ${itemIndex - 1}`,
            url: imgUrl,
            downloadTarget: imgUrl,
            thumbnail: imgUrl,
            uploader,
            type: 'image',
            resolution: 'High Resolution Image'
          });
        }
      }

      if (mediaItems.length === 0) {
        if (thumbnail) {
          mediaItems.push({
            id: `behance_cover_${proj.id || Date.now()}`,
            index: 1,
            title,
            url: thumbnail,
            downloadTarget: thumbnail,
            thumbnail,
            uploader,
            type: 'image',
            resolution: 'Original Cover'
          });
        } else {
          throw new Error('No downloadable media found in this Behance project.');
        }
      }

      const videoItems = mediaItems.filter(i => i.type === 'video');
      const effectiveItems = videoItems.length > 0 ? videoItems : mediaItems;

      if (effectiveItems.length > 1) {
        return {
          id: `behance_${proj.id || Date.now()}`,
          isPlaylist: true,
          isCarousel: true,
          url,
          title,
          uploader,
          itemCount: effectiveItems.length,
          items: effectiveItems.map(item => ({
            id: item.id,
            url: item.url,
            title: item.title,
            thumbnail: item.thumbnail,
            duration: 0,
            downloadQuery: item.downloadTarget,
            downloadTarget: item.downloadTarget,
            uploader,
            type: item.type,
            embedUrl: item.embedUrl || '',
            directStreamUrl: item.directStreamUrl || ''
          })),
          thumbnail,
          downloadTarget: effectiveItems[0].downloadTarget,
          directStreamUrl: effectiveItems[0].directStreamUrl || '',
          formats: [
            {
              formatId: effectiveItems[0].type === 'image' ? 'behance_img_orig' : 'behance_vid_best',
              ext: effectiveItems[0].type === 'image' ? 'jpg' : 'mp4',
              resolution: effectiveItems[0].resolution || '1080p',
              url: effectiveItems[0].downloadTarget,
              isImage: effectiveItems[0].type === 'image'
            }
          ]
        };
      }

      const single = effectiveItems[0];
      const isImg = single.type === 'image';
      return {
        id: single.id,
        url,
        title: single.title,
        uploader,
        thumbnail: single.thumbnail,
        duration: 0,
        formats: [
          {
            formatId: isImg ? 'behance_image_orig' : 'behance_video_best',
            ext: isImg ? 'jpg' : 'mp4',
            resolution: single.resolution,
            url: single.downloadTarget,
            isImage: isImg
          }
        ],
        downloadTarget: single.downloadTarget,
        directStreamUrl: single.directStreamUrl || (isImg ? single.downloadTarget : ''),
        embedUrl: single.embedUrl || '',
        platform: 'behance',
        mediaType: isImg ? 'image' : 'video'
      };
    } catch (err) {
      logger.error('Behance analysis failed:', err);
      throw classifyError(err, 'Failed to extract media from Behance');
    }
  }

  async analyzeDribbble(url, timeoutMs = 35000) {
    logger.info(`Analyzing Dribbble URL: ${url}`);
    try {
      const res = await fetchHtml(url, {
        'User-Agent': 'DuckDuckBot/1.0; (+http://duckduckgo.com/duckduckbot.html)',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
      });
      const html = res.body || '';

      let rawTitle = html.match(/<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']/i)?.[1] ||
                     html.match(/<meta[^>]+name=["']twitter:title["'][^>]+content=["']([^"']+)["']/i)?.[1] ||
                     html.match(/<title>([^<]+)<\/title>/i)?.[1] ||
                     'Dribbble Shot';
      let title = rawTitle.replace(/&amp;/g, '&').replace(/&#39;/g, "'").replace(/&quot;/g, '"').replace(/\s*\|\s*Dribbble/i, '').trim();

      let uploader = 'Dribbble Designer';
      const authorMatch = html.match(/by\s+([^<]+?)\s+on Dribbble/i) || html.match(/<meta[^>]+property=["']og:site_name["'][^>]+content=["']([^"']+)["']/i);
      if (authorMatch && authorMatch[1] && !authorMatch[1].toLowerCase().includes('dribbble')) {
        uploader = authorMatch[1].trim();
      }

      let thumbnail = html.match(/<meta[^>]+property=["']og:image(?::secure_url)?["'][^>]+content=["']([^"']+)["']/i)?.[1] ||
                      html.match(/<meta[^>]+name=["']twitter:image["'][^>]+content=["']([^"']+)["']/i)?.[1] ||
                      '';
      thumbnail = thumbnail.replace(/&amp;/g, '&');

      // Detect videos
      let videoUrl = '';
      const vMatch = html.match(/https:\/\/cdn\.dribbble\.com\/userupload\/[^"'\s<>]+\.mp4[^"'\s<>]*/gi) ||
                     html.match(/https?:\/\/[^"'\s<>]+\.(?:mp4|webm)[^"'\s<>]*/gi) || [];
      const validVids = vMatch.filter(v => !v.includes('blank') && !v.includes('pixel'));
      if (validVids.length > 0) {
        videoUrl = validVids.find(v => v.includes('large-') || v.includes('original-')) || validVids[0];
      }

      const isVideo = !!videoUrl;
      const isImg = !isVideo && !!thumbnail;
      const downloadTarget = isVideo ? videoUrl : (thumbnail || url);

      return {
        id: `dribbble_${Date.now()}`,
        url,
        title,
        uploader,
        thumbnail: thumbnail || videoUrl,
        duration: 0,
        formats: [
          {
            formatId: isVideo ? 'dribbble_video_1080p' : 'dribbble_image_high',
            ext: isVideo ? 'mp4' : 'jpg',
            resolution: isVideo ? '1080p' : 'High Resolution Image',
            url: downloadTarget,
            isVideo,
            isImage: isImg
          }
        ],
        downloadTarget,
        directStreamUrl: isVideo ? videoUrl : (isImg ? thumbnail : ''),
        platform: 'dribbble',
        mediaType: isVideo ? 'video' : (isImg ? 'image' : 'video')
      };
    } catch (err) {
      logger.warn('Dribbble extraction failed, trying universal web fallback:', err);
      return await this.analyzeUniversalWebMedia(url, timeoutMs);
    }
  }

  async analyzeUniversalWebMedia(url, timeoutMs = 35000) {
    logger.info(`Analyzing Universal Web Media URL: ${url}`);
    try {
      const res = await fetchSmartHtml(url);
      const html = res.body || '';

      // 1. Title
      let rawTitle = html.match(/<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']/i)?.[1] ||
                     html.match(/<meta[^>]+name=["']twitter:title["'][^>]+content=["']([^"']+)["']/i)?.[1] ||
                     html.match(/<title>([^<]+)<\/title>/i)?.[1] ||
                     '';
      let title = rawTitle
        .replace(/&amp;/g, '&')
        .replace(/&#39;/g, "'")
        .replace(/&quot;/g, '"')
        .replace(/[\r\n\t]+/g, ' ')
        .trim();

      if (!title || title.toLowerCase() === 'not found' || title.toLowerCase() === 'just a moment...') {
        try {
          const u = new URL(url);
          const slug = u.pathname.split('/').filter(Boolean).pop() || u.hostname;
          title = slug.replace(/[-_]/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
        } catch (_) {
          title = 'Web Media';
        }
      }

      // 2. Author / Uploader
      let uploader = html.match(/<meta[^>]+property=["']og:site_name["'][^>]+content=["']([^"']+)["']/i)?.[1] ||
                     html.match(/<meta[^>]+name=["']author["'][^>]+content=["']([^"']+)["']/i)?.[1] ||
                     '';
      if (!uploader) {
        try {
          uploader = new URL(url).hostname.replace(/^www\./, '');
        } catch (_) {
          uploader = 'Web Creator';
        }
      }
      uploader = uploader.replace(/&amp;/g, '&').trim();

      // 3. Thumbnail
      let thumbnail = html.match(/<meta[^>]+property=["']og:image(?::secure_url)?["'][^>]+content=["']([^"']+)["']/i)?.[1] ||
                      html.match(/<meta[^>]+name=["']twitter:image["'][^>]+content=["']([^"']+)["']/i)?.[1] ||
                      html.match(/<link[^>]+rel=["']image_src["'][^>]+href=["']([^"']+)["']/i)?.[1] ||
                      '';
      thumbnail = thumbnail.replace(/&amp;/g, '&');
      if (thumbnail && !thumbnail.startsWith('http')) {
        try { thumbnail = new URL(thumbnail, url).href; } catch (_) {}
      }

      // 4. Video Detection
      let videoUrl = html.match(/<meta[^>]+property=["']og:video(?::secure_url|:url)?["'][^>]+content=["']([^"']+)["']/i)?.[1] ||
                     html.match(/<meta[^>]+name=["']twitter:player:stream["'][^>]+content=["']([^"']+)["']/i)?.[1] ||
                     '';
      videoUrl = videoUrl.replace(/&amp;/g, '&');

      // Video tag or source
      if (!videoUrl) {
        const srcMatch = html.match(/<video[^>]*src=["']([^"']+)["']/i) ||
                         html.match(/<source[^>]*src=["']([^"']+\.mp4[^"']*)["']/i) ||
                         html.match(/<source[^>]*src=["']([^"']+\.webm[^"']*)["']/i);
        if (srcMatch && srcMatch[1]) videoUrl = srcMatch[1];
      }

      // Check embedded players (Vimeo, YouTube, Wistia)
      let embedUrl = '';
      let downloadTarget = videoUrl;

      const vimeoMatch = html.match(/(?:player\.vimeo\.com\/video\/|vimeo\.com\/)(\d+)/i);
      if (vimeoMatch && vimeoMatch[1]) {
        embedUrl = `https://player.vimeo.com/video/${vimeoMatch[1]}`;
        if (!videoUrl) {
          videoUrl = `https://vimeo.com/${vimeoMatch[1]}`;
          downloadTarget = videoUrl;
        }
      }

      const ytMatch = html.match(/(?:youtube\.com\/(?:embed\/|watch\?v=)|youtu\.be\/)([a-zA-Z0-9_-]{11})/i);
      if (ytMatch && ytMatch[1] && !videoUrl) {
        embedUrl = `https://www.youtube.com/embed/${ytMatch[1]}`;
        videoUrl = `https://www.youtube.com/watch?v=${ytMatch[1]}`;
        downloadTarget = videoUrl;
      }

      // Direct media scanning in HTML
      if (!videoUrl) {
        const cdnVids = html.match(/https?:\/\/[a-zA-Z0-9.\-_/]+\.(?:mp4|webm|mov|m4v)(?:\?[^"'\s<>]*)?/gi) || [];
        const valid = cdnVids.filter(v => !v.includes('blank') && !v.includes('pixel') && !v.includes('tracking') && !v.includes('ad_') && !v.includes('analytics'));
        if (valid.length > 0) {
          videoUrl = valid[0];
          downloadTarget = videoUrl;
        }
      }

      // Audio detection if no video
      let audioUrl = '';
      if (!videoUrl) {
        const audMatch = html.match(/<meta[^>]+property=["']og:audio(?::secure_url)?["'][^>]+content=["']([^"']+)["']/i)?.[1] ||
                         html.match(/<audio[^>]*src=["']([^"']+)["']/i) ||
                         html.match(/<source[^>]*src=["']([^"']+\.(?:mp3|wav|m4a|aac|flac|ogg)[^"']*)["']/i);
        if (audMatch && audMatch[1]) audioUrl = audMatch[1].replace(/&amp;/g, '&');
        if (!audioUrl) {
          const cdnAuds = html.match(/https?:\/\/[a-zA-Z0-9.\-_/]+\.(?:mp3|wav|m4a|aac|flac|ogg)(?:\?[^"'\s<>]*)?/gi) || [];
          if (cdnAuds.length > 0) audioUrl = cdnAuds[0];
        }
      }

      const isVideo = !!videoUrl;
      const isAudio = !isVideo && !!audioUrl;
      const isImg = !isVideo && !isAudio && !!thumbnail;

      if (!isVideo && !isAudio && !isImg) {
        throw new Error('No media elements (video, audio, or high-res image) detected on this webpage.');
      }

      const mediaType = isVideo ? 'video' : (isAudio ? 'audio' : 'image');
      const finalTarget = isVideo ? downloadTarget : (isAudio ? audioUrl : thumbnail);
      const ext = isVideo ? 'mp4' : (isAudio ? 'mp3' : 'jpg');
      const resolution = isVideo ? '1080p' : (isAudio ? '320 kbps' : 'Original Image');

      let domain = '';
      try { domain = new URL(url).hostname.replace(/^www\./, ''); } catch (_) {}

      return {
        id: `web_${Date.now()}`,
        url,
        title,
        uploader,
        thumbnail: thumbnail || (isVideo ? videoUrl : ''),
        duration: 0,
        formats: [
          {
            formatId: `universal_${mediaType}_best`,
            ext,
            resolution,
            url: finalTarget,
            isVideo,
            isAudio,
            isImage: isImg
          }
        ],
        downloadTarget: finalTarget,
        directStreamUrl: (isVideo && !embedUrl) ? videoUrl : (isAudio ? audioUrl : (isImg ? thumbnail : '')),
        embedUrl,
        platform: domain || 'web',
        mediaType
      };
    } catch (err) {
      logger.error('Universal web media extraction failed:', err);
      throw classifyError(err, 'Failed to extract media from this webpage');
    }
  }

  async analyzeFiverr(url, timeoutMs = 35000) {
    logger.info(`Analyzing Fiverr URL: ${url}`);
    try {
      const html = await dumpHeadlessDom(url, timeoutMs) || '';
      if (!html) {
        throw new Error('Could not render Fiverr page');
      }

      const cleanHtml = html.replace(/&amp;/g, '&');
      let title = cleanHtml.match(/<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']/i)?.[1] ||
                  cleanHtml.match(/<meta[^>]+name=["']twitter:title["'][^>]+content=["']([^"']+)["']/i)?.[1] ||
                  cleanHtml.match(/<title>([^<]+)<\/title>/i)?.[1] ||
                  'Fiverr Gig Portfolio';
      title = title.replace(/\s*\|\s*Fiverr/i, '').trim();

      let uploader = 'Fiverr Seller';
      const authorMatch = cleanHtml.match(/by\s+([a-zA-Z0-9_\-]+)\s+on Fiverr/i) ||
                          cleanHtml.match(/class=["'][^"']*seller-name[^"']*["'][^>]*>([^<]+)</i);
      if (authorMatch && authorMatch[1]) {
        uploader = authorMatch[1].trim();
      } else {
        const uMatch = url.match(/fiverr\.com\/([a-zA-Z0-9_\-]+)\//);
        if (uMatch && uMatch[1] && !['s', 'categories', 'gigs'].includes(uMatch[1])) {
          uploader = uMatch[1];
        }
      }

      const thumbnail = cleanHtml.match(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i)?.[1] ||
                        cleanHtml.match(/https:\/\/(?:res\.cloudinary\.com\/fiverr-prod|fiverr-res\.cloudinary\.com)\/images\/[^"'\s<>]+/i)?.[0] || '';

      // Check for video assets
      let videoUrl = cleanHtml.match(/<meta[^>]+property=["']og:video(?::secure_url)?["'][^>]+content=["']([^"']+)["']/i)?.[1] ||
                     cleanHtml.match(/<video[^>]+src=["']([^"']+)["']/i)?.[1] ||
                     cleanHtml.match(/https:\/\/(?:res\.cloudinary\.com\/fiverr-prod|fiverr-res\.cloudinary\.com)\/video\/upload\/[^"'\s<>]+?\.mp4/i)?.[0] || '';

      if (videoUrl) {
        videoUrl = videoUrl.replace(/&amp;/g, '&');
      }

      const isVideo = Boolean(videoUrl);
      const directTarget = isVideo ? videoUrl : (thumbnail || url);

      return {
        id: `fiverr_${Date.now()}`,
        url,
        title,
        uploader,
        thumbnail,
        duration: 0,
        formats: [
          {
            formatId: isVideo ? 'fiverr_video_best' : 'fiverr_image_best',
            ext: isVideo ? 'mp4' : 'jpg',
            resolution: isVideo ? '1080p' : 'Original',
            url: directTarget,
            isImage: !isVideo
          }
        ],
        downloadTarget: directTarget,
        directStreamUrl: isVideo ? directTarget : '',
        embedUrl: '',
        platform: 'fiverr',
        mediaType: isVideo ? 'video' : 'image'
      };
    } catch (err) {
      logger.warn('Fiverr direct headless failed, trying universal web fallback:', err);
      return await this.analyzeUniversalWebMedia(url, timeoutMs);
    }
  }

  async analyzeArtStation(url, timeoutMs = 35000) {
    logger.info(`Analyzing ArtStation URL: ${url}`);
    try {
      const pMatch = url.match(/(?:artwork|projects)\/([a-zA-Z0-9]+)/);
      const projId = pMatch ? pMatch[1] : null;

      let title = 'ArtStation Artwork';
      let uploader = 'ArtStation Artist';
      let thumbnail = '';
      let directTarget = '';
      let isVideo = false;

      if (projId) {
        try {
          const jsonRes = await fetchHtml(`https://www.artstation.com/projects/${projId}.json`, {
            'User-Agent': 'Mozilla/5.0 (compatible; Discordbot/2.0; +https://discordapp.com)'
          });
          if (jsonRes.statusCode === 200 && jsonRes.body) {
            const data = JSON.parse(jsonRes.body);
            title = data.title || title;
            uploader = data.user?.username || data.user?.full_name || uploader;
            thumbnail = data.cover_url || '';

            if (data.assets && data.assets.length > 0) {
              const videoAsset = data.assets.find(a => a.has_embedded_player || a.video_clip || (a.asset_type === 'video'));
              if (videoAsset) {
                isVideo = true;
                if (videoAsset.player_embedded) {
                  const srcM = videoAsset.player_embedded.match(/src=["']([^"']+)["']/i);
                  if (srcM) directTarget = srcM[1];
                }
                if (!directTarget && videoAsset.video_clip) {
                  directTarget = videoAsset.video_clip;
                }
                if (!directTarget && videoAsset.image_url) {
                  directTarget = videoAsset.image_url;
                }
              } else {
                directTarget = data.assets[0].image_url || thumbnail;
              }
            }
          }
        } catch (_) {}
      }

      if (!directTarget) {
        const html = await dumpHeadlessDom(url, timeoutMs) || '';
        if (html) {
          const cleanHtml = html.replace(/&amp;/g, '&');
          title = cleanHtml.match(/<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']/i)?.[1] ||
                  cleanHtml.match(/<title>([^<]+)<\/title>/i)?.[1] || title;
          uploader = cleanHtml.match(/<meta[^>]+name=["']author["'][^>]+content=["']([^"']+)["']/i)?.[1] || uploader;
          thumbnail = cleanHtml.match(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i)?.[1] || thumbnail;
          const videoUrl = cleanHtml.match(/<video[^>]+src=["']([^"']+)["']/i)?.[1] || '';
          if (videoUrl) {
            isVideo = true;
            directTarget = videoUrl;
          } else {
            directTarget = thumbnail || url;
          }
        }
      }

      return {
        id: `artstation_${projId || Date.now()}`,
        url,
        title: title.replace(/\s*\|\s*ArtStation/i, '').trim(),
        uploader,
        thumbnail,
        duration: 0,
        formats: [
          {
            formatId: isVideo ? 'artstation_video' : 'artstation_image',
            ext: isVideo ? 'mp4' : 'jpg',
            resolution: isVideo ? '1080p' : 'Original',
            url: directTarget,
            isImage: !isVideo
          }
        ],
        downloadTarget: directTarget,
        directStreamUrl: isVideo ? directTarget : '',
        embedUrl: (directTarget && (directTarget.includes('vimeo.com') || directTarget.includes('youtube.com'))) ? directTarget : '',
        platform: 'artstation',
        mediaType: isVideo ? 'video' : 'image'
      };
    } catch (err) {
      logger.warn('ArtStation extraction failed, trying universal web fallback:', err);
      return await this.analyzeUniversalWebMedia(url, timeoutMs);
    }
  }

  async analyzePinterest(url, timeoutMs = 35000) {
    logger.info(`Analyzing Pinterest URL: ${url}`);
    const targetUrl = await this.expandPinterestUrl(url);

    let title = '';
    let author = 'Pinterest Creator';
    let thumbnail = 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?w=800';
    let directImageUrl = '';
    let directVideoUrl = '';
    let durationSec = 0;
    let pinId = '';

    // Extract Pin ID
    const pinMat = targetUrl.match(/pin\/(?:[\w-]+--)?(\d+)/i);
    if (pinMat) {
      pinId = pinMat[1];
    } else {
      const numMat = targetUrl.match(/(\d{10,22})/);
      if (numMat) pinId = numMat[1];
    }

    // 1. Direct query to Pinterest official PinResource endpoint
    if (pinId) {
      try {
        const opts = { field_set_key: 'unauth_react_main_pin', id: pinId };
        const q = encodeURIComponent(JSON.stringify({ options: opts }));
        const apiUrl = `https://www.pinterest.com/resource/PinResource/get/?data=${q}`;
        const { body: apiBody, statusCode } = await fetchHtml(apiUrl, {
          'X-Pinterest-PWS-Handler': 'www/[username].js',
          'Accept': 'application/json, text/javascript, */*, q=0.01',
          'X-Requested-With': 'XMLHttpRequest',
          'Referer': 'https://www.pinterest.com/'
        });

        if (statusCode === 200 && apiBody) {
          const json = JSON.parse(apiBody);
          const data = json.resource_response?.data;
          if (data) {
            const parsedTitle = data.title || data.grid_title || data.closeup_unified_description || '';
            if (parsedTitle && parsedTitle.trim()) {
              title = parsedTitle.trim();
            }

            const pinner = data.pinner;
            if (pinner) {
              const pinnerName = pinner.full_name || pinner.username || '';
              if (pinnerName) author = pinnerName;
            }

            const images = data.images;
            const origImg = images?.orig?.url || images?.['736x']?.url || '';
            if (origImg) {
              directImageUrl = origImg;
              thumbnail = origImg;
            }

            // Check videos
            let vidList = data.videos?.video_list;
            if (!vidList && data.story_pin_data?.pages) {
              for (const page of data.story_pin_data.pages) {
                if (page.blocks) {
                  for (const blk of page.blocks) {
                    if (blk.video?.video_list) {
                      vidList = blk.video.video_list;
                      break;
                    }
                  }
                }
                if (vidList) break;
              }
            }

            if (vidList) {
              const preferredKeys = ['V_EXP7', 'V_720P', 'V_480P'];
              for (const pk of preferredKeys) {
                const vObj = vidList[pk];
                if (vObj?.url && vObj.url.includes('.mp4')) {
                  directVideoUrl = vObj.url;
                  if (vObj.duration) durationSec = Math.round(vObj.duration / 1000);
                  if (vObj.thumbnail) thumbnail = vObj.thumbnail;
                  break;
                }
              }
              if (!directVideoUrl) {
                for (const vk of Object.keys(vidList)) {
                  const vObj = vidList[vk];
                  if (vObj?.url && vObj.url.includes('.mp4')) {
                    directVideoUrl = vObj.url;
                    if (vObj.duration) durationSec = Math.round(vObj.duration / 1000);
                    if (vObj.thumbnail) thumbnail = vObj.thumbnail;
                    break;
                  }
                }
              }
            }
          }
        }
      } catch (apiErr) {
        logger.warn('[Analyzer] Pinterest PinResource query notice:', apiErr.message);
      }
    }

    // 2. Fallback HTML Scraping (if direct media or title missing)
    if (!directVideoUrl && !directImageUrl) {
      try {
        const { body: html } = await fetchHtml(targetUrl, {
          'Referer': 'https://www.google.com/'
        });
        const cleanHtml = html.replace(/\\\//g, '/').replace(/\\u002F/gi, '/').replace(/&amp;/g, '&');

        if (!title) {
          const ogTitleM = cleanHtml.match(/<meta\s+property=["']og:title["']\s+content=["'](.*?)["']/i) ||
                           cleanHtml.match(/<meta\s+content=["'](.*?)["']\s+property=["']og:title["']/i);
          if (ogTitleM && ogTitleM[1]) {
            title = ogTitleM[1].replace(/ \| Pinterest$/i, '').trim();
          } else {
            const pageTitleM = cleanHtml.match(/<title[^>]*>(.*?)<\/title>/i);
            if (pageTitleM && pageTitleM[1]) {
              title = pageTitleM[1].replace(/ \| Pinterest$/i, '').trim();
            }
          }
        }

        const vidPattern = /https?:\/\/[a-zA-Z0-9.-]*pinimg\.com\/videos\/[a-zA-Z0-9/_.-]+\.mp4/i;
        const vidM = cleanHtml.match(vidPattern);
        if (vidM) {
          directVideoUrl = vidM[0];
        } else {
          const ogvM = cleanHtml.match(/<meta\s+property=["']og:video(?::secure_url)?["']\s+content=["'](.*?)["']/i);
          if (ogvM && ogvM[1]) directVideoUrl = ogvM[1];
        }

        const imgPattern = /https:\/\/i\.pinimg\.com\/(?:originals|736x)\/[a-zA-Z0-9/_.-]+\.(?:jpg|png|webp|gif)/i;
        const imgM = cleanHtml.match(imgPattern);
        if (imgM) {
          directImageUrl = imgM[0];
          if (!thumbnail || thumbnail.includes('unsplash')) thumbnail = directImageUrl;
        } else {
          const ogImgM = cleanHtml.match(/<meta\s+property=["']og:image["']\s+content=["'](.*?)["']/i);
          if (ogImgM && ogImgM[1]) {
            directImageUrl = ogImgM[1];
            if (!thumbnail || thumbnail.includes('unsplash')) thumbnail = directImageUrl;
          }
        }
      } catch (htmlErr) {
        logger.warn('[Analyzer] Pinterest HTML fallback notice:', htmlErr.message);
      }
    }

    if (!title) {
      title = pinId ? `Pinterest Pin ${pinId}` : 'Pinterest Visual Media';
    }

    const isVideo = Boolean(directVideoUrl);
    const mediaStream = directVideoUrl || directImageUrl;

    const meta = {
      id: pinId || 'pinterest_pin',
      url: targetUrl,
      title: title,
      uploader: author,
      channel: author,
      thumbnail: thumbnail,
      duration: durationSec,
      extractor: 'pinterest',
      directStreamUrl: mediaStream,
      formats: isVideo ? [
        { formatId: 'best-video', label: 'Best Video (MP4)', ext: 'mp4', resolution: '1080p', type: 'video' },
        { formatId: 'best-audio', label: 'Audio Only (MP3)', ext: 'mp3', type: 'audio' }
      ] : [
        { formatId: 'original-image', label: 'High Resolution Photo', ext: 'jpg', type: 'image' }
      ],
      defaultProfile: isVideo ? {
        type: 'video',
        presetId: 'best-video',
        label: 'Best Video Quality',
        container: 'mp4'
      } : {
        type: 'image',
        presetId: 'original-image',
        label: 'Original Image',
        container: 'jpg'
      }
    };

    return meta;
  }

  isCloudStorageUrl(urlStr) {
    if (!this.isValidUrl(urlStr)) return false;
    const lower = urlStr.toLowerCase();
    if (lower.includes('/folders/') || lower.includes('folderview') || lower.includes('/scl/fo/')) return false;
    return lower.includes('drive.google.com') ||
           lower.includes('dropbox.com') ||
           lower.includes('1drv.ms') ||
           lower.includes('onedrive.live.com') ||
           lower.includes('sharepoint.com') ||
           /\.(mp4|mov|mkv|webm|avi|flv|m4v|mp3|wav|m4a|aac|flac|ogg|zip|rar|7z|tar|gz)(\?.*)?$/i.test(urlStr);
  }

  async analyzeCloudStorage(url, timeoutMs = 35000) {
    if (this.isPlaylistUrl(url)) {
      return await this.analyzePlaylist(url, timeoutMs);
    }
    logger.info(`Analyzing cloud storage / direct media URL: ${url}`);
    let directUrl = url;
    let title = 'Cloud Media';
    let isArchive = false;
    let isAudio = false;
    let isVideo = true;

    const lower = url.toLowerCase();
    if (lower.includes('drive.google.com')) {
      const driveMatch = url.match(/\/d\/([a-zA-Z0-9_-]+)/) || url.match(/id=([a-zA-Z0-9_-]+)/);
      if (driveMatch) {
        directUrl = `https://drive.google.com/uc?export=download&id=${driveMatch[1]}`;
        title = `Google Drive File (${driveMatch[1].substring(0, 8)})`;
      }
    } else if (lower.includes('dropbox.com')) {
      directUrl = url.replace('dl=0', 'dl=1');
      if (!directUrl.includes('dl=1')) {
        directUrl += (directUrl.includes('?') ? '&' : '?') + 'dl=1';
      }
      const nameMatch = url.match(/\/([^/?#]+)\?/);
      if (nameMatch) {
        try { title = decodeURIComponent(nameMatch[1]); } catch (_) {}
      }
    } else if (lower.includes('1drv.ms') || lower.includes('onedrive.live.com') || lower.includes('sharepoint.com')) {
      directUrl = url.includes('download=1') ? url : url + (url.includes('?') ? '&' : '?') + 'download=1';
      title = 'OneDrive File';
    } else {
      try {
        const u = new URL(url);
        const bname = path.basename(u.pathname);
        if (bname) title = decodeURIComponent(bname);
      } catch (_) {}
    }

    if (/\.(zip|rar|7z|tar|gz)(\?.*)?$/i.test(url) || /\.(zip|rar|7z|tar|gz)(\?.*)?$/i.test(directUrl)) {
      isArchive = true;
      isVideo = false;
      isAudio = false;
    } else if (/\.(mp3|wav|m4a|aac|flac|ogg)(\?.*)?$/i.test(url) || /\.(mp3|wav|m4a|aac|flac|ogg)(\?.*)?$/i.test(directUrl)) {
      isAudio = true;
      isVideo = false;
    }

    return {
      id: 'cloud_' + Date.now(),
      url: directUrl,
      directUrl: directUrl,
      directStreamUrl: directUrl,
      title: title,
      thumbnail: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800',
      duration: 0,
      uploader: 'Cloud Storage',
      channel: 'Cloud Storage',
      extractor: 'cloud',
      isArchive: isArchive,
      hasAudio: isAudio || isVideo,
      hasVideo: isVideo,
      availableResolutions: isVideo ? [1080, 720] : [],
      formats: isArchive ? [
        { format_id: 'archive_original', ext: 'zip', height: null, vcodec: 'none', acodec: 'none', url: directUrl }
      ] : (isVideo ? [
        { format_id: 'cloud_1080p', ext: 'mp4', height: 1080, vcodec: 'h264', acodec: 'aac', url: directUrl },
        { format_id: 'cloud_720p', ext: 'mp4', height: 720, vcodec: 'h264', acodec: 'aac', url: directUrl },
        { format_id: 'cloud_audio', ext: 'mp3', height: null, vcodec: 'none', acodec: 'mp3', url: directUrl }
      ] : [
        { format_id: 'cloud_audio', ext: 'mp3', height: null, vcodec: 'none', acodec: 'mp3', url: directUrl }
      ]),
      defaultProfile: isArchive ? {
        type: 'archive',
        presetId: 'original-archive',
        label: 'Original Archive (.zip)',
        container: 'zip'
      } : (isVideo ? {
        type: 'video',
        presetId: 'best-available',
        label: 'Direct Cloud Video (MP4)',
        container: 'mp4',
        remuxToMp4: true
      } : {
        type: 'audio',
        presetId: 'best-audio',
        label: 'Direct Audio Stream (MP3)',
        container: 'mp3'
      })
    };
  }

  async analyzeInstagram(url, timeoutMs = 25000) {
    logger.info(`Analyzing Instagram media with multi-slide/carousel extractor: ${url}`);
    // 1. Try Python with yt_dlp InstagramIE._real_extract
    try {
      const pyCode = `
import sys, json, yt_dlp
url = sys.argv[1]
ydl = yt_dlp.YoutubeDL({'quiet': True, 'no_warnings': True})
ie = yt_dlp.extractor.instagram.InstagramIE(ydl)
res = ie._real_extract(url)
t = res.get('_type')
title = res.get('title') or (res.get('description') or '')[:60] or 'Instagram Post'
uploader = res.get('uploader') or res.get('channel') or '@Instagram'
if t == 'playlist':
    entries = res.get('entries', [])
    slides = []
    for idx, e in enumerate(entries):
        formats = e.get('formats') or []
        vid_url = formats[-1].get('url') if formats else None
        thumbs = e.get('thumbnails') or []
        img_url = thumbs[-1].get('url') if thumbs else (e.get('thumbnail') or None)
        slide_url = vid_url or img_url
        if slide_url:
            slides.append({
                'index': idx + 1,
                'title': f"{title} (Slide {idx + 1})",
                'url': slide_url,
                'thumbnail': img_url or vid_url,
                'isVideo': bool(vid_url),
                'duration': e.get('duration') or 0
            })
    print(json.dumps({'type': 'playlist', 'title': title, 'uploader': uploader, 'itemCount': len(slides), 'items': slides}))
else:
    formats = res.get('formats') or []
    vid_url = formats[-1].get('url') if formats else None
    thumbs = res.get('thumbnails') or []
    img_url = thumbs[-1].get('url') if thumbs else res.get('thumbnail')
    print(json.dumps({'type': 'single', 'title': title, 'uploader': uploader, 'videoUrl': vid_url, 'photoUrl': img_url, 'thumbnail': img_url or vid_url, 'duration': res.get('duration') or 0}))
`.trim();

      const { stdout } = await execFileAsync('python', ['-c', pyCode, url], {
        windowsHide: true,
        timeout: timeoutMs,
        maxBuffer: 15 * 1024 * 1024
      });

      const parsed = JSON.parse(stdout.trim());
      if (parsed.type === 'playlist' && parsed.items && parsed.items.length > 0) {
        return {
          isPlaylist: true,
          isCarousel: true,
          url,
          title: parsed.title,
          uploader: parsed.uploader,
          itemCount: parsed.items.length,
          items: parsed.items.map((s) => ({
            url: s.url,
            title: s.title,
            thumbnail: s.thumbnail,
            duration: s.duration || 0,
            downloadQuery: s.url,
            uploader: parsed.uploader
          }))
        };
      } else if (parsed.photoUrl || parsed.videoUrl) {
        const isPhoto = !parsed.videoUrl;
        return {
          id: 'instagram_' + Date.now(),
          url,
          title: parsed.title,
          uploader: parsed.uploader,
          thumbnail: parsed.thumbnail,
          duration: parsed.duration || 0,
          formats: [
            {
              formatId: isPhoto ? 'photo_original' : 'video_original',
              ext: isPhoto ? 'jpg' : 'mp4',
              resolution: isPhoto ? 'Original High-Res Photo' : '1080p Full HD',
              url: parsed.videoUrl || parsed.photoUrl,
              isImage: isPhoto
            }
          ],
          isImage: isPhoto
        };
      }
    } catch (e) {
      logger.warn('[Instagram Carousel] Python extractor fallback failed:', e.message);
    }

    // 2. Fallback: Direct HTML / Embed scraping if Python is not installed or errored
    try {
      const shortcodeMatch = url.match(/(?:p|reel|tv)\/([a-zA-Z0-9_-]+)/);
      const shortcode = shortcodeMatch ? shortcodeMatch[1] : '';
      if (shortcode) {
        const embedUrl = `https://www.instagram.com/p/${shortcode}/embed/captioned/`;
        const { body } = await fetchHtml(embedUrl);
        const imgMat = body.match(/<img[^>]+class="[^"]*EmbeddedMediaImage[^"]*"[^>]+src="([^"]+)"/);
        const titleMat = body.match(/class="[^"]*Caption[^"]*"[^>]*>(.*?)<\/div>/s);
        const userMat = body.match(/class="[^"]*Username[^"]*"[^>]*>(.*?)<\/div>/s);
        const rawPhoto = imgMat ? imgMat[1].replace(/&amp;/g, '&') : '';
        const cap = titleMat ? titleMat[1].replace(/<[^>]+>/g, '').trim() : 'Instagram Post';
        const user = userMat ? userMat[1].replace(/<[^>]+>/g, '').trim() : 'Instagram';
        if (rawPhoto) {
          return {
            id: 'instagram_' + shortcode,
            url,
            title: cap,
            uploader: user,
            thumbnail: rawPhoto,
            duration: 0,
            formats: [{
              formatId: 'photo_embed',
              ext: 'jpg',
              resolution: 'Original Photo',
              url: rawPhoto,
              isImage: true
            }],
            isImage: true
          };
        }
      }
    } catch (embErr) {
      logger.warn('[Instagram Carousel] Embed fallback failed:', embErr.message);
    }

    throw new Error('Could not analyze Instagram carousel or photo post.');
  }

  async analyzeUrl(url, timeoutMs = 35000) {
    if (this.isPlaylistUrl(url)) {
      return await this.analyzePlaylist(url, timeoutMs);
    }
    if (this.isThreadsUrl(url)) {
      return await this.analyzeThreads(url, timeoutMs);
    }
    if (this.isSpotifyPlaylistUrl(url)) {
      return await this.analyzePlaylist(url, timeoutMs);
    }
    if (this.isSpotifyUrl(url)) {
      return await this.analyzeSpotify(url, timeoutMs);
    }
    if (this.isAppleMusicAlbumUrl(url)) {
      return await this.analyzePlaylist(url, timeoutMs);
    }
    if (this.isAppleMusicUrl(url)) {
      return await this.analyzeAppleMusic(url, timeoutMs);
    }
    if (this.isBehanceUrl(url)) {
      return await this.analyzeBehance(url, timeoutMs);
    }
    if (this.isDribbbleUrl(url)) {
      return await this.analyzeDribbble(url, timeoutMs);
    }
    if (this.isArtStationUrl(url)) {
      return await this.analyzeArtStation(url, timeoutMs);
    }
    if (this.isFiverrUrl(url)) {
      return await this.analyzeFiverr(url, timeoutMs);
    }
    if (this.isPinterestUrl(url)) {
      return await this.analyzePinterest(url, timeoutMs);
    }
    if (this.isCloudStorageUrl(url)) {
      return await this.analyzeCloudStorage(url, timeoutMs);
    }

    // Proactively check Instagram URLs for carousels / multi-slide posts
    if (url.includes('instagram.com/p/') || url.includes('instagram.com/reel/')) {
      try {
        const igResult = await this.analyzeInstagram(url, timeoutMs);
        if (igResult) return igResult;
      } catch (igErr) {
        logger.info(`Instagram custom handler deferred to yt-dlp: ${igErr.message}`);
      }
    }

    logger.info(`Analyzing URL with yt-dlp: ${url}`);
    const ytdlpPath = await dependencyManager.getYtDlpExecutablePath();
    const isMultiPost = url.includes('instagram.com') || url.includes('pinterest.com');
    const ytArgs = await youtubeTokenManager.getYtDlpExtractorArgs(url);
    const args = [
      '--dump-single-json',
      '--skip-download',
      '--no-warnings',
      ...(isMultiPost ? [] : ['--no-playlist']),
      '--no-check-certificates',
      '--match-filter', '!is_storyboard',
      ...ytArgs,
      '--add-header', 'User-Agent:Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
      url
    ];

    const localAppData = process.env.LOCALAPPDATA || (os.homedir ? path.join(os.homedir(), 'AppData', 'Local') : '');
    const cookiesFilePath = localAppData ? path.join(localAppData, 'MediaFetch', 'cookies.txt') : '';
    if (cookiesFilePath && fs.existsSync(cookiesFilePath) && fs.statSync(cookiesFilePath).size > 10) {
      args.push('--cookies', cookiesFilePath);
    } else {
      const cookiesBrowser = settingsManager.getSettings()?.engine?.cookiesBrowser || 'none';
      if (cookiesBrowser && cookiesBrowser !== 'none') {
        args.push('--cookies-from-browser', cookiesBrowser);
      }
    }

    try {
      const { stdout } = await execFileAsync(ytdlpPath, args, {
        windowsHide: true,
        timeout: timeoutMs,
        maxBuffer: 30 * 1024 * 1024
      });
      const raw = JSON.parse(stdout);
      return this.parseYtDlpOutput(url, raw);
    } catch (err) {
      // If yt-dlp failed because the Instagram post is a photo carousel with no video formats, fallback to Instagram handler
      if (url.includes('instagram.com') || (err && String(err).includes('No video formats found'))) {
        try {
          return await this.analyzeInstagram(url, timeoutMs);
        } catch (_) {}
      }
      logger.info(`yt-dlp could not extract media for ${url}, automatically switching to Universal Web Media Extractor...`);
      try {
        return await this.analyzeUniversalWebMedia(url, timeoutMs);
      } catch (fallbackErr) {
        logger.error('Both yt-dlp and Universal Web Media Extractor failed:', fallbackErr);
      }
      logger.error('Metadata analysis failed:', err);
      throw classifyError(err, 'Failed to analyze media URL');
    }
  }

  resolveAuthenticTitle(raw, url) {
    let candidate = '';
    const isYouTube = (raw.extractor_key && raw.extractor_key.toLowerCase().includes('youtube')) || 
                      (raw.extractor && raw.extractor.toLowerCase().includes('youtube')) ||
                      (url && (url.includes('youtube.com') || url.includes('youtu.be')));
    
    const rawTitle = (raw.title || '').trim();
    const isGenericTitle = !rawTitle || 
      /^video by /i.test(rawTitle) || 
      /^post by /i.test(rawTitle) || 
      /^tweet by /i.test(rawTitle) || 
      /^tiktok video by /i.test(rawTitle) || 
      /^threads post by /i.test(rawTitle) || 
      /^photo by /i.test(rawTitle) || 
      /^media by /i.test(rawTitle) ||
      rawTitle.toLowerCase() === 'media' ||
      rawTitle.toLowerCase() === 'instagram' ||
      rawTitle.toLowerCase() === 'threads' ||
      rawTitle.toLowerCase() === 'twitter' ||
      rawTitle.toLowerCase() === 'tiktok' ||
      rawTitle.toLowerCase() === 'facebook' ||
      rawTitle.toLowerCase().includes('log in') ||
      rawTitle.toLowerCase().includes('login');

    if ((!isYouTube || isGenericTitle) && raw.description) {
      const lines = raw.description.split(/[\r\n]+/);
      for (let line of lines) {
        line = line.replace(/https?:\/\/\S+/g, '').replace(/[#@]\S+/g, '').trim();
        line = line.replace(/^["'“”‘]+|["'“”‘]+$/g, '').trim();
        if (line.length >= 3) {
          candidate = line;
          break;
        }
      }
      if (!candidate) {
        for (const line of lines) {
          const trimmed = line.trim();
          if (trimmed.length >= 3 && !trimmed.startsWith('http')) {
            candidate = trimmed;
            break;
          }
        }
      }
    }

    if (candidate) {
      if (candidate.length > 120) candidate = candidate.substring(0, 117).trim() + '...';
      return candidate;
    }
    if (raw.fulltitle && !isGenericTitle) return raw.fulltitle.trim();
    if (rawTitle && !isGenericTitle) return rawTitle;
    if (rawTitle && /^video by /i.test(rawTitle)) {
      const stripped = rawTitle.replace(/^video by /i, '').trim();
      if (stripped) return `Instagram Clip (${stripped})`;
    }
    if (raw.uploader) return `Media by ${raw.uploader}`;
    return 'Media';
  }

  parseYtDlpOutput(url, raw) {
    const formats = (raw.formats || []).map((f) => {
      const isAudioOnly = f.vcodec === 'none' && f.acodec !== 'none';
      const isVideoOnly = f.vcodec !== 'none' && f.acodec === 'none';
      const hasAudioAndVideo = f.vcodec !== 'none' && f.acodec !== 'none';
      let qualityLabel = '';
      if (f.height) {
        qualityLabel = `${f.height}p`;
        if (f.fps && f.fps > 30) qualityLabel += `${f.fps}`;
      } else if (f.abr) {
        qualityLabel = `${Math.round(f.abr)}kbps audio`;
      } else {
        qualityLabel = f.format_note || f.ext;
      }

      return {
        formatId: f.format_id,
        ext: f.ext,
        resolution: f.resolution || (f.height ? `${f.width || '?'}x${f.height}` : undefined),
        height: f.height,
        width: f.width,
        vcodec: f.vcodec,
        acodec: f.acodec,
        filesize: f.filesize,
        filesizeApprox: f.filesize_approx,
        fps: f.fps,
        tbr: f.tbr,
        vbr: f.vbr,
        abr: f.abr,
        isAudioOnly,
        isVideoOnly,
        hasAudioAndVideo,
        qualityLabel,
        protocol: f.protocol
      };
    });

    const heights = formats
      .map((f) => f.height)
      .filter((h) => typeof h === 'number' && h > 0 && h <= 2160); // Cap at 4K (2160p) - exclude 8K completely
    const availableResolutions = [...new Set(heights)].sort((a, b) => b - a);

    const hasAudio = formats.some((f) => f.acodec && f.acodec !== 'none');
    const hasVideo = formats.some((f) => f.vcodec && f.vcodec !== 'none');

    const meta = {
      id: raw.id || 'media',
      url,
      title: this.resolveAuthenticTitle(raw, url),
      thumbnail: (() => {
        let best = raw.thumbnail;
        if (Array.isArray(raw.thumbnails) && raw.thumbnails.length > 0) {
          const sorted = [...raw.thumbnails].sort((a, b) => ((b.width || 0) * (b.height || 0)) - ((a.width || 0) * (a.height || 0)));
          if (sorted[0]?.url) best = sorted[0].url;
        }
        if (raw.id && (raw.extractor_key === 'Youtube' || url.includes('youtu'))) {
          best = `https://i.ytimg.com/vi/${raw.id}/maxresdefault.jpg`;
        }
        return best || raw.thumbnails?.[0]?.url;
      })(),
      duration: raw.duration,
      uploader: raw.uploader || raw.channel || raw.creator,
      channel: raw.channel,
      description: raw.description ? raw.description.substring(0, 300) : undefined,
      extractor: raw.extractor_key || raw.extractor,
      formats,
      availableResolutions,
      hasAudio,
      hasVideo,
      defaultProfile: {
        type: 'video',
        presetId: 'best-available',
        label: 'Best Available Quality (Universal H.264)',
        container: 'mp4',
        remuxToMp4: true
      }
    };

    if (raw._type === 'playlist' || (raw.entries && Array.isArray(raw.entries) && raw.entries.length > 1)) {
      const entries = Array.isArray(raw.entries) ? raw.entries : [];
      meta.isPlaylist = true;
      meta.isCarousel = true;
      meta.itemCount = entries.length;
      meta.items = entries.map((entry, idx) => {
        const isEntryVideo = (entry.vcodec && entry.vcodec !== 'none') || (entry.formats && entry.formats.some((f) => f.vcodec && f.vcodec !== 'none'));
        const entryThumb = entry.thumbnail || entry.thumbnails?.[0]?.url || meta.thumbnail;
        const entryUrl = entry.url || entry.webpage_url || url;
        const entryTitle = entry.title || `${meta.title} (Slide ${idx + 1})`;
        return {
          id: entry.id || `slide_${idx + 1}`,
          title: entryTitle,
          thumbnail: entryThumb,
          duration: entry.duration || 0,
          url: entryUrl,
          downloadQuery: entryUrl,
          uploader: entry.uploader || meta.uploader || '@Instagram',
          mediaType: isEntryVideo ? 'video' : 'image',
          subFolderName: ''
        };
      });
      meta.carouselSlides = meta.items.map((item, idx) => ({
        index: idx + 1,
        id: item.id,
        mediaType: item.mediaType,
        label: `Slide ${idx + 1} • ${item.mediaType === 'video' ? 'Video' : 'Photo'}`,
        url: item.url,
        thumbnail: item.thumbnail,
        duration: item.duration
      }));
    }

    return meta;
  }

  getAvailableProfiles(metadata) {
    const profiles = [];
    if (metadata.hasVideo) {
      profiles.push({
        type: 'video',
        presetId: 'best-available',
        label: 'Best Available Quality (Universal H.264)',
        container: 'mp4',
        remuxToMp4: true
      });
      if (metadata.availableResolutions.includes(2160)) {
        profiles.push({ type: 'video', presetId: 'video-4k', label: '4K Ultra HD (2160p) • Studio Quality (Slower • Large File)', resolution: 2160, container: 'mp4', remuxToMp4: true });
      }
      if (metadata.availableResolutions.includes(1440)) {
        profiles.push({ type: 'video', presetId: 'video-1440p', label: '1440p Quad HD (2K) • High Quality (Moderate Speed)', resolution: 1440, container: 'mp4', remuxToMp4: true });
      }
      if (metadata.availableResolutions.includes(1080) || metadata.availableResolutions.some(r => r >= 1080)) {
        profiles.push({ type: 'video', presetId: 'video-1080p', label: '1080p Full HD • Recommended (Fast & Balanced)', resolution: 1080, container: 'mp4', remuxToMp4: true });
      }
      if (metadata.availableResolutions.includes(720) || metadata.availableResolutions.some(r => r >= 720)) {
        profiles.push({ type: 'video', presetId: 'video-720p', label: '720p HD • High Speed (Light File)', resolution: 720, container: 'mp4', remuxToMp4: true });
      }
      profiles.push({
        type: 'video',
        presetId: 'video-prores',
        label: 'Apple ProRes 422 HQ (Broadcast Master)',
        container: 'mov'
      });
    }

    if (metadata.hasAudio) {
      profiles.push({
        type: 'audio',
        presetId: 'best-audio',
        label: 'Best Audio Quality (MP3 320kbps)',
        container: 'mp3'
      });
      profiles.push({
        type: 'audio',
        presetId: 'audio-wav',
        label: 'Lossless Studio Audio (WAV 48kHz)',
        container: 'wav'
      });
    }

    return profiles;
  }
}

export const metadataAnalyzer = new MetadataAnalyzer();