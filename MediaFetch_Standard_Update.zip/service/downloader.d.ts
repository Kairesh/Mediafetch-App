import { DownloadItem } from '../common/types.js';
export interface ProgressUpdate {
    progress: number;
    downloadedBytes: number;
    totalBytes: number;
    speed: string;
    eta: string;
    stageDescription?: string;
}
export declare class DownloadJob {
    private item;
    private childProcess?;
    private isPaused;
    private isCancelled;
    private lastProgressEmit;
    private throttleMs;
    private onProgressCb?;
    constructor(item: DownloadItem, onProgress?: (update: ProgressUpdate) => void);
    getItem(): DownloadItem;
    start(): Promise<{
        finalPath: string;
        fileSize: number;
    }>;
    pause(): void;
    cancel(): void;
    private killProcess;
    private parseStdout;
    private parseStderr;
    private emitThrottledProgress;
    private parseBytes;
    private getContainerExtension;
    private findStagingFile;
    private cleanupStagingFiles;
    private buildYtDlpArgs;
}
