export interface DependencyStatus {
    name: 'ytdlp' | 'ffmpeg' | 'ffprobe';
    available: boolean;
    version?: string;
    path?: string;
    error?: string;
}
export declare class DependencyManager {
    private binDir;
    private isUpdating;
    constructor();
    private ensureBinDirectory;
    getBinDir(): string;
    checkYtDlp(): Promise<DependencyStatus>;
    checkFfmpeg(): Promise<DependencyStatus>;
    checkFfprobe(): Promise<DependencyStatus>;
    getYtDlpExecutablePath(): Promise<string>;
    getFfmpegExecutablePath(): Promise<string | undefined>;
    installYtDlp(onProgress?: (stage: string, progress: number, message: string) => void): Promise<{
        success: boolean;
        version?: string;
        error?: string;
    }>;
    installFfmpeg(onProgress?: (stage: string, progress: number, message: string) => void): Promise<{
        success: boolean;
        version?: string;
        error?: string;
    }>;
    updateYtDlp(hasActiveDownloads: boolean, onProgress?: (stage: string, progress: number, message: string) => void): Promise<{
        success: boolean;
        version?: string;
        error?: string;
    }>;
}
export declare const dependencyManager: DependencyManager;
