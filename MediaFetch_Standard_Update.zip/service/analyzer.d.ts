import { MediaMetadata, DownloadProfile } from '../common/types.js';
export declare class MetadataAnalyzer {
    isValidUrl(urlStr: string): boolean;
    isPlaylistUrl(urlStr: string): boolean;
    analyzePlaylist(url: string, timeoutMs?: number): Promise<import('../common/types.js').PlaylistMetadata>;
    analyzeUrl(url: string, timeoutMs?: number): Promise<MediaMetadata>;
    /**
     * Parses raw yt-dlp output into structured MediaMetadata.
     */
    parseYtDlpOutput(url: string, raw: any): MediaMetadata;
    /**
     * Generates smart format profiles available for this specific media.
     */
    getAvailableProfiles(metadata: MediaMetadata): DownloadProfile[];
}
export declare const metadataAnalyzer: MetadataAnalyzer;
