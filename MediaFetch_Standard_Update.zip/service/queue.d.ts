import { DownloadItem, DownloadProfile, MediaMetadata, ProjectContext, HistoryEntry } from '../common/types.js';
export type QueueEventListener = (event: {
    type: 'QUEUE_UPDATED' | 'DOWNLOAD_PROGRESS' | 'DOWNLOAD_COMPLETED' | 'DOWNLOAD_FAILED';
    item?: DownloadItem;
    items?: DownloadItem[];
    historyEntry?: HistoryEntry;
}) => void;
export declare class QueueManager {
    private queuePath;
    private items;
    private activeJobs;
    private listeners;
    private isProcessing;
    constructor();
    subscribe(listener: QueueEventListener): () => void;
    private emit;
    getItems(): DownloadItem[];
    getActiveCount(): number;
    addItem(url: string, profile: DownloadProfile, projectContext?: ProjectContext, targetDirectory?: string, metadata?: Partial<MediaMetadata>): DownloadItem;
    pauseItem(id: string): void;
    resumeItem(id: string): void;
    cancelItem(id: string): void;
    retryItem(id: string): void;
    removeItem(id: string): void;
    clearCompleted(): void;
    clearAll(): void;
    resumeAllInterrupted(): void;
    processQueue(): Promise<void>;
    private startItemDownload;
    private load;
    private save;
}
export declare const queueManager: QueueManager;
