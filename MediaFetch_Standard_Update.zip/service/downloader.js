import { spawn, execFile, execFileSync } from 'child_process';
import { promisify } from 'util';
import path from 'path';
import fs from 'fs';
import os from 'os';
import https from 'https';
import http from 'http';
import { classifyError } from '../common/errors.js';
import { dependencyManager } from './dependencies.js';
import { filesystemManager } from './filesystem.js';
import { settingsManager } from './settings.js';
import { metadataAnalyzer } from './analyzer.js';
import { logger } from './logger.js';
import { youtubeTokenManager } from './youtubeToken.js';

const execFileAsync = promisify(execFile);

let cachedServiceEncoder = null;
function getOptimalEncoderArgs(ffmpegPath) {
  if (cachedServiceEncoder) return cachedServiceEncoder;
  const candidates = [
    { name: 'h264_nvenc', args: ['-c:v', 'h264_nvenc', '-preset', 'p4', '-cq', '18', '-b:v', '0', '-maxrate', '120M', '-bufsize', '120M', '-pix_fmt', 'yuv420p'] },
    { name: 'h264_qsv', args: ['-c:v', 'h264_qsv', '-preset', 'veryfast', '-global_quality', '18', '-pix_fmt', 'yuv420p'] },
    { name: 'h264_amf', args: ['-c:v', 'h264_amf', '-quality', 'quality', '-rc', 'cqp', '-qp_p', '18', '-qp_i', '18', '-pix_fmt', 'yuv420p'] }
  ];
  for (const c of candidates) {
    try {
      execFileSync(ffmpegPath, ['-f', 'lavfi', '-i', 'nullsrc=s=256x256:d=0.04', '-c:v', c.name, '-f', 'null', '-'], { windowsHide: true, timeout: 1500, stdio: 'pipe' });
      cachedServiceEncoder = c.args;
      return cachedServiceEncoder;
    } catch (_) {}
  }
  cachedServiceEncoder = [
    '-threads', '0',
    '-c:v', 'libx264',
    '-preset', 'ultrafast',
    '-crf', '18',
    '-pix_fmt', 'yuv420p'
  ];
  return cachedServiceEncoder;
}

function getAria2cExecutablePath() {
  const localAppData = process.env.LOCALAPPDATA || (os.homedir ? path.join(os.homedir(), 'AppData', 'Local') : '');
  const mfAria2c = localAppData ? path.join(localAppData, 'MediaFetch', 'bin', process.platform === 'win32' ? 'aria2c.exe' : 'aria2c') : '';
  if (mfAria2c && fs.existsSync(mfAria2c)) {
    return mfAria2c;
  }
  return null;
}

async function probeDurationSeconds(filePath, ffprobePath) {
  if (!ffprobePath || !fs.existsSync(ffprobePath) || !fs.existsSync(filePath)) {
    return null;
  }
  try {
    const { stdout } = await execFileAsync(ffprobePath, [
      '-v', 'error',
      '-show_entries', 'format=duration',
      '-of', 'default=noprint_wrappers=1:nokey=1',
      filePath
    ], { windowsHide: true, timeout: 10000 });
    const dur = parseFloat((stdout || '').trim());
    return (!isNaN(dur) && dur > 0) ? dur : null;
  } catch (err) {
    logger.warn('[DownloadJob] probeDuration notice:', err?.message || err);
    return null;
  }
}

export class DownloadJob {
  constructor(item, onProgress) {
    this.item = item;
    this.childProcess = undefined;
    this.activeHttpRequest = undefined;
    this.isPaused = false;
    this.isCancelled = false;
    this.lastProgressEmit = 0;
    this.throttleMs = 250;
    this.onProgressCb = onProgress;
    this.streamIndex = 0;
    this.completedStreamsBytes = 0;
    this.completedStreamsTotal = 0;
    this.currentStreamDownloaded = 0;
    this.currentStreamTotal = 0;
    this.lastStreamTotal = 0;
  }

  getItem() {
    return this.item;
  }

  async start() {
    let ytdlpPath = await dependencyManager.getYtDlpExecutablePath();
    let ffmpegPath = await dependencyManager.getFfmpegExecutablePath();
    let ffprobePath = await dependencyManager.getFfprobeExecutablePath();
    const binDir = dependencyManager.getBinDir();

    // Auto-heal missing engine binaries before download begins
    if (!fs.existsSync(ytdlpPath)) {
      this.emitThrottledProgress({
        progress: 2,
        downloadedBytes: 0,
        totalBytes: 0,
        speed: '',
        eta: '',
        stageDescription: 'Auto-installing media engine (first run)...'
      });
      await dependencyManager.installYtDlp((stage, pct, msg) => {
        this.emitThrottledProgress({
          progress: Math.min(10, Math.round(pct * 0.1)),
          downloadedBytes: 0,
          totalBytes: 0,
          speed: '',
          eta: '',
          stageDescription: msg || 'Configuring media engine...'
        });
      });
      ytdlpPath = await dependencyManager.getYtDlpExecutablePath();
    }

    if (!fs.existsSync(ffmpegPath)) {
      this.emitThrottledProgress({
        progress: 10,
        downloadedBytes: 0,
        totalBytes: 0,
        speed: '',
        eta: '',
        stageDescription: 'Auto-installing FFmpeg merger (first run)...'
      });
      await dependencyManager.installFfmpeg((stage, pct, msg) => {
        this.emitThrottledProgress({
          progress: Math.min(20, 10 + Math.round(pct * 0.1)),
          downloadedBytes: 0,
          totalBytes: 0,
          speed: '',
          eta: '',
          stageDescription: msg || 'Configuring FFmpeg...'
        });
      });
      ffmpegPath = await dependencyManager.getFfmpegExecutablePath();
      ffprobePath = await dependencyManager.getFfprobeExecutablePath();
    }

    // Check if custom location setting is active
    const currentSettings = settingsManager.getSettings();
    let targetDir = this.item.targetFolder;
    if (!targetDir) {
      const isCustomModeActive = currentSettings?.downloads?.downloadLocationMode === 'custom' || currentSettings?.downloads?.downloadLocationMode === 'custom_flat';
      if (isCustomModeActive && currentSettings?.downloads?.customLocation?.trim()) {
        targetDir = path.resolve(currentSettings.downloads.customLocation.trim());
      } else {
        targetDir = this.item.projectFolder || filesystemManager.resolveTargetDirectory(this.item.projectContext).targetDir;
      }
    }
    const stagingDir = path.join(targetDir, '.temp_mediafetch');
    filesystemManager.ensureDirExists(stagingDir);

    // 1. Pre-Analysis to resolve genuine title, Spotify / Apple Music pair query, Threads or Pinterest direct media stream
    const isSpotify = (this.item.url.includes('spotify.com') || this.item.url.includes('spotify.link'));
    const isAppleMusic = (this.item.url.includes('music.apple.com') || this.item.url.includes('itunes.apple.com'));
    const isThreads = (this.item.url.includes('threads.net') || this.item.url.includes('threads.com'));
    const isPinterest = (this.item.url.includes('pinterest.') || this.item.url.includes('pin.it') || this.item.url.includes('pinimg.com') || this.item.metadata?.platform === 'pinterest' || this.item.metadata?.extractor === 'pinterest');
    const isInstagram = this.item.url.includes('instagram.com');
    const isBehance = /behance\.(?:net|com)/i.test(this.item.url);
    const isDribbble = /dribbble\.com/i.test(this.item.url);
    const isFiverr = /fiverr\.com/i.test(this.item.url);
    const isArtStation = /artstation\.com/i.test(this.item.url);
    const isTikTok = this.item.metadata?.platform === 'tiktok' || /tiktok\.com|tiktokcdn|vm\.tiktok\.com|vt\.tiktok\.com/i.test(this.item.url);
    const isTwitter = /twitter\.com|x\.com/i.test(this.item.url);
    const isFacebook = /facebook\.com|fb\.watch/i.test(this.item.url);

    // CRITICAL: Guard against stale metadata from previous downloads!
    // NEVER wipe metadata if item is part of a playlist or zip batch!
    const isPlaylistOrBatch = Boolean(this.item.metadata?.isPlaylist || this.item.metadata?.batchId || this.item.metadata?.zipPackage);
    if (!isSpotify && !isAppleMusic && !isPlaylistOrBatch && this.item.metadata && this.item.metadata.url && this.item.metadata.url !== this.item.url && this.item.metadata.webpage_url !== this.item.url) {
      logger.info(`[DownloadJob] Discarding stale metadata for item ${this.item.id} (URL mismatch: ${this.item.metadata.url} vs ${this.item.url})`);
      this.item.metadata = {};
      this.item.title = '';
    }

    if (isPinterest && this.item.url.includes('pin.it')) {
      try {
        const expanded = await metadataAnalyzer.expandPinterestUrl(this.item.url);
        if (expanded && !expanded.includes('pin.it')) {
          this.item.url = expanded;
        }
      } catch (e) {}
    }

    const isGenericTitle = !this.item.title || 
      this.item.title === 'Fetching media info...' || 
      /^video by /i.test(this.item.title) || 
      /^post by /i.test(this.item.title) || 
      /^tweet by /i.test(this.item.title) || 
      this.item.title.toLowerCase() === 'media' ||
      /^media[\._]/i.test(this.item.title);

    // Mandatory pre-analysis if title is generic (e.g. downloaded directly without Analyze)
    // or for platforms that require URL expansion / search queries
    const needsMandatoryPreAnalysis = 
                                     ((isSpotify || isAppleMusic) && (!this.item.metadata?.downloadQuery || isGenericTitle)) || 
                                     (isInstagram && !this.item.metadata?.directStreamUrl && !this.item.metadata?.downloadTarget) ||
                                     (isThreads && !this.item.metadata?.directStreamUrl) ||
                                     (isPinterest && (!this.item.metadata?.directStreamUrl || isGenericTitle) && !this.item.url.includes('pinimg.com')) ||
                                     (isBehance && !this.item.metadata?.downloadTarget && !this.item.metadata?.directStreamUrl) ||
                                     (isDribbble && !this.item.metadata?.directStreamUrl && !this.item.metadata?.downloadTarget) ||
                                     (isFiverr && !this.item.metadata?.directStreamUrl && !this.item.metadata?.downloadTarget) ||
                                     (isArtStation && !this.item.metadata?.directStreamUrl && !this.item.metadata?.downloadTarget) ||
                                     ((isTwitter || isFacebook) && (!this.item.metadata?.directStreamUrl && !this.item.metadata?.downloadTarget || isGenericTitle)) ||
                                     (isTikTok && !this.item.metadata?.directStreamUrl && !this.item.metadata?.downloadTarget);

    if (needsMandatoryPreAnalysis) {
      try {
        logger.info(`[DownloadJob] Running pre-download metadata analysis for item ${this.item.id}: ${this.item.url}`);
        this.emitThrottledProgress({
          progress: 5,
          downloadedBytes: 0,
          totalBytes: 0,
          speed: '',
          eta: '',
          stageDescription: 'Analyzing media information...'
        });
        const freshMeta = await Promise.race([
          metadataAnalyzer.analyzeUrl(this.item.url, 12000),
          new Promise((_, reject) => setTimeout(() => reject(new Error('Pre-analysis timeout')), 12000))
        ]);
        if (freshMeta) {
          this.item.metadata = { ...(this.item.metadata || {}), ...freshMeta };
          if (freshMeta.title && !/^video by /i.test(freshMeta.title) && freshMeta.title.toLowerCase() !== 'media') {
            this.item.title = freshMeta.title;
          }
          if (freshMeta.thumbnail && !this.item.thumbnail) {
            this.item.thumbnail = freshMeta.thumbnail;
          }
          if (freshMeta.duration && !this.item.duration) {
            this.item.duration = freshMeta.duration;
          }
          this.emitThrottledProgress({
            progress: 8,
            stageDescription: `Found: ${this.item.title || 'media'}`
          });
        }
      } catch (metaErr) {
        logger.warn(`[DownloadJob] Pre-download metadata analysis notice for ${this.item.url}:`, metaErr.message);
        if ((isSpotify || isAppleMusic) && !this.item.metadata?.downloadQuery && isGenericTitle) {
          throw metaErr;
        }
      }
    }

    // 2. Resolve effective download target
    let downloadTarget = this.item.metadata?.downloadQuery || this.item.metadata?.downloadTarget || this.item.metadata?.directStreamUrl || this.item.url;
    const isYouTube = Boolean(
      (typeof this.item.url === 'string' && (this.item.url.includes('youtube.com') || this.item.url.includes('youtu.be'))) ||
      (typeof downloadTarget === 'string' && (downloadTarget.includes('youtube.com') || downloadTarget.includes('youtu.be') || downloadTarget.includes('googlevideo.com'))) ||
      (this.item.metadata?.extractor && String(this.item.metadata.extractor).toLowerCase().includes('youtube'))
    );
    if (isYouTube) {
      downloadTarget = this.item.url || this.item.metadata?.webpage_url || (downloadTarget.includes('googlevideo.com') ? this.item.url : downloadTarget);
    }
    if (isSpotify || isAppleMusic) {
      if (this.item.metadata?.downloadQuery) {
        downloadTarget = this.item.metadata.downloadQuery;
      } else {
        const qTitle = (!isGenericTitle && this.item.title) ? this.item.title : (this.item.metadata?.title || 'song');
        const qArtist = this.item.metadata?.uploader || this.item.metadata?.channel || '';
        downloadTarget = `ytsearch1:${qTitle} ${qArtist} audio`.trim();
      }
    } else if (isThreads && this.item.metadata?.directStreamUrl) {
      downloadTarget = this.item.metadata.directStreamUrl;
    } else if (isPinterest) {
      if (this.item.profile?.type === 'image' && (this.item.metadata?.directImageUrl || this.item.metadata?.thumbnail || this.item.metadata?.directStreamUrl)) {
        downloadTarget = this.item.metadata.directImageUrl || this.item.metadata.thumbnail || this.item.metadata.directStreamUrl;
      } else if (this.item.metadata?.directVideoUrl) {
        downloadTarget = this.item.metadata.directVideoUrl;
      } else if (this.item.metadata?.directStreamUrl) {
        downloadTarget = this.item.metadata.directStreamUrl;
      }
    } else if (isBehance && (this.item.metadata?.downloadTarget || this.item.metadata?.directStreamUrl || this.item.metadata?.items?.[0]?.downloadTarget)) {
      downloadTarget = this.item.metadata.downloadTarget || this.item.metadata.directStreamUrl || (this.item.metadata.items && this.item.metadata.items[0]?.downloadTarget) || (this.item.metadata.items && this.item.metadata.items[0]?.url) || this.item.url;
    } else if (isDribbble && (this.item.metadata?.directStreamUrl || this.item.metadata?.downloadTarget)) {
      downloadTarget = this.item.metadata.directStreamUrl || this.item.metadata.downloadTarget;
    } else if (isFiverr && (this.item.metadata?.directStreamUrl || this.item.metadata?.downloadTarget)) {
      downloadTarget = this.item.metadata.directStreamUrl || this.item.metadata.downloadTarget;
    } else if (isArtStation && (this.item.metadata?.directStreamUrl || this.item.metadata?.downloadTarget)) {
      downloadTarget = this.item.metadata.directStreamUrl || this.item.metadata.downloadTarget;
    } else if (isTikTok) {
      if (this.item.profile?.type === 'audio' && (this.item.metadata?.directAudioUrl || this.item.metadata?.formats?.find(f => f.isAudioOnly)?.url)) {
        downloadTarget = this.item.metadata.directAudioUrl || this.item.metadata.formats.find(f => f.isAudioOnly).url;
      } else if (this.item.profile?.type === 'image' && (this.item.metadata?.thumbnail || this.item.metadata?.directStreamUrl)) {
        downloadTarget = this.item.metadata.thumbnail || this.item.metadata.directStreamUrl;
      } else {
        const reqQuality = String(this.item.profile?.quality || this.item.profile?.resolution || '');
        const matchingFmt = Array.isArray(this.item.metadata?.formats) && this.item.metadata.formats.find(f => 
          (reqQuality && (f.quality === reqQuality || f.resolution?.includes(reqQuality))) ||
          (reqQuality === '720' && f.formatId === 'tiktok_sd_nowm') ||
          (reqQuality === '1080' && f.formatId === 'tiktok_hd_nowm')
        );
        downloadTarget = matchingFmt?.url || this.item.metadata?.directStreamUrl || this.item.metadata?.downloadTarget || downloadTarget;
      }

      // Safety Guard: if downloadTarget is still a raw tiktok.com web URL, analyze it to extract direct CDN stream
      if (typeof downloadTarget === 'string' && (downloadTarget.includes('tiktok.com/') || downloadTarget.includes('vm.tiktok.com') || downloadTarget.includes('vt.tiktok.com')) && !downloadTarget.includes('tiktokcdn')) {
        try {
          logger.info(`[DownloadJob] Resolving raw TikTok web URL into direct CDN stream: ${downloadTarget}`);
          const resolvedMeta = await metadataAnalyzer.analyzeTikTok(downloadTarget);
          if (resolvedMeta) {
            this.item.metadata = { ...(this.item.metadata || {}), ...resolvedMeta };
            if (this.item.profile?.type === 'audio' && resolvedMeta.directAudioUrl) {
              downloadTarget = resolvedMeta.directAudioUrl;
            } else if (this.item.profile?.type === 'image' && (resolvedMeta.thumbnail || resolvedMeta.directStreamUrl)) {
              downloadTarget = resolvedMeta.thumbnail || resolvedMeta.directStreamUrl;
            } else {
              const reqQ = String(this.item.profile?.quality || this.item.profile?.resolution || '');
              const fmt = resolvedMeta.formats?.find(f => reqQ && (f.quality === reqQ || f.resolution?.includes(reqQ)));
              downloadTarget = fmt?.url || resolvedMeta.directStreamUrl || resolvedMeta.downloadTarget || downloadTarget;
            }
          }
        } catch (resErr) {
          logger.warn('[DownloadJob] Failed to resolve raw TikTok web URL:', resErr.message);
        }
      }
    }

    const isUpcoming = Boolean(this.item.metadata?.isUpcoming || this.item.metadata?.liveStatus === 'is_upcoming');
    if (isUpcoming) {
      if (!this.item.profile) this.item.profile = {};
      this.item.profile.type = 'image';
      downloadTarget = this.item.metadata?.thumbnail || this.item.metadata?.directStreamUrl || downloadTarget;
    }

    // Direct image download support (e.g. Google Drive image files, Threads, Instagram, Pinterest photos, X/Twitter, Facebook, or Video Cover / Thumbnail)
    const isImageFile = Boolean(
      isUpcoming ||
      this.item.profile?.type === 'image' ||
      this.item.metadata?.mediaType === 'image' ||
      this.item.metadata?.isImage ||
      (typeof this.item.title === 'string' && /\.(jpg|jpeg|png|webp|gif|bmp|svg|tiff)($|\?)/i.test(this.item.title)) ||
      (typeof downloadTarget === 'string' && downloadTarget.startsWith('http') && (
        /\.(jpg|jpeg|png|webp|gif|bmp|svg|tiff)($|\?)/i.test(downloadTarget) ||
        downloadTarget.includes('twimg.com') ||
        /[?&]format=(jpg|jpeg|png|webp)/i.test(downloadTarget)
      ))
    );

    if (isImageFile) {
      let imgTarget = downloadTarget;
      const allUrls = `${this.item.url} ${downloadTarget}`;
      const ytM = allUrls.match(/(?:v=|shorts\/|youtu\.be\/|embed\/)([a-zA-Z0-9_-]{11})/);

      if (typeof downloadTarget === 'string' && downloadTarget.includes('twimg.com')) {
        imgTarget = downloadTarget.replace(/name=[a-z0-9]+/i, 'name=orig').replace(/format=webp/i, 'format=jpg');
      } else if (isUpcoming) {
        imgTarget = this.item.metadata?.thumbnail || this.item.metadata?.directStreamUrl || (ytM && ytM[1] ? `https://i.ytimg.com/vi/${ytM[1]}/maxresdefault.jpg` : downloadTarget);
      } else if (this.item.profile?.type === 'image' && ytM && ytM[1] && !this.item.metadata?.mediaType) {
        let candidateImg = this.item.thumbnail || this.item.metadata?.thumbnail;
        if (candidateImg) {
          imgTarget = candidateImg;
        } else {
          imgTarget = `https://i.ytimg.com/vi/${ytM[1]}/maxresdefault.jpg`;
        }
      }

      logger.info(`[DownloadJob] Direct image download for item ${this.item.id}: ${imgTarget}`);
      let ext = 'jpg';
      const titleExtMatch = (this.item.title || '').match(/\.(jpg|jpeg|png|webp|gif|bmp|svg|tiff)($|\?)/i);
      const urlExtMatch = (typeof downloadTarget === 'string') ? downloadTarget.match(/\.(jpg|jpeg|png|webp|gif|bmp|svg|tiff)($|\?)/i) : null;
      const formatParamMatch = (typeof downloadTarget === 'string') ? downloadTarget.match(/[?&]format=(jpg|jpeg|png|webp|gif)/i) : null;
      if (titleExtMatch) {
        ext = titleExtMatch[1].toLowerCase();
      } else if (urlExtMatch) {
        ext = urlExtMatch[1].toLowerCase();
      } else if (formatParamMatch) {
        ext = formatParamMatch[1].toLowerCase() === 'webp' ? 'jpg' : formatParamMatch[1].toLowerCase();
      } else if (this.item.profile?.container && ['jpg', 'jpeg', 'png', 'webp', 'gif', 'bmp', 'svg'].includes(this.item.profile.container.toLowerCase())) {
        ext = this.item.profile.container.toLowerCase();
      }

      let cleanCandidate = this.item.title || 'image';
      if (titleExtMatch) {
        cleanCandidate = cleanCandidate.replace(/\.(jpg|jpeg|png|webp|gif|bmp|svg|tiff)($|\?)/i, '');
      }
      const cleanTitle = filesystemManager.sanitizeFilename(cleanCandidate).substring(0, 100);
      const finalName = `${cleanTitle}.${ext}`;
      const tempImgPath = path.join(stagingDir, `${this.item.id}__MF__${cleanTitle}.${ext}`);

      const fallbacks = [];
      if (ytM && ytM[1]) {
        fallbacks.push(`https://i.ytimg.com/vi/${ytM[1]}/hq720.jpg`);
        fallbacks.push(`https://i.ytimg.com/vi/${ytM[1]}/hqdefault.jpg`);
      }

      this.emitThrottledProgress({
        progress: 10,
        downloadedBytes: 0,
        totalBytes: 0,
        speed: '',
        eta: '',
        stageDescription: 'Downloading image file...'
      });

      try {
        await this.downloadDirectStream(imgTarget, tempImgPath);
      } catch (streamErr) {
        let downloadedOk = false;
        for (const fb of fallbacks) {
          try {
            await this.downloadDirectStream(fb, tempImgPath);
            downloadedOk = true;
            break;
          } catch (_) {}
        }
        if (!downloadedOk) {
          throw streamErr;
        }
      }

      const effectiveTargetDir = this.resolveFinalTargetDir(targetDir, ext, 'image');
      const finalized = filesystemManager.finalizeDownloadedFile(tempImgPath, effectiveTargetDir, finalName);
      this.item.downloadedPath = finalized.finalPath;
      return finalized;
    }

    // Direct archive download support (e.g. zip, rar, 7z from cloud storage or direct link)
    const isDirectArchive = this.item.profile?.type === 'archive' ||
      (typeof downloadTarget === 'string' && downloadTarget.startsWith('http') && downloadTarget.match(/\.(zip|rar|7z|tar|gz)($|\?)/i));
    if (isDirectArchive) {
      logger.info(`[DownloadJob] Direct archive download for item ${this.item.id}: ${downloadTarget}`);
      const cleanCandidate = (!isGenericTitle && this.item.title) ? this.item.title : (this.item.metadata?.title || 'cloud_archive');
      const cleanTitle = filesystemManager.sanitizeFilename(cleanCandidate).substring(0, 80);
      const extMatch = downloadTarget.match(/\.(zip|rar|7z|tar|gz)($|\?)/i);
      const ext = extMatch ? extMatch[1].toLowerCase() : 'zip';
      const tempArchiveFile = path.join(stagingDir, `${this.item.id}__MF__${cleanTitle}.${ext}`);

      await this.downloadDirectStream(downloadTarget, tempArchiveFile);
      const effectiveTargetDir = targetDir;
      const finalized = filesystemManager.finalizeDownloadedFile(tempArchiveFile, effectiveTargetDir, `${cleanTitle}.${ext}`);
      this.item.downloadedPath = finalized.finalPath;
      return finalized;
    }

    // Direct video stream download (e.g. Threads video extracted directly with authentication tokens or raw MP4 CDN URLs)
    // CRITICAL: NEVER treat Spotify, YouTube as direct video streams!
    const isDirectVideoStream = !isSpotify && !isYouTube &&
      this.item.profile?.type !== 'audio' &&
      this.item.profile?.type !== 'image' &&
      (this.item.profile?.type === 'video' || this.item.profile?.type === 'video-only' || this.item.metadata?.mediaType === 'video' || this.item.metadata?.hasVideo) &&
      !String(downloadTarget).includes('.m3u8') &&
      Boolean(
        (this.item.metadata?.directStreamUrl && !this.item.metadata.directStreamUrl.includes('youtube.com') && !this.item.metadata.directStreamUrl.includes('youtu.be') && !this.item.metadata.directStreamUrl.includes('googlevideo.com') && !this.item.metadata.directStreamUrl.includes('tiktok.com/')) || 
        (typeof downloadTarget === 'string' && downloadTarget.startsWith('http') && 
         !downloadTarget.includes('tiktok.com/') &&
         (downloadTarget.includes('fbcdn.net') || downloadTarget.includes('cdninstagram.com') || downloadTarget.includes('twimg.com') || downloadTarget.includes('licdn.com') || downloadTarget.includes('tiktokcdn') || downloadTarget.includes('tikwm') || downloadTarget.includes('tikmate') || downloadTarget.includes('drive.google.com') || downloadTarget.includes('drive.usercontent.google.com') || (downloadTarget.match(/\.(mp4|mov|mkv|webm|avi|m4v)($|\?)/i) && !downloadTarget.includes('googlevideo.com') && !downloadTarget.includes('youtube.com') && !downloadTarget.includes('youtu.be'))))
      );

    if (isDirectVideoStream) {
      logger.info(`[DownloadJob] Direct video stream download for item ${this.item.id}: ${downloadTarget}`);
      const cleanCandidate = (!isGenericTitle && this.item.title) ? this.item.title : (this.item.metadata?.title || 'video_stream');
      const cleanTitle = filesystemManager.sanitizeFilename(cleanCandidate).substring(0, 80);
      const rawExtMatch = (typeof downloadTarget === 'string') ? (this.item.title || downloadTarget).match(/\.(mp4|mov|mkv|webm|avi|m4v)($|\?)/i) : null;
      const streamExt = rawExtMatch ? rawExtMatch[1].toLowerCase() : 'mp4';
      const tempStreamFile = path.join(stagingDir, `${this.item.id}__MF__${cleanTitle}.${streamExt}`);

      await this.downloadDirectStream(downloadTarget, tempStreamFile);
      return await this.processAndFinalizeDownloadedFile(tempStreamFile, stagingDir, targetDir, ffmpegPath, ffprobePath, binDir, cleanTitle);
    }

    const isDirectAudioStream = !isSpotify && !isYouTube &&
      this.item.profile?.type === 'audio' &&
      Boolean(
        typeof downloadTarget === 'string' && downloadTarget.startsWith('http') &&
        (downloadTarget.includes('tiktokcdn') || downloadTarget.includes('tikwm') || (isTikTok && this.item.profile?.type === 'audio') || downloadTarget.includes('drive.google.com') || downloadTarget.includes('drive.usercontent.google.com') || (downloadTarget.match(/\.(mp3|wav|m4a|aac|flac|ogg|mp4|mov|mkv|webm|avi|m4v)($|\?)/i) && !downloadTarget.includes('googlevideo.com') && !downloadTarget.includes('youtube.com') && !downloadTarget.includes('youtu.be')))
      );

    if (isDirectAudioStream) {
      logger.info(`[DownloadJob] Direct audio stream download for item ${this.item.id}: ${downloadTarget}`);
      const cleanCandidate = (!isGenericTitle && this.item.title) ? this.item.title : (this.item.metadata?.title || 'audio_stream');
      const cleanTitle = filesystemManager.sanitizeFilename(cleanCandidate).substring(0, 80);
      const rawExtMatch = (typeof downloadTarget === 'string') ? (this.item.title || downloadTarget).match(/\.(mp3|wav|m4a|aac|flac|ogg|mp4|mov)($|\?)/i) : null;
      const streamExt = rawExtMatch ? rawExtMatch[1].toLowerCase() : (this.item.metadata?.mediaType === 'video' ? 'mp4' : 'mp3');
      const tempStreamFile = path.join(stagingDir, `${this.item.id}__MF__${cleanTitle}.${streamExt}`);

      await this.downloadDirectStream(downloadTarget, tempStreamFile);
      return await this.processAndFinalizeDownloadedFile(tempStreamFile, stagingDir, targetDir, ffmpegPath, ffprobePath, binDir, cleanTitle);
    }

    // Safe staging template that preserves authentic video title and never hardcodes 'Media' or 'Video by <username>'
    const hasValidTitle = !isGenericTitle && this.item.title && this.item.title !== 'Fetching media info...';
    const cleanTitleCandidate = hasValidTitle
      ? this.item.title
      : (this.item.metadata?.title && !/^video by /i.test(this.item.metadata.title) && this.item.metadata.title.toLowerCase() !== 'media' && !/^media[\._]/i.test(this.item.metadata.title) ? this.item.metadata.title : '');
    const safeTitlePart = cleanTitleCandidate ? filesystemManager.sanitizeFilename(cleanTitleCandidate).substring(0, 80) : '';
    const stagingTemplate = safeTitlePart 
      ? path.join(stagingDir, `${this.item.id}__MF__${safeTitlePart}.%(ext)s`)
      : path.join(stagingDir, `${this.item.id}__MF__%(title).80s.%(ext)s`);
    const ffmpegLocation = ffmpegPath ? path.dirname(ffmpegPath) : undefined;

    // Search targets (with automatic fallback queries for Spotify and playlist items)
    const searchTargets = [downloadTarget];

    // If downloadTarget is a non-YouTube URL with an embedded YouTube video ID, add direct search by video ID as fallback
    const ytMatch = downloadTarget.match(/(?:v=|\/shorts\/|\/embed\/|youtu\.be\/|\/v\/|\/e\/)([\w-]{11})/);
    if (ytMatch && ytMatch[1] && !downloadTarget.includes('youtube.com') && !downloadTarget.includes('youtu.be')) {
      const vidSearch = `ytsearch1:${ytMatch[1]}`;
      if (!searchTargets.includes(vidSearch)) {
        searchTargets.push(vidSearch);
      }
    }

    const rawCandidateTitle = (!isGenericTitle && this.item.title) ? this.item.title : (this.item.metadata?.title || '');
    const cleanT = rawCandidateTitle
      .replace(/\s*[-â€“]\s*.*$/, '')
      .replace(/[\\/:*?"<>|]/g, '')
      .replace(/\s+/g, ' ')
      .trim();
    const candidateArtist = this.item.metadata?.uploader || this.item.metadata?.channel || '';

    if (cleanT && cleanT.length > 2 && (isSpotify || this.item.isPlaylist || this.item.metadata?.isPlaylist || this.item.batchId || this.item.metadata?.batchId)) {
      // Primary artist (strip featuring, commas, collab artists)
      const primaryArtist = candidateArtist.split(/[,;&/]|feat\.?|ft\.?/i)[0].trim();
      
      // Stripped title (remove parentheses, brackets like "(Pokemon Legends: Z-A but it's Lo-fi)")
      const strippedTitle = cleanT.replace(/\s*[\(\[][^\)\]]*[\)\]]/g, '').trim();

      // Cleaned characters (remove non-ASCII or corrupt accents)
      const asciiTitle = cleanT.normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/[^\x20-\x7E]/g, ' ').replace(/\s+/g, ' ').trim();
      const asciiPrimary = primaryArtist.normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/[^\x20-\x7E]/g, ' ').replace(/\s+/g, ' ').trim();

      if (asciiPrimary) {
        const alt1 = `ytsearch1:${asciiTitle} ${asciiPrimary}`.trim();
        if (!searchTargets.includes(alt1)) searchTargets.push(alt1);
      }
      if (strippedTitle && strippedTitle.length > 2 && asciiPrimary) {
        const altStr = `ytsearch1:${strippedTitle} ${asciiPrimary}`.trim();
        if (!searchTargets.includes(altStr)) searchTargets.push(altStr);
      }
      if (candidateArtist && candidateArtist !== primaryArtist) {
        const alt2 = `ytsearch1:${asciiTitle} ${candidateArtist}`.trim();
        if (!searchTargets.includes(alt2)) searchTargets.push(alt2);
      }
      const alt3 = `ytsearch1:${asciiTitle} audio`.trim();
      if (!searchTargets.includes(alt3)) searchTargets.push(alt3);
      const alt4 = `ytsearch1:${asciiTitle}`.trim();
      if (!searchTargets.includes(alt4)) searchTargets.push(alt4);
      if (strippedTitle && strippedTitle.length > 2) {
        const alt5 = `ytsearch1:${strippedTitle}`.trim();
        if (!searchTargets.includes(alt5)) searchTargets.push(alt5);
      }
    }

    if (youtubeTokenManager.isYouTubeUrl(downloadTarget) || (this.item.url && youtubeTokenManager.isYouTubeUrl(this.item.url))) {
      await youtubeTokenManager.getVisitorData().catch(() => {});
    }

    return new Promise((resolve, reject) => {
      const executeDownload = (targetIndex = 0) => {
        filesystemManager.ensureDirExists(stagingDir);
        if (this.isCancelled) {
          this.cleanupStagingFiles(stagingDir, this.item.id);
          return reject({ isCancelled: true });
        }
        if (this.isPaused) {
          return reject({ isPaused: true });
        }

        const currentTarget = searchTargets[targetIndex];
        const args = this.buildYtDlpArgs(currentTarget, this.item.profile, stagingTemplate, ffmpegLocation);

        logger.info(`[DownloadJob] Starting download for item ${this.item.id}: ${currentTarget}`);
        logger.debug('[DownloadJob] yt-dlp args:', args);

        let stdoutBuf = '';
        let stderrBuf = '';
        let watchdogTimer;

        try {
          this.childProcess = spawn(ytdlpPath, args, {
            windowsHide: true,
            stdio: ['ignore', 'pipe', 'pipe']
          });
          try {
            if (this.childProcess.pid && typeof os.setPriority === 'function') {
              os.setPriority(this.childProcess.pid, os.constants.priority.PRIORITY_BELOW_NORMAL);
            }
          } catch (_) {}

          // Inactivity watchdog: only triggers if process stalls completely with NO data for 300s
          const resetWatchdog = () => {
            if (watchdogTimer) clearTimeout(watchdogTimer);
            watchdogTimer = setTimeout(() => {
              logger.warn(`[DownloadJob] Inactivity watchdog timeout (300s) for item ${this.item.id} on query "${currentTarget}". Terminating stalled process...`);
              if (this.childProcess) {
                const pid = this.childProcess.pid;
                if (process.platform === 'win32' && pid) {
                  try {
                    const { exec } = require('child_process');
                    exec(`taskkill /pid ${pid} /T /F`, { windowsHide: true }, () => {});
                  } catch (_) {
                    try { this.childProcess.kill('SIGKILL'); } catch (_) {}
                  }
                } else {
                  try { this.childProcess.kill('SIGKILL'); } catch (_) {}
                }
              }
            }, 300000);
          };
          resetWatchdog();

          const initialStage = (this.item.profile?.timeRange && (this.item.profile.timeRange.start || this.item.profile.timeRange.end))
            ? `Preparing clip (${this.item.profile.timeRange.start || '00:00:00'} - ${this.item.profile.timeRange.end || 'end'}) - Seeking stream...`
            : 'Connecting to media server...';

          this.emitThrottledProgress({
            progress: 1,
            downloadedBytes: 0,
            totalBytes: 0,
            speed: '',
            eta: '',
            stageDescription: initialStage
          });
        } catch (err) {
          if (watchdogTimer) clearTimeout(watchdogTimer);
          return reject(classifyError(err, 'Failed to launch yt-dlp'));
        }

        this.childProcess.stdout?.on('data', (chunk) => {
          if (typeof resetWatchdog === 'function') resetWatchdog();
          const text = chunk.toString('utf-8');
          stdoutBuf += text;
          this.parseStdout(text);
        });

        this.childProcess.stderr?.on('data', (chunk) => {
          if (typeof resetWatchdog === 'function') resetWatchdog();
          const text = chunk.toString('utf-8');
          stderrBuf += text;
          this.parseStderr(text);
        });

        this.childProcess.on('error', (err) => {
          if (watchdogTimer) clearTimeout(watchdogTimer);
          logger.error(`[DownloadJob] Process error for item [${this.item.id}]:`, err);
          reject(classifyError(err));
        });

        this.childProcess.on('close', async (code) => {
          if (watchdogTimer) {
            clearTimeout(watchdogTimer);
            watchdogTimer = undefined;
          }
          this.childProcess = undefined;

          if (this.isPaused) {
            logger.info(`[DownloadJob] Item ${this.item.id} paused.`);
            return reject({ isPaused: true });
          }
          if (this.isCancelled) {
            logger.info(`[DownloadJob] Item ${this.item.id} cancelled.`);
            this.cleanupStagingFiles(stagingDir, this.item.id);
            return reject({ isCancelled: true });
          }

          // Check if file was produced in staging folder regardless of exit code (handles code 0 and code 101)
          const stagingResult = this.findStagingFile(stagingDir, this.item.id);

          if (stagingResult && stagingResult.filePath) {
            try {
              const finalized = await this.processAndFinalizeDownloadedFile(
                stagingResult.filePath,
                stagingDir,
                targetDir,
                ffmpegPath,
                ffprobePath,
                binDir,
                stagingResult.extractedTitle
              );
              resolve(finalized);
              return;
            } catch (finErr) {
              this.cleanupStagingFiles(stagingDir, this.item.id);
              reject(classifyError(finErr, 'Failed to process downloaded file'));
              return;
            }
          } else {
            const combinedOut = ((stderrBuf || '') + ' ' + (stdoutBuf || '')).toLowerCase();
            const isCookieError = combinedOut.includes('the page needs to be reloaded') ||
                                  combinedOut.includes('confirm youâ€™re not a robot') ||
                                  combinedOut.includes('failed to parse json') ||
                                  combinedOut.includes('failed to decrypt') ||
                                  combinedOut.includes('dpapi') ||
                                  combinedOut.includes('database is locked') ||
                                  combinedOut.includes('cookie');
            if (!skipCookies && isCookieError) {
              logger.warn(`[DownloadJob] Cookie / DPAPI decryption error detected for item ${this.item.id}. Retrying cleanly without cookies...`);
              this.cleanupStagingFiles(stagingDir, this.item.id);
              return executeDownload(targetIndex, true);
            }

            const isPermanentFail = combinedOut.includes('video unavailable') || combinedOut.includes('this video is unavailable') || combinedOut.includes('private video') || combinedOut.includes('sign in to confirm');

            // 3-Tier Trim Engine:
            // Tier 1 was --download-sections. If that failed and we haven't tried fallbacks:
            if (!isPermanentFail && this.downloadedWithSections && !this.retriedWithoutSections) {
              this.retriedWithoutSections = true;
              this.downloadedWithSections = false;
              this.cleanupStagingFiles(stagingDir, this.item.id);

              // Tier 2: Extract direct stream URL(s) via yt-dlp -g and download only needed range via ffmpeg -ss/-to
              logger.info(`[DownloadJob] Tier 1 trim failed for "${currentTarget}". Attempting Tier 2: direct stream URLs via yt-dlp -g + ffmpeg -ss -to...`);
              this.emitThrottledProgress({
                progress: 5,
                downloadedBytes: 0,
                totalBytes: 0,
                speed: '',
                eta: '',
                stageDescription: 'Connecting to direct stream range...'
              });

              try {
                const ytdlpPath = await dependencyManager.getYtDlpExecutablePath();
                const nodeBin = dependencyManager.getNodeExecutablePath();
                const jsRuntime = (nodeBin === 'node' || !nodeBin) ? 'node' : `node:${nodeBin}`;
                const gArgs = [
                  '--no-playlist',
                  '--no-check-certificates',
                  '--no-warnings',
                  '--skip-download',
                  '--js-runtimes', jsRuntime,
                  '-g'
                ];
                if (this.item.profile?.customFormatId) {
                  gArgs.push('-f', this.item.profile.customFormatId);
                } else if (this.item.profile?.type === 'audio') {
                  gArgs.push('-f', 'bestaudio/best');
                } else {
                  gArgs.push('-f', 'bestvideo+bestaudio/best');
                }
                const localAppData = process.env.LOCALAPPDATA || (os.homedir ? path.join(os.homedir(), 'AppData', 'Local') : '');
                const cookiesFilePath = localAppData ? path.join(localAppData, 'MediaFetch', 'cookies.txt') : '';
                if (cookiesFilePath && fs.existsSync(cookiesFilePath) && fs.statSync(cookiesFilePath).size > 10) {
                  gArgs.push('--cookies', cookiesFilePath);
                }
                gArgs.push(currentTarget);

                const { stdout: gOut } = await execFileAsync(ytdlpPath, gArgs, { windowsHide: true, timeout: 25000 });
                const streamUrls = (gOut || '').trim().split(/\r?\n/).filter((u) => u.startsWith('http'));

                if (streamUrls.length > 0 && ffmpegPath && fs.existsSync(ffmpegPath)) {
                  filesystemManager.ensureDirExists(stagingDir);
                  const isVideoOnly = this.item.profile?.type === 'video-only' || this.item.profile?.presetId === 'video-only';
                  const isAudioOnly = this.item.profile?.type === 'audio' || ['mp3', 'wav', 'm4a', 'flac', 'aac', 'ogg'].includes((this.item.profile?.container || '').toLowerCase());
                  let start = this.normalizeTime(this.item.profile?.timeRange?.start, '00:00:00');
                  let end = this.normalizeTime(this.item.profile?.timeRange?.end, '99:59:59');
                  const startSec = this.parseTimeToSeconds(start);
                  const endSec = this.parseTimeToSeconds(end);
                  const clipDurSec = (endSec > startSec) ? (endSec - startSec) : 300;
                  const rangeTimeoutMs = Math.max(60000, Math.ceil(clipDurSec * 3000));
                  const tier2Staging = path.join(stagingDir, `${this.item.id}__MF__tier2_${Date.now()}.${(this.item.profile?.container || 'mp4').toLowerCase()}`);

                  let ffRangeArgs = ['-y'];
                  const ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';
                  const refHeader = "Referer: https://www.youtube.com/\r\nOrigin: https://www.youtube.com\r\n";
                  for (const sUrl of streamUrls) {
                    ffRangeArgs.push('-user_agent', ua, '-headers', refHeader, '-ss', start, '-to', end, '-i', sUrl);
                  }
                  if (streamUrls.length === 1) {
                    if (isAudioOnly) {
                      ffRangeArgs.push('-vn', '-c:a', 'aac', '-b:a', '192k', '-ar', '48000', tier2Staging);
                    } else {
                      ffRangeArgs.push(
                        ...getOptimalEncoderArgs(ffmpegPath),
                        ...(isVideoOnly ? ['-an'] : ['-c:a', 'aac', '-b:a', '192k', '-ar', '48000']),
                        '-movflags', '+faststart',
                        tier2Staging
                      );
                    }
                  } else {
                    if (isAudioOnly) {
                      ffRangeArgs.push('-map', '1:a:0?', '-vn', '-c:a', 'aac', '-b:a', '192k', '-ar', '48000', tier2Staging);
                    } else {
                      ffRangeArgs.push(
                        '-map', '0:v:0', '-map', '1:a:0?',
                        ...getOptimalEncoderArgs(ffmpegPath),
                        ...(isVideoOnly ? ['-an'] : ['-c:a', 'aac', '-b:a', '192k', '-ar', '48000']),
                        '-movflags', '+faststart',
                        tier2Staging
                      );
                    }
                  }
                  logger.info(`[DownloadJob] Executing Tier 2 stream trim: ffmpeg ${ffRangeArgs.join(' ')}`);
                  await new Promise((resolveT2, rejectT2) => {
                    const t2Proc = spawn(ffmpegPath, ffRangeArgs, { windowsHide: true });
                    const timer = setTimeout(() => {
                      try { t2Proc.kill('SIGKILL'); } catch (_) {}
                      rejectT2(new Error('Tier 2 stream trim timed out'));
                    }, rangeTimeoutMs);
                    t2Proc.on('error', (err) => { clearTimeout(timer); rejectT2(err); });
                    t2Proc.on('close', (c) => {
                      clearTimeout(timer);
                      if (c === 0 && fs.existsSync(tier2Staging) && fs.statSync(tier2Staging).size > 1000) {
                        resolveT2();
                      } else {
                        rejectT2(new Error(`Tier 2 stream trim exited with code ${c}`));
                      }
                    });
                  });

                  if (fs.existsSync(tier2Staging) && fs.statSync(tier2Staging).size > 1000) {
                    logger.info(`[DownloadJob] Tier 2 direct stream range trim succeeded.`);
                    this.downloadedWithTier2 = true;
                    const finalized = await this.processAndFinalizeDownloadedFile(
                      tier2Staging,
                      stagingDir,
                      targetDir,
                      ffmpegPath,
                      ffprobePath,
                      binDir,
                      safeTitlePart
                    );
                    resolve(finalized);
                    return;
                  }
                }
              } catch (tier2Err) {
                logger.warn(`[DownloadJob] Tier 2 trim notice: ${tier2Err.message}. Proceeding to Tier 3 (full download + async local cut)...`);
              }

              // Tier 3: Full download followed by local async cut
              logger.info(`[DownloadJob] Executing Tier 3: Full file download followed by local async cut...`);
              filesystemManager.ensureDirExists(stagingDir);
              return executeDownload(targetIndex);
            }

            // Check if fallback search query is available (only for query-related failures, never for unavailable/private videos)
            if (!isPermanentFail && targetIndex + 1 < searchTargets.length) {
              this.cleanupStagingFiles(stagingDir, this.item.id);
              logger.info(`[DownloadJob] Query "${currentTarget}" did not produce a file (exit: ${code}), trying fallback query "${searchTargets[targetIndex + 1]}" (${targetIndex + 2}/${searchTargets.length})...`);
              return executeDownload(targetIndex + 1);
            }

            this.cleanupStagingFiles(stagingDir, this.item.id);
            const errorMsg = stderrBuf || (code === 0 ? 'Downloaded file not found in staging folder.' : `yt-dlp exited with code ${code}`);
            logger.warn(`yt-dlp failed after all queries: ${errorMsg}`);
            reject(classifyError(new Error(errorMsg), stderrBuf));
          }
        });
      };

      executeDownload(0);
    });
  }

  downloadDirectStream(streamUrl, stagingFile) {
    return new Promise((resolve, reject) => {
      const download = (targetUrl, redirectCount = 0) => {
        if (redirectCount > 5) return reject(new Error('Too many redirects'));
        let referer = 'https://www.google.com/';
        const pageUrl = this.item.url || '';
        try {
          if (pageUrl.includes('x.com') || pageUrl.includes('twitter.com') || targetUrl.includes('twimg.com')) {
            referer = 'https://x.com/';
          } else if (pageUrl.includes('instagram.com') || targetUrl.includes('cdninstagram.com')) {
            referer = 'https://www.instagram.com/';
          } else if (pageUrl.includes('threads.net') || pageUrl.includes('threads.com')) {
            referer = 'https://www.threads.net/';
          } else if (pageUrl.includes('linkedin.com') || targetUrl.includes('licdn.com')) {
            referer = 'https://www.linkedin.com/';
          } else if (pageUrl.includes('behance.net') || targetUrl.includes('behance.net') || targetUrl.includes('vimeocdn.com')) {
            referer = 'https://www.behance.net/';
          } else if (targetUrl.includes('tiktokcdn') || targetUrl.includes('tikwm') || targetUrl.includes('tikmate') || pageUrl.includes('tiktok.com')) {
            referer = 'https://www.tiktok.com/';
          } else if (pageUrl.startsWith('http')) {
            referer = new URL(pageUrl).origin + '/';
          } else {
            const u = new URL(targetUrl);
            referer = u.origin + '/';
          }
        } catch (_) {}

        this.emitThrottledProgress({
          progress: 5,
          downloadedBytes: 0,
          totalBytes: 0,
          speed: '',
          eta: '',
          stageDescription: 'Connecting to direct media stream...'
        });

        let existingSize = 0;
        if (fs.existsSync(stagingFile)) {
          try { existingSize = fs.statSync(stagingFile).size; } catch (_) {}
        }

        const client = targetUrl.startsWith('https:') ? https : http;
        const reqHeaders = {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
          'Referer': referer
        };
        if (existingSize > 0) {
          reqHeaders['Range'] = `bytes=${existingSize}-`;
        }

        const req = client.get(targetUrl, {
          headers: reqHeaders
        }, (res) => {
          if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
            let nextUrl = res.headers.location;
            if (!nextUrl.startsWith('http')) {
              try {
                nextUrl = new URL(nextUrl, targetUrl).href;
              } catch (_) {}
            }
            return download(nextUrl, redirectCount + 1);
          }
          if (res.statusCode !== 200 && res.statusCode !== 206) {
            return reject(new Error(`Direct stream download failed with HTTP status ${res.statusCode}`));
          }

          const isRangeResume = res.statusCode === 206;
          const streamContentLen = parseInt(res.headers['content-length'] || '0', 10);
          const totalBytes = isRangeResume ? (existingSize + streamContentLen) : streamContentLen;

          this.emitThrottledProgress({
            progress: 8,
            downloadedBytes: isRangeResume ? existingSize : 0,
            totalBytes,
            speed: '',
            eta: '',
            stageDescription: totalBytes > 0 ? `Connected to stream (${(totalBytes / (1024 * 1024)).toFixed(1)} MB)...` : 'Connected, receiving media data...'
          });

          let downloaded = isRangeResume ? existingSize : 0;
          const out = fs.createWriteStream(stagingFile, { 
            flags: isRangeResume ? 'a' : 'w', 
            highWaterMark: 1024 * 1024 * 4 
          });
          let lastProgress = Date.now();
          let lastDownloaded = downloaded;

          res.on('data', (chunk) => {
            if (this.isCancelled) {
              res.destroy();
              out.close();
              try { fs.unlinkSync(stagingFile); } catch (_) {}
              return reject({ isCancelled: true });
            }
            if (this.isPaused) {
              res.destroy();
              out.close();
              return reject({ isPaused: true });
            }

            downloaded += chunk.length;
            const now = Date.now();
            if (now - lastProgress > 250) {
              const deltaBytes = downloaded - lastDownloaded;
              const deltaTime = (now - lastProgress) / 1000;
              const speedBytesPerSec = deltaTime > 0 ? deltaBytes / deltaTime : 0;
              const speedStr = (speedBytesPerSec / (1024 * 1024)).toFixed(1) + ' MB/s';
              const pct = totalBytes > 0 ? Math.min(90, Math.round((downloaded / totalBytes) * 100)) : 50;

              const isImg = this.item.profile?.type === 'image' || this.item.metadata?.mediaType === 'image' || this.item.metadata?.isImage;
              const isAud = this.item.profile?.type === 'audio' || this.item.metadata?.mediaType === 'audio';
              const stageDesc = isImg ? 'Downloading image file...' : (isAud ? 'Downloading audio stream...' : 'Downloading video stream...');

              this.emitThrottledProgress({
                progress: pct,
                downloadedBytes: downloaded,
                totalBytes: totalBytes,
                speed: speedStr,
                eta: '',
                stageDescription: stageDesc
              });
              lastProgress = now;
              lastDownloaded = downloaded;
            }
          });

          res.pipe(out);
          out.on('finish', () => {
            out.close();
            this.activeHttpRequest = undefined;
            resolve({ filePath: stagingFile, totalBytes: downloaded });
          });
          out.on('error', (err) => {
            out.close();
            this.activeHttpRequest = undefined;
            try { fs.unlinkSync(stagingFile); } catch (_) {}
            reject(err);
          });
        });

        this.activeHttpRequest = req;
        req.on('error', (err) => {
          this.activeHttpRequest = undefined;
          try { fs.unlinkSync(stagingFile); } catch (_) {}
          reject(err);
        });
      };

      download(streamUrl);
    });
  }

  async processAndFinalizeDownloadedFile(currentStagingFile, stagingDir, targetDir, ffmpegPath, ffprobePath, binDir, extractedTitle) {
    const stagingExt = path.extname(currentStagingFile).replace('.', '').toLowerCase();
    let container = (this.item.profile?.container || 'mp4').toLowerCase();
    const isAudioOnly = this.item.profile?.type === 'audio' || ['mp3', 'wav', 'm4a', 'flac', 'aac', 'ogg'].includes(container);
    const isVideoOnly = this.item.profile?.type === 'video-only' || this.item.profile?.presetId === 'video-only';

    let res = 1080;
    if (this.item.profile?.resolution && typeof this.item.profile.resolution === 'number' && this.item.profile.resolution > 0) {
      res = this.item.profile.resolution;
    } else if (typeof this.item.profile?.presetId === 'string' && this.item.profile.presetId.startsWith('res-')) {
      const parsed = parseInt(this.item.profile.presetId.replace('res-', ''), 10);
      if (!isNaN(parsed) && parsed > 0) res = parsed;
    }

    const isProRes = container === 'mov' && (this.item.profile?.label?.includes('ProRes') || this.item.profile?.presetId?.includes('prores'));

    // Probe video & audio codecs using ffprobe to detect AV1/VP9 vs H.264 and Opus vs AAC
    let probedVideoCodec = null;
    if (ffprobePath && !isAudioOnly) {
      probedVideoCodec = await this.probeVideoCodec(currentStagingFile, ffprobePath);
      logger.info(`[DownloadJob] Probed video stream codec: ${probedVideoCodec || 'none/unknown'}`);
    }
    let probedAudioCodec = null;
    if (ffprobePath && !isVideoOnly) {
      probedAudioCodec = await this.probeAudioCodec(currentStagingFile, ffprobePath);
      logger.info(`[DownloadJob] Probed audio stream codec: ${probedAudioCodec || 'none/unknown'}`);
    }
    const isH264 = probedVideoCodec === 'h264' || probedVideoCodec === 'avc1';
    const appName = (this.item.projectContext?.application || '').toLowerCase();
    const isAfterEffects = appName.includes('aftereffects') || appName.includes('aeft') || appName.includes('ae');
    const isPremiere = (appName.includes('premiere') || appName.includes('ppro')) && !isAfterEffects;

    // Pro-Grade FFmpeg Transcoding & Adobe Normalization
    if (ffmpegPath && fs.existsSync(ffmpegPath)) {
      const processedFile = path.join(stagingDir, `proc_${Date.now()}_${this.item.id}.${container}`);
      let ffmpegArgs = [];
      const hasTimeRange = Boolean(!this.downloadedWithSections && !this.downloadedWithTier2 && this.item.profile?.timeRange && (this.item.profile.timeRange.start || this.item.profile.timeRange.end));
      let timeSeekArgs = [];
      if (hasTimeRange) {
        let start = this.normalizeTime(this.item.profile.timeRange.start, '00:00:00');
        let end = this.normalizeTime(this.item.profile.timeRange.end, '99:59:59');
        const startSec = this.parseTimeToSeconds(start);
        const endSec = this.parseTimeToSeconds(end);
        if (endSec > 0 && startSec > endSec) {
          const tmp = start; start = end; end = tmp;
        }
        timeSeekArgs = ['-ss', start, '-to', end];
      }

      if (isAudioOnly) {
        // Resolve Target Bitrate based on user profile selection
        let targetBitrate = '320k';
        const pId = this.item.profile?.presetId || '';
        const pLbl = this.item.profile?.label || '';
        if (pId === 'audio-mp3-128' || pLbl.includes('128')) targetBitrate = '128k';
        else if (pId === 'audio-mp3-192' || pLbl.includes('192')) targetBitrate = '192k';
        else if (pId === 'audio-mp3-96' || pLbl.includes('96')) targetBitrate = '96k';
        else if (pId === 'audio-m4a' || pLbl.includes('256')) targetBitrate = '256k';
        else if (pId === 'audio-mp3-320' || pLbl.includes('320')) targetBitrate = '320k';

        if (container === 'wav') {
          ffmpegArgs = ['-y', '-i', currentStagingFile, '-vn', '-c:a', 'pcm_s16le', '-ar', '48000', processedFile];
        } else if (container === 'm4a' || container === 'aac') {
          ffmpegArgs = ['-y', '-i', currentStagingFile, '-vn', '-c:a', 'aac', '-b:a', targetBitrate, '-ar', '48000', processedFile];
        } else if (container === 'flac') {
          ffmpegArgs = ['-y', '-i', currentStagingFile, '-vn', '-c:a', 'flac', processedFile];
        } else if (container === 'webm') {
          ffmpegArgs = ['-y', '-i', currentStagingFile, '-vn', '-c:a', 'libopus', '-b:a', '160k', processedFile];
        } else {
          // Guaranteed MP3 bitrate encoding (e.g. 128k, 192k, 320k)
          ffmpegArgs = ['-y', '-i', currentStagingFile, '-vn', '-c:a', 'libmp3lame', '-b:a', targetBitrate, '-ar', '44100', processedFile];
        }
      } else if (isVideoOnly) {
        if (container === 'webm') {
          if (stagingExt === 'webm') {
            ffmpegArgs = ['-y', '-i', currentStagingFile, '-c:v', 'copy', '-an', processedFile];
          } else {
            ffmpegArgs = ['-y', '-i', currentStagingFile, '-c:v', 'libvpx-vp9', '-b:v', '0', '-crf', '24', '-an', processedFile];
          }
        } else if (container === 'mkv') {
          if (stagingExt === 'mkv') {
            ffmpegArgs = ['-y', '-i', currentStagingFile, '-c:v', 'copy', '-an', processedFile];
          } else {
            ffmpegArgs = ['-y', '-threads', '0', '-i', currentStagingFile, ...getOptimalEncoderArgs(ffmpegPath), '-an', processedFile];
          }
        } else if (container === 'mov') {
          if (isH264) {
            ffmpegArgs = ['-y', '-i', currentStagingFile, '-c:v', 'copy', '-tag:v', 'avc1', '-an', '-movflags', '+faststart', processedFile];
          } else {
            ffmpegArgs = ['-y', '-threads', '0', '-i', currentStagingFile, ...getOptimalEncoderArgs(ffmpegPath), '-tag:v', 'avc1', '-an', '-movflags', '+faststart', processedFile];
          }
        } else {
          if (isH264 && stagingExt === 'mp4' && !hasTimeRange) {
            ffmpegArgs = ['-y', '-i', currentStagingFile, '-c:v', 'copy', '-an', '-movflags', '+faststart', processedFile];
          } else {
            ffmpegArgs = ['-y', '-threads', '0', '-i', currentStagingFile, ...getOptimalEncoderArgs(ffmpegPath), '-an', '-movflags', '+faststart', processedFile];
          }
        }
      } else if (isProRes) {
        ffmpegArgs = [
          '-y', '-i', currentStagingFile,
          '-c:v', 'prores_ks', '-profile:v', '3', '-pix_fmt', 'yuv422p10le',
          '-c:a', 'pcm_s16le', '-ar', '48000',
          processedFile
        ];
      } else if (container === 'webm') {
        if (stagingExt === 'webm') {
          ffmpegArgs = ['-y', '-i', currentStagingFile, '-c', 'copy', processedFile];
        } else if (probedVideoCodec === 'vp9' || probedVideoCodec === 'vp8' || probedVideoCodec === 'av01' || probedVideoCodec === 'av1') {
          ffmpegArgs = ['-y', '-i', currentStagingFile, '-c:v', 'copy', '-c:a', 'libopus', '-b:a', '160k', processedFile];
        } else {
          ffmpegArgs = [
            '-y', '-i', currentStagingFile,
            '-c:v', 'libvpx-vp9', '-b:v', '0', '-crf', '28', '-cpu-used', '4', '-row-mt', '1',
            '-c:a', 'libopus', '-b:a', '160k',
            processedFile
          ];
        }
      } else if (container === 'mkv') {
        if (stagingExt === 'mkv') {
          ffmpegArgs = ['-y', '-i', currentStagingFile, '-c', 'copy', processedFile];
        } else {
          ffmpegArgs = [
            '-y', '-i', currentStagingFile,
            ...getOptimalEncoderArgs(ffmpegPath),
            '-pix_fmt', 'yuv420p',
            '-c:a', 'aac', '-b:a', '320k', '-ar', '48000',
            processedFile
          ];
        }
      } else if (container === 'mov') {
        if (isH264 && (stagingExt === 'mov' || stagingExt === 'mp4')) {
          ffmpegArgs = [
            '-y', '-i', currentStagingFile,
            '-c:v', 'copy',
            '-tag:v', 'avc1',
            '-c:a', 'aac', '-b:a', '320k', '-ar', '48000',
            '-movflags', '+faststart',
            processedFile
          ];
        } else if (isH264) {
          ffmpegArgs = [
            '-y', '-i', currentStagingFile,
            '-c:v', 'copy',
            '-tag:v', 'avc1',
            '-c:a', 'aac', '-b:a', '320k', '-ar', '48000',
            '-af', 'aresample=async=1000:first_pts=0',
            '-movflags', '+faststart',
            processedFile
          ];
        } else {
          ffmpegArgs = [
            '-y',
            '-threads', '0',
            '-i', currentStagingFile,
            ...getOptimalEncoderArgs(ffmpegPath),
            '-pix_fmt', 'yuv420p',
            '-tag:v', 'avc1',
            '-map', '0:v:0',
            '-map', '0:a?',
            '-c:a', 'aac',
            '-b:a', '320k',
            '-ar', '48000',
            '-movflags', '+faststart',
            processedFile
          ];
        }
      } else {
        // MP4 container: Bit-for-bit stream copy if source is already confirmed H.264 and audio is AAC
        // If audio is Opus or non-AAC (e.g. YouTube clip download), transcode audio to 320k 48kHz AAC while preserving 100% untouched video stream copy
        if (isH264 && container === 'mp4' && !hasTimeRange) {
          const isAacAudio = probedAudioCodec === 'aac' || probedAudioCodec === 'mp4a';
          const hasAudio = Boolean(probedAudioCodec);
          if ((stagingExt === 'mp4' || stagingExt === 'mov') && (!hasAudio || isAacAudio)) {
            ffmpegArgs = [
              '-y', '-i', currentStagingFile,
              '-c', 'copy',
              '-movflags', '+faststart',
              processedFile
            ];
          } else {
            ffmpegArgs = [
              '-y', '-i', currentStagingFile,
              '-map', '0:v:0',
              '-map', '0:a?',
              '-c:v', 'copy',
              '-c:a', 'aac', '-b:a', '320k', '-ar', '48000',
              '-movflags', '+faststart',
              processedFile
            ];
          }
        } else {
          // AV1/VP9 4K/8K: Must explicitly map both streams so Adobe gets video+audio.
          // -map 0:v:0 -map 0:a? forces FFmpeg to include both streams without failing on silent video.
          // -pix_fmt yuv420p is required by h264_nvenc (NVENC cannot accept NV12 directly from AV1 decoder).
          // -movflags +faststart enables streaming seek in Adobe timeline.
          ffmpegArgs = [
            '-y',
            '-i', currentStagingFile,
            ...getOptimalEncoderArgs(ffmpegPath),
            '-map', '0:v:0',
            '-map', '0:a?',
            ...(isVideoOnly ? ['-an'] : ['-c:a', 'aac', '-b:a', '320k', '-ar', '48000']),
            '-movflags', '+faststart',
            processedFile
          ];
        }
      }

      if (timeSeekArgs.length > 0) {
        const iIdx = ffmpegArgs.indexOf('-i');
        if (iIdx !== -1) {
          ffmpegArgs.splice(iIdx, 0, ...timeSeekArgs);
        }
      }

      try {
        this.emitThrottledProgress({
          progress: 92,
          downloadedBytes: this.item.downloadedBytes || 0,
          totalBytes: this.item.totalBytes || 0,
          speed: '',
          eta: 'Finalizing...',
          stageDescription: isH264 ? `Finalizing lossless ${container.toUpperCase()} for Adobe timeline...` : (hasTimeRange ? `Precision trimming for Adobe timeline...` : `Hardware accelerating ${container.toUpperCase()} for Adobe...`)
        });
        logger.info(`[DownloadJob] Transcoding with FFmpeg: ${ffmpegArgs.join(' ')}`);

        await new Promise((resFf) => {
          const ffProc = spawn(ffmpegPath, ffmpegArgs, { windowsHide: true });
          try {
            if (ffProc.pid && typeof os.setPriority === 'function') {
              os.setPriority(ffProc.pid, os.constants.priority.PRIORITY_BELOW_NORMAL);
            }
          } catch (_) {}
          let ffErr = '';
          ffProc.stderr?.on('data', (chunk) => {
            const text = chunk.toString();
            ffErr = (ffErr + text).slice(-1500);
            const timeMatch = text.match(/time=(\d+):(\d+):(\d+\.\d+)/);
            const speedMatch = text.match(/speed=\s*([\d\.]+x)/);
            const fpsMatch = text.match(/fps=\s*([\d\.]+)/);
            if (timeMatch) {
              const curSec = (parseFloat(timeMatch[1]) * 3600) + (parseFloat(timeMatch[2]) * 60) + parseFloat(timeMatch[3]);
              const durSec = this.item.duration || 0;
              let pct = 92;
              if (durSec > 0) {
                pct = Math.min(99, Math.max(91, 91 + Math.round((curSec / durSec) * 8)));
              }
              const spd = speedMatch ? speedMatch[1] : (fpsMatch ? `${fpsMatch[1]} fps` : '');
              const resTag = res >= 2160 ? '4K' : (res >= 1440 ? '2K' : (res >= 1080 ? 'Full HD' : (res >= 720 ? '720p HD' : 'video')));
              this.emitThrottledProgress({
                progress: pct,
                downloadedBytes: this.item.downloadedBytes || 0,
                totalBytes: this.item.totalBytes || 0,
                speed: spd ? `Optimizing at ${spd}` : '',
                eta: 'Almost ready...',
                stageDescription: `Optimizing ${resTag} stream for Adobe timeline (${pct}%)...`
              });
            }
          });
          ffProc.on('close', async (code) => {
            if (code === 0 && fs.existsSync(processedFile) && fs.statSync(processedFile).size > 1000) {
              if (timeSeekArgs.length > 0) this.trimmedInTranscode = true;
              resFf();
            } else {
              logger.warn(`[DownloadJob] Primary FFmpeg transcode finished with code ${code}. Retrying with universal fallback...`);
              let cpuArgs = [];
              if (isAudioOnly) {
                let targetBitrate = '320k';
                const pId = this.item.profile?.presetId || '';
                const pLbl = this.item.profile?.label || '';
                if (pId === 'audio-mp3-128' || pLbl.includes('128')) targetBitrate = '128k';
                else if (pId === 'audio-mp3-192' || pLbl.includes('192')) targetBitrate = '192k';
                else if (pId === 'audio-mp3-96' || pLbl.includes('96')) targetBitrate = '96k';
                else if (pId === 'audio-m4a' || pLbl.includes('256')) targetBitrate = '256k';
                else if (pId === 'audio-mp3-320' || pLbl.includes('320')) targetBitrate = '320k';

                if (container === 'wav') {
                  cpuArgs = ['-y', ...timeSeekArgs, '-i', currentStagingFile, '-vn', '-c:a', 'pcm_s16le', '-ar', '48000', processedFile];
                } else if (container === 'm4a' || container === 'aac') {
                  cpuArgs = ['-y', ...timeSeekArgs, '-i', currentStagingFile, '-vn', '-c:a', 'aac', '-b:a', targetBitrate, '-ar', '48000', processedFile];
                } else if (container === 'flac') {
                  cpuArgs = ['-y', ...timeSeekArgs, '-i', currentStagingFile, '-vn', '-c:a', 'flac', processedFile];
                } else if (container === 'webm') {
                  cpuArgs = ['-y', ...timeSeekArgs, '-i', currentStagingFile, '-vn', '-c:a', 'libopus', '-b:a', '160k', processedFile];
                } else {
                  cpuArgs = ['-y', ...timeSeekArgs, '-i', currentStagingFile, '-vn', '-c:a', 'libmp3lame', '-b:a', targetBitrate, '-ar', '44100', processedFile];
                }
              } else if (container === 'webm') {
                cpuArgs = [
                  '-y', ...timeSeekArgs, '-i', currentStagingFile,
                  '-c:v', 'libvpx-vp9', '-b:v', '0', '-crf', '24',
                  ...(isVideoOnly ? ['-an'] : ['-c:a', 'libopus', '-b:a', '160k']),
                  processedFile
                ];
              } else if (container === 'mkv') {
                cpuArgs = [
                  '-y', ...timeSeekArgs, '-threads', '0', '-i', currentStagingFile,
                  ...getOptimalEncoderArgs(ffmpegPath),
                  '-map', '0:v:0', '-map', '0:a?',
                  ...(isVideoOnly ? ['-an'] : ['-c:a', 'aac', '-b:a', '320k', '-ar', '48000']),
                  processedFile
                ];
              } else {
                cpuArgs = [
                  '-y', ...timeSeekArgs, '-threads', '0', '-i', currentStagingFile,
                  ...getOptimalEncoderArgs(ffmpegPath),
                  ...(container === 'mov' ? ['-tag:v', 'avc1'] : []),
                  '-map', '0:v:0', '-map', '0:a?',
                  ...(isVideoOnly ? ['-an'] : ['-c:a', 'aac', '-b:a', '320k', '-ar', '48000']),
                  '-movflags', '+faststart',
                  processedFile
                ];
              }
              try {
                const cpuProc = spawn(ffmpegPath, cpuArgs, { windowsHide: true });
                cpuProc.on('close', () => resFf());
                cpuProc.on('error', () => resFf());
              } catch (_) {
                resFf();
              }
            }
          });
          ffProc.on('error', (err) => {
            logger.warn('FFmpeg spawn notice:', err);
            resFf();
          });
        });

        if (fs.existsSync(processedFile) && fs.statSync(processedFile).size > 1000) {
          try { fs.unlinkSync(currentStagingFile); } catch (_) {}
          currentStagingFile = processedFile;
        }
      } catch (ffmpegErr) {
        logger.warn('[DownloadJob] FFmpeg processing notice:', ffmpegErr);
      }
    }

    // Fallback: If timeRange was requested but file was not trimmed above, perform instant lossless stream copy cut
    const fallbackHasTimeRange = Boolean(!this.downloadedWithSections && !this.trimmedInTranscode && !this.downloadedWithTier2 && this.item.profile?.timeRange && (this.item.profile.timeRange.start || this.item.profile.timeRange.end));
    if (fallbackHasTimeRange && currentStagingFile && fs.existsSync(currentStagingFile)) {
      const activeFfmpeg = (ffmpegPath && fs.existsSync(ffmpegPath)) ? ffmpegPath : path.join(binDir || '', process.platform === 'win32' ? 'ffmpeg.exe' : 'ffmpeg');
      if (activeFfmpeg && fs.existsSync(activeFfmpeg)) {
        const trimmedCut = path.join(stagingDir, `cut_${Date.now()}_${this.item.id}.${stagingExt}`);
        try {
          let start = this.normalizeTime(this.item.profile.timeRange.start, '00:00:00');
          let end = this.normalizeTime(this.item.profile.timeRange.end, '99:59:59');
          const startSec = this.parseTimeToSeconds(start);
          const endSec = this.parseTimeToSeconds(end);
          const expectedDurSec = (endSec > startSec) ? (endSec - startSec) : null;
          const mediaDuration = this.item.duration || expectedDurSec || 300;
          const cutTimeoutMs = Math.max(60000, Math.ceil(mediaDuration * 2000));

          this.emitThrottledProgress({
            progress: 94,
            downloadedBytes: this.item.downloadedBytes || 0,
            totalBytes: this.item.totalBytes || 0,
            speed: '',
            eta: 'Trimming...',
            stageDescription: `Precision trimming clip (${start} - ${end})...`
          });

          await new Promise((resolveCut, rejectCut) => {
            const cutProc = spawn(activeFfmpeg, [
              '-y', '-ss', start, '-to', end, '-i', currentStagingFile, '-c', 'copy', '-movflags', '+faststart', trimmedCut
            ], { windowsHide: true, stdio: ['ignore', 'ignore', 'pipe'] });

            let cutStderr = '';
            cutProc.stderr?.on('data', (d) => {
              const text = d.toString();
              cutStderr += text;
              const timeMatch = text.match(/time=(\d+):(\d+):(\d+\.\d+)/);
              if (timeMatch && expectedDurSec) {
                const curSec = (parseFloat(timeMatch[1]) * 3600) + (parseFloat(timeMatch[2]) * 60) + parseFloat(timeMatch[3]);
                const pct = Math.min(99, Math.max(93, 93 + Math.round((curSec / expectedDurSec) * 6)));
                this.emitThrottledProgress({
                  progress: pct,
                  downloadedBytes: this.item.downloadedBytes || 0,
                  totalBytes: this.item.totalBytes || 0,
                  speed: '',
                  eta: 'Trimming...',
                  stageDescription: `Trimming clip (${pct}%)...`
                });
              }
            });

            const timer = setTimeout(() => {
              try { cutProc.kill('SIGKILL'); } catch (_) {}
              rejectCut(new Error(`Stream copy cut timed out after ${cutTimeoutMs}ms`));
            }, cutTimeoutMs);

            cutProc.on('error', (err) => {
              clearTimeout(timer);
              rejectCut(err);
            });

            cutProc.on('close', (code) => {
              clearTimeout(timer);
              if (code === 0 && fs.existsSync(trimmedCut) && fs.statSync(trimmedCut).size > 1000) {
                resolveCut();
              } else {
                rejectCut(new Error(`Stream copy cut failed with exit code ${code}: ${cutStderr.slice(-300)}`));
              }
            });
          });

          if (fs.existsSync(trimmedCut) && fs.statSync(trimmedCut).size > 1000) {
            // Verify output duration using ffprobe
            if (expectedDurSec && ffprobePath && fs.existsSync(ffprobePath)) {
              const actualDur = await probeDurationSeconds(trimmedCut, ffprobePath);
              if (actualDur && Math.abs(actualDur - expectedDurSec) > 2.5) {
                logger.warn(`[DownloadJob] Trim duration mismatch: expected ${expectedDurSec}s, got ${actualDur}s`);
              }
            }
            try { fs.unlinkSync(currentStagingFile); } catch (_) {}
            currentStagingFile = trimmedCut;
          }
        } catch (cutErr) {
          logger.warn(`Post-download stream copy cut notice: ${cutErr.message}`);
          throw cutErr;
        }
      }
    }

    const ext = this.getContainerExtension(this.item.profile || {});
    let finalName = '';

    if (this.item.profile?.customFilename && this.item.profile.customFilename.trim().length > 0) {
      const customClean = filesystemManager.sanitizeFilename(this.item.profile.customFilename.trim());
      finalName = customClean + '.' + ext;
      this.item.title = customClean;
    } else {
      const isGeneric = (str) => {
        if (!str) return true;
        const s = str.trim();
        return !s || s === 'Fetching media info...' || /^video by /i.test(s) || /^post by /i.test(s) || /^tweet by /i.test(s) || s.toLowerCase() === 'media' || /^media[\._]/i.test(s);
      };

      const curTitle = (this.item.title || '').trim();
      const curIsGeneric = isGeneric(curTitle);
      
      const extTitle = (extractedTitle || '').trim();
      const extIsGeneric = isGeneric(extTitle);

      const metaTitle = (this.item.metadata?.title || '').trim();
      const metaIsGeneric = isGeneric(metaTitle);

      let chosenTitle = 'MediaFetch_Media';
      if (!metaIsGeneric) {
        chosenTitle = metaTitle;
      } else if (!curIsGeneric) {
        chosenTitle = curTitle;
      } else if (!extIsGeneric) {
        chosenTitle = extTitle;
      } else if (metaTitle && !isGeneric(metaTitle)) {
        chosenTitle = metaTitle.replace(/^video by /i, 'Clip - ').trim();
      } else if (curTitle && !isGeneric(curTitle)) {
        chosenTitle = curTitle.replace(/^video by /i, 'Clip - ').trim();
      } else if (extTitle && !isGeneric(extTitle)) {
        chosenTitle = extTitle.replace(/^video by /i, 'Clip - ').trim();
      }

      const cleanChosen = filesystemManager.sanitizeFilename(chosenTitle);
      finalName = cleanChosen + '.' + ext;
      this.item.title = cleanChosen;
    }

    const effectiveTargetDir = this.resolveFinalTargetDir(targetDir, ext, this.item.profile?.type);
    const finalized = filesystemManager.finalizeDownloadedFile(currentStagingFile, effectiveTargetDir, finalName);
    this.item.downloadedPath = finalized.finalPath;
    this.cleanupStagingFiles(stagingDir, this.item.id);
    // Brief settle delay to guarantee Windows file handles / Defender filters have flushed before Premiere Pro opens it
    await new Promise(r => setTimeout(r, 400));
    return finalized;
  }

  resolveFinalTargetDir(baseTargetDir, ext, profileType) {
    // For ZIP packages, ALWAYS directly return baseTargetDir (staging folder) - ZERO loose wrapper folders!
    if (this.item.zipPackage || this.item.metadata?.zipPackage) {
      if (baseTargetDir) {
        filesystemManager.ensureDirExists(baseTargetDir);
        return baseTargetDir;
      }
    }

    const rawLocMode = settingsManager.getSettings()?.downloads?.downloadLocationMode || 'simple';
    const locMode = rawLocMode === 'project' ? 'simple' : rawLocMode;
    const isCustomFlat = locMode === 'custom_flat' || Boolean(this.item.isCustomFlat);
    const isCustomMode = locMode === 'custom' || isCustomFlat || Boolean(this.item.isCustomPath);
    const isPlaylist = Boolean(this.item.metadata?.isPlaylist || this.item.isPlaylist || this.item.metadata?.playlistTitle);

    let root = baseTargetDir || filesystemManager.resolveTargetDirectory().targetDir;
    root = root.replace(/[\/\\]+$/, '');

    // 1. Direct Custom Flat folder: save all media directly without subfolders
    if (isCustomFlat) {
      filesystemManager.ensureDirExists(root);
      return root;
    }

    // 2. Playlist: save into Playlists/[Playlist Name]
    if (isPlaylist) {
      const rawPTitle = this.item.metadata?.playlistTitle || this.item.metadata?.customFolderName || 'Playlist';
      const pTitle = rawPTitle.replace(/[\\/:*?"<>|]/g, '_').trim() || 'Playlist';
      let pDir = path.join(root, 'Playlists', pTitle);
      if (this.item.metadata?.subFolderName) {
        pDir = path.join(pDir, this.item.metadata.subFolderName);
      }
      filesystemManager.ensureDirExists(pDir);
      return pDir;
    }

    const cleanExt = (ext || '').toLowerCase().replace(/^\./, '').split('?')[0];
    const isAudio = profileType === 'audio' || ['mp3', 'wav', 'm4a', 'flac', 'aac', 'ogg', 'opus', 'aiff', 'm4p'].includes(cleanExt);
    const isImage = profileType === 'image' || ['jpg', 'jpeg', 'png', 'webp', 'gif', 'bmp', 'svg', 'tiff', 'tif', 'ico'].includes(cleanExt);
    const subType = isAudio ? 'Audio' : (isImage ? 'Images' : 'Video');

    // 3. Custom Path Mode: Save strictly into [CustomFolder]/Video, Audio, Images
    if (isCustomMode) {
      const finalDir = path.join(root, subType);
      filesystemManager.ensureDirExists(finalDir);
      return finalDir;
    }

    // Clean any existing trailing subfolders from root
    root = root.replace(/[\/\\](?:Link|Search|LinkMediaFetch|SerachMediafetch|Video|Audio|Images?)$/i, '');
    if (!/[\/\\]MediaFetch$/i.test(root) && path.basename(root).toLowerCase() !== 'mediafetch') {
      root = path.join(root, 'MediaFetch');
    }

    // 4. Simple Path Mode (DEFAULT): Save strictly into [ProjectFolder]/MediaFetch/Video, Audio, Images
    const finalDir = path.join(root, subType);
    filesystemManager.ensureDirExists(finalDir);
    return finalDir;
  }

  pause() {
    this.isPaused = true;
    this.killProcess();
  }

  cancel() {
    this.isCancelled = true;
    this.killProcess();
  }

  killProcess() {
    if (this.activeHttpRequest) {
      try {
        this.activeHttpRequest.destroy();
        this.activeHttpRequest = undefined;
      } catch (_) {}
    }
    if (this.childProcess) {
      try {
        if (process.platform === 'win32') {
          try {
            spawn('taskkill', ['/pid', String(this.childProcess.pid), '/f', '/t'], { windowsHide: true });
          } catch (_) {}
          try {
            this.childProcess.kill('SIGKILL');
          } catch (_) {}
        } else {
          this.childProcess.kill('SIGKILL');
        }
      } catch (err) {
        logger.warn(`[DownloadJob] Kill error for [${this.item.id}]:`, err);
      }
    }
  }

  async probeVideoCodec(filePath, ffprobePath) {
    if (!ffprobePath || !fs.existsSync(ffprobePath) || !fs.existsSync(filePath)) {
      return null;
    }
    try {
      const { stdout } = await execFileAsync(ffprobePath, [
        '-v', 'error',
        '-select_streams', 'v:0',
        '-show_entries', 'stream=codec_name',
        '-of', 'default=noprint_wrappers=1:nokey=1',
        filePath
      ], { windowsHide: true });
      return (stdout || '').trim().toLowerCase();
    } catch (err) {
      logger.warn('[DownloadJob] ffprobe probe notice:', err);
      return null;
    }
  }

  async probeAudioCodec(filePath, ffprobePath) {
    if (!ffprobePath || !fs.existsSync(ffprobePath) || !fs.existsSync(filePath)) {
      return null;
    }
    try {
      const { stdout } = await execFileAsync(ffprobePath, [
        '-v', 'error',
        '-select_streams', 'a:0',
        '-show_entries', 'stream=codec_name',
        '-of', 'default=noprint_wrappers=1:nokey=1',
        filePath
      ], { windowsHide: true });
      return (stdout || '').trim().toLowerCase();
    } catch (err) {
      logger.warn('[DownloadJob] ffprobe audio probe notice:', err);
      return null;
    }
  }

  parseStdout(data) {
    if (this.isPaused || this.isCancelled) return;
    const lines = data.split(/\r?\n/);
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed) continue;
      if (trimmed.startsWith('MF_TITLE:')) {
        const t = trimmed.substring('MF_TITLE:'.length).trim();
        const isGeneric = !t || /^video by /i.test(t) || /^post by /i.test(t) || /^tweet by /i.test(t) || t.toLowerCase() === 'media' || /^media[\._]/i.test(t);
        if (t && t.length > 0 && !isGeneric && (this.item.title === 'Fetching media info...' || !this.item.title || /^video by /i.test(this.item.title) || this.item.title.toLowerCase() === 'media' || /^media[\._]/i.test(this.item.title))) {
          this.item.title = t;
          if (!this.item.metadata) this.item.metadata = {};
          this.item.metadata.title = t;
          this.onProgressCb?.({
            progress: this.item.progress || 0,
            downloadedBytes: this.item.downloadedBytes || 0,
            totalBytes: this.item.totalBytes || 0,
            speed: this.item.speed || '',
            eta: this.item.eta || '',
            stageDescription: 'Starting download...'
          });
        }
      } else if (trimmed.startsWith('[download] Destination:') || trimmed.startsWith('[download] Got destination:')) {
        const destMatch = trimmed.match(/__MF__(.*?)(?:__MF__|\.[a-zA-Z0-9]+$)/);
        if (destMatch && destMatch[1] && (this.item.title === 'Fetching media info...' || !this.item.title || this.item.title.toLowerCase() === 'media' || /^media[\._]/i.test(this.item.title))) {
          let dt = destMatch[1].trim();
          dt = dt.replace(/\.f\d+$/i, '').replace(/\.temp$/i, '').trim();
          const isGeneric = !dt || /^video by /i.test(dt) || /^post by /i.test(dt) || /^tweet by /i.test(dt) || dt.toLowerCase() === 'media' || /^media[\._]/i.test(dt);
          if (!isGeneric) {
            this.item.title = dt;
            if (!this.item.metadata) this.item.metadata = {};
            this.item.metadata.title = dt;
          }
        }
        this.streamIndex++;
        if (this.streamIndex > 1) {
          // Stream 2 (audio track) begins after Stream 1 (video) finished
          if (this.currentStreamTotal > 0) {
            this.completedStreamsBytes += (this.currentStreamDownloaded || this.currentStreamTotal);
            this.completedStreamsTotal += this.currentStreamTotal;
            this.currentStreamDownloaded = 0;
            this.currentStreamTotal = 0;
          }
          this.emitThrottledProgress({
            progress: Math.min(90, Math.max(88, this.item.progress || 0)),
            downloadedBytes: this.completedStreamsBytes,
            totalBytes: this.completedStreamsTotal,
            speed: '',
            eta: '',
            stageDescription: 'Video stream ready, fetching audio track...'
          });
        } else {
          this.emitThrottledProgress({
            progress: Math.max(10, this.item.progress || 0),
            downloadedBytes: this.item.downloadedBytes || 0,
            totalBytes: this.item.totalBytes || 0,
            speed: '',
            eta: '',
            stageDescription: 'Connected to server, starting media transfer...'
          });
        }
      } else if (trimmed.includes('Downloading webpage') || trimmed.includes('Extracting URL')) {
        this.emitThrottledProgress({
          progress: Math.max(3, this.item.progress || 0),
          downloadedBytes: 0,
          totalBytes: 0,
          speed: '',
          eta: '',
          stageDescription: 'Resolving media host...'
        });
      } else if (trimmed.includes('player API') || trimmed.includes('initial data')) {
        this.emitThrottledProgress({
          progress: Math.max(6, this.item.progress || 0),
          downloadedBytes: 0,
          totalBytes: 0,
          speed: '',
          eta: '',
          stageDescription: 'Negotiating high-speed stream...'
        });
      } else if (trimmed.includes('Downloading 1 format') || trimmed.includes('Downloading format') || trimmed.includes('[info]')) {
        this.emitThrottledProgress({
          progress: Math.max(8, this.item.progress || 0),
          downloadedBytes: 0,
          totalBytes: 0,
          speed: '',
          eta: '',
          stageDescription: 'Stream selected, establishing CDN connection...'
        });
      } else if (trimmed.startsWith('MF_PROGRESS:')) {
        const parts = trimmed.substring('MF_PROGRESS:'.length).split('|');
        if (parts.length >= 5) {
          const rawPercent = parts[0].replace('%', '').trim();
          const percent = parseFloat(rawPercent) || 0;
          const downloadedStr = parts[1].trim();
          const totalStr = parts[2].trim();
          const speedStr = parts[3].trim();
          const etaStr = parts[4].trim();
          const downloadedBytes = this.parseBytes(downloadedStr);
          const totalBytes = this.parseBytes(totalStr);

          // Detect transition to audio stream if Destination message was buffered
          if (this.streamIndex <= 1 && this.lastStreamTotal > 15 * 1024 * 1024 && totalBytes > 0 && totalBytes < this.lastStreamTotal * 0.4 && percent < 20) {
            this.streamIndex = 2;
            this.completedStreamsBytes += (this.currentStreamDownloaded || this.lastStreamTotal);
            this.completedStreamsTotal += this.lastStreamTotal;
            this.currentStreamDownloaded = 0;
            this.currentStreamTotal = 0;
          }

          this.lastStreamTotal = totalBytes;
          this.currentStreamDownloaded = downloadedBytes;
          this.currentStreamTotal = totalBytes;

          let aggregateDownloaded = downloadedBytes;
          let aggregateTotal = totalBytes;

          if (this.streamIndex > 1 || this.completedStreamsTotal > 0) {
            aggregateDownloaded = this.completedStreamsBytes + downloadedBytes;
            aggregateTotal = this.completedStreamsTotal + totalBytes;
          }

          this.item.downloadedBytes = aggregateDownloaded;
          this.item.totalBytes = aggregateTotal;
          this.item.speed = speedStr;
          this.item.eta = etaStr;

          let overallPercent = percent;
          if (aggregateTotal > 0) {
            overallPercent = (aggregateDownloaded / aggregateTotal) * 100;
          }

          const prevProg = this.item.progress || 0;
          let targetProgress = Math.min(90, Math.round(overallPercent));
          if (this.streamIndex > 1) {
            targetProgress = Math.min(90, Math.max(88, targetProgress));
          }
          const displayProgress = Math.max(prevProg, targetProgress);
          this.item.progress = displayProgress;

          let stageDesc = '';
          if (this.streamIndex > 1) {
            stageDesc = `Downloading audio track (${percent.toFixed(0)}%)...`;
          } else {
            stageDesc = `Downloading (${percent.toFixed(0)}%)`;
          }

          this.emitThrottledProgress({
            progress: displayProgress,
            downloadedBytes: aggregateDownloaded,
            totalBytes: aggregateTotal,
            speed: speedStr || '',
            eta: etaStr || '',
            stageDescription: stageDesc
          });
        }
      } else if (trimmed.includes('CN:') && /\[#\w+\s+[\d\.]+[A-Za-z]+\/[\d\.]+[A-Za-z]+\s*\(\d+%\)/.test(trimmed)) {
        const ariaMatch = trimmed.match(/\[#\w+\s+([\d\.]+[A-Za-z]+)\/([\d\.]+[A-Za-z]+)\s*\((\d+)%\).*?DL:([\d\.]+[A-Za-z]+(?:\/s)?)?(?:\s+ETA:([\w:]+))?/);
        if (ariaMatch) {
          const dlStr = ariaMatch[1];
          const totStr = ariaMatch[2];
          const pct = parseInt(ariaMatch[3], 10) || 0;
          const spd = ariaMatch[4] ? `${ariaMatch[4]}/s`.replace('/s/s', '/s') : '';
          const eta = ariaMatch[5] || '';
          const dlBytes = this.parseBytes(dlStr);
          const totBytes = this.parseBytes(totStr);
          const displayProg = Math.min(90, Math.max(5, pct));
          this.emitThrottledProgress({
            progress: displayProg,
            downloadedBytes: dlBytes,
            totalBytes: totBytes,
            speed: spd,
            eta: eta,
            stageDescription: `Downloading (${displayProg}%)`
          });
        }
      } else if (/^\[download\]\s+\d+(\.\d+)?%/i.test(trimmed)) {
        const stdMatch = trimmed.match(/\[download\]\s+(\d+(?:\.\d+)?)%\s+of\s+~?\s*([\d\.]+\s*[a-zA-Z]+)(?:\s+at\s+~?\s*([\d\.]+\s*[a-zA-Z]+\/s))?(?:\s+ETA\s+([0-9:]+))?/i);
        if (stdMatch) {
          const percent = parseFloat(stdMatch[1]) || 0;
          const totalStr = stdMatch[2] || '';
          const speedStr = stdMatch[3] || '';
          const etaStr = stdMatch[4] || '';
          const totalBytes = this.parseBytes(totalStr);
          const downloadedBytes = totalBytes > 0 ? Math.round((percent / 100) * totalBytes) : 0;

          if (this.streamIndex <= 1 && this.lastStreamTotal > 15 * 1024 * 1024 && totalBytes > 0 && totalBytes < this.lastStreamTotal * 0.4 && percent < 20) {
            this.streamIndex = 2;
            this.completedStreamsBytes += (this.currentStreamDownloaded || this.lastStreamTotal);
            this.completedStreamsTotal += this.lastStreamTotal;
            this.currentStreamDownloaded = 0;
            this.currentStreamTotal = 0;
          }

          this.lastStreamTotal = totalBytes;
          this.currentStreamDownloaded = downloadedBytes;
          this.currentStreamTotal = totalBytes;

          let aggregateDownloaded = downloadedBytes;
          let aggregateTotal = totalBytes;

          if (this.streamIndex > 1 || this.completedStreamsTotal > 0) {
            aggregateDownloaded = this.completedStreamsBytes + downloadedBytes;
            aggregateTotal = this.completedStreamsTotal + totalBytes;
          }

          this.item.downloadedBytes = aggregateDownloaded;
          this.item.totalBytes = aggregateTotal;
          this.item.speed = speedStr;
          this.item.eta = etaStr;

          let overallPercent = percent;
          if (aggregateTotal > 0) {
            overallPercent = (aggregateDownloaded / aggregateTotal) * 100;
          }

          const prevProg = this.item.progress || 0;
          let targetProgress = Math.min(90, Math.round(overallPercent));
          if (this.streamIndex > 1) {
            targetProgress = Math.min(90, Math.max(88, targetProgress));
          }
          const displayProgress = Math.max(prevProg, targetProgress);
          this.item.progress = displayProgress;

          let stageDesc = '';
          if (this.streamIndex > 1) {
            stageDesc = `Downloading audio track (${percent.toFixed(0)}%)...`;
          } else {
            stageDesc = `Downloading (${percent.toFixed(0)}%)`;
          }

          this.emitThrottledProgress({
            progress: displayProgress,
            downloadedBytes: aggregateDownloaded,
            totalBytes: aggregateTotal,
            speed: speedStr || '',
            eta: etaStr || '',
            stageDescription: stageDesc
          });
        }
      } else if (trimmed.includes('[Merger]') || trimmed.includes('[ExtractAudio]') || trimmed.includes('[FixupM3u8]') || trimmed.includes('MF_MERGE:')) {
        this.emitThrottledProgress({
          progress: 91,
          downloadedBytes: this.item.downloadedBytes || 0,
          totalBytes: this.item.totalBytes || 0,
          speed: '',
          eta: 'Finalizing...',
          stageDescription: 'Merging audio and video streams (almost ready)...'
        });
      }
    }
  }

  parseStderr(data) {
    if (this.isPaused || this.isCancelled) return;
    if (data.includes('[Merger]') || data.includes('[ExtractAudio]') || data.includes('Post-process')) {
      this.emitThrottledProgress({
        progress: 91,
        downloadedBytes: this.item.downloadedBytes || 0,
        totalBytes: this.item.totalBytes || 0,
        speed: '',
        eta: 'Finalizing...',
        stageDescription: 'Processing & remuxing with FFmpeg (almost ready)...'
      });
      return;
    }

    if (data.includes('Opening') || data.includes('Press [q]') || data.includes('Metadata:') || data.includes('Stream #') || data.includes('Starting connection attempt') || data.includes('Successfully connected')) {
      const isTrim = Boolean(this.item.profile?.timeRange);
      const startPoint = this.item.profile?.timeRange?.start || '00:00:00';
      this.emitThrottledProgress({
        progress: Math.max(isTrim ? 12 : 5, this.item.progress || 0),
        downloadedBytes: this.item.downloadedBytes || 0,
        totalBytes: this.item.totalBytes || 0,
        speed: '',
        eta: '',
        stageDescription: isTrim ? `Seeking stream to cut point (${startPoint})...` : 'Establishing media stream...'
      });
    }

    const timeMatch = data.match(/time=\s*(-?[\d\.:]+)/);
    const sizeMatch = data.match(/size=\s*(\d+)\s*[kK]i?B/i);
    const speedMatch = data.match(/speed=\s*([\d\.]+)x/i);
    const frameMatch = data.match(/frame=\s*(\d+)/i);
    if (timeMatch || frameMatch) {
      const sizeKb = sizeMatch ? parseInt(sizeMatch[1], 10) : 0;
      const downloadedBytes = sizeKb * 1024;
      const speedStr = speedMatch ? `${speedMatch[1]}x` : '';

      let pct = Math.max(5, this.item.progress || 5);
      if (this.item.profile?.timeRange && timeMatch) {
        const tr = this.item.profile.timeRange;
        const s = this.parseTimeToSeconds(tr.start);
        const e = this.parseTimeToSeconds(tr.end);
        const dur = (e > s) ? (e - s) : 0;
        const rawCur = this.parseTimeToSeconds(timeMatch[1]);
        const cur = Math.max(0, rawCur);
        if (dur > 0) {
          pct = Math.min(95, Math.max(5, Math.round((cur / dur) * 100)));
        }
      }

      this.emitThrottledProgress({
        progress: pct,
        downloadedBytes: downloadedBytes > 0 ? downloadedBytes : (this.item.downloadedBytes || 0),
        totalBytes: this.item.totalBytes || 0,
        speed: speedStr,
        eta: '',
        stageDescription: `Downloading trimmed stream (${pct}%)...`
      });
    }
  }

  emitThrottledProgress(update) {
    if (this.isPaused || this.isCancelled) return;
    const now = Date.now();
    if (now - this.lastProgressEmit >= this.throttleMs) {
      this.lastProgressEmit = now;
      this.onProgressCb?.(update);
    }
  }

  parseBytes(str) {
    if (!str || str === 'N/A' || str === 'Unknown') return 0;
    const match = str.match(/([\d\.]+)\s*([KMGTP]?i?B)/i);
    if (!match) return 0;
    const num = parseFloat(match[1]);
    const unit = match[2].toUpperCase();
    const multipliers = {
      'B': 1,
      'KB': 1024,
      'KIB': 1024,
      'MB': 1024 * 1024,
      'MIB': 1024 * 1024,
      'GB': 1024 * 1024 * 1024,
      'GIB': 1024 * 1024 * 1024,
      'TB': 1024 * 1024 * 1024 * 1024
    };
    return Math.round(num * (multipliers[unit] || 1));
  }

  parseTimeToSeconds(val) {
    if (!val) return 0;
    const clean = String(val).trim();
    if (!clean) return 0;
    const parts = clean.split(':').map(p => parseFloat(p.trim()) || 0);
    if (parts.length >= 3) {
      let sec = parts[0] * 3600 + parts[1] * 60 + parts[2];
      if (parts.length >= 4) sec += parts[3] / 30; // frames fallback
      return sec;
    } else if (parts.length === 2) {
      return parts[0] * 60 + parts[1];
    } else if (parts.length === 1) {
      return parts[0];
    }
    return 0;
  }

  normalizeTime(val, fallback = '00:00:00') {
    if (!val) return fallback;
    const clean = String(val).trim();
    if (!clean) return fallback;

    let totalSec = this.parseTimeToSeconds(clean);
    if (isNaN(totalSec) || totalSec < 0) totalSec = 0;

    const h = Math.floor(totalSec / 3600);
    const m = Math.floor((totalSec % 3600) / 60);
    const s = Math.floor(totalSec % 60);
    const frac = totalSec - Math.floor(totalSec);
    const fracStr = frac > 0 ? ('.' + Math.round(frac * 1000).toString().padStart(3, '0')) : '';

    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}${fracStr}`;
  }

  getContainerExtension(profile) {
    const c = (profile.container || '').toLowerCase();
    if (c) {
      return c;
    }
    if (profile.type === 'audio') {
      if (profile.presetId === 'audio-wav') return 'wav';
      if (profile.presetId === 'audio-m4a') return 'm4a';
      if (profile.presetId === 'audio-flac') return 'flac';
      return 'mp3';
    }
    return 'mp4';
  }

  findStagingFile(stagingDir, downloadId) {
    if (!fs.existsSync(stagingDir)) return null;
    const files = fs.readdirSync(stagingDir);
    const found = files.find(f => f.startsWith(downloadId) && !f.endsWith('.part') && !f.endsWith('.ytdl') && !f.endsWith('.temp') && !/\.f\d+\.[a-zA-Z0-9]+$/i.test(f));
    if (!found) return null;

    let extractedTitle;
    if (found.includes('__MF__')) {
      const parts = found.split('__MF__');
      if (parts.length > 1) {
        extractedTitle = path.parse(parts[1]).name;
        if (extractedTitle) {
          extractedTitle = extractedTitle.replace(/\.f\d+$/i, '').replace(/\.temp$/i, '').trim();
        }
      }
    }
    return {
      filePath: path.join(stagingDir, found),
      extractedTitle
    };
  }

  cleanupStagingFiles(stagingDir, downloadId) {
    try {
      if (!fs.existsSync(stagingDir)) return;
      const files = fs.readdirSync(stagingDir);
      const now = Date.now();
      for (const f of files) {
        const fullPath = path.join(stagingDir, f);
        if (downloadId && (f.startsWith(downloadId) || f.includes(downloadId))) {
          try { fs.unlinkSync(fullPath); } catch (e) {}
        } else {
          try {
            const stat = fs.statSync(fullPath);
            if (now - stat.mtimeMs > 10 * 60 * 1000) {
              fs.unlinkSync(fullPath);
            }
          } catch (_) {}
        }
      }
      // Preserve stagingDir directory structure to prevent race conditions during concurrent/retry downloads
    } catch (e) {}
  }

  buildYtDlpArgs(url, profile, outputTemplate, ffmpegBinDir) {
    const cleanUrl = url.trim();
    const isYouTube = youtubeTokenManager.isYouTubeUrl(cleanUrl);
    const isSearchQuery = cleanUrl.startsWith('ytsearch');

    const cacheDir = path.join(process.env.LOCALAPPDATA || process.env.APPDATA || os.tmpdir(), 'MediaFetch', '.cache');

    const nodeBin = dependencyManager.getNodeExecutablePath();
    const jsRuntime = (nodeBin === 'node' || !nodeBin) ? 'node' : `node:${nodeBin}`;

    let ytExtArgs = [];
    if (isYouTube) {
      ytExtArgs.push('--remote-components', 'ejs:github');
    }

    const args = [
      '--newline',
      '--continue',
      '--no-playlist',
      '--no-check-certificates',
      '--no-mtime',
      '--cache-dir', cacheDir,
      '--js-runtimes', jsRuntime,
      '--buffer-size', '16M',
      ...ytExtArgs,
      ...(isSearchQuery ? ['--max-downloads', '1', '-i'] : []),
      '--progress-template', 'download:MF_PROGRESS:%(progress._percent_str)s|%(progress._downloaded_bytes_str)s|%(progress._total_bytes_str|progress._total_bytes_estimate_str)s|%(progress._speed_str)s|%(progress._eta_str)s',
      '--print', 'before_dl:MF_TITLE:%(title)s',
      '--retries', '10',
      '--fragment-retries', '10',
      '--file-access-retries', '3',
      '--concurrent-fragments', '16',
      '--socket-timeout', '30',
      '-o', outputTemplate
    ];

    if (ffmpegBinDir) {
      args.push('--ffmpeg-location', ffmpegBinDir);
    }

    const pageUrl = this.item.url || '';
    if (cleanUrl.includes('behance.net') || cleanUrl.includes('vimeo.com') || pageUrl.includes('behance.net')) {
      args.push('--referer', 'https://www.behance.net/');
      args.push('--add-header', 'Referer:https://www.behance.net/');
    } else if (cleanUrl.includes('instagram.com') || pageUrl.includes('instagram.com')) {
      args.push('--referer', 'https://www.instagram.com/');
    } else if (cleanUrl.includes('threads.net') || cleanUrl.includes('threads.com') || pageUrl.includes('threads.net')) {
      args.push('--referer', 'https://www.threads.net/');
    } else if (cleanUrl.includes('x.com') || cleanUrl.includes('twitter.com') || pageUrl.includes('x.com') || pageUrl.includes('twitter.com')) {
      args.push('--referer', 'https://x.com/');
    } else if (cleanUrl.includes('linkedin.com') || pageUrl.includes('linkedin.com')) {
      args.push('--referer', 'https://www.linkedin.com/');
    }

    const hasTimeRange = Boolean(profile.timeRange && (profile.timeRange.start?.trim() || profile.timeRange.end?.trim()));
    if (hasTimeRange && !this.retriedWithoutSections) {
      let start = this.normalizeTime(profile.timeRange.start, '00:00:00');
      let end = profile.timeRange.end ? this.normalizeTime(profile.timeRange.end, '99:59:59') : '99:59:59';
      const startSec = this.parseTimeToSeconds(start);
      const endSec = this.parseTimeToSeconds(end);
      if (endSec > 0 && startSec > endSec) {
        const tmp = start; start = end; end = tmp;
      }
      args.push('--download-sections', `*${start}-${end}`);
      args.push('--force-keyframes-at-cuts');
      // Fast input seeking with connection resiliency:
      args.push('--downloader-args', 'ffmpeg:-threads 0 -reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5');
      this.downloadedWithSections = true;
    } else {
      this.downloadedWithSections = false;
      const aria2cPath = getAria2cExecutablePath();
      if (aria2cPath) {
        args.push('--downloader', aria2cPath, '--downloader-args', 'aria2c:-x16 -s16 -k1M -j16');
      }
    }

    if (!skipCookies) {
      const localAppData = process.env.LOCALAPPDATA || (os.homedir ? path.join(os.homedir(), 'AppData', 'Local') : '');
      const cookiesFilePath = localAppData ? path.join(localAppData, 'MediaFetch', 'cookies.txt') : '';
      if (cookiesFilePath && fs.existsSync(cookiesFilePath) && fs.statSync(cookiesFilePath).size > 10) {
        args.push('--cookies', cookiesFilePath);
      } else {
        const rawCookiesBrowser = settingsManager.getSettings()?.engine?.browserCookies || settingsManager.getSettings()?.engine?.cookiesBrowser || 'none';
        const isWin = process.platform === 'win32';
        const cookiesBrowser = (isWin && rawCookiesBrowser === 'chrome') ? 'none' : rawCookiesBrowser;
        if (cookiesBrowser && cookiesBrowser !== 'none') {
          args.push('--cookies-from-browser', cookiesBrowser);
        }
      }
    }

    const container = (profile.container || 'mp4').toLowerCase();
    const isExplicitVideo = ['mp4', 'mov', 'mkv', 'webm', 'avi'].includes(container);
    const isAudio = !isExplicitVideo && (profile.type === 'audio' || ['mp3', 'wav', 'm4a', 'flac', 'aac', 'ogg'].includes(container));
    const isVideoOnly = profile.type === 'video-only' || profile.presetId === 'video-only';

    let res = 1080;
    if (profile.resolution && typeof profile.resolution === 'number' && profile.resolution > 0) {
      res = profile.resolution;
    } else if (profile.presetId === 'video-4k' || profile.presetId === 'res-2160') {
      res = 2160;
    } else if (profile.presetId === 'video-1440p' || profile.presetId === 'res-1440') {
      res = 1440;
    } else if (profile.presetId === 'video-1080p' || profile.presetId === 'res-1080') {
      res = 1080;
    } else if (profile.presetId === 'video-720p' || profile.presetId === 'res-720') {
      res = 720;
    } else if (profile.presetId === 'video-480p' || profile.presetId === 'res-480') {
      res = 480;
    } else if (profile.presetId === 'video-360p' || profile.presetId === 'res-360') {
      res = 360;
    } else if (profile.presetId === 'best-available' || profile.presetId === 'video-only') {
      res = 9999;
    } else if (typeof profile.presetId === 'string' && profile.presetId.startsWith('res-')) {
      const parsed = parseInt(profile.presetId.replace('res-', ''), 10);
      if (!isNaN(parsed) && parsed > 0) res = parsed;
    }

    if (profile.customFormatId) {
      args.push('-f', profile.customFormatId);
    } else if (isAudio) {
      let targetFormat = (container === 'wav' || container === 'm4a' || container === 'flac') ? container : 'mp3';
      let targetQuality = '0';
      const pId = profile.presetId || '';
      const pLbl = profile.label || '';
      if (pId === 'audio-mp3-128' || pLbl.includes('128')) targetQuality = '128K';
      else if (pId === 'audio-mp3-192' || pLbl.includes('192')) targetQuality = '192K';
      else if (pId === 'audio-mp3-96' || pLbl.includes('96')) targetQuality = '96K';
      else if (pId === 'audio-mp3-320' || pLbl.includes('320')) targetQuality = '320K';

      if (container === 'webm') {
        args.push('-f', 'bestaudio[ext=webm]/bestaudio[acodec=opus]/bestaudio[ext=webm]/bestaudio/best', '-x');
      } else {
        args.push(
          '-f', 'bestaudio/best',
          '-x',
          '--audio-format', targetFormat,
          '--audio-quality', targetQuality
        );
      }
    } else if (isVideoOnly) {
      if (container === 'webm') {
        const fStr = (res >= 9999)
          ? 'bestvideo[ext=webm]/bestvideo[vcodec^=vp]/bestvideo/best'
          : `bestvideo[height=${res}][ext=webm]/bestvideo[height<=?${res}][ext=webm]/bestvideo[height=${res}]/bestvideo[height<=?${res}]/bestvideo/best`;
        args.push('-f', fStr);
      } else {
        if (res >= 9999) {
          args.push('-S', 'res,vcodec:h264');
          args.push('-f', 'bestvideo/best');
        } else {
          args.push('-S', `res:${res},vcodec:h264`);
          args.push('-f', `bestvideo[height=${res}][vcodec^=avc1]/bestvideo[height=${res}][vcodec^=h264]/bestvideo[height<=?${res}][vcodec^=avc1]/bestvideo[height<=?${res}][vcodec^=h264]/bestvideo[height=${res}]/bestvideo[height<=?${res}]/bestvideo/best`);
        }
      }
    } else {
      // Video + Audio: Guaranteed TRUE requested resolution (4K, 1440p, 1080p, 720p, 480p, 360p)
      if (container === 'webm') {
        const fStr = (res >= 9999)
          ? 'bestvideo[ext=webm]+bestaudio[ext=webm]/bestvideo[vcodec^=vp]+bestaudio[acodec^=opus]/bestvideo+bestaudio/best'
          : `bestvideo[height=${res}][ext=webm]+bestaudio[ext=webm]/bestvideo[height<=?${res}][ext=webm]+bestaudio[ext=webm]/bestvideo[height=${res}]+bestaudio/bestvideo[height<=?${res}]+bestaudio/bestvideo+bestaudio/best`;
        args.push('-f', fStr);
      } else {
        if (res >= 9999) {
          args.push('-S', 'res,vcodec:h264,acodec:m4a');
          args.push('-f', 'bestvideo[vcodec^=avc1]+bestaudio[acodec^=mp4a]/bestvideo[vcodec^=avc1]+bestaudio/bestvideo[vcodec^=h264]+bestaudio[acodec^=mp4a]/bestvideo[vcodec^=h264]+bestaudio/bestvideo+bestaudio[acodec^=mp4a]/bestvideo+bestaudio[ext=m4a]/bestvideo+bestaudio/best');
        } else {
          args.push('-S', `res:${res},vcodec:h264,acodec:m4a`);
          args.push('-f', `bestvideo[height=${res}][vcodec^=avc1]+bestaudio[acodec^=mp4a]/bestvideo[height=${res}][vcodec^=avc1]+bestaudio[ext=m4a]/bestvideo[height=${res}][vcodec^=avc1]+bestaudio/bestvideo[height=${res}][vcodec^=h264]+bestaudio[acodec^=mp4a]/bestvideo[height=${res}][vcodec^=h264]+bestaudio/bestvideo[height<=?${res}][vcodec^=avc1]+bestaudio[acodec^=mp4a]/bestvideo[height<=?${res}][vcodec^=avc1]+bestaudio/bestvideo[height<=?${res}][vcodec^=h264]+bestaudio[acodec^=mp4a]/bestvideo[height<=?${res}][vcodec^=h264]+bestaudio/bestvideo[height=${res}]+bestaudio[acodec^=mp4a]/bestvideo[height=${res}]+bestaudio/bestvideo[height<=?${res}]+bestaudio/bestvideo+bestaudio/best`);
        }
      }
    }

    if (!isAudio && ['mp4', 'mkv', 'webm', 'mov'].includes(container)) {
      if (container === 'mov') {
        // Matroska (MKV) accepts AV1, VP9, H.264, AAC, and Opus losslessly without muxer errors.
        // We stage as MKV, and our pro FFmpeg normalizer transcodes/remuxes cleanly to QuickTime MOV.
        args.push('--merge-output-format', 'mkv');
      } else {
        args.push('--merge-output-format', container);
      }
    }

    args.push(cleanUrl);
    return args;
  }
}