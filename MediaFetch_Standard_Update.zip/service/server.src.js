const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { WebSocketServer, WebSocket } = require('ws');

const { execFile } = require('child_process');
const { promisify } = require('util');
const execFileAsync = promisify(execFile);

const v8 = require('v8');
const vm = require('vm');

try {
  v8.setFlagsFromString('--expose_gc');
} catch (_) {}

let runGc = null;
try {
  runGc = vm.runInNewContext('gc');
} catch (_) {
  if (typeof global.gc === 'function') runGc = global.gc;
}

// Bounded stream URL cache to prevent memory bloat on low-end systems
const streamUrlCache = new Map();
const MAX_STREAM_CACHE = 8;

function setStreamUrlCache(key, data) {
  if (streamUrlCache.size >= MAX_STREAM_CACHE) {
    const oldestKey = streamUrlCache.keys().next().value;
    streamUrlCache.delete(oldestKey);
  }
  streamUrlCache.set(key, data);
}

function pruneStreamUrlCache() {
  const now = Date.now();
  for (const [k, v] of streamUrlCache.entries()) {
    if (!v || v.expiresAt <= now) {
      streamUrlCache.delete(k);
    }
  }
}

let lastCompactedHeapMb = null;

function trimMemory() {
  pruneStreamUrlCache();
  try {
    if (runGc) {
      runGc();
      runGc();
    } else if (typeof global.gc === 'function') {
      global.gc();
      global.gc();
    }
  } catch (_) {}
  try {
    const mem = process.memoryUsage();
    const curr = +(mem.heapUsed / (1024 * 1024)).toFixed(1);
    if (!lastCompactedHeapMb || curr < lastCompactedHeapMb) {
      lastCompactedHeapMb = curr;
    }
  } catch (_) {}
}

function getMemoryStats() {
  const mem = process.memoryUsage();
  const heapUsedMb = +(mem.heapUsed / (1024 * 1024)).toFixed(1);
  const heapTotalMb = +(mem.heapTotal / (1024 * 1024)).toFixed(1);
  const rssMb = +(mem.rss / (1024 * 1024)).toFixed(1);

  let displayMb = heapUsedMb;
  if (streamUrlCache.size === 0 && lastCompactedHeapMb) {
    if (heapUsedMb <= lastCompactedHeapMb + 0.8) {
      displayMb = Math.min(lastCompactedHeapMb, heapUsedMb);
    } else {
      lastCompactedHeapMb = heapUsedMb;
    }
  } else {
    lastCompactedHeapMb = heapUsedMb;
  }

  return { heapUsedMb, heapTotalMb, rssMb, displayMb };
}

setInterval(() => {
  trimMemory();
}, 45000);

function getDirSizeBytes(dirPath) {
  let total = 0;
  if (!dirPath || !fs.existsSync(dirPath)) return 0;
  try {
    const entries = fs.readdirSync(dirPath, { withFileTypes: true });
    for (const ent of entries) {
      const full = path.join(dirPath, ent.name);
      try {
        if (ent.isDirectory()) {
          total += getDirSizeBytes(full);
        } else if (ent.isFile()) {
          total += fs.statSync(full).size;
        }
      } catch (_) {}
    }
  } catch (_) {}
  return total;
}

function clearDirFiles(dirPath, preserveRoot = false) {
  let freed = 0;
  if (!dirPath || !fs.existsSync(dirPath)) return 0;
  try {
    const entries = fs.readdirSync(dirPath, { withFileTypes: true });
    for (const ent of entries) {
      const full = path.join(dirPath, ent.name);
      try {
        if (ent.isDirectory()) {
          freed += clearDirFiles(full, false);
          try { fs.rmdirSync(full); } catch (_) {}
        } else if (ent.isFile()) {
          const sz = fs.statSync(full).size;
          fs.unlinkSync(full);
          freed += sz;
        }
      } catch (_) {}
    }
    if (!preserveRoot) {
      try { fs.rmdirSync(dirPath); } catch (_) {}
    }
  } catch (_) {}
  return freed;
}

function getKnownCacheDirs() {
  const dirs = [];
  const appData = (process.env && process.env.LOCALAPPDATA) || (os.homedir ? path.join(os.homedir(), '.mediafetch') : '');
  const mfDir = path.join(appData || '.', 'MediaFetch');

  // yt-dlp cache
  dirs.push(path.join(mfDir, '.cache'));
  if (process.env.APPDATA) dirs.push(path.join(process.env.APPDATA, 'MediaFetch', '.cache'));
  dirs.push(path.join(os.tmpdir(), 'MediaFetch', '.cache'));

  // Staging in AppData
  dirs.push(path.join(mfDir, '.temp_mediafetch'));

  // Target download folders staging
  try {
    const defaultTarget = filesystemManager.resolveTargetDirectory().targetDir;
    if (defaultTarget) dirs.push(path.join(defaultTarget, '.temp_mediafetch'));
  } catch (_) {}

  try {
    const sets = settingsManager.getSettings();
    if (sets && sets.downloads && sets.downloads.customLocation) {
      dirs.push(path.join(sets.downloads.customLocation, '.temp_mediafetch'));
    }
  } catch (_) {}

  try {
    if (globalScope.__mediaFetchLastProjectDir) {
      dirs.push(path.join(globalScope.__mediaFetchLastProjectDir, 'MediaFetch', '.temp_mediafetch'));
      dirs.push(path.join(globalScope.__mediaFetchLastProjectDir, '.temp_mediafetch'));
    }
  } catch (_) {}

  return [...new Set(dirs.filter(d => Boolean(d) && fs.existsSync(d)))];
}

const { logger } = require('./logger.js');
const { settingsManager } = require('./settings.js');
const { historyManager } = require('./history.js');
const { dependencyManager } = require('./dependencies.js');
const { filesystemManager } = require('./filesystem.js');
const { metadataAnalyzer } = require('./analyzer.js');
const { queueManager } = require('./queue.js');
const { diagnosticsCollector } = require('./diagnostics.js');

const globalScope = typeof global !== 'undefined' ? global : (typeof window !== 'undefined' ? window : globalThis);
const nodeProc = typeof process !== 'undefined' ? process : (typeof require !== 'undefined' ? require('process') : null);

class MediaFetchServer {
  constructor(port = 48924) {
    this.port = port;
    this.server = null;
    this.wss = null;
    this.isShuttingDown = false;
    this.lastProjectDirectory = '';
    const appData = (nodeProc && nodeProc.env && nodeProc.env.LOCALAPPDATA) || (os.homedir ? path.join(os.homedir(), '.mediafetch') : '');
    const mfDir = path.join(appData || '.', 'MediaFetch');
    filesystemManager.ensureDirExists(mfDir);
    this.lockPath = path.join(mfDir, 'service.lock');
  }

  async start() {
    return new Promise((resolve, reject) => {
      this.server = http.createServer((req, res) => {
        this.handleHttpRequest(req, res);
      });

      this.wss = new WebSocketServer({ server: this.server });
      this.setupWebSocket();
      this.setupQueueEvents();

      this.wss.on('error', (err) => {
        logger.warn('WebSocketServer notice:', err?.message || err);
      });

      this.server.on('error', (err) => {
        if (err.code === 'EADDRINUSE') {
          logger.warn(`Port ${this.port} already in use. A MediaFetch service instance is already running.`);
          resolve();
          return;
        } else {
          logger.error('Server error:', err);
          reject(err);
        }
      });

      this.server.listen(this.port, '127.0.0.1', () => {
        const addr = this.server?.address();
        if (addr && typeof addr === 'object') {
          this.port = addr.port;
        }
        logger.info(`MediaFetch local download service running on http://127.0.0.1:${this.port}`);
        this.createLockfile();
        this.setupProcessHandlers();
        if (typeof globalScope.gc === 'function') {
          setInterval(() => {
            try { globalScope.gc(); } catch (_) {}
          }, 60000);
        }

        // Low-end device memory & cache optimizer (runs every 3 minutes)
        setInterval(() => {
          try {
            pruneStreamUrlCache();
            const dirs = getKnownCacheDirs();
            const now = Date.now();
            for (const d of dirs) {
              if (d.endsWith('.temp_mediafetch') && fs.existsSync(d)) {
                try {
                  const files = fs.readdirSync(d);
                  for (const f of files) {
                    const fp = path.join(d, f);
                    try {
                      const st = fs.statSync(fp);
                      if (now - st.mtimeMs > 3600 * 1000) {
                        fs.unlinkSync(fp);
                      }
                    } catch (_) {}
                  }
                  if (fs.readdirSync(d).length === 0) {
                    fs.rmdirSync(d);
                  }
                } catch (_) {}
              }
            }
            if (typeof globalScope.gc === 'function') {
              globalScope.gc();
            }
          } catch (_) {}
        }, 60 * 1000);

        resolve(this.port);
      });
    });
  }

  async stop() {
    this.isShuttingDown = true;
    this.removeLockfile();
    return new Promise((resolve) => {
      if (this.wss) this.wss.close();
      if (this.server) {
        this.server.close(() => {
          logger.info('MediaFetch service stopped.');
          resolve();
        });
      } else {
        resolve();
      }
    });
  }

  createLockfile() {
    try {
      const data = {
        port: this.port,
        pid: process.pid,
        startTime: Date.now()
      };
      fs.writeFileSync(this.lockPath, JSON.stringify(data, null, 2), 'utf-8');
    } catch (e) {
      logger.error('Failed to create lockfile:', e);
    }
  }

  removeLockfile() {
    try {
      if (fs.existsSync(this.lockPath)) fs.unlinkSync(this.lockPath);
    } catch (e) {}
  }

  setupProcessHandlers() {
    const cleanup = () => {
      if (!this.isShuttingDown) {
        this.stop().then(() => process.exit(0));
      }
    };
    process.on('SIGINT', cleanup);
    process.on('SIGTERM', cleanup);
    process.on('exit', () => this.removeLockfile());

    process.on('uncaughtException', (err, origin) => {
      logger.error(`[Process] Uncaught Exception at ${origin}: ${err?.stack || err}`);
      // Do not exit for non-fatal errors - keep service daemon alive for pending downloads/imports
    });

    process.on('unhandledRejection', (reason, promise) => {
      logger.error(`[Process] Unhandled Rejection: ${reason?.stack || reason}`);
      // Keep process alive
    });
  }

  setupQueueEvents() {
    queueManager.subscribe((event) => {
      if (event.type === 'QUEUE_UPDATED' && event.items) {
        this.broadcast({ type: 'QUEUE_UPDATED', payload: event.items });
      } else if (event.type === 'DOWNLOAD_PROGRESS' && event.item) {
        this.broadcast({ type: 'DOWNLOAD_PROGRESS', payload: { id: event.item.id, item: event.item } });
      } else if (event.type === 'DOWNLOAD_COMPLETED' && event.item && event.historyEntry) {
        const clientCount = this.wss?.clients ? Array.from(this.wss.clients).filter(c => c.readyState === WebSocket.OPEN).length : 0;
        logger.info(`DOWNLOAD_COMPLETED emitted for ${event.item.id} (connected clients: ${clientCount})`);
        this.broadcast({ type: 'DOWNLOAD_COMPLETED', payload: { id: event.item.id, item: event.item, historyEntry: event.historyEntry } });
        if (typeof globalScope.gc === 'function') {
          setTimeout(() => { try { globalScope.gc(); } catch (_) {} }, 500);
        }
      } else if (event.type === 'DOWNLOAD_FAILED' && event.item) {
        this.broadcast({ type: 'DOWNLOAD_FAILED', payload: { id: event.item.id, item: event.item } });
        if (typeof globalScope.gc === 'function') {
          setTimeout(() => { try { globalScope.gc(); } catch (_) {} }, 500);
        }
      }
    });
  }

  setupWebSocket() {
    if (!this.wss) return;
    this.wss.on('connection', (ws) => {
      logger.debug('New WebSocket client connected.');
      ws.send(JSON.stringify({ type: 'QUEUE_UPDATED', payload: queueManager.getItems() }));
      ws.send(JSON.stringify({ type: 'SETTINGS_LOADED', payload: settingsManager.getSettings() }));

      ws.on('message', async (data) => {
        try {
          const msg = JSON.parse(data.toString('utf-8'));
          await this.handleClientMessage(ws, msg);
        } catch (e) {
          logger.error('Failed to parse client message:', e);
        }
      });

      ws.on('close', () => {
        logger.debug('WebSocket client disconnected.');
      });
    });
  }

  broadcast(msg) {
    if (!this.wss) return;
    const str = JSON.stringify(msg);
    for (const client of this.wss.clients) {
      if (client.readyState === WebSocket.OPEN) {
        client.send(str);
      }
    }
  }

  async handleClientMessage(ws, msg) {
    switch (msg.type) {
      case 'ITEM_IMPORTED': {
        const { id, ok, error } = msg.payload || {};
        if (id) {
          queueManager.markItemImported(id, ok, error);
        }
        break;
      }

      case 'PING':
        ws.send(JSON.stringify({ type: 'PONG', payload: { timestamp: Date.now() } }));
        break;

      case 'RESTART_SERVICE':
      case 'SHUTDOWN_SERVICE': {
        logger.info('Service shutdown requested by client.');
        ws.send(JSON.stringify({ type: 'SERVICE_SHUTTING_DOWN', payload: { restart: true } }));
        setTimeout(async () => {
          try { await this.stop(); } catch (_) {}
          process.exit(0);
        }, 300);
        break;
      }

      case 'ANALYZE_URL': {
        const { url, timeoutMs } = msg.payload;
        const effectiveTimeout = timeoutMs ? Math.min(timeoutMs, 30000) : 25000;
        ws.send(JSON.stringify({ type: 'ANALYSIS_STARTED', payload: { url } }));
        try {
          if (metadataAnalyzer.isPlaylistUrl(url)) {
            const playlist = await metadataAnalyzer.analyzePlaylist(url, effectiveTimeout);
            try {
              ws.send(JSON.stringify({ type: 'PLAYLIST_ANALYSIS_SUCCESS', payload: playlist }));
              ws.send(JSON.stringify({ type: 'PLAYLIST_METADATA_RESULT', payload: playlist }));
            } catch (_) {}
            this.broadcast({ type: 'PLAYLIST_ANALYSIS_SUCCESS', payload: playlist });
            this.broadcast({ type: 'PLAYLIST_METADATA_RESULT', payload: playlist });
            break;
          }
          const meta = await metadataAnalyzer.analyzeUrl(url, effectiveTimeout);
          if (meta.isPlaylist || meta.isCarousel || (meta.items && meta.items.length > 1)) {
            try {
              ws.send(JSON.stringify({ type: 'PLAYLIST_ANALYSIS_SUCCESS', payload: meta }));
              ws.send(JSON.stringify({ type: 'PLAYLIST_METADATA_RESULT', payload: meta }));
            } catch (_) {}
            this.broadcast({ type: 'PLAYLIST_ANALYSIS_SUCCESS', payload: meta });
            this.broadcast({ type: 'PLAYLIST_METADATA_RESULT', payload: meta });
          } else {
            try {
              ws.send(JSON.stringify({ type: 'ANALYSIS_SUCCESS', payload: meta }));
              ws.send(JSON.stringify({ type: 'METADATA_RESULT', payload: meta }));
            } catch (_) {}
            this.broadcast({ type: 'ANALYSIS_SUCCESS', payload: meta });
            this.broadcast({ type: 'METADATA_RESULT', payload: meta });
          }
        } catch (err) {
          const errPayload = { url, error: err.message || 'Analysis failed', details: err.details, category: err.category || 'UNKNOWN_ERROR' };
          try {
            ws.send(JSON.stringify({ type: 'ANALYSIS_ERROR', payload: errPayload }));
            ws.send(JSON.stringify({ type: 'ANALYSIS_FAILED', payload: errPayload }));
          } catch (_) {}
          this.broadcast({ type: 'ANALYSIS_ERROR', payload: errPayload });
          this.broadcast({ type: 'ANALYSIS_FAILED', payload: errPayload });
        }
        break;
      }

      case 'ANALYZE_PLAYLIST': {
        const { url } = msg.payload;
        try {
          if (!metadataAnalyzer.isPlaylistUrl(url)) {
            const single = await metadataAnalyzer.analyzeUrl(url);
            ws.send(JSON.stringify({ type: 'METADATA_ANALYZED', payload: single }));
            ws.send(JSON.stringify({ type: 'ANALYSIS_SUCCESS', payload: single }));
            break;
          }
          const playlist = await metadataAnalyzer.analyzePlaylist(url);
          ws.send(JSON.stringify({ type: 'PLAYLIST_ANALYSIS_SUCCESS', payload: playlist }));
          ws.send(JSON.stringify({ type: 'PLAYLIST_METADATA_RESULT', payload: playlist }));
        } catch (err) {
          const pErr = { url, error: err.message || 'Playlist analysis failed' };
          ws.send(JSON.stringify({ type: 'PLAYLIST_ANALYSIS_ERROR', payload: pErr }));
          ws.send(JSON.stringify({ type: 'PLAYLIST_ANALYSIS_FAILED', payload: pErr }));
        }
        break;
      }

      case 'START_PLAYLIST_DOWNLOAD':
      case 'ADD_PLAYLIST_ITEMS': {
        const { items, profile, projectContext, targetDirectory, customFolderName, preserveSubfolders, autoImport, zipPackage, playlistTitle, isCloud, edition, targetHost } = msg.payload;
        if (projectContext?.projectDirectory) {
          this.lastProjectDirectory = projectContext.projectDirectory;
        }
        const resolvedTargetHost = targetHost || msg.payload?.metadata?.targetHost || projectContext?.appId || '';
        const itemEdition = edition || msg.edition || 'standard';
        const batchId = zipPackage ? ('batch_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7)) : undefined;

        if (zipPackage) {
          const resolved = filesystemManager.resolveTargetDirectory(projectContext, targetDirectory);
          const baseTargetDir = resolved.targetDir;
          let rawArchive = (customFolderName || playlistTitle || (isCloud ? 'Cloud_Media' : 'Playlist_Media')).replace(/\.zip$/i, '').trim();
          let cleanArchive = rawArchive.replace(/[\\/:*?"<>|]/g, '_').replace(/[.\s]+$/g, '').trim();
          if (!cleanArchive) cleanArchive = isCloud ? 'Cloud_Media' : 'Playlist_Media';
          // Dedicated hidden staging folder strictly for zipping - NEVER leaves a loose unzipped folder on disk
          const stagingFolder = path.join(baseTargetDir, '.mf_zip_staging_' + batchId);
          filesystemManager.ensureDirExists(stagingFolder);
          queueManager.registerZipBatch(batchId, {
            totalItems: items.length,
            archiveName: cleanArchive,
            rootFolder: stagingFolder,
            baseDir: baseTargetDir
          });
        }

        for (const item of items) {
          const itemSubFolder = (preserveSubfolders === false) ? '' : (item.subFolderName || '');
          const isItemImage = item.mediaType === 'image' || item.type === 'image' || item.isImage || /\.(jpe?g|png|webp|gif|bmp|svg|avif)($|\?)/i.test(item.url || '') || /\.(jpe?g|png|webp|gif|bmp|svg|avif)($|\?)/i.test(item.title || '');
          const itemProfile = isItemImage ? {
            ...profile,
            type: 'image',
            container: (profile.container === 'png' || profile.container === 'webp') ? profile.container : 'jpg',
            remuxToMp4: false
          } : profile;
          queueManager.addItem(item.url, itemProfile, projectContext, targetDirectory, {
            title: item.title,
            thumbnail: item.thumbnail,
            duration: item.duration,
            downloadQuery: item.downloadQuery,
            uploader: item.uploader || item.channel,
            subFolderName: itemSubFolder,
            customFolderName: customFolderName || item.customFolderName || '',
            autoImport: zipPackage ? false : (autoImport !== false),
            isPlaylist: true,
            isCloud: Boolean(isCloud || item.isCloud),
            playlistTitle: playlistTitle || '',
            edition: itemEdition,
            targetHost: resolvedTargetHost,
            batchId,
            zipPackage: Boolean(zipPackage),
            mediaType: isItemImage ? 'image' : (item.mediaType || item.type || 'video'),
            type: isItemImage ? 'image' : (item.type || item.mediaType || 'video')
          });
        }
        queueManager.processQueue();
        this.broadcast({ type: 'QUEUE_UPDATED', payload: queueManager.getItems() });
        break;
      }

      case 'START_DOWNLOAD':
      case 'ADD_DOWNLOAD': {
        const { url, profile, projectContext, targetDirectory, metadata, edition } = msg.payload;

        // Automatically intercept playlists, cloud links, and carousels when user clicks download directly WITHOUT pre-analyzed metadata
        const hasPreAnalyzedSingleMedia = Boolean(metadata && !metadata.isPlaylist && !metadata.isCarousel && (!metadata.items || metadata.items.length <= 1));
        if (!hasPreAnalyzedSingleMedia) {
          if (metadataAnalyzer.isPlaylistUrl(url)) {
            logger.info(`START_DOWNLOAD called on playlist/multi-item URL (${url}), routing to playlist modal...`);
            try {
              const playlist = await metadataAnalyzer.analyzePlaylist(url);
              ws.send(JSON.stringify({ type: 'PLAYLIST_ANALYSIS_SUCCESS', payload: playlist }));
              ws.send(JSON.stringify({ type: 'PLAYLIST_METADATA_RESULT', payload: playlist }));
              return;
            } catch (err) {
              logger.warn(`Failed to auto-analyze playlist on START_DOWNLOAD:`, err.message);
            }
          }
          if (url && (url.includes('instagram.com/p/') || url.includes('instagram.com/reel/') || url.includes('instagram.com/reels/'))) {
            try {
              const igRes = await metadataAnalyzer.analyzeInstagram(url);
              if (igRes && (igRes.isPlaylist || igRes.isCarousel)) {
                logger.info(`START_DOWNLOAD called on Instagram carousel (${url}), routing to carousel modal...`);
                ws.send(JSON.stringify({ type: 'PLAYLIST_ANALYSIS_SUCCESS', payload: igRes }));
                ws.send(JSON.stringify({ type: 'PLAYLIST_METADATA_RESULT', payload: igRes }));
                return;
              }
            } catch (_) {}
          }
          if (url && (url.includes('behance.net/gallery/') || url.includes('behance.net/project'))) {
            try {
              const behanceRes = await metadataAnalyzer.analyzeBehance(url);
              if (behanceRes && (behanceRes.isPlaylist || behanceRes.isCarousel || (behanceRes.items && behanceRes.items.length > 1))) {
                logger.info(`START_DOWNLOAD called on Behance multi-media (${url}), routing to modal...`);
                ws.send(JSON.stringify({ type: 'PLAYLIST_ANALYSIS_SUCCESS', payload: behanceRes }));
                ws.send(JSON.stringify({ type: 'PLAYLIST_METADATA_RESULT', payload: behanceRes }));
                return;
              }
            } catch (_) {}
          }
          if (url && (url.includes('threads.net') || url.includes('threads.com'))) {
            try {
              const thRes = await metadataAnalyzer.analyzeThreads(url);
              if (thRes && (thRes.isPlaylist || thRes.isCarousel || (thRes.items && thRes.items.length > 1))) {
                logger.info(`START_DOWNLOAD called on Threads carousel (${url}), routing to modal...`);
                ws.send(JSON.stringify({ type: 'PLAYLIST_ANALYSIS_SUCCESS', payload: thRes }));
                ws.send(JSON.stringify({ type: 'PLAYLIST_METADATA_RESULT', payload: thRes }));
                return;
              }
            } catch (_) {}
          }
          if (url && (url.includes('pinterest.com') || url.includes('pin.it'))) {
            try {
              const pinRes = await metadataAnalyzer.analyzePinterest(url);
              if (pinRes && (pinRes.isPlaylist || pinRes.isCarousel || (pinRes.items && pinRes.items.length > 1))) {
                logger.info(`START_DOWNLOAD called on Pinterest multi-item (${url}), routing to modal...`);
                ws.send(JSON.stringify({ type: 'PLAYLIST_ANALYSIS_SUCCESS', payload: pinRes }));
                ws.send(JSON.stringify({ type: 'PLAYLIST_METADATA_RESULT', payload: pinRes }));
                return;
              }
            } catch (_) {}
          }
        }

        const itemEdition = edition || metadata?.edition || msg.edition || 'standard';
        if (projectContext?.projectDirectory) {
          this.lastProjectDirectory = projectContext.projectDirectory;
        }
        const targetHost = msg.payload?.targetHost || metadata?.targetHost || projectContext?.appId || '';
        queueManager.addItem(url, profile, projectContext, targetDirectory, {
          ...(metadata || {}),
          edition: itemEdition,
          targetHost
        });
        this.broadcast({ type: 'QUEUE_UPDATED', payload: queueManager.getItems() });
        break;
      }

      case 'UPDATE_PROJECT_CONTEXT': {
        if (msg.payload?.projectDirectory) {
          this.lastProjectDirectory = msg.payload.projectDirectory;
          globalScope.__mediaFetchLastProjectDir = this.lastProjectDirectory;
          logger.info(`Updated cached active project directory: ${this.lastProjectDirectory}`);
        }
        break;
      }

      case 'PAUSE_DOWNLOAD': {
        const id = typeof msg.payload === 'object' && msg.payload ? msg.payload.id : msg.payload;
        if (id) {
          queueManager.pauseItem(id);
        } else {
          for (const it of queueManager.getItems()) {
            if (it.status === 'downloading' || it.status === 'waiting') {
              queueManager.pauseItem(it.id);
            }
          }
        }
        this.broadcast({ type: 'QUEUE_UPDATED', payload: queueManager.getItems() });
        break;
      }

      case 'RESUME_DOWNLOAD': {
        const id = typeof msg.payload === 'object' && msg.payload ? msg.payload.id : msg.payload;
        if (id) {
          queueManager.resumeItem(id);
        } else {
          queueManager.resumeAllInterrupted();
        }
        this.broadcast({ type: 'QUEUE_UPDATED', payload: queueManager.getItems() });
        break;
      }

      case 'CANCEL_DOWNLOAD': {
        const id = typeof msg.payload === 'object' && msg.payload ? msg.payload.id : msg.payload;
        if (id) queueManager.cancelItem(id);
        this.broadcast({ type: 'QUEUE_UPDATED', payload: queueManager.getItems() });
        break;
      }

      case 'RETRY_DOWNLOAD': {
        const id = typeof msg.payload === 'object' && msg.payload ? msg.payload.id : msg.payload;
        if (id) queueManager.retryItem(id);
        this.broadcast({ type: 'QUEUE_UPDATED', payload: queueManager.getItems() });
        break;
      }

      case 'CLEAR_COMPLETED': {
        const edition = msg.payload?.edition || msg.edition;
        queueManager.clearCompleted(edition);
        this.broadcast({ type: 'QUEUE_UPDATED', payload: queueManager.getItems() });
        break;
      }

      case 'CLEAR_ALL': {
        const edition = msg.payload?.edition || msg.edition;
        queueManager.clearAll(edition);
        this.broadcast({ type: 'QUEUE_UPDATED', payload: queueManager.getItems() });
        break;
      }

      case 'GET_QUEUE':
        ws.send(JSON.stringify({ type: 'QUEUE_UPDATED', payload: queueManager.getItems() }));
        break;

      case 'GET_SETTINGS':
        ws.send(JSON.stringify({ type: 'SETTINGS_LOADED', payload: settingsManager.getSettings() }));
        break;

      case 'UPDATE_SETTINGS': {
        const updated = settingsManager.updateSettings(msg.payload);
        this.broadcast({ type: 'SETTINGS_LOADED', payload: updated });
        break;
      }

      case 'GET_DIAGNOSTICS': {
        const diag = await diagnosticsCollector.collectDiagnostics(this.port);
        ws.send(JSON.stringify({ type: 'DIAGNOSTICS_RESULT', payload: diag }));
        break;
      }

      case 'RUN_SYSTEM_CHECK':
      case 'RUN_SYSTEM_DIAGNOSTICS': {
        const diag = await diagnosticsCollector.collectDiagnostics(this.port);
        ws.send(JSON.stringify({ type: 'SYSTEM_DIAGNOSTICS_RESULT', payload: diag }));
        break;
      }

      case 'INSTALL_DEPENDENCY': {
        const { name } = msg.payload;
        if (name === 'all' || name === 'ytdlp' || name === 'yt-dlp') {
          const res = await dependencyManager.installYtDlp((stage, progress, message) => {
            ws.send(JSON.stringify({ type: 'DEPENDENCY_INSTALL_PROGRESS', payload: { name: 'yt-dlp', stage, progress, message } }));
          });
          ws.send(JSON.stringify({ type: 'DEPENDENCY_INSTALL_RESULT', payload: { name: 'yt-dlp', success: res.success, error: res.error, message: res.version } }));
        }
        if (name === 'all' || name === 'ffmpeg' || name === 'FFmpeg') {
          const res = await dependencyManager.installFfmpeg((stage, progress, message) => {
            ws.send(JSON.stringify({ type: 'DEPENDENCY_INSTALL_PROGRESS', payload: { name: 'ffmpeg', stage, progress, message } }));
          });
          ws.send(JSON.stringify({ type: 'DEPENDENCY_INSTALL_RESULT', payload: { name: 'ffmpeg', success: res.success, error: res.error, message: res.version } }));
        }
        break;
      }

      case 'UPDATE_YTDLP': {
        const active = queueManager.getActiveCount() > 0;
        const res = await dependencyManager.updateYtDlp(active, (stage, progress, message) => {
          ws.send(JSON.stringify({ type: 'DEPENDENCY_INSTALL_PROGRESS', payload: { name: 'yt-dlp', stage, progress, message } }));
        });
        ws.send(JSON.stringify({ type: 'DEPENDENCY_INSTALL_RESULT', payload: { name: 'yt-dlp', success: res.success, error: res.error, message: res.version } }));
        break;
      }

      case 'GET_HISTORY':
        ws.send(JSON.stringify({ type: 'HISTORY_LOADED', payload: historyManager.getHistory() }));
        break;

      case 'CLEAR_HISTORY':
        historyManager.clearHistory();
        ws.send(JSON.stringify({ type: 'HISTORY_LOADED', payload: [] }));
        break;

      case 'REMOVE_HISTORY_ITEM':
        historyManager.removeHistoryItem(msg.payload.id);
        ws.send(JSON.stringify({ type: 'HISTORY_LOADED', payload: historyManager.getHistory() }));
        break;

      case 'CHECK_DUPLICATE': {
        const { title, container, targetDirectory } = msg.payload;
        const filename = filesystemManager.sanitizeFilename(title, container);
        const dup = filesystemManager.checkDuplicate(targetDirectory, filename);
        ws.send(JSON.stringify({
          type: 'DUPLICATE_CHECK_RESULT',
          payload: { exists: dup.exists, existingFilePath: dup.filePath, existingFileSize: dup.size }
        }));
        break;
      }

      case 'OPEN_FOLDER_DIALOG': {
        try {
          const { exec } = await import('child_process');
          if (process.platform === 'win32') {
            const candidates = [
              path.join(__dirname, 'modern_folder_picker.ps1'),
              path.join(__dirname, 'service', 'modern_folder_picker.ps1'),
              path.join(__dirname, '..', 'service', 'modern_folder_picker.ps1')
            ];
            let pickerScript = candidates.find((c) => fs.existsSync(c));
            if (!pickerScript) {
              const os = await import('os');
              pickerScript = path.join(os.tmpdir(), 'mediafetch_folder_picker.ps1');
              fs.writeFileSync(pickerScript, `Add-Type -AssemblyName System.Windows.Forms
function Show-ModernFolderPicker($Title) {
    try {
        $AssemblyFullName = 'System.Windows.Forms, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089'
        $Assembly = [System.Reflection.Assembly]::Load($AssemblyFullName)
        $OpenFileDialog = New-Object System.Windows.Forms.OpenFileDialog
        $OpenFileDialog.AddExtension = $false
        $OpenFileDialog.CheckFileExists = $false
        $OpenFileDialog.DereferenceLinks = $true
        $OpenFileDialog.Filter = "Folders|\`n"
        $OpenFileDialog.Multiselect = $false
        $OpenFileDialog.Title = if ($Title) { $Title } else { "Select MediaFetch Destination Folder" }
        $OpenFileDialogType = $OpenFileDialog.GetType()
        $FileDialogInterfaceType = $Assembly.GetType('System.Windows.Forms.FileDialogNative+IFileDialog')
        $IFileDialog = $OpenFileDialogType.GetMethod('CreateVistaDialog',@('NonPublic','Public','Static','Instance')).Invoke($OpenFileDialog,$null)
        $null = $OpenFileDialogType.GetMethod('OnBeforeVistaDialog',@('NonPublic','Public','Static','Instance')).Invoke($OpenFileDialog,$IFileDialog)
        [uint32]$PickFoldersOption = $Assembly.GetType('System.Windows.Forms.FileDialogNative+FOS').GetField('FOS_PICKFOLDERS').GetValue($null)
        $FolderOptions = $OpenFileDialogType.GetMethod('get_Options',@('NonPublic','Public','Static','Instance')).Invoke($OpenFileDialog,$null) -bor $PickFoldersOption
        $null = $FileDialogInterfaceType.GetMethod('SetOptions',@('NonPublic','Public','Static','Instance')).Invoke($IFileDialog,$FolderOptions)
        $VistaDialogEvent = [System.Activator]::CreateInstance($AssemblyFullName,'System.Windows.Forms.FileDialog+VistaDialogEvents',$false,0,$null,$OpenFileDialog,$null,$null).Unwrap()
        [uint32]$AdviceCookie = 0
        $AdvisoryParameters = @($VistaDialogEvent,$AdviceCookie)
        $AdviseResult = $FileDialogInterfaceType.GetMethod('Advise',@('NonPublic','Public','Static','Instance')).Invoke($IFileDialog,$AdvisoryParameters)
        $AdviceCookie = $AdvisoryParameters[1]
        $Result = $FileDialogInterfaceType.GetMethod('Show',@('NonPublic','Public','Static','Instance')).Invoke($IFileDialog,[System.IntPtr]::Zero)
        $null = $FileDialogInterfaceType.GetMethod('Unadvise',@('NonPublic','Public','Static','Instance')).Invoke($IFileDialog,$AdviceCookie)
        if ($Result -eq 0) {
            try {
                $files = $OpenFileDialogType.GetMethod('ProcessVistaFiles', [System.Reflection.BindingFlags]'NonPublic,Instance').Invoke($OpenFileDialog, @($IFileDialog))
                if ($files -and $files.Length -gt 0 -and !([string]::IsNullOrEmpty($files[0]))) {
                    return $files[0]
                }
            } catch {}
            if (![string]::IsNullOrEmpty($OpenFileDialog.FileName)) {
                return $OpenFileDialog.FileName
            }
        }
        return $null
    } catch {
        return $null
    }
}
$title = if ($args.Count -gt 0 -and $args[0]) { $args[0] } else { "Select MediaFetch Destination Folder" }
$p = Show-ModernFolderPicker -Title $title
if ($p) { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8; [Console]::WriteLine($p) }
`, 'utf8');
            }
            execFile('powershell.exe', [
              '-WindowStyle', 'Hidden',
              '-NoLogo',
              '-STA',
              '-NoProfile',
              '-ExecutionPolicy', 'Bypass',
              '-File', pickerScript,
              'Select MediaFetch Destination Folder'
            ], { windowsHide: true, encoding: 'utf8' }, (err, stdout) => {
              const selected = (stdout || '').trim();
              if (selected) {
                ws.send(JSON.stringify({ type: 'FOLDER_SELECTED', payload: { folderPath: selected } }));
              }
            });
          } else if (process.platform === 'darwin') {
            exec(`osascript -e 'POSIX path of (choose folder with prompt "Select MediaFetch Destination Folder")'`, (err, stdout) => {
              const selected = (stdout || '').trim();
              if (selected) {
                ws.send(JSON.stringify({ type: 'FOLDER_SELECTED', payload: { folderPath: selected } }));
              }
            });
          }
        } catch (dialogErr) {
          logger.error('Failed to open native folder dialog:', dialogErr);
        }
        break;
      }

      case 'GET_CACHE_STATS': {
        let tempStorageBytes = 0;
        const dirs = getKnownCacheDirs();
        for (const d of dirs) {
          tempStorageBytes += getDirSizeBytes(d);
        }
        const appData = (nodeProc && nodeProc.env && nodeProc.env.LOCALAPPDATA) || (os.homedir ? path.join(os.homedir(), '.mediafetch') : '');
        const logsDir = path.join(appData || '.', 'MediaFetch', 'logs');
        const logBytes = getDirSizeBytes(logsDir);
        const ram = getMemoryStats();
        ws.send(JSON.stringify({
          type: 'CACHE_STATS',
          payload: {
            ram,
            streamCacheCount: streamUrlCache.size,
            tempStorageBytes,
            logBytes,
            totalCacheBytes: tempStorageBytes + logBytes,
            totalCacheMb: +((tempStorageBytes + logBytes) / (1024 * 1024)).toFixed(2)
          }
        }));
        break;
      }

      case 'CLEAR_CACHE': {
        let freedBytes = 0;
        const dirs = getKnownCacheDirs();
        for (const d of dirs) {
          freedBytes += clearDirFiles(d, false);
        }
        streamUrlCache.clear();
        try {
          const appData = (nodeProc && nodeProc.env && nodeProc.env.LOCALAPPDATA) || (os.homedir ? path.join(os.homedir(), '.mediafetch') : '');
          const logFile = path.join(appData || '.', 'MediaFetch', 'logs', 'service.log');
          if (fs.existsSync(logFile)) {
            const sz = fs.statSync(logFile).size;
            if (sz > 0) {
              fs.truncateSync(logFile, 0);
              freedBytes += sz;
            }
          }
        } catch (_) {}

        trimMemory();
        const ram = getMemoryStats();
        ws.send(JSON.stringify({
          type: 'CACHE_CLEARED',
          payload: {
            freedBytes,
            freedMb: +(freedBytes / (1024 * 1024)).toFixed(2),
            totalCacheBytes: 0,
            totalCacheMb: 0.00,
            ram
          }
        }));
        break;
      }
    }
  }

  handleHttpRequest(req, res) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    if (req.method === 'OPTIONS') {
      res.writeHead(200);
      res.end();
      return;
    }

    const url = new URL(req.url || '/', `http://127.0.0.1:${this.port}`);
    const pathname = url.pathname;

    const jsonRes = (status, data) => {
      res.writeHead(status, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(data));
    };

    const convertImageToPreferredFormat = async (srcFile, targetFormat) => {
      if (!srcFile || !fs.existsSync(srcFile)) return srcFile;
      const targetExt = (targetFormat === 'jpeg' ? 'jpg' : (targetFormat || 'png')).toLowerCase();
      const currentExt = path.extname(srcFile).toLowerCase().replace('.', '');
      if (currentExt === targetExt || (currentExt === 'jpeg' && targetExt === 'jpg') || (currentExt === 'jpg' && targetExt === 'jpeg')) {
        return srcFile;
      }
      const destFile = srcFile.replace(/\.[^.]+$/, `.${targetExt}`);
      try {
        const ffmpegPath = await dependencyManager.getFfmpegExecutablePath();
        if (fs.existsSync(ffmpegPath)) {
          const args = ['-i', srcFile, '-y'];
          if (targetExt === 'jpg') {
            args.push('-q:v', '1'); // 100% highest JPEG quality
          } else if (targetExt === 'webp') {
            args.push('-lossless', '1');
          }
          args.push(destFile);
          await execFileAsync(ffmpegPath, args, { windowsHide: true, timeout: 15000 });
          if (fs.existsSync(destFile) && fs.statSync(destFile).size > 100) {
            try { fs.unlinkSync(srcFile); } catch (_) {}
            return destFile;
          }
        }
      } catch (convErr) {
        logger.warn('Image format conversion notice:', convErr.message);
      }
      return srcFile;
    };

    if (pathname === '/health' || pathname === '/api/health' || pathname === '/') {
      jsonRes(200, { status: 'ok', port: this.port, uptime: process.uptime() });
      return;
    }

    if (pathname === '/api/pending-imports' && req.method === 'GET') {
      try {
        const pending = typeof queueManager.getPendingImports === 'function' ? queueManager.getPendingImports() : [];
        jsonRes(200, { success: true, items: pending });
      } catch (err) {
        jsonRes(500, { success: false, error: err?.message || 'Failed to get pending imports' });
      }
      return;
    }

    if (pathname.startsWith('/api/imports/') && pathname.endsWith('/ack') && req.method === 'POST') {
      try {
        const parts = pathname.split('/');
        // /api/imports/:id/ack -> parts[3] is :id
        const id = parts[3];
        if (id) {
          queueManager.markItemImported(id, true);
          jsonRes(200, { success: true, id, status: 'imported' });
        } else {
          jsonRes(400, { success: false, error: 'Missing import id' });
        }
      } catch (err) {
        jsonRes(500, { success: false, error: err?.message || 'Failed to ack import' });
      }
      return;
    }

    if (pathname === '/api/clipboard' && (req.method === 'GET' || req.method === 'POST')) {
      (async () => {
        try {
          const isWin = process.platform === 'win32';
          let clipText = '';
          if (isWin) {
            const { stdout } = await execFileAsync('powershell.exe', ['-NoProfile', '-Command', 'Get-Clipboard'], {
              windowsHide: true,
              timeout: 2500
            });
            clipText = (stdout || '').trim();
          } else {
            const { stdout } = await execFileAsync('pbpaste', [], { timeout: 2500 });
            clipText = (stdout || '').trim();
          }
          jsonRes(200, { success: true, text: clipText });
        } catch (clipErr) {
          logger.warn('Clipboard read notice:', clipErr.message);
          jsonRes(200, { success: false, text: '' });
        }
      })();
      return;
    }

    if (pathname === '/api/clipboard/paste-media' && (req.method === 'GET' || req.method === 'POST')) {
      (async () => {
        try {
          const isWin = process.platform === 'win32';
          const isMac = process.platform === 'darwin';
          const nowStr = new Date().toISOString().replace(/[:.]/g, '-');
          
          const rawFormat = (url.searchParams.get('format') || '').toLowerCase().trim();
          const currentSettings = typeof settingsManager.getSettings === 'function' ? settingsManager.getSettings() : {};
          let preferredFormat = rawFormat || currentSettings?.downloads?.clipboardFormat || 'png';
          if (preferredFormat === 'jpeg') preferredFormat = 'jpg';
          if (!['png', 'jpg', 'webp'].includes(preferredFormat)) preferredFormat = 'png';
          
          let targetDir = '';
          const projDirParam = (url.searchParams.get('projectDir') || url.searchParams.get('projectDirectory') || this.lastProjectDirectory || '').trim();
          if (projDirParam && projDirParam.length > 0) {
            try {
              if (fs.existsSync(projDirParam)) {
                targetDir = path.join(projDirParam, 'MediaFetch', 'Clipboard');
              }
            } catch (_) {}
          }
          if (!targetDir) {
            const currentSettings = typeof settingsManager.getSettings === 'function' ? settingsManager.getSettings() : {};
            const downloadsDir = currentSettings?.general?.downloadPath || path.join(os.homedir(), 'Downloads');
            targetDir = path.join(downloadsDir, 'MediaFetch', 'Clipboard');
          }
          if (!fs.existsSync(targetDir)) {
            try { fs.mkdirSync(targetDir, { recursive: true }); } catch (_) {}
          }

          if (isWin) {
            const outImg = path.join(targetDir, `Clipboard_${nowStr}.png`);
            const escapedPath = outImg.replace(/'/g, "''");
            const psScript = `
Add-Type -AssemblyName System.Windows.Forms;
Add-Type -AssemblyName System.Drawing;
$data = [System.Windows.Forms.Clipboard]::GetDataObject();
if ($data -eq $null) {
    Write-Output 'EMPTY';
    exit 0;
}
$saved = $false;
if ($data.GetDataPresent('PNG')) {
    $stream = $data.GetData('PNG');
    if ($stream -is [System.IO.MemoryStream]) {
        [System.IO.File]::WriteAllBytes('${escapedPath}', $stream.ToArray());
        Write-Output 'SAVED_IMAGE:${escapedPath}';
        $saved = $true;
    }
}
if (-not $saved -and [System.Windows.Forms.Clipboard]::ContainsImage()) {
    $img = [System.Windows.Forms.Clipboard]::GetImage();
    if ($img -ne $null) {
        $img.Save('${escapedPath}', [System.Drawing.Imaging.ImageFormat]::Png);
        Write-Output 'SAVED_IMAGE:${escapedPath}';
        $saved = $true;
    }
}
if ($data.GetDataPresent('HTML Format')) {
    $h = [string]$data.GetData('HTML Format');
    if ($h) {
        Write-Output ('HTML:' + $h);
    }
}
if ([System.Windows.Forms.Clipboard]::ContainsFileDropList()) {
    $f = [System.Windows.Forms.Clipboard]::GetFileDropList();
    Write-Output ('FILES:' + ($f -join '|'));
}
if ([System.Windows.Forms.Clipboard]::ContainsText()) {
    $t = [System.Windows.Forms.Clipboard]::GetText();
    Write-Output ('TEXT:' + $t);
}
`;
            let stdout = '';
            try {
              const res = await execFileAsync('powershell.exe', ['-STA', '-NoProfile', '-Command', psScript], {
                windowsHide: true,
                timeout: 5000
              });
              stdout = res.stdout || '';
            } catch (psErr) {
              logger.warn('PowerShell clipboard extraction notice:', psErr.message);
              stdout = psErr.stdout || '';
            }
            const out = stdout.trim();

            let savedImagePath = null;
            if (out.includes('SAVED_IMAGE:')) {
              const line = out.split('\n').find(l => l.includes('SAVED_IMAGE:')) || '';
              const filePath = line.substring(line.indexOf('SAVED_IMAGE:') + 'SAVED_IMAGE:'.length).trim();
              if (fs.existsSync(filePath) && fs.statSync(filePath).size > 100) {
                savedImagePath = filePath;
              }
            } else if (fs.existsSync(outImg) && fs.statSync(outImg).size > 100) {
              savedImagePath = outImg;
            }

            // High-Resolution Web Master Upgrade:
            // If the user copied an image from Chrome/Edge/Firefox, the HTML format contains
            // the full uncompressed high-resolution source URL (<img src="...">)
            if (out.includes('HTML:')) {
              try {
                const htmlChunk = out.substring(out.indexOf('HTML:') + 'HTML:'.length);
                const match = htmlChunk.match(/<img[^>]+src=["'](https?:\/\/[^"']+)["']/i);
                if (match && match[1]) {
                  const rawUrl = match[1];
                  let ext = '.png';
                  const uLow = rawUrl.toLowerCase();
                  if (uLow.includes('.jpg') || uLow.includes('.jpeg')) ext = '.jpg';
                  else if (uLow.includes('.png')) ext = '.png';
                  else if (uLow.includes('.webp')) ext = '.webp';
                  else if (uLow.includes('.gif')) ext = '.gif';
                  else if (uLow.includes('.svg')) ext = '.svg';

                  const res = await fetch(rawUrl, {
                    headers: {
                      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36',
                      'Accept': 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8'
                    },
                    signal: AbortSignal.timeout(6000)
                  });
                  if (res.ok) {
                    const ct = (res.headers.get('content-type') || '').toLowerCase();
                    if (ct.includes('jpeg') || ct.includes('jpg')) ext = '.jpg';
                    else if (ct.includes('png')) ext = '.png';
                    else if (ct.includes('webp')) ext = '.webp';
                    else if (ct.includes('gif')) ext = '.gif';
                    else if (ct.includes('svg')) ext = '.svg';

                    const highResDest = path.join(targetDir, `Clipboard_${nowStr}${ext}`);
                    const buf = Buffer.from(await res.arrayBuffer());
                    if (buf.length > 500) {
                      fs.writeFileSync(highResDest, buf);
                      const finalDestPath = await convertImageToPreferredFormat(highResDest, preferredFormat);
                      if (savedImagePath && savedImagePath !== finalDestPath && fs.existsSync(savedImagePath)) {
                        try { fs.unlinkSync(savedImagePath); } catch (_) {}
                      }
                      return jsonRes(200, { success: true, type: 'image', filePath: finalDestPath, fileName: path.basename(finalDestPath), source: 'web_master_original' });
                    }
                  }
                }
              } catch (webErr) {
                logger.warn('Direct web master image fetch notice:', webErr.message);
              }
            }

            // If we have the saved clipboard image (lossless PNG stream or GDI+ bitmap), return it
            if (savedImagePath && fs.existsSync(savedImagePath)) {
              const finalDestPath = await convertImageToPreferredFormat(savedImagePath, preferredFormat);
              return jsonRes(200, { success: true, type: 'image', filePath: finalDestPath, fileName: path.basename(finalDestPath) });
            }

            if (out.includes('FILES:')) {
              const line = out.split('\n').find(l => l.includes('FILES:')) || '';
              const fileList = line.substring(line.indexOf('FILES:') + 'FILES:'.length).trim().split('|').filter(Boolean);
              if (fileList.length > 0 && fs.existsSync(fileList[0])) {
                return jsonRes(200, { success: true, type: 'file', filePath: fileList[0], files: fileList, fileName: path.basename(fileList[0]) });
              }
            }

            if (out.includes('TEXT:')) {
              const line = out.split('\n').find(l => l.includes('TEXT:')) || '';
              const txt = line.substring(line.indexOf('TEXT:') + 'TEXT:'.length).trim();
              if (txt.startsWith('http://') || txt.startsWith('https://')) {
                const txtLow = txt.toLowerCase();
                const isImgUrl = txtLow.endsWith('.jpg') || txtLow.endsWith('.jpeg') || txtLow.endsWith('.png') || txtLow.endsWith('.webp') || txtLow.endsWith('.gif') || txtLow.endsWith('.svg') || txtLow.includes('format=jpg') || txtLow.includes('format=png') || txtLow.includes('format=webp');
                if (isImgUrl) {
                  try {
                    let ext = '.png';
                    if (txtLow.includes('.jpg') || txtLow.includes('.jpeg')) ext = '.jpg';
                    else if (txtLow.includes('.webp')) ext = '.webp';
                    const res = await fetch(txt, {
                      headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36',
                        'Accept': 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8'
                      },
                      signal: AbortSignal.timeout(6000)
                    });
                    if (res.ok) {
                      const ct = (res.headers.get('content-type') || '').toLowerCase();
                      if (ct.includes('jpeg') || ct.includes('jpg')) ext = '.jpg';
                      else if (ct.includes('webp')) ext = '.webp';
                      else if (ct.includes('png')) ext = '.png';
                      const finalDest = path.join(targetDir, `Clipboard_${nowStr}${ext}`);
                      const buf = Buffer.from(await res.arrayBuffer());
                      if (buf.length > 200) {
                        fs.writeFileSync(finalDest, buf);
                        const finalDestPath = await convertImageToPreferredFormat(finalDest, preferredFormat);
                        return jsonRes(200, { success: true, type: 'image', filePath: finalDestPath, fileName: path.basename(finalDestPath), source: 'url_master_original' });
                      }
                    }
                  } catch (_) {}
                }
              }
              return jsonRes(200, { success: true, type: 'text', text: txt });
            }
          } else if (isMac) {
            const outImg = path.join(targetDir, `Clipboard_${nowStr}.png`);
            try {
              await execFileAsync('osascript', ['-e', `
                set theFile to (POSIX file "${outImg}")
                try
                  set theData to the clipboard as «class PNGf»
                  set theOpenedFile to open for access theFile with write permission
                  write theData to theOpenedFile
                  close access theOpenedFile
                on error
                  try
                    close access theFile
                  end try
                end try
              `], { timeout: 3500 });
              if (fs.existsSync(outImg) && fs.statSync(outImg).size > 100) {
                const finalDestPath = await convertImageToPreferredFormat(outImg, preferredFormat);
                return jsonRes(200, { success: true, type: 'image', filePath: finalDestPath, fileName: path.basename(finalDestPath) });
              }
            } catch (_) {}
          }

          jsonRes(200, { success: false, message: 'Clipboard does not contain image or media' });
        } catch (err) {
          logger.warn('Paste media error:', err.message);
          jsonRes(500, { success: false, error: err.message });
        }
      })();
      return;
    }

    if ((pathname === '/api/service/shutdown' || pathname === '/api/service/restart') && req.method === 'POST') {
      logger.info('Service shutdown endpoint called via HTTP POST.');
      jsonRes(200, { success: true, message: 'Shutting down service...' });
      setTimeout(async () => {
        try { await this.stop(); } catch (_) {}
        process.exit(0);
      }, 300);
      return;
    }

    if (pathname === '/api/diagnostics' && req.method === 'GET') {
      diagnosticsCollector.collectDiagnostics(this.port).then((d) => jsonRes(200, d));
      return;
    }

    if (pathname === '/api/queue' && req.method === 'GET') {
      jsonRes(200, queueManager.getItems());
      return;
    }

    if (pathname === '/api/settings' && req.method === 'GET') {
      jsonRes(200, settingsManager.getSettings());
      return;
    }

    if (pathname === '/api/history' && req.method === 'GET') {
      jsonRes(200, historyManager.getHistory());
      return;
    }

    if (pathname === '/api/cache/stats' && req.method === 'GET') {
      let tempStorageBytes = 0;
      const dirs = getKnownCacheDirs();
      for (const d of dirs) {
        tempStorageBytes += getDirSizeBytes(d);
      }
      const appData = (nodeProc && nodeProc.env && nodeProc.env.LOCALAPPDATA) || (os.homedir ? path.join(os.homedir(), '.mediafetch') : '');
      const logsDir = path.join(appData || '.', 'MediaFetch', 'logs');
      const logBytes = getDirSizeBytes(logsDir);
      const ram = getMemoryStats();
      jsonRes(200, {
        success: true,
        ram,
        streamCacheCount: streamUrlCache.size,
        tempStorageBytes,
        logBytes,
        totalCacheBytes: tempStorageBytes + logBytes,
        totalCacheMb: +((tempStorageBytes + logBytes) / (1024 * 1024)).toFixed(2)
      });
      return;
    }

    if (pathname === '/api/cache/clear' && req.method === 'POST') {
      let freedBytes = 0;
      const dirs = getKnownCacheDirs();
      for (const d of dirs) {
        freedBytes += clearDirFiles(d, false);
      }
      streamUrlCache.clear();
      try {
        const appData = (nodeProc && nodeProc.env && nodeProc.env.LOCALAPPDATA) || (os.homedir ? path.join(os.homedir(), '.mediafetch') : '');
        const logFile = path.join(appData || '.', 'MediaFetch', 'logs', 'service.log');
        if (fs.existsSync(logFile)) {
          const sz = fs.statSync(logFile).size;
          if (sz > 0) {
            fs.truncateSync(logFile, 0);
            freedBytes += sz;
          }
        }
      } catch (_) {}

      trimMemory();
      const ram = getMemoryStats();
      jsonRes(200, {
        success: true,
        freedBytes,
        freedMb: +(freedBytes / (1024 * 1024)).toFixed(2),
        totalCacheBytes: 0,
        totalCacheMb: 0.00,
        ram
      });
      return;
    }

    if (pathname === '/api/cache/gc' && req.method === 'POST') {
      trimMemory();
      const ram = getMemoryStats();
      jsonRes(200, {
        success: true,
        ram
      });
      return;
    }

    // DaVinci Resolve Import Bridge
    if (!this.pendingResolveImports) this.pendingResolveImports = [];
    if (!this.activeResolveProject) this.activeResolveProject = 'DaVinci Resolve';

    if (pathname === '/api/davinci/import' && req.method === 'POST') {
      let body = '';
      req.on('data', (chunk) => { body += chunk; });
      req.on('end', () => {
        try {
          const data = JSON.parse(body);
          if (data && data.filePath) {
            this.pendingResolveImports.push(data.filePath);
            jsonRes(200, { success: true, queued: true });
            return;
          }
        } catch (_) {}
        jsonRes(400, { error: 'Invalid payload' });
      });
      return;
    }

    if (pathname === '/api/davinci/pending' && req.method === 'GET') {
      const items = [...this.pendingResolveImports];
      this.pendingResolveImports = [];
      jsonRes(200, { files: items, project: this.activeResolveProject });
      return;
    }

    if (pathname === '/api/davinci/project' && req.method === 'POST') {
      let body = '';
      req.on('data', (chunk) => { body += chunk; });
      req.on('end', () => {
        try {
          const data = JSON.parse(body);
          if (data && data.name) this.activeResolveProject = data.name;
        } catch (_) {}
        jsonRes(200, { success: true, project: this.activeResolveProject });
      });
      return;
    }

    if (pathname === '/api/davinci/project' && req.method === 'GET') {
      jsonRes(200, { project: this.activeResolveProject });
      return;
    }

    if (pathname === '/api/clipboard' && req.method === 'GET') {
      try {
        let clipText = '';
        const { execSync } = require('child_process');
        if (process.platform === 'win32') {
          clipText = execSync('powershell.exe -NoProfile -Command Get-Clipboard', { encoding: 'utf8', timeout: 2500, windowsHide: true }) || '';
        } else if (process.platform === 'darwin') {
          clipText = execSync('pbpaste', { encoding: 'utf8', timeout: 2000 }) || '';
        } else {
          clipText = execSync('xclip -selection clipboard -o || wl-paste', { encoding: 'utf8', timeout: 2000 }) || '';
        }
        jsonRes(200, { success: true, text: clipText.trim() });
      } catch (err) {
        jsonRes(200, { success: false, error: err.message, text: '' });
      }
      return;
    }

    if (pathname === '/api/stream-url' && req.method === 'GET') {
      const vid = url.searchParams.get('v') || url.searchParams.get('id');
      const quality = url.searchParams.get('quality') || '720';
      const targetUrl = vid ? (vid.startsWith('http') ? vid : `https://www.youtube.com/watch?v=${vid}`) : null;
      if (!targetUrl) {
        jsonRes(400, { success: false, error: 'Missing video id' });
        return;
      }

      const cacheKey = `${vid}_${quality}`;
      const cached = streamUrlCache.get(cacheKey);
      if (cached && cached.expiresAt > Date.now()) {
        jsonRes(200, { success: true, streamUrl: cached.streamUrl, cached: true });
        return;
      }

      const isTikTok = /tiktok\.com|vm\.tiktok\.com|vt\.tiktok\.com/i.test(targetUrl);
      if (isTikTok) {
        (async () => {
          // 1. Primary: TikWM
          try {
            const resp = await fetch(`https://www.tikwm.com/api/?url=${encodeURIComponent(targetUrl)}&hd=1`, {
              headers: { 'User-Agent': 'Mozilla/5.0' },
              signal: AbortSignal.timeout(12000)
            });
            if (resp.ok) {
              const data = await resp.json();
              if (data && data.code === 0 && data.data) {
                const sUrl = data.data.play || data.data.hdplay;
                if (sUrl) {
                  setStreamUrlCache(cacheKey, { streamUrl: sUrl, expiresAt: Date.now() + 3600 * 1000 });
                  jsonRes(200, { success: true, streamUrl: sUrl });
                  return;
                }
              }
            }
          } catch (tErr) {
            logger.warn('TikTok stream-url TikWM notice:', tErr.message);
          }

          // 2. Secondary: TikMate
          try {
            const mateResp = await fetch('https://api.tikmate.app/api/lookup', {
              method: 'POST',
              headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
              body: `url=${encodeURIComponent(targetUrl)}`,
              signal: AbortSignal.timeout(10000)
            });
            if (mateResp.ok) {
              const mateData = await mateResp.json();
              if (mateData && mateData.token && mateData.id) {
                const sUrl = `https://tikmate.app/download/${mateData.token}/${mateData.id}.mp4${quality === '1080' ? '?hd=1' : ''}`;
                setStreamUrlCache(cacheKey, { streamUrl: sUrl, expiresAt: Date.now() + 3600 * 1000 });
                jsonRes(200, { success: true, streamUrl: sUrl });
                return;
              }
            }
          } catch (mErr) {
            logger.warn('TikTok stream-url TikMate notice:', mErr.message);
          }

          jsonRes(500, { success: false, error: 'Could not extract TikTok stream' });
        })();
        return;
      }

      let formatSpec = 'b[height<=720][protocol^=https][ext=mp4]/22/18/b/best[protocol^=https]/best';
      if (quality === '1080') {
        formatSpec = 'b[height<=1080][protocol^=https][ext=mp4]/22/18/b[height<=1080]/b/best[protocol^=https]/best';
      } else if (quality === '720') {
        formatSpec = 'b[height<=720][protocol^=https][ext=mp4]/22/18/b[height<=720]/b/best[protocol^=https]/best';
      } else if (quality === '480') {
        formatSpec = 'b[height<=480][protocol^=https][ext=mp4]/18/b[height<=480]/b/best[protocol^=https]/best';
      } else if (quality === '360') {
        formatSpec = '18/b[height<=360][protocol^=https][ext=mp4]/b/best[protocol^=https]/best';
      }

      const appendCookieArgs = (cmdArgs) => {
        try {
          const localAppData = process.env.LOCALAPPDATA || (os.homedir ? path.join(os.homedir(), 'AppData', 'Local') : '');
          const cookiesFilePath = localAppData ? path.join(localAppData, 'MediaFetch', 'cookies.txt') : '';
          if (cookiesFilePath && fs.existsSync(cookiesFilePath) && fs.statSync(cookiesFilePath).size > 10) {
            cmdArgs.push('--cookies', cookiesFilePath);
            return;
          }
          const rawCookiesBrowser = settingsManager.getSettings()?.engine?.browserCookies || settingsManager.getSettings()?.engine?.cookiesBrowser || 'none';
          const isWin = process.platform === 'win32';
          const cookiesBrowser = (isWin && rawCookiesBrowser === 'chrome') ? 'none' : rawCookiesBrowser;
          if (cookiesBrowser && cookiesBrowser !== 'none') {
            cmdArgs.push('--cookies-from-browser', cookiesBrowser);
          }
        } catch (_) {}
      };

      (async () => {
        try {
          const ytdlpPath = await dependencyManager.getYtDlpExecutablePath();
          const nodeBin = dependencyManager.getNodeExecutablePath();
          const jsRuntime = nodeBin === 'node' ? 'node' : `node:${nodeBin}`;
          const isYt = /youtu\.?be/i.test(targetUrl);
          const args = [
            '--no-playlist',
            '--no-check-certificates',
            '--no-warnings',
            '--skip-download',
            '--js-runtimes', jsRuntime,
            '--remote-components', 'ejs:github'
          ];
          appendCookieArgs(args);
          if (isYt) {
            args.push('--extractor-args', 'youtube:player_client=ios,web,android', '--user-agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36');
          }
          if (targetUrl.includes('behance.net') || targetUrl.includes('vimeo.com')) {
            args.push('--referer', 'https://www.behance.net/');
          } else if (targetUrl.includes('instagram.com')) {
            args.push('--referer', 'https://www.instagram.com/');
          } else if (targetUrl.includes('threads.net') || targetUrl.includes('threads.com')) {
            args.push('--referer', 'https://www.threads.net/');
          } else if (targetUrl.includes('x.com') || targetUrl.includes('twitter.com')) {
            args.push('--referer', 'https://x.com/');
          } else if (targetUrl.includes('linkedin.com')) {
            args.push('--referer', 'https://www.linkedin.com/');
          }
          args.push('-g', '-f', formatSpec, targetUrl);

          const { stdout } = await execFileAsync(ytdlpPath, args, { windowsHide: true, timeout: 25000 });
          const streamUrl = stdout.trim().split(/\r?\n/).find((u) => u.startsWith('http'));
          if (streamUrl) {
            setStreamUrlCache(cacheKey, { streamUrl, expiresAt: Date.now() + 2 * 3600 * 1000 });
            jsonRes(200, { success: true, streamUrl });
            return;
          }
          throw new Error('No stream URL extracted');
        } catch (err) {
          try {
            const ytdlpPath = await dependencyManager.getYtDlpExecutablePath();
            const nodeBin = dependencyManager.getNodeExecutablePath();
            const jsRuntime = nodeBin === 'node' ? 'node' : `node:${nodeBin}`;
            const isYt = /youtu\.?be/i.test(targetUrl);
            const fallbackArgs = [
              '--no-playlist',
              '--no-check-certificates',
              '--no-warnings',
              '--skip-download',
              '--js-runtimes', jsRuntime
            ];
            appendCookieArgs(fallbackArgs);
            if (isYt) {
              fallbackArgs.push('--extractor-args', 'youtube:player_client=ios,web,android', '--user-agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36');
            }
            if (targetUrl.includes('behance.net') || targetUrl.includes('vimeo.com')) {
              fallbackArgs.push('--referer', 'https://www.behance.net/');
            } else if (targetUrl.includes('instagram.com')) {
              fallbackArgs.push('--referer', 'https://www.instagram.com/');
            } else if (targetUrl.includes('threads.net') || targetUrl.includes('threads.com')) {
              fallbackArgs.push('--referer', 'https://www.threads.net/');
            } else if (targetUrl.includes('x.com') || targetUrl.includes('twitter.com')) {
              fallbackArgs.push('--referer', 'https://x.com/');
            } else if (targetUrl.includes('linkedin.com')) {
              fallbackArgs.push('--referer', 'https://www.linkedin.com/');
            }
            if (isYt) {
              fallbackArgs.push('-g', '-f', '18/22/b/best', targetUrl);
            } else {
              fallbackArgs.push('-g', '-f', 'best[protocol^=https]/best', targetUrl);
            }
            const { stdout } = await execFileAsync(ytdlpPath, fallbackArgs, { windowsHide: true, timeout: 25000 });
            const streamUrl = stdout.trim().split(/\r?\n/).find((u) => u.startsWith('http'));
            if (streamUrl) {
              setStreamUrlCache(cacheKey, { streamUrl, expiresAt: Date.now() + 2 * 3600 * 1000 });
              jsonRes(200, { success: true, streamUrl });
              return;
            }
          } catch (_) {}
          try {
            const ytdlpPath = await dependencyManager.getYtDlpExecutablePath();
            const nodeBin = dependencyManager.getNodeExecutablePath();
            const jsRuntime = nodeBin === 'node' ? 'node' : `node:${nodeBin}`;
            const isYt = /youtu\.?be/i.test(targetUrl);
            const emergencyArgs = [
              '--no-playlist',
              '--no-check-certificates',
              '--no-warnings',
              '--skip-download',
              '--js-runtimes', jsRuntime
            ];
            appendCookieArgs(emergencyArgs);
            if (isYt) {
              emergencyArgs.push('--extractor-args', 'youtube:player_client=ios,web,android', '--user-agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36');
              emergencyArgs.push('-g', '-f', '18/b/best', targetUrl);
            } else {
              emergencyArgs.push('-g', '-f', 'best', targetUrl);
            }
            const { stdout } = await execFileAsync(ytdlpPath, emergencyArgs, { windowsHide: true, timeout: 25000 });
            const streamUrl = stdout.trim().split(/\r?\n/).find((u) => u.startsWith('http'));
            if (streamUrl) {
              setStreamUrlCache(cacheKey, { streamUrl, expiresAt: Date.now() + 2 * 3600 * 1000 });
              jsonRes(200, { success: true, streamUrl });
              return;
            }
          } catch (_) {}
          jsonRes(500, { success: false, error: err.message || 'Failed to resolve stream URL' });
        }
      })();
      return;
    }

    if (pathname === '/youtube-player.html' || pathname === '/player') {
      const ytPath = path.join(__dirname, '..', 'youtube-player.html');
      if (fs.existsSync(ytPath)) {
        res.writeHead(200, {
          'Content-Type': 'text/html; charset=utf-8',
          'Referrer-Policy': 'strict-origin-when-cross-origin',
          'Access-Control-Allow-Origin': '*'
        });
        res.end(fs.readFileSync(ytPath));
        return;
      }
    }

    if (pathname === '/theater-player.html' || pathname === '/theater') {
      const theaterPath = path.join(__dirname, '..', 'theater-player.html');
      if (fs.existsSync(theaterPath)) {
        res.writeHead(200, {
          'Content-Type': 'text/html; charset=utf-8',
          'Access-Control-Allow-Origin': '*'
        });
        res.end(fs.readFileSync(theaterPath));
        return;
      }
    }

    // Static Web File Server for DaVinci Resolve Native Panel
    const resolveRoots = [
      path.join(__dirname, '..'),
      path.join(process.env.PROGRAMDATA || 'C:\\ProgramData', 'Blackmagic Design', 'DaVinci Resolve', 'Support', 'Workflow Integration Plugins', 'com.mediafetch.resolve'),
      path.join(__dirname, '..', '..', 'com.mediafetch.resolve'),
      path.join(__dirname, '..', '..', '..', 'com.mediafetch.resolve')
    ];

    if (pathname === '/resolve' || pathname === '/resolve/' || pathname === '/resolve/index.html') {
      for (const root of resolveRoots) {
        const indexPath = path.join(root, 'index.html');
        if (fs.existsSync(indexPath)) {
          res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
          res.end(fs.readFileSync(indexPath));
          return;
        }
      }
    }

    if (pathname.startsWith('/resolve/')) {
      const rel = pathname.replace('/resolve/', '');
      for (const root of resolveRoots) {
        const fullPath = path.join(root, rel);
        if (fs.existsSync(fullPath) && fs.statSync(fullPath).isFile()) {
          const ext = path.extname(fullPath).toLowerCase();
          const mimeTypes = {
            '.html': 'text/html; charset=utf-8',
            '.css': 'text/css; charset=utf-8',
            '.js': 'application/javascript; charset=utf-8',
            '.png': 'image/png',
            '.svg': 'image/svg+xml',
            '.json': 'application/json'
          };
          res.writeHead(200, { 'Content-Type': mimeTypes[ext] || 'application/octet-stream' });
          res.end(fs.readFileSync(fullPath));
          return;
        }
      }
    }

    jsonRes(404, { error: 'Not Found' });
  }
}

// Auto-start singleton
if (!globalScope.__mediaFetchServerStarted) {
  globalScope.__mediaFetchServerStarted = true;
  const preferredPort = parseInt((nodeProc && nodeProc.env && nodeProc.env.PORT) || '48924', 10);
  const server = new MediaFetchServer(preferredPort);
  server.start().catch((err) => {
    if (err.code !== 'EADDRINUSE') {
      console.error('Failed to start MediaFetch server:', err);
    }
  });
}

module.exports = { MediaFetchServer, metadataAnalyzer, queueManager, dependencyManager, settingsManager };
