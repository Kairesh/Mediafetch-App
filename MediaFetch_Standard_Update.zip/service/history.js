import fs from 'fs';
import path from 'path';
import os from 'os';
import { logger } from './logger.js';

export class HistoryManager {
  historyPath;
  entries = [];
  maxEntries = 2000;

  constructor() {
    const baseDir = process.env.LOCALAPPDATA || path.join(os.homedir(), '.mediafetch');
    const mfDir = path.join(baseDir, 'MediaFetch');
    this.historyPath = path.join(mfDir, 'history.json');
    this.entries = this.load();
  }

  ensureDirectory() {
    const dir = path.dirname(this.historyPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  }

  getHistory() {
    return [...this.entries];
  }

  addEntry(entry) {
    this.entries = this.entries.filter(e => e.id !== entry.id);
    this.entries.push(entry);
    if (this.entries.length > this.maxEntries) {
      this.entries = this.entries.slice(-this.maxEntries);
    }
    this.save();
  }

  removeHistoryItem(id) {
    this.entries = this.entries.filter(e => e.id !== id);
    this.save();
  }

  removeHistory(id) {
    this.removeHistoryItem(id);
  }

  clearHistory() {
    this.entries = [];
    this.save();
  }

  load() {
    try {
      if (fs.existsSync(this.historyPath)) {
        const raw = fs.readFileSync(this.historyPath, 'utf8');
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (e) {
      logger.warn('Failed to load history:', e);
    }
    return [];
  }

  save() {
    try {
      this.ensureDirectory();
      const tmp = this.historyPath + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify(this.entries, null, 2), 'utf8');
      fs.renameSync(tmp, this.historyPath);
    } catch (e) {
      logger.warn('Failed to save history:', e);
    }
  }
}

export const historyManager = new HistoryManager();
