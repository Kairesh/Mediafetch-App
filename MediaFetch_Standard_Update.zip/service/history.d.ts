import { HistoryEntry } from '../common/types.js';
export declare class HistoryManager {
    private historyPath;
    private entries;
    private maxEntries;
    constructor();
    private ensureDirectory;
    getHistory(): HistoryEntry[];
    addEntry(entry: HistoryEntry): void;
    removeEntry(id: string): void;
    clearHistory(): void;
    private load;
    private save;
}
export declare const historyManager: HistoryManager;
