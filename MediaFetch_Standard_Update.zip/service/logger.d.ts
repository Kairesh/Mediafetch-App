export type LogLevel = 'DEBUG' | 'INFO' | 'WARN' | 'ERROR';
export declare class Logger {
    private logDir;
    private logFile;
    private maxSizeBytes;
    private maxBackups;
    private isDebugEnabled;
    constructor();
    setDebug(enabled: boolean): void;
    private ensureDirectory;
    debug(message: string, meta?: unknown): void;
    info(message: string, meta?: unknown): void;
    warn(message: string, meta?: unknown): void;
    error(message: string, meta?: unknown): void;
    private write;
    private appendToFile;
    private rotateIfNeeded;
    getRecentLogs(limitLines?: number): string[];
    getLogFilePath(): string;
}
export declare const logger: Logger;
