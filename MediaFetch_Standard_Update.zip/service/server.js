var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// node_modules/ws/lib/constants.js
var require_constants = __commonJS({
  "node_modules/ws/lib/constants.js"(exports2, module2) {
    "use strict";
    var BINARY_TYPES = ["nodebuffer", "arraybuffer", "fragments"];
    var hasBlob = typeof Blob !== "undefined";
    if (hasBlob) BINARY_TYPES.push("blob");
    module2.exports = {
      BINARY_TYPES,
      CLOSE_TIMEOUT: 3e4,
      EMPTY_BUFFER: Buffer.alloc(0),
      GUID: "258EAFA5-E914-47DA-95CA-C5AB0DC85B11",
      hasBlob,
      kForOnEventAttribute: /* @__PURE__ */ Symbol("kIsForOnEventAttribute"),
      kListener: /* @__PURE__ */ Symbol("kListener"),
      kStatusCode: /* @__PURE__ */ Symbol("status-code"),
      kWebSocket: /* @__PURE__ */ Symbol("websocket"),
      NOOP: () => {
      }
    };
  }
});

// node_modules/ws/lib/buffer-util.js
var require_buffer_util = __commonJS({
  "node_modules/ws/lib/buffer-util.js"(exports2, module2) {
    "use strict";
    var { EMPTY_BUFFER } = require_constants();
    var FastBuffer = Buffer[Symbol.species];
    function concat(list, totalLength) {
      if (list.length === 0) return EMPTY_BUFFER;
      if (list.length === 1) return list[0];
      const target = Buffer.allocUnsafe(totalLength);
      let offset = 0;
      for (let i = 0; i < list.length; i++) {
        const buf = list[i];
        target.set(buf, offset);
        offset += buf.length;
      }
      if (offset < totalLength) {
        return new FastBuffer(target.buffer, target.byteOffset, offset);
      }
      return target;
    }
    function _mask(source, mask, output, offset, length) {
      for (let i = 0; i < length; i++) {
        output[offset + i] = source[i] ^ mask[i & 3];
      }
    }
    function _unmask(buffer, mask) {
      for (let i = 0; i < buffer.length; i++) {
        buffer[i] ^= mask[i & 3];
      }
    }
    function toArrayBuffer(buf) {
      if (buf.length === buf.buffer.byteLength) {
        return buf.buffer;
      }
      return buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.length);
    }
    function toBuffer(data) {
      toBuffer.readOnly = true;
      if (Buffer.isBuffer(data)) return data;
      let buf;
      if (data instanceof ArrayBuffer) {
        buf = new FastBuffer(data);
      } else if (ArrayBuffer.isView(data)) {
        buf = new FastBuffer(data.buffer, data.byteOffset, data.byteLength);
      } else {
        buf = Buffer.from(data);
        toBuffer.readOnly = false;
      }
      return buf;
    }
    module2.exports = {
      concat,
      mask: _mask,
      toArrayBuffer,
      toBuffer,
      unmask: _unmask
    };
    if (!process.env.WS_NO_BUFFER_UTIL) {
      try {
        const bufferUtil = require("bufferutil");
        module2.exports.mask = function(source, mask, output, offset, length) {
          if (length < 48) _mask(source, mask, output, offset, length);
          else bufferUtil.mask(source, mask, output, offset, length);
        };
        module2.exports.unmask = function(buffer, mask) {
          if (buffer.length < 32) _unmask(buffer, mask);
          else bufferUtil.unmask(buffer, mask);
        };
      } catch (e) {
      }
    }
  }
});

// node_modules/ws/lib/limiter.js
var require_limiter = __commonJS({
  "node_modules/ws/lib/limiter.js"(exports2, module2) {
    "use strict";
    var kDone = /* @__PURE__ */ Symbol("kDone");
    var kRun = /* @__PURE__ */ Symbol("kRun");
    var Limiter = class {
      /**
       * Creates a new `Limiter`.
       *
       * @param {Number} [concurrency=Infinity] The maximum number of jobs allowed
       *     to run concurrently
       */
      constructor(concurrency) {
        this[kDone] = () => {
          this.pending--;
          this[kRun]();
        };
        this.concurrency = concurrency || Infinity;
        this.jobs = [];
        this.pending = 0;
      }
      /**
       * Adds a job to the queue.
       *
       * @param {Function} job The job to run
       * @public
       */
      add(job) {
        this.jobs.push(job);
        this[kRun]();
      }
      /**
       * Removes a job from the queue and runs it if possible.
       *
       * @private
       */
      [kRun]() {
        if (this.pending === this.concurrency) return;
        if (this.jobs.length) {
          const job = this.jobs.shift();
          this.pending++;
          job(this[kDone]);
        }
      }
    };
    module2.exports = Limiter;
  }
});

// node_modules/ws/lib/permessage-deflate.js
var require_permessage_deflate = __commonJS({
  "node_modules/ws/lib/permessage-deflate.js"(exports2, module2) {
    "use strict";
    var zlib = require("zlib");
    var bufferUtil = require_buffer_util();
    var Limiter = require_limiter();
    var { kStatusCode } = require_constants();
    var FastBuffer = Buffer[Symbol.species];
    var TRAILER = Buffer.from([0, 0, 255, 255]);
    var kPerMessageDeflate = /* @__PURE__ */ Symbol("permessage-deflate");
    var kTotalLength = /* @__PURE__ */ Symbol("total-length");
    var kCallback = /* @__PURE__ */ Symbol("callback");
    var kBuffers = /* @__PURE__ */ Symbol("buffers");
    var kError = /* @__PURE__ */ Symbol("error");
    var zlibLimiter;
    var PerMessageDeflate = class {
      /**
       * Creates a PerMessageDeflate instance.
       *
       * @param {Object} [options] Configuration options
       * @param {(Boolean|Number)} [options.clientMaxWindowBits] Advertise support
       *     for, or request, a custom client window size
       * @param {Boolean} [options.clientNoContextTakeover=false] Advertise/
       *     acknowledge disabling of client context takeover
       * @param {Number} [options.concurrencyLimit=10] The number of concurrent
       *     calls to zlib
       * @param {Boolean} [options.isServer=false] Create the instance in either
       *     server or client mode
       * @param {Number} [options.maxPayload=0] The maximum allowed message length
       * @param {(Boolean|Number)} [options.serverMaxWindowBits] Request/confirm the
       *     use of a custom server window size
       * @param {Boolean} [options.serverNoContextTakeover=false] Request/accept
       *     disabling of server context takeover
       * @param {Number} [options.threshold=1024] Size (in bytes) below which
       *     messages should not be compressed if context takeover is disabled
       * @param {Object} [options.zlibDeflateOptions] Options to pass to zlib on
       *     deflate
       * @param {Object} [options.zlibInflateOptions] Options to pass to zlib on
       *     inflate
       */
      constructor(options) {
        this._options = options || {};
        this._threshold = this._options.threshold !== void 0 ? this._options.threshold : 1024;
        this._maxPayload = this._options.maxPayload | 0;
        this._isServer = !!this._options.isServer;
        this._deflate = null;
        this._inflate = null;
        this.params = null;
        if (!zlibLimiter) {
          const concurrency = this._options.concurrencyLimit !== void 0 ? this._options.concurrencyLimit : 10;
          zlibLimiter = new Limiter(concurrency);
        }
      }
      /**
       * @type {String}
       */
      static get extensionName() {
        return "permessage-deflate";
      }
      /**
       * Create an extension negotiation offer.
       *
       * @return {Object} Extension parameters
       * @public
       */
      offer() {
        const params = {};
        if (this._options.serverNoContextTakeover) {
          params.server_no_context_takeover = true;
        }
        if (this._options.clientNoContextTakeover) {
          params.client_no_context_takeover = true;
        }
        if (this._options.serverMaxWindowBits) {
          params.server_max_window_bits = this._options.serverMaxWindowBits;
        }
        if (this._options.clientMaxWindowBits) {
          params.client_max_window_bits = this._options.clientMaxWindowBits;
        } else if (this._options.clientMaxWindowBits == null) {
          params.client_max_window_bits = true;
        }
        return params;
      }
      /**
       * Accept an extension negotiation offer/response.
       *
       * @param {Array} configurations The extension negotiation offers/reponse
       * @return {Object} Accepted configuration
       * @public
       */
      accept(configurations) {
        configurations = this.normalizeParams(configurations);
        this.params = this._isServer ? this.acceptAsServer(configurations) : this.acceptAsClient(configurations);
        return this.params;
      }
      /**
       * Releases all resources used by the extension.
       *
       * @public
       */
      cleanup() {
        if (this._inflate) {
          this._inflate.close();
          this._inflate = null;
        }
        if (this._deflate) {
          const callback = this._deflate[kCallback];
          this._deflate.close();
          this._deflate = null;
          if (callback) {
            callback(
              new Error(
                "The deflate stream was closed while data was being processed"
              )
            );
          }
        }
      }
      /**
       *  Accept an extension negotiation offer.
       *
       * @param {Array} offers The extension negotiation offers
       * @return {Object} Accepted configuration
       * @private
       */
      acceptAsServer(offers) {
        const opts = this._options;
        const accepted = offers.find((params) => {
          if (opts.serverNoContextTakeover === false && params.server_no_context_takeover || params.server_max_window_bits && (opts.serverMaxWindowBits === false || typeof opts.serverMaxWindowBits === "number" && opts.serverMaxWindowBits > params.server_max_window_bits) || typeof opts.clientMaxWindowBits === "number" && (typeof params.client_max_window_bits === "number" ? opts.clientMaxWindowBits > params.client_max_window_bits : !params.client_max_window_bits)) {
            return false;
          }
          return true;
        });
        if (!accepted) {
          throw new Error("None of the extension offers can be accepted");
        }
        if (opts.serverNoContextTakeover) {
          accepted.server_no_context_takeover = true;
        }
        if (opts.clientNoContextTakeover) {
          accepted.client_no_context_takeover = true;
        }
        if (typeof opts.serverMaxWindowBits === "number") {
          accepted.server_max_window_bits = opts.serverMaxWindowBits;
        }
        if (typeof opts.clientMaxWindowBits === "number") {
          accepted.client_max_window_bits = opts.clientMaxWindowBits;
        } else if (accepted.client_max_window_bits === true || opts.clientMaxWindowBits === false) {
          delete accepted.client_max_window_bits;
        }
        return accepted;
      }
      /**
       * Accept the extension negotiation response.
       *
       * @param {Array} response The extension negotiation response
       * @return {Object} Accepted configuration
       * @private
       */
      acceptAsClient(response) {
        const params = response[0];
        if (this._options.clientNoContextTakeover === false && params.client_no_context_takeover) {
          throw new Error('Unexpected parameter "client_no_context_takeover"');
        }
        if (!params.client_max_window_bits) {
          if (typeof this._options.clientMaxWindowBits === "number") {
            params.client_max_window_bits = this._options.clientMaxWindowBits;
          }
        } else if (this._options.clientMaxWindowBits === false || typeof this._options.clientMaxWindowBits === "number" && params.client_max_window_bits > this._options.clientMaxWindowBits) {
          throw new Error(
            'Unexpected or invalid parameter "client_max_window_bits"'
          );
        }
        return params;
      }
      /**
       * Normalize parameters.
       *
       * @param {Array} configurations The extension negotiation offers/reponse
       * @return {Array} The offers/response with normalized parameters
       * @private
       */
      normalizeParams(configurations) {
        configurations.forEach((params) => {
          Object.keys(params).forEach((key) => {
            let value = params[key];
            if (value.length > 1) {
              throw new Error(`Parameter "${key}" must have only a single value`);
            }
            value = value[0];
            if (key === "client_max_window_bits") {
              if (value !== true) {
                const num = +value;
                if (!Number.isInteger(num) || num < 8 || num > 15) {
                  throw new TypeError(
                    `Invalid value for parameter "${key}": ${value}`
                  );
                }
                value = num;
              } else if (!this._isServer) {
                throw new TypeError(
                  `Invalid value for parameter "${key}": ${value}`
                );
              }
            } else if (key === "server_max_window_bits") {
              const num = +value;
              if (!Number.isInteger(num) || num < 8 || num > 15) {
                throw new TypeError(
                  `Invalid value for parameter "${key}": ${value}`
                );
              }
              value = num;
            } else if (key === "client_no_context_takeover" || key === "server_no_context_takeover") {
              if (value !== true) {
                throw new TypeError(
                  `Invalid value for parameter "${key}": ${value}`
                );
              }
            } else {
              throw new Error(`Unknown parameter "${key}"`);
            }
            params[key] = value;
          });
        });
        return configurations;
      }
      /**
       * Decompress data. Concurrency limited.
       *
       * @param {Buffer} data Compressed data
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @public
       */
      decompress(data, fin, callback) {
        zlibLimiter.add((done) => {
          this._decompress(data, fin, (err, result) => {
            done();
            callback(err, result);
          });
        });
      }
      /**
       * Compress data. Concurrency limited.
       *
       * @param {(Buffer|String)} data Data to compress
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @public
       */
      compress(data, fin, callback) {
        zlibLimiter.add((done) => {
          this._compress(data, fin, (err, result) => {
            done();
            callback(err, result);
          });
        });
      }
      /**
       * Decompress data.
       *
       * @param {Buffer} data Compressed data
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @private
       */
      _decompress(data, fin, callback) {
        const endpoint = this._isServer ? "client" : "server";
        if (!this._inflate) {
          const key = `${endpoint}_max_window_bits`;
          const windowBits = typeof this.params[key] !== "number" ? zlib.Z_DEFAULT_WINDOWBITS : this.params[key];
          this._inflate = zlib.createInflateRaw({
            ...this._options.zlibInflateOptions,
            windowBits
          });
          this._inflate[kPerMessageDeflate] = this;
          this._inflate[kTotalLength] = 0;
          this._inflate[kBuffers] = [];
          this._inflate.on("error", inflateOnError);
          this._inflate.on("data", inflateOnData);
        }
        this._inflate[kCallback] = callback;
        this._inflate.write(data);
        if (fin) this._inflate.write(TRAILER);
        this._inflate.flush(() => {
          const err = this._inflate[kError];
          if (err) {
            this._inflate.close();
            this._inflate = null;
            callback(err);
            return;
          }
          const data2 = bufferUtil.concat(
            this._inflate[kBuffers],
            this._inflate[kTotalLength]
          );
          if (this._inflate._readableState.endEmitted) {
            this._inflate.close();
            this._inflate = null;
          } else {
            this._inflate[kTotalLength] = 0;
            this._inflate[kBuffers] = [];
            if (fin && this.params[`${endpoint}_no_context_takeover`]) {
              this._inflate.reset();
            }
          }
          callback(null, data2);
        });
      }
      /**
       * Compress data.
       *
       * @param {(Buffer|String)} data Data to compress
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @private
       */
      _compress(data, fin, callback) {
        const endpoint = this._isServer ? "server" : "client";
        if (!this._deflate) {
          const key = `${endpoint}_max_window_bits`;
          const windowBits = typeof this.params[key] !== "number" ? zlib.Z_DEFAULT_WINDOWBITS : this.params[key];
          this._deflate = zlib.createDeflateRaw({
            ...this._options.zlibDeflateOptions,
            windowBits
          });
          this._deflate[kTotalLength] = 0;
          this._deflate[kBuffers] = [];
          this._deflate.on("data", deflateOnData);
        }
        this._deflate[kCallback] = callback;
        this._deflate.write(data);
        this._deflate.flush(zlib.Z_SYNC_FLUSH, () => {
          if (!this._deflate) {
            return;
          }
          let data2 = bufferUtil.concat(
            this._deflate[kBuffers],
            this._deflate[kTotalLength]
          );
          if (fin) {
            data2 = new FastBuffer(data2.buffer, data2.byteOffset, data2.length - 4);
          }
          this._deflate[kCallback] = null;
          this._deflate[kTotalLength] = 0;
          this._deflate[kBuffers] = [];
          if (fin && this.params[`${endpoint}_no_context_takeover`]) {
            this._deflate.reset();
          }
          callback(null, data2);
        });
      }
    };
    module2.exports = PerMessageDeflate;
    function deflateOnData(chunk) {
      this[kBuffers].push(chunk);
      this[kTotalLength] += chunk.length;
    }
    function inflateOnData(chunk) {
      this[kTotalLength] += chunk.length;
      if (this[kPerMessageDeflate]._maxPayload < 1 || this[kTotalLength] <= this[kPerMessageDeflate]._maxPayload) {
        this[kBuffers].push(chunk);
        return;
      }
      this[kError] = new RangeError("Max payload size exceeded");
      this[kError].code = "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH";
      this[kError][kStatusCode] = 1009;
      this.removeListener("data", inflateOnData);
      this.reset();
    }
    function inflateOnError(err) {
      this[kPerMessageDeflate]._inflate = null;
      if (this[kError]) {
        this[kCallback](this[kError]);
        return;
      }
      err[kStatusCode] = 1007;
      this[kCallback](err);
    }
  }
});

// node_modules/ws/lib/validation.js
var require_validation = __commonJS({
  "node_modules/ws/lib/validation.js"(exports2, module2) {
    "use strict";
    var { isUtf8 } = require("buffer");
    var { hasBlob } = require_constants();
    var tokenChars = [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      // 0 - 15
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      // 16 - 31
      0,
      1,
      0,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      1,
      1,
      0,
      1,
      1,
      0,
      // 32 - 47
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      // 48 - 63
      0,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      // 64 - 79
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      0,
      1,
      1,
      // 80 - 95
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      // 96 - 111
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      1,
      0,
      1,
      0
      // 112 - 127
    ];
    function isValidStatusCode(code) {
      return code >= 1e3 && code <= 1014 && code !== 1004 && code !== 1005 && code !== 1006 || code >= 3e3 && code <= 4999;
    }
    function _isValidUTF8(buf) {
      const len = buf.length;
      let i = 0;
      while (i < len) {
        if ((buf[i] & 128) === 0) {
          i++;
        } else if ((buf[i] & 224) === 192) {
          if (i + 1 === len || (buf[i + 1] & 192) !== 128 || (buf[i] & 254) === 192) {
            return false;
          }
          i += 2;
        } else if ((buf[i] & 240) === 224) {
          if (i + 2 >= len || (buf[i + 1] & 192) !== 128 || (buf[i + 2] & 192) !== 128 || buf[i] === 224 && (buf[i + 1] & 224) === 128 || // Overlong
          buf[i] === 237 && (buf[i + 1] & 224) === 160) {
            return false;
          }
          i += 3;
        } else if ((buf[i] & 248) === 240) {
          if (i + 3 >= len || (buf[i + 1] & 192) !== 128 || (buf[i + 2] & 192) !== 128 || (buf[i + 3] & 192) !== 128 || buf[i] === 240 && (buf[i + 1] & 240) === 128 || // Overlong
          buf[i] === 244 && buf[i + 1] > 143 || buf[i] > 244) {
            return false;
          }
          i += 4;
        } else {
          return false;
        }
      }
      return true;
    }
    function isBlob(value) {
      return hasBlob && typeof value === "object" && typeof value.arrayBuffer === "function" && typeof value.type === "string" && typeof value.stream === "function" && (value[Symbol.toStringTag] === "Blob" || value[Symbol.toStringTag] === "File");
    }
    module2.exports = {
      isBlob,
      isValidStatusCode,
      isValidUTF8: _isValidUTF8,
      tokenChars
    };
    if (isUtf8) {
      module2.exports.isValidUTF8 = function(buf) {
        return buf.length < 24 ? _isValidUTF8(buf) : isUtf8(buf);
      };
    } else if (!process.env.WS_NO_UTF_8_VALIDATE) {
      try {
        const isValidUTF8 = require("utf-8-validate");
        module2.exports.isValidUTF8 = function(buf) {
          return buf.length < 32 ? _isValidUTF8(buf) : isValidUTF8(buf);
        };
      } catch (e) {
      }
    }
  }
});

// node_modules/ws/lib/receiver.js
var require_receiver = __commonJS({
  "node_modules/ws/lib/receiver.js"(exports2, module2) {
    "use strict";
    var { Writable } = require("stream");
    var PerMessageDeflate = require_permessage_deflate();
    var {
      BINARY_TYPES,
      EMPTY_BUFFER,
      kStatusCode,
      kWebSocket
    } = require_constants();
    var { concat, toArrayBuffer, unmask } = require_buffer_util();
    var { isValidStatusCode, isValidUTF8 } = require_validation();
    var FastBuffer = Buffer[Symbol.species];
    var GET_INFO = 0;
    var GET_PAYLOAD_LENGTH_16 = 1;
    var GET_PAYLOAD_LENGTH_64 = 2;
    var GET_MASK = 3;
    var GET_DATA = 4;
    var INFLATING = 5;
    var DEFER_EVENT = 6;
    var Receiver = class extends Writable {
      /**
       * Creates a Receiver instance.
       *
       * @param {Object} [options] Options object
       * @param {Boolean} [options.allowSynchronousEvents=true] Specifies whether
       *     any of the `'message'`, `'ping'`, and `'pong'` events can be emitted
       *     multiple times in the same tick
       * @param {String} [options.binaryType=nodebuffer] The type for binary data
       * @param {Object} [options.extensions] An object containing the negotiated
       *     extensions
       * @param {Boolean} [options.isServer=false] Specifies whether to operate in
       *     client or server mode
       * @param {Number} [options.maxBufferedChunks=0] The maximum number of
       *     buffered data chunks
       * @param {Number} [options.maxFragments=0] The maximum number of message
       *     fragments
       * @param {Number} [options.maxPayload=0] The maximum allowed message length
       * @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
       *     not to skip UTF-8 validation for text and close messages
       */
      constructor(options = {}) {
        super();
        this._allowSynchronousEvents = options.allowSynchronousEvents !== void 0 ? options.allowSynchronousEvents : true;
        this._binaryType = options.binaryType || BINARY_TYPES[0];
        this._extensions = options.extensions || {};
        this._isServer = !!options.isServer;
        this._maxBufferedChunks = options.maxBufferedChunks | 0;
        this._maxFragments = options.maxFragments | 0;
        this._maxPayload = options.maxPayload | 0;
        this._skipUTF8Validation = !!options.skipUTF8Validation;
        this[kWebSocket] = void 0;
        this._bufferedBytes = 0;
        this._buffers = [];
        this._compressed = false;
        this._payloadLength = 0;
        this._mask = void 0;
        this._fragmented = 0;
        this._masked = false;
        this._fin = false;
        this._opcode = 0;
        this._totalPayloadLength = 0;
        this._messageLength = 0;
        this._numFragments = 0;
        this._fragments = [];
        this._errored = false;
        this._loop = false;
        this._state = GET_INFO;
      }
      /**
       * Implements `Writable.prototype._write()`.
       *
       * @param {Buffer} chunk The chunk of data to write
       * @param {String} encoding The character encoding of `chunk`
       * @param {Function} cb Callback
       * @private
       */
      _write(chunk, encoding, cb) {
        if (this._opcode === 8 && this._state == GET_INFO) return cb();
        if (this._maxBufferedChunks > 0 && this._buffers.length >= this._maxBufferedChunks) {
          cb(
            this.createError(
              RangeError,
              "Too many buffered chunks",
              false,
              1008,
              "WS_ERR_TOO_MANY_BUFFERED_PARTS"
            )
          );
          return;
        }
        this._bufferedBytes += chunk.length;
        this._buffers.push(chunk);
        this.startLoop(cb);
      }
      /**
       * Consumes `n` bytes from the buffered data.
       *
       * @param {Number} n The number of bytes to consume
       * @return {Buffer} The consumed bytes
       * @private
       */
      consume(n) {
        this._bufferedBytes -= n;
        if (n === this._buffers[0].length) return this._buffers.shift();
        if (n < this._buffers[0].length) {
          const buf = this._buffers[0];
          this._buffers[0] = new FastBuffer(
            buf.buffer,
            buf.byteOffset + n,
            buf.length - n
          );
          return new FastBuffer(buf.buffer, buf.byteOffset, n);
        }
        const dst = Buffer.allocUnsafe(n);
        do {
          const buf = this._buffers[0];
          const offset = dst.length - n;
          if (n >= buf.length) {
            dst.set(this._buffers.shift(), offset);
          } else {
            dst.set(new Uint8Array(buf.buffer, buf.byteOffset, n), offset);
            this._buffers[0] = new FastBuffer(
              buf.buffer,
              buf.byteOffset + n,
              buf.length - n
            );
          }
          n -= buf.length;
        } while (n > 0);
        return dst;
      }
      /**
       * Starts the parsing loop.
       *
       * @param {Function} cb Callback
       * @private
       */
      startLoop(cb) {
        this._loop = true;
        do {
          switch (this._state) {
            case GET_INFO:
              this.getInfo(cb);
              break;
            case GET_PAYLOAD_LENGTH_16:
              this.getPayloadLength16(cb);
              break;
            case GET_PAYLOAD_LENGTH_64:
              this.getPayloadLength64(cb);
              break;
            case GET_MASK:
              this.getMask();
              break;
            case GET_DATA:
              this.getData(cb);
              break;
            case INFLATING:
            case DEFER_EVENT:
              this._loop = false;
              return;
          }
        } while (this._loop);
        if (!this._errored) cb();
      }
      /**
       * Reads the first two bytes of a frame.
       *
       * @param {Function} cb Callback
       * @private
       */
      getInfo(cb) {
        if (this._bufferedBytes < 2) {
          this._loop = false;
          return;
        }
        const buf = this.consume(2);
        if ((buf[0] & 48) !== 0) {
          const error = this.createError(
            RangeError,
            "RSV2 and RSV3 must be clear",
            true,
            1002,
            "WS_ERR_UNEXPECTED_RSV_2_3"
          );
          cb(error);
          return;
        }
        const compressed = (buf[0] & 64) === 64;
        if (compressed && !this._extensions[PerMessageDeflate.extensionName]) {
          const error = this.createError(
            RangeError,
            "RSV1 must be clear",
            true,
            1002,
            "WS_ERR_UNEXPECTED_RSV_1"
          );
          cb(error);
          return;
        }
        this._fin = (buf[0] & 128) === 128;
        this._opcode = buf[0] & 15;
        this._payloadLength = buf[1] & 127;
        if (this._opcode === 0) {
          if (compressed) {
            const error = this.createError(
              RangeError,
              "RSV1 must be clear",
              true,
              1002,
              "WS_ERR_UNEXPECTED_RSV_1"
            );
            cb(error);
            return;
          }
          if (!this._fragmented) {
            const error = this.createError(
              RangeError,
              "invalid opcode 0",
              true,
              1002,
              "WS_ERR_INVALID_OPCODE"
            );
            cb(error);
            return;
          }
          this._opcode = this._fragmented;
        } else if (this._opcode === 1 || this._opcode === 2) {
          if (this._fragmented) {
            const error = this.createError(
              RangeError,
              `invalid opcode ${this._opcode}`,
              true,
              1002,
              "WS_ERR_INVALID_OPCODE"
            );
            cb(error);
            return;
          }
          this._compressed = compressed;
        } else if (this._opcode > 7 && this._opcode < 11) {
          if (!this._fin) {
            const error = this.createError(
              RangeError,
              "FIN must be set",
              true,
              1002,
              "WS_ERR_EXPECTED_FIN"
            );
            cb(error);
            return;
          }
          if (compressed) {
            const error = this.createError(
              RangeError,
              "RSV1 must be clear",
              true,
              1002,
              "WS_ERR_UNEXPECTED_RSV_1"
            );
            cb(error);
            return;
          }
          if (this._payloadLength > 125 || this._opcode === 8 && this._payloadLength === 1) {
            const error = this.createError(
              RangeError,
              `invalid payload length ${this._payloadLength}`,
              true,
              1002,
              "WS_ERR_INVALID_CONTROL_PAYLOAD_LENGTH"
            );
            cb(error);
            return;
          }
        } else {
          const error = this.createError(
            RangeError,
            `invalid opcode ${this._opcode}`,
            true,
            1002,
            "WS_ERR_INVALID_OPCODE"
          );
          cb(error);
          return;
        }
        if (!this._fin && !this._fragmented) this._fragmented = this._opcode;
        this._masked = (buf[1] & 128) === 128;
        if (this._isServer) {
          if (!this._masked) {
            const error = this.createError(
              RangeError,
              "MASK must be set",
              true,
              1002,
              "WS_ERR_EXPECTED_MASK"
            );
            cb(error);
            return;
          }
        } else if (this._masked) {
          const error = this.createError(
            RangeError,
            "MASK must be clear",
            true,
            1002,
            "WS_ERR_UNEXPECTED_MASK"
          );
          cb(error);
          return;
        }
        if (this._payloadLength === 126) this._state = GET_PAYLOAD_LENGTH_16;
        else if (this._payloadLength === 127) this._state = GET_PAYLOAD_LENGTH_64;
        else this.haveLength(cb);
      }
      /**
       * Gets extended payload length (7+16).
       *
       * @param {Function} cb Callback
       * @private
       */
      getPayloadLength16(cb) {
        if (this._bufferedBytes < 2) {
          this._loop = false;
          return;
        }
        this._payloadLength = this.consume(2).readUInt16BE(0);
        this.haveLength(cb);
      }
      /**
       * Gets extended payload length (7+64).
       *
       * @param {Function} cb Callback
       * @private
       */
      getPayloadLength64(cb) {
        if (this._bufferedBytes < 8) {
          this._loop = false;
          return;
        }
        const buf = this.consume(8);
        const num = buf.readUInt32BE(0);
        if (num > Math.pow(2, 53 - 32) - 1) {
          const error = this.createError(
            RangeError,
            "Unsupported WebSocket frame: payload length > 2^53 - 1",
            false,
            1009,
            "WS_ERR_UNSUPPORTED_DATA_PAYLOAD_LENGTH"
          );
          cb(error);
          return;
        }
        this._payloadLength = num * Math.pow(2, 32) + buf.readUInt32BE(4);
        this.haveLength(cb);
      }
      /**
       * Payload length has been read.
       *
       * @param {Function} cb Callback
       * @private
       */
      haveLength(cb) {
        if (this._payloadLength && this._opcode < 8) {
          this._totalPayloadLength += this._payloadLength;
          if (this._totalPayloadLength > this._maxPayload && this._maxPayload > 0) {
            const error = this.createError(
              RangeError,
              "Max payload size exceeded",
              false,
              1009,
              "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH"
            );
            cb(error);
            return;
          }
        }
        if (this._masked) this._state = GET_MASK;
        else this._state = GET_DATA;
      }
      /**
       * Reads mask bytes.
       *
       * @private
       */
      getMask() {
        if (this._bufferedBytes < 4) {
          this._loop = false;
          return;
        }
        this._mask = this.consume(4);
        this._state = GET_DATA;
      }
      /**
       * Reads data bytes.
       *
       * @param {Function} cb Callback
       * @private
       */
      getData(cb) {
        let data = EMPTY_BUFFER;
        if (this._payloadLength) {
          if (this._bufferedBytes < this._payloadLength) {
            this._loop = false;
            return;
          }
          data = this.consume(this._payloadLength);
          if (this._masked && (this._mask[0] | this._mask[1] | this._mask[2] | this._mask[3]) !== 0) {
            unmask(data, this._mask);
          }
        }
        if (this._opcode > 7) {
          this.controlMessage(data, cb);
          return;
        }
        if (this._maxFragments > 0 && ++this._numFragments > this._maxFragments) {
          const error = this.createError(
            RangeError,
            "Too many message fragments",
            false,
            1008,
            "WS_ERR_TOO_MANY_BUFFERED_PARTS"
          );
          cb(error);
          return;
        }
        if (this._compressed) {
          this._state = INFLATING;
          this.decompress(data, cb);
          return;
        }
        if (data.length) {
          this._messageLength = this._totalPayloadLength;
          this._fragments.push(data);
        }
        this.dataMessage(cb);
      }
      /**
       * Decompresses data.
       *
       * @param {Buffer} data Compressed data
       * @param {Function} cb Callback
       * @private
       */
      decompress(data, cb) {
        const perMessageDeflate = this._extensions[PerMessageDeflate.extensionName];
        perMessageDeflate.decompress(data, this._fin, (err, buf) => {
          if (err) return cb(err);
          if (buf.length) {
            this._messageLength += buf.length;
            if (this._messageLength > this._maxPayload && this._maxPayload > 0) {
              const error = this.createError(
                RangeError,
                "Max payload size exceeded",
                false,
                1009,
                "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH"
              );
              cb(error);
              return;
            }
            this._fragments.push(buf);
          }
          this.dataMessage(cb);
          if (this._state === GET_INFO) this.startLoop(cb);
        });
      }
      /**
       * Handles a data message.
       *
       * @param {Function} cb Callback
       * @private
       */
      dataMessage(cb) {
        if (!this._fin) {
          this._state = GET_INFO;
          return;
        }
        const messageLength = this._messageLength;
        const fragments = this._fragments;
        this._totalPayloadLength = 0;
        this._messageLength = 0;
        this._fragmented = 0;
        this._numFragments = 0;
        this._fragments = [];
        if (this._opcode === 2) {
          let data;
          if (this._binaryType === "nodebuffer") {
            data = concat(fragments, messageLength);
          } else if (this._binaryType === "arraybuffer") {
            data = toArrayBuffer(concat(fragments, messageLength));
          } else if (this._binaryType === "blob") {
            data = new Blob(fragments);
          } else {
            data = fragments;
          }
          if (this._allowSynchronousEvents) {
            this.emit("message", data, true);
            this._state = GET_INFO;
          } else {
            this._state = DEFER_EVENT;
            setImmediate(() => {
              this.emit("message", data, true);
              this._state = GET_INFO;
              this.startLoop(cb);
            });
          }
        } else {
          const buf = concat(fragments, messageLength);
          if (!this._skipUTF8Validation && !isValidUTF8(buf)) {
            const error = this.createError(
              Error,
              "invalid UTF-8 sequence",
              true,
              1007,
              "WS_ERR_INVALID_UTF8"
            );
            cb(error);
            return;
          }
          if (this._state === INFLATING || this._allowSynchronousEvents) {
            this.emit("message", buf, false);
            this._state = GET_INFO;
          } else {
            this._state = DEFER_EVENT;
            setImmediate(() => {
              this.emit("message", buf, false);
              this._state = GET_INFO;
              this.startLoop(cb);
            });
          }
        }
      }
      /**
       * Handles a control message.
       *
       * @param {Buffer} data Data to handle
       * @return {(Error|RangeError|undefined)} A possible error
       * @private
       */
      controlMessage(data, cb) {
        if (this._opcode === 8) {
          if (data.length === 0) {
            this._loop = false;
            this.emit("conclude", 1005, EMPTY_BUFFER);
            this.end();
          } else {
            const code = data.readUInt16BE(0);
            if (!isValidStatusCode(code)) {
              const error = this.createError(
                RangeError,
                `invalid status code ${code}`,
                true,
                1002,
                "WS_ERR_INVALID_CLOSE_CODE"
              );
              cb(error);
              return;
            }
            const buf = new FastBuffer(
              data.buffer,
              data.byteOffset + 2,
              data.length - 2
            );
            if (!this._skipUTF8Validation && !isValidUTF8(buf)) {
              const error = this.createError(
                Error,
                "invalid UTF-8 sequence",
                true,
                1007,
                "WS_ERR_INVALID_UTF8"
              );
              cb(error);
              return;
            }
            this._loop = false;
            this.emit("conclude", code, buf);
            this.end();
          }
          this._state = GET_INFO;
          return;
        }
        if (this._allowSynchronousEvents) {
          this.emit(this._opcode === 9 ? "ping" : "pong", data);
          this._state = GET_INFO;
        } else {
          this._state = DEFER_EVENT;
          setImmediate(() => {
            this.emit(this._opcode === 9 ? "ping" : "pong", data);
            this._state = GET_INFO;
            this.startLoop(cb);
          });
        }
      }
      /**
       * Builds an error object.
       *
       * @param {function(new:Error|RangeError)} ErrorCtor The error constructor
       * @param {String} message The error message
       * @param {Boolean} prefix Specifies whether or not to add a default prefix to
       *     `message`
       * @param {Number} statusCode The status code
       * @param {String} errorCode The exposed error code
       * @return {(Error|RangeError)} The error
       * @private
       */
      createError(ErrorCtor, message, prefix, statusCode, errorCode) {
        this._loop = false;
        this._errored = true;
        const err = new ErrorCtor(
          prefix ? `Invalid WebSocket frame: ${message}` : message
        );
        Error.captureStackTrace(err, this.createError);
        err.code = errorCode;
        err[kStatusCode] = statusCode;
        return err;
      }
    };
    module2.exports = Receiver;
  }
});

// node_modules/ws/lib/sender.js
var require_sender = __commonJS({
  "node_modules/ws/lib/sender.js"(exports2, module2) {
    "use strict";
    var { Duplex } = require("stream");
    var { randomFillSync } = require("crypto");
    var {
      types: { isUint8Array }
    } = require("util");
    var PerMessageDeflate = require_permessage_deflate();
    var { EMPTY_BUFFER, kWebSocket, NOOP } = require_constants();
    var { isBlob, isValidStatusCode } = require_validation();
    var { mask: applyMask, toBuffer } = require_buffer_util();
    var kByteLength = /* @__PURE__ */ Symbol("kByteLength");
    var maskBuffer = Buffer.alloc(4);
    var RANDOM_POOL_SIZE = 8 * 1024;
    var randomPool;
    var randomPoolPointer = RANDOM_POOL_SIZE;
    var DEFAULT = 0;
    var DEFLATING = 1;
    var GET_BLOB_DATA = 2;
    var Sender = class _Sender {
      /**
       * Creates a Sender instance.
       *
       * @param {Duplex} socket The connection socket
       * @param {Object} [extensions] An object containing the negotiated extensions
       * @param {Function} [generateMask] The function used to generate the masking
       *     key
       */
      constructor(socket, extensions, generateMask) {
        this._extensions = extensions || {};
        if (generateMask) {
          this._generateMask = generateMask;
          this._maskBuffer = Buffer.alloc(4);
        }
        this._socket = socket;
        this._firstFragment = true;
        this._compress = false;
        this._bufferedBytes = 0;
        this._queue = [];
        this._state = DEFAULT;
        this.onerror = NOOP;
        this[kWebSocket] = void 0;
      }
      /**
       * Frames a piece of data according to the HyBi WebSocket protocol.
       *
       * @param {(Buffer|String)} data The data to frame
       * @param {Object} options Options object
       * @param {Boolean} [options.fin=false] Specifies whether or not to set the
       *     FIN bit
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Buffer} [options.maskBuffer] The buffer used to store the masking
       *     key
       * @param {Number} options.opcode The opcode
       * @param {Boolean} [options.readOnly=false] Specifies whether `data` can be
       *     modified
       * @param {Boolean} [options.rsv1=false] Specifies whether or not to set the
       *     RSV1 bit
       * @return {(Buffer|String)[]} The framed data
       * @public
       */
      static frame(data, options) {
        let mask;
        let merge = false;
        let offset = 2;
        let skipMasking = false;
        if (options.mask) {
          mask = options.maskBuffer || maskBuffer;
          if (options.generateMask) {
            options.generateMask(mask);
          } else {
            if (randomPoolPointer === RANDOM_POOL_SIZE) {
              if (randomPool === void 0) {
                randomPool = Buffer.alloc(RANDOM_POOL_SIZE);
              }
              randomFillSync(randomPool, 0, RANDOM_POOL_SIZE);
              randomPoolPointer = 0;
            }
            mask[0] = randomPool[randomPoolPointer++];
            mask[1] = randomPool[randomPoolPointer++];
            mask[2] = randomPool[randomPoolPointer++];
            mask[3] = randomPool[randomPoolPointer++];
          }
          skipMasking = (mask[0] | mask[1] | mask[2] | mask[3]) === 0;
          offset = 6;
        }
        let dataLength;
        if (typeof data === "string") {
          if ((!options.mask || skipMasking) && options[kByteLength] !== void 0) {
            dataLength = options[kByteLength];
          } else {
            data = Buffer.from(data);
            dataLength = data.length;
          }
        } else {
          dataLength = data.length;
          merge = options.mask && options.readOnly && !skipMasking;
        }
        let payloadLength = dataLength;
        if (dataLength >= 65536) {
          offset += 8;
          payloadLength = 127;
        } else if (dataLength > 125) {
          offset += 2;
          payloadLength = 126;
        }
        const target = Buffer.allocUnsafe(merge ? dataLength + offset : offset);
        target[0] = options.fin ? options.opcode | 128 : options.opcode;
        if (options.rsv1) target[0] |= 64;
        target[1] = payloadLength;
        if (payloadLength === 126) {
          target.writeUInt16BE(dataLength, 2);
        } else if (payloadLength === 127) {
          target[2] = target[3] = 0;
          target.writeUIntBE(dataLength, 4, 6);
        }
        if (!options.mask) return [target, data];
        target[1] |= 128;
        target[offset - 4] = mask[0];
        target[offset - 3] = mask[1];
        target[offset - 2] = mask[2];
        target[offset - 1] = mask[3];
        if (skipMasking) return [target, data];
        if (merge) {
          applyMask(data, mask, target, offset, dataLength);
          return [target];
        }
        applyMask(data, mask, data, 0, dataLength);
        return [target, data];
      }
      /**
       * Sends a close message to the other peer.
       *
       * @param {Number} [code] The status code component of the body
       * @param {(String|Buffer)} [data] The message component of the body
       * @param {Boolean} [mask=false] Specifies whether or not to mask the message
       * @param {Function} [cb] Callback
       * @public
       */
      close(code, data, mask, cb) {
        let buf;
        if (code === void 0) {
          buf = EMPTY_BUFFER;
        } else if (typeof code !== "number" || !isValidStatusCode(code)) {
          throw new TypeError("First argument must be a valid error code number");
        } else if (data === void 0 || !data.length) {
          buf = Buffer.allocUnsafe(2);
          buf.writeUInt16BE(code, 0);
        } else {
          const length = Buffer.byteLength(data);
          if (length > 123) {
            throw new RangeError("The message must not be greater than 123 bytes");
          }
          buf = Buffer.allocUnsafe(2 + length);
          buf.writeUInt16BE(code, 0);
          if (typeof data === "string") {
            buf.write(data, 2);
          } else if (isUint8Array(data)) {
            buf.set(data, 2);
          } else {
            throw new TypeError("Second argument must be a string or a Uint8Array");
          }
        }
        const options = {
          [kByteLength]: buf.length,
          fin: true,
          generateMask: this._generateMask,
          mask,
          maskBuffer: this._maskBuffer,
          opcode: 8,
          readOnly: false,
          rsv1: false
        };
        if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, buf, false, options, cb]);
        } else {
          this.sendFrame(_Sender.frame(buf, options), cb);
        }
      }
      /**
       * Sends a ping message to the other peer.
       *
       * @param {*} data The message to send
       * @param {Boolean} [mask=false] Specifies whether or not to mask `data`
       * @param {Function} [cb] Callback
       * @public
       */
      ping(data, mask, cb) {
        let byteLength;
        let readOnly;
        if (typeof data === "string") {
          byteLength = Buffer.byteLength(data);
          readOnly = false;
        } else if (isBlob(data)) {
          byteLength = data.size;
          readOnly = false;
        } else {
          data = toBuffer(data);
          byteLength = data.length;
          readOnly = toBuffer.readOnly;
        }
        if (byteLength > 125) {
          throw new RangeError("The data size must not be greater than 125 bytes");
        }
        const options = {
          [kByteLength]: byteLength,
          fin: true,
          generateMask: this._generateMask,
          mask,
          maskBuffer: this._maskBuffer,
          opcode: 9,
          readOnly,
          rsv1: false
        };
        if (isBlob(data)) {
          if (this._state !== DEFAULT) {
            this.enqueue([this.getBlobData, data, false, options, cb]);
          } else {
            this.getBlobData(data, false, options, cb);
          }
        } else if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, data, false, options, cb]);
        } else {
          this.sendFrame(_Sender.frame(data, options), cb);
        }
      }
      /**
       * Sends a pong message to the other peer.
       *
       * @param {*} data The message to send
       * @param {Boolean} [mask=false] Specifies whether or not to mask `data`
       * @param {Function} [cb] Callback
       * @public
       */
      pong(data, mask, cb) {
        let byteLength;
        let readOnly;
        if (typeof data === "string") {
          byteLength = Buffer.byteLength(data);
          readOnly = false;
        } else if (isBlob(data)) {
          byteLength = data.size;
          readOnly = false;
        } else {
          data = toBuffer(data);
          byteLength = data.length;
          readOnly = toBuffer.readOnly;
        }
        if (byteLength > 125) {
          throw new RangeError("The data size must not be greater than 125 bytes");
        }
        const options = {
          [kByteLength]: byteLength,
          fin: true,
          generateMask: this._generateMask,
          mask,
          maskBuffer: this._maskBuffer,
          opcode: 10,
          readOnly,
          rsv1: false
        };
        if (isBlob(data)) {
          if (this._state !== DEFAULT) {
            this.enqueue([this.getBlobData, data, false, options, cb]);
          } else {
            this.getBlobData(data, false, options, cb);
          }
        } else if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, data, false, options, cb]);
        } else {
          this.sendFrame(_Sender.frame(data, options), cb);
        }
      }
      /**
       * Sends a data message to the other peer.
       *
       * @param {*} data The message to send
       * @param {Object} options Options object
       * @param {Boolean} [options.binary=false] Specifies whether `data` is binary
       *     or text
       * @param {Boolean} [options.compress=false] Specifies whether or not to
       *     compress `data`
       * @param {Boolean} [options.fin=false] Specifies whether the fragment is the
       *     last one
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Function} [cb] Callback
       * @public
       */
      send(data, options, cb) {
        const perMessageDeflate = this._extensions[PerMessageDeflate.extensionName];
        let opcode = options.binary ? 2 : 1;
        let rsv1 = options.compress;
        let byteLength;
        let readOnly;
        if (typeof data === "string") {
          byteLength = Buffer.byteLength(data);
          readOnly = false;
        } else if (isBlob(data)) {
          byteLength = data.size;
          readOnly = false;
        } else {
          data = toBuffer(data);
          byteLength = data.length;
          readOnly = toBuffer.readOnly;
        }
        if (this._firstFragment) {
          this._firstFragment = false;
          if (rsv1 && perMessageDeflate && perMessageDeflate.params[perMessageDeflate._isServer ? "server_no_context_takeover" : "client_no_context_takeover"]) {
            rsv1 = byteLength >= perMessageDeflate._threshold;
          }
          this._compress = rsv1;
        } else {
          rsv1 = false;
          opcode = 0;
        }
        if (options.fin) this._firstFragment = true;
        const opts = {
          [kByteLength]: byteLength,
          fin: options.fin,
          generateMask: this._generateMask,
          mask: options.mask,
          maskBuffer: this._maskBuffer,
          opcode,
          readOnly,
          rsv1
        };
        if (isBlob(data)) {
          if (this._state !== DEFAULT) {
            this.enqueue([this.getBlobData, data, this._compress, opts, cb]);
          } else {
            this.getBlobData(data, this._compress, opts, cb);
          }
        } else if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, data, this._compress, opts, cb]);
        } else {
          this.dispatch(data, this._compress, opts, cb);
        }
      }
      /**
       * Gets the contents of a blob as binary data.
       *
       * @param {Blob} blob The blob
       * @param {Boolean} [compress=false] Specifies whether or not to compress
       *     the data
       * @param {Object} options Options object
       * @param {Boolean} [options.fin=false] Specifies whether or not to set the
       *     FIN bit
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Buffer} [options.maskBuffer] The buffer used to store the masking
       *     key
       * @param {Number} options.opcode The opcode
       * @param {Boolean} [options.readOnly=false] Specifies whether `data` can be
       *     modified
       * @param {Boolean} [options.rsv1=false] Specifies whether or not to set the
       *     RSV1 bit
       * @param {Function} [cb] Callback
       * @private
       */
      getBlobData(blob, compress, options, cb) {
        this._bufferedBytes += options[kByteLength];
        this._state = GET_BLOB_DATA;
        blob.arrayBuffer().then((arrayBuffer) => {
          if (this._socket.destroyed) {
            const err = new Error(
              "The socket was closed while the blob was being read"
            );
            process.nextTick(callCallbacks, this, err, cb);
            return;
          }
          this._bufferedBytes -= options[kByteLength];
          const data = toBuffer(arrayBuffer);
          if (!compress) {
            this._state = DEFAULT;
            this.sendFrame(_Sender.frame(data, options), cb);
            this.dequeue();
          } else {
            this.dispatch(data, compress, options, cb);
          }
        }).catch((err) => {
          process.nextTick(onError, this, err, cb);
        });
      }
      /**
       * Dispatches a message.
       *
       * @param {(Buffer|String)} data The message to send
       * @param {Boolean} [compress=false] Specifies whether or not to compress
       *     `data`
       * @param {Object} options Options object
       * @param {Boolean} [options.fin=false] Specifies whether or not to set the
       *     FIN bit
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Buffer} [options.maskBuffer] The buffer used to store the masking
       *     key
       * @param {Number} options.opcode The opcode
       * @param {Boolean} [options.readOnly=false] Specifies whether `data` can be
       *     modified
       * @param {Boolean} [options.rsv1=false] Specifies whether or not to set the
       *     RSV1 bit
       * @param {Function} [cb] Callback
       * @private
       */
      dispatch(data, compress, options, cb) {
        if (!compress) {
          this.sendFrame(_Sender.frame(data, options), cb);
          return;
        }
        const perMessageDeflate = this._extensions[PerMessageDeflate.extensionName];
        this._bufferedBytes += options[kByteLength];
        this._state = DEFLATING;
        perMessageDeflate.compress(data, options.fin, (_, buf) => {
          if (this._socket.destroyed) {
            const err = new Error(
              "The socket was closed while data was being compressed"
            );
            callCallbacks(this, err, cb);
            return;
          }
          this._bufferedBytes -= options[kByteLength];
          this._state = DEFAULT;
          options.readOnly = false;
          this.sendFrame(_Sender.frame(buf, options), cb);
          this.dequeue();
        });
      }
      /**
       * Executes queued send operations.
       *
       * @private
       */
      dequeue() {
        while (this._state === DEFAULT && this._queue.length) {
          const params = this._queue.shift();
          this._bufferedBytes -= params[3][kByteLength];
          Reflect.apply(params[0], this, params.slice(1));
        }
      }
      /**
       * Enqueues a send operation.
       *
       * @param {Array} params Send operation parameters.
       * @private
       */
      enqueue(params) {
        this._bufferedBytes += params[3][kByteLength];
        this._queue.push(params);
      }
      /**
       * Sends a frame.
       *
       * @param {(Buffer | String)[]} list The frame to send
       * @param {Function} [cb] Callback
       * @private
       */
      sendFrame(list, cb) {
        if (list.length === 2) {
          this._socket.cork();
          this._socket.write(list[0]);
          this._socket.write(list[1], cb);
          this._socket.uncork();
        } else {
          this._socket.write(list[0], cb);
        }
      }
    };
    module2.exports = Sender;
    function callCallbacks(sender, err, cb) {
      if (typeof cb === "function") cb(err);
      for (let i = 0; i < sender._queue.length; i++) {
        const params = sender._queue[i];
        const callback = params[params.length - 1];
        if (typeof callback === "function") callback(err);
      }
    }
    function onError(sender, err, cb) {
      callCallbacks(sender, err, cb);
      sender.onerror(err);
    }
  }
});

// node_modules/ws/lib/event-target.js
var require_event_target = __commonJS({
  "node_modules/ws/lib/event-target.js"(exports2, module2) {
    "use strict";
    var { kForOnEventAttribute, kListener } = require_constants();
    var kCode = /* @__PURE__ */ Symbol("kCode");
    var kData = /* @__PURE__ */ Symbol("kData");
    var kError = /* @__PURE__ */ Symbol("kError");
    var kMessage = /* @__PURE__ */ Symbol("kMessage");
    var kReason = /* @__PURE__ */ Symbol("kReason");
    var kTarget = /* @__PURE__ */ Symbol("kTarget");
    var kType = /* @__PURE__ */ Symbol("kType");
    var kWasClean = /* @__PURE__ */ Symbol("kWasClean");
    var Event = class {
      /**
       * Create a new `Event`.
       *
       * @param {String} type The name of the event
       * @throws {TypeError} If the `type` argument is not specified
       */
      constructor(type) {
        this[kTarget] = null;
        this[kType] = type;
      }
      /**
       * @type {*}
       */
      get target() {
        return this[kTarget];
      }
      /**
       * @type {String}
       */
      get type() {
        return this[kType];
      }
    };
    Object.defineProperty(Event.prototype, "target", { enumerable: true });
    Object.defineProperty(Event.prototype, "type", { enumerable: true });
    var CloseEvent = class extends Event {
      /**
       * Create a new `CloseEvent`.
       *
       * @param {String} type The name of the event
       * @param {Object} [options] A dictionary object that allows for setting
       *     attributes via object members of the same name
       * @param {Number} [options.code=0] The status code explaining why the
       *     connection was closed
       * @param {String} [options.reason=''] A human-readable string explaining why
       *     the connection was closed
       * @param {Boolean} [options.wasClean=false] Indicates whether or not the
       *     connection was cleanly closed
       */
      constructor(type, options = {}) {
        super(type);
        this[kCode] = options.code === void 0 ? 0 : options.code;
        this[kReason] = options.reason === void 0 ? "" : options.reason;
        this[kWasClean] = options.wasClean === void 0 ? false : options.wasClean;
      }
      /**
       * @type {Number}
       */
      get code() {
        return this[kCode];
      }
      /**
       * @type {String}
       */
      get reason() {
        return this[kReason];
      }
      /**
       * @type {Boolean}
       */
      get wasClean() {
        return this[kWasClean];
      }
    };
    Object.defineProperty(CloseEvent.prototype, "code", { enumerable: true });
    Object.defineProperty(CloseEvent.prototype, "reason", { enumerable: true });
    Object.defineProperty(CloseEvent.prototype, "wasClean", { enumerable: true });
    var ErrorEvent = class extends Event {
      /**
       * Create a new `ErrorEvent`.
       *
       * @param {String} type The name of the event
       * @param {Object} [options] A dictionary object that allows for setting
       *     attributes via object members of the same name
       * @param {*} [options.error=null] The error that generated this event
       * @param {String} [options.message=''] The error message
       */
      constructor(type, options = {}) {
        super(type);
        this[kError] = options.error === void 0 ? null : options.error;
        this[kMessage] = options.message === void 0 ? "" : options.message;
      }
      /**
       * @type {*}
       */
      get error() {
        return this[kError];
      }
      /**
       * @type {String}
       */
      get message() {
        return this[kMessage];
      }
    };
    Object.defineProperty(ErrorEvent.prototype, "error", { enumerable: true });
    Object.defineProperty(ErrorEvent.prototype, "message", { enumerable: true });
    var MessageEvent = class extends Event {
      /**
       * Create a new `MessageEvent`.
       *
       * @param {String} type The name of the event
       * @param {Object} [options] A dictionary object that allows for setting
       *     attributes via object members of the same name
       * @param {*} [options.data=null] The message content
       */
      constructor(type, options = {}) {
        super(type);
        this[kData] = options.data === void 0 ? null : options.data;
      }
      /**
       * @type {*}
       */
      get data() {
        return this[kData];
      }
    };
    Object.defineProperty(MessageEvent.prototype, "data", { enumerable: true });
    var EventTarget = {
      /**
       * Register an event listener.
       *
       * @param {String} type A string representing the event type to listen for
       * @param {(Function|Object)} handler The listener to add
       * @param {Object} [options] An options object specifies characteristics about
       *     the event listener
       * @param {Boolean} [options.once=false] A `Boolean` indicating that the
       *     listener should be invoked at most once after being added. If `true`,
       *     the listener would be automatically removed when invoked.
       * @public
       */
      addEventListener(type, handler, options = {}) {
        for (const listener of this.listeners(type)) {
          if (!options[kForOnEventAttribute] && listener[kListener] === handler && !listener[kForOnEventAttribute]) {
            return;
          }
        }
        let wrapper;
        if (type === "message") {
          wrapper = function onMessage(data, isBinary) {
            const event = new MessageEvent("message", {
              data: isBinary ? data : data.toString()
            });
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else if (type === "close") {
          wrapper = function onClose(code, message) {
            const event = new CloseEvent("close", {
              code,
              reason: message.toString(),
              wasClean: this._closeFrameReceived && this._closeFrameSent
            });
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else if (type === "error") {
          wrapper = function onError(error) {
            const event = new ErrorEvent("error", {
              error,
              message: error.message
            });
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else if (type === "open") {
          wrapper = function onOpen() {
            const event = new Event("open");
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else {
          return;
        }
        wrapper[kForOnEventAttribute] = !!options[kForOnEventAttribute];
        wrapper[kListener] = handler;
        if (options.once) {
          this.once(type, wrapper);
        } else {
          this.on(type, wrapper);
        }
      },
      /**
       * Remove an event listener.
       *
       * @param {String} type A string representing the event type to remove
       * @param {(Function|Object)} handler The listener to remove
       * @public
       */
      removeEventListener(type, handler) {
        for (const listener of this.listeners(type)) {
          if (listener[kListener] === handler && !listener[kForOnEventAttribute]) {
            this.removeListener(type, listener);
            break;
          }
        }
      }
    };
    module2.exports = {
      CloseEvent,
      ErrorEvent,
      Event,
      EventTarget,
      MessageEvent
    };
    function callListener(listener, thisArg, event) {
      if (typeof listener === "object" && listener.handleEvent) {
        listener.handleEvent.call(listener, event);
      } else {
        listener.call(thisArg, event);
      }
    }
  }
});

// node_modules/ws/lib/extension.js
var require_extension = __commonJS({
  "node_modules/ws/lib/extension.js"(exports2, module2) {
    "use strict";
    var { tokenChars } = require_validation();
    function push(dest, name, elem) {
      if (dest[name] === void 0) dest[name] = [elem];
      else dest[name].push(elem);
    }
    function parse(header) {
      const offers = /* @__PURE__ */ Object.create(null);
      let params = /* @__PURE__ */ Object.create(null);
      let mustUnescape = false;
      let isEscaping = false;
      let inQuotes = false;
      let extensionName;
      let paramName;
      let start = -1;
      let code = -1;
      let end = -1;
      let i = 0;
      for (; i < header.length; i++) {
        code = header.charCodeAt(i);
        if (extensionName === void 0) {
          if (end === -1 && tokenChars[code] === 1) {
            if (start === -1) start = i;
          } else if (i !== 0 && (code === 32 || code === 9)) {
            if (end === -1 && start !== -1) end = i;
          } else if (code === 59 || code === 44) {
            if (start === -1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (end === -1) end = i;
            const name = header.slice(start, end);
            if (code === 44) {
              push(offers, name, params);
              params = /* @__PURE__ */ Object.create(null);
            } else {
              extensionName = name;
            }
            start = end = -1;
          } else {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
        } else if (paramName === void 0) {
          if (end === -1 && tokenChars[code] === 1) {
            if (start === -1) start = i;
          } else if (code === 32 || code === 9) {
            if (end === -1 && start !== -1) end = i;
          } else if (code === 59 || code === 44) {
            if (start === -1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (end === -1) end = i;
            push(params, header.slice(start, end), true);
            if (code === 44) {
              push(offers, extensionName, params);
              params = /* @__PURE__ */ Object.create(null);
              extensionName = void 0;
            }
            start = end = -1;
          } else if (code === 61 && start !== -1 && end === -1) {
            paramName = header.slice(start, i);
            start = end = -1;
          } else {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
        } else {
          if (isEscaping) {
            if (tokenChars[code] !== 1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (start === -1) start = i;
            else if (!mustUnescape) mustUnescape = true;
            isEscaping = false;
          } else if (inQuotes) {
            if (tokenChars[code] === 1) {
              if (start === -1) start = i;
            } else if (code === 34 && start !== -1) {
              inQuotes = false;
              end = i;
            } else if (code === 92) {
              isEscaping = true;
            } else {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
          } else if (code === 34 && header.charCodeAt(i - 1) === 61) {
            inQuotes = true;
          } else if (end === -1 && tokenChars[code] === 1) {
            if (start === -1) start = i;
          } else if (start !== -1 && (code === 32 || code === 9)) {
            if (end === -1) end = i;
          } else if (code === 59 || code === 44) {
            if (start === -1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (end === -1) end = i;
            let value = header.slice(start, end);
            if (mustUnescape) {
              value = value.replace(/\\/g, "");
              mustUnescape = false;
            }
            push(params, paramName, value);
            if (code === 44) {
              push(offers, extensionName, params);
              params = /* @__PURE__ */ Object.create(null);
              extensionName = void 0;
            }
            paramName = void 0;
            start = end = -1;
          } else {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
        }
      }
      if (start === -1 || inQuotes || code === 32 || code === 9) {
        throw new SyntaxError("Unexpected end of input");
      }
      if (end === -1) end = i;
      const token = header.slice(start, end);
      if (extensionName === void 0) {
        push(offers, token, params);
      } else {
        if (paramName === void 0) {
          push(params, token, true);
        } else if (mustUnescape) {
          push(params, paramName, token.replace(/\\/g, ""));
        } else {
          push(params, paramName, token);
        }
        push(offers, extensionName, params);
      }
      return offers;
    }
    function format(extensions) {
      return Object.keys(extensions).map((extension) => {
        let configurations = extensions[extension];
        if (!Array.isArray(configurations)) configurations = [configurations];
        return configurations.map((params) => {
          return [extension].concat(
            Object.keys(params).map((k) => {
              let values = params[k];
              if (!Array.isArray(values)) values = [values];
              return values.map((v) => v === true ? k : `${k}=${v}`).join("; ");
            })
          ).join("; ");
        }).join(", ");
      }).join(", ");
    }
    module2.exports = { format, parse };
  }
});

// node_modules/ws/lib/websocket.js
var require_websocket = __commonJS({
  "node_modules/ws/lib/websocket.js"(exports2, module2) {
    "use strict";
    var EventEmitter = require("events");
    var https4 = require("https");
    var http5 = require("http");
    var net = require("net");
    var tls = require("tls");
    var { randomBytes, createHash } = require("crypto");
    var { Duplex, Readable } = require("stream");
    var { URL: URL2 } = require("url");
    var PerMessageDeflate = require_permessage_deflate();
    var Receiver = require_receiver();
    var Sender = require_sender();
    var { isBlob } = require_validation();
    var {
      BINARY_TYPES,
      CLOSE_TIMEOUT,
      EMPTY_BUFFER,
      GUID,
      kForOnEventAttribute,
      kListener,
      kStatusCode,
      kWebSocket,
      NOOP
    } = require_constants();
    var {
      EventTarget: { addEventListener, removeEventListener }
    } = require_event_target();
    var { format, parse } = require_extension();
    var { toBuffer } = require_buffer_util();
    var kAborted = /* @__PURE__ */ Symbol("kAborted");
    var protocolVersions = [8, 13];
    var readyStates = ["CONNECTING", "OPEN", "CLOSING", "CLOSED"];
    var subprotocolRegex = /^[!#$%&'*+\-.0-9A-Z^_`|a-z~]+$/;
    var WebSocket2 = class _WebSocket extends EventEmitter {
      /**
       * Create a new `WebSocket`.
       *
       * @param {(String|URL)} address The URL to which to connect
       * @param {(String|String[])} [protocols] The subprotocols
       * @param {Object} [options] Connection options
       */
      constructor(address, protocols, options) {
        super();
        this._binaryType = BINARY_TYPES[0];
        this._closeCode = 1006;
        this._closeFrameReceived = false;
        this._closeFrameSent = false;
        this._closeMessage = EMPTY_BUFFER;
        this._closeTimer = null;
        this._errorEmitted = false;
        this._extensions = {};
        this._paused = false;
        this._protocol = "";
        this._readyState = _WebSocket.CONNECTING;
        this._receiver = null;
        this._sender = null;
        this._socket = null;
        if (address !== null) {
          this._bufferedAmount = 0;
          this._isServer = false;
          this._redirects = 0;
          if (protocols === void 0) {
            protocols = [];
          } else if (!Array.isArray(protocols)) {
            if (typeof protocols === "object" && protocols !== null) {
              options = protocols;
              protocols = [];
            } else {
              protocols = [protocols];
            }
          }
          initAsClient(this, address, protocols, options);
        } else {
          this._autoPong = options.autoPong;
          this._closeTimeout = options.closeTimeout;
          this._isServer = true;
        }
      }
      /**
       * For historical reasons, the custom "nodebuffer" type is used by the default
       * instead of "blob".
       *
       * @type {String}
       */
      get binaryType() {
        return this._binaryType;
      }
      set binaryType(type) {
        if (!BINARY_TYPES.includes(type)) return;
        this._binaryType = type;
        if (this._receiver) this._receiver._binaryType = type;
      }
      /**
       * @type {Number}
       */
      get bufferedAmount() {
        if (!this._socket) return this._bufferedAmount;
        return this._socket._writableState.length + this._sender._bufferedBytes;
      }
      /**
       * @type {String}
       */
      get extensions() {
        return Object.keys(this._extensions).join();
      }
      /**
       * @type {Boolean}
       */
      get isPaused() {
        return this._paused;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onclose() {
        return null;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onerror() {
        return null;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onopen() {
        return null;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onmessage() {
        return null;
      }
      /**
       * @type {String}
       */
      get protocol() {
        return this._protocol;
      }
      /**
       * @type {Number}
       */
      get readyState() {
        return this._readyState;
      }
      /**
       * @type {String}
       */
      get url() {
        return this._url;
      }
      /**
       * Set up the socket and the internal resources.
       *
       * @param {Duplex} socket The network socket between the server and client
       * @param {Buffer} head The first packet of the upgraded stream
       * @param {Object} options Options object
       * @param {Boolean} [options.allowSynchronousEvents=false] Specifies whether
       *     any of the `'message'`, `'ping'`, and `'pong'` events can be emitted
       *     multiple times in the same tick
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Number} [options.maxBufferedChunks=0] The maximum number of
       *     buffered data chunks
       * @param {Number} [options.maxFragments=0] The maximum number of message
       *     fragments
       * @param {Number} [options.maxPayload=0] The maximum allowed message size
       * @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
       *     not to skip UTF-8 validation for text and close messages
       * @private
       */
      setSocket(socket, head, options) {
        const receiver = new Receiver({
          allowSynchronousEvents: options.allowSynchronousEvents,
          binaryType: this.binaryType,
          extensions: this._extensions,
          isServer: this._isServer,
          maxBufferedChunks: options.maxBufferedChunks,
          maxFragments: options.maxFragments,
          maxPayload: options.maxPayload,
          skipUTF8Validation: options.skipUTF8Validation
        });
        const sender = new Sender(socket, this._extensions, options.generateMask);
        this._receiver = receiver;
        this._sender = sender;
        this._socket = socket;
        receiver[kWebSocket] = this;
        sender[kWebSocket] = this;
        socket[kWebSocket] = this;
        receiver.on("conclude", receiverOnConclude);
        receiver.on("drain", receiverOnDrain);
        receiver.on("error", receiverOnError);
        receiver.on("message", receiverOnMessage);
        receiver.on("ping", receiverOnPing);
        receiver.on("pong", receiverOnPong);
        sender.onerror = senderOnError;
        if (socket.setTimeout) socket.setTimeout(0);
        if (socket.setNoDelay) socket.setNoDelay();
        if (head.length > 0) socket.unshift(head);
        socket.on("close", socketOnClose);
        socket.on("data", socketOnData);
        socket.on("end", socketOnEnd);
        socket.on("error", socketOnError);
        this._readyState = _WebSocket.OPEN;
        this.emit("open");
      }
      /**
       * Emit the `'close'` event.
       *
       * @private
       */
      emitClose() {
        if (!this._socket) {
          this._readyState = _WebSocket.CLOSED;
          this.emit("close", this._closeCode, this._closeMessage);
          return;
        }
        if (this._extensions[PerMessageDeflate.extensionName]) {
          this._extensions[PerMessageDeflate.extensionName].cleanup();
        }
        this._receiver.removeAllListeners();
        this._readyState = _WebSocket.CLOSED;
        this.emit("close", this._closeCode, this._closeMessage);
      }
      /**
       * Start a closing handshake.
       *
       *          +----------+   +-----------+   +----------+
       *     - - -|ws.close()|-->|close frame|-->|ws.close()|- - -
       *    |     +----------+   +-----------+   +----------+     |
       *          +----------+   +-----------+         |
       * CLOSING  |ws.close()|<--|close frame|<--+-----+       CLOSING
       *          +----------+   +-----------+   |
       *    |           |                        |   +---+        |
       *                +------------------------+-->|fin| - - - -
       *    |         +---+                      |   +---+
       *     - - - - -|fin|<---------------------+
       *              +---+
       *
       * @param {Number} [code] Status code explaining why the connection is closing
       * @param {(String|Buffer)} [data] The reason why the connection is
       *     closing
       * @public
       */
      close(code, data) {
        if (this.readyState === _WebSocket.CLOSED) return;
        if (this.readyState === _WebSocket.CONNECTING) {
          const msg = "WebSocket was closed before the connection was established";
          abortHandshake(this, this._req, msg);
          return;
        }
        if (this.readyState === _WebSocket.CLOSING) {
          if (this._closeFrameSent && (this._closeFrameReceived || this._receiver._writableState.errorEmitted)) {
            this._socket.end();
          }
          return;
        }
        this._readyState = _WebSocket.CLOSING;
        this._sender.close(code, data, !this._isServer, (err) => {
          if (err) return;
          this._closeFrameSent = true;
          if (this._closeFrameReceived || this._receiver._writableState.errorEmitted) {
            this._socket.end();
          }
        });
        setCloseTimer(this);
      }
      /**
       * Pause the socket.
       *
       * @public
       */
      pause() {
        if (this.readyState === _WebSocket.CONNECTING || this.readyState === _WebSocket.CLOSED) {
          return;
        }
        this._paused = true;
        this._socket.pause();
      }
      /**
       * Send a ping.
       *
       * @param {*} [data] The data to send
       * @param {Boolean} [mask] Indicates whether or not to mask `data`
       * @param {Function} [cb] Callback which is executed when the ping is sent
       * @public
       */
      ping(data, mask, cb) {
        if (this.readyState === _WebSocket.CONNECTING) {
          throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
        }
        if (typeof data === "function") {
          cb = data;
          data = mask = void 0;
        } else if (typeof mask === "function") {
          cb = mask;
          mask = void 0;
        }
        if (typeof data === "number") data = data.toString();
        if (this.readyState !== _WebSocket.OPEN) {
          sendAfterClose(this, data, cb);
          return;
        }
        if (mask === void 0) mask = !this._isServer;
        this._sender.ping(data || EMPTY_BUFFER, mask, cb);
      }
      /**
       * Send a pong.
       *
       * @param {*} [data] The data to send
       * @param {Boolean} [mask] Indicates whether or not to mask `data`
       * @param {Function} [cb] Callback which is executed when the pong is sent
       * @public
       */
      pong(data, mask, cb) {
        if (this.readyState === _WebSocket.CONNECTING) {
          throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
        }
        if (typeof data === "function") {
          cb = data;
          data = mask = void 0;
        } else if (typeof mask === "function") {
          cb = mask;
          mask = void 0;
        }
        if (typeof data === "number") data = data.toString();
        if (this.readyState !== _WebSocket.OPEN) {
          sendAfterClose(this, data, cb);
          return;
        }
        if (mask === void 0) mask = !this._isServer;
        this._sender.pong(data || EMPTY_BUFFER, mask, cb);
      }
      /**
       * Resume the socket.
       *
       * @public
       */
      resume() {
        if (this.readyState === _WebSocket.CONNECTING || this.readyState === _WebSocket.CLOSED) {
          return;
        }
        this._paused = false;
        if (!this._receiver._writableState.needDrain) this._socket.resume();
      }
      /**
       * Send a data message.
       *
       * @param {*} data The message to send
       * @param {Object} [options] Options object
       * @param {Boolean} [options.binary] Specifies whether `data` is binary or
       *     text
       * @param {Boolean} [options.compress] Specifies whether or not to compress
       *     `data`
       * @param {Boolean} [options.fin=true] Specifies whether the fragment is the
       *     last one
       * @param {Boolean} [options.mask] Specifies whether or not to mask `data`
       * @param {Function} [cb] Callback which is executed when data is written out
       * @public
       */
      send(data, options, cb) {
        if (this.readyState === _WebSocket.CONNECTING) {
          throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
        }
        if (typeof options === "function") {
          cb = options;
          options = {};
        }
        if (typeof data === "number") data = data.toString();
        if (this.readyState !== _WebSocket.OPEN) {
          sendAfterClose(this, data, cb);
          return;
        }
        const opts = {
          binary: typeof data !== "string",
          mask: !this._isServer,
          compress: true,
          fin: true,
          ...options
        };
        if (!this._extensions[PerMessageDeflate.extensionName]) {
          opts.compress = false;
        }
        this._sender.send(data || EMPTY_BUFFER, opts, cb);
      }
      /**
       * Forcibly close the connection.
       *
       * @public
       */
      terminate() {
        if (this.readyState === _WebSocket.CLOSED) return;
        if (this.readyState === _WebSocket.CONNECTING) {
          const msg = "WebSocket was closed before the connection was established";
          abortHandshake(this, this._req, msg);
          return;
        }
        if (this._socket) {
          this._readyState = _WebSocket.CLOSING;
          this._socket.destroy();
        }
      }
    };
    Object.defineProperty(WebSocket2, "CONNECTING", {
      enumerable: true,
      value: readyStates.indexOf("CONNECTING")
    });
    Object.defineProperty(WebSocket2.prototype, "CONNECTING", {
      enumerable: true,
      value: readyStates.indexOf("CONNECTING")
    });
    Object.defineProperty(WebSocket2, "OPEN", {
      enumerable: true,
      value: readyStates.indexOf("OPEN")
    });
    Object.defineProperty(WebSocket2.prototype, "OPEN", {
      enumerable: true,
      value: readyStates.indexOf("OPEN")
    });
    Object.defineProperty(WebSocket2, "CLOSING", {
      enumerable: true,
      value: readyStates.indexOf("CLOSING")
    });
    Object.defineProperty(WebSocket2.prototype, "CLOSING", {
      enumerable: true,
      value: readyStates.indexOf("CLOSING")
    });
    Object.defineProperty(WebSocket2, "CLOSED", {
      enumerable: true,
      value: readyStates.indexOf("CLOSED")
    });
    Object.defineProperty(WebSocket2.prototype, "CLOSED", {
      enumerable: true,
      value: readyStates.indexOf("CLOSED")
    });
    [
      "binaryType",
      "bufferedAmount",
      "extensions",
      "isPaused",
      "protocol",
      "readyState",
      "url"
    ].forEach((property) => {
      Object.defineProperty(WebSocket2.prototype, property, { enumerable: true });
    });
    ["open", "error", "close", "message"].forEach((method) => {
      Object.defineProperty(WebSocket2.prototype, `on${method}`, {
        enumerable: true,
        get() {
          for (const listener of this.listeners(method)) {
            if (listener[kForOnEventAttribute]) return listener[kListener];
          }
          return null;
        },
        set(handler) {
          for (const listener of this.listeners(method)) {
            if (listener[kForOnEventAttribute]) {
              this.removeListener(method, listener);
              break;
            }
          }
          if (typeof handler !== "function") return;
          this.addEventListener(method, handler, {
            [kForOnEventAttribute]: true
          });
        }
      });
    });
    WebSocket2.prototype.addEventListener = addEventListener;
    WebSocket2.prototype.removeEventListener = removeEventListener;
    module2.exports = WebSocket2;
    function initAsClient(websocket, address, protocols, options) {
      const opts = {
        allowSynchronousEvents: true,
        autoPong: true,
        closeTimeout: CLOSE_TIMEOUT,
        protocolVersion: protocolVersions[1],
        maxBufferedChunks: 256 * 1024,
        maxFragments: 16 * 1024,
        maxPayload: 100 * 1024 * 1024,
        skipUTF8Validation: false,
        perMessageDeflate: true,
        followRedirects: false,
        maxRedirects: 10,
        ...options,
        socketPath: void 0,
        hostname: void 0,
        protocol: void 0,
        timeout: void 0,
        method: "GET",
        host: void 0,
        path: void 0,
        port: void 0
      };
      websocket._autoPong = opts.autoPong;
      websocket._closeTimeout = opts.closeTimeout;
      if (!protocolVersions.includes(opts.protocolVersion)) {
        throw new RangeError(
          `Unsupported protocol version: ${opts.protocolVersion} (supported versions: ${protocolVersions.join(", ")})`
        );
      }
      let parsedUrl;
      if (address instanceof URL2) {
        parsedUrl = address;
      } else {
        try {
          parsedUrl = new URL2(address);
        } catch {
          throw new SyntaxError(`Invalid URL: ${address}`);
        }
      }
      if (parsedUrl.protocol === "http:") {
        parsedUrl.protocol = "ws:";
      } else if (parsedUrl.protocol === "https:") {
        parsedUrl.protocol = "wss:";
      }
      websocket._url = parsedUrl.href;
      const isSecure = parsedUrl.protocol === "wss:";
      const isIpcUrl = parsedUrl.protocol === "ws+unix:";
      let invalidUrlMessage;
      if (parsedUrl.protocol !== "ws:" && !isSecure && !isIpcUrl) {
        invalidUrlMessage = `The URL's protocol must be one of "ws:", "wss:", "http:", "https:", or "ws+unix:"`;
      } else if (isIpcUrl && !parsedUrl.pathname) {
        invalidUrlMessage = "The URL's pathname is empty";
      } else if (parsedUrl.hash) {
        invalidUrlMessage = "The URL contains a fragment identifier";
      }
      if (invalidUrlMessage) {
        const err = new SyntaxError(invalidUrlMessage);
        if (websocket._redirects === 0) {
          throw err;
        } else {
          emitErrorAndClose(websocket, err);
          return;
        }
      }
      const defaultPort = isSecure ? 443 : 80;
      const key = randomBytes(16).toString("base64");
      const request = isSecure ? https4.request : http5.request;
      const protocolSet = /* @__PURE__ */ new Set();
      let perMessageDeflate;
      opts.createConnection = opts.createConnection || (isSecure ? tlsConnect : netConnect);
      opts.defaultPort = opts.defaultPort || defaultPort;
      opts.port = parsedUrl.port || defaultPort;
      opts.host = parsedUrl.hostname.startsWith("[") ? parsedUrl.hostname.slice(1, -1) : parsedUrl.hostname;
      opts.headers = {
        ...opts.headers,
        "Sec-WebSocket-Version": opts.protocolVersion,
        "Sec-WebSocket-Key": key,
        Connection: "Upgrade",
        Upgrade: "websocket"
      };
      opts.path = parsedUrl.pathname + parsedUrl.search;
      opts.timeout = opts.handshakeTimeout;
      if (opts.perMessageDeflate) {
        perMessageDeflate = new PerMessageDeflate({
          ...opts.perMessageDeflate,
          isServer: false,
          maxPayload: opts.maxPayload
        });
        opts.headers["Sec-WebSocket-Extensions"] = format({
          [PerMessageDeflate.extensionName]: perMessageDeflate.offer()
        });
      }
      if (protocols.length) {
        for (const protocol of protocols) {
          if (typeof protocol !== "string" || !subprotocolRegex.test(protocol) || protocolSet.has(protocol)) {
            throw new SyntaxError(
              "An invalid or duplicated subprotocol was specified"
            );
          }
          protocolSet.add(protocol);
        }
        opts.headers["Sec-WebSocket-Protocol"] = protocols.join(",");
      }
      if (opts.origin) {
        if (opts.protocolVersion < 13) {
          opts.headers["Sec-WebSocket-Origin"] = opts.origin;
        } else {
          opts.headers.Origin = opts.origin;
        }
      }
      if (parsedUrl.username || parsedUrl.password) {
        opts.auth = `${parsedUrl.username}:${parsedUrl.password}`;
      }
      if (isIpcUrl) {
        const parts = opts.path.split(":");
        opts.socketPath = parts[0];
        opts.path = parts[1];
      }
      let req;
      if (opts.followRedirects) {
        if (websocket._redirects === 0) {
          websocket._originalIpc = isIpcUrl;
          websocket._originalSecure = isSecure;
          websocket._originalHostOrSocketPath = isIpcUrl ? opts.socketPath : parsedUrl.host;
          const headers = options && options.headers;
          options = { ...options, headers: {} };
          if (headers) {
            for (const [key2, value] of Object.entries(headers)) {
              options.headers[key2.toLowerCase()] = value;
            }
          }
        } else if (websocket.listenerCount("redirect") === 0) {
          const isSameHost = isIpcUrl ? websocket._originalIpc ? opts.socketPath === websocket._originalHostOrSocketPath : false : websocket._originalIpc ? false : parsedUrl.host === websocket._originalHostOrSocketPath;
          if (!isSameHost || websocket._originalSecure && !isSecure) {
            delete opts.headers.authorization;
            delete opts.headers.cookie;
            if (!isSameHost) delete opts.headers.host;
            opts.auth = void 0;
          }
        }
        if (opts.auth && !options.headers.authorization) {
          options.headers.authorization = "Basic " + Buffer.from(opts.auth).toString("base64");
        }
        req = websocket._req = request(opts);
        if (websocket._redirects) {
          websocket.emit("redirect", websocket.url, req);
        }
      } else {
        req = websocket._req = request(opts);
      }
      if (opts.timeout) {
        req.on("timeout", () => {
          abortHandshake(websocket, req, "Opening handshake has timed out");
        });
      }
      req.on("error", (err) => {
        if (req === null || req[kAborted]) return;
        req = websocket._req = null;
        emitErrorAndClose(websocket, err);
      });
      req.on("response", (res) => {
        const location = res.headers.location;
        const statusCode = res.statusCode;
        if (location && opts.followRedirects && statusCode >= 300 && statusCode < 400) {
          if (++websocket._redirects > opts.maxRedirects) {
            abortHandshake(websocket, req, "Maximum redirects exceeded");
            return;
          }
          req.abort();
          let addr;
          try {
            addr = new URL2(location, address);
          } catch (e) {
            const err = new SyntaxError(`Invalid URL: ${location}`);
            emitErrorAndClose(websocket, err);
            return;
          }
          initAsClient(websocket, addr, protocols, options);
        } else if (!websocket.emit("unexpected-response", req, res)) {
          abortHandshake(
            websocket,
            req,
            `Unexpected server response: ${res.statusCode}`
          );
        }
      });
      req.on("upgrade", (res, socket, head) => {
        websocket.emit("upgrade", res);
        if (websocket.readyState !== WebSocket2.CONNECTING) return;
        req = websocket._req = null;
        const upgrade = res.headers.upgrade;
        if (upgrade === void 0 || upgrade.toLowerCase() !== "websocket") {
          abortHandshake(websocket, socket, "Invalid Upgrade header");
          return;
        }
        const digest = createHash("sha1").update(key + GUID).digest("base64");
        if (res.headers["sec-websocket-accept"] !== digest) {
          abortHandshake(websocket, socket, "Invalid Sec-WebSocket-Accept header");
          return;
        }
        const serverProt = res.headers["sec-websocket-protocol"];
        let protError;
        if (serverProt !== void 0) {
          if (!protocolSet.size) {
            protError = "Server sent a subprotocol but none was requested";
          } else if (!protocolSet.has(serverProt)) {
            protError = "Server sent an invalid subprotocol";
          }
        } else if (protocolSet.size) {
          protError = "Server sent no subprotocol";
        }
        if (protError) {
          abortHandshake(websocket, socket, protError);
          return;
        }
        if (serverProt) websocket._protocol = serverProt;
        const secWebSocketExtensions = res.headers["sec-websocket-extensions"];
        if (secWebSocketExtensions !== void 0) {
          if (!perMessageDeflate) {
            const message = "Server sent a Sec-WebSocket-Extensions header but no extension was requested";
            abortHandshake(websocket, socket, message);
            return;
          }
          let extensions;
          try {
            extensions = parse(secWebSocketExtensions);
          } catch (err) {
            const message = "Invalid Sec-WebSocket-Extensions header";
            abortHandshake(websocket, socket, message);
            return;
          }
          const extensionNames = Object.keys(extensions);
          if (extensionNames.length !== 1 || extensionNames[0] !== PerMessageDeflate.extensionName) {
            const message = "Server indicated an extension that was not requested";
            abortHandshake(websocket, socket, message);
            return;
          }
          try {
            perMessageDeflate.accept(extensions[PerMessageDeflate.extensionName]);
          } catch (err) {
            const message = "Invalid Sec-WebSocket-Extensions header";
            abortHandshake(websocket, socket, message);
            return;
          }
          websocket._extensions[PerMessageDeflate.extensionName] = perMessageDeflate;
        }
        websocket.setSocket(socket, head, {
          allowSynchronousEvents: opts.allowSynchronousEvents,
          generateMask: opts.generateMask,
          maxBufferedChunks: opts.maxBufferedChunks,
          maxFragments: opts.maxFragments,
          maxPayload: opts.maxPayload,
          skipUTF8Validation: opts.skipUTF8Validation
        });
      });
      if (opts.finishRequest) {
        opts.finishRequest(req, websocket);
      } else {
        req.end();
      }
    }
    function emitErrorAndClose(websocket, err) {
      websocket._readyState = WebSocket2.CLOSING;
      websocket._errorEmitted = true;
      websocket.emit("error", err);
      websocket.emitClose();
    }
    function netConnect(options) {
      options.path = options.socketPath;
      return net.connect(options);
    }
    function tlsConnect(options) {
      options.path = void 0;
      if (!options.servername && options.servername !== "") {
        options.servername = net.isIP(options.host) ? "" : options.host;
      }
      return tls.connect(options);
    }
    function abortHandshake(websocket, stream, message) {
      websocket._readyState = WebSocket2.CLOSING;
      const err = new Error(message);
      Error.captureStackTrace(err, abortHandshake);
      if (stream.setHeader) {
        stream[kAborted] = true;
        stream.abort();
        if (stream.socket && !stream.socket.destroyed) {
          stream.socket.destroy();
        }
        process.nextTick(emitErrorAndClose, websocket, err);
      } else {
        stream.destroy(err);
        stream.once("error", websocket.emit.bind(websocket, "error"));
        stream.once("close", websocket.emitClose.bind(websocket));
      }
    }
    function sendAfterClose(websocket, data, cb) {
      if (data) {
        const length = isBlob(data) ? data.size : toBuffer(data).length;
        if (websocket._socket) websocket._sender._bufferedBytes += length;
        else websocket._bufferedAmount += length;
      }
      if (cb) {
        const err = new Error(
          `WebSocket is not open: readyState ${websocket.readyState} (${readyStates[websocket.readyState]})`
        );
        process.nextTick(cb, err);
      }
    }
    function receiverOnConclude(code, reason) {
      const websocket = this[kWebSocket];
      websocket._closeFrameReceived = true;
      websocket._closeMessage = reason;
      websocket._closeCode = code;
      if (websocket._socket[kWebSocket] === void 0) return;
      websocket._socket.removeListener("data", socketOnData);
      process.nextTick(resume, websocket._socket);
      if (code === 1005) websocket.close();
      else websocket.close(code, reason);
    }
    function receiverOnDrain() {
      const websocket = this[kWebSocket];
      if (!websocket.isPaused) websocket._socket.resume();
    }
    function receiverOnError(err) {
      const websocket = this[kWebSocket];
      if (websocket._socket[kWebSocket] !== void 0) {
        websocket._socket.removeListener("data", socketOnData);
        process.nextTick(resume, websocket._socket);
        websocket.close(err[kStatusCode]);
      }
      if (!websocket._errorEmitted) {
        websocket._errorEmitted = true;
        websocket.emit("error", err);
      }
    }
    function receiverOnFinish() {
      this[kWebSocket].emitClose();
    }
    function receiverOnMessage(data, isBinary) {
      this[kWebSocket].emit("message", data, isBinary);
    }
    function receiverOnPing(data) {
      const websocket = this[kWebSocket];
      if (websocket._autoPong) websocket.pong(data, !this._isServer, NOOP);
      websocket.emit("ping", data);
    }
    function receiverOnPong(data) {
      this[kWebSocket].emit("pong", data);
    }
    function resume(stream) {
      stream.resume();
    }
    function senderOnError(err) {
      const websocket = this[kWebSocket];
      if (websocket.readyState === WebSocket2.CLOSED) return;
      if (websocket.readyState === WebSocket2.OPEN) {
        websocket._readyState = WebSocket2.CLOSING;
        setCloseTimer(websocket);
      }
      this._socket.end();
      if (!websocket._errorEmitted) {
        websocket._errorEmitted = true;
        websocket.emit("error", err);
      }
    }
    function setCloseTimer(websocket) {
      websocket._closeTimer = setTimeout(
        websocket._socket.destroy.bind(websocket._socket),
        websocket._closeTimeout
      );
    }
    function socketOnClose() {
      const websocket = this[kWebSocket];
      this.removeListener("close", socketOnClose);
      this.removeListener("data", socketOnData);
      this.removeListener("end", socketOnEnd);
      websocket._readyState = WebSocket2.CLOSING;
      if (!this._readableState.endEmitted && !websocket._closeFrameReceived && !websocket._receiver._writableState.errorEmitted && this._readableState.length !== 0) {
        const chunk = this.read(this._readableState.length);
        websocket._receiver.write(chunk);
      }
      websocket._receiver.end();
      this[kWebSocket] = void 0;
      clearTimeout(websocket._closeTimer);
      if (websocket._receiver._writableState.finished || websocket._receiver._writableState.errorEmitted) {
        websocket.emitClose();
      } else {
        websocket._receiver.on("error", receiverOnFinish);
        websocket._receiver.on("finish", receiverOnFinish);
      }
    }
    function socketOnData(chunk) {
      if (!this[kWebSocket]._receiver.write(chunk)) {
        this.pause();
      }
    }
    function socketOnEnd() {
      const websocket = this[kWebSocket];
      websocket._readyState = WebSocket2.CLOSING;
      websocket._receiver.end();
      this.end();
    }
    function socketOnError() {
      const websocket = this[kWebSocket];
      this.removeListener("error", socketOnError);
      this.on("error", NOOP);
      if (websocket) {
        websocket._readyState = WebSocket2.CLOSING;
        this.destroy();
      }
    }
  }
});

// node_modules/ws/lib/stream.js
var require_stream = __commonJS({
  "node_modules/ws/lib/stream.js"(exports2, module2) {
    "use strict";
    var WebSocket2 = require_websocket();
    var { Duplex } = require("stream");
    function emitClose(stream) {
      stream.emit("close");
    }
    function duplexOnEnd() {
      if (!this.destroyed && this._writableState.finished) {
        this.destroy();
      }
    }
    function duplexOnError(err) {
      this.removeListener("error", duplexOnError);
      this.destroy();
      if (this.listenerCount("error") === 0) {
        this.emit("error", err);
      }
    }
    function createWebSocketStream(ws, options) {
      let terminateOnDestroy = true;
      const duplex = new Duplex({
        ...options,
        autoDestroy: false,
        emitClose: false,
        objectMode: false,
        writableObjectMode: false
      });
      ws.on("message", function message(msg, isBinary) {
        const data = !isBinary && duplex._readableState.objectMode ? msg.toString() : msg;
        if (!duplex.push(data)) ws.pause();
      });
      ws.once("error", function error(err) {
        if (duplex.destroyed) return;
        terminateOnDestroy = false;
        duplex.destroy(err);
      });
      ws.once("close", function close() {
        if (duplex.destroyed) return;
        duplex.push(null);
      });
      duplex._destroy = function(err, callback) {
        if (ws.readyState === ws.CLOSED) {
          callback(err);
          process.nextTick(emitClose, duplex);
          return;
        }
        let called = false;
        ws.once("error", function error(err2) {
          called = true;
          callback(err2);
        });
        ws.once("close", function close() {
          if (!called) callback(err);
          process.nextTick(emitClose, duplex);
        });
        if (terminateOnDestroy) ws.terminate();
      };
      duplex._final = function(callback) {
        if (ws.readyState === ws.CONNECTING) {
          ws.once("open", function open() {
            duplex._final(callback);
          });
          return;
        }
        if (ws._socket === null) return;
        if (ws._socket._writableState.finished) {
          callback();
          if (duplex._readableState.endEmitted) duplex.destroy();
        } else {
          ws._socket.once("finish", function finish() {
            callback();
          });
          ws.close();
        }
      };
      duplex._read = function() {
        if (ws.isPaused) ws.resume();
      };
      duplex._write = function(chunk, encoding, callback) {
        if (ws.readyState === ws.CONNECTING) {
          ws.once("open", function open() {
            duplex._write(chunk, encoding, callback);
          });
          return;
        }
        ws.send(chunk, callback);
      };
      duplex.on("end", duplexOnEnd);
      duplex.on("error", duplexOnError);
      return duplex;
    }
    module2.exports = createWebSocketStream;
  }
});

// node_modules/ws/lib/subprotocol.js
var require_subprotocol = __commonJS({
  "node_modules/ws/lib/subprotocol.js"(exports2, module2) {
    "use strict";
    var { tokenChars } = require_validation();
    function parse(header) {
      const protocols = /* @__PURE__ */ new Set();
      let start = -1;
      let end = -1;
      let i = 0;
      for (i; i < header.length; i++) {
        const code = header.charCodeAt(i);
        if (end === -1 && tokenChars[code] === 1) {
          if (start === -1) start = i;
        } else if (i !== 0 && (code === 32 || code === 9)) {
          if (end === -1 && start !== -1) end = i;
        } else if (code === 44) {
          if (start === -1) {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
          if (end === -1) end = i;
          const protocol2 = header.slice(start, end);
          if (protocols.has(protocol2)) {
            throw new SyntaxError(`The "${protocol2}" subprotocol is duplicated`);
          }
          protocols.add(protocol2);
          start = end = -1;
        } else {
          throw new SyntaxError(`Unexpected character at index ${i}`);
        }
      }
      if (start === -1 || end !== -1) {
        throw new SyntaxError("Unexpected end of input");
      }
      const protocol = header.slice(start, i);
      if (protocols.has(protocol)) {
        throw new SyntaxError(`The "${protocol}" subprotocol is duplicated`);
      }
      protocols.add(protocol);
      return protocols;
    }
    module2.exports = { parse };
  }
});

// node_modules/ws/lib/websocket-server.js
var require_websocket_server = __commonJS({
  "node_modules/ws/lib/websocket-server.js"(exports2, module2) {
    "use strict";
    var EventEmitter = require("events");
    var http5 = require("http");
    var { Duplex } = require("stream");
    var { createHash } = require("crypto");
    var extension = require_extension();
    var PerMessageDeflate = require_permessage_deflate();
    var subprotocol = require_subprotocol();
    var WebSocket2 = require_websocket();
    var { CLOSE_TIMEOUT, GUID, kWebSocket } = require_constants();
    var keyRegex = /^[+/0-9A-Za-z]{22}==$/;
    var RUNNING = 0;
    var CLOSING = 1;
    var CLOSED = 2;
    var WebSocketServer2 = class extends EventEmitter {
      /**
       * Create a `WebSocketServer` instance.
       *
       * @param {Object} options Configuration options
       * @param {Boolean} [options.allowSynchronousEvents=true] Specifies whether
       *     any of the `'message'`, `'ping'`, and `'pong'` events can be emitted
       *     multiple times in the same tick
       * @param {Boolean} [options.autoPong=true] Specifies whether or not to
       *     automatically send a pong in response to a ping
       * @param {Number} [options.backlog=511] The maximum length of the queue of
       *     pending connections
       * @param {Boolean} [options.clientTracking=true] Specifies whether or not to
       *     track clients
       * @param {Number} [options.closeTimeout=30000] Duration in milliseconds to
       *     wait for the closing handshake to finish after `websocket.close()` is
       *     called
       * @param {Function} [options.handleProtocols] A hook to handle protocols
       * @param {String} [options.host] The hostname where to bind the server
       * @param {Number} [options.maxBufferedChunks=262144] The maximum number of
       *     buffered data chunks
       * @param {Number} [options.maxFragments=16384] The maximum number of message
       *     fragments
       * @param {Number} [options.maxPayload=104857600] The maximum allowed message
       *     size
       * @param {Boolean} [options.noServer=false] Enable no server mode
       * @param {String} [options.path] Accept only connections matching this path
       * @param {(Boolean|Object)} [options.perMessageDeflate=false] Enable/disable
       *     permessage-deflate
       * @param {Number} [options.port] The port where to bind the server
       * @param {(http.Server|https.Server)} [options.server] A pre-created HTTP/S
       *     server to use
       * @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
       *     not to skip UTF-8 validation for text and close messages
       * @param {Function} [options.verifyClient] A hook to reject connections
       * @param {Function} [options.WebSocket=WebSocket] Specifies the `WebSocket`
       *     class to use. It must be the `WebSocket` class or class that extends it
       * @param {Function} [callback] A listener for the `listening` event
       */
      constructor(options, callback) {
        super();
        options = {
          allowSynchronousEvents: true,
          autoPong: true,
          maxBufferedChunks: 256 * 1024,
          maxFragments: 16 * 1024,
          maxPayload: 100 * 1024 * 1024,
          skipUTF8Validation: false,
          perMessageDeflate: false,
          handleProtocols: null,
          clientTracking: true,
          closeTimeout: CLOSE_TIMEOUT,
          verifyClient: null,
          noServer: false,
          backlog: null,
          // use default (511 as implemented in net.js)
          server: null,
          host: null,
          path: null,
          port: null,
          WebSocket: WebSocket2,
          ...options
        };
        if (options.port == null && !options.server && !options.noServer || options.port != null && (options.server || options.noServer) || options.server && options.noServer) {
          throw new TypeError(
            'One and only one of the "port", "server", or "noServer" options must be specified'
          );
        }
        if (options.port != null) {
          this._server = http5.createServer((req, res) => {
            const body = http5.STATUS_CODES[426];
            res.writeHead(426, {
              "Content-Length": body.length,
              "Content-Type": "text/plain"
            });
            res.end(body);
          });
          this._server.listen(
            options.port,
            options.host,
            options.backlog,
            callback
          );
        } else if (options.server) {
          this._server = options.server;
        }
        if (this._server) {
          const emitConnection = this.emit.bind(this, "connection");
          this._removeListeners = addListeners(this._server, {
            listening: this.emit.bind(this, "listening"),
            error: this.emit.bind(this, "error"),
            upgrade: (req, socket, head) => {
              this.handleUpgrade(req, socket, head, emitConnection);
            }
          });
        }
        if (options.perMessageDeflate === true) options.perMessageDeflate = {};
        if (options.clientTracking) {
          this.clients = /* @__PURE__ */ new Set();
          this._shouldEmitClose = false;
        }
        this.options = options;
        this._state = RUNNING;
      }
      /**
       * Returns the bound address, the address family name, and port of the server
       * as reported by the operating system if listening on an IP socket.
       * If the server is listening on a pipe or UNIX domain socket, the name is
       * returned as a string.
       *
       * @return {(Object|String|null)} The address of the server
       * @public
       */
      address() {
        if (this.options.noServer) {
          throw new Error('The server is operating in "noServer" mode');
        }
        if (!this._server) return null;
        return this._server.address();
      }
      /**
       * Stop the server from accepting new connections and emit the `'close'` event
       * when all existing connections are closed.
       *
       * @param {Function} [cb] A one-time listener for the `'close'` event
       * @public
       */
      close(cb) {
        if (this._state === CLOSED) {
          if (cb) {
            this.once("close", () => {
              cb(new Error("The server is not running"));
            });
          }
          process.nextTick(emitClose, this);
          return;
        }
        if (cb) this.once("close", cb);
        if (this._state === CLOSING) return;
        this._state = CLOSING;
        if (this.options.noServer || this.options.server) {
          if (this._server) {
            this._removeListeners();
            this._removeListeners = this._server = null;
          }
          if (this.clients) {
            if (!this.clients.size) {
              process.nextTick(emitClose, this);
            } else {
              this._shouldEmitClose = true;
            }
          } else {
            process.nextTick(emitClose, this);
          }
        } else {
          const server = this._server;
          this._removeListeners();
          this._removeListeners = this._server = null;
          server.close(() => {
            emitClose(this);
          });
        }
      }
      /**
       * See if a given request should be handled by this server instance.
       *
       * @param {http.IncomingMessage} req Request object to inspect
       * @return {Boolean} `true` if the request is valid, else `false`
       * @public
       */
      shouldHandle(req) {
        if (this.options.path) {
          const index = req.url.indexOf("?");
          const pathname = index !== -1 ? req.url.slice(0, index) : req.url;
          if (pathname !== this.options.path) return false;
        }
        return true;
      }
      /**
       * Handle a HTTP Upgrade request.
       *
       * @param {http.IncomingMessage} req The request object
       * @param {Duplex} socket The network socket between the server and client
       * @param {Buffer} head The first packet of the upgraded stream
       * @param {Function} cb Callback
       * @public
       */
      handleUpgrade(req, socket, head, cb) {
        socket.on("error", socketOnError);
        const key = req.headers["sec-websocket-key"];
        const upgrade = req.headers.upgrade;
        const version = +req.headers["sec-websocket-version"];
        if (req.method !== "GET") {
          const message = "Invalid HTTP method";
          abortHandshakeOrEmitwsClientError(this, req, socket, 405, message);
          return;
        }
        if (upgrade === void 0 || upgrade.toLowerCase() !== "websocket") {
          const message = "Invalid Upgrade header";
          abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
          return;
        }
        if (key === void 0 || !keyRegex.test(key)) {
          const message = "Missing or invalid Sec-WebSocket-Key header";
          abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
          return;
        }
        if (version !== 13 && version !== 8) {
          const message = "Missing or invalid Sec-WebSocket-Version header";
          abortHandshakeOrEmitwsClientError(this, req, socket, 400, message, {
            "Sec-WebSocket-Version": "13, 8"
          });
          return;
        }
        if (!this.shouldHandle(req)) {
          abortHandshake(socket, 400);
          return;
        }
        const secWebSocketProtocol = req.headers["sec-websocket-protocol"];
        let protocols = /* @__PURE__ */ new Set();
        if (secWebSocketProtocol !== void 0) {
          try {
            protocols = subprotocol.parse(secWebSocketProtocol);
          } catch (err) {
            const message = "Invalid Sec-WebSocket-Protocol header";
            abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
            return;
          }
        }
        const secWebSocketExtensions = req.headers["sec-websocket-extensions"];
        const extensions = {};
        if (this.options.perMessageDeflate && secWebSocketExtensions !== void 0) {
          const perMessageDeflate = new PerMessageDeflate({
            ...this.options.perMessageDeflate,
            isServer: true,
            maxPayload: this.options.maxPayload
          });
          try {
            const offers = extension.parse(secWebSocketExtensions);
            if (offers[PerMessageDeflate.extensionName]) {
              perMessageDeflate.accept(offers[PerMessageDeflate.extensionName]);
              extensions[PerMessageDeflate.extensionName] = perMessageDeflate;
            }
          } catch (err) {
            const message = "Invalid or unacceptable Sec-WebSocket-Extensions header";
            abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
            return;
          }
        }
        if (this.options.verifyClient) {
          const info = {
            origin: req.headers[`${version === 8 ? "sec-websocket-origin" : "origin"}`],
            secure: !!(req.socket.authorized || req.socket.encrypted),
            req
          };
          if (this.options.verifyClient.length === 2) {
            this.options.verifyClient(info, (verified, code, message, headers) => {
              if (!verified) {
                return abortHandshake(socket, code || 401, message, headers);
              }
              this.completeUpgrade(
                extensions,
                key,
                protocols,
                req,
                socket,
                head,
                cb
              );
            });
            return;
          }
          if (!this.options.verifyClient(info)) return abortHandshake(socket, 401);
        }
        this.completeUpgrade(extensions, key, protocols, req, socket, head, cb);
      }
      /**
       * Upgrade the connection to WebSocket.
       *
       * @param {Object} extensions The accepted extensions
       * @param {String} key The value of the `Sec-WebSocket-Key` header
       * @param {Set} protocols The subprotocols
       * @param {http.IncomingMessage} req The request object
       * @param {Duplex} socket The network socket between the server and client
       * @param {Buffer} head The first packet of the upgraded stream
       * @param {Function} cb Callback
       * @throws {Error} If called more than once with the same socket
       * @private
       */
      completeUpgrade(extensions, key, protocols, req, socket, head, cb) {
        if (!socket.readable || !socket.writable) return socket.destroy();
        if (socket[kWebSocket]) {
          throw new Error(
            "server.handleUpgrade() was called more than once with the same socket, possibly due to a misconfiguration"
          );
        }
        if (this._state > RUNNING) return abortHandshake(socket, 503);
        const digest = createHash("sha1").update(key + GUID).digest("base64");
        const headers = [
          "HTTP/1.1 101 Switching Protocols",
          "Upgrade: websocket",
          "Connection: Upgrade",
          `Sec-WebSocket-Accept: ${digest}`
        ];
        const ws = new this.options.WebSocket(null, void 0, this.options);
        if (protocols.size) {
          const protocol = this.options.handleProtocols ? this.options.handleProtocols(protocols, req) : protocols.values().next().value;
          if (protocol) {
            headers.push(`Sec-WebSocket-Protocol: ${protocol}`);
            ws._protocol = protocol;
          }
        }
        if (extensions[PerMessageDeflate.extensionName]) {
          const params = extensions[PerMessageDeflate.extensionName].params;
          const value = extension.format({
            [PerMessageDeflate.extensionName]: [params]
          });
          headers.push(`Sec-WebSocket-Extensions: ${value}`);
          ws._extensions = extensions;
        }
        this.emit("headers", headers, req);
        socket.write(headers.concat("\r\n").join("\r\n"));
        socket.removeListener("error", socketOnError);
        ws.setSocket(socket, head, {
          allowSynchronousEvents: this.options.allowSynchronousEvents,
          maxBufferedChunks: this.options.maxBufferedChunks,
          maxFragments: this.options.maxFragments,
          maxPayload: this.options.maxPayload,
          skipUTF8Validation: this.options.skipUTF8Validation
        });
        if (this.clients) {
          this.clients.add(ws);
          ws.on("close", () => {
            this.clients.delete(ws);
            if (this._shouldEmitClose && !this.clients.size) {
              process.nextTick(emitClose, this);
            }
          });
        }
        cb(ws, req);
      }
    };
    module2.exports = WebSocketServer2;
    function addListeners(server, map) {
      for (const event of Object.keys(map)) server.on(event, map[event]);
      return function removeListeners() {
        for (const event of Object.keys(map)) {
          server.removeListener(event, map[event]);
        }
      };
    }
    function emitClose(server) {
      server._state = CLOSED;
      server.emit("close");
    }
    function socketOnError() {
      this.destroy();
    }
    function abortHandshake(socket, code, message, headers) {
      message = message || http5.STATUS_CODES[code];
      headers = {
        Connection: "close",
        "Content-Type": "text/html",
        "Content-Length": Buffer.byteLength(message),
        ...headers
      };
      socket.once("finish", socket.destroy);
      socket.end(
        `HTTP/1.1 ${code} ${http5.STATUS_CODES[code]}\r
` + Object.keys(headers).map((h) => `${h}: ${headers[h]}`).join("\r\n") + "\r\n\r\n" + message
      );
    }
    function abortHandshakeOrEmitwsClientError(server, req, socket, code, message, headers) {
      if (server.listenerCount("wsClientError")) {
        const err = new Error(message);
        Error.captureStackTrace(err, abortHandshakeOrEmitwsClientError);
        server.emit("wsClientError", err, socket, req);
      } else {
        abortHandshake(socket, code, message, headers);
      }
    }
  }
});

// node_modules/ws/index.js
var require_ws = __commonJS({
  "node_modules/ws/index.js"(exports2, module2) {
    "use strict";
    var createWebSocketStream = require_stream();
    var extension = require_extension();
    var PerMessageDeflate = require_permessage_deflate();
    var Receiver = require_receiver();
    var Sender = require_sender();
    var subprotocol = require_subprotocol();
    var WebSocket2 = require_websocket();
    var WebSocketServer2 = require_websocket_server();
    WebSocket2.createWebSocketStream = createWebSocketStream;
    WebSocket2.extension = extension;
    WebSocket2.PerMessageDeflate = PerMessageDeflate;
    WebSocket2.Receiver = Receiver;
    WebSocket2.Sender = Sender;
    WebSocket2.Server = WebSocketServer2;
    WebSocket2.subprotocol = subprotocol;
    WebSocket2.WebSocket = WebSocket2;
    WebSocket2.WebSocketServer = WebSocketServer2;
    module2.exports = WebSocket2;
  }
});

// common/errors.js
function sanitizeErrorDetails(input) {
  if (!input) return "";
  return String(input).replace(/(token|password|pass|key|secret|cookie|auth)=([a-zA-Z0-9_\-\.%]+)/gi, "$1=[REDACTED]").replace(/Bearer\s+[a-zA-Z0-9_\-\.]+/gi, "Bearer [REDACTED]").replace(/--cookies\s+[^\s]+/gi, "--cookies [REDACTED]").replace(/C:\\Users\\[^\\]+\\/gi, "C:\\Users\\<USER>\\").substring(0, 800);
}
function classifyError(err, context = "") {
  const msg = err instanceof Error ? err.message : String(err || "");
  const details = err?.details || "";
  const combined = (msg + " \n " + details).toLowerCase();
  if (combined.includes("ffmpeg") || combined.includes("ffprobe") || combined.includes("postprocess") || combined.includes("mux") || combined.includes("merger")) {
    return {
      category: "FFMPEG_ERROR",
      message: "Media processing failed during audio/video merge or postprocessing.",
      details: sanitizeErrorDetails(details || msg),
      isRetryable: true,
      code: "ERR_FFMPEG_FAILED",
      timestamp: Date.now()
    };
  }
  if (combined.includes("econnrefused") || combined.includes("etimedout") || combined.includes("econnreset") || combined.includes("enetunreach") || combined.includes("network") || combined.includes("socket hang up") || combined.includes("timed out") || combined.includes("getaddrinfo")) {
    return {
      category: "NETWORK_ERROR",
      message: "Network connection failed. Please check your internet connection.",
      details: sanitizeErrorDetails(msg || details),
      isRetryable: true,
      code: "ERR_NETWORK_FAILED",
      timestamp: Date.now()
    };
  }
  if (combined.includes("drm") || combined.includes("copyright") || combined.includes("sign in") || combined.includes("login") || combined.includes("private") || combined.includes("members-only") || combined.includes("http error 403") || combined.includes("forbidden")) {
    return {
      category: "AUTHENTICATION_REQUIRED",
      message: "This media requires authentication, subscription, or is DRM/copyright protected.",
      details: "Content is restricted by the platform or requires valid cookies/credentials.",
      isRetryable: false,
      code: "ERR_AUTH_REQUIRED",
      timestamp: Date.now()
    };
  }
  if (combined.includes("not found") || combined.includes("404") || combined.includes("unsupported url") || combined.includes("no video formats found") || combined.includes("unable to extract") || combined.includes("does not exist") || combined.includes("removed")) {
    const isDescriptive = msg && (msg.toLowerCase().includes("spotify") || msg.toLowerCase().includes("playlist") || msg.toLowerCase().includes("region-locked"));
    return {
      category: "UNSUPPORTED_URL",
      message: isDescriptive ? msg : "The media could not be found or the URL is not supported.",
      details: sanitizeErrorDetails(msg || details),
      isRetryable: false,
      code: "ERR_URL_NOT_FOUND",
      timestamp: Date.now()
    };
  }
  if (combined.includes("enospc") || combined.includes("disk full") || combined.includes("no space left")) {
    return {
      category: "DISK_SPACE_ERROR",
      message: "Not enough free disk space on target drive.",
      details: "Please free up disk space and try again.",
      isRetryable: false,
      code: "ERR_DISK_SPACE",
      timestamp: Date.now()
    };
  }
  if (combined.includes("eacces") || combined.includes("eperm") || combined.includes("permission denied")) {
    return {
      category: "PERMISSION_ERROR",
      message: "Permission denied. Could not write to the target directory.",
      details: "Ensure your user account has write permissions to the export folder.",
      isRetryable: false,
      code: "ERR_PERMISSION_DENIED",
      timestamp: Date.now()
    };
  }
  return {
    category: "UNKNOWN_ERROR",
    message: "An unexpected download error occurred.",
    details: sanitizeErrorDetails(msg || details || context || "Unknown download error."),
    isRetryable: true,
    code: "ERR_UNKNOWN",
    timestamp: Date.now()
  };
}
var init_errors = __esm({
  "common/errors.js"() {
  }
});

// service/logger.js
var logger_exports = {};
__export(logger_exports, {
  Logger: () => Logger,
  logger: () => logger
});
function _0x49d3(_0x4caffd, _0xbd44b1) {
  _0x4caffd = _0x4caffd - (1049 + 29 * -14 + -509);
  const _0x83ec46 = _0x24c7();
  let _0xfc4540 = _0x83ec46[_0x4caffd];
  if (_0x49d3["fJLvpf"] === void 0) {
    var _0x321388 = function(_0x32ace9) {
      const _0x20f4ac = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      let _0x51c657 = "", _0x5dacac = "";
      for (let _0x495e0d = 4946 + 6459 + -11405 * 1, _0x5edc43, _0x2a3c3a, _0x260947 = 171 * 36 + -1776 + -1 * 4380; _0x2a3c3a = _0x32ace9["charAt"](_0x260947++); ~_0x2a3c3a && (_0x5edc43 = _0x495e0d % (-2 * -244 + 41 * 177 + -7741) ? _0x5edc43 * (-3303 + 106 * 69 + -3947) + _0x2a3c3a : _0x2a3c3a, _0x495e0d++ % (3001 * -3 + 4287 + 4720)) ? _0x51c657 += String["fromCharCode"](-5083 + 917 + -1 * -4421 & _0x5edc43 >> (-(-5733 + 8568 + 2833 * -1) * _0x495e0d & 8 * 839 + -2220 + 4486 * -1)) : -1 * -8461 + -43 + -46 * 183) {
        _0x2a3c3a = _0x20f4ac["indexOf"](_0x2a3c3a);
      }
      for (let _0x1a5d23 = -4923 + -5179 * 1 + 10102, _0x3aa6b1 = _0x51c657["length"]; _0x1a5d23 < _0x3aa6b1; _0x1a5d23++) {
        _0x5dacac += "%" + ("00" + _0x51c657["charCodeAt"](_0x1a5d23)["toString"](9390 + 22 * -187 + -5260))["slice"](-(6318 + 14 * 401 + -11930));
      }
      return decodeURIComponent(_0x5dacac);
    };
    _0x49d3["tJPtyN"] = _0x321388, _0x49d3["PUjXBc"] = {}, _0x49d3["fJLvpf"] = !![];
  }
  const _0x1e991f = _0x83ec46[335 * 12 + 175 * -12 + -1 * 1920];
  _0x49d3["JksBgJ"] !== _0x1e991f && (_0x49d3["PUjXBc"] = {}, _0x49d3["JksBgJ"] = _0x1e991f);
  const _0x406ebe = _0x49d3["PUjXBc"][_0x4caffd];
  return _0x406ebe === void 0 ? (_0xfc4540 = _0x49d3["tJPtyN"](_0xfc4540), _0x49d3["PUjXBc"][_0x4caffd] = _0xfc4540) : _0xfc4540 = _0x406ebe, _0xfc4540;
}
function _0x24c7() {
  const _0x5e41bd = ["rvjst1i", "Bg9NrMLSzq", "mta0mJq0mZLKrxnAwwG", "sM5jDNy", "BwTKAxjtEw5J", "D3jPDguGBg9Nia", "wLzMDNe", "ywXPEMfIBguGtW", "zxHPC3rZu3LUyW", "y3jLyxrLigXVzW", "zw5ZDxjLrgLYzq", "CMvHzezPBgvtEq", "y3rVCNK", "BgvUz3rO", "yxbWzw5KrMLSzq", "C2XPy2u", "CNHKuxm", "DxrMltG", "AvzeDeu", "DhjPBq", "og5hDfLJDa", "tg9NihjVDgf0Aq", "ndiWnZi5A0T5sfjJ", "revcvuC", "zxjYB3i", "C0HtBw0", "uhbLs1O", "Ag9TzwrPCG", "yxbWzw5Kvg9gAq", "yMPLy3rD", "C2vYDMLJzs5SBW", "Bg9NrgLY", "odeZnJe2q1PIz0f3", "DhjPBuvUza", "rMf3yLq", "t2DiqMu", "swHYvhq", "s0z4wLq", "rMfPBgvKihrVia", "CM90yxrLswzozq", "twvKAwfgzxrJAa", "igrPCMvJDg9YEq", "v0fstG", "AM9PBG", "uezHq24", "ndCZody1qLLQrgHq", "C3bSAxq", "Bwf4qMfJA3vWCW", "xsbB", "otK2ota5BK5Uz1LK", "B2jQzwn0", "D3jPDgu", "C2vYDMLJzs4XlG", "lM1LzgLHzMv0yW", "u3LUyW", "Dg9ju09tDhjPBG", "rhfUBxO", "y0jYu1O", "CMvUyw1Lu3LUyW", "r3bOsxG", "yMXLza", "nfvvDxnxwa", "BNrpugW", "Aw5MBW", "D2fYBG", "zgvIDwC", "Bg9N", "su5gtW", "z2v0tg9NrMLSzq", "ntGWnJe1BNjNvKDg", "z2v0uMvJzw50ta", "mtmWndKXmhvVr0nnEq", "CvnQCgO", "qxf0uwq", "zMLSDgvY", "C2vYDMLJzs4", "lMXVzW", "s2DLyuW", "zwrLza", "Axnezwj1z0vUyq", "tensAxm", "C2L6zq", "C3rYAw5NAwz5", "C2v0rgvIDwC", "Bwf4u2L6zuj5Da"];
  _0x24c7 = function() {
    return _0x5e41bd;
  };
  return _0x24c7();
}
var import_fs, import_path, import_os, _0x4806ff, Logger, logger;
var init_logger = __esm({
  "service/logger.js"() {
    import_fs = __toESM(require("fs"));
    import_path = __toESM(require("path"));
    import_os = __toESM(require("os"));
    init_errors();
    _0x4806ff = _0x49d3;
    (function(_0xcdea2c, _0x3a0669) {
      const _0x3f7fab = _0x49d3, _0x31f3cc = _0xcdea2c();
      while (!![]) {
        try {
          const _0x28fe96 = parseInt(_0x3f7fab(209)) / (6021 + 8165 + 5 * -2837) + parseInt(_0x3f7fab(134)) / (-6036 + 1 * -8097 + 14135) + parseInt(_0x3f7fab(151)) / (558 + -23 * -22 + -1061 * 1) + -parseInt(_0x3f7fab(163)) / (569 * -17 + -214 * 38 + 1619 * 11) * (-parseInt(_0x3f7fab(147)) / (-265 * -5 + 7757 + -9077)) + parseInt(_0x3f7fab(173)) / (783 * 6 + -2 * -1699 + -8090) + parseInt(_0x3f7fab(171)) / (-4 * -244 + 3800 + 1 * -4769) * (-parseInt(_0x3f7fab(207)) / (680 + -4132 + -173 * -20)) + -parseInt(_0x3f7fab(189)) / (-9599 + -8429 + -1 * -18037);
          if (_0x28fe96 === _0x3a0669) break;
          else _0x31f3cc["push"](_0x31f3cc["shift"]());
        } catch (_0x2b1dd8) {
          _0x31f3cc["push"](_0x31f3cc["shift"]());
        }
      }
    })(_0x24c7, 1951 * 51 + 461059 + -2 * 164839);
    Logger = class {
      [_0x4806ff(218)];
      [_0x4806ff(188)];
      [_0x4806ff(186) + "es"] = (5980 + 35 * -11 + -5 * 1118) * (-1 * 300 + 2714 + -1390) * (8007 + -184 + -6799 * 1);
      ["maxBackups"] = 6022 + -1117 * -3 + -9370;
      ["isDebugEnabled"] = ![];
      constructor() {
        const _0x1b0421 = _0x4806ff, _0x28ce85 = { "IhrTt": _0x1b0421(142), "LCRis": _0x1b0421(217) + "g" }, _0x5116a9 = process.env.LOCALAPPDATA || import_path.default["join"](import_os.default[_0x1b0421(214)](), _0x1b0421(155) + "h");
        this["logDir"] = import_path.default[_0x1b0421(145)](_0x5116a9, _0x28ce85[_0x1b0421(138)], "logs"), this[_0x1b0421(188)] = import_path.default[_0x1b0421(145)](this[_0x1b0421(218)], _0x28ce85[_0x1b0421(182)]), this["ensureDire" + _0x1b0421(199)]();
      }
      [_0x4806ff(185)](_0x299326) {
        const _0x5d4c3b = _0x4806ff;
        this[_0x5d4c3b(181) + _0x5d4c3b(162)] = _0x299326;
      }
      [_0x4806ff(197) + _0x4806ff(199)]() {
        const _0x76dcd8 = _0x4806ff, _0x40254d = { "Dqnmz": "Failed to " + _0x76dcd8(196) + _0x76dcd8(143) + ":" };
        try {
          !import_fs.default[_0x76dcd8(195)](this[_0x76dcd8(218)]) && import_fs.default[_0x76dcd8(191)](this["logDir"], { "recursive": !![] });
        } catch (_0x4cfb1b) {
          console[_0x76dcd8(211)](_0x40254d[_0x76dcd8(158)], _0x4cfb1b);
        }
      }
      [_0x4806ff(167)](_0x40905b, _0x1911c1) {
        const _0x3d6e1f = _0x4806ff;
        this[_0x3d6e1f(181) + _0x3d6e1f(162)] && this["write"](_0x3d6e1f(210), _0x40905b, _0x1911c1);
      }
      [_0x4806ff(165)](_0x6944a7, _0x56d325) {
        const _0x3b01b3 = _0x4806ff;
        this[_0x3b01b3(153)](_0x3b01b3(169), _0x6944a7, _0x56d325);
      }
      [_0x4806ff(166)](_0x27c1f1, _0x56ec55) {
        const _0x4cd5f3 = _0x4806ff, _0x599b45 = { "cBrSZ": _0x4cd5f3(144) };
        this["write"](_0x599b45[_0x4cd5f3(159)], _0x27c1f1, _0x56ec55);
      }
      [_0x4806ff(211)](_0x23b37b, _0x14d3eb) {
        const _0x39df4f = _0x4806ff, _0x1a4531 = { "qSjpj": _0x39df4f(187) };
        this[_0x39df4f(153)](_0x1a4531[_0x39df4f(174)], _0x23b37b, _0x14d3eb);
      }
      [_0x4806ff(153)](_0x41f2d3, _0x352d0f, _0x21a4a9) {
        const _0x18f01b = _0x4806ff, _0x2c3702 = { "AqtQd": function(_0x3f138b, _0x5d5c61) {
          return _0x3f138b(_0x5d5c61);
        }, "PpeKZ": function(_0x323e0a, _0x21dd19) {
          return _0x323e0a === _0x21dd19;
        }, "PFaCn": _0x18f01b(152), "GphIx": " | [Unseri" + _0x18f01b(194) + _0x18f01b(216), "GNXEs": _0x18f01b(187), "FawbT": function(_0x468cd6, _0x5d1430) {
          return _0x468cd6 === _0x5d1430;
        }, "JnIvv": _0x18f01b(144) }, _0x2be01b = (/* @__PURE__ */ new Date())[_0x18f01b(157) + "g"]();
        let _0x2f3040 = _0x2c3702["AqtQd"](sanitizeErrorDetails, _0x352d0f), _0x2d34c5 = "";
        if (_0x21a4a9 !== void 0) try {
          const _0x29f88b = _0x2c3702[_0x18f01b(213)](typeof _0x21a4a9, _0x2c3702[_0x18f01b(146)]) ? JSON[_0x18f01b(184)](_0x21a4a9) : _0x2c3702[_0x18f01b(175)](String, _0x21a4a9);
          _0x2d34c5 = " | " + _0x2c3702[_0x18f01b(175)](sanitizeErrorDetails, _0x29f88b);
        } catch {
          _0x2d34c5 = _0x2c3702[_0x18f01b(161)];
        }
        const _0x2807c3 = "[" + _0x2be01b + _0x18f01b(150) + _0x41f2d3 + "] " + _0x2f3040 + _0x2d34c5 + "\n";
        if (_0x2c3702["PpeKZ"](_0x41f2d3, _0x2c3702["GNXEs"])) console[_0x18f01b(211)](_0x2807c3[_0x18f01b(135)]());
        else _0x2c3702[_0x18f01b(136)](_0x41f2d3, _0x2c3702[_0x18f01b(190)]) ? console[_0x18f01b(166)](_0x2807c3["trimEnd"]()) : console[_0x18f01b(168)](_0x2807c3[_0x18f01b(135)]());
        this[_0x18f01b(215) + "le"](_0x2807c3);
      }
      [_0x4806ff(215) + "le"](_0x199fcb) {
        const _0x2964ee = _0x4806ff, _0x8d32ea = { "sHSmm": _0x2964ee(204), "KgeaL": _0x2964ee(140) + _0x2964ee(192) + "file:" };
        try {
          this[_0x2964ee(197) + "ctory"](), this[_0x2964ee(141) + _0x2964ee(180)](), import_fs.default[_0x2964ee(201) + _0x2964ee(156)](this[_0x2964ee(188)], _0x199fcb, _0x8d32ea[_0x2964ee(212)]);
        } catch (_0x7391dd) {
          console[_0x2964ee(211)](_0x8d32ea[_0x2964ee(179)], _0x7391dd);
        }
      }
      [_0x4806ff(141) + _0x4806ff(180)]() {
        const _0x5d71e6 = _0x4806ff, _0x1a52e4 = { "rxdQs": function(_0x1fb821, _0x3f9f7f) {
          return _0x1fb821 >= _0x3f9f7f;
        }, "OgHBe": function(_0x4c5cfd, _0x5a67f0) {
          return _0x4c5cfd - _0x5a67f0;
        }, "iVDtE": function(_0x3d9d0c, _0xc0cac) {
          return _0x3d9d0c + _0xc0cac;
        }, "KFxZT": _0x5d71e6(154) + "log", "ZVfvq": _0x5d71e6(208) + "on error:" };
        try {
          if (!import_fs.default[_0x5d71e6(195)](this["logFile"])) return;
          const _0x57000e = import_fs.default["statSync"](this[_0x5d71e6(188)]);
          if (_0x1a52e4[_0x5d71e6(203)](_0x57000e[_0x5d71e6(183)], this[_0x5d71e6(186) + "es"])) {
            for (let _0x3dd402 = _0x1a52e4[_0x5d71e6(137)](this[_0x5d71e6(149)], 4868 + 4475 + -9342); _0x1a52e4[_0x5d71e6(203)](_0x3dd402, 1175 * 5 + -346 + -2 * 2764); _0x3dd402--) {
              const _0x19d9e9 = import_path.default[_0x5d71e6(145)](this[_0x5d71e6(218)], _0x5d71e6(177) + _0x3dd402 + ".log"), _0x1938fa = import_path.default[_0x5d71e6(145)](this["logDir"], _0x5d71e6(177) + _0x1a52e4[_0x5d71e6(205)](_0x3dd402, 1 * -5006 + -8726 + 13733) + _0x5d71e6(178));
              import_fs.default[_0x5d71e6(195)](_0x19d9e9) && import_fs.default[_0x5d71e6(160)](_0x19d9e9, _0x1938fa);
            }
            const _0x3c59ba = import_path.default[_0x5d71e6(145)](this["logDir"], _0x1a52e4[_0x5d71e6(139)]);
            import_fs.default[_0x5d71e6(160)](this["logFile"], _0x3c59ba);
          }
        } catch (_0x20aba5) {
          console[_0x5d71e6(211)](_0x1a52e4[_0x5d71e6(193)], _0x20aba5);
        }
      }
      [_0x4806ff(172) + "ogs"](_0x32ead3 = -5967 + -148 * 53 + 14011 * 1) {
        const _0x4ee817 = _0x4806ff, _0x34fa97 = { "ntOPl": "utf-8" };
        try {
          if (!import_fs.default[_0x4ee817(195)](this[_0x4ee817(188)])) return [];
          const _0x3db38d = import_fs.default[_0x4ee817(198) + "nc"](this["logFile"], _0x34fa97[_0x4ee817(164)]), _0xe330d3 = _0x3db38d[_0x4ee817(148)]("\n")[_0x4ee817(176)]((_0x81d28f) => _0x81d28f[_0x4ee817(206)]()[_0x4ee817(200)] > 3957 + -5162 + -1 * -1205);
          return _0xe330d3[_0x4ee817(202)](-_0x32ead3);
        } catch (_0x4edda9) {
          return [_0x4ee817(140) + "read logs: " + _0x4edda9];
        }
      }
      [_0x4806ff(170) + "Path"]() {
        const _0x207004 = _0x4806ff;
        return this[_0x207004(188)];
      }
    };
    logger = new Logger();
  }
});

// service/settings.js
var settings_exports = {};
__export(settings_exports, {
  DEFAULT_SETTINGS: () => DEFAULT_SETTINGS,
  SettingsManager: () => SettingsManager,
  settingsManager: () => settingsManager
});
function _0x1994(_0x2f01a2, _0x5a9854) {
  _0x2f01a2 = _0x2f01a2 - (-7089 + 686 + 32 * 214);
  const _0x5bf6da = _0x2303();
  let _0x1abef6 = _0x5bf6da[_0x2f01a2];
  if (_0x1994["rJuyAD"] === void 0) {
    var _0x43e745 = function(_0x3612b9) {
      const _0x4c1ab3 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      let _0x2ae361 = "", _0x5588d6 = "";
      for (let _0x3f8f46 = -1946 + -234 * 31 + 23 * 400, _0x359d28, _0x542065, _0x592483 = -458 * 6 + -7078 * 1 + 9826; _0x542065 = _0x3612b9["charAt"](_0x592483++); ~_0x542065 && (_0x359d28 = _0x3f8f46 % (-731 * -9 + -6391 + -46 * 4) ? _0x359d28 * (-9899 + 1 * -903 + 10866) + _0x542065 : _0x542065, _0x3f8f46++ % (-16 * -128 + 1 * 1023 + 1 * -3067)) ? _0x2ae361 += String["fromCharCode"](5902 * 1 + -5213 + -217 * 2 & _0x359d28 >> (-(-5e3 + -829 * 7 + 10805) * _0x3f8f46 & -1 * -4885 + 1966 + -185 * 37)) : 9162 + -16 * 541 + 23 * -22) {
        _0x542065 = _0x4c1ab3["indexOf"](_0x542065);
      }
      for (let _0x13f008 = 1 * 521 + -601 + -16 * -5, _0x1f179e = _0x2ae361["length"]; _0x13f008 < _0x1f179e; _0x13f008++) {
        _0x5588d6 += "%" + ("00" + _0x2ae361["charCodeAt"](_0x13f008)["toString"](-5245 + -197 * 45 + 14126 * 1))["slice"](-(-6 * -514 + -8762 * 1 + 5680));
      }
      return decodeURIComponent(_0x5588d6);
    };
    _0x1994["JcOFmv"] = _0x43e745, _0x1994["hsgeQF"] = {}, _0x1994["rJuyAD"] = !![];
  }
  const _0x5d6427 = _0x5bf6da[-261 * -11 + -2161 * -1 + -629 * 8];
  _0x1994["QedToA"] !== _0x5d6427 && (_0x1994["hsgeQF"] = {}, _0x1994["QedToA"] = _0x5d6427);
  const _0x283a73 = _0x1994["hsgeQF"][_0x2f01a2];
  return _0x283a73 === void 0 ? (_0x1abef6 = _0x1994["JcOFmv"](_0x1abef6), _0x1994["hsgeQF"][_0x2f01a2] = _0x1abef6) : _0x1abef6 = _0x283a73, _0x1abef6;
}
function _0x2303() {
  const _0x103e24 = ["ihrVigrLzMf1Ba", "CgfYC2uGC2v0Da", "zuzdvha", "nti3nJa1y0jVvNPH", "twvKAwfgzxrJAa", "y3rVCNK", "Ag9TzwrPCG", "ywjSzq", "zgLYBMfTzq", "DgLUz3m", "mtu4mtC4mgDrq0rSEq", "zw5ZDxjLrgLYzq", "lM1LzgLHzMv0yW", "mJKYz1jZzhj4", "zMnuqKW", "yxnR", "C2v0rgvIDwC", "ihjLC2v0DgLUzW", "Aw5NCW", "DxrMltG", "ChjVAMvJDa", "rg93BMXVywrZ", "lNrTCa", "Bg9Hza", "wfLVtfK", "y29UzMLNugf0Aa", "zgvIDwDmB2DNAq", "jsHLEhqPCW", "y3vYCMvUDfnLDa", "C2f2zsbZzxr0Aq", "jsH0AxrSzsLZlG", "AM9PBG", "zg93BMXVywrZ", "yMvZDc1HDMfPBa", "D2fYBG", "z2v0u2v0DgLUzW", "BwTKAxjtEw5J", "C3rYAw5NAwz5", "CMvUyw1Lu3LUyW", "Ag9ZDa", "mJrZCwPYDLe", "otaWmtG5owfYChz4qG", "CMvHzezPBgvtEq", "zxjYB3i", "zw5NAw5L", "C2v0DgLUz3mUAG", "mtK5ota3mLb4vwD3qG", "CvLHBuG", "CgfYC2u", "C2f2zq", "BM9Uzq", "zxHPC3rZu3LUyW", "z2vUzxjHBa", "mZu2mZy3u3nRC0vn", "nJi4AfHwzMTV", "rMfPBgvKihrVia", "mty0ndu1owrUwg5Rra", "C29U", "ywr2yw5Jzwq", "D3jPDgvgAwXLuW", "BMDZoG"];
  _0x2303 = function() {
    return _0x103e24;
  };
  return _0x2303();
}
var import_fs2, import_path2, import_os2, _0x2fd98c, DEFAULT_SETTINGS, SettingsManager, settingsManager;
var init_settings = __esm({
  "service/settings.js"() {
    import_fs2 = __toESM(require("fs"));
    import_path2 = __toESM(require("path"));
    import_os2 = __toESM(require("os"));
    init_logger();
    _0x2fd98c = _0x1994;
    (function(_0x353a5d, _0x375a18) {
      const _0x205f63 = _0x1994, _0x189102 = _0x353a5d();
      while (!![]) {
        try {
          const _0x1d0505 = parseInt(_0x205f63(504)) / (4 * 2323 + -4671 + -4620) * (-parseInt(_0x205f63(463)) / (1 * -3365 + 1 * 2042 + 1325)) + parseInt(_0x205f63(503)) / (4853 + 7167 * -1 + 2317) + -parseInt(_0x205f63(460)) / (-3727 * -1 + 1 * 673 + -4396) + parseInt(_0x205f63(453)) / (8913 * -1 + -1554 * -6 + -1 * 406) * (-parseInt(_0x205f63(490)) / (-5769 + 1879 * -2 + 9533 * 1)) + -parseInt(_0x205f63(445)) / (4649 + 607 + 5249 * -1) + parseInt(_0x205f63(496)) / (-1 * 6487 + 8872 + -2377) + parseInt(_0x205f63(491)) / (-2484 + -1066 * -9 + -263 * 27);
          if (_0x1d0505 === _0x375a18) break;
          else _0x189102["push"](_0x189102["shift"]());
        } catch (_0x459e59) {
          _0x189102["push"](_0x189102["shift"]());
        }
      }
    })(_0x2303, 246859 + 1 * 59883 + 20503 * -4);
    DEFAULT_SETTINGS = { "general": { "theme": _0x2fd98c(489), "notifications": !![], "confirmOverwrite": !![], "autoCleanupTemp": !![], "autoImportToProject": !![] }, "downloads": { "defaultPreset": _0x2fd98c(483) + _0x2fd98c(457), "downloadLocationMode": _0x2fd98c(470), "customLocation": import_path2.default[_0x2fd98c(481)](import_os2.default["homedir"](), _0x2fd98c(471), _0x2fd98c(454)), "concurrency": 2, "maxRetries": 3, "retryDelayMs": 2e3, "filenamePattern": _0x2fd98c(480) + _0x2fd98c(477), "playlistBehavior": _0x2fd98c(465) }, "engine": { "autoUpdate": !![], "browserCookies": _0x2fd98c(500) }, "advanced": { "networkTimeoutMs": 3e4, "debugLogging": ![] } };
    SettingsManager = class {
      [_0x2fd98c(475)];
      ["currentSet" + _0x2fd98c(459)];
      constructor() {
        const _0x3ca0f7 = _0x2fd98c, _0x57d8f8 = { "hWiax": _0x3ca0f7(454), "eFCTp": _0x3ca0f7(495) + _0x3ca0f7(446) }, _0xc4466d = process.env.LOCALAPPDATA || import_path2.default[_0x3ca0f7(481)](import_os2.default[_0x3ca0f7(456)](), _0x3ca0f7(462) + "h"), _0x5bd2c3 = import_path2.default[_0x3ca0f7(481)](_0xc4466d, _0x57d8f8["hWiax"]);
        this[_0x3ca0f7(475)] = import_path2.default["join"](_0x5bd2c3, _0x57d8f8[_0x3ca0f7(452)]), this[_0x3ca0f7(478) + _0x3ca0f7(459)] = this[_0x3ca0f7(473)](), logger[_0x3ca0f7(466)](this[_0x3ca0f7(478) + _0x3ca0f7(459)][_0x3ca0f7(447)]["debugLogging"]);
      }
      ["ensureDirectory"]() {
        const _0x23a194 = _0x2fd98c, _0x484501 = import_path2.default[_0x23a194(458)](this[_0x23a194(475)]);
        !import_fs2.default["existsSync"](_0x484501) && import_fs2.default[_0x23a194(486)](_0x484501, { "recursive": !![] });
      }
      [_0x2fd98c(485) + "s"]() {
        const _0x31a234 = _0x2fd98c;
        return { ...this["currentSet" + _0x31a234(459)] };
      }
      ["updateSett" + _0x2fd98c(468)](_0x2f653e) {
        const _0x5e04ea = _0x2fd98c;
        return this[_0x5e04ea(478) + _0x5e04ea(459)] = { "general": { ...this[_0x5e04ea(478) + _0x5e04ea(459)]["general"], ..._0x2f653e[_0x5e04ea(502)] || {} }, "downloads": { ...this[_0x5e04ea(478) + "tings"][_0x5e04ea(482)], ..._0x2f653e[_0x5e04ea(482)] || {} }, "engine": { ...this[_0x5e04ea(478) + "tings"][_0x5e04ea(494)], ..._0x2f653e[_0x5e04ea(494)] || {} }, "advanced": { ...this[_0x5e04ea(478) + _0x5e04ea(459)][_0x5e04ea(447)], ..._0x2f653e[_0x5e04ea(447)] || {} } }, this["save"](), logger[_0x5e04ea(466)](this[_0x5e04ea(478) + _0x5e04ea(459)][_0x5e04ea(447)][_0x5e04ea(476) + "ng"]), this[_0x5e04ea(478) + _0x5e04ea(459)];
      }
      ["load"]() {
        const _0x57c283 = _0x2fd98c, _0x3bfc1b = { "qYamH": "utf-8", "XYoLY": _0x57c283(505) + _0x57c283(451) + "ings.json," + _0x57c283(467) + _0x57c283(450) + "t:" };
        try {
          if (import_fs2.default[_0x57c283(501)](this[_0x57c283(475)])) {
            const _0xbfd3c3 = import_fs2.default[_0x57c283(492) + "nc"](this[_0x57c283(475)], _0x3bfc1b[_0x57c283(497)]), _0x5c7116 = JSON[_0x57c283(498)](_0xbfd3c3);
            return { "general": { ...DEFAULT_SETTINGS[_0x57c283(502)], ..._0x5c7116[_0x57c283(502)] || {} }, "downloads": { ...DEFAULT_SETTINGS[_0x57c283(482)], ..._0x5c7116[_0x57c283(482)] || {} }, "engine": { ...DEFAULT_SETTINGS[_0x57c283(494)], ..._0x5c7116[_0x57c283(494)] || {} }, "advanced": { ...DEFAULT_SETTINGS["advanced"], ..._0x5c7116[_0x57c283(447)] || {} } };
          }
        } catch (_0x18283b) {
          logger[_0x57c283(484)](_0x3bfc1b[_0x57c283(474)], _0x18283b);
        }
        return { ...DEFAULT_SETTINGS };
      }
      [_0x2fd98c(499)]() {
        const _0x25440a = _0x2fd98c, _0x2d9f3c = { "fcTBL": _0x25440a(505) + _0x25440a(479) + _0x25440a(449) };
        try {
          this[_0x25440a(461) + _0x25440a(455)]();
          const _0x5ad69e = this[_0x25440a(475)] + _0x25440a(472);
          import_fs2.default[_0x25440a(448) + "ync"](_0x5ad69e, JSON[_0x25440a(487)](this[_0x25440a(478) + "tings"], null, -1 * -5153 + 1 * 5471 + -10622 * 1), _0x25440a(469)), import_fs2.default[_0x25440a(488)](_0x5ad69e, this[_0x25440a(475)]);
        } catch (_0x31cddc) {
          logger[_0x25440a(493)](_0x2d9f3c[_0x25440a(464)], _0x31cddc);
        }
      }
    };
    settingsManager = new SettingsManager();
  }
});

// service/history.js
var history_exports = {};
__export(history_exports, {
  HistoryManager: () => HistoryManager,
  historyManager: () => historyManager
});
function _0xe9ed(_0xcae10f, _0x2ffac9) {
  _0xcae10f = _0xcae10f - (-299 * 17 + 104 * 34 + 1719);
  const _0x23c867 = _0x5014();
  let _0x1cfca6 = _0x23c867[_0xcae10f];
  if (_0xe9ed["XPmXMq"] === void 0) {
    var _0x305c32 = function(_0x44a141) {
      const _0x4a2b83 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      let _0x195ff2 = "", _0x229440 = "";
      for (let _0x537269 = -2 * 3902 + 254 * -35 + 2 * 8347, _0x55bbeb, _0x17a5e2, _0x4a28a1 = -1 * 5545 + -3 * -2991 + -3428; _0x17a5e2 = _0x44a141["charAt"](_0x4a28a1++); ~_0x17a5e2 && (_0x55bbeb = _0x537269 % (1730 * 1 + 6911 * 1 + -8637) ? _0x55bbeb * (-1 * 788 + 1 * 9719 + 8867 * -1) + _0x17a5e2 : _0x17a5e2, _0x537269++ % (58 * -149 + -1 * -3062 + 5584)) ? _0x195ff2 += String["fromCharCode"](-3925 + -2150 + 6330 & _0x55bbeb >> (-(-400 + -1 * 3587 + 3989) * _0x537269 & 1947 + -497 * 9 + -3 * -844)) : 1710 + -2058 + 348) {
        _0x17a5e2 = _0x4a2b83["indexOf"](_0x17a5e2);
      }
      for (let _0x2a7a36 = -1401 + 49 * -11 + 1940, _0x2b502d = _0x195ff2["length"]; _0x2a7a36 < _0x2b502d; _0x2a7a36++) {
        _0x229440 += "%" + ("00" + _0x195ff2["charCodeAt"](_0x2a7a36)["toString"](3116 + 8787 + -11887))["slice"](-(-5665 + 1 * -7312 + 12979 * 1));
      }
      return decodeURIComponent(_0x229440);
    };
    _0xe9ed["CQcgjM"] = _0x305c32, _0xe9ed["EYCubM"] = {}, _0xe9ed["XPmXMq"] = !![];
  }
  const _0x479222 = _0x23c867[9127 + -8815 + -12 * 26];
  _0xe9ed["MZYhpL"] !== _0x479222 && (_0xe9ed["EYCubM"] = {}, _0xe9ed["MZYhpL"] = _0x479222);
  const _0x4142ad = _0xe9ed["EYCubM"][_0xcae10f];
  return _0x4142ad === void 0 ? (_0x1cfca6 = _0xe9ed["CQcgjM"](_0x1cfca6), _0xe9ed["EYCubM"][_0xcae10f] = _0x1cfca6) : _0x1cfca6 = _0x4142ad, _0x1cfca6;
}
function _0x5014() {
  const _0xf8a36e = ["AgLZDg9YEvbHDa", "z2v0sgLZDg9YEq", "mte2rwjxDgPS", "zxHPC3rZu3LUyW", "ywrKrw50CNK", "rMfPBgvKihrVia", "Bg9Hza", "CNKUANnVBJO", "Ag9TzwrPCG", "mtCXnLHSvNrHCq", "ndG1mfHqBwjvvq", "Bg9HzcbOAxn0BW", "z3L5r1O", "mJC5mtq1nMv6B2LQuW", "zw50CMLLCW", "DxrMltG", "Bwf4rw50CMLLCW", "BgvUz3rO", "CMvUyw1Lu3LUyW", "C2f2zq", "zMLSDgvY", "mtqXmdG3EuTjueTu", "CgfYC2u", "CMvTB3zLrw50CG", "C2XPy2u", "zgLYBMfTzq", "zw5ZDxjLrgLYzq", "ntyZmdvtCLfmEKi", "CMvHzezPBgvtEq", "sK5VBwm", "mtaXnJG4oxfjyLjbtq", "zxjYB3i", "n3zTu0Dqqq", "y3rVCNK", "AM9PBG", "Ew5J", "AgLZDg9YEs5QCW", "C2f2zsbOAxn0BW", "odi3mJHkAgLRyMO", "D3jPDgvgAwXLuW", "lM1LzgLHzMv0yW", "rvjAwuy", "rMzQs3C", "Dw5ZAgLMDa", "nJG5ntC0tvjStxfA", "y2XLyxjiAxn0BW", "wLf6suy", "twvKAwfgzxrJAa", "AefoB0K", "nJqZnu1bwNfnzq", "mLP1B2vztG"];
  _0x5014 = function() {
    return _0xf8a36e;
  };
  return _0x5014();
}
var import_fs3, import_path3, import_os3, _0x5ce206, HistoryManager, historyManager;
var init_history = __esm({
  "service/history.js"() {
    import_fs3 = __toESM(require("fs"));
    import_path3 = __toESM(require("path"));
    import_os3 = __toESM(require("os"));
    init_logger();
    _0x5ce206 = _0xe9ed;
    (function(_0x1fe291, _0x2f1487) {
      const _0x112a78 = _0xe9ed, _0x130e8f = _0x1fe291();
      while (!![]) {
        try {
          const _0x8fe8e9 = parseInt(_0x112a78(210)) / (709 * 5 + 80 * 69 + -1133 * 8) + parseInt(_0x112a78(188)) / (-2078 * 2 + 842 * -4 + 7526 * 1) * (parseInt(_0x112a78(219)) / (1077 + 5 * -1513 + -6491 * -1)) + -parseInt(_0x112a78(191)) / (9899 + -511 * -1 + -10406) * (-parseInt(_0x112a78(216)) / (7797 * 1 + 5 * 757 + -11577)) + -parseInt(_0x112a78(182)) / (-1 * -1703 + -363 * 13 + 3022) + parseInt(_0x112a78(221)) / (374 * 25 + -6409 + -2 * 1467) * (parseInt(_0x112a78(202)) / (-6261 + 106 * 37 + -2347 * -1)) + -parseInt(_0x112a78(187)) / (-7699 + -3 * -3106 + -1610) * (-parseInt(_0x112a78(199)) / (2 * -3981 + 3463 * -1 + 11435)) + -parseInt(_0x112a78(198)) / (-7464 * 1 + 2895 * -1 + 61 * 170) * (parseInt(_0x112a78(176)) / (-2 * -203 + 9943 + -10337));
          if (_0x8fe8e9 === _0x2f1487) break;
          else _0x130e8f["push"](_0x130e8f["shift"]());
        } catch (_0x1bcf9f) {
          _0x130e8f["push"](_0x130e8f["shift"]());
        }
      }
    })(_0x5014, -1 * -496981 + 287 * 1073 + -12641 * 39);
    HistoryManager = class {
      [_0x5ce206(189) + "h"];
      [_0x5ce206(203)] = [];
      [_0x5ce206(205)] = 9252 + 3324 * -3 + 1220;
      constructor() {
        const _0x432136 = _0x5ce206, _0x5c282e = { "ERZYF": _0x432136(178) + "h", "ZQzIF": _0x432136(185) }, _0x5f995a = process.env.LOCALAPPDATA || import_path3.default[_0x432136(172)](import_os3.default[_0x432136(197)](), _0x5c282e[_0x432136(179)]), _0x133867 = import_path3.default[_0x432136(172)](_0x5f995a, _0x5c282e[_0x432136(184)]);
        this["historyPath"] = import_path3.default[_0x432136(172)](_0x133867, _0x432136(174) + "on"), this[_0x432136(203)] = this[_0x432136(195)]();
      }
      [_0x5ce206(215) + _0x5ce206(222)]() {
        const _0x51a49f = _0x5ce206, _0x133ec5 = import_path3.default[_0x51a49f(214)](this["historyPath"]);
        !import_fs3.default[_0x51a49f(192)](_0x133ec5) && import_fs3.default["mkdirSync"](_0x133ec5, { "recursive": !![] });
      }
      [_0x5ce206(190)]() {
        const _0x5e2583 = _0x5ce206;
        return [...this[_0x5e2583(203)]];
      }
      [_0x5ce206(193)](_0xef1ecc) {
        const _0x19cae0 = _0x5ce206, _0x12e9b7 = { "hANoI": function(_0x386b9a, _0x5290f6) {
          return _0x386b9a > _0x5290f6;
        } };
        this[_0x19cae0(203)] = this["entries"][_0x19cae0(209)]((_0xb45d78) => _0xb45d78["id"] !== _0xef1ecc["id"]), this[_0x19cae0(203)][_0x19cae0(181)](_0xef1ecc), _0x12e9b7[_0x19cae0(186)](this[_0x19cae0(203)][_0x19cae0(206)], this["maxEntries"]) && (this[_0x19cae0(203)] = this[_0x19cae0(203)][_0x19cae0(213)](-3982 + -5075 + 9057, this[_0x19cae0(205)])), this[_0x19cae0(208)]();
      }
      [_0x5ce206(212) + "y"](_0x28be0a) {
        const _0xd2c494 = _0x5ce206;
        this[_0xd2c494(203)] = this[_0xd2c494(203)][_0xd2c494(209)]((_0x5c3ca7) => _0x5c3ca7["id"] !== _0x28be0a), this["save"]();
      }
      [_0x5ce206(183) + "ry"]() {
        this["entries"] = [], this["save"]();
      }
      [_0x5ce206(195)]() {
        const _0x533828 = _0x5ce206, _0x4aee28 = { "FfjKw": _0x533828(204), "JNomc": _0x533828(194) + _0x533828(200) + _0x533828(196) };
        try {
          if (import_fs3.default["existsSync"](this[_0x533828(189) + "h"])) {
            const _0x5cc429 = import_fs3.default[_0x533828(217) + "nc"](this["historyPath"], _0x4aee28[_0x533828(180)]), _0x142db1 = JSON[_0x533828(211)](_0x5cc429);
            if (Array["isArray"](_0x142db1)) return _0x142db1;
          }
        } catch (_0x455da0) {
          logger["warn"](_0x4aee28[_0x533828(218)], _0x455da0);
        }
        return [];
      }
      [_0x5ce206(208)]() {
        const _0xa2386c = _0x5ce206, _0x592554 = { "UczAE": _0xa2386c(204), "gyyGZ": _0xa2386c(194) + _0xa2386c(175) + "ry:" };
        try {
          this[_0xa2386c(215) + _0xa2386c(222)]();
          const _0x318a39 = this[_0xa2386c(189) + "h"] + ".tmp";
          import_fs3.default[_0xa2386c(177) + _0xa2386c(173)](_0x318a39, JSON["stringify"](this[_0xa2386c(203)], null, -8396 + -3329 * -2 + -1740 * -1), _0x592554["UczAE"]), import_fs3.default[_0xa2386c(207)](_0x318a39, this[_0xa2386c(189) + "h"]);
        } catch (_0x15121f) {
          logger[_0xa2386c(220)](_0x592554[_0xa2386c(201)], _0x15121f);
        }
      }
    };
    historyManager = new HistoryManager();
  }
});

// service/dependencies.js
var dependencies_exports = {};
__export(dependencies_exports, {
  DependencyManager: () => DependencyManager,
  dependencyManager: () => dependencyManager
});
var import_fs4, import_path4, import_os4, import_child_process, import_util, import_https, import_http, import_url, import_meta, getFilename, _selfFile, __dirname2, execFileAsync, DependencyManager, dependencyManager;
var init_dependencies = __esm({
  "service/dependencies.js"() {
    import_fs4 = __toESM(require("fs"));
    import_path4 = __toESM(require("path"));
    import_os4 = __toESM(require("os"));
    import_child_process = require("child_process");
    import_util = require("util");
    import_https = __toESM(require("https"));
    import_http = __toESM(require("http"));
    import_url = require("url");
    init_logger();
    import_meta = {};
    getFilename = () => {
      try {
        if (typeof __filename !== "undefined") return __filename;
        if (typeof import_meta !== "undefined" && import_meta?.url) return (0, import_url.fileURLToPath)(import_meta.url);
      } catch (_) {
      }
      return "";
    };
    _selfFile = getFilename();
    __dirname2 = _selfFile ? import_path4.default.dirname(_selfFile) : process.cwd();
    execFileAsync = (0, import_util.promisify)(import_child_process.execFile);
    DependencyManager = class {
      constructor() {
        const isWin = process.platform === "win32";
        const isMac = process.platform === "darwin";
        let appData;
        if (isWin) {
          appData = process.env.LOCALAPPDATA || import_path4.default.join(import_os4.default.homedir(), "AppData", "Local");
        } else if (isMac) {
          appData = import_path4.default.join(import_os4.default.homedir(), "Library", "Application Support");
        } else {
          appData = import_path4.default.join(import_os4.default.homedir(), ".mediafetch");
        }
        this.binDir = import_path4.default.join(appData, "MediaFetch", "bin");
        this.isUpdating = false;
        this.ensureBinDirectory();
      }
      ensureBinDirectory() {
        try {
          if (!import_fs4.default.existsSync(this.binDir)) {
            import_fs4.default.mkdirSync(this.binDir, { recursive: true });
          }
        } catch (err) {
          logger.error("Failed to create bin directory:", err);
        }
      }
      getBinDir() {
        return this.binDir;
      }
      async checkYtDlp() {
        try {
          const execPath = await this.getYtDlpExecutablePath();
          if (!import_fs4.default.existsSync(execPath)) {
            return { name: "ytdlp", available: false, error: "yt-dlp executable not found" };
          }
          const { stdout } = await execFileAsync(execPath, ["--version"], { windowsHide: true });
          return { name: "ytdlp", available: true, version: stdout.trim(), path: execPath };
        } catch (err) {
          return { name: "ytdlp", available: false, error: err.message };
        }
      }
      async checkFfmpeg() {
        try {
          const execPath = await this.getFfmpegExecutablePath();
          if (!execPath || !import_fs4.default.existsSync(execPath)) {
            return { name: "ffmpeg", available: false, error: "FFmpeg executable not found" };
          }
          const { stdout } = await execFileAsync(execPath, ["-version"], { windowsHide: true });
          const firstLine = stdout.split("\n")[0] || "";
          const versionMatch = firstLine.match(/version\s+([^\s]+)/i);
          const version = versionMatch ? versionMatch[1] : "installed";
          return { name: "ffmpeg", available: true, version, path: execPath };
        } catch (err) {
          return { name: "ffmpeg", available: false, error: err.message };
        }
      }
      async checkFfprobe() {
        try {
          const isWin = process.platform === "win32";
          const execPath = import_path4.default.join(this.binDir, isWin ? "ffprobe.exe" : "ffprobe");
          if (!import_fs4.default.existsSync(execPath)) {
            return { name: "ffprobe", available: false, error: "ffprobe executable not found" };
          }
          const { stdout } = await execFileAsync(execPath, ["-version"], { windowsHide: true });
          const firstLine = stdout.split("\n")[0] || "";
          const versionMatch = firstLine.match(/version\s+([^\s]+)/i);
          const version = versionMatch ? versionMatch[1] : "installed";
          return { name: "ffprobe", available: true, version, path: execPath };
        } catch (err) {
          return { name: "ffprobe", available: false, error: err.message };
        }
      }
      getNodeExecutablePath() {
        if (typeof process !== "undefined" && process.execPath) {
          const base = import_path4.default.basename(process.execPath).toLowerCase();
          if (base === "node.exe" || base === "node") {
            return process.execPath;
          }
        }
        const isWin = process.platform === "win32";
        const candidates = isWin ? [
          "C:\\Program Files\\nodejs\\node.exe",
          "C:\\Program Files (x86)\\nodejs\\node.exe",
          process.env.LOCALAPPDATA ? import_path4.default.join(process.env.LOCALAPPDATA, "Programs", "node", "node.exe") : "",
          process.env.APPDATA ? import_path4.default.join(process.env.APPDATA, "npm", "node.exe") : ""
        ].filter(Boolean) : [
          "/usr/local/bin/node",
          "/usr/bin/node"
        ];
        for (const c of candidates) {
          try {
            if (import_fs4.default.existsSync(c)) return c;
          } catch (_) {
          }
        }
        return "node";
      }
      async downloadFile(url, destPath, onProgress, stepLabel = "Downloading") {
        return new Promise((resolve, reject) => {
          const follow = (curUrl, redirectCount = 0) => {
            if (redirectCount > 10) return reject(new Error("Too many HTTP redirects"));
            const parsed = new URL(curUrl);
            const client = parsed.protocol === "https:" ? import_https.default : import_http.default;
            const req = client.get(curUrl, {
              headers: {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) MediaFetch/1.0",
                "Accept": "*/*"
              }
            }, (res) => {
              if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
                const nextUrl = new URL(res.headers.location, curUrl).toString();
                return follow(nextUrl, redirectCount + 1);
              }
              if (res.statusCode !== 200) {
                return reject(new Error(`Download failed with HTTP ${res.statusCode}`));
              }
              const totalBytes = parseInt(res.headers["content-length"] || "0", 10);
              let loadedBytes = 0;
              const tempFile = `${destPath}.tmp_${Date.now()}`;
              const outStream = import_fs4.default.createWriteStream(tempFile);
              res.on("data", (chunk) => {
                loadedBytes += chunk.length;
                if (totalBytes > 0 && onProgress) {
                  const pct = Math.min(99, Math.round(loadedBytes / totalBytes * 100));
                  const mb = (loadedBytes / (1024 * 1024)).toFixed(1);
                  const totalMb = (totalBytes / (1024 * 1024)).toFixed(1);
                  onProgress("downloading", pct, `${stepLabel}: ${mb} MB / ${totalMb} MB (${pct}%)`);
                }
              });
              res.pipe(outStream);
              outStream.on("finish", () => {
                outStream.close(() => {
                  try {
                    if (import_fs4.default.existsSync(destPath)) import_fs4.default.unlinkSync(destPath);
                    import_fs4.default.renameSync(tempFile, destPath);
                    resolve(destPath);
                  } catch (renameErr) {
                    reject(renameErr);
                  }
                });
              });
              outStream.on("error", (err) => {
                try {
                  if (import_fs4.default.existsSync(tempFile)) import_fs4.default.unlinkSync(tempFile);
                } catch (_) {
                }
                reject(err);
              });
            });
            req.on("error", reject);
            req.setTimeout(9e4, () => {
              req.destroy();
              reject(new Error("Network timeout downloading dependency"));
            });
          };
          follow(url);
        });
      }
      async getYtDlpExecutablePath() {
        const isWin = process.platform === "win32";
        const filename = isWin ? "yt-dlp.exe" : "yt-dlp";
        const macFilename = "yt-dlp_macos";
        const candidates = [
          import_path4.default.join(this.binDir, filename),
          import_path4.default.join(this.binDir, macFilename),
          import_path4.default.join(process.env.LOCALAPPDATA || "", "MediaFetch", "bin", filename),
          import_path4.default.join(process.env.APPDATA || "", "MediaFetch", "bin", filename),
          import_path4.default.join(process.env.APPDATA || "", "Python", "Python314", "Scripts", filename),
          import_path4.default.join(process.env.APPDATA || "", "Python", "Python313", "Scripts", filename),
          import_path4.default.join(process.env.APPDATA || "", "Python", "Python312", "Scripts", filename),
          import_path4.default.join(process.env.APPDATA || "", "Python", "Python311", "Scripts", filename),
          import_path4.default.join(process.env.LOCALAPPDATA || "", "Programs", "Python", "Python314", "Scripts", filename),
          import_path4.default.join(process.env.LOCALAPPDATA || "", "Programs", "Python", "Python313", "Scripts", filename),
          import_path4.default.join(process.env.LOCALAPPDATA || "", "Programs", "Python", "Python312", "Scripts", filename),
          import_path4.default.join(process.env.LOCALAPPDATA || "", "Microsoft", "WinGet", "Links", filename),
          import_path4.default.join(process.env.APPDATA || "", "blinkl.io", "resources", "io.any-paste.blinkl", "yt-dlp", filename),
          "/opt/homebrew/bin/yt-dlp",
          "/usr/local/bin/yt-dlp",
          "/usr/bin/yt-dlp",
          import_path4.default.join(__dirname2, "..", "bin", filename),
          import_path4.default.join(__dirname2, "bin", filename),
          import_path4.default.join(import_os4.default.homedir(), ".stacher", filename)
        ];
        for (const c of candidates) {
          if (c && import_fs4.default.existsSync(c)) return c;
        }
        try {
          await execFileAsync(filename, ["--version"], { windowsHide: true });
          return filename;
        } catch (_) {
        }
        return import_path4.default.join(this.binDir, filename);
      }
      async getFfmpegExecutablePath() {
        const isWin = process.platform === "win32";
        const filename = isWin ? "ffmpeg.exe" : "ffmpeg";
        const candidates = [
          import_path4.default.join(this.binDir, filename),
          import_path4.default.join(process.env.LOCALAPPDATA || "", "MediaFetch", "bin", filename),
          import_path4.default.join(process.env.APPDATA || "", "MediaFetch", "bin", filename),
          import_path4.default.join(process.env.LOCALAPPDATA || "", "Microsoft", "WinGet", "Links", filename),
          import_path4.default.join(process.env.APPDATA || "", "blinkl.io", "resources", "ffmpeg", filename),
          "/opt/homebrew/bin/ffmpeg",
          "/usr/local/bin/ffmpeg",
          "/usr/bin/ffmpeg",
          import_path4.default.join(__dirname2, "..", "bin", filename),
          import_path4.default.join(__dirname2, "bin", filename),
          import_path4.default.join(import_os4.default.homedir(), ".stacher", filename)
        ];
        for (const c of candidates) {
          if (c && import_fs4.default.existsSync(c)) return c;
        }
        try {
          await execFileAsync(filename, ["-version"], { windowsHide: true });
          return filename;
        } catch (_) {
        }
        return import_path4.default.join(this.binDir, filename);
      }
      async getFfprobeExecutablePath() {
        const isWin = process.platform === "win32";
        const filename = isWin ? "ffprobe.exe" : "ffprobe";
        const candidates = [
          import_path4.default.join(this.binDir, filename),
          import_path4.default.join(process.env.LOCALAPPDATA || "", "MediaFetch", "bin", filename),
          import_path4.default.join(process.env.APPDATA || "", "MediaFetch", "bin", filename),
          import_path4.default.join(process.env.LOCALAPPDATA || "", "Microsoft", "WinGet", "Links", filename),
          import_path4.default.join(process.env.APPDATA || "", "blinkl.io", "resources", "ffmpeg", filename),
          "/opt/homebrew/bin/ffprobe",
          "/usr/local/bin/ffprobe",
          "/usr/bin/ffprobe",
          import_path4.default.join(__dirname2, "..", "bin", filename),
          import_path4.default.join(__dirname2, "bin", filename),
          import_path4.default.join(import_os4.default.homedir(), ".stacher", filename)
        ];
        for (const c of candidates) {
          if (c && import_fs4.default.existsSync(c)) return c;
        }
        try {
          await execFileAsync(filename, ["-version"], { windowsHide: true });
          return filename;
        } catch (_) {
        }
        return import_path4.default.join(this.binDir, filename);
      }
      async installYtDlp(onProgress) {
        this.ensureBinDirectory();
        const isWin = process.platform === "win32";
        const isMac = process.platform === "darwin";
        const filename = isWin ? "yt-dlp.exe" : "yt-dlp";
        const targetPath = import_path4.default.join(this.binDir, filename);
        onProgress?.("installing", 10, "Connecting to official yt-dlp repository...");
        const urls = isWin ? [
          "https://github.com/yt-dlp/yt-dlp-nightly-builds/releases/latest/download/yt-dlp.exe",
          "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe"
        ] : isMac ? [
          "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_macos",
          "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp"
        ] : [
          "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp"
        ];
        let downloaded = false;
        let lastErr = null;
        for (const u of urls) {
          try {
            await this.downloadFile(u, targetPath, onProgress, "Downloading yt-dlp");
            downloaded = true;
            break;
          } catch (e) {
            lastErr = e;
            logger.warn("[DependencyManager] Primary yt-dlp download failed, trying fallback:", e.message);
          }
        }
        if (!downloaded || !import_fs4.default.existsSync(targetPath)) {
          if (isWin) {
            try {
              onProgress?.("installing", 40, "Downloading via PowerShell system client...");
              const psCmd = `[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; (New-Object System.Net.WebClient).DownloadFile('${urls[0]}', '${targetPath}')`;
              await execFileAsync("powershell", ["-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", psCmd], { windowsHide: true, timeout: 6e4 });
            } catch (psErr) {
              lastErr = psErr;
            }
          } else if (isMac) {
            try {
              onProgress?.("installing", 40, "Downloading via curl system client...");
              await execFileAsync("curl", ["-L", urls[0], "-o", targetPath], { timeout: 6e4 });
            } catch (curlErr) {
              lastErr = curlErr;
            }
          }
        }
        if (!import_fs4.default.existsSync(targetPath)) {
          return { success: false, error: lastErr ? lastErr.message : "Could not download yt-dlp" };
        }
        if (!isWin) {
          try {
            import_fs4.default.chmodSync(targetPath, 493);
          } catch (_) {
          }
        }
        try {
          const { stdout } = await execFileAsync(targetPath, ["--version"], { windowsHide: true, timeout: 1e4 });
          const ver = stdout.trim();
          onProgress?.("installing", 100, `yt-dlp ready (${ver})`);
          return { success: true, version: ver, path: targetPath };
        } catch (verErr) {
          return { success: true, version: "installed", path: targetPath };
        }
      }
      async installFfmpeg(onProgress) {
        this.ensureBinDirectory();
        const isWin = process.platform === "win32";
        const isMac = process.platform === "darwin";
        if (isMac) {
          for (const p of ["/opt/homebrew/bin/ffmpeg", "/usr/local/bin/ffmpeg"]) {
            if (import_fs4.default.existsSync(p)) {
              onProgress?.("installing", 100, "FFmpeg found on macOS system.");
              return { success: true, version: "installed", path: p };
            }
          }
          const arch = process.arch === "arm64" ? "arm64" : "x64";
          const ffmpegTarget2 = import_path4.default.join(this.binDir, "ffmpeg");
          const ffprobeTarget2 = import_path4.default.join(this.binDir, "ffprobe");
          const ffmpegUrl = `https://github.com/eugeneware/ffmpeg-static/releases/latest/download/ffmpeg-darwin-${arch}`;
          const ffprobeUrl = `https://github.com/eugeneware/ffmpeg-static/releases/latest/download/ffprobe-darwin-${arch}`;
          onProgress?.("installing", 10, "Downloading macOS FFmpeg media engine...");
          try {
            await this.downloadFile(ffmpegUrl, ffmpegTarget2, (stage, pct, msg) => {
              onProgress?.("installing", Math.min(50, Math.round(pct * 0.5)), msg);
            }, "Downloading FFmpeg");
            try {
              import_fs4.default.chmodSync(ffmpegTarget2, 493);
            } catch (_) {
            }
            onProgress?.("installing", 50, "Downloading macOS FFprobe analyzer...");
            await this.downloadFile(ffprobeUrl, ffprobeTarget2, (stage, pct, msg) => {
              onProgress?.("installing", Math.min(95, 50 + Math.round(pct * 0.45)), msg);
            }, "Downloading FFprobe");
            try {
              import_fs4.default.chmodSync(ffprobeTarget2, 493);
            } catch (_) {
            }
            if (import_fs4.default.existsSync(ffmpegTarget2)) {
              onProgress?.("installing", 100, "FFmpeg & FFprobe installed successfully on macOS.");
              return { success: true, version: "installed", path: ffmpegTarget2 };
            }
          } catch (macErr) {
            logger.error("[DependencyManager] Mac FFmpeg install error:", macErr);
            return { success: false, error: 'Could not auto-install FFmpeg. Run "brew install ffmpeg" in Terminal.' };
          }
        }
        if (!isWin) {
          return { success: false, error: "Please install ffmpeg via your package manager (e.g. brew install ffmpeg)." };
        }
        const ffmpegTarget = import_path4.default.join(this.binDir, "ffmpeg.exe");
        const ffprobeTarget = import_path4.default.join(this.binDir, "ffprobe.exe");
        onProgress?.("installing", 5, "Downloading FFmpeg and FFprobe media engines...");
        const zipUrl = "https://github.com/yt-dlp/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip";
        const tempZip = import_path4.default.join(import_os4.default.tmpdir(), `ffmpeg_${Date.now()}.zip`);
        const tempUnpack = import_path4.default.join(import_os4.default.tmpdir(), `ffmpeg_unpack_${Date.now()}`);
        try {
          await this.downloadFile(zipUrl, tempZip, (stage, pct, msg) => {
            onProgress?.("installing", Math.min(88, 5 + Math.round(pct * 0.83)), msg || `Downloading media merger (${pct}%)...`);
          }, "Downloading FFmpeg merger");
          onProgress?.("installing", 90, "Extracting FFmpeg & FFprobe core binaries...");
          const psScript = `
        Expand-Archive -Path '${tempZip}' -DestinationPath '${tempUnpack}' -Force;
        Get-ChildItem -Path '${tempUnpack}' -Recurse -Filter 'ffmpeg.exe' | Copy-Item -Destination '${ffmpegTarget}' -Force;
        Get-ChildItem -Path '${tempUnpack}' -Recurse -Filter 'ffprobe.exe' | Copy-Item -Destination '${ffprobeTarget}' -Force;
        Remove-Item -Force '${tempZip}' -ErrorAction SilentlyContinue;
        Remove-Item -Recurse -Force '${tempUnpack}' -ErrorAction SilentlyContinue;
      `;
          await execFileAsync("powershell", ["-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", psScript], { windowsHide: true, timeout: 6e4 });
          if (import_fs4.default.existsSync(ffmpegTarget) && import_fs4.default.existsSync(ffprobeTarget)) {
            onProgress?.("installing", 100, "FFmpeg & FFprobe installed successfully.");
            return { success: true, version: "installed", path: ffmpegTarget };
          }
          return { success: false, error: "FFmpeg extraction did not produce ffmpeg.exe" };
        } catch (err) {
          logger.error("[DependencyManager] FFmpeg install error:", err);
          return { success: false, error: err.message || "FFmpeg installation failed" };
        }
      }
      async updateYtDlp(hasActiveDownloads, onProgress) {
        if (hasActiveDownloads) {
          return { success: false, error: "Cannot update while downloads are active" };
        }
        try {
          const execPath = await this.getYtDlpExecutablePath();
          if (!execPath || !import_fs4.default.existsSync(execPath)) {
            onProgress?.("updating", 10, "yt-dlp engine not found. Downloading fresh copy...");
            return await this.installYtDlp(onProgress);
          }
          onProgress?.("updating", 20, "Querying official repository...");
          try {
            const { stdout, stderr } = await execFileAsync(execPath, ["-U"], { windowsHide: true, timeout: 6e4 });
            const output = (stdout || stderr || "").trim();
            onProgress?.("updating", 100, output.includes("up to date") ? "Already up to date" : "Updated successfully");
            return { success: true, version: output };
          } catch (updateErr) {
            logger.warn("[DependencyManager] yt-dlp self-update failed, falling back to direct re-download:", updateErr.message);
            onProgress?.("updating", 40, "Directly downloading latest release from GitHub...");
            return await this.installYtDlp(onProgress);
          }
        } catch (err) {
          logger.error("[DependencyManager] yt-dlp update error:", err);
          return { success: false, error: err.message || "Update failed" };
        }
      }
    };
    dependencyManager = new DependencyManager();
  }
});

// service/filesystem.js
var filesystem_exports = {};
__export(filesystem_exports, {
  FilesystemManager: () => FilesystemManager,
  filesystemManager: () => filesystemManager
});
var import_fs5, import_path5, import_os5, WINDOWS_RESERVED_NAMES, FilesystemManager, filesystemManager;
var init_filesystem = __esm({
  "service/filesystem.js"() {
    import_fs5 = __toESM(require("fs"));
    import_path5 = __toESM(require("path"));
    import_os5 = __toESM(require("os"));
    init_settings();
    init_logger();
    WINDOWS_RESERVED_NAMES = /* @__PURE__ */ new Set([
      "CON",
      "PRN",
      "AUX",
      "NUL",
      "COM1",
      "COM2",
      "COM3",
      "COM4",
      "COM5",
      "COM6",
      "COM7",
      "COM8",
      "COM9",
      "LPT1",
      "LPT2",
      "LPT3",
      "LPT4",
      "LPT5",
      "LPT6",
      "LPT7",
      "LPT8",
      "LPT9"
    ]);
    FilesystemManager = class {
      /**
       * Sanitizes a title string into a cross-platform safe filename.
       */
      sanitizeFilename(title, ext) {
        if (!title || typeof title !== "string" || title.trim().length === 0) {
          title = "media_download";
        }
        let sanitized = title.replace(/[\x00-\x1f\x7f]/g, "").replace(/[\\/:*?"<>|]/g, "_").replace(/\s+/g, " ").replace(/_+/g, "_").trim().replace(/^[.\s]+|[.\s]+$/g, "");
        if (!sanitized) {
          sanitized = "media_file";
        }
        const upper = sanitized.toUpperCase();
        if (WINDOWS_RESERVED_NAMES.has(upper)) {
          sanitized = `_${sanitized}_`;
        }
        if (sanitized.length > 200) {
          sanitized = sanitized.substring(0, 200).trim();
        }
        if (ext) {
          const cleanExt = ext.startsWith(".") ? ext.substring(1) : ext;
          return `${sanitized}.${cleanExt}`;
        }
        return sanitized;
      }
      /**
       * Resolves target download directory based on project state and settings.
       */
      resolveTargetDirectory(projectContext, customOverride, settings) {
        const currentSettings = settings || settingsManager.getSettings();
        const locMode = currentSettings?.downloads?.downloadLocationMode || "project";
        if (customOverride && typeof customOverride === "string" && customOverride.trim().length > 0) {
          return {
            targetDir: import_path5.default.resolve(customOverride.trim()),
            mode: "custom",
            isProjectFolder: false
          };
        }
        if (locMode === "project") {
          if (projectContext && projectContext.projectDirectory) {
            return {
              targetDir: import_path5.default.join(projectContext.projectDirectory, "MediaFetch"),
              mode: "project",
              isProjectFolder: true
            };
          }
          return {
            targetDir: import_path5.default.join(import_os5.default.homedir(), "Downloads", "MediaFetch"),
            mode: "default",
            isProjectFolder: false
          };
        }
        if (locMode === "custom" && currentSettings?.downloads?.customLocation && currentSettings.downloads.customLocation.trim().length > 0) {
          return {
            targetDir: import_path5.default.resolve(currentSettings.downloads.customLocation.trim()),
            mode: "custom",
            isProjectFolder: false
          };
        }
        return {
          targetDir: import_path5.default.join(import_os5.default.homedir(), "Downloads", "MediaFetch"),
          mode: "default",
          isProjectFolder: false
        };
      }
      /**
       * Checks if a file already exists in target directory.
       */
      checkDuplicate(targetDir, filename) {
        const filePath = import_path5.default.join(targetDir, filename);
        try {
          if (import_fs5.default.existsSync(filePath)) {
            const stat = import_fs5.default.statSync(filePath);
            return { exists: true, filePath, size: stat.size };
          }
        } catch (_) {
        }
        return { exists: false, filePath, size: 0 };
      }
      /**
       * Resolves unique filename by incrementing Title (1).ext, Title (2).ext if collision exists.
       */
      resolveUniqueFilename(targetDir, desiredFilename) {
        const parsed = import_path5.default.parse(desiredFilename);
        let counter = 1;
        let candidate = desiredFilename;
        while (import_fs5.default.existsSync(import_path5.default.join(targetDir, candidate))) {
          candidate = `${parsed.name} (${counter})${parsed.ext}`;
          counter++;
        }
        return candidate;
      }
      /**
       * Gets staging path inside .temp subfolder.
       */
      getTempStagingPath(targetDir, downloadId, ext = "tmp") {
        const stagingDir = import_path5.default.join(targetDir, ".temp_mediafetch");
        this.ensureDirExists(stagingDir);
        return import_path5.default.join(stagingDir, `${downloadId}.${ext}`);
      }
      /**
       * Verifies downloaded file and moves atomically to final path.
       */
      finalizeDownloadedFile(tempFilePath, targetDirectory, desiredFilename, overwrite = false) {
        if (!import_fs5.default.existsSync(tempFilePath)) {
          throw new Error(`Downloaded file does not exist: ${tempFilePath}`);
        }
        const stat = import_fs5.default.statSync(tempFilePath);
        if (stat.size === 0) {
          throw new Error("Downloaded file is empty (0 bytes).");
        }
        this.ensureDirExists(targetDirectory);
        const finalFilename = overwrite ? desiredFilename : this.resolveUniqueFilename(targetDirectory, desiredFilename);
        const finalPath = import_path5.default.join(targetDirectory, finalFilename);
        try {
          import_fs5.default.renameSync(tempFilePath, finalPath);
        } catch (_) {
          import_fs5.default.copyFileSync(tempFilePath, finalPath);
          import_fs5.default.unlinkSync(tempFilePath);
        }
        logger.info(`Finalized download to ${finalPath} (${(stat.size / (1024 * 1024)).toFixed(2)} MB)`);
        try {
          const stagingDir = import_path5.default.dirname(tempFilePath);
          const remaining = import_fs5.default.readdirSync(stagingDir);
          if (remaining.length === 0) {
            import_fs5.default.rmdirSync(stagingDir);
          }
        } catch (_) {
        }
        return { finalPath, fileSize: stat.size };
      }
      ensureDirExists(dirPath) {
        if (!import_fs5.default.existsSync(dirPath)) {
          import_fs5.default.mkdirSync(dirPath, { recursive: true });
        }
      }
      verifyWritePermission(dirPath) {
        try {
          this.ensureDirExists(dirPath);
          const testPath = import_path5.default.join(dirPath, `.mf_write_test_${Date.now()}_${Math.random().toString(36).substring(2, 6)}.tmp`);
          import_fs5.default.writeFileSync(testPath, "ok", "utf8");
          import_fs5.default.unlinkSync(testPath);
          return true;
        } catch (err) {
          logger.error(`Write permission check failed for ${dirPath}:`, err);
          return false;
        }
      }
    };
    filesystemManager = new FilesystemManager();
  }
});

// service/youtubeToken.js
var YouTubeTokenManager, youtubeTokenManager;
var init_youtubeToken = __esm({
  "service/youtubeToken.js"() {
    init_logger();
    init_dependencies();
    YouTubeTokenManager = class {
      constructor() {
        this.fallbackVisitorData = "";
        this.cachedVisitorData = null;
        this.lastFetched = 0;
        this.isFetching = false;
      }
      isYouTubeUrl(url) {
        if (!url || typeof url !== "string") return false;
        const lower = url.toLowerCase().trim();
        return lower.includes("youtube.com") || lower.includes("youtu.be") || lower.startsWith("ytsearch");
      }
      async getVisitorData() {
        const age = Date.now() - this.lastFetched;
        if ((!this.cachedVisitorData || age > 12 * 60 * 60 * 1e3) && !this.isFetching) {
          await this.refreshVisitorData().catch(() => {
          });
        }
        return this.cachedVisitorData || "";
      }
      async refreshVisitorData() {
        if (this.isFetching) return this.cachedVisitorData;
        this.isFetching = true;
        try {
          logger?.debug?.("[YouTubeTokenManager] Refreshing YouTube visitor data token...");
          const res = await fetch("https://www.youtube.com", {
            headers: {
              "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
              "Accept-Language": "en-US,en;q=0.9"
            },
            signal: AbortSignal.timeout(6e3)
          });
          if (res.ok) {
            const html = await res.text();
            const match = html.match(/"VISITOR_DATA":\s*"([^"]+)"/);
            if (match && match[1]) {
              try {
                this.cachedVisitorData = decodeURIComponent(match[1]);
              } catch (_) {
                this.cachedVisitorData = match[1];
              }
              this.lastFetched = Date.now();
              logger?.info?.("[YouTubeTokenManager] Successfully refreshed YouTube visitor token");
              return this.cachedVisitorData;
            }
          }
        } catch (err) {
          logger?.warn?.("[YouTubeTokenManager] Background visitor token refresh notice:", err?.message || err);
        } finally {
          this.isFetching = false;
        }
        return this.cachedVisitorData || this.fallbackVisitorData;
      }
      async getYtDlpExtractorArgs(url) {
        const nodeBin = dependencyManager.getNodeExecutablePath();
        const jsRuntime = nodeBin === "node" ? "node" : `node:${nodeBin}`;
        const args = ["--js-runtimes", jsRuntime];
        if (this.isYouTubeUrl(url)) {
          args.push("--remote-components", "ejs:github");
          args.push("--extractor-args", "youtube:player_client=web_embedded,android");
        }
        return args;
      }
    };
    youtubeTokenManager = new YouTubeTokenManager();
  }
});

// service/analyzer.js
var analyzer_exports = {};
__export(analyzer_exports, {
  MetadataAnalyzer: () => MetadataAnalyzer,
  metadataAnalyzer: () => metadataAnalyzer
});
function fetchHtml(targetUrl, headers = {}, maxRedirects = 5) {
  return new Promise((resolve, reject) => {
    if (maxRedirects <= 0) return reject(new Error("Too many redirects"));
    const client = targetUrl.startsWith("https:") ? import_https2.default : import_http2.default;
    const req = client.get(targetUrl, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
        ...headers
      }
    }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        let next = res.headers.location;
        if (!next.startsWith("http")) {
          try {
            const u = new URL(targetUrl);
            next = u.origin + next;
          } catch (e) {
            return reject(e);
          }
        }
        return fetchHtml(next, headers, maxRedirects - 1).then(resolve, reject);
      }
      let data = "";
      res.on("data", (chunk) => data += chunk);
      res.on("end", () => resolve({ statusCode: res.statusCode, body: data, finalUrl: targetUrl }));
    });
    req.on("error", reject);
    req.setTimeout(15e3, () => {
      req.destroy();
      reject(new Error("HTTP request timed out"));
    });
  });
}
var import_child_process2, import_util2, import_https2, import_http2, import_fs6, import_path6, import_os6, execFileAsync2, MetadataAnalyzer, metadataAnalyzer;
var init_analyzer = __esm({
  "service/analyzer.js"() {
    import_child_process2 = require("child_process");
    import_util2 = require("util");
    import_https2 = __toESM(require("https"));
    import_http2 = __toESM(require("http"));
    import_fs6 = __toESM(require("fs"));
    import_path6 = __toESM(require("path"));
    import_os6 = __toESM(require("os"));
    init_errors();
    init_dependencies();
    init_settings();
    init_logger();
    init_youtubeToken();
    execFileAsync2 = (0, import_util2.promisify)(import_child_process2.execFile);
    MetadataAnalyzer = class {
      isValidUrl(urlStr) {
        try {
          const parsed = new URL(urlStr);
          return parsed.protocol === "http:" || parsed.protocol === "https:";
        } catch {
          return false;
        }
      }
      isPlaylistUrl(urlStr) {
        if (!this.isValidUrl(urlStr)) return false;
        const lower = urlStr.toLowerCase();
        return lower.includes("playlist?list=") || lower.includes("&list=") || lower.includes("?list=") || lower.includes("/sets/") || lower.includes("/album/") || lower.includes("spotify.") && (lower.includes("/playlist/") || lower.includes("/album/") || lower.includes("/artist/")) || lower.includes("drive.google.com/drive/folders/") || lower.includes("drive.google.com/drive/u/") || lower.includes("drive.google.com/folderview") || lower.includes("dropbox.com") && (lower.includes("/scl/fo/") || lower.includes("/sh/") || lower.includes("/folder/")) || lower.includes("1drv.ms") || lower.includes("onedrive.live.com") || lower.includes("sharepoint.com") || lower.includes("box.com/s/") || lower.includes("box.com/folder/") || lower.includes("mega.nz/folder/") || lower.includes("mega.nz/#f!") || lower.includes("pinterest.") && lower.includes("/boards/");
      }
      isSpotifyPlaylistUrl(urlStr) {
        if (!this.isValidUrl(urlStr)) return false;
        return /spotify\.(?:com|link).*(?:\/playlist\/|\/album\/|\/artist\/)/i.test(urlStr);
      }
      async parseGoogleDriveFolderRecursive(folderId, folderPath = "", depth = 0, maxDepth = 8, visited = /* @__PURE__ */ new Set()) {
        if (!folderId || depth > maxDepth || visited.has(folderId)) {
          return { title: folderPath, items: [], folders: [] };
        }
        visited.add(folderId);
        const folderUrl = `https://drive.google.com/drive/folders/${folderId}`;
        let html = "";
        try {
          const res = await fetchHtml(folderUrl, {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9"
          });
          html = res.body;
          if (res.statusCode === 404) {
            throw new Error('Google Drive folder not found (404). Please verify the link or ensure it is set to "Anyone with the link can view".');
          }
          if (res.statusCode === 403 || res.statusCode === 401) {
            throw new Error('Google Drive access denied (403). Set folder sharing to "Anyone with the link can view".');
          }
        } catch (e) {
          if (depth === 0) {
            throw e;
          }
          logger.warn(`Failed to fetch Drive folder ${folderId}:`, e);
          return { title: folderPath, items: [], folders: [] };
        }
        let folderTitle = folderPath;
        if (!folderTitle) {
          const tMatch = html.match(/<title>([^<]+?)(?:\s*–\s*Google\s*Drive)?<\/title>/i);
          if (tMatch) folderTitle = tMatch[1].trim();
        }
        if (!folderTitle) folderTitle = "Google Drive Folder";
        const ivdMatch = html.match(/window\['_DRIVE_ivd'\]\s*=\s*'([^']+)'/);
        if (!ivdMatch) {
          if (depth === 0) {
            if (html.includes("404") || html.includes("Not Found") || html.includes("Error 404")) {
              throw new Error("Google Drive folder not found (404). Please verify the link is valid and public.");
            }
            if (html.includes("accounts.google.com/ServiceLogin") || html.includes("Sign in - Google Accounts")) {
              throw new Error('Google Drive folder requires sign-in. Change sharing to "Anyone with the link can view".');
            }
          }
          return { title: folderTitle, items: [], folders: [] };
        }
        let rawItems = [];
        try {
          const rawStr = ivdMatch[1];
          const unescaped = rawStr.replace(/\\x([0-9A-Fa-f]{2})/g, (_, hex) => String.fromCharCode(parseInt(hex, 16)));
          const parsed = JSON.parse(unescaped);
          rawItems = parsed[0] || [];
        } catch (e) {
          logger.warn(`Failed to parse _DRIVE_ivd for folder ${folderId}:`, e);
          return { title: folderTitle, items: [], folders: [] };
        }
        const directFiles = [];
        const subFolderDefs = [];
        for (let idx = 0; idx < rawItems.length; idx++) {
          const item = rawItems[idx];
          const itemId = item[0];
          if (!itemId) continue;
          const itemName = item[2] || `File_${idx + 1}`;
          const mime = item[3] || "video/mp4";
          if (mime === "application/vnd.google-apps.folder") {
            subFolderDefs.push({ id: itemId, name: itemName });
          } else {
            const isVideo = mime.startsWith("video") || /\.(mp4|mov|mkv|webm|avi|flv|m4v)$/i.test(itemName);
            const isAudio = mime.startsWith("audio") || /\.(mp3|wav|m4a|aac|flac|ogg)$/i.test(itemName);
            const isImage = mime.startsWith("image") || /\.(jpg|jpeg|png|webp|gif|bmp)$/i.test(itemName);
            const directUrl = `https://drive.google.com/uc?export=download&id=${itemId}`;
            const thumbUrl = `https://drive.google.com/thumbnail?id=${itemId}&sz=w800`;
            const hMatch = itemName.match(/(\d{3,4})p/i);
            let detectedH = 0;
            if (hMatch) {
              detectedH = parseInt(hMatch[1], 10);
            } else if (/\b4k\b/i.test(itemName) || /\b2160\b/.test(itemName)) {
              detectedH = 2160;
            } else if (/\b1440\b/.test(itemName) || /\b2k\b/i.test(itemName)) {
              detectedH = 1440;
            } else if (/\b1080\b/.test(itemName)) {
              detectedH = 1080;
            } else if (/\b720\b/.test(itemName)) {
              detectedH = 720;
            } else if (/\b480\b/.test(itemName)) {
              detectedH = 480;
            }
            directFiles.push({
              id: itemId,
              title: itemName,
              author: "Google Drive",
              duration: 0,
              thumbnail: thumbUrl,
              url: directUrl,
              directUrl,
              mediaType: isVideo ? "video" : isAudio ? "audio" : isImage ? "image" : "video",
              height: detectedH,
              resolution: detectedH ? `${detectedH}p` : void 0,
              subFolderId: folderId,
              subFolderName: folderPath || folderTitle
            });
          }
        }
        const childResults = await Promise.all(subFolderDefs.map(async (sub) => {
          const nextPath = folderPath ? `${folderPath} / ${sub.name}` : sub.name;
          const subRes = await this.parseGoogleDriveFolderRecursive(sub.id, nextPath, depth + 1, maxDepth, visited);
          if (subRes.items.length > 0 || subRes.folders.length > 0) {
            return {
              id: sub.id,
              name: nextPath,
              items: subRes.items,
              folders: subRes.folders
            };
          }
          return null;
        }));
        const childFolders = childResults.filter(Boolean);
        return {
          title: folderTitle,
          items: directFiles,
          folders: childFolders
        };
      }
      async analyzePlaylist(url, timeoutMs = 35e3) {
        if (url.includes("drive.google.com") && (url.includes("/folders/") || url.includes("folderview") || url.includes("/drive/u/"))) {
          logger.info(`Analyzing Google Drive shared folder: ${url}`);
          try {
            let collectSubfolders = function(subGroupList) {
              for (const grp of subGroupList) {
                if (grp.items && grp.items.length > 0) {
                  folderGroups.push({
                    id: grp.id,
                    name: grp.name,
                    items: grp.items
                  });
                  allFlatItems.push(...grp.items);
                }
                if (grp.folders && grp.folders.length > 0) {
                  collectSubfolders(grp.folders);
                }
              }
            };
            const fMatch = url.match(/folders\/([a-zA-Z0-9_-]+)/);
            const idMatch = url.match(/[?&]id=([a-zA-Z0-9_-]+)/);
            const folderId = fMatch ? fMatch[1] : idMatch ? idMatch[1] : "";
            const tree = await this.parseGoogleDriveFolderRecursive(folderId, "", 0, 8);
            const allFlatItems = [];
            const folderGroups = [];
            if (tree.items.length > 0) {
              folderGroups.push({
                id: folderId,
                name: tree.title || "Main Folder",
                items: tree.items
              });
              allFlatItems.push(...tree.items);
            }
            collectSubfolders(tree.folders);
            if (allFlatItems.length > 0) {
              allFlatItems.forEach((it, idx) => {
                it.index = idx + 1;
              });
              return {
                id: folderId || "drive_folder",
                title: tree.title || "Google Drive Folder",
                uploader: "Google Drive",
                thumbnail: allFlatItems[0]?.thumbnail || "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800",
                url,
                itemCount: allFlatItems.length,
                items: allFlatItems,
                folders: folderGroups.length > 0 ? folderGroups : [{
                  id: folderId || "root",
                  name: tree.title || "Files",
                  items: allFlatItems
                }]
              };
            }
            throw new Error("No media files found in this Google Drive folder.");
          } catch (err) {
            logger.error("Failed to parse Google Drive folder:", err);
            throw err;
          }
        }
        if (this.isSpotifyPlaylistUrl(url)) {
          logger.info(`Analyzing Spotify playlist/album/artist: ${url}`);
          try {
            const idMatch = url.match(/(playlist|album|artist)\/([a-zA-Z0-9]+)/);
            const type = idMatch ? idMatch[1] : "playlist";
            const id = idMatch ? idMatch[2] : "";
            if (id) {
              const embedUrl = `https://open.spotify.com/embed/${type}/${id}`;
              const { body: html } = await fetchHtml(embedUrl);
              const nextDataMatch = html.match(/<script id="__NEXT_DATA__" type="application\/json">([\s\S]+?)<\/script>/);
              if (nextDataMatch) {
                const nextData = JSON.parse(nextDataMatch[1]);
                const entity = nextData.props?.pageProps?.state?.data?.entity;
                if (entity) {
                  const isArtist = entity.type === "artist" || type === "artist";
                  const playlistTitle = isArtist ? `${entity.name || "Artist"} - Top Tracks` : entity.name || entity.title || "Spotify Playlist";
                  const coverImg = entity.coverArt?.sources?.[0]?.url || entity.visualIdentity?.image?.[1]?.url || entity.visualIdentity?.image?.[0]?.url || "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800";
                  const rawTracks = entity.trackList || [];
                  const defaultArtist = entity.name || entity.subtitle || "Artist";
                  const items = rawTracks.map((t, idx) => {
                    const trackTitle = t.title || `Track ${idx + 1}`;
                    const trackArtist = t.subtitle || defaultArtist;
                    const durSec = t.duration ? Math.round(t.duration / 1e3) : 180;
                    const trackUri = t.uri ? t.uri.replace("spotify:track:", "https://open.spotify.com/track/") : url;
                    const fullTitle = trackArtist ? `${trackTitle} - ${trackArtist}`.trim() : trackTitle;
                    const searchQuery = `ytsearch1:${trackTitle} ${trackArtist} audio`.trim();
                    return {
                      id: t.id || t.uid || `spotify_${idx}`,
                      url: trackUri,
                      title: fullTitle,
                      duration: durSec,
                      thumbnail: coverImg,
                      channel: trackArtist,
                      uploader: trackArtist,
                      downloadQuery: searchQuery,
                      index: idx + 1
                    };
                  });
                  return {
                    id,
                    url,
                    title: playlistTitle,
                    uploader: isArtist ? entity.name : entity.subtitle || "Spotify",
                    itemCount: items.length,
                    items,
                    thumbnail: coverImg
                  };
                }
              }
            }
          } catch (spErr) {
            logger.warn("Spotify playlist embed scraper notice:", spErr);
          }
        }
        logger.info(`Analyzing playlist with yt-dlp: ${url}`);
        const ytdlpPath = await dependencyManager.getYtDlpExecutablePath();
        const ytArgs = await youtubeTokenManager.getYtDlpExtractorArgs(url);
        const args = [
          "--flat-playlist",
          "--playlist-items",
          "1:50",
          "--dump-single-json",
          "--no-check-certificates",
          "--prefer-free-formats",
          ...ytArgs,
          "--add-header",
          "User-Agent:Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
          url
        ];
        try {
          const { stdout } = await execFileAsync2(ytdlpPath, args, {
            windowsHide: true,
            timeout: timeoutMs,
            maxBuffer: 50 * 1024 * 1024
          });
          const raw = JSON.parse(stdout);
          const items = (raw.entries || []).map((entry, index) => {
            let entryUrl = entry.url || entry.webpage_url || "";
            if (entry.id && (!entryUrl || !entryUrl.startsWith("http"))) {
              entryUrl = `https://www.youtube.com/watch?v=${entry.id}`;
            }
            if (!entryUrl) entryUrl = url;
            const entryTitle = entry.title || `Track ${index + 1}`;
            const hMatch = entryTitle.match(/(\d{3,4})p/i);
            let detectedH = entry.height || 0;
            if (!detectedH && hMatch) {
              detectedH = parseInt(hMatch[1], 10);
            } else if (!detectedH) {
              if (/\b4k\b/i.test(entryTitle) || /\b2160\b/.test(entryTitle)) detectedH = 2160;
              else if (/\b1440\b/.test(entryTitle) || /\b2k\b/i.test(entryTitle)) detectedH = 1440;
              else if (/\b1080\b/.test(entryTitle)) detectedH = 1080;
              else if (/\b720\b/.test(entryTitle)) detectedH = 720;
              else if (/\b480\b/.test(entryTitle)) detectedH = 480;
            }
            return {
              id: entry.id || `item_${index}`,
              url: entryUrl,
              downloadQuery: entryUrl,
              title: entryTitle,
              duration: entry.duration || 0,
              thumbnail: entry.thumbnail || entry.thumbnails?.[0]?.url,
              channel: entry.uploader || entry.channel || "",
              uploader: entry.uploader || entry.channel || "",
              index: index + 1,
              height: detectedH,
              resolution: detectedH ? `${detectedH}p` : void 0
            };
          });
          if (items.length > 0 && items[0].url && !items.some((it) => it.height > 0)) {
            try {
              const sampleArgs = [
                "--dump-single-json",
                "--skip-download",
                "--no-warnings",
                "--no-playlist",
                ...ytArgs,
                items[0].url
              ];
              const sampleProc = await execFileAsync2(ytdlpPath, sampleArgs, { windowsHide: true, timeout: 6e3 });
              const sampleRaw = JSON.parse(sampleProc.stdout);
              const sampleHeights = (sampleRaw.formats || []).map((f) => f.height).filter((h) => typeof h === "number" && h > 0);
              if (sampleHeights.length > 0) {
                const maxH = Math.max(...sampleHeights);
                items[0].height = maxH;
                items[0].resolution = `${maxH}p`;
              }
            } catch (_) {
            }
          }
          const rawTitle = (raw.title || raw.playlist_title || raw.playlist || raw.name || "").trim();
          const firstUploader = items[0]?.uploader || items[0]?.channel || raw.uploader || raw.channel || "";
          let finalTitle = rawTitle;
          if (!finalTitle || finalTitle === "NA" || finalTitle === "[NA]" || finalTitle.toLowerCase() === "playlist") {
            finalTitle = firstUploader ? `${firstUploader} - Playlist` : raw.id ? `Playlist_${raw.id}` : "Media Playlist";
          }
          return {
            id: raw.id || "playlist",
            url,
            title: finalTitle,
            uploader: raw.uploader || raw.channel || firstUploader || "YouTube",
            itemCount: items.length,
            items,
            thumbnail: raw.thumbnails?.[0]?.url || (items[0]?.thumbnail || "")
          };
        } catch (err) {
          logger.error("Playlist analysis failed:", err);
          const vMatch = url.match(/(?:v=|\/watch\/|\/embed\/|youtu\.be\/|shorts\/)([a-zA-Z0-9_-]{11})/);
          if (vMatch && vMatch[1]) {
            try {
              logger.info(`Playlist analysis failed, attempting fallback to single video for ID ${vMatch[1]}`);
              const singleUrl = `https://www.youtube.com/watch?v=${vMatch[1]}`;
              const singleMeta = await this.analyzeUrl(singleUrl, 15e3);
              if (singleMeta) {
                return {
                  id: vMatch[1],
                  url,
                  title: singleMeta.title || "YouTube Media",
                  uploader: singleMeta.uploader || "YouTube",
                  itemCount: 1,
                  items: [{
                    id: singleMeta.id || vMatch[1],
                    url: singleUrl,
                    title: singleMeta.title || "YouTube Media",
                    duration: singleMeta.duration || 0,
                    thumbnail: singleMeta.thumbnail || "",
                    channel: singleMeta.uploader || "",
                    uploader: singleMeta.uploader || "",
                    index: 1,
                    height: singleMeta.height || 0,
                    resolution: singleMeta.resolution || (singleMeta.height ? `${singleMeta.height}p` : void 0)
                  }],
                  thumbnail: singleMeta.thumbnail || ""
                };
              }
            } catch (singleErr) {
              logger.warn("Single video fallback after playlist failure failed:", singleErr);
            }
          }
          throw classifyError(err, "Failed to analyze playlist");
        }
      }
      isThreadsUrl(urlStr) {
        if (!this.isValidUrl(urlStr)) return false;
        return /threads\.(?:net|com)/i.test(urlStr);
      }
      isSpotifyUrl(urlStr) {
        if (!this.isValidUrl(urlStr)) return false;
        return /spotify\.(?:com|link)/i.test(urlStr);
      }
      isPinterestUrl(urlStr) {
        if (!this.isValidUrl(urlStr)) return false;
        const lower = urlStr.toLowerCase();
        return lower.includes("pinterest.com") || lower.includes("pin.it");
      }
      async expandPinterestUrl(urlStr) {
        if (!urlStr || !urlStr.includes("pin.it")) return urlStr;
        try {
          const res = await fetchHtml(urlStr);
          if (res.finalUrl && !res.finalUrl.includes("pin.it")) {
            return res.finalUrl;
          }
        } catch (e) {
          logger.warn("[Analyzer] Failed to expand pin.it with fetchHtml:", e.message);
        }
        return urlStr;
      }
      async analyzeThreads(url, timeoutMs = 2e4) {
        logger.info(`Analyzing Threads post: ${url}`);
        try {
          const { body: html, finalUrl } = await fetchHtml(url, {
            "User-Agent": "facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)"
          });
          let ogVideo = html.match(/<meta[^>]+property=["']og:video(?::secure_url)?["'][^>]+content=["']([^"']+)["']/i)?.[1]?.replace(/&amp;/g, "&");
          const ogTitle = html.match(/<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']/i)?.[1];
          const ogDesc = html.match(/<meta[^>]+property=["']og:description["'][^>]+content=["']([^"']+)["']/i)?.[1];
          const ogImage = html.match(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i)?.[1]?.replace(/&amp;/g, "&");
          let videoUrl = ogVideo || "";
          if (!videoUrl) {
            const clean = html.replace(/\\u0025/g, "%").replace(/\\u0026/g, "&").replace(/\\\//g, "/").replace(/&amp;/g, "&");
            const vids = clean.match(/https:\/\/[a-zA-Z0-9.\-_]+(?:fbcdn\.net|cdninstagram\.com)[^"\'><\s\\]+?\.mp4[^"\'><\s\\]*/g) || [];
            const valid = vids.filter((v) => !v.includes("rsrc.php") && v.includes("oh=") && v.includes("oe="));
            if (valid.length > 0) {
              videoUrl = valid[0];
            } else if (vids.length > 0) {
              videoUrl = vids.find((v) => !v.includes("rsrc.php")) || "";
            }
          }
          let author = "Threads Creator";
          let title = "Threads Post";
          let thumbnail = ogImage || "https://images.unsplash.com/photo-1611605698335-8b1569810432?w=800";
          const urlAuthorMatch = (finalUrl || url).match(/@([a-zA-Z0-9._]+)/);
          if (urlAuthorMatch) {
            author = "@" + urlAuthorMatch[1];
          } else if (ogTitle) {
            const aMatch = ogTitle.match(/@([a-zA-Z0-9._]+)/);
            if (aMatch) author = "@" + aMatch[1];
          }
          if (ogDesc) {
            let cleanDesc = ogDesc.replace(/&amp;/g, "&").replace(/&#x[0-9a-fA-F]+;/g, " ").replace(/&#[0-9]+;/g, " ").replace(/&quot;/g, '"').replace(/https?:\/\/\S+/g, "").trim();
            const firstLine = cleanDesc.split(/[\r\n]+/)[0]?.trim();
            if (firstLine && firstLine.length >= 3) {
              title = firstLine.length > 120 ? firstLine.substring(0, 117) + "..." : firstLine;
            } else if (cleanDesc.length >= 3) {
              title = cleanDesc.length > 120 ? cleanDesc.substring(0, 117) + "..." : cleanDesc;
            }
          }
          const isGenericThreadsTitle = !title || title === "Threads Post" || title.toLowerCase().includes("log in") || title.toLowerCase().includes("login") || title.toLowerCase().includes("join threads") || title.toLowerCase().includes("sign up");
          if (isGenericThreadsTitle) {
            title = author && author !== "Threads Creator" ? `Threads Video (${author})` : "Threads Video";
          }
          const scMatch = (finalUrl || url).match(/post\/([a-zA-Z0-9_-]+)/) || url.match(/share\/([a-zA-Z0-9_-]+)/);
          const shortcode = scMatch ? scMatch[1] : "";
          const hasVideo = !!videoUrl;
          const formats = [];
          if (hasVideo) {
            formats.push({
              formatId: "threads-best",
              ext: "mp4",
              resolution: "1080x1920",
              height: 1080,
              width: 1920,
              vcodec: "h264",
              acodec: "aac",
              isAudioOnly: false,
              isVideoOnly: false,
              hasAudioAndVideo: true,
              qualityLabel: "1080p Full HD",
              url: videoUrl
            });
            formats.push({
              formatId: "threads-720p",
              ext: "mp4",
              resolution: "720x1280",
              height: 720,
              width: 1280,
              vcodec: "h264",
              acodec: "aac",
              isAudioOnly: false,
              isVideoOnly: false,
              hasAudioAndVideo: true,
              qualityLabel: "720p HD",
              url: videoUrl
            });
            formats.push({
              formatId: "threads-audio",
              ext: "mp3",
              isAudioOnly: true,
              isVideoOnly: false,
              hasAudioAndVideo: false,
              qualityLabel: "Audio (MP3 320kbps)",
              url: videoUrl
            });
          } else if (ogImage) {
            formats.push({
              formatId: "threads-image",
              ext: "jpg",
              resolution: "Original Photo",
              isAudioOnly: false,
              isVideoOnly: false,
              hasAudioAndVideo: false,
              qualityLabel: "Original Photo (JPG)",
              url: ogImage
            });
          }
          return {
            id: shortcode || "threads_" + Date.now(),
            url,
            directStreamUrl: videoUrl || ogImage,
            title,
            thumbnail,
            duration: hasVideo ? 30 : 0,
            uploader: author,
            channel: author,
            description: ogDesc,
            extractor: "Threads",
            formats,
            availableResolutions: hasVideo ? [1080, 720] : [],
            hasAudio: hasVideo,
            hasVideo,
            hasImage: !hasVideo && !!ogImage,
            defaultProfile: {
              type: hasVideo ? "video" : "image",
              presetId: hasVideo ? "best-available" : "original-image",
              label: hasVideo ? "Best Available Quality (Universal H.264)" : "Original Photo (JPG)",
              container: hasVideo ? "mp4" : "jpg",
              remuxToMp4: hasVideo
            }
          };
        } catch (err) {
          logger.error("Threads analysis failed:", err);
          throw classifyError(err, "Failed to analyze Threads media");
        }
      }
      async analyzeSpotify(url, timeoutMs = 35e3) {
        if (this.isSpotifyPlaylistUrl(url)) {
          return await this.analyzePlaylist(url, timeoutMs);
        }
        logger.info(`Analyzing Spotify track: ${url}`);
        try {
          let trackTitle = "";
          let artist = "";
          let thumbnail = "";
          let durationSec = 0;
          const trackIdMatch = url.match(/track\/([a-zA-Z0-9]+)/);
          const trackId = trackIdMatch ? trackIdMatch[1] : "";
          try {
            const { body: ssrHtml, statusCode: ssrStatus } = await fetchHtml(url, {
              "User-Agent": "facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)"
            });
            if (ssrStatus === 200) {
              const ogTitleMatch = ssrHtml.match(/<meta property=["']og:title["'] content=["']([^"']+)["']/i);
              const ogDescMatch = ssrHtml.match(/<meta property=["']og:description["'] content=["']([^"']+)["']/i);
              const ogImageMatch = ssrHtml.match(/<meta property=["']og:image["'] content=["']([^"']+)["']/i);
              const durationMatch = ssrHtml.match(/<meta property=["']music:duration["'] content=["']([^"']+)["']/i);
              if (ogTitleMatch && ogTitleMatch[1] && !ogTitleMatch[1].startsWith("Spotify")) {
                trackTitle = ogTitleMatch[1];
              }
              if (ogDescMatch && ogDescMatch[1]) {
                const parts = ogDescMatch[1].split("\xB7").map((s) => s.trim());
                if (parts.length > 0 && parts[0]) artist = parts[0];
              }
              if (ogImageMatch && ogImageMatch[1]) {
                thumbnail = ogImageMatch[1];
              }
              if (durationMatch && durationMatch[1]) {
                durationSec = parseInt(durationMatch[1], 10);
              }
            }
          } catch (ssrErr) {
            logger.warn("Spotify SSR scraper notice:", ssrErr);
          }
          if (trackId) {
            try {
              const embedUrl = `https://open.spotify.com/embed/track/${trackId}`;
              const { body: embedHtml } = await fetchHtml(embedUrl);
              const nextDataMatch = embedHtml.match(/<script id="__NEXT_DATA__" type="application\/json">([\s\S]+?)<\/script>/);
              if (nextDataMatch) {
                const nextData = JSON.parse(nextDataMatch[1]);
                const entity = nextData.props?.pageProps?.state?.data?.entity;
                if (entity) {
                  if (entity.name && (!trackTitle || trackTitle === "Spotify Track")) {
                    trackTitle = entity.name;
                  }
                  if (entity.artists && Array.isArray(entity.artists) && entity.artists.length > 0) {
                    artist = entity.artists.map((a) => a.name).filter(Boolean).join(", ");
                  }
                  if (entity.duration) {
                    durationSec = Math.round(entity.duration / 1e3);
                  }
                  const coverImg = entity.visualIdentity?.image?.[1]?.url || entity.visualIdentity?.image?.[0]?.url || entity.coverArt?.sources?.[0]?.url;
                  if (coverImg && (!thumbnail || thumbnail.includes("unsplash"))) {
                    thumbnail = coverImg;
                  }
                }
              }
            } catch (embErr) {
              logger.warn("Spotify embed parse notice:", embErr);
            }
          }
          if (!trackTitle) {
            try {
              const oembedUrl = `https://open.spotify.com/oembed?url=${encodeURIComponent(url)}`;
              const { body: oembedJson } = await fetchHtml(oembedUrl);
              const oembed = JSON.parse(oembedJson);
              if (oembed.title) trackTitle = oembed.title;
              if (oembed.thumbnail_url && !thumbnail) thumbnail = oembed.thumbnail_url;
            } catch (oeErr) {
              logger.warn("Spotify oembed notice:", oeErr);
            }
          }
          if (!trackTitle || trackTitle === "Spotify Track") {
            throw new Error("This Spotify track could not be found, is region-locked, or has been removed from Spotify.");
          }
          if (!artist) artist = "Spotify";
          if (!thumbnail) thumbnail = "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800";
          if (!durationSec) durationSec = 180;
          const query = `ytsearch1:${trackTitle} ${artist} audio`.trim();
          logger.info(`Pairing Spotify track with YouTube stream query: ${query}`);
          const ytdlpPath = await dependencyManager.getYtDlpExecutablePath();
          const ytArgs = await youtubeTokenManager.getYtDlpExtractorArgs(url);
          const args = [
            "--dump-single-json",
            "--no-playlist",
            "--no-check-certificates",
            "--prefer-free-formats",
            ...ytArgs,
            "--add-header",
            "User-Agent:Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
            query
          ];
          let meta;
          try {
            const { stdout } = await execFileAsync2(ytdlpPath, args, {
              windowsHide: true,
              timeout: Math.min(timeoutMs, 15e3),
              maxBuffer: 30 * 1024 * 1024
            });
            const raw = JSON.parse(stdout);
            const entry = raw.entries && raw.entries.length > 0 ? raw.entries[0] : raw;
            meta = this.parseYtDlpOutput(url, entry);
          } catch (ytSearchErr) {
            logger.warn("YouTube pairing search notice during Spotify analysis:", ytSearchErr.message);
            meta = {
              id: trackId || "spotify_track",
              url,
              title: trackTitle,
              formats: [{
                format_id: "audio_mp3_320",
                ext: "mp3",
                resolution: "audio only",
                note: "MP3 320kbps High Quality Audio"
              }],
              duration: durationSec || 180,
              thumbnail
            };
          }
          meta.id = trackId || (meta.id || "spotify_track");
          meta.url = url;
          meta.title = trackTitle;
          meta.thumbnail = thumbnail;
          meta.uploader = artist;
          meta.channel = artist;
          meta.extractor = "Spotify";
          meta.platform = "spotify";
          meta.isSpotify = true;
          meta.duration = durationSec > 0 ? durationSec : meta.duration;
          meta.downloadQuery = query;
          meta.downloadTarget = meta.webpage_url || query;
          delete meta.directStreamUrl;
          meta.defaultProfile = {
            type: "audio",
            presetId: "best-audio",
            label: "Best Audio Quality (MP3 320kbps)",
            container: "mp3"
          };
          return meta;
        } catch (err) {
          logger.error("Spotify analysis failed:", err);
          throw classifyError(err, "Failed to analyze Spotify song");
        }
      }
      async analyzePinterest(url, timeoutMs = 35e3) {
        logger.info(`Analyzing Pinterest URL: ${url}`);
        const targetUrl = await this.expandPinterestUrl(url);
        let title = "";
        let author = "Pinterest Creator";
        let thumbnail = "https://images.unsplash.com/photo-1579783902614-a3fb3927b675?w=800";
        let directImageUrl = "";
        let directVideoUrl = "";
        let durationSec = 0;
        let pinId = "";
        const pinMat = targetUrl.match(/pin\/(?:[\w-]+--)?(\d+)/i);
        if (pinMat) {
          pinId = pinMat[1];
        } else {
          const numMat = targetUrl.match(/(\d{10,22})/);
          if (numMat) pinId = numMat[1];
        }
        if (pinId) {
          try {
            const opts = { field_set_key: "unauth_react_main_pin", id: pinId };
            const q = encodeURIComponent(JSON.stringify({ options: opts }));
            const apiUrl = `https://www.pinterest.com/resource/PinResource/get/?data=${q}`;
            const { body: apiBody, statusCode } = await fetchHtml(apiUrl, {
              "X-Pinterest-PWS-Handler": "www/[username].js",
              "Accept": "application/json, text/javascript, */*, q=0.01",
              "X-Requested-With": "XMLHttpRequest",
              "Referer": "https://www.pinterest.com/"
            });
            if (statusCode === 200 && apiBody) {
              const json = JSON.parse(apiBody);
              const data = json.resource_response?.data;
              if (data) {
                const parsedTitle = data.title || data.grid_title || data.closeup_unified_description || "";
                if (parsedTitle && parsedTitle.trim()) {
                  title = parsedTitle.trim();
                }
                const pinner = data.pinner;
                if (pinner) {
                  const pinnerName = pinner.full_name || pinner.username || "";
                  if (pinnerName) author = pinnerName;
                }
                const images = data.images;
                const origImg = images?.orig?.url || images?.["736x"]?.url || "";
                if (origImg) {
                  directImageUrl = origImg;
                  thumbnail = origImg;
                }
                let vidList = data.videos?.video_list;
                if (!vidList && data.story_pin_data?.pages) {
                  for (const page of data.story_pin_data.pages) {
                    if (page.blocks) {
                      for (const blk of page.blocks) {
                        if (blk.video?.video_list) {
                          vidList = blk.video.video_list;
                          break;
                        }
                      }
                    }
                    if (vidList) break;
                  }
                }
                if (vidList) {
                  const preferredKeys = ["V_EXP7", "V_720P", "V_480P"];
                  for (const pk of preferredKeys) {
                    const vObj = vidList[pk];
                    if (vObj?.url && vObj.url.includes(".mp4")) {
                      directVideoUrl = vObj.url;
                      if (vObj.duration) durationSec = Math.round(vObj.duration / 1e3);
                      if (vObj.thumbnail) thumbnail = vObj.thumbnail;
                      break;
                    }
                  }
                  if (!directVideoUrl) {
                    for (const vk of Object.keys(vidList)) {
                      const vObj = vidList[vk];
                      if (vObj?.url && vObj.url.includes(".mp4")) {
                        directVideoUrl = vObj.url;
                        if (vObj.duration) durationSec = Math.round(vObj.duration / 1e3);
                        if (vObj.thumbnail) thumbnail = vObj.thumbnail;
                        break;
                      }
                    }
                  }
                }
              }
            }
          } catch (apiErr) {
            logger.warn("[Analyzer] Pinterest PinResource query notice:", apiErr.message);
          }
        }
        if (!directVideoUrl && !directImageUrl) {
          try {
            const { body: html } = await fetchHtml(targetUrl, {
              "Referer": "https://www.google.com/"
            });
            const cleanHtml = html.replace(/\\\//g, "/").replace(/\\u002F/gi, "/").replace(/&amp;/g, "&");
            if (!title) {
              const ogTitleM = cleanHtml.match(/<meta\s+property=["']og:title["']\s+content=["'](.*?)["']/i) || cleanHtml.match(/<meta\s+content=["'](.*?)["']\s+property=["']og:title["']/i);
              if (ogTitleM && ogTitleM[1]) {
                title = ogTitleM[1].replace(/ \| Pinterest$/i, "").trim();
              } else {
                const pageTitleM = cleanHtml.match(/<title[^>]*>(.*?)<\/title>/i);
                if (pageTitleM && pageTitleM[1]) {
                  title = pageTitleM[1].replace(/ \| Pinterest$/i, "").trim();
                }
              }
            }
            const vidPattern = /https?:\/\/[a-zA-Z0-9.-]*pinimg\.com\/videos\/[a-zA-Z0-9/_.-]+\.mp4/i;
            const vidM = cleanHtml.match(vidPattern);
            if (vidM) {
              directVideoUrl = vidM[0];
            } else {
              const ogvM = cleanHtml.match(/<meta\s+property=["']og:video(?::secure_url)?["']\s+content=["'](.*?)["']/i);
              if (ogvM && ogvM[1]) directVideoUrl = ogvM[1];
            }
            const imgPattern = /https:\/\/i\.pinimg\.com\/(?:originals|736x)\/[a-zA-Z0-9/_.-]+\.(?:jpg|png|webp|gif)/i;
            const imgM = cleanHtml.match(imgPattern);
            if (imgM) {
              directImageUrl = imgM[0];
              if (!thumbnail || thumbnail.includes("unsplash")) thumbnail = directImageUrl;
            } else {
              const ogImgM = cleanHtml.match(/<meta\s+property=["']og:image["']\s+content=["'](.*?)["']/i);
              if (ogImgM && ogImgM[1]) {
                directImageUrl = ogImgM[1];
                if (!thumbnail || thumbnail.includes("unsplash")) thumbnail = directImageUrl;
              }
            }
          } catch (htmlErr) {
            logger.warn("[Analyzer] Pinterest HTML fallback notice:", htmlErr.message);
          }
        }
        if (!title) {
          title = pinId ? `Pinterest Pin ${pinId}` : "Pinterest Visual Media";
        }
        const isVideo = Boolean(directVideoUrl);
        const mediaStream = directVideoUrl || directImageUrl;
        const meta = {
          id: pinId || "pinterest_pin",
          url: targetUrl,
          title,
          uploader: author,
          channel: author,
          thumbnail,
          duration: durationSec,
          extractor: "pinterest",
          directStreamUrl: mediaStream,
          formats: isVideo ? [
            { formatId: "best-video", label: "Best Video (MP4)", ext: "mp4", resolution: "1080p", type: "video" },
            { formatId: "best-audio", label: "Audio Only (MP3)", ext: "mp3", type: "audio" }
          ] : [
            { formatId: "original-image", label: "High Resolution Photo", ext: "jpg", type: "image" }
          ],
          defaultProfile: isVideo ? {
            type: "video",
            presetId: "best-video",
            label: "Best Video Quality",
            container: "mp4"
          } : {
            type: "image",
            presetId: "original-image",
            label: "Original Image",
            container: "jpg"
          }
        };
        return meta;
      }
      isCloudStorageUrl(urlStr) {
        if (!this.isValidUrl(urlStr)) return false;
        const lower = urlStr.toLowerCase();
        if (lower.includes("/folders/") || lower.includes("folderview") || lower.includes("/scl/fo/")) return false;
        return lower.includes("drive.google.com") || lower.includes("dropbox.com") || lower.includes("1drv.ms") || lower.includes("onedrive.live.com") || lower.includes("sharepoint.com") || /\.(mp4|mov|mkv|webm|avi|flv|m4v|mp3|wav|m4a|aac|flac|ogg|zip|rar|7z|tar|gz)(\?.*)?$/i.test(urlStr);
      }
      async analyzeCloudStorage(url, timeoutMs = 35e3) {
        if (this.isPlaylistUrl(url)) {
          return await this.analyzePlaylist(url, timeoutMs);
        }
        logger.info(`Analyzing cloud storage / direct media URL: ${url}`);
        let directUrl = url;
        let title = "Cloud Media";
        let isArchive = false;
        let isAudio = false;
        let isVideo = true;
        const lower = url.toLowerCase();
        if (lower.includes("drive.google.com")) {
          const driveMatch = url.match(/\/d\/([a-zA-Z0-9_-]+)/) || url.match(/id=([a-zA-Z0-9_-]+)/);
          if (driveMatch) {
            directUrl = `https://drive.google.com/uc?export=download&id=${driveMatch[1]}`;
            title = `Google Drive File (${driveMatch[1].substring(0, 8)})`;
          }
        } else if (lower.includes("dropbox.com")) {
          directUrl = url.replace("dl=0", "dl=1");
          if (!directUrl.includes("dl=1")) {
            directUrl += (directUrl.includes("?") ? "&" : "?") + "dl=1";
          }
          const nameMatch = url.match(/\/([^/?#]+)\?/);
          if (nameMatch) {
            try {
              title = decodeURIComponent(nameMatch[1]);
            } catch (_) {
            }
          }
        } else if (lower.includes("1drv.ms") || lower.includes("onedrive.live.com") || lower.includes("sharepoint.com")) {
          directUrl = url.includes("download=1") ? url : url + (url.includes("?") ? "&" : "?") + "download=1";
          title = "OneDrive File";
        } else {
          try {
            const u = new URL(url);
            const bname = import_path6.default.basename(u.pathname);
            if (bname) title = decodeURIComponent(bname);
          } catch (_) {
          }
        }
        if (/\.(zip|rar|7z|tar|gz)(\?.*)?$/i.test(url) || /\.(zip|rar|7z|tar|gz)(\?.*)?$/i.test(directUrl)) {
          isArchive = true;
          isVideo = false;
          isAudio = false;
        } else if (/\.(mp3|wav|m4a|aac|flac|ogg)(\?.*)?$/i.test(url) || /\.(mp3|wav|m4a|aac|flac|ogg)(\?.*)?$/i.test(directUrl)) {
          isAudio = true;
          isVideo = false;
        }
        return {
          id: "cloud_" + Date.now(),
          url: directUrl,
          directUrl,
          directStreamUrl: directUrl,
          title,
          thumbnail: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800",
          duration: 0,
          uploader: "Cloud Storage",
          channel: "Cloud Storage",
          extractor: "cloud",
          isArchive,
          hasAudio: isAudio || isVideo,
          hasVideo: isVideo,
          availableResolutions: isVideo ? [1080, 720] : [],
          formats: isArchive ? [
            { format_id: "archive_original", ext: "zip", height: null, vcodec: "none", acodec: "none", url: directUrl }
          ] : isVideo ? [
            { format_id: "cloud_1080p", ext: "mp4", height: 1080, vcodec: "h264", acodec: "aac", url: directUrl },
            { format_id: "cloud_720p", ext: "mp4", height: 720, vcodec: "h264", acodec: "aac", url: directUrl },
            { format_id: "cloud_audio", ext: "mp3", height: null, vcodec: "none", acodec: "mp3", url: directUrl }
          ] : [
            { format_id: "cloud_audio", ext: "mp3", height: null, vcodec: "none", acodec: "mp3", url: directUrl }
          ],
          defaultProfile: isArchive ? {
            type: "archive",
            presetId: "original-archive",
            label: "Original Archive (.zip)",
            container: "zip"
          } : isVideo ? {
            type: "video",
            presetId: "best-available",
            label: "Direct Cloud Video (MP4)",
            container: "mp4",
            remuxToMp4: true
          } : {
            type: "audio",
            presetId: "best-audio",
            label: "Direct Audio Stream (MP3)",
            container: "mp3"
          }
        };
      }
      async analyzeInstagram(url, timeoutMs = 25e3) {
        logger.info(`Analyzing Instagram media with multi-slide/carousel extractor: ${url}`);
        try {
          const pyCode = `
import sys, json, yt_dlp
url = sys.argv[1]
ydl = yt_dlp.YoutubeDL({'quiet': True, 'no_warnings': True})
ie = yt_dlp.extractor.instagram.InstagramIE(ydl)
res = ie._real_extract(url)
t = res.get('_type')
title = res.get('title') or (res.get('description') or '')[:60] or 'Instagram Post'
uploader = res.get('uploader') or res.get('channel') or '@Instagram'
if t == 'playlist':
    entries = res.get('entries', [])
    slides = []
    for idx, e in enumerate(entries):
        formats = e.get('formats') or []
        vid_url = formats[-1].get('url') if formats else None
        thumbs = e.get('thumbnails') or []
        img_url = thumbs[-1].get('url') if thumbs else (e.get('thumbnail') or None)
        slide_url = vid_url or img_url
        if slide_url:
            slides.append({
                'index': idx + 1,
                'title': f"{title} (Slide {idx + 1})",
                'url': slide_url,
                'thumbnail': img_url or vid_url,
                'isVideo': bool(vid_url),
                'duration': e.get('duration') or 0
            })
    print(json.dumps({'type': 'playlist', 'title': title, 'uploader': uploader, 'itemCount': len(slides), 'items': slides}))
else:
    formats = res.get('formats') or []
    vid_url = formats[-1].get('url') if formats else None
    thumbs = res.get('thumbnails') or []
    img_url = thumbs[-1].get('url') if thumbs else res.get('thumbnail')
    print(json.dumps({'type': 'single', 'title': title, 'uploader': uploader, 'videoUrl': vid_url, 'photoUrl': img_url, 'thumbnail': img_url or vid_url, 'duration': res.get('duration') or 0}))
`.trim();
          const { stdout } = await execFileAsync2("python", ["-c", pyCode, url], {
            windowsHide: true,
            timeout: timeoutMs,
            maxBuffer: 15 * 1024 * 1024
          });
          const parsed = JSON.parse(stdout.trim());
          if (parsed.type === "playlist" && parsed.items && parsed.items.length > 0) {
            return {
              isPlaylist: true,
              isCarousel: true,
              url,
              title: parsed.title,
              uploader: parsed.uploader,
              itemCount: parsed.items.length,
              items: parsed.items.map((s) => ({
                url: s.url,
                title: s.title,
                thumbnail: s.thumbnail,
                duration: s.duration || 0,
                downloadQuery: s.url,
                uploader: parsed.uploader
              }))
            };
          } else if (parsed.photoUrl || parsed.videoUrl) {
            const isPhoto = !parsed.videoUrl;
            return {
              id: "instagram_" + Date.now(),
              url,
              title: parsed.title,
              uploader: parsed.uploader,
              thumbnail: parsed.thumbnail,
              duration: parsed.duration || 0,
              formats: [
                {
                  formatId: isPhoto ? "photo_original" : "video_original",
                  ext: isPhoto ? "jpg" : "mp4",
                  resolution: isPhoto ? "Original High-Res Photo" : "1080p Full HD",
                  url: parsed.videoUrl || parsed.photoUrl,
                  isImage: isPhoto
                }
              ],
              isImage: isPhoto
            };
          }
        } catch (e) {
          logger.warn("[Instagram Carousel] Python extractor fallback failed:", e.message);
        }
        try {
          const shortcodeMatch = url.match(/(?:p|reel|tv)\/([a-zA-Z0-9_-]+)/);
          const shortcode = shortcodeMatch ? shortcodeMatch[1] : "";
          if (shortcode) {
            const embedUrl = `https://www.instagram.com/p/${shortcode}/embed/captioned/`;
            const { body } = await fetchHtml(embedUrl);
            const imgMat = body.match(/<img[^>]+class="[^"]*EmbeddedMediaImage[^"]*"[^>]+src="([^"]+)"/);
            const titleMat = body.match(/class="[^"]*Caption[^"]*"[^>]*>(.*?)<\/div>/s);
            const userMat = body.match(/class="[^"]*Username[^"]*"[^>]*>(.*?)<\/div>/s);
            const rawPhoto = imgMat ? imgMat[1].replace(/&amp;/g, "&") : "";
            const cap = titleMat ? titleMat[1].replace(/<[^>]+>/g, "").trim() : "Instagram Post";
            const user = userMat ? userMat[1].replace(/<[^>]+>/g, "").trim() : "Instagram";
            if (rawPhoto) {
              return {
                id: "instagram_" + shortcode,
                url,
                title: cap,
                uploader: user,
                thumbnail: rawPhoto,
                duration: 0,
                formats: [{
                  formatId: "photo_embed",
                  ext: "jpg",
                  resolution: "Original Photo",
                  url: rawPhoto,
                  isImage: true
                }],
                isImage: true
              };
            }
          }
        } catch (embErr) {
          logger.warn("[Instagram Carousel] Embed fallback failed:", embErr.message);
        }
        throw new Error("Could not analyze Instagram carousel or photo post.");
      }
      async analyzeUrl(url, timeoutMs = 35e3) {
        if (this.isPlaylistUrl(url)) {
          return await this.analyzePlaylist(url, timeoutMs);
        }
        if (this.isThreadsUrl(url)) {
          return await this.analyzeThreads(url, timeoutMs);
        }
        if (this.isSpotifyPlaylistUrl(url)) {
          return await this.analyzePlaylist(url, timeoutMs);
        }
        if (this.isSpotifyUrl(url)) {
          return await this.analyzeSpotify(url, timeoutMs);
        }
        if (this.isPinterestUrl(url)) {
          return await this.analyzePinterest(url, timeoutMs);
        }
        if (this.isCloudStorageUrl(url)) {
          return await this.analyzeCloudStorage(url, timeoutMs);
        }
        if (url.includes("instagram.com/p/") || url.includes("instagram.com/reel/")) {
          try {
            const igResult = await this.analyzeInstagram(url, timeoutMs);
            if (igResult) return igResult;
          } catch (igErr) {
            logger.info(`Instagram custom handler deferred to yt-dlp: ${igErr.message}`);
          }
        }
        logger.info(`Analyzing URL with yt-dlp: ${url}`);
        const ytdlpPath = await dependencyManager.getYtDlpExecutablePath();
        const isMultiPost = url.includes("instagram.com") || url.includes("pinterest.com");
        const ytArgs = await youtubeTokenManager.getYtDlpExtractorArgs(url);
        const args = [
          "--dump-single-json",
          "--skip-download",
          "--no-warnings",
          ...isMultiPost ? [] : ["--no-playlist"],
          "--no-check-certificates",
          "--match-filter",
          "!is_storyboard",
          ...ytArgs,
          "--add-header",
          "User-Agent:Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
          url
        ];
        const localAppData = process.env.LOCALAPPDATA || (import_os6.default.homedir ? import_path6.default.join(import_os6.default.homedir(), "AppData", "Local") : "");
        const cookiesFilePath = localAppData ? import_path6.default.join(localAppData, "MediaFetch", "cookies.txt") : "";
        if (cookiesFilePath && import_fs6.default.existsSync(cookiesFilePath) && import_fs6.default.statSync(cookiesFilePath).size > 10) {
          args.push("--cookies", cookiesFilePath);
        } else {
          const cookiesBrowser = settingsManager.getSettings()?.engine?.cookiesBrowser || "none";
          if (cookiesBrowser && cookiesBrowser !== "none") {
            args.push("--cookies-from-browser", cookiesBrowser);
          }
        }
        try {
          const { stdout } = await execFileAsync2(ytdlpPath, args, {
            windowsHide: true,
            timeout: timeoutMs,
            maxBuffer: 30 * 1024 * 1024
          });
          const raw = JSON.parse(stdout);
          return this.parseYtDlpOutput(url, raw);
        } catch (err) {
          if (url.includes("instagram.com") || err && String(err).includes("No video formats found")) {
            try {
              return await this.analyzeInstagram(url, timeoutMs);
            } catch (_) {
            }
          }
          logger.error("Metadata analysis failed:", err);
          throw classifyError(err, "Failed to analyze media URL");
        }
      }
      resolveAuthenticTitle(raw, url) {
        let candidate = "";
        const isYouTube = raw.extractor_key && raw.extractor_key.toLowerCase().includes("youtube") || raw.extractor && raw.extractor.toLowerCase().includes("youtube") || url && (url.includes("youtube.com") || url.includes("youtu.be"));
        const rawTitle = (raw.title || "").trim();
        const isGenericTitle = !rawTitle || /^video by /i.test(rawTitle) || /^post by /i.test(rawTitle) || /^tweet by /i.test(rawTitle) || /^tiktok video by /i.test(rawTitle) || /^threads post by /i.test(rawTitle) || /^photo by /i.test(rawTitle) || /^media by /i.test(rawTitle) || rawTitle.toLowerCase() === "media" || rawTitle.toLowerCase() === "instagram" || rawTitle.toLowerCase() === "threads" || rawTitle.toLowerCase() === "twitter" || rawTitle.toLowerCase() === "tiktok" || rawTitle.toLowerCase() === "facebook" || rawTitle.toLowerCase().includes("log in") || rawTitle.toLowerCase().includes("login");
        if ((!isYouTube || isGenericTitle) && raw.description) {
          const lines = raw.description.split(/[\r\n]+/);
          for (let line of lines) {
            line = line.replace(/https?:\/\/\S+/g, "").replace(/[#@]\S+/g, "").trim();
            line = line.replace(/^["'“”‘]+|["'“”‘]+$/g, "").trim();
            if (line.length >= 3) {
              candidate = line;
              break;
            }
          }
          if (!candidate) {
            for (const line of lines) {
              const trimmed = line.trim();
              if (trimmed.length >= 3 && !trimmed.startsWith("http")) {
                candidate = trimmed;
                break;
              }
            }
          }
        }
        if (candidate) {
          if (candidate.length > 120) candidate = candidate.substring(0, 117).trim() + "...";
          return candidate;
        }
        if (raw.fulltitle && !isGenericTitle) return raw.fulltitle.trim();
        if (rawTitle && !isGenericTitle) return rawTitle;
        if (rawTitle && /^video by /i.test(rawTitle)) {
          const stripped = rawTitle.replace(/^video by /i, "").trim();
          if (stripped) return `Instagram Clip (${stripped})`;
        }
        if (raw.uploader) return `Media by ${raw.uploader}`;
        return "Media";
      }
      parseYtDlpOutput(url, raw) {
        const formats = (raw.formats || []).map((f) => {
          const isAudioOnly = f.vcodec === "none" && f.acodec !== "none";
          const isVideoOnly = f.vcodec !== "none" && f.acodec === "none";
          const hasAudioAndVideo = f.vcodec !== "none" && f.acodec !== "none";
          let qualityLabel = "";
          if (f.height) {
            qualityLabel = `${f.height}p`;
            if (f.fps && f.fps > 30) qualityLabel += `${f.fps}`;
          } else if (f.abr) {
            qualityLabel = `${Math.round(f.abr)}kbps audio`;
          } else {
            qualityLabel = f.format_note || f.ext;
          }
          return {
            formatId: f.format_id,
            ext: f.ext,
            resolution: f.resolution || (f.height ? `${f.width || "?"}x${f.height}` : void 0),
            height: f.height,
            width: f.width,
            vcodec: f.vcodec,
            acodec: f.acodec,
            filesize: f.filesize,
            filesizeApprox: f.filesize_approx,
            fps: f.fps,
            tbr: f.tbr,
            vbr: f.vbr,
            abr: f.abr,
            isAudioOnly,
            isVideoOnly,
            hasAudioAndVideo,
            qualityLabel,
            protocol: f.protocol
          };
        });
        const heights = formats.map((f) => f.height).filter((h) => typeof h === "number" && h > 0 && h <= 2160);
        const availableResolutions = [...new Set(heights)].sort((a, b) => b - a);
        const hasAudio = formats.some((f) => f.acodec && f.acodec !== "none");
        const hasVideo = formats.some((f) => f.vcodec && f.vcodec !== "none");
        const meta = {
          id: raw.id || "media",
          url,
          title: this.resolveAuthenticTitle(raw, url),
          thumbnail: (() => {
            let best = raw.thumbnail;
            if (Array.isArray(raw.thumbnails) && raw.thumbnails.length > 0) {
              const sorted = [...raw.thumbnails].sort((a, b) => (b.width || 0) * (b.height || 0) - (a.width || 0) * (a.height || 0));
              if (sorted[0]?.url) best = sorted[0].url;
            }
            if (raw.id && (raw.extractor_key === "Youtube" || url.includes("youtu"))) {
              best = `https://i.ytimg.com/vi/${raw.id}/maxresdefault.jpg`;
            }
            return best || raw.thumbnails?.[0]?.url;
          })(),
          duration: raw.duration,
          uploader: raw.uploader || raw.channel || raw.creator,
          channel: raw.channel,
          description: raw.description ? raw.description.substring(0, 300) : void 0,
          extractor: raw.extractor_key || raw.extractor,
          formats,
          availableResolutions,
          hasAudio,
          hasVideo,
          defaultProfile: {
            type: "video",
            presetId: "best-available",
            label: "Best Available Quality (Universal H.264)",
            container: "mp4",
            remuxToMp4: true
          }
        };
        if (raw._type === "playlist" || raw.entries && Array.isArray(raw.entries) && raw.entries.length > 1) {
          const entries = Array.isArray(raw.entries) ? raw.entries : [];
          meta.isPlaylist = true;
          meta.isCarousel = true;
          meta.itemCount = entries.length;
          meta.items = entries.map((entry, idx) => {
            const isEntryVideo = entry.vcodec && entry.vcodec !== "none" || entry.formats && entry.formats.some((f) => f.vcodec && f.vcodec !== "none");
            const entryThumb = entry.thumbnail || entry.thumbnails?.[0]?.url || meta.thumbnail;
            const entryUrl = entry.url || entry.webpage_url || url;
            const entryTitle = entry.title || `${meta.title} (Slide ${idx + 1})`;
            return {
              id: entry.id || `slide_${idx + 1}`,
              title: entryTitle,
              thumbnail: entryThumb,
              duration: entry.duration || 0,
              url: entryUrl,
              downloadQuery: entryUrl,
              uploader: entry.uploader || meta.uploader || "@Instagram",
              mediaType: isEntryVideo ? "video" : "image",
              subFolderName: ""
            };
          });
          meta.carouselSlides = meta.items.map((item, idx) => ({
            index: idx + 1,
            id: item.id,
            mediaType: item.mediaType,
            label: `Slide ${idx + 1} \u2022 ${item.mediaType === "video" ? "Video" : "Photo"}`,
            url: item.url,
            thumbnail: item.thumbnail,
            duration: item.duration
          }));
        }
        return meta;
      }
      getAvailableProfiles(metadata) {
        const profiles = [];
        if (metadata.hasVideo) {
          profiles.push({
            type: "video",
            presetId: "best-available",
            label: "Best Available Quality (Universal H.264)",
            container: "mp4",
            remuxToMp4: true
          });
          if (metadata.availableResolutions.includes(2160)) {
            profiles.push({ type: "video", presetId: "video-4k", label: "4K Ultra HD (2160p) \u2022 Studio Quality (Slower \u2022 Large File)", resolution: 2160, container: "mp4", remuxToMp4: true });
          }
          if (metadata.availableResolutions.includes(1440)) {
            profiles.push({ type: "video", presetId: "video-1440p", label: "1440p Quad HD (2K) \u2022 High Quality (Moderate Speed)", resolution: 1440, container: "mp4", remuxToMp4: true });
          }
          if (metadata.availableResolutions.includes(1080) || metadata.availableResolutions.some((r) => r >= 1080)) {
            profiles.push({ type: "video", presetId: "video-1080p", label: "1080p Full HD \u2022 Recommended (Fast & Balanced)", resolution: 1080, container: "mp4", remuxToMp4: true });
          }
          if (metadata.availableResolutions.includes(720) || metadata.availableResolutions.some((r) => r >= 720)) {
            profiles.push({ type: "video", presetId: "video-720p", label: "720p HD \u2022 High Speed (Light File)", resolution: 720, container: "mp4", remuxToMp4: true });
          }
          profiles.push({
            type: "video",
            presetId: "video-prores",
            label: "Apple ProRes 422 HQ (Broadcast Master)",
            container: "mov"
          });
        }
        if (metadata.hasAudio) {
          profiles.push({
            type: "audio",
            presetId: "best-audio",
            label: "Best Audio Quality (MP3 320kbps)",
            container: "mp3"
          });
          profiles.push({
            type: "audio",
            presetId: "audio-wav",
            label: "Lossless Studio Audio (WAV 48kHz)",
            container: "wav"
          });
        }
        return profiles;
      }
    };
    metadataAnalyzer = new MetadataAnalyzer();
  }
});

// service/downloader.js
function getOptimalEncoderArgs(ffmpegPath) {
  if (cachedServiceEncoder) return cachedServiceEncoder;
  try {
    const encOut = (0, import_child_process3.execFileSync)(ffmpegPath, ["-hide_banner", "-encoders"], { encoding: "utf8", windowsHide: true, timeout: 2e3 });
    if (encOut.includes("h264_nvenc")) {
      cachedServiceEncoder = [
        "-c:v",
        "h264_nvenc",
        "-preset",
        "p2",
        "-cq",
        "16",
        "-b:v",
        "0",
        "-maxrate",
        "120M",
        "-bufsize",
        "120M",
        "-pix_fmt",
        "yuv420p"
      ];
    } else if (encOut.includes("h264_qsv")) {
      cachedServiceEncoder = [
        "-c:v",
        "h264_qsv",
        "-preset",
        "veryfast",
        "-global_quality",
        "17",
        "-pix_fmt",
        "yuv420p"
      ];
    } else if (encOut.includes("h264_amf")) {
      cachedServiceEncoder = [
        "-c:v",
        "h264_amf",
        "-quality",
        "quality",
        "-pix_fmt",
        "yuv420p"
      ];
    } else {
      cachedServiceEncoder = [
        "-c:v",
        "libx264",
        "-preset",
        "veryfast",
        "-crf",
        "17",
        "-pix_fmt",
        "yuv420p",
        "-threads",
        "0"
      ];
    }
  } catch (e) {
    cachedServiceEncoder = [
      "-c:v",
      "libx264",
      "-preset",
      "veryfast",
      "-crf",
      "18",
      "-pix_fmt",
      "yuv420p",
      "-threads",
      "0"
    ];
  }
  return cachedServiceEncoder;
}
var import_child_process3, import_util3, import_path7, import_fs7, import_os7, import_https3, import_http3, execFileAsync3, cachedServiceEncoder, DownloadJob;
var init_downloader = __esm({
  "service/downloader.js"() {
    import_child_process3 = require("child_process");
    import_util3 = require("util");
    import_path7 = __toESM(require("path"));
    import_fs7 = __toESM(require("fs"));
    import_os7 = __toESM(require("os"));
    import_https3 = __toESM(require("https"));
    import_http3 = __toESM(require("http"));
    init_errors();
    init_dependencies();
    init_filesystem();
    init_settings();
    init_analyzer();
    init_logger();
    init_youtubeToken();
    execFileAsync3 = (0, import_util3.promisify)(import_child_process3.execFile);
    cachedServiceEncoder = null;
    DownloadJob = class {
      constructor(item, onProgress) {
        this.item = item;
        this.childProcess = void 0;
        this.activeHttpRequest = void 0;
        this.isPaused = false;
        this.isCancelled = false;
        this.lastProgressEmit = 0;
        this.throttleMs = 250;
        this.onProgressCb = onProgress;
      }
      getItem() {
        return this.item;
      }
      async start() {
        let ytdlpPath = await dependencyManager.getYtDlpExecutablePath();
        let ffmpegPath = await dependencyManager.getFfmpegExecutablePath();
        let ffprobePath = await dependencyManager.getFfprobeExecutablePath();
        const binDir = dependencyManager.getBinDir();
        if (!import_fs7.default.existsSync(ytdlpPath)) {
          this.emitThrottledProgress({
            progress: 2,
            downloadedBytes: 0,
            totalBytes: 0,
            speed: "",
            eta: "",
            stageDescription: "Auto-installing media engine (first run)..."
          });
          await dependencyManager.installYtDlp((stage, pct, msg) => {
            this.emitThrottledProgress({
              progress: Math.min(10, Math.round(pct * 0.1)),
              downloadedBytes: 0,
              totalBytes: 0,
              speed: "",
              eta: "",
              stageDescription: msg || "Configuring media engine..."
            });
          });
          ytdlpPath = await dependencyManager.getYtDlpExecutablePath();
        }
        if (!import_fs7.default.existsSync(ffmpegPath)) {
          this.emitThrottledProgress({
            progress: 10,
            downloadedBytes: 0,
            totalBytes: 0,
            speed: "",
            eta: "",
            stageDescription: "Auto-installing FFmpeg merger (first run)..."
          });
          await dependencyManager.installFfmpeg((stage, pct, msg) => {
            this.emitThrottledProgress({
              progress: Math.min(20, 10 + Math.round(pct * 0.1)),
              downloadedBytes: 0,
              totalBytes: 0,
              speed: "",
              eta: "",
              stageDescription: msg || "Configuring FFmpeg..."
            });
          });
          ffmpegPath = await dependencyManager.getFfmpegExecutablePath();
          ffprobePath = await dependencyManager.getFfprobeExecutablePath();
        }
        const currentSettings = settingsManager.getSettings();
        let targetDir = this.item.targetFolder;
        if (!targetDir) {
          if (currentSettings?.downloads?.downloadLocationMode === "custom" && currentSettings?.downloads?.customLocation?.trim()) {
            targetDir = import_path7.default.resolve(currentSettings.downloads.customLocation.trim());
          } else {
            targetDir = this.item.projectFolder || filesystemManager.resolveTargetDirectory(this.item.projectContext).targetDir;
          }
        }
        const stagingDir = import_path7.default.join(targetDir, ".temp_mediafetch");
        filesystemManager.ensureDirExists(stagingDir);
        const isSpotify = this.item.url.includes("spotify.com") || this.item.url.includes("spotify.link");
        const isThreads = this.item.url.includes("threads.net") || this.item.url.includes("threads.com");
        const isPinterest = this.item.url.includes("pinterest.com") || this.item.url.includes("pin.it");
        const isInstagram = this.item.url.includes("instagram.com");
        const isPlaylistOrBatch = Boolean(this.item.metadata?.isPlaylist || this.item.metadata?.batchId || this.item.metadata?.zipPackage);
        if (!isSpotify && !isPlaylistOrBatch && this.item.metadata && this.item.metadata.url && this.item.metadata.url !== this.item.url && this.item.metadata.webpage_url !== this.item.url) {
          logger.info(`[DownloadJob] Discarding stale metadata for item ${this.item.id} (URL mismatch: ${this.item.metadata.url} vs ${this.item.url})`);
          this.item.metadata = {};
          this.item.title = "";
        }
        if (isPinterest && this.item.url.includes("pin.it")) {
          try {
            const expanded = await metadataAnalyzer.expandPinterestUrl(this.item.url);
            if (expanded && !expanded.includes("pin.it")) {
              this.item.url = expanded;
            }
          } catch (e) {
          }
        }
        const isGenericTitle = !this.item.title || this.item.title === "Fetching media info..." || /^video by /i.test(this.item.title) || /^post by /i.test(this.item.title) || this.item.title.toLowerCase() === "media";
        const needsMandatoryPreAnalysis = isSpotify && (!this.item.metadata?.downloadQuery || isGenericTitle) || isThreads && !this.item.metadata?.directStreamUrl || isPinterest && (!this.item.metadata?.directStreamUrl || isGenericTitle);
        if (needsMandatoryPreAnalysis) {
          try {
            logger.info(`[DownloadJob] Running mandatory pre-download metadata analysis for item ${this.item.id}: ${this.item.url}`);
            this.emitThrottledProgress({
              progress: 5,
              downloadedBytes: 0,
              totalBytes: 0,
              speed: "",
              eta: "",
              stageDescription: "Analyzing media information..."
            });
            const freshMeta = await metadataAnalyzer.analyzeUrl(this.item.url);
            if (freshMeta) {
              this.item.metadata = { ...this.item.metadata || {}, ...freshMeta };
              if (freshMeta.title && !/^video by /i.test(freshMeta.title) && freshMeta.title.toLowerCase() !== "media") {
                this.item.title = freshMeta.title;
              }
              if (freshMeta.thumbnail && !this.item.thumbnail) {
                this.item.thumbnail = freshMeta.thumbnail;
              }
              if (freshMeta.duration && !this.item.duration) {
                this.item.duration = freshMeta.duration;
              }
            }
          } catch (metaErr) {
            logger.warn(`[DownloadJob] Pre-download metadata analysis notice for ${this.item.url}:`, metaErr.message);
            if (isSpotify && !this.item.metadata?.downloadQuery && isGenericTitle) {
              throw metaErr;
            }
          }
        }
        let downloadTarget = this.item.metadata?.downloadQuery || this.item.metadata?.downloadTarget || this.item.metadata?.directStreamUrl || this.item.url;
        if (isSpotify) {
          if (this.item.metadata?.downloadQuery) {
            downloadTarget = this.item.metadata.downloadQuery;
          } else {
            const qTitle = !isGenericTitle && this.item.title ? this.item.title : this.item.metadata?.title || "song";
            const qArtist = this.item.metadata?.uploader || this.item.metadata?.channel || "";
            downloadTarget = `ytsearch1:${qTitle} ${qArtist} audio`.trim();
          }
        } else if (isThreads && this.item.metadata?.directStreamUrl) {
          downloadTarget = this.item.metadata.directStreamUrl;
        } else if (isPinterest && this.item.metadata?.directStreamUrl) {
          downloadTarget = this.item.metadata.directStreamUrl;
        }
        const isImageFile = Boolean(
          this.item.profile?.type === "image" || this.item.metadata?.mediaType === "image" || typeof this.item.title === "string" && /\.(jpg|jpeg|png|webp|gif|bmp|svg|tiff)($|\?)/i.test(this.item.title) || typeof downloadTarget === "string" && downloadTarget.startsWith("http") && /\.(jpg|jpeg|png|webp|gif|bmp|svg|tiff)($|\?)/i.test(downloadTarget)
        );
        if (isImageFile) {
          let imgTarget = downloadTarget;
          const allUrls = `${this.item.url} ${downloadTarget}`;
          const ytM = allUrls.match(/(?:v=|shorts\/|youtu\.be\/|embed\/)([a-zA-Z0-9_-]{11})/);
          if (this.item.profile?.type === "image" && ytM && ytM[1] && !this.item.metadata?.mediaType) {
            let candidateImg = this.item.thumbnail || this.item.metadata?.thumbnail;
            if (candidateImg) {
              imgTarget = candidateImg;
            } else {
              imgTarget = `https://i.ytimg.com/vi/${ytM[1]}/maxresdefault.jpg`;
            }
          }
          logger.info(`[DownloadJob] Direct image download for item ${this.item.id}: ${imgTarget}`);
          let ext = "jpg";
          const titleExtMatch = (this.item.title || "").match(/\.(jpg|jpeg|png|webp|gif|bmp|svg|tiff)($|\?)/i);
          const urlExtMatch = typeof downloadTarget === "string" ? downloadTarget.match(/\.(jpg|jpeg|png|webp|gif|bmp|svg|tiff)($|\?)/i) : null;
          if (titleExtMatch) {
            ext = titleExtMatch[1].toLowerCase();
          } else if (urlExtMatch) {
            ext = urlExtMatch[1].toLowerCase();
          } else if (this.item.profile?.container && ["jpg", "jpeg", "png", "webp", "gif", "bmp", "svg"].includes(this.item.profile.container.toLowerCase())) {
            ext = this.item.profile.container.toLowerCase();
          }
          let cleanCandidate = this.item.title || "image";
          if (titleExtMatch) {
            cleanCandidate = cleanCandidate.replace(/\.(jpg|jpeg|png|webp|gif|bmp|svg|tiff)($|\?)/i, "");
          }
          const cleanTitle = filesystemManager.sanitizeFilename(cleanCandidate).substring(0, 100);
          const finalName = `${cleanTitle}.${ext}`;
          const tempImgPath = import_path7.default.join(stagingDir, `${this.item.id}__MF__${cleanTitle}.${ext}`);
          const fallbacks = [];
          if (ytM && ytM[1]) {
            fallbacks.push(`https://i.ytimg.com/vi/${ytM[1]}/hq720.jpg`);
            fallbacks.push(`https://i.ytimg.com/vi/${ytM[1]}/hqdefault.jpg`);
          }
          this.emitThrottledProgress({
            progress: 10,
            downloadedBytes: 0,
            totalBytes: 0,
            speed: "",
            eta: "",
            stageDescription: "Downloading image file..."
          });
          try {
            await this.downloadDirectStream(imgTarget, tempImgPath);
          } catch (streamErr) {
            let downloadedOk = false;
            for (const fb of fallbacks) {
              try {
                await this.downloadDirectStream(fb, tempImgPath);
                downloadedOk = true;
                break;
              } catch (_) {
              }
            }
            if (!downloadedOk) {
              throw streamErr;
            }
          }
          const effectiveTargetDir = this.resolveFinalTargetDir(targetDir, ext, "image");
          const finalized = filesystemManager.finalizeDownloadedFile(tempImgPath, effectiveTargetDir, finalName);
          this.item.downloadedPath = finalized.finalPath;
          return finalized;
        }
        const isDirectArchive = this.item.profile?.type === "archive" || typeof downloadTarget === "string" && downloadTarget.startsWith("http") && downloadTarget.match(/\.(zip|rar|7z|tar|gz)($|\?)/i);
        if (isDirectArchive) {
          logger.info(`[DownloadJob] Direct archive download for item ${this.item.id}: ${downloadTarget}`);
          const cleanCandidate = !isGenericTitle && this.item.title ? this.item.title : this.item.metadata?.title || "cloud_archive";
          const cleanTitle = filesystemManager.sanitizeFilename(cleanCandidate).substring(0, 80);
          const extMatch = downloadTarget.match(/\.(zip|rar|7z|tar|gz)($|\?)/i);
          const ext = extMatch ? extMatch[1].toLowerCase() : "zip";
          const tempArchiveFile = import_path7.default.join(stagingDir, `${this.item.id}__MF__${cleanTitle}.${ext}`);
          await this.downloadDirectStream(downloadTarget, tempArchiveFile);
          const effectiveTargetDir = targetDir;
          const finalized = filesystemManager.finalizeDownloadedFile(tempArchiveFile, effectiveTargetDir, `${cleanTitle}.${ext}`);
          this.item.downloadedPath = finalized.finalPath;
          return finalized;
        }
        const isDirectVideoStream = !isSpotify && (this.item.profile?.type === "video" || this.item.profile?.type === "video-only") && Boolean(
          this.item.metadata?.directStreamUrl && !this.item.metadata.directStreamUrl.includes("youtube.com") && !this.item.metadata.directStreamUrl.includes("youtu.be") || typeof downloadTarget === "string" && downloadTarget.startsWith("http") && (downloadTarget.includes("fbcdn.net") || downloadTarget.includes("cdninstagram.com") || downloadTarget.includes("drive.google.com") || downloadTarget.includes("drive.usercontent.google.com") || downloadTarget.match(/\.(mp4|mov|mkv|webm|avi|m4v)($|\?)/i) && !downloadTarget.includes("googlevideo.com") && !downloadTarget.includes("youtube.com") && !downloadTarget.includes("youtu.be"))
        );
        if (isDirectVideoStream) {
          logger.info(`[DownloadJob] Direct video stream download for item ${this.item.id}: ${downloadTarget}`);
          const cleanCandidate = !isGenericTitle && this.item.title ? this.item.title : this.item.metadata?.title || "video_stream";
          const cleanTitle = filesystemManager.sanitizeFilename(cleanCandidate).substring(0, 80);
          const rawExtMatch = typeof downloadTarget === "string" ? (this.item.title || downloadTarget).match(/\.(mp4|mov|mkv|webm|avi|m4v)($|\?)/i) : null;
          const streamExt = rawExtMatch ? rawExtMatch[1].toLowerCase() : "mp4";
          const tempStreamFile = import_path7.default.join(stagingDir, `${this.item.id}__MF__${cleanTitle}.${streamExt}`);
          await this.downloadDirectStream(downloadTarget, tempStreamFile);
          return await this.processAndFinalizeDownloadedFile(tempStreamFile, stagingDir, targetDir, ffmpegPath, ffprobePath, binDir, cleanTitle);
        }
        const isDirectAudioStream = !isSpotify && this.item.profile?.type === "audio" && Boolean(
          typeof downloadTarget === "string" && downloadTarget.startsWith("http") && (downloadTarget.includes("drive.google.com") || downloadTarget.includes("drive.usercontent.google.com") || downloadTarget.match(/\.(mp3|wav|m4a|aac|flac|ogg)($|\?)/i))
        );
        if (isDirectAudioStream) {
          logger.info(`[DownloadJob] Direct audio stream download for item ${this.item.id}: ${downloadTarget}`);
          const cleanCandidate = !isGenericTitle && this.item.title ? this.item.title : this.item.metadata?.title || "audio_stream";
          const cleanTitle = filesystemManager.sanitizeFilename(cleanCandidate).substring(0, 80);
          const rawExtMatch = typeof downloadTarget === "string" ? (this.item.title || downloadTarget).match(/\.(mp3|wav|m4a|aac|flac|ogg|mp4|mov)($|\?)/i) : null;
          const streamExt = rawExtMatch ? rawExtMatch[1].toLowerCase() : "mp3";
          const tempStreamFile = import_path7.default.join(stagingDir, `${this.item.id}__MF__${cleanTitle}.${streamExt}`);
          await this.downloadDirectStream(downloadTarget, tempStreamFile);
          return await this.processAndFinalizeDownloadedFile(tempStreamFile, stagingDir, targetDir, ffmpegPath, ffprobePath, binDir, cleanTitle);
        }
        const cleanTitleCandidate = !isGenericTitle && this.item.title ? this.item.title : this.item.metadata?.title && !/^video by /i.test(this.item.metadata.title) ? this.item.metadata.title : "Media";
        const safeTitlePart = filesystemManager.sanitizeFilename(cleanTitleCandidate).substring(0, 80);
        const stagingTemplate = import_path7.default.join(stagingDir, `${this.item.id}__MF__${safeTitlePart}.%(ext)s`);
        const ffmpegLocation = ffmpegPath ? import_path7.default.dirname(ffmpegPath) : void 0;
        const searchTargets = [downloadTarget];
        const ytMatch = downloadTarget.match(/(?:v=|\/shorts\/|\/embed\/|youtu\.be\/|\/v\/|\/e\/)([\w-]{11})/);
        if (ytMatch && ytMatch[1]) {
          const vidSearch = `ytsearch1:${ytMatch[1]}`;
          if (!searchTargets.includes(vidSearch)) {
            searchTargets.push(vidSearch);
          }
        }
        const rawCandidateTitle = !isGenericTitle && this.item.title ? this.item.title : this.item.metadata?.title || "";
        const cleanT = rawCandidateTitle.replace(/\s*[-–]\s*.*$/, "").replace(/[\\/:*?"<>|]/g, "").replace(/\s+/g, " ").trim();
        const candidateArtist = this.item.metadata?.uploader || this.item.metadata?.channel || "";
        if (cleanT && cleanT.length > 2 && (isSpotify || this.item.isPlaylist || this.item.metadata?.isPlaylist || this.item.batchId || this.item.metadata?.batchId)) {
          const primaryArtist = candidateArtist.split(/[,;&/]|feat\.?|ft\.?/i)[0].trim();
          const strippedTitle = cleanT.replace(/\s*[\(\[][^\)\]]*[\)\]]/g, "").trim();
          const asciiTitle = cleanT.normalize("NFKD").replace(/[\u0300-\u036f]/g, "").replace(/[^\x20-\x7E]/g, " ").replace(/\s+/g, " ").trim();
          const asciiPrimary = primaryArtist.normalize("NFKD").replace(/[\u0300-\u036f]/g, "").replace(/[^\x20-\x7E]/g, " ").replace(/\s+/g, " ").trim();
          if (asciiPrimary) {
            const alt1 = `ytsearch1:${asciiTitle} ${asciiPrimary}`.trim();
            if (!searchTargets.includes(alt1)) searchTargets.push(alt1);
          }
          if (strippedTitle && strippedTitle.length > 2 && asciiPrimary) {
            const altStr = `ytsearch1:${strippedTitle} ${asciiPrimary}`.trim();
            if (!searchTargets.includes(altStr)) searchTargets.push(altStr);
          }
          if (candidateArtist && candidateArtist !== primaryArtist) {
            const alt2 = `ytsearch1:${asciiTitle} ${candidateArtist}`.trim();
            if (!searchTargets.includes(alt2)) searchTargets.push(alt2);
          }
          const alt3 = `ytsearch1:${asciiTitle} audio`.trim();
          if (!searchTargets.includes(alt3)) searchTargets.push(alt3);
          const alt4 = `ytsearch1:${asciiTitle}`.trim();
          if (!searchTargets.includes(alt4)) searchTargets.push(alt4);
          if (strippedTitle && strippedTitle.length > 2) {
            const alt5 = `ytsearch1:${strippedTitle}`.trim();
            if (!searchTargets.includes(alt5)) searchTargets.push(alt5);
          }
        }
        return new Promise((resolve, reject) => {
          const executeDownload = (targetIndex = 0) => {
            if (this.isCancelled) {
              this.cleanupStagingFiles(stagingDir, this.item.id);
              return reject({ isCancelled: true });
            }
            if (this.isPaused) {
              return reject({ isPaused: true });
            }
            const currentTarget = searchTargets[targetIndex];
            const args = this.buildYtDlpArgs(currentTarget, this.item.profile, stagingTemplate, ffmpegLocation);
            logger.info(`[DownloadJob] Starting download for item ${this.item.id}: ${currentTarget}`);
            logger.debug("[DownloadJob] yt-dlp args:", args);
            let stdoutBuf = "";
            let stderrBuf = "";
            let watchdogTimer;
            try {
              this.childProcess = (0, import_child_process3.spawn)(ytdlpPath, args, {
                windowsHide: true,
                stdio: ["ignore", "pipe", "pipe"]
              });
              try {
                if (this.childProcess.pid && typeof import_os7.default.setPriority === "function") {
                  import_os7.default.setPriority(this.childProcess.pid, import_os7.default.constants.priority.PRIORITY_BELOW_NORMAL);
                }
              } catch (_) {
              }
              watchdogTimer = setTimeout(() => {
                logger.warn(`[DownloadJob] Watchdog timeout (45s) for item ${this.item.id} on query "${currentTarget}". Terminating stalled process...`);
                if (this.childProcess) {
                  const pid = this.childProcess.pid;
                  if (process.platform === "win32" && pid) {
                    try {
                      const { exec } = require("child_process");
                      exec(`taskkill /pid ${pid} /T /F`, () => {
                      });
                    } catch (_) {
                      try {
                        this.childProcess.kill("SIGKILL");
                      } catch (_2) {
                      }
                    }
                  } else {
                    try {
                      this.childProcess.kill("SIGKILL");
                    } catch (_) {
                    }
                  }
                }
              }, 45e3);
              this.emitThrottledProgress({
                progress: 1,
                downloadedBytes: 0,
                totalBytes: 0,
                speed: "",
                eta: "",
                stageDescription: "Connecting to media server..."
              });
            } catch (err) {
              if (watchdogTimer) clearTimeout(watchdogTimer);
              return reject(classifyError(err, "Failed to launch yt-dlp"));
            }
            this.childProcess.stdout?.on("data", (chunk) => {
              const text = chunk.toString("utf-8");
              stdoutBuf += text;
              this.parseStdout(text);
            });
            this.childProcess.stderr?.on("data", (chunk) => {
              const text = chunk.toString("utf-8");
              stderrBuf += text;
              this.parseStderr(text);
            });
            this.childProcess.on("error", (err) => {
              if (watchdogTimer) clearTimeout(watchdogTimer);
              logger.error(`[DownloadJob] Process error for item [${this.item.id}]:`, err);
              reject(classifyError(err));
            });
            this.childProcess.on("close", async (code) => {
              if (watchdogTimer) {
                clearTimeout(watchdogTimer);
                watchdogTimer = void 0;
              }
              this.childProcess = void 0;
              if (this.isPaused) {
                logger.info(`[DownloadJob] Item ${this.item.id} paused.`);
                return reject({ isPaused: true });
              }
              if (this.isCancelled) {
                logger.info(`[DownloadJob] Item ${this.item.id} cancelled.`);
                this.cleanupStagingFiles(stagingDir, this.item.id);
                return reject({ isCancelled: true });
              }
              const stagingResult = this.findStagingFile(stagingDir, this.item.id);
              if (stagingResult && stagingResult.filePath) {
                try {
                  const finalized = await this.processAndFinalizeDownloadedFile(
                    stagingResult.filePath,
                    stagingDir,
                    targetDir,
                    ffmpegPath,
                    ffprobePath,
                    binDir,
                    stagingResult.extractedTitle
                  );
                  resolve(finalized);
                  return;
                } catch (finErr) {
                  this.cleanupStagingFiles(stagingDir, this.item.id);
                  reject(classifyError(finErr, "Failed to process downloaded file"));
                  return;
                }
              } else {
                if (targetIndex + 1 < searchTargets.length) {
                  this.cleanupStagingFiles(stagingDir, this.item.id);
                  logger.info(`[DownloadJob] Query "${currentTarget}" did not produce a file (exit: ${code}), trying fallback query "${searchTargets[targetIndex + 1]}" (${targetIndex + 2}/${searchTargets.length})...`);
                  return executeDownload(targetIndex + 1);
                }
                this.cleanupStagingFiles(stagingDir, this.item.id);
                const errorMsg = stderrBuf || (code === 0 ? "Downloaded file not found in staging folder." : `yt-dlp exited with code ${code}`);
                logger.warn(`yt-dlp failed after all queries: ${errorMsg}`);
                reject(classifyError(new Error(errorMsg), stderrBuf));
              }
            });
          };
          executeDownload(0);
        });
      }
      downloadDirectStream(streamUrl, stagingFile) {
        return new Promise((resolve, reject) => {
          const download = (targetUrl, redirectCount = 0) => {
            if (redirectCount > 5) return reject(new Error("Too many redirects"));
            const client = targetUrl.startsWith("https:") ? import_https3.default : import_http3.default;
            const req = client.get(targetUrl, {
              headers: {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                "Referer": "https://www.threads.net/"
              }
            }, (res) => {
              if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
                let nextUrl = res.headers.location;
                if (!nextUrl.startsWith("http")) {
                  try {
                    nextUrl = new URL(nextUrl, targetUrl).href;
                  } catch (_) {
                  }
                }
                return download(nextUrl, redirectCount + 1);
              }
              if (res.statusCode !== 200 && res.statusCode !== 206) {
                return reject(new Error(`Direct stream download failed with HTTP status ${res.statusCode}`));
              }
              const totalBytes = parseInt(res.headers["content-length"] || "0", 10);
              let downloaded = 0;
              const out = import_fs7.default.createWriteStream(stagingFile, { highWaterMark: 1024 * 1024 * 4 });
              let lastProgress = Date.now();
              let lastDownloaded = 0;
              res.on("data", (chunk) => {
                if (this.isCancelled) {
                  res.destroy();
                  out.close();
                  try {
                    import_fs7.default.unlinkSync(stagingFile);
                  } catch (_) {
                  }
                  return reject({ isCancelled: true });
                }
                if (this.isPaused) {
                  res.destroy();
                  out.close();
                  return reject({ isPaused: true });
                }
                downloaded += chunk.length;
                const now = Date.now();
                if (now - lastProgress > 250) {
                  const deltaBytes = downloaded - lastDownloaded;
                  const deltaTime = (now - lastProgress) / 1e3;
                  const speedBytesPerSec = deltaTime > 0 ? deltaBytes / deltaTime : 0;
                  const speedStr = (speedBytesPerSec / (1024 * 1024)).toFixed(1) + " MB/s";
                  const pct = totalBytes > 0 ? Math.min(90, Math.round(downloaded / totalBytes * 100)) : 50;
                  this.emitThrottledProgress({
                    progress: pct,
                    downloadedBytes: downloaded,
                    totalBytes,
                    speed: speedStr,
                    eta: "",
                    stageDescription: "Downloading video stream..."
                  });
                  lastProgress = now;
                  lastDownloaded = downloaded;
                }
              });
              res.pipe(out);
              out.on("finish", () => {
                out.close();
                this.activeHttpRequest = void 0;
                resolve({ filePath: stagingFile, totalBytes: downloaded });
              });
              out.on("error", (err) => {
                out.close();
                this.activeHttpRequest = void 0;
                try {
                  import_fs7.default.unlinkSync(stagingFile);
                } catch (_) {
                }
                reject(err);
              });
            });
            this.activeHttpRequest = req;
            req.on("error", (err) => {
              this.activeHttpRequest = void 0;
              try {
                import_fs7.default.unlinkSync(stagingFile);
              } catch (_) {
              }
              reject(err);
            });
          };
          download(streamUrl);
        });
      }
      async processAndFinalizeDownloadedFile(currentStagingFile, stagingDir, targetDir, ffmpegPath, ffprobePath, binDir, extractedTitle) {
        const stagingExt = import_path7.default.extname(currentStagingFile).replace(".", "").toLowerCase();
        let container = (this.item.profile?.container || "mp4").toLowerCase();
        const isAudioOnly = this.item.profile?.type === "audio" || ["mp3", "wav", "m4a", "flac", "aac", "ogg"].includes(container);
        const isVideoOnly = this.item.profile?.type === "video-only" || this.item.profile?.presetId === "video-only";
        let res = 1080;
        if (this.item.profile?.resolution && typeof this.item.profile.resolution === "number" && this.item.profile.resolution > 0) {
          res = this.item.profile.resolution;
        } else if (typeof this.item.profile?.presetId === "string" && this.item.profile.presetId.startsWith("res-")) {
          const parsed = parseInt(this.item.profile.presetId.replace("res-", ""), 10);
          if (!isNaN(parsed) && parsed > 0) res = parsed;
        }
        const isProRes = container === "mov" && (this.item.profile?.label?.includes("ProRes") || this.item.profile?.presetId?.includes("prores"));
        let probedVideoCodec = null;
        if (ffprobePath && !isAudioOnly) {
          probedVideoCodec = await this.probeVideoCodec(currentStagingFile, ffprobePath);
          logger.info(`[DownloadJob] Probed video stream codec: ${probedVideoCodec || "none/unknown"}`);
        }
        const isH264 = probedVideoCodec === "h264" || probedVideoCodec === "avc1";
        const appName = (this.item.projectContext?.application || "").toLowerCase();
        const isAfterEffects = appName.includes("aftereffects") || appName.includes("aeft") || appName.includes("ae");
        const isPremiere = (appName.includes("premiere") || appName.includes("ppro")) && !isAfterEffects;
        if (ffmpegPath && import_fs7.default.existsSync(ffmpegPath)) {
          const processedFile = import_path7.default.join(stagingDir, `proc_${Date.now()}_${this.item.id}.${container}`);
          let ffmpegArgs = [];
          if (isAudioOnly) {
            let targetBitrate = "320k";
            const pId = this.item.profile?.presetId || "";
            const pLbl = this.item.profile?.label || "";
            if (pId === "audio-mp3-128" || pLbl.includes("128")) targetBitrate = "128k";
            else if (pId === "audio-mp3-192" || pLbl.includes("192")) targetBitrate = "192k";
            else if (pId === "audio-mp3-96" || pLbl.includes("96")) targetBitrate = "96k";
            else if (pId === "audio-m4a" || pLbl.includes("256")) targetBitrate = "256k";
            else if (pId === "audio-mp3-320" || pLbl.includes("320")) targetBitrate = "320k";
            if (container === "wav") {
              ffmpegArgs = ["-y", "-i", currentStagingFile, "-vn", "-c:a", "pcm_s16le", "-ar", "48000", processedFile];
            } else if (container === "m4a" || container === "aac") {
              ffmpegArgs = ["-y", "-i", currentStagingFile, "-vn", "-c:a", "aac", "-b:a", targetBitrate, "-ar", "48000", processedFile];
            } else if (container === "flac") {
              ffmpegArgs = ["-y", "-i", currentStagingFile, "-vn", "-c:a", "flac", processedFile];
            } else if (container === "webm") {
              ffmpegArgs = ["-y", "-i", currentStagingFile, "-vn", "-c:a", "libopus", "-b:a", "160k", processedFile];
            } else {
              ffmpegArgs = ["-y", "-i", currentStagingFile, "-vn", "-c:a", "libmp3lame", "-b:a", targetBitrate, "-ar", "44100", processedFile];
            }
          } else if (isVideoOnly) {
            if (container === "webm") {
              if (stagingExt === "webm") {
                ffmpegArgs = ["-y", "-i", currentStagingFile, "-c:v", "copy", "-an", processedFile];
              } else {
                ffmpegArgs = ["-y", "-i", currentStagingFile, "-c:v", "libvpx-vp9", "-b:v", "0", "-crf", "24", "-an", processedFile];
              }
            } else if (container === "mkv") {
              if (stagingExt === "mkv") {
                ffmpegArgs = ["-y", "-i", currentStagingFile, "-c:v", "copy", "-an", processedFile];
              } else {
                ffmpegArgs = ["-y", "-i", currentStagingFile, "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "veryfast", "-crf", "20", "-an", processedFile];
              }
            } else if (container === "mov") {
              if (isH264) {
                ffmpegArgs = ["-y", "-i", currentStagingFile, "-c:v", "copy", "-an", "-movflags", "+faststart", processedFile];
              } else {
                ffmpegArgs = ["-y", "-i", currentStagingFile, "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "veryfast", "-crf", "20", "-an", "-movflags", "+faststart", processedFile];
              }
            } else {
              if (isH264 && stagingExt === "mp4") {
                ffmpegArgs = ["-y", "-i", currentStagingFile, "-c:v", "copy", "-an", "-movflags", "+faststart", processedFile];
              } else {
                ffmpegArgs = ["-y", "-i", currentStagingFile, "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "veryfast", "-crf", "20", "-an", "-movflags", "+faststart", processedFile];
              }
            }
          } else if (isProRes) {
            ffmpegArgs = [
              "-y",
              "-i",
              currentStagingFile,
              "-c:v",
              "prores_ks",
              "-profile:v",
              "3",
              "-pix_fmt",
              "yuv422p10le",
              "-c:a",
              "pcm_s16le",
              "-ar",
              "48000",
              processedFile
            ];
          } else if (container === "webm") {
            if (stagingExt === "webm") {
              ffmpegArgs = ["-y", "-i", currentStagingFile, "-c", "copy", processedFile];
            } else if (probedVideoCodec === "vp9" || probedVideoCodec === "vp8" || probedVideoCodec === "av01" || probedVideoCodec === "av1") {
              ffmpegArgs = ["-y", "-i", currentStagingFile, "-c:v", "copy", "-c:a", "libopus", "-b:a", "160k", processedFile];
            } else {
              ffmpegArgs = [
                "-y",
                "-i",
                currentStagingFile,
                "-c:v",
                "libvpx-vp9",
                "-b:v",
                "0",
                "-crf",
                "28",
                "-cpu-used",
                "4",
                "-row-mt",
                "1",
                "-c:a",
                "libopus",
                "-b:a",
                "160k",
                processedFile
              ];
            }
          } else if (container === "mkv") {
            if (stagingExt === "mkv") {
              ffmpegArgs = ["-y", "-i", currentStagingFile, "-c", "copy", processedFile];
            } else {
              ffmpegArgs = [
                "-y",
                "-i",
                currentStagingFile,
                ...getOptimalEncoderArgs(ffmpegPath),
                "-pix_fmt",
                "yuv420p",
                "-c:a",
                "aac",
                "-b:a",
                "320k",
                "-ar",
                "48000",
                processedFile
              ];
            }
          } else if (container === "mov") {
            if (isH264 && (stagingExt === "mov" || stagingExt === "mp4")) {
              ffmpegArgs = [
                "-y",
                "-i",
                currentStagingFile,
                "-c:v",
                "copy",
                "-c:a",
                "aac",
                "-b:a",
                "320k",
                "-ar",
                "48000",
                "-movflags",
                "+faststart",
                processedFile
              ];
            } else if (isH264) {
              ffmpegArgs = [
                "-y",
                "-i",
                currentStagingFile,
                "-c:v",
                "copy",
                "-c:a",
                "aac",
                "-b:a",
                "320k",
                "-ar",
                "48000",
                "-af",
                "aresample=async=1000:first_pts=0",
                "-movflags",
                "+faststart",
                processedFile
              ];
            } else {
              ffmpegArgs = [
                "-y",
                "-hwaccel",
                "auto",
                "-threads",
                "0",
                "-i",
                currentStagingFile,
                ...getOptimalEncoderArgs(ffmpegPath),
                "-pix_fmt",
                "yuv420p",
                "-map",
                "0:v:0",
                "-map",
                "0:a?",
                "-c:a",
                "aac",
                "-b:a",
                "320k",
                "-ar",
                "48000",
                "-movflags",
                "+faststart",
                processedFile
              ];
            }
          } else {
            if (isH264 && (stagingExt === "mp4" || stagingExt === "mov") && container === "mp4") {
              ffmpegArgs = [
                "-y",
                "-i",
                currentStagingFile,
                "-c",
                "copy",
                "-movflags",
                "+faststart",
                processedFile
              ];
            } else {
              ffmpegArgs = [
                "-y",
                "-hwaccel",
                "auto",
                "-threads",
                "0",
                "-i",
                currentStagingFile,
                ...getOptimalEncoderArgs(ffmpegPath),
                "-pix_fmt",
                "yuv420p",
                "-map",
                "0:v:0",
                "-map",
                "0:a?",
                "-c:a",
                "aac",
                "-b:a",
                "320k",
                "-ar",
                "48000",
                "-movflags",
                "+faststart",
                processedFile
              ];
            }
          }
          try {
            this.emitThrottledProgress({
              progress: 92,
              downloadedBytes: this.item.downloadedBytes || 0,
              totalBytes: this.item.totalBytes || 0,
              speed: "",
              eta: "Finalizing...",
              stageDescription: `Processing & optimizing ${container.toUpperCase()} for Adobe...`
            });
            logger.info(`[DownloadJob] Transcoding with FFmpeg: ${ffmpegArgs.join(" ")}`);
            await new Promise((resFf) => {
              const ffProc = (0, import_child_process3.spawn)(ffmpegPath, ffmpegArgs, { windowsHide: true });
              try {
                if (ffProc.pid && typeof import_os7.default.setPriority === "function") {
                  import_os7.default.setPriority(ffProc.pid, import_os7.default.constants.priority.PRIORITY_BELOW_NORMAL);
                }
              } catch (_) {
              }
              let ffErr = "";
              ffProc.stderr?.on("data", (chunk) => {
                const text = chunk.toString();
                ffErr = (ffErr + text).slice(-1500);
                const timeMatch = text.match(/time=(\d+):(\d+):(\d+\.\d+)/);
                const speedMatch = text.match(/speed=\s*([\d\.]+x)/);
                const fpsMatch = text.match(/fps=\s*([\d\.]+)/);
                if (timeMatch) {
                  const curSec = parseFloat(timeMatch[1]) * 3600 + parseFloat(timeMatch[2]) * 60 + parseFloat(timeMatch[3]);
                  const durSec = this.item.duration || 0;
                  let pct = 92;
                  if (durSec > 0) {
                    pct = Math.min(99, Math.max(91, 91 + Math.round(curSec / durSec * 8)));
                  }
                  const spd = speedMatch ? speedMatch[1] : fpsMatch ? `${fpsMatch[1]} fps` : "";
                  const resTag = res >= 2160 ? "4K" : res >= 1440 ? "2K" : res >= 1080 ? "Full HD" : res >= 720 ? "720p HD" : "video";
                  this.emitThrottledProgress({
                    progress: pct,
                    downloadedBytes: this.item.downloadedBytes || 0,
                    totalBytes: this.item.totalBytes || 0,
                    speed: spd ? `Optimizing at ${spd}` : "",
                    eta: "Almost ready...",
                    stageDescription: `Optimizing ${resTag} stream for Adobe timeline (${pct}%)...`
                  });
                }
              });
              ffProc.on("close", (code) => {
                if (code === 0) resFf();
                else {
                  logger.warn(`FFmpeg exit code ${code}: ${ffErr.slice(-300)}`);
                  resFf();
                }
              });
              ffProc.on("error", (err) => {
                logger.warn("FFmpeg spawn notice:", err);
                resFf();
              });
            });
            if (import_fs7.default.existsSync(processedFile) && import_fs7.default.statSync(processedFile).size > 1e3) {
              try {
                import_fs7.default.unlinkSync(currentStagingFile);
              } catch (_) {
              }
              currentStagingFile = processedFile;
            }
          } catch (ffmpegErr) {
            logger.warn("[DownloadJob] FFmpeg processing notice:", ffmpegErr);
          }
        }
        const ext = this.getContainerExtension(this.item.profile || {});
        let finalName = "";
        if (this.item.profile?.customFilename && this.item.profile.customFilename.trim().length > 0) {
          const customClean = filesystemManager.sanitizeFilename(this.item.profile.customFilename.trim());
          finalName = customClean + "." + ext;
          this.item.title = customClean;
        } else {
          const curTitle = (this.item.title || "").trim();
          const curIsGeneric = !curTitle || curTitle === "Fetching media info..." || /^video by /i.test(curTitle) || /^post by /i.test(curTitle) || curTitle.toLowerCase() === "media";
          const extTitle = (extractedTitle || "").trim();
          const extIsGeneric = !extTitle || /^video by /i.test(extTitle) || /^post by /i.test(extTitle) || extTitle.toLowerCase() === "media";
          const metaTitle = (this.item.metadata?.title || "").trim();
          const metaIsGeneric = !metaTitle || metaTitle === "Fetching media info..." || /^video by /i.test(metaTitle) || /^post by /i.test(metaTitle) || metaTitle.toLowerCase() === "media";
          let chosenTitle = "MediaFetch_Media";
          if (!metaIsGeneric) {
            chosenTitle = metaTitle;
          } else if (!curIsGeneric) {
            chosenTitle = curTitle;
          } else if (!extIsGeneric) {
            chosenTitle = extTitle;
          } else if (metaTitle && metaTitle !== "Fetching media info...") {
            chosenTitle = metaTitle.replace(/^video by /i, "Clip - ").trim();
          } else if (curTitle && curTitle !== "Fetching media info...") {
            chosenTitle = curTitle.replace(/^video by /i, "Clip - ").trim();
          } else if (extTitle) {
            chosenTitle = extTitle.replace(/^video by /i, "Clip - ").trim();
          }
          const cleanChosen = filesystemManager.sanitizeFilename(chosenTitle);
          finalName = cleanChosen + "." + ext;
          this.item.title = cleanChosen;
        }
        const effectiveTargetDir = this.resolveFinalTargetDir(targetDir, ext, this.item.profile?.type);
        const finalized = filesystemManager.finalizeDownloadedFile(currentStagingFile, effectiveTargetDir, finalName);
        this.item.downloadedPath = finalized.finalPath;
        this.cleanupStagingFiles(stagingDir, this.item.id);
        return finalized;
      }
      resolveFinalTargetDir(baseTargetDir, ext, profileType) {
        if (this.item.zipPackage || this.item.metadata?.zipPackage) {
          if (baseTargetDir) {
            filesystemManager.ensureDirExists(baseTargetDir);
            return baseTargetDir;
          }
        }
        const isPlaylistOrCustom = Boolean(
          this.item.metadata?.isPlaylist || this.item.metadata?.subFolderName || this.item.metadata?.customFolderName || this.item.metadata?.playlistTitle || this.item.targetFolder && this.item.targetFolder !== filesystemManager.resolveTargetDirectory().targetDir
        );
        if (isPlaylistOrCustom && baseTargetDir) {
          filesystemManager.ensureDirExists(baseTargetDir);
          return baseTargetDir;
        }
        let root = baseTargetDir || filesystemManager.resolveTargetDirectory().targetDir;
        root = root.replace(/[\/\\]+$/, "");
        if (/[\/\\](?:LinkMediaFetch|SerachMediafetch)$/i.test(root)) {
          root = import_path7.default.dirname(root);
        }
        if (!/[\/\\]MediaFetch$/i.test(root) && import_path7.default.basename(root).toLowerCase() !== "mediafetch") {
          root = import_path7.default.join(root, "MediaFetch");
        }
        const cleanExt = (ext || "").toLowerCase().replace(/^\./, "").split("?")[0];
        const isAudio = profileType === "audio" || ["mp3", "wav", "m4a", "flac", "aac", "ogg", "opus", "aiff", "m4p"].includes(cleanExt);
        const isImage = profileType === "image" || ["jpg", "jpeg", "png", "webp", "gif", "bmp", "svg", "tiff", "tif", "ico"].includes(cleanExt);
        const subType = isAudio ? "Audio" : isImage ? "Image" : "Video";
        const finalDir = import_path7.default.join(root, "LinkMediaFetch", subType);
        filesystemManager.ensureDirExists(finalDir);
        return finalDir;
      }
      pause() {
        this.isPaused = true;
        this.killProcess();
      }
      cancel() {
        this.isCancelled = true;
        this.killProcess();
      }
      killProcess() {
        if (this.activeHttpRequest) {
          try {
            this.activeHttpRequest.destroy();
            this.activeHttpRequest = void 0;
          } catch (_) {
          }
        }
        if (this.childProcess) {
          try {
            if (process.platform === "win32") {
              try {
                (0, import_child_process3.spawn)("taskkill", ["/pid", String(this.childProcess.pid), "/f", "/t"], { windowsHide: true });
              } catch (_) {
              }
              try {
                this.childProcess.kill("SIGKILL");
              } catch (_) {
              }
            } else {
              this.childProcess.kill("SIGKILL");
            }
          } catch (err) {
            logger.warn(`[DownloadJob] Kill error for [${this.item.id}]:`, err);
          }
        }
      }
      async probeVideoCodec(filePath, ffprobePath) {
        if (!ffprobePath || !import_fs7.default.existsSync(ffprobePath) || !import_fs7.default.existsSync(filePath)) {
          return null;
        }
        try {
          const { stdout } = await execFileAsync3(ffprobePath, [
            "-v",
            "error",
            "-select_streams",
            "v:0",
            "-show_entries",
            "stream=codec_name",
            "-of",
            "default=noprint_wrappers=1:nokey=1",
            filePath
          ], { windowsHide: true });
          return (stdout || "").trim().toLowerCase();
        } catch (err) {
          logger.warn("[DownloadJob] ffprobe probe notice:", err);
          return null;
        }
      }
      parseStdout(data) {
        if (this.isPaused || this.isCancelled) return;
        const lines = data.split(/\r?\n/);
        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed) continue;
          if (trimmed.startsWith("MF_TITLE:")) {
            const t = trimmed.substring("MF_TITLE:".length).trim();
            const isGeneric = !t || /^video by /i.test(t) || /^post by /i.test(t) || /^tweet by /i.test(t) || t.toLowerCase() === "media";
            if (t && t.length > 0 && !isGeneric && (this.item.title === "Fetching media info..." || !this.item.title || /^video by /i.test(this.item.title))) {
              this.item.title = t;
              this.onProgressCb?.({
                progress: this.item.progress || 0,
                downloadedBytes: this.item.downloadedBytes || 0,
                totalBytes: this.item.totalBytes || 0,
                speed: this.item.speed || "",
                eta: this.item.eta || "",
                stageDescription: "Starting download..."
              });
            }
          } else if (trimmed.startsWith("[download] Destination:") || trimmed.startsWith("[download] Got destination:")) {
            const destMatch = trimmed.match(/__MF__(.*?)\.[a-zA-Z0-9]+$/);
            if (destMatch && destMatch[1] && (this.item.title === "Fetching media info..." || !this.item.title)) {
              const dt = destMatch[1].trim();
              if (!/^video by /i.test(dt) && !/^post by /i.test(dt)) {
                this.item.title = dt;
              }
            }
          } else if (trimmed.startsWith("MF_PROGRESS:")) {
            const parts = trimmed.substring("MF_PROGRESS:".length).split("|");
            if (parts.length >= 5) {
              const rawPercent = parts[0].replace("%", "").trim();
              const percent = parseFloat(rawPercent) || 0;
              const downloadedStr = parts[1].trim();
              const totalStr = parts[2].trim();
              const speedStr = parts[3].trim();
              const etaStr = parts[4].trim();
              const downloadedBytes = this.parseBytes(downloadedStr);
              const totalBytes = this.parseBytes(totalStr);
              this.emitThrottledProgress({
                progress: Math.min(90, Math.max(0, percent)),
                downloadedBytes,
                totalBytes,
                speed: speedStr || "",
                eta: etaStr || "",
                stageDescription: "Downloading high-quality media stream..."
              });
            }
          } else if (trimmed.includes("[Merger]") || trimmed.includes("[ExtractAudio]") || trimmed.includes("[FixupM3u8]")) {
            this.emitThrottledProgress({
              progress: 91,
              downloadedBytes: this.item.downloadedBytes || 0,
              totalBytes: this.item.totalBytes || 0,
              speed: "",
              eta: "Finalizing...",
              stageDescription: "Merging audio and video streams (almost ready)..."
            });
          }
        }
      }
      parseStderr(data) {
        if (this.isPaused || this.isCancelled) return;
        if (data.includes("[Merger]") || data.includes("[ExtractAudio]") || data.includes("Post-process")) {
          this.emitThrottledProgress({
            progress: 91,
            downloadedBytes: this.item.downloadedBytes || 0,
            totalBytes: this.item.totalBytes || 0,
            speed: "",
            eta: "Finalizing...",
            stageDescription: "Processing & remuxing with FFmpeg (almost ready)..."
          });
          return;
        }
        if (data.includes("Opening") || data.includes("Press [q]") || data.includes("Metadata:") || data.includes("Stream #")) {
          this.emitThrottledProgress({
            progress: Math.max(3, this.item.progress || 0),
            downloadedBytes: this.item.downloadedBytes || 0,
            totalBytes: this.item.totalBytes || 0,
            speed: "",
            eta: "",
            stageDescription: "Seeking media server stream..."
          });
        }
        const timeMatch = data.match(/time=\s*([\d\.:]+)/);
        const sizeMatch = data.match(/size=\s*(\d+)\s*[kK]i?B/);
        const speedMatch = data.match(/speed=\s*([\d\.]+)x/);
        if (timeMatch) {
          const sizeKb = sizeMatch ? parseInt(sizeMatch[1], 10) : 0;
          const downloadedBytes = sizeKb * 1024;
          const speedStr = speedMatch ? `${speedMatch[1]}x` : "";
          let pct = 50;
          if (this.item.profile?.timeRange) {
            const tr = this.item.profile.timeRange;
            const s = this.parseTimeToSeconds(tr.start);
            const e = this.parseTimeToSeconds(tr.end);
            const dur = e > s ? e - s : 0;
            const cur = this.parseTimeToSeconds(timeMatch[1]);
            if (dur > 0) {
              pct = Math.min(95, Math.max(5, Math.round(cur / dur * 100)));
            }
          }
          this.emitThrottledProgress({
            progress: pct,
            downloadedBytes: downloadedBytes > 0 ? downloadedBytes : this.item.downloadedBytes || 0,
            totalBytes: this.item.totalBytes || 0,
            speed: speedStr,
            eta: "",
            stageDescription: `Downloading trimmed stream (${pct}%)...`
          });
        }
      }
      emitThrottledProgress(update) {
        if (this.isPaused || this.isCancelled) return;
        const now = Date.now();
        if (now - this.lastProgressEmit >= this.throttleMs) {
          this.lastProgressEmit = now;
          this.onProgressCb?.(update);
        }
      }
      parseBytes(str) {
        if (!str || str === "N/A" || str === "Unknown") return 0;
        const match = str.match(/([\d\.]+)\s*([KMGTP]?i?B)/i);
        if (!match) return 0;
        const num = parseFloat(match[1]);
        const unit = match[2].toUpperCase();
        const multipliers = {
          "B": 1,
          "KB": 1024,
          "KIB": 1024,
          "MB": 1024 * 1024,
          "MIB": 1024 * 1024,
          "GB": 1024 * 1024 * 1024,
          "GIB": 1024 * 1024 * 1024,
          "TB": 1024 * 1024 * 1024 * 1024
        };
        return Math.round(num * (multipliers[unit] || 1));
      }
      parseTimeToSeconds(val) {
        if (!val) return 0;
        const clean = String(val).trim();
        if (!clean) return 0;
        const parts = clean.split(":").map((p) => parseFloat(p.trim()) || 0);
        if (parts.length >= 3) {
          let sec = parts[0] * 3600 + parts[1] * 60 + parts[2];
          if (parts.length >= 4) sec += parts[3] / 30;
          return sec;
        } else if (parts.length === 2) {
          return parts[0] * 60 + parts[1];
        } else if (parts.length === 1) {
          return parts[0];
        }
        return 0;
      }
      normalizeTime(val, fallback = "00:00:00") {
        if (!val) return fallback;
        const clean = String(val).trim();
        if (!clean) return fallback;
        let totalSec = this.parseTimeToSeconds(clean);
        if (isNaN(totalSec) || totalSec < 0) totalSec = 0;
        const h = Math.floor(totalSec / 3600);
        const m = Math.floor(totalSec % 3600 / 60);
        const s = Math.floor(totalSec % 60);
        const frac = totalSec - Math.floor(totalSec);
        const fracStr = frac > 0 ? "." + Math.round(frac * 1e3).toString().padStart(3, "0") : "";
        return `${h.toString().padStart(2, "0")}:${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}${fracStr}`;
      }
      getContainerExtension(profile) {
        const c = (profile.container || "").toLowerCase();
        if (c) {
          return c;
        }
        if (profile.type === "audio") {
          if (profile.presetId === "audio-wav") return "wav";
          if (profile.presetId === "audio-m4a") return "m4a";
          if (profile.presetId === "audio-flac") return "flac";
          return "mp3";
        }
        return "mp4";
      }
      findStagingFile(stagingDir, downloadId) {
        if (!import_fs7.default.existsSync(stagingDir)) return null;
        const files = import_fs7.default.readdirSync(stagingDir);
        const found = files.find((f) => f.startsWith(downloadId) && !f.endsWith(".part") && !f.endsWith(".ytdl") && !f.endsWith(".temp"));
        if (!found) return null;
        let extractedTitle;
        if (found.includes("__MF__")) {
          const parts = found.split("__MF__");
          if (parts.length > 1) {
            extractedTitle = import_path7.default.parse(parts[1]).name;
          }
        }
        return {
          filePath: import_path7.default.join(stagingDir, found),
          extractedTitle
        };
      }
      cleanupStagingFiles(stagingDir, downloadId) {
        try {
          if (!import_fs7.default.existsSync(stagingDir)) return;
          const files = import_fs7.default.readdirSync(stagingDir);
          const now = Date.now();
          for (const f of files) {
            const fullPath = import_path7.default.join(stagingDir, f);
            if (downloadId && f.startsWith(downloadId)) {
              try {
                import_fs7.default.unlinkSync(fullPath);
              } catch (e) {
              }
            } else {
              try {
                const stat = import_fs7.default.statSync(fullPath);
                if (now - stat.mtimeMs > 3600 * 1e3) {
                  import_fs7.default.unlinkSync(fullPath);
                }
              } catch (_) {
              }
            }
          }
          try {
            const remaining = import_fs7.default.readdirSync(stagingDir);
            if (remaining.length === 0) {
              import_fs7.default.rmdirSync(stagingDir);
            }
          } catch (_) {
          }
        } catch (e) {
        }
      }
      buildYtDlpArgs(url, profile, outputTemplate, ffmpegBinDir) {
        const cleanUrl = url.trim();
        const isYouTube = youtubeTokenManager.isYouTubeUrl(cleanUrl);
        const isSearchQuery = cleanUrl.startsWith("ytsearch");
        const cacheDir = import_path7.default.join(process.env.LOCALAPPDATA || process.env.APPDATA || import_os7.default.tmpdir(), "MediaFetch", ".cache");
        const nodeBin = dependencyManager.getNodeExecutablePath();
        const jsRuntime = nodeBin === "node" ? "node" : `node:${nodeBin}`;
        const args = [
          "--newline",
          "--continue",
          "--no-playlist",
          "--no-check-certificates",
          "--no-mtime",
          "--cache-dir",
          cacheDir,
          "--js-runtimes",
          jsRuntime,
          ...isYouTube ? ["--remote-components", "ejs:github", "--extractor-args", "youtube:player_client=web_embedded,android"] : [],
          ...isSearchQuery ? ["--max-downloads", "1", "-i"] : [],
          "--progress-template",
          "MF_PROGRESS:%(progress._percent_str)s|%(progress._downloaded_bytes_str)s|%(progress._total_bytes_str|progress._total_bytes_estimate_str)s|%(progress._speed_str)s|%(progress._eta_str)s",
          "--print",
          "pre_process:MF_TITLE:%(title)s",
          "--no-simulate",
          "--retries",
          "10",
          "--fragment-retries",
          "20",
          "--file-access-retries",
          "5",
          "--buffer-size",
          "16M",
          "--http-chunk-size",
          "10M",
          "--concurrent-fragments",
          "8",
          "--socket-timeout",
          "30",
          "-o",
          outputTemplate
        ];
        if (ffmpegBinDir) {
          args.push("--ffmpeg-location", ffmpegBinDir);
        }
        if (profile.timeRange && (profile.timeRange.start || profile.timeRange.end)) {
          let start = this.normalizeTime(profile.timeRange.start, "00:00:00");
          let end = this.normalizeTime(profile.timeRange.end, "99:59:59");
          const startSec = this.parseTimeToSeconds(start);
          const endSec = this.parseTimeToSeconds(end);
          if (endSec > 0 && startSec > endSec) {
            const tmp = start;
            start = end;
            end = tmp;
          }
          args.push("--download-sections", `*${start}-${end}`);
          args.push("--downloader-args", "ffmpeg_i:-seekable 1 -reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5");
          args.push("--downloader-args", "ffmpeg:-c copy");
        } else {
          args.push("--downloader-args", "ffmpeg_i:-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5");
        }
        const localAppData = process.env.LOCALAPPDATA || (import_os7.default.homedir ? import_path7.default.join(import_os7.default.homedir(), "AppData", "Local") : "");
        const cookiesFilePath = localAppData ? import_path7.default.join(localAppData, "MediaFetch", "cookies.txt") : "";
        if (cookiesFilePath && import_fs7.default.existsSync(cookiesFilePath) && import_fs7.default.statSync(cookiesFilePath).size > 10) {
          args.push("--cookies", cookiesFilePath);
        } else {
          const cookiesBrowser = settingsManager.getSettings()?.engine?.cookiesBrowser || "none";
          if (cookiesBrowser && cookiesBrowser !== "none") {
            args.push("--cookies-from-browser", cookiesBrowser);
          }
        }
        const container = (profile.container || "mp4").toLowerCase();
        const isExplicitVideo = ["mp4", "mov", "mkv", "webm", "avi"].includes(container);
        const isAudio = !isExplicitVideo && (profile.type === "audio" || ["mp3", "wav", "m4a", "flac", "aac", "ogg"].includes(container));
        const isVideoOnly = profile.type === "video-only" || profile.presetId === "video-only";
        let res = 1080;
        if (profile.resolution && typeof profile.resolution === "number" && profile.resolution > 0) {
          res = profile.resolution;
        } else if (profile.presetId === "video-4k" || profile.presetId === "res-2160") {
          res = 2160;
        } else if (profile.presetId === "video-1440p" || profile.presetId === "res-1440") {
          res = 1440;
        } else if (profile.presetId === "video-1080p" || profile.presetId === "res-1080") {
          res = 1080;
        } else if (profile.presetId === "video-720p" || profile.presetId === "res-720") {
          res = 720;
        } else if (profile.presetId === "video-480p" || profile.presetId === "res-480") {
          res = 480;
        } else if (profile.presetId === "video-360p" || profile.presetId === "res-360") {
          res = 360;
        } else if (profile.presetId === "best-available" || profile.presetId === "video-only") {
          res = 9999;
        } else if (typeof profile.presetId === "string" && profile.presetId.startsWith("res-")) {
          const parsed = parseInt(profile.presetId.replace("res-", ""), 10);
          if (!isNaN(parsed) && parsed > 0) res = parsed;
        }
        if (profile.customFormatId) {
          args.push("-f", profile.customFormatId);
        } else if (isAudio) {
          let targetFormat = container === "wav" || container === "m4a" || container === "flac" ? container : "mp3";
          let targetQuality = "0";
          const pId = profile.presetId || "";
          const pLbl = profile.label || "";
          if (pId === "audio-mp3-128" || pLbl.includes("128")) targetQuality = "128K";
          else if (pId === "audio-mp3-192" || pLbl.includes("192")) targetQuality = "192K";
          else if (pId === "audio-mp3-96" || pLbl.includes("96")) targetQuality = "96K";
          else if (pId === "audio-mp3-320" || pLbl.includes("320")) targetQuality = "320K";
          if (container === "webm") {
            args.push("-f", "bestaudio[ext=webm]/bestaudio[acodec=opus]/bestaudio/best", "-x");
          } else {
            args.push(
              "-f",
              "bestaudio/best",
              "-x",
              "--audio-format",
              targetFormat,
              "--audio-quality",
              targetQuality
            );
          }
        } else if (isVideoOnly) {
          const hasTimeRange = Boolean(profile.timeRange && (profile.timeRange.start || profile.timeRange.end));
          if (container === "webm") {
            const fStr = res >= 9999 ? "bestvideo[ext=webm]/bestvideo[vcodec^=vp]/bestvideo/best" : `bestvideo[height<=?${res}][ext=webm]/bestvideo[height<=?${res}][vcodec^=vp]/bestvideo[height<=?${res}]/bestvideo/best`;
            args.push("-f", fStr);
          } else if (hasTimeRange) {
            const maxH = res < 9999 ? res : 1080;
            const fStr = `bestvideo[height<=?${maxH}][protocol^=m3u8]/bestvideo[height<=?${maxH}][vcodec^=avc1]/bestvideo[height<=?${maxH}][vcodec^=h264]/bestvideo[height<=?${maxH}][ext=mp4][vcodec!*=av01]/bestvideo[height<=?${maxH}]/best`;
            args.push("-f", fStr);
          } else if (res >= 1440) {
            const fStr = res >= 9999 ? "bestvideo[vcodec^=av01]/bestvideo[vcodec^=vp9]/bestvideo/best" : res >= 4320 ? "bestvideo[height<=4320][vcodec^=av01]/bestvideo[height<=4320][vcodec^=vp9]/bestvideo[height<=4320]/best" : res >= 2160 ? "bestvideo[height<=2160][vcodec^=av01]/bestvideo[height<=2160][vcodec^=vp9]/bestvideo[height<=2160]/best" : "bestvideo[height<=1440][vcodec^=av01]/bestvideo[height<=1440][vcodec^=vp9]/bestvideo[height<=1440]/best";
            args.push("-f", fStr);
          } else {
            const fStr = `bestvideo[height<=?${res}][vcodec^=avc1]/bestvideo[height<=?${res}][vcodec^=h264]/bestvideo[height<=?${res}][ext=mp4][vcodec!*=av01]/bestvideo[height<=?${res}]/best`;
            args.push("-f", fStr);
          }
        } else {
          const hasTimeRange = Boolean(profile.timeRange && (profile.timeRange.start || profile.timeRange.end));
          if (container === "webm") {
            const fStr = res >= 9999 ? "bestvideo[ext=webm]+bestaudio[ext=webm]/bestvideo[vcodec^=vp]+bestaudio[acodec^=opus]/bestvideo+bestaudio/best" : `bestvideo[height<=?${res}][ext=webm]+bestaudio[ext=webm]/bestvideo[height<=?${res}][vcodec^=vp]+bestaudio[acodec^=opus]/bestvideo[height<=?${res}]+bestaudio/bestvideo+bestaudio/best`;
            args.push("-f", fStr);
          } else if (hasTimeRange) {
            const maxH = res < 9999 ? res : 1080;
            const fStr = `bestvideo[height<=?${maxH}][protocol^=m3u8]+bestaudio[protocol^=m3u8]/bestvideo[height<=?${maxH}][vcodec^=avc1]+bestaudio[ext=m4a]/bestvideo[height<=?${maxH}][vcodec^=h264]+bestaudio[ext=m4a]/bestvideo[height<=?${maxH}][ext=mp4][vcodec!*=av01]+bestaudio[ext=m4a]/bestvideo[height<=?${maxH}]+bestaudio/best`;
            args.push("-f", fStr);
          } else if (res >= 1440) {
            const fStr = res >= 9999 ? "bestvideo[vcodec^=av01]+bestaudio[ext=m4a]/bestvideo[vcodec^=vp9]+bestaudio[ext=m4a]/bestvideo+bestaudio[ext=m4a]/bestvideo[vcodec^=av01]+bestaudio/bestvideo[vcodec^=vp9]+bestaudio/bestvideo+bestaudio/best" : `bestvideo[height<=?${res}][vcodec^=av01]+bestaudio[ext=m4a]/bestvideo[height<=?${res}][vcodec^=vp9]+bestaudio[ext=m4a]/bestvideo[height<=?${res}]+bestaudio[ext=m4a]/bestvideo[height<=?${res}][vcodec^=av01]+bestaudio/bestvideo[height<=?${res}][vcodec^=vp9]+bestaudio/bestvideo[height<=?${res}]+bestaudio/best`;
            args.push("-f", fStr);
          } else {
            const fStr = `bestvideo[height<=?${res}][vcodec^=avc1]+bestaudio[ext=m4a]/bestvideo[height<=?${res}][vcodec^=h264]+bestaudio[ext=m4a]/bestvideo[height<=?${res}][ext=mp4][vcodec!*=av01]+bestaudio[ext=m4a]/bestvideo[height<=?${res}]+bestaudio[ext=m4a]/bestvideo[height<=?${res}]+bestaudio/best[height<=?${res}]/best`;
            args.push("-f", fStr);
          }
        }
        if (!isAudio && ["mp4", "mkv", "webm", "mov"].includes(container)) {
          if (container === "mov") {
            args.push("--merge-output-format", "mkv");
          } else {
            args.push("--merge-output-format", container);
          }
        }
        args.push(cleanUrl);
        return args;
      }
    };
  }
});

// service/retry.js
function _0x38d8(_0x27a9fa, _0x549935) {
  _0x27a9fa = _0x27a9fa - (7 * 824 + -2 * 3595 + 1594);
  const _0x2c0448 = _0x43ad();
  let _0x27d528 = _0x2c0448[_0x27a9fa];
  if (_0x38d8["GVsutY"] === void 0) {
    var _0x1a4817 = function(_0x54fe9d) {
      const _0x566690 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      let _0x3647a9 = "", _0x1ef9d4 = "";
      for (let _0x195ad7 = 9977 * -1 + -4311 + 188 * 76, _0x1e6501, _0x21d0a7, _0x2c49ab = -4653 + -801 * 11 + -33 * -408; _0x21d0a7 = _0x54fe9d["charAt"](_0x2c49ab++); ~_0x21d0a7 && (_0x1e6501 = _0x195ad7 % (-3524 + -44 * 143 + -491 * -20) ? _0x1e6501 * (6 * -1021 + -6609 + 12799) + _0x21d0a7 : _0x21d0a7, _0x195ad7++ % (6 * 526 + -4342 + -1 * -1190)) ? _0x3647a9 += String["fromCharCode"](-297 + 1655 + -1103 & _0x1e6501 >> (-(750 + 4197 * -1 + 1 * 3449) * _0x195ad7 & -2 * 4022 + -3354 * -1 + 2348 * 2)) : 553 * -11 + 1657 * 1 + -4426 * -1) {
        _0x21d0a7 = _0x566690["indexOf"](_0x21d0a7);
      }
      for (let _0x95b966 = 2 * 3871 + -5422 + 145 * -16, _0x5d2acd = _0x3647a9["length"]; _0x95b966 < _0x5d2acd; _0x95b966++) {
        _0x1ef9d4 += "%" + ("00" + _0x3647a9["charCodeAt"](_0x95b966)["toString"](-1 * 4948 + -7868 + 12832))["slice"](-(2692 + -115 * 35 + 1335));
      }
      return decodeURIComponent(_0x1ef9d4);
    };
    _0x38d8["CeyUGR"] = _0x1a4817, _0x38d8["gVGLFj"] = {}, _0x38d8["GVsutY"] = !![];
  }
  const _0x16a38d = _0x2c0448[-3958 + -4229 + 8187];
  _0x38d8["mbISRr"] !== _0x16a38d && (_0x38d8["gVGLFj"] = {}, _0x38d8["mbISRr"] = _0x16a38d);
  const _0x2f2e6c = _0x38d8["gVGLFj"][_0x27a9fa];
  return _0x2f2e6c === void 0 ? (_0x27d528 = _0x38d8["CeyUGR"](_0x27d528), _0x38d8["gVGLFj"][_0x27a9fa] = _0x27d528) : _0x27d528 = _0x2f2e6c, _0x27d528;
}
function _0x43ad() {
  const _0x233cc4 = ["zwXHEq", "y2XLyxjbBgW", "sxPLEKC", "Bwf4uMv0CMLLCW", "C2HVDwXKuMv0CG", "Dhj5", "C2v0", "u2nOzwr1BgLUzW", "CMv0CNLdB3vUDa", "Cg93", "ihjLDhj5icm", "qMnvBfi", "BwLU", "mtKWmZGXmMLLAvDVua", "mJeXnMfXzNfKDG", "mtu5nJyZmfnkA1bpvq", "BhbWChe", "BxmUlI4", "igzVCIbPDgvTia", "mtK0odHiCwLhEKy", "ovrZwfrHDq", "zhvSzwrszxrYEq", "CMfUzg9T", "zgvSzxrL", "ywn0AxzLvgLTzq", "CM91BMq", "xsbPBIa", "mtu2nufvyvrOva", "nJK2nteZmermu1zwvG", "C2nOzwr1Bgvszq", "mtGWnJy5nKHbwujSvq", "mJy1nti4sLDQAKTd", "ntHdBhfoz2u", "CwPXvNa", "ExPfBxO", "y2fUy2vSu2nOzq", "y2fSy3vSyxrLra"];
  _0x43ad = function() {
    return _0x233cc4;
  };
  return _0x43ad();
}
var _0x41542e, RetryManager, retryManager;
var init_retry = __esm({
  "service/retry.js"() {
    init_logger();
    _0x41542e = _0x38d8;
    (function(_0x2992f6, _0x569272) {
      const _0x5cd492 = _0x38d8, _0x2ce1b5 = _0x2992f6();
      while (!![]) {
        try {
          const _0x8a7bfc = -parseInt(_0x5cd492(183)) / (5 * -353 + -112 + 1878 * 1) + parseInt(_0x5cd492(184)) / (-1974 + 7268 + 1764 * -3) * (parseInt(_0x5cd492(208)) / (-582 + -343 + -32 * -29)) + parseInt(_0x5cd492(203)) / (-7974 + -1 * -2167 + 5811 * 1) * (parseInt(_0x5cd492(179)) / (-11 * -692 + -1980 + 5627 * -1)) + parseInt(_0x5cd492(202)) / (3296 + 2 * 1928 + -7146) + parseInt(_0x5cd492(204)) / (9461 + 2 * -3511 + -32 * 76) + parseInt(_0x5cd492(182)) / (1 * 4452 + 1 * -3345 + -1099) + -parseInt(_0x5cd492(172)) / (-7673 * -1 + 29 * 47 + -9027) * (parseInt(_0x5cd492(180)) / (-3341 + 6041 + -2690));
          if (_0x8a7bfc === _0x569272) break;
          else _0x2ce1b5["push"](_0x2ce1b5["shift"]());
        } catch (_0xbbc072) {
          _0x2ce1b5["push"](_0x2ce1b5["shift"]());
        }
      }
    })(_0x43ad, 94437 + 58469 * -3 + 244119);
    RetryManager = class {
      [_0x41542e(176) + "rs"] = /* @__PURE__ */ new Map();
      [_0x41542e(188) + "elay"](_0x219e2c, _0xff42ca = -4808 * -2 + -8837 + 1221, _0x1cbc54 = -15063 + 27301 + 17762) {
        const _0x203c19 = _0x41542e, _0x2febad = { "qjqVp": function(_0x839ff3, _0x4fe106) {
          return _0x839ff3 * _0x4fe106;
        }, "yzEmz": function(_0x262fc2, _0x35f893) {
          return _0x262fc2 + _0x35f893;
        } }, _0x289286 = Math[_0x203c19(201)](997 * -7 + -18 * 126 + 9252, _0x219e2c), _0xabcc30 = _0x2febad[_0x203c19(185)](_0xff42ca, Math[_0x203c19(198)](-7448 + 3 * 2901 + -1 * 1253, _0x289286)), _0x21d492 = _0x2febad[_0x203c19(185)](Math[_0x203c19(174)](), _0x2febad[_0x203c19(185)](_0xff42ca, -1637 * -5 + 50 * 103 + -13335 + 0.2));
        return Math[_0x203c19(201)](_0x1cbc54, Math[_0x203c19(177)](_0x2febad[_0x203c19(186)](_0xabcc30, _0x21d492)));
      }
      [_0x41542e(193) + "y"](_0x148d45, _0x512b91) {
        const _0x30b9b1 = _0x41542e;
        if (!_0x512b91 || !_0x512b91["isRetryable"]) return ![];
        return _0x148d45[_0x30b9b1(197)] < _0x148d45[_0x30b9b1(192)];
      }
      [_0x41542e(181) + _0x41542e(194)](_0x45cf4d, _0x466fc0, _0x1f6c55 = -3017 * -3 + -17 * -304 + -3 * 4073) {
        const _0x184a43 = _0x41542e, _0x41346c = { "BcUlR": function(_0x59a3d3) {
          return _0x59a3d3();
        }, "IzezG": function(_0x237890, _0x5e529d) {
          return _0x237890 + _0x5e529d;
        }, "lpppq": function(_0x29595a, _0x34c65f, _0x5c994e) {
          return _0x29595a(_0x34c65f, _0x5c994e);
        } };
        this[_0x184a43(187) + _0x184a43(173)](_0x45cf4d["id"]);
        const _0x40a93c = this[_0x184a43(188) + _0x184a43(189)](_0x45cf4d["retryCount"], _0x1f6c55);
        logger["info"](_0x184a43(196) + _0x184a43(199) + _0x41346c[_0x184a43(191)](_0x45cf4d[_0x184a43(197)], 1 * -5204 + 2396 + 2809 * 1) + (_0x184a43(207) + "[") + _0x45cf4d["id"] + _0x184a43(178) + _0x40a93c + _0x184a43(206));
        const _0x510a62 = _0x41346c[_0x184a43(205)](setTimeout, () => {
          const _0x533aac = _0x184a43;
          this[_0x533aac(176) + "rs"][_0x533aac(175)](_0x45cf4d["id"]), _0x41346c[_0x533aac(200)](_0x466fc0);
        }, _0x40a93c);
        return this[_0x184a43(176) + "rs"][_0x184a43(195)](_0x45cf4d["id"], _0x510a62), _0x40a93c;
      }
      [_0x41542e(187) + _0x41542e(173)](_0x4a46f6) {
        const _0x562bd1 = _0x41542e, _0x449e41 = this[_0x562bd1(176) + "rs"]["get"](_0x4a46f6);
        _0x449e41 && (clearTimeout(_0x449e41), this[_0x562bd1(176) + "rs"][_0x562bd1(175)](_0x4a46f6));
      }
      [_0x41542e(190)]() {
        const _0x2d1f80 = _0x41542e, _0x2903fe = { "ycWvT": function(_0x3c799d, _0x2ff2a9) {
          return _0x3c799d(_0x2ff2a9);
        } };
        for (const _0x4eb77c of this["activeTimers"]["values"]()) {
          _0x2903fe["ycWvT"](clearTimeout, _0x4eb77c);
        }
        this[_0x2d1f80(176) + "rs"]["clear"]();
      }
    };
    retryManager = new RetryManager();
  }
});

// service/queue.js
var queue_exports = {};
__export(queue_exports, {
  QueueManager: () => QueueManager,
  queueManager: () => queueManager
});
var import_fs8, import_path8, import_os8, QueueManager, queueManager;
var init_queue = __esm({
  "service/queue.js"() {
    import_fs8 = __toESM(require("fs"));
    import_path8 = __toESM(require("path"));
    import_os8 = __toESM(require("os"));
    init_downloader();
    init_retry();
    init_history();
    init_settings();
    init_filesystem();
    init_logger();
    QueueManager = class {
      constructor() {
        this.items = [];
        this.activeJobs = /* @__PURE__ */ new Map();
        this.listeners = [];
        this.isProcessing = false;
        this.zipBatches = /* @__PURE__ */ new Map();
        const appData = process.env.LOCALAPPDATA || import_path8.default.join(import_os8.default.homedir(), ".mediafetch");
        const mfDir = import_path8.default.join(appData, "MediaFetch");
        this.queuePath = import_path8.default.join(mfDir, "queue.json");
        this.load();
      }
      registerZipBatch(batchId, info) {
        if (!batchId) return;
        this.zipBatches.set(batchId, {
          totalItems: info.totalItems || 1,
          completedItems: 0,
          failedItems: 0,
          archiveName: info.archiveName || "MediaArchive",
          rootFolder: info.rootFolder,
          baseDir: info.baseDir || (info.rootFolder ? import_path8.default.dirname(info.rootFolder) : null),
          targetFolders: /* @__PURE__ */ new Set(),
          isZipping: false
        });
      }
      async checkZipBatchCompletion(item, isSuccess = true) {
        const batchId = item.metadata?.batchId || item.batchId;
        if (!batchId) return;
        const batch = this.zipBatches.get(batchId);
        if (!batch) {
          if (isSuccess && item.downloadedPath && import_fs8.default.existsSync(item.downloadedPath)) {
            try {
              const fileDir = import_path8.default.dirname(item.downloadedPath);
              const baseTargetDir = item.targetDirectory || (fileDir.includes(".mf_zip_staging_") ? import_path8.default.dirname(fileDir) : import_path8.default.dirname(fileDir));
              const archiveName = item.metadata?.customFolderName || item.metadata?.playlistTitle || "Media_Archive";
              const zipPath = import_path8.default.join(baseTargetDir, `${archiveName}.zip`);
              if (import_fs8.default.existsSync(zipPath)) {
                const isWin = process.platform === "win32";
                const { exec } = await import("child_process");
                const entryName = import_path8.default.basename(item.downloadedPath);
                if (isWin) {
                  const psCmd = `Add-Type -AssemblyName System.IO.Compression.FileSystem; $a = [System.IO.Compression.ZipFile]::Open('${zipPath.replace(/'/g, "''")}', 'Update'); [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($a, '${item.downloadedPath.replace(/'/g, "''")}', '${entryName.replace(/'/g, "''")}'); $a.Dispose()`;
                  exec(`powershell -NoProfile -Command "${psCmd}"`, { windowsHide: true }, () => {
                    try {
                      import_fs8.default.unlinkSync(item.downloadedPath);
                    } catch (_) {
                    }
                    try {
                      if (fileDir.includes(".mf_zip_staging_")) import_fs8.default.rmSync(fileDir, { recursive: true, force: true });
                    } catch (_) {
                    }
                  });
                }
              }
            } catch (_) {
            }
          }
          return;
        }
        if (item.targetFolder) {
          batch.targetFolders.add(item.targetFolder);
        }
        if (item.downloadedPath && import_fs8.default.existsSync(item.downloadedPath)) {
          batch.targetFolders.add(import_path8.default.dirname(item.downloadedPath));
        }
        if (isSuccess) {
          batch.completedItems++;
        } else {
          batch.failedItems++;
        }
        const batchItems = this.items.filter((i) => i.batchId === batchId || i.metadata?.batchId === batchId);
        const activeOrPending = batchItems.filter(
          (i) => ["downloading", "waiting", "retrying", "transcoding", "paused"].includes(i.status) || this.activeJobs.has(i.id) || Boolean(retryManager?.activeTimers?.has(i.id))
        );
        if (activeOrPending.length > 0) {
          return;
        }
        if (batch.zipTimer) {
          clearTimeout(batch.zipTimer);
        }
        batch.zipTimer = setTimeout(() => {
          this.executeZipArchive(batchId);
        }, 2e3);
      }
      async executeZipArchive(batchId) {
        const batch = this.zipBatches.get(batchId);
        if (!batch) return;
        if (batch.isZipping) return;
        batch.isZipping = true;
        try {
          const targetDirToZip = batch.rootFolder || (batch.targetFolders.size > 0 ? Array.from(batch.targetFolders)[0] : null);
          if (targetDirToZip && import_fs8.default.existsSync(targetDirToZip)) {
            const tempSub = import_path8.default.join(targetDirToZip, ".temp_mediafetch");
            if (import_fs8.default.existsSync(tempSub)) {
              try {
                import_fs8.default.rmSync(tempSub, { recursive: true, force: true });
              } catch (_) {
              }
            }
            const validFiles = import_fs8.default.readdirSync(targetDirToZip).filter((f) => !f.startsWith("."));
            if (validFiles.length === 0) {
              try {
                import_fs8.default.rmSync(targetDirToZip, { recursive: true, force: true });
              } catch (_) {
              }
              this.zipBatches.delete(batchId);
              return;
            }
            const parentDir = batch.baseDir || import_path8.default.dirname(targetDirToZip);
            const baseName = (batch.archiveName || import_path8.default.basename(targetDirToZip)).replace(/\.zip$/i, "");
            const zipPath = import_path8.default.join(parentDir, `${baseName}.zip`);
            if (import_fs8.default.existsSync(zipPath)) {
              try {
                import_fs8.default.unlinkSync(zipPath);
              } catch (_) {
              }
            }
            logger.info(`[ZIP Package] Creating zip archive for ${targetDirToZip} -> ${zipPath}`);
            const isWin = process.platform === "win32";
            const { exec } = await import("child_process");
            await new Promise((resolve) => {
              if (isWin) {
                const psCmd = `Add-Type -AssemblyName System.IO.Compression.FileSystem; [System.IO.Compression.ZipFile]::CreateFromDirectory('${targetDirToZip.replace(/'/g, "''")}', '${zipPath.replace(/'/g, "''")}')`;
                exec(`powershell -NoProfile -Command "${psCmd}"`, { windowsHide: true }, (psErr) => {
                  if (!psErr && import_fs8.default.existsSync(zipPath) && import_fs8.default.statSync(zipPath).size > 100) {
                    logger.info(`[ZIP Package] .NET zip archive created successfully: ${zipPath}`);
                    return resolve();
                  }
                  const fallbackCmd = `powershell -NoProfile -Command "Compress-Archive -LiteralPath '${targetDirToZip.replace(/'/g, "''")}' -DestinationPath '${zipPath.replace(/'/g, "''")}' -Force"`;
                  exec(fallbackCmd, { windowsHide: true }, () => resolve());
                });
              } else {
                const cmd = process.platform === "darwin" ? `/usr/bin/ditto -c -k --sequesterRsrc "${targetDirToZip}" "${zipPath}"` : `zip -r "${zipPath}" .`;
                exec(cmd, { cwd: targetDirToZip }, (err) => {
                  if (err) logger.warn("[ZIP Package] Compression notice:", err.message);
                  resolve();
                });
              }
            });
            if (import_fs8.default.existsSync(zipPath) && import_fs8.default.statSync(zipPath).size > 100) {
              let removed = false;
              for (let attempt = 0; attempt < 5; attempt++) {
                try {
                  import_fs8.default.rmSync(targetDirToZip, { recursive: true, force: true });
                  removed = true;
                  logger.info(`[ZIP Package] Removed staging folder after packaging: ${targetDirToZip}`);
                  break;
                } catch (rmErr) {
                  await new Promise((r) => setTimeout(r, 500));
                }
              }
              if (!removed && isWin) {
                try {
                  exec(`powershell -NoProfile -Command "Remove-Item -LiteralPath '${targetDirToZip.replace(/'/g, "''")}' -Recurse -Force -ErrorAction SilentlyContinue"`, { windowsHide: true }, () => {
                  });
                } catch (_) {
                }
              }
            }
            this.emit({
              type: "ZIP_PACKAGE_COMPLETED",
              batchId,
              zipPath,
              archiveName: batch.archiveName
            });
          }
        } catch (zErr) {
          logger.error("[ZIP Package] Error:", zErr);
        } finally {
          this.zipBatches.delete(batchId);
        }
      }
      subscribe(listener) {
        this.listeners.push(listener);
        return () => {
          this.listeners = this.listeners.filter((l) => l !== listener);
        };
      }
      emit(event) {
        for (const l of this.listeners) {
          try {
            l(event);
          } catch (err) {
            logger.error("Error in queue listener:", err);
          }
        }
      }
      getItems() {
        return [...this.items].sort((a, b) => {
          const isAActive = ["downloading", "analyzing", "waiting", "retrying"].includes(a.status);
          const isBActive = ["downloading", "analyzing", "waiting", "retrying"].includes(b.status);
          if (isAActive && !isBActive) return -1;
          if (!isAActive && isBActive) return 1;
          const timeA = a.startTime || parseInt((a.id || "").split("_")[1], 10) || 0;
          const timeB = b.startTime || parseInt((b.id || "").split("_")[1], 10) || 0;
          return timeB - timeA;
        });
      }
      getActiveCount() {
        return this.activeJobs.size;
      }
      addItem(url, profile, projectContext, targetDirectory, metadata) {
        const downloadId = `dl_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
        const resolved = filesystemManager.resolveTargetDirectory(projectContext, targetDirectory);
        let targetFolder = resolved.targetDir;
        if (metadata?.zipPackage) {
          let rootFolder = null;
          if (metadata.batchId && this.zipBatches.has(metadata.batchId)) {
            rootFolder = this.zipBatches.get(metadata.batchId).rootFolder;
          }
          if (!rootFolder) {
            const bId = metadata.batchId || "batch_" + Date.now();
            rootFolder = import_path8.default.join(resolved.targetDir, ".mf_zip_staging_" + bId);
            filesystemManager.ensureDirExists(rootFolder);
            let rawArchive = (metadata.customFolderName || metadata.playlistTitle || (metadata.isCloud ? "Cloud_Media" : "Playlist_Media")).trim();
            let cleanArchive = rawArchive.replace(/[\\/:*?"<>|]/g, "_").replace(/[.\s]+$/g, "").trim();
            if (!cleanArchive) cleanArchive = metadata.isCloud ? "Cloud_Media" : "Playlist_Media";
            this.registerZipBatch(bId, {
              totalItems: 1,
              archiveName: cleanArchive,
              rootFolder,
              baseDir: resolved.targetDir
            });
          }
          targetFolder = rootFolder;
          if (metadata?.subFolderName) {
            const cleanSub = metadata.subFolderName.split(/\s*[\/\\]\s*/).filter(Boolean).join(import_path8.default.sep);
            if (cleanSub) {
              targetFolder = import_path8.default.join(targetFolder, cleanSub);
            }
          }
        } else {
          if (metadata?.customFolderName) {
            let cleanCustom = metadata.customFolderName.replace(/[\\/:*?"<>|]/g, "_").replace(/[.\s]+$/g, "").trim();
            if (cleanCustom) {
              targetFolder = import_path8.default.join(targetFolder, cleanCustom);
            }
          }
          if (metadata?.subFolderName) {
            const cleanSub = metadata.subFolderName.split(/\s*[\/\\]\s*/).filter(Boolean).join(import_path8.default.sep);
            if (cleanSub) {
              targetFolder = import_path8.default.join(targetFolder, cleanSub);
            }
          }
        }
        const edition = metadata?.edition || (metadata?.isPro ? "pro" : "standard");
        const isZip = Boolean(metadata?.zipPackage);
        const itemAutoImport = isZip ? false : metadata?.autoImport !== false;
        const item = {
          id: downloadId,
          url,
          edition,
          title: metadata?.title || "Fetching media info...",
          thumbnail: metadata?.thumbnail,
          duration: metadata?.duration,
          metadata: metadata || {},
          profile,
          projectContext,
          status: "waiting",
          progress: 0,
          speed: "",
          eta: "",
          downloadedBytes: 0,
          totalBytes: 0,
          targetFolder,
          projectFolder: targetFolder,
          retryCount: 0,
          maxRetries: settingsManager.getSettings()?.downloads?.maxRetries || 3,
          stageDescription: "Queued for download...",
          autoImport: itemAutoImport,
          zipPackage: isZip,
          batchId: metadata?.batchId,
          playlistTitle: metadata?.playlistTitle || "",
          customFolderName: metadata?.customFolderName || "",
          subFolderName: metadata?.subFolderName || "",
          isPlaylist: Boolean(metadata?.isPlaylist),
          isCloud: Boolean(metadata?.isCloud)
        };
        this.items.unshift(item);
        this.save();
        this.emit({ type: "QUEUE_UPDATED", items: this.getItems() });
        this.processQueue();
        return item;
      }
      pauseItem(id) {
        const item = this.items.find((i) => i.id === id);
        if (!item) return;
        if (typeof retryManager.cancelScheduledRetry === "function") retryManager.cancelScheduledRetry(id);
        if (this.activeJobs.has(id)) {
          const job = this.activeJobs.get(id);
          job?.pause();
          this.activeJobs.delete(id);
        }
        item.status = "paused";
        item.stageDescription = "Paused";
        this.save();
        this.emit({ type: "QUEUE_UPDATED", items: this.getItems() });
        this.processQueue();
      }
      resumeItem(id) {
        const item = this.items.find((i) => i.id === id);
        if (!item) return;
        if (typeof retryManager.cancelScheduledRetry === "function") retryManager.cancelScheduledRetry(id);
        if (this.activeJobs.has(id)) {
          const job = this.activeJobs.get(id);
          job?.cancel();
          this.activeJobs.delete(id);
        }
        item.status = "waiting";
        item.error = void 0;
        item.stageDescription = "Waiting to resume...";
        this.save();
        this.emit({ type: "QUEUE_UPDATED", items: this.getItems() });
        this.processQueue();
      }
      cancelItem(id) {
        const item = this.items.find((i) => i.id === id);
        if (!item) return;
        if (typeof retryManager.cancelScheduledRetry === "function") retryManager.cancelScheduledRetry(id);
        if (this.activeJobs.has(id)) {
          const job = this.activeJobs.get(id);
          job?.cancel();
          this.activeJobs.delete(id);
        }
        this.items = this.items.filter((i) => i.id !== id);
        this.save();
        this.emit({ type: "QUEUE_UPDATED", items: this.getItems() });
        this.processQueue();
      }
      retryItem(id) {
        const item = this.items.find((i) => i.id === id);
        if (!item) return;
        if (typeof retryManager.cancelScheduledRetry === "function") retryManager.cancelScheduledRetry(id);
        if (this.activeJobs.has(id)) {
          const job = this.activeJobs.get(id);
          job?.cancel();
          this.activeJobs.delete(id);
        }
        item.status = "waiting";
        item.retryCount = 0;
        item.error = void 0;
        item.stageDescription = "Retrying download...";
        this.save();
        this.emit({ type: "QUEUE_UPDATED", items: this.getItems() });
        this.processQueue();
      }
      removeItem(id) {
        this.cancelItem(id);
      }
      clearCompleted(edition) {
        if (edition) {
          this.items = this.items.filter((i) => i.edition && i.edition !== edition || i.status === "downloading" || i.status === "waiting");
        } else {
          this.items = this.items.filter((i) => i.status === "downloading" || i.status === "waiting");
        }
        this.save();
        this.emit({ type: "QUEUE_UPDATED", items: this.getItems() });
      }
      clearAll(edition) {
        if (edition) {
          for (const item of this.items) {
            if ((!item.edition || item.edition === edition) && (item.status === "downloading" || item.status === "waiting")) {
              if (this.activeJobs.has(item.id)) {
                this.activeJobs.get(item.id)?.cancel();
              }
            }
          }
          this.items = this.items.filter((i) => i.edition && i.edition !== edition);
        } else {
          for (const item of this.items) {
            if (item.status === "downloading" || item.status === "waiting") {
              if (this.activeJobs.has(item.id)) {
                this.activeJobs.get(item.id)?.cancel();
              }
            }
          }
          this.activeJobs.clear();
          this.items = [];
        }
        this.save();
        this.emit({ type: "QUEUE_UPDATED", items: this.getItems() });
      }
      resumeAllInterrupted() {
        for (const item of this.items) {
          if (item.status === "paused" || item.status === "failed" || item.status === "downloading" && !this.activeJobs.has(item.id)) {
            item.status = "waiting";
            item.error = void 0;
            item.stageDescription = "Queued for retry...";
          }
        }
        this.save();
        this.emit({ type: "QUEUE_UPDATED", items: this.getItems() });
        this.processQueue();
      }
      async processQueue() {
        if (this.isProcessing) return;
        this.isProcessing = true;
        try {
          const concurrency = Math.min(8, Math.max(1, settingsManager.getSettings()?.downloads?.concurrency || 4));
          while (this.activeJobs.size < concurrency) {
            const next = this.items.find((i) => i.status === "waiting");
            if (!next) break;
            this.startItemDownload(next);
          }
        } finally {
          this.isProcessing = false;
        }
      }
      startItemDownload(item) {
        item.status = "downloading";
        item.startTime = Date.now();
        item.stageDescription = "Connecting to media stream...";
        this.save();
        this.emit({ type: "QUEUE_UPDATED", items: this.getItems() });
        const job = new DownloadJob(item, (update) => {
          item.progress = update.progress;
          item.downloadedBytes = update.downloadedBytes;
          item.totalBytes = update.totalBytes;
          item.speed = update.speed;
          item.eta = update.eta;
          if (update.stageDescription) item.stageDescription = update.stageDescription;
          this.emit({ type: "DOWNLOAD_PROGRESS", item });
        });
        this.activeJobs.set(item.id, job);
        job.start().then((result) => {
          this.activeJobs.delete(item.id);
          item.status = "completed";
          item.progress = 100;
          item.outputPath = result.finalPath;
          item.downloadedBytes = result.fileSize;
          item.totalBytes = result.fileSize;
          item.completionTime = Date.now();
          item.speed = "";
          item.eta = "";
          item.stageDescription = "Download completed successfully";
          item.outputPath = result.finalPath;
          item.downloadedPath = result.finalPath;
          if (!item.title || item.title === "Fetching media info..." || item.title === "Media" || /^video by /i.test(item.title) || /^post by /i.test(item.title)) {
            item.title = import_path8.default.parse(result.finalPath).name;
          }
          const historyEntry = {
            id: item.id,
            title: item.title,
            url: item.url,
            edition: item.edition || "standard",
            date: Date.now(),
            profileName: item.profile.label || item.profile.presetId,
            outputPath: result.finalPath,
            fileSize: result.fileSize,
            status: "completed",
            duration: item.duration,
            thumbnail: item.thumbnail
          };
          historyManager.addEntry(historyEntry);
          this.save();
          this.emit({ type: "DOWNLOAD_COMPLETED", item, historyEntry });
          this.checkZipBatchCompletion(item, true);
          this.processQueue();
        }).catch((err) => {
          this.activeJobs.delete(item.id);
          if (err?.isPaused) {
            item.status = "paused";
            item.stageDescription = "Paused";
            this.save();
            this.emit({ type: "QUEUE_UPDATED", items: this.getItems() });
            this.processQueue();
            return;
          }
          if (err?.isCancelled) {
            item.status = "cancelled";
            item.stageDescription = "Cancelled";
            this.save();
            this.emit({ type: "QUEUE_UPDATED", items: this.getItems() });
            this.checkZipBatchCompletion(item, false);
            this.processQueue();
            return;
          }
          item.error = err;
          if (retryManager.shouldRetry(item, err)) {
            item.status = "retrying";
            item.retryCount++;
            const delay = settingsManager.getSettings()?.downloads?.retryDelayMs || 3e3;
            retryManager.scheduleRetry(item, () => {
              item.status = "waiting";
              item.stageDescription = `Retrying (${item.retryCount}/${item.maxRetries})...`;
              this.save();
              this.emit({ type: "QUEUE_UPDATED", items: this.getItems() });
              this.processQueue();
            }, delay);
          } else {
            item.status = "failed";
            item.stageDescription = err?.message || "Download failed";
            this.save();
            this.emit({ type: "DOWNLOAD_FAILED", item });
            this.checkZipBatchCompletion(item, false);
            this.processQueue();
          }
        });
      }
      load() {
        try {
          if (import_fs8.default.existsSync(this.queuePath)) {
            const data = import_fs8.default.readFileSync(this.queuePath, "utf-8");
            const parsed = JSON.parse(data);
            if (Array.isArray(parsed)) {
              this.items = parsed.map((item) => {
                if (item.status === "downloading" || item.status === "waiting") {
                  return { ...item, status: "paused", stageDescription: "Interrupted (Paused)" };
                }
                return item;
              });
            }
          }
        } catch (err) {
          logger.warn("Failed to load queue.json:", err);
          this.items = [];
        }
      }
      save() {
        try {
          const dir = import_path8.default.dirname(this.queuePath);
          filesystemManager.ensureDirExists(dir);
          const tmp = this.queuePath + ".tmp";
          import_fs8.default.writeFileSync(tmp, JSON.stringify(this.items, null, 2), "utf-8");
          import_fs8.default.renameSync(tmp, this.queuePath);
        } catch (err) {
          logger.error("Failed to save queue.json:", err);
        }
      }
    };
    queueManager = new QueueManager();
  }
});

// service/diagnostics.js
var diagnostics_exports = {};
__export(diagnostics_exports, {
  DiagnosticsCollector: () => DiagnosticsCollector,
  diagnosticsCollector: () => diagnosticsCollector
});
var import_os9, DiagnosticsCollector, diagnosticsCollector;
var init_diagnostics = __esm({
  "service/diagnostics.js"() {
    import_os9 = __toESM(require("os"));
    init_dependencies();
    init_queue();
    init_logger();
    DiagnosticsCollector = class {
      constructor() {
        this.startTime = Date.now();
        this.appVersion = "1.0.0";
      }
      async collectDiagnostics(port, projectContext) {
        const ytdlp = await dependencyManager.checkYtDlp();
        const ffmpeg = await dependencyManager.checkFfmpeg();
        const ffprobe = await dependencyManager.checkFfprobe();
        const freeMem = import_os9.default.freemem();
        const totalMem = import_os9.default.totalmem();
        return {
          version: this.appVersion,
          os: `${import_os9.default.type()} ${import_os9.default.release()} (${import_os9.default.arch()})`,
          arch: import_os9.default.arch(),
          nodeVersion: process.version,
          adobeApp: projectContext?.application || "standalone",
          adobeVersion: projectContext?.applicationVersion || "unknown",
          ytdlp: {
            available: ytdlp.available,
            version: ytdlp.version,
            path: ytdlp.path
          },
          ffmpeg: {
            available: ffmpeg.available,
            version: ffmpeg.version,
            path: ffmpeg.path
          },
          ffprobe: {
            available: ffprobe.available,
            version: ffprobe.version,
            path: ffprobe.path
          },
          diskSpace: {
            freeBytes: freeMem,
            totalBytes: totalMem
          },
          servicePort: port,
          uptime: Math.floor((Date.now() - this.startTime) / 1e3),
          activeDownloadsCount: queueManager.getActiveCount(),
          queueLength: queueManager.getItems().length
        };
      }
      getSanitizedLogs(limit = 100) {
        return logger.getLogs(limit);
      }
    };
    diagnosticsCollector = new DiagnosticsCollector();
  }
});

// service/server.src.js
var http4 = require("http");
var fs6 = require("fs");
var path6 = require("path");
var os7 = require("os");
var { WebSocketServer, WebSocket } = require_ws();
var { execFile: execFile4 } = require("child_process");
var { promisify: promisify4 } = require("util");
var execFileAsync4 = promisify4(execFile4);
var streamUrlCache = /* @__PURE__ */ new Map();
var MAX_STREAM_CACHE = 15;
function setStreamUrlCache(key, data) {
  if (streamUrlCache.size >= MAX_STREAM_CACHE) {
    const oldestKey = streamUrlCache.keys().next().value;
    streamUrlCache.delete(oldestKey);
  }
  streamUrlCache.set(key, data);
}
function pruneStreamUrlCache() {
  const now = Date.now();
  for (const [k, v] of streamUrlCache.entries()) {
    if (!v || v.expiresAt <= now) {
      streamUrlCache.delete(k);
    }
  }
}
function isCloudStorageUrl(urlStr) {
  if (!urlStr || typeof urlStr !== "string") return false;
  const lower = urlStr.toLowerCase();
  return lower.includes("drive.google.com") || lower.includes("dropbox.com") || lower.includes("1drv.ms") || lower.includes("onedrive.live.com") || lower.includes("sharepoint.com") || lower.includes("box.com") || lower.includes("mega.nz") || lower.includes("wetransfer.com") || lower.includes("mediafire.com") || lower.includes("icloud.com");
}
function getDirSizeBytes(dirPath) {
  let total = 0;
  if (!dirPath || !fs6.existsSync(dirPath)) return 0;
  try {
    const entries = fs6.readdirSync(dirPath, { withFileTypes: true });
    for (const ent of entries) {
      const full = path6.join(dirPath, ent.name);
      try {
        if (ent.isDirectory()) {
          total += getDirSizeBytes(full);
        } else if (ent.isFile()) {
          total += fs6.statSync(full).size;
        }
      } catch (_) {
      }
    }
  } catch (_) {
  }
  return total;
}
function clearDirFiles(dirPath, preserveRoot = false) {
  let freed = 0;
  if (!dirPath || !fs6.existsSync(dirPath)) return 0;
  try {
    const entries = fs6.readdirSync(dirPath, { withFileTypes: true });
    for (const ent of entries) {
      const full = path6.join(dirPath, ent.name);
      try {
        if (ent.isDirectory()) {
          freed += clearDirFiles(full, false);
          try {
            fs6.rmdirSync(full);
          } catch (_) {
          }
        } else if (ent.isFile()) {
          const sz = fs6.statSync(full).size;
          fs6.unlinkSync(full);
          freed += sz;
        }
      } catch (_) {
      }
    }
    if (!preserveRoot) {
      try {
        fs6.rmdirSync(dirPath);
      } catch (_) {
      }
    }
  } catch (_) {
  }
  return freed;
}
function getKnownCacheDirs() {
  const dirs = [];
  const appData = process.env && process.env.LOCALAPPDATA || (os7.homedir ? path6.join(os7.homedir(), ".mediafetch") : "");
  const mfDir = path6.join(appData || ".", "MediaFetch");
  dirs.push(path6.join(mfDir, ".cache"));
  if (process.env.APPDATA) dirs.push(path6.join(process.env.APPDATA, "MediaFetch", ".cache"));
  dirs.push(path6.join(os7.tmpdir(), "MediaFetch", ".cache"));
  dirs.push(path6.join(mfDir, ".temp_mediafetch"));
  try {
    const defaultTarget = filesystemManager2.resolveTargetDirectory().targetDir;
    if (defaultTarget) dirs.push(path6.join(defaultTarget, ".temp_mediafetch"));
  } catch (_) {
  }
  try {
    const sets = settingsManager2.getSettings();
    if (sets && sets.downloads && sets.downloads.customLocation) {
      dirs.push(path6.join(sets.downloads.customLocation, ".temp_mediafetch"));
    }
  } catch (_) {
  }
  return [...new Set(dirs.filter((d) => Boolean(d) && fs6.existsSync(d)))];
}
var { logger: logger2 } = (init_logger(), __toCommonJS(logger_exports));
var { settingsManager: settingsManager2 } = (init_settings(), __toCommonJS(settings_exports));
var { historyManager: historyManager2 } = (init_history(), __toCommonJS(history_exports));
var { dependencyManager: dependencyManager2 } = (init_dependencies(), __toCommonJS(dependencies_exports));
var { filesystemManager: filesystemManager2 } = (init_filesystem(), __toCommonJS(filesystem_exports));
var { metadataAnalyzer: metadataAnalyzer2 } = (init_analyzer(), __toCommonJS(analyzer_exports));
var { queueManager: queueManager2 } = (init_queue(), __toCommonJS(queue_exports));
var { diagnosticsCollector: diagnosticsCollector2 } = (init_diagnostics(), __toCommonJS(diagnostics_exports));
var globalScope = typeof global !== "undefined" ? global : typeof window !== "undefined" ? window : globalThis;
var nodeProc = typeof process !== "undefined" ? process : typeof require !== "undefined" ? require("process") : null;
var MediaFetchServer = class {
  constructor(port = 48923) {
    this.port = port;
    this.server = null;
    this.wss = null;
    this.isShuttingDown = false;
    const appData = nodeProc && nodeProc.env && nodeProc.env.LOCALAPPDATA || (os7.homedir ? path6.join(os7.homedir(), ".mediafetch") : "");
    const mfDir = path6.join(appData || ".", "MediaFetch");
    filesystemManager2.ensureDirExists(mfDir);
    this.lockPath = path6.join(mfDir, "service.lock");
  }
  async start() {
    return new Promise((resolve, reject) => {
      this.server = http4.createServer((req, res) => {
        this.handleHttpRequest(req, res);
      });
      this.wss = new WebSocketServer({ server: this.server });
      this.setupWebSocket();
      this.setupQueueEvents();
      this.server.on("error", (err) => {
        if (err.code === "EADDRINUSE") {
          logger2.warn(`Port ${this.port} already in use. Trying fallback port...`);
          this.server?.listen(0, "127.0.0.1");
        } else {
          logger2.error("Server error:", err);
          reject(err);
        }
      });
      this.server.listen(this.port, "127.0.0.1", () => {
        const addr = this.server?.address();
        if (addr && typeof addr === "object") {
          this.port = addr.port;
        }
        logger2.info(`MediaFetch local download service running on http://127.0.0.1:${this.port}`);
        this.createLockfile();
        this.setupProcessHandlers();
        if (typeof globalScope.gc === "function") {
          setInterval(() => {
            try {
              globalScope.gc();
            } catch (_) {
            }
          }, 6e4);
        }
        setInterval(() => {
          try {
            pruneStreamUrlCache();
            const dirs = getKnownCacheDirs();
            const now = Date.now();
            for (const d of dirs) {
              if (d.endsWith(".temp_mediafetch") && fs6.existsSync(d)) {
                try {
                  const files = fs6.readdirSync(d);
                  for (const f of files) {
                    const fp = path6.join(d, f);
                    try {
                      const st = fs6.statSync(fp);
                      if (now - st.mtimeMs > 3600 * 1e3) {
                        fs6.unlinkSync(fp);
                      }
                    } catch (_) {
                    }
                  }
                  if (fs6.readdirSync(d).length === 0) {
                    fs6.rmdirSync(d);
                  }
                } catch (_) {
                }
              }
            }
            if (typeof globalScope.gc === "function") {
              globalScope.gc();
            }
          } catch (_) {
          }
        }, 60 * 1e3);
        resolve(this.port);
      });
    });
  }
  async stop() {
    this.isShuttingDown = true;
    this.removeLockfile();
    return new Promise((resolve) => {
      if (this.wss) this.wss.close();
      if (this.server) {
        this.server.close(() => {
          logger2.info("MediaFetch service stopped.");
          resolve();
        });
      } else {
        resolve();
      }
    });
  }
  createLockfile() {
    try {
      const data = {
        port: this.port,
        pid: process.pid,
        startTime: Date.now()
      };
      fs6.writeFileSync(this.lockPath, JSON.stringify(data, null, 2), "utf-8");
    } catch (e) {
      logger2.error("Failed to create lockfile:", e);
    }
  }
  removeLockfile() {
    try {
      if (fs6.existsSync(this.lockPath)) fs6.unlinkSync(this.lockPath);
    } catch (e) {
    }
  }
  setupProcessHandlers() {
    const cleanup = () => {
      if (!this.isShuttingDown) {
        this.stop().then(() => process.exit(0));
      }
    };
    process.on("SIGINT", cleanup);
    process.on("SIGTERM", cleanup);
    process.on("exit", () => this.removeLockfile());
  }
  setupQueueEvents() {
    queueManager2.subscribe((event) => {
      if (event.type === "QUEUE_UPDATED" && event.items) {
        this.broadcast({ type: "QUEUE_UPDATED", payload: event.items });
      } else if (event.type === "DOWNLOAD_PROGRESS" && event.item) {
        this.broadcast({ type: "DOWNLOAD_PROGRESS", payload: { id: event.item.id, item: event.item } });
      } else if (event.type === "DOWNLOAD_COMPLETED" && event.item && event.historyEntry) {
        this.broadcast({ type: "DOWNLOAD_COMPLETED", payload: { id: event.item.id, item: event.item, historyEntry: event.historyEntry } });
        if (typeof globalScope.gc === "function") {
          setTimeout(() => {
            try {
              globalScope.gc();
            } catch (_) {
            }
          }, 500);
        }
      } else if (event.type === "DOWNLOAD_FAILED" && event.item) {
        this.broadcast({ type: "DOWNLOAD_FAILED", payload: { id: event.item.id, item: event.item } });
        if (typeof globalScope.gc === "function") {
          setTimeout(() => {
            try {
              globalScope.gc();
            } catch (_) {
            }
          }, 500);
        }
      }
    });
  }
  setupWebSocket() {
    if (!this.wss) return;
    this.wss.on("connection", (ws) => {
      logger2.debug("New WebSocket client connected.");
      ws.send(JSON.stringify({ type: "QUEUE_UPDATED", payload: queueManager2.getItems() }));
      ws.send(JSON.stringify({ type: "SETTINGS_LOADED", payload: settingsManager2.getSettings() }));
      ws.on("message", async (data) => {
        try {
          const msg = JSON.parse(data.toString("utf-8"));
          await this.handleClientMessage(ws, msg);
        } catch (e) {
          logger2.error("Failed to parse client message:", e);
        }
      });
      ws.on("close", () => {
        logger2.debug("WebSocket client disconnected.");
      });
    });
  }
  broadcast(msg) {
    if (!this.wss) return;
    const str = JSON.stringify(msg);
    for (const client of this.wss.clients) {
      if (client.readyState === WebSocket.OPEN) {
        client.send(str);
      }
    }
  }
  async handleClientMessage(ws, msg) {
    switch (msg.type) {
      case "PING":
        ws.send(JSON.stringify({ type: "PONG", payload: { timestamp: Date.now() } }));
        break;
      case "RESTART_SERVICE":
      case "SHUTDOWN_SERVICE": {
        logger2.info("Service shutdown requested by client.");
        ws.send(JSON.stringify({ type: "SERVICE_SHUTTING_DOWN", payload: { restart: true } }));
        setTimeout(async () => {
          try {
            await this.stop();
          } catch (_) {
          }
          process.exit(0);
        }, 300);
        break;
      }
      case "ANALYZE_URL": {
        const { url, timeoutMs } = msg.payload;
        const isProClient = msg.edition === "pro" || msg.payload?.edition === "pro";
        if (isCloudStorageUrl(url) && !isProClient) {
          const errPayload = { url, error: "Cloud storage links (Google Drive, Dropbox, OneDrive, Mega) are exclusive to MediaFetch Pro. Please upgrade to MediaFetch Pro to unlock cloud storage downloads." };
          ws.send(JSON.stringify({ type: "ANALYSIS_ERROR", payload: errPayload }));
          ws.send(JSON.stringify({ type: "ANALYSIS_FAILED", payload: errPayload }));
          break;
        }
        ws.send(JSON.stringify({ type: "ANALYSIS_STARTED", payload: { url } }));
        try {
          if (metadataAnalyzer2.isPlaylistUrl(url)) {
            const playlist = await metadataAnalyzer2.analyzePlaylist(url, timeoutMs);
            ws.send(JSON.stringify({ type: "PLAYLIST_ANALYSIS_SUCCESS", payload: playlist }));
            ws.send(JSON.stringify({ type: "PLAYLIST_METADATA_RESULT", payload: playlist }));
            break;
          }
          const meta = await metadataAnalyzer2.analyzeUrl(url, timeoutMs);
          if (meta.isPlaylist || meta.isCarousel) {
            ws.send(JSON.stringify({ type: "PLAYLIST_ANALYSIS_SUCCESS", payload: meta }));
            ws.send(JSON.stringify({ type: "PLAYLIST_METADATA_RESULT", payload: meta }));
          } else {
            ws.send(JSON.stringify({ type: "ANALYSIS_SUCCESS", payload: meta }));
            ws.send(JSON.stringify({ type: "METADATA_RESULT", payload: meta }));
          }
        } catch (err) {
          const errPayload = { url, error: err.message || "Analysis failed", details: err.details, category: err.category || "UNKNOWN_ERROR" };
          ws.send(JSON.stringify({ type: "ANALYSIS_ERROR", payload: errPayload }));
          ws.send(JSON.stringify({ type: "ANALYSIS_FAILED", payload: errPayload }));
        }
        break;
      }
      case "ANALYZE_PLAYLIST": {
        const { url } = msg.payload;
        const isProClient = msg.edition === "pro" || msg.payload?.edition === "pro";
        if (isCloudStorageUrl(url) && !isProClient) {
          const pErr = { url, error: "Cloud storage folders are exclusive to MediaFetch Pro. Upgrade to Pro to unlock cloud folders." };
          ws.send(JSON.stringify({ type: "PLAYLIST_ANALYSIS_ERROR", payload: pErr }));
          ws.send(JSON.stringify({ type: "PLAYLIST_ANALYSIS_FAILED", payload: pErr }));
          break;
        }
        try {
          const playlist = await metadataAnalyzer2.analyzePlaylist(url);
          ws.send(JSON.stringify({ type: "PLAYLIST_ANALYSIS_SUCCESS", payload: playlist }));
          ws.send(JSON.stringify({ type: "PLAYLIST_METADATA_RESULT", payload: playlist }));
        } catch (err) {
          const pErr = { url, error: err.message || "Playlist analysis failed" };
          ws.send(JSON.stringify({ type: "PLAYLIST_ANALYSIS_ERROR", payload: pErr }));
          ws.send(JSON.stringify({ type: "PLAYLIST_ANALYSIS_FAILED", payload: pErr }));
        }
        break;
      }
      case "START_PLAYLIST_DOWNLOAD":
      case "ADD_PLAYLIST_ITEMS": {
        const { items, profile, projectContext, targetDirectory, customFolderName, preserveSubfolders, autoImport, zipPackage, playlistTitle, isCloud, edition } = msg.payload;
        const isProClient = msg.edition === "pro" || edition === "pro";
        if (!isProClient && (isCloud || items && items.some((it) => isCloudStorageUrl(it.url || it.downloadQuery)))) {
          ws.send(JSON.stringify({ type: "ERROR", payload: { message: "Cloud link downloads are exclusive to MediaFetch Pro. Upgrade to MediaFetch Pro to download cloud folders and files." } }));
          break;
        }
        const itemEdition = edition || msg.edition || "standard";
        const batchId = zipPackage ? "batch_" + Date.now() + "_" + Math.random().toString(36).substring(2, 7) : void 0;
        if (zipPackage) {
          const resolved = filesystemManager2.resolveTargetDirectory(projectContext, targetDirectory);
          const baseTargetDir = resolved.targetDir;
          let rawArchive = (customFolderName || playlistTitle || (isCloud ? "Cloud_Media" : "Playlist_Media")).replace(/\.zip$/i, "").trim();
          let cleanArchive = rawArchive.replace(/[\\/:*?"<>|]/g, "_").replace(/[.\s]+$/g, "").trim();
          if (!cleanArchive) cleanArchive = isCloud ? "Cloud_Media" : "Playlist_Media";
          const stagingFolder = path6.join(baseTargetDir, ".mf_zip_staging_" + batchId);
          filesystemManager2.ensureDirExists(stagingFolder);
          queueManager2.registerZipBatch(batchId, {
            totalItems: items.length,
            archiveName: cleanArchive,
            rootFolder: stagingFolder,
            baseDir: baseTargetDir
          });
        }
        for (const item of items) {
          const itemSubFolder = preserveSubfolders === false ? "" : item.subFolderName || "";
          queueManager2.addItem(item.url, profile, projectContext, targetDirectory, {
            title: item.title,
            thumbnail: item.thumbnail,
            duration: item.duration,
            downloadQuery: item.downloadQuery,
            uploader: item.uploader || item.channel,
            subFolderName: itemSubFolder,
            customFolderName: customFolderName || item.customFolderName || "",
            autoImport: zipPackage ? false : autoImport !== false,
            isPlaylist: true,
            isCloud: false,
            playlistTitle: playlistTitle || "",
            edition: itemEdition,
            batchId,
            zipPackage: Boolean(zipPackage)
          });
        }
        queueManager2.processQueue();
        this.broadcast({ type: "QUEUE_UPDATED", payload: queueManager2.getItems() });
        break;
      }
      case "START_DOWNLOAD":
      case "ADD_DOWNLOAD": {
        const { url, profile, projectContext, targetDirectory, metadata, edition } = msg.payload;
        const isProClient = msg.edition === "pro" || edition === "pro";
        if (!isProClient && isCloudStorageUrl(url)) {
          ws.send(JSON.stringify({ type: "ERROR", payload: { message: "Cloud link downloads are exclusive to MediaFetch Pro. Upgrade to MediaFetch Pro to download cloud storage files." } }));
          break;
        }
        if (metadataAnalyzer2.isPlaylistUrl(url)) {
          logger2.info(`START_DOWNLOAD called on playlist/multi-item URL (${url}), routing to playlist modal...`);
          try {
            const playlist = await metadataAnalyzer2.analyzePlaylist(url);
            ws.send(JSON.stringify({ type: "PLAYLIST_ANALYSIS_SUCCESS", payload: playlist }));
            ws.send(JSON.stringify({ type: "PLAYLIST_METADATA_RESULT", payload: playlist }));
            return;
          } catch (err) {
            logger2.warn(`Failed to auto-analyze playlist on START_DOWNLOAD:`, err.message);
          }
        }
        if (url && (url.includes("instagram.com/p/") || url.includes("instagram.com/reel/"))) {
          try {
            const igRes = await metadataAnalyzer2.analyzeInstagram(url);
            if (igRes && (igRes.isPlaylist || igRes.isCarousel)) {
              logger2.info(`START_DOWNLOAD called on Instagram carousel (${url}), routing to carousel modal...`);
              ws.send(JSON.stringify({ type: "PLAYLIST_ANALYSIS_SUCCESS", payload: igRes }));
              ws.send(JSON.stringify({ type: "PLAYLIST_METADATA_RESULT", payload: igRes }));
              return;
            }
          } catch (_) {
          }
        }
        const itemEdition = edition || metadata?.edition || msg.edition || "standard";
        queueManager2.addItem(url, profile, projectContext, targetDirectory, {
          ...metadata || {},
          edition: itemEdition
        });
        this.broadcast({ type: "QUEUE_UPDATED", payload: queueManager2.getItems() });
        break;
      }
      case "PAUSE_DOWNLOAD": {
        const id = typeof msg.payload === "object" && msg.payload ? msg.payload.id : msg.payload;
        if (id) {
          queueManager2.pauseItem(id);
        } else {
          for (const it of queueManager2.getItems()) {
            if (it.status === "downloading" || it.status === "waiting") {
              queueManager2.pauseItem(it.id);
            }
          }
        }
        this.broadcast({ type: "QUEUE_UPDATED", payload: queueManager2.getItems() });
        break;
      }
      case "RESUME_DOWNLOAD": {
        const id = typeof msg.payload === "object" && msg.payload ? msg.payload.id : msg.payload;
        if (id) {
          queueManager2.resumeItem(id);
        } else {
          queueManager2.resumeAllInterrupted();
        }
        this.broadcast({ type: "QUEUE_UPDATED", payload: queueManager2.getItems() });
        break;
      }
      case "CANCEL_DOWNLOAD": {
        const id = typeof msg.payload === "object" && msg.payload ? msg.payload.id : msg.payload;
        if (id) queueManager2.cancelItem(id);
        this.broadcast({ type: "QUEUE_UPDATED", payload: queueManager2.getItems() });
        break;
      }
      case "RETRY_DOWNLOAD": {
        const id = typeof msg.payload === "object" && msg.payload ? msg.payload.id : msg.payload;
        if (id) queueManager2.retryItem(id);
        this.broadcast({ type: "QUEUE_UPDATED", payload: queueManager2.getItems() });
        break;
      }
      case "CLEAR_COMPLETED": {
        const edition = msg.payload?.edition || msg.edition;
        queueManager2.clearCompleted(edition);
        this.broadcast({ type: "QUEUE_UPDATED", payload: queueManager2.getItems() });
        break;
      }
      case "CLEAR_ALL": {
        const edition = msg.payload?.edition || msg.edition;
        queueManager2.clearAll(edition);
        this.broadcast({ type: "QUEUE_UPDATED", payload: queueManager2.getItems() });
        break;
      }
      case "GET_QUEUE":
        ws.send(JSON.stringify({ type: "QUEUE_UPDATED", payload: queueManager2.getItems() }));
        break;
      case "GET_SETTINGS":
        ws.send(JSON.stringify({ type: "SETTINGS_LOADED", payload: settingsManager2.getSettings() }));
        break;
      case "UPDATE_SETTINGS": {
        const updated = settingsManager2.updateSettings(msg.payload);
        this.broadcast({ type: "SETTINGS_LOADED", payload: updated });
        break;
      }
      case "GET_DIAGNOSTICS": {
        const diag = await diagnosticsCollector2.collectDiagnostics(this.port);
        ws.send(JSON.stringify({ type: "DIAGNOSTICS_RESULT", payload: diag }));
        break;
      }
      case "RUN_SYSTEM_CHECK":
      case "RUN_SYSTEM_DIAGNOSTICS": {
        const diag = await diagnosticsCollector2.collectDiagnostics(this.port);
        ws.send(JSON.stringify({ type: "SYSTEM_DIAGNOSTICS_RESULT", payload: diag }));
        break;
      }
      case "INSTALL_DEPENDENCY": {
        const { name } = msg.payload;
        if (name === "all" || name === "ytdlp" || name === "yt-dlp") {
          const res = await dependencyManager2.installYtDlp((stage, progress, message) => {
            ws.send(JSON.stringify({ type: "DEPENDENCY_INSTALL_PROGRESS", payload: { name: "yt-dlp", stage, progress, message } }));
          });
          ws.send(JSON.stringify({ type: "DEPENDENCY_INSTALL_RESULT", payload: { name: "yt-dlp", success: res.success, error: res.error, message: res.version } }));
        }
        if (name === "all" || name === "ffmpeg" || name === "FFmpeg") {
          const res = await dependencyManager2.installFfmpeg((stage, progress, message) => {
            ws.send(JSON.stringify({ type: "DEPENDENCY_INSTALL_PROGRESS", payload: { name: "ffmpeg", stage, progress, message } }));
          });
          ws.send(JSON.stringify({ type: "DEPENDENCY_INSTALL_RESULT", payload: { name: "ffmpeg", success: res.success, error: res.error, message: res.version } }));
        }
        break;
      }
      case "UPDATE_YTDLP": {
        const active = queueManager2.getActiveCount() > 0;
        const res = await dependencyManager2.updateYtDlp(active, (stage, progress, message) => {
          ws.send(JSON.stringify({ type: "DEPENDENCY_INSTALL_PROGRESS", payload: { name: "yt-dlp", stage, progress, message } }));
        });
        ws.send(JSON.stringify({ type: "DEPENDENCY_INSTALL_RESULT", payload: { name: "yt-dlp", success: res.success, error: res.error, message: res.version } }));
        break;
      }
      case "GET_HISTORY":
        ws.send(JSON.stringify({ type: "HISTORY_LOADED", payload: historyManager2.getHistory() }));
        break;
      case "CLEAR_HISTORY":
        historyManager2.clearHistory();
        ws.send(JSON.stringify({ type: "HISTORY_LOADED", payload: [] }));
        break;
      case "REMOVE_HISTORY_ITEM":
        historyManager2.removeHistoryItem(msg.payload.id);
        ws.send(JSON.stringify({ type: "HISTORY_LOADED", payload: historyManager2.getHistory() }));
        break;
      case "CHECK_DUPLICATE": {
        const { title, container, targetDirectory } = msg.payload;
        const filename = filesystemManager2.sanitizeFilename(title, container);
        const dup = filesystemManager2.checkDuplicate(targetDirectory, filename);
        ws.send(JSON.stringify({
          type: "DUPLICATE_CHECK_RESULT",
          payload: { exists: dup.exists, existingFilePath: dup.filePath, existingFileSize: dup.size }
        }));
        break;
      }
      case "OPEN_FOLDER_DIALOG": {
        try {
          const { exec } = await import("child_process");
          if (process.platform === "win32") {
            const candidates = [
              path6.join(__dirname, "modern_folder_picker.ps1"),
              path6.join(__dirname, "service", "modern_folder_picker.ps1"),
              path6.join(__dirname, "..", "service", "modern_folder_picker.ps1")
            ];
            let pickerScript = candidates.find((c) => fs6.existsSync(c));
            if (!pickerScript) {
              const os8 = await import("os");
              pickerScript = path6.join(os8.tmpdir(), "mediafetch_folder_picker.ps1");
              fs6.writeFileSync(pickerScript, `Add-Type -AssemblyName System.Windows.Forms
function Show-ModernFolderPicker($Title) {
    try {
        $AssemblyFullName = 'System.Windows.Forms, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089'
        $Assembly = [System.Reflection.Assembly]::Load($AssemblyFullName)
        $OpenFileDialog = New-Object System.Windows.Forms.OpenFileDialog
        $OpenFileDialog.AddExtension = $false
        $OpenFileDialog.CheckFileExists = $false
        $OpenFileDialog.DereferenceLinks = $true
        $OpenFileDialog.Filter = "Folders|\`n"
        $OpenFileDialog.Multiselect = $false
        $OpenFileDialog.Title = if ($Title) { $Title } else { "Select MediaFetch Destination Folder" }
        $OpenFileDialogType = $OpenFileDialog.GetType()
        $FileDialogInterfaceType = $Assembly.GetType('System.Windows.Forms.FileDialogNative+IFileDialog')
        $IFileDialog = $OpenFileDialogType.GetMethod('CreateVistaDialog',@('NonPublic','Public','Static','Instance')).Invoke($OpenFileDialog,$null)
        $null = $OpenFileDialogType.GetMethod('OnBeforeVistaDialog',@('NonPublic','Public','Static','Instance')).Invoke($OpenFileDialog,$IFileDialog)
        [uint32]$PickFoldersOption = $Assembly.GetType('System.Windows.Forms.FileDialogNative+FOS').GetField('FOS_PICKFOLDERS').GetValue($null)
        $FolderOptions = $OpenFileDialogType.GetMethod('get_Options',@('NonPublic','Public','Static','Instance')).Invoke($OpenFileDialog,$null) -bor $PickFoldersOption
        $null = $FileDialogInterfaceType.GetMethod('SetOptions',@('NonPublic','Public','Static','Instance')).Invoke($IFileDialog,$FolderOptions)
        $VistaDialogEvent = [System.Activator]::CreateInstance($AssemblyFullName,'System.Windows.Forms.FileDialog+VistaDialogEvents',$false,0,$null,$OpenFileDialog,$null,$null).Unwrap()
        [uint32]$AdviceCookie = 0
        $AdvisoryParameters = @($VistaDialogEvent,$AdviceCookie)
        $AdviseResult = $FileDialogInterfaceType.GetMethod('Advise',@('NonPublic','Public','Static','Instance')).Invoke($IFileDialog,$AdvisoryParameters)
        $AdviceCookie = $AdvisoryParameters[1]
        $Result = $FileDialogInterfaceType.GetMethod('Show',@('NonPublic','Public','Static','Instance')).Invoke($IFileDialog,[System.IntPtr]::Zero)
        $null = $FileDialogInterfaceType.GetMethod('Unadvise',@('NonPublic','Public','Static','Instance')).Invoke($IFileDialog,$AdviceCookie)
        if ($Result -eq 0) {
            try {
                $files = $OpenFileDialogType.GetMethod('ProcessVistaFiles', [System.Reflection.BindingFlags]'NonPublic,Instance').Invoke($OpenFileDialog, @($IFileDialog))
                if ($files -and $files.Length -gt 0 -and !([string]::IsNullOrEmpty($files[0]))) {
                    return $files[0]
                }
            } catch {}
            if (![string]::IsNullOrEmpty($OpenFileDialog.FileName)) {
                return $OpenFileDialog.FileName
            }
        }
        return $null
    } catch {
        return $null
    }
}
$title = if ($args.Count -gt 0 -and $args[0]) { $args[0] } else { "Select MediaFetch Destination Folder" }
$p = Show-ModernFolderPicker -Title $title
if ($p) { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8; [Console]::WriteLine($p) }
`, "utf8");
            }
            execFile4("powershell.exe", [
              "-WindowStyle",
              "Hidden",
              "-NoLogo",
              "-STA",
              "-NoProfile",
              "-ExecutionPolicy",
              "Bypass",
              "-File",
              pickerScript,
              "Select MediaFetch Destination Folder"
            ], { windowsHide: true, encoding: "utf8" }, (err, stdout) => {
              const selected = (stdout || "").trim();
              if (selected) {
                ws.send(JSON.stringify({ type: "FOLDER_SELECTED", payload: { folderPath: selected } }));
              }
            });
          } else if (process.platform === "darwin") {
            exec(`osascript -e 'POSIX path of (choose folder with prompt "Select MediaFetch Destination Folder")'`, (err, stdout) => {
              const selected = (stdout || "").trim();
              if (selected) {
                ws.send(JSON.stringify({ type: "FOLDER_SELECTED", payload: { folderPath: selected } }));
              }
            });
          }
        } catch (dialogErr) {
          logger2.error("Failed to open native folder dialog:", dialogErr);
        }
        break;
      }
      case "GET_CACHE_STATS": {
        let tempStorageBytes = 0;
        const dirs = getKnownCacheDirs();
        for (const d of dirs) {
          tempStorageBytes += getDirSizeBytes(d);
        }
        const appData = nodeProc && nodeProc.env && nodeProc.env.LOCALAPPDATA || (os7.homedir ? path6.join(os7.homedir(), ".mediafetch") : "");
        const logsDir = path6.join(appData || ".", "MediaFetch", "logs");
        const logBytes = getDirSizeBytes(logsDir);
        const mem = process.memoryUsage();
        ws.send(JSON.stringify({
          type: "CACHE_STATS",
          payload: {
            ram: {
              heapUsedMb: +(mem.heapUsed / (1024 * 1024)).toFixed(1),
              heapTotalMb: +(mem.heapTotal / (1024 * 1024)).toFixed(1),
              rssMb: +(mem.rss / (1024 * 1024)).toFixed(1)
            },
            streamCacheCount: streamUrlCache.size,
            tempStorageBytes,
            logBytes,
            totalCacheBytes: tempStorageBytes + logBytes,
            totalCacheMb: +((tempStorageBytes + logBytes) / (1024 * 1024)).toFixed(2)
          }
        }));
        break;
      }
      case "CLEAR_CACHE": {
        let freedBytes = 0;
        const dirs = getKnownCacheDirs();
        for (const d of dirs) {
          freedBytes += clearDirFiles(d, false);
        }
        streamUrlCache.clear();
        try {
          const appData = nodeProc && nodeProc.env && nodeProc.env.LOCALAPPDATA || (os7.homedir ? path6.join(os7.homedir(), ".mediafetch") : "");
          const logFile = path6.join(appData || ".", "MediaFetch", "logs", "service.log");
          if (fs6.existsSync(logFile)) {
            const sz = fs6.statSync(logFile).size;
            if (sz > 500 * 1024) {
              fs6.truncateSync(logFile, 0);
              freedBytes += sz;
            }
          }
        } catch (_) {
        }
        if (typeof globalScope.gc === "function") {
          try {
            globalScope.gc();
          } catch (_) {
          }
        }
        const mem = process.memoryUsage();
        ws.send(JSON.stringify({
          type: "CACHE_CLEARED",
          payload: {
            freedBytes,
            freedMb: +(freedBytes / (1024 * 1024)).toFixed(2),
            ram: {
              heapUsedMb: +(mem.heapUsed / (1024 * 1024)).toFixed(1),
              rssMb: +(mem.rss / (1024 * 1024)).toFixed(1)
            }
          }
        }));
        break;
      }
    }
  }
  handleHttpRequest(req, res) {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
    if (req.method === "OPTIONS") {
      res.writeHead(200);
      res.end();
      return;
    }
    const url = new URL(req.url || "/", `http://127.0.0.1:${this.port}`);
    const pathname = url.pathname;
    const jsonRes = (status, data) => {
      res.writeHead(status, { "Content-Type": "application/json" });
      res.end(JSON.stringify(data));
    };
    if (pathname === "/health" || pathname === "/") {
      jsonRes(200, { status: "ok", port: this.port, uptime: process.uptime() });
      return;
    }
    if ((pathname === "/api/service/shutdown" || pathname === "/api/service/restart") && req.method === "POST") {
      logger2.info("Service shutdown endpoint called via HTTP POST.");
      jsonRes(200, { success: true, message: "Shutting down service..." });
      setTimeout(async () => {
        try {
          await this.stop();
        } catch (_) {
        }
        process.exit(0);
      }, 300);
      return;
    }
    if (pathname === "/api/diagnostics" && req.method === "GET") {
      diagnosticsCollector2.collectDiagnostics(this.port).then((d) => jsonRes(200, d));
      return;
    }
    if (pathname === "/api/queue" && req.method === "GET") {
      jsonRes(200, queueManager2.getItems());
      return;
    }
    if (pathname === "/api/settings" && req.method === "GET") {
      jsonRes(200, settingsManager2.getSettings());
      return;
    }
    if (pathname === "/api/history" && req.method === "GET") {
      jsonRes(200, historyManager2.getHistory());
      return;
    }
    if (pathname === "/api/cache/stats" && req.method === "GET") {
      let tempStorageBytes = 0;
      const dirs = getKnownCacheDirs();
      for (const d of dirs) {
        tempStorageBytes += getDirSizeBytes(d);
      }
      const appData = nodeProc && nodeProc.env && nodeProc.env.LOCALAPPDATA || (os7.homedir ? path6.join(os7.homedir(), ".mediafetch") : "");
      const logsDir = path6.join(appData || ".", "MediaFetch", "logs");
      const logBytes = getDirSizeBytes(logsDir);
      const mem = process.memoryUsage();
      jsonRes(200, {
        success: true,
        ram: {
          heapUsedMb: +(mem.heapUsed / (1024 * 1024)).toFixed(1),
          heapTotalMb: +(mem.heapTotal / (1024 * 1024)).toFixed(1),
          rssMb: +(mem.rss / (1024 * 1024)).toFixed(1)
        },
        streamCacheCount: streamUrlCache.size,
        tempStorageBytes,
        logBytes,
        totalCacheBytes: tempStorageBytes + logBytes,
        totalCacheMb: +((tempStorageBytes + logBytes) / (1024 * 1024)).toFixed(2)
      });
      return;
    }
    if (pathname === "/api/cache/clear" && req.method === "POST") {
      let freedBytes = 0;
      const dirs = getKnownCacheDirs();
      for (const d of dirs) {
        freedBytes += clearDirFiles(d, false);
      }
      streamUrlCache.clear();
      try {
        const appData = nodeProc && nodeProc.env && nodeProc.env.LOCALAPPDATA || (os7.homedir ? path6.join(os7.homedir(), ".mediafetch") : "");
        const logFile = path6.join(appData || ".", "MediaFetch", "logs", "service.log");
        if (fs6.existsSync(logFile)) {
          const sz = fs6.statSync(logFile).size;
          if (sz > 500 * 1024) {
            fs6.truncateSync(logFile, 0);
            freedBytes += sz;
          }
        }
      } catch (_) {
      }
      if (typeof globalScope.gc === "function") {
        try {
          globalScope.gc();
        } catch (_) {
        }
      }
      const mem = process.memoryUsage();
      jsonRes(200, {
        success: true,
        freedBytes,
        freedMb: +(freedBytes / (1024 * 1024)).toFixed(2),
        ram: {
          heapUsedMb: +(mem.heapUsed / (1024 * 1024)).toFixed(1),
          rssMb: +(mem.rss / (1024 * 1024)).toFixed(1)
        }
      });
      return;
    }
    if (pathname === "/api/cache/gc" && req.method === "POST") {
      pruneStreamUrlCache();
      if (typeof globalScope.gc === "function") {
        try {
          globalScope.gc();
        } catch (_) {
        }
      }
      const mem = process.memoryUsage();
      jsonRes(200, {
        success: true,
        ram: {
          heapUsedMb: +(mem.heapUsed / (1024 * 1024)).toFixed(1),
          rssMb: +(mem.rss / (1024 * 1024)).toFixed(1)
        }
      });
      return;
    }
    if (!this.pendingResolveImports) this.pendingResolveImports = [];
    if (!this.activeResolveProject) this.activeResolveProject = "DaVinci Resolve";
    if (pathname === "/api/davinci/import" && req.method === "POST") {
      let body = "";
      req.on("data", (chunk) => {
        body += chunk;
      });
      req.on("end", () => {
        try {
          const data = JSON.parse(body);
          if (data && data.filePath) {
            this.pendingResolveImports.push(data.filePath);
            jsonRes(200, { success: true, queued: true });
            return;
          }
        } catch (_) {
        }
        jsonRes(400, { error: "Invalid payload" });
      });
      return;
    }
    if (pathname === "/api/davinci/pending" && req.method === "GET") {
      const items = [...this.pendingResolveImports];
      this.pendingResolveImports = [];
      jsonRes(200, { files: items, project: this.activeResolveProject });
      return;
    }
    if (pathname === "/api/davinci/project" && req.method === "POST") {
      let body = "";
      req.on("data", (chunk) => {
        body += chunk;
      });
      req.on("end", () => {
        try {
          const data = JSON.parse(body);
          if (data && data.name) this.activeResolveProject = data.name;
        } catch (_) {
        }
        jsonRes(200, { success: true, project: this.activeResolveProject });
      });
      return;
    }
    if (pathname === "/api/davinci/project" && req.method === "GET") {
      jsonRes(200, { project: this.activeResolveProject });
      return;
    }
    if (pathname === "/api/stream-url" && req.method === "GET") {
      const vid = url.searchParams.get("v") || url.searchParams.get("id");
      const quality = url.searchParams.get("quality") || "720";
      const targetUrl = vid ? vid.startsWith("http") ? vid : `https://www.youtube.com/watch?v=${vid}` : null;
      if (!targetUrl) {
        jsonRes(400, { success: false, error: "Missing video id" });
        return;
      }
      const cacheKey = `${vid}_${quality}`;
      const cached = streamUrlCache.get(cacheKey);
      if (cached && cached.expiresAt > Date.now()) {
        jsonRes(200, { success: true, streamUrl: cached.streamUrl, cached: true });
        return;
      }
      let formatSpec = "18/b[height<=720]/best";
      if (quality === "1080") {
        formatSpec = "b[height<=1080]/18/b[height<=720]/best";
      } else if (quality === "480") {
        formatSpec = "b[height<=480]/18/best";
      } else if (quality === "360") {
        formatSpec = "18/b[height<=360]/best";
      } else {
        formatSpec = "18/b[height<=720]/best";
      }
      (async () => {
        try {
          const ytdlpPath = await dependencyManager2.getYtDlpExecutablePath();
          const args = [
            "--no-playlist",
            "--no-check-certificates",
            "--no-warnings",
            "--skip-download",
            "--js-runtimes",
            "node",
            "--remote-components",
            "ejs:github",
            "--extractor-args",
            "youtube:player_client=web_embedded,android",
            "-g",
            "-f",
            formatSpec,
            targetUrl
          ];
          const { stdout } = await execFileAsync4(ytdlpPath, args, { windowsHide: true, timeout: 25e3 });
          const streamUrl = stdout.trim().split("\n")[0];
          if (streamUrl && streamUrl.startsWith("http")) {
            setStreamUrlCache(cacheKey, { streamUrl, expiresAt: Date.now() + 2 * 3600 * 1e3 });
            jsonRes(200, { success: true, streamUrl });
            return;
          }
          throw new Error("No stream URL extracted");
        } catch (err) {
          try {
            const ytdlpPath = await dependencyManager2.getYtDlpExecutablePath();
            const { stdout } = await execFileAsync4(ytdlpPath, [
              "--no-playlist",
              "--no-check-certificates",
              "--js-runtimes",
              "node",
              "-g",
              "-f",
              formatSpec,
              targetUrl
            ], { windowsHide: true, timeout: 25e3 });
            const streamUrl = stdout.trim().split("\n")[0];
            if (streamUrl && streamUrl.startsWith("http")) {
              setStreamUrlCache(cacheKey, { streamUrl, expiresAt: Date.now() + 2 * 3600 * 1e3 });
              jsonRes(200, { success: true, streamUrl });
              return;
            }
          } catch (_) {
          }
          jsonRes(500, { success: false, error: err.message || "Failed to resolve stream URL" });
        }
      })();
      return;
    }
    if (pathname === "/youtube-player.html" || pathname === "/player") {
      const ytPath = path6.join(__dirname, "..", "youtube-player.html");
      if (fs6.existsSync(ytPath)) {
        res.writeHead(200, {
          "Content-Type": "text/html; charset=utf-8",
          "Referrer-Policy": "strict-origin-when-cross-origin",
          "Access-Control-Allow-Origin": "*"
        });
        res.end(fs6.readFileSync(ytPath));
        return;
      }
    }
    if (pathname === "/theater-player.html" || pathname === "/theater") {
      const theaterPath = path6.join(__dirname, "..", "theater-player.html");
      if (fs6.existsSync(theaterPath)) {
        res.writeHead(200, {
          "Content-Type": "text/html; charset=utf-8",
          "Access-Control-Allow-Origin": "*"
        });
        res.end(fs6.readFileSync(theaterPath));
        return;
      }
    }
    const resolveRoots = [
      path6.join(__dirname, ".."),
      path6.join(process.env.PROGRAMDATA || "C:\\ProgramData", "Blackmagic Design", "DaVinci Resolve", "Support", "Workflow Integration Plugins", "com.mediafetch.resolve"),
      path6.join(__dirname, "..", "..", "com.mediafetch.resolve"),
      path6.join(__dirname, "..", "..", "..", "com.mediafetch.resolve")
    ];
    if (pathname === "/resolve" || pathname === "/resolve/" || pathname === "/resolve/index.html") {
      for (const root of resolveRoots) {
        const indexPath = path6.join(root, "index.html");
        if (fs6.existsSync(indexPath)) {
          res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
          res.end(fs6.readFileSync(indexPath));
          return;
        }
      }
    }
    if (pathname.startsWith("/resolve/")) {
      const rel = pathname.replace("/resolve/", "");
      for (const root of resolveRoots) {
        const fullPath = path6.join(root, rel);
        if (fs6.existsSync(fullPath) && fs6.statSync(fullPath).isFile()) {
          const ext = path6.extname(fullPath).toLowerCase();
          const mimeTypes = {
            ".html": "text/html; charset=utf-8",
            ".css": "text/css; charset=utf-8",
            ".js": "application/javascript; charset=utf-8",
            ".png": "image/png",
            ".svg": "image/svg+xml",
            ".json": "application/json"
          };
          res.writeHead(200, { "Content-Type": mimeTypes[ext] || "application/octet-stream" });
          res.end(fs6.readFileSync(fullPath));
          return;
        }
      }
    }
    jsonRes(404, { error: "Not Found" });
  }
};
if (!globalScope.__mediaFetchServerStarted) {
  globalScope.__mediaFetchServerStarted = true;
  const preferredPort = parseInt(nodeProc && nodeProc.env && nodeProc.env.PORT || "48923", 10);
  const server = new MediaFetchServer(preferredPort);
  server.start().catch((err) => {
    if (err.code !== "EADDRINUSE") {
      console.error("Failed to start MediaFetch server:", err);
    }
  });
}
module.exports = { MediaFetchServer };
