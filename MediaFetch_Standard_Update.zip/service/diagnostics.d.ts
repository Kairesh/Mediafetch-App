import { SystemDiagnostics, ProjectContext } from '../common/types.js';
export declare class DiagnosticsCollector {
    private startTime;
    private appVersion;
    getDiagnostics(port: number, projectContext?: ProjectContext): Promise<SystemDiagnostics>;
    getSanitizedLogs(limit?: number): string[];
}
export declare const diagnosticsCollector: DiagnosticsCollector;
