export function sanitizeErrorDetails(input) {
  if (!input) return '';
  return String(input)
    .replace(/(token|password|pass|key|secret|cookie|auth)=([a-zA-Z0-9_\-\.%]+)/gi, '$1=[REDACTED]')
    .replace(/Bearer\s+[a-zA-Z0-9_\-\.]+/gi, 'Bearer [REDACTED]')
    .replace(/--cookies\s+[^\s]+/gi, '--cookies [REDACTED]')
    .replace(/C:\\Users\\[^\\]+\\/gi, 'C:\\Users\\<USER>\\')
    .substring(0, 800);
}

export function classifyError(err, context = '') {
  const msg = err instanceof Error ? err.message : String(err || '');
  const details = err?.details || '';
  const stderr = typeof err?.stderr === 'string' ? err.stderr : '';
  const stdout = typeof err?.stdout === 'string' ? err.stdout : '';
  const ctx = typeof context === 'string' ? context : '';
  const combined = (msg + ' \n ' + details + ' \n ' + stderr + ' \n ' + stdout + ' \n ' + ctx).toLowerCase();

  // 1. Age Restriction / Authentication / Sign in required (MUST be checked first so age-restricted videos are cleanly identified)
  if (
    combined.includes('sign in to confirm your age') ||
    combined.includes('confirm your age') ||
    combined.includes('inappropriate for some users') ||
    combined.includes('age-restricted') ||
    combined.includes('requires age confirmation') ||
    combined.includes('cookies-from-browser') ||
    combined.includes('sign in') ||
    combined.includes('login required') ||
    combined.includes('private') ||
    combined.includes('members-only') ||
    combined.includes('requires authentication') ||
    combined.includes('drm') ||
    combined.includes('copyright') ||
    combined.includes('http error 403') ||
    combined.includes('forbidden')
  ) {
    const isAgeRestricted = combined.includes('age') || combined.includes('inappropriate for some users') || combined.includes('confirm your age');
    return {
      category: 'AUTHENTICATION_REQUIRED',
      message: isAgeRestricted
        ? 'This video is 18+ Age-Restricted by YouTube. Please use the Cookie Guide in Settings to import your YouTube cookies.'
        : 'This media requires authentication, subscription, or is DRM/copyright protected.',
      details: sanitizeErrorDetails(stderr || msg || details || 'Content is restricted by the platform or requires valid cookies/credentials.'),
      isRetryable: false,
      retryable: false,
      code: 'ERR_AUTH_REQUIRED',
      timestamp: Date.now()
    };
  }

  // 2. FFmpeg / Postprocessing / Merger errors MUST be caught before generic 'not found' checks!
  if (
    combined.includes('ffmpeg') ||
    combined.includes('ffprobe') ||
    combined.includes('postprocess') ||
    combined.includes('mux') ||
    combined.includes('merger')
  ) {
    return {
      category: 'FFMPEG_ERROR',
      message: 'Media processing failed during audio/video merge or postprocessing.',
      details: sanitizeErrorDetails(stderr || details || msg),
      isRetryable: true,
      code: 'ERR_FFMPEG_FAILED',
      timestamp: Date.now()
    };
  }

  // 3. Network / Connection errors
  if (
    combined.includes('econnrefused') ||
    combined.includes('etimedout') ||
    combined.includes('econnreset') ||
    combined.includes('enetunreach') ||
    combined.includes('network') ||
    combined.includes('socket hang up') ||
    combined.includes('timed out') ||
    combined.includes('getaddrinfo')
  ) {
    return {
      category: 'NETWORK_ERROR',
      message: 'Network connection failed. Please check your internet connection.',
      details: sanitizeErrorDetails(stderr || msg || details),
      isRetryable: true,
      code: 'ERR_NETWORK_FAILED',
      timestamp: Date.now()
    };
  }

  // 4. Invalid / Unsupported / Not Found URLs (safe since ffmpeg/ffprobe checked first)
  if (
    combined.includes('not found') ||
    combined.includes('404') ||
    combined.includes('unsupported url') ||
    combined.includes('no video formats found') ||
    combined.includes('unable to extract') ||
    combined.includes('does not exist') ||
    combined.includes('removed')
  ) {
    return {
      category: 'UNSUPPORTED_URL',
      message: 'The media could not be found or the URL is not supported.',
      details: sanitizeErrorDetails(msg || details),
      isRetryable: false,
      code: 'ERR_URL_NOT_FOUND',
      timestamp: Date.now()
    };
  }

  // 5. Disk Space
  if (combined.includes('enospc') || combined.includes('disk full') || combined.includes('no space left')) {
    return {
      category: 'DISK_SPACE_ERROR',
      message: 'Not enough free disk space on target drive.',
      details: 'Please free up disk space and try again.',
      isRetryable: false,
      code: 'ERR_DISK_SPACE',
      timestamp: Date.now()
    };
  }

  // 6. Permission errors
  if (combined.includes('eacces') || combined.includes('eperm') || combined.includes('permission denied')) {
    return {
      category: 'PERMISSION_ERROR',
      message: 'Permission denied. Could not write to the target directory.',
      details: 'Ensure your user account has write permissions to the export folder.',
      isRetryable: false,
      code: 'ERR_PERMISSION_DENIED',
      timestamp: Date.now()
    };
  }

  // Default fallback
  return {
    category: 'UNKNOWN_ERROR',
    message: 'An unexpected download error occurred.',
    details: sanitizeErrorDetails(msg || details || context || 'Unknown download error.'),
    isRetryable: true,
    code: 'ERR_UNKNOWN',
    timestamp: Date.now()
  };
}