/**
 * YouTube Visitor Data & Token Manager
 * Automatically provides valid visitor tokens to bypass YouTube anti-bot & SABR restrictions.
 */

import fs from 'fs';
import path from 'path';
import os from 'os';
import { logger } from './logger.js';
import { dependencyManager } from './dependencies.js';

class YouTubeTokenManager {
  constructor() {
    this.fallbackVisitorData = null;
    this.tokenFilePath = path.join(process.env.LOCALAPPDATA || (os.homedir ? path.join(os.homedir(), 'AppData', 'Local') : '.'), 'MediaFetch', 'visitor_data.txt');
    this.cachedVisitorData = this.readSavedVisitorData() || null;
    this.lastFetched = this.cachedVisitorData ? Date.now() : 0;
    this.isFetching = false;
  }

  readSavedVisitorData() {
    try {
      if (fs.existsSync(this.tokenFilePath)) {
        const val = fs.readFileSync(this.tokenFilePath, 'utf8').trim();
        if (val && val.length > 20) return val;
      }
    } catch (_) {}
    return null;
  }

  saveVisitorData(vd) {
    try {
      const dir = path.dirname(this.tokenFilePath);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(this.tokenFilePath, vd, 'utf8');
    } catch (_) {}
  }

  isYouTubeUrl(url) {
    if (!url || typeof url !== 'string') return false;
    const lower = url.toLowerCase().trim();
    return lower.includes('youtube.com') || lower.includes('youtu.be') || lower.startsWith('ytsearch');
  }

  async getVisitorData() {
    const age = Date.now() - this.lastFetched;
    if ((!this.cachedVisitorData || age > 6 * 60 * 60 * 1000) && !this.isFetching) {
      await this.refreshVisitorData().catch(() => {});
    }
    return this.cachedVisitorData || null;
  }

  async refreshVisitorData() {
    if (this.isFetching) return this.cachedVisitorData;
    this.isFetching = true;
    try {
      logger?.debug?.('[YouTubeTokenManager] Refreshing YouTube visitor data token...');
      let controller = null;
      let timer = null;
      if (typeof AbortController !== 'undefined') {
        controller = new AbortController();
        timer = setTimeout(() => {
          try { controller.abort(); } catch (_) {}
        }, 6000);
      }
      const fetchOpts = {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
          'Accept-Language': 'en-US,en;q=0.9'
        }
      };
      if (controller) fetchOpts.signal = controller.signal;
      const res = await fetch('https://www.youtube.com', fetchOpts);
      if (timer) clearTimeout(timer);
      if (res.ok) {
        const html = await res.text();
        const match = html.match(/"VISITOR_DATA":\s*"([^"]+)"/);
        if (match && match[1]) {
          try {
            this.cachedVisitorData = decodeURIComponent(match[1]);
          } catch (_) {
            this.cachedVisitorData = match[1];
          }
          this.lastFetched = Date.now();
          this.saveVisitorData(this.cachedVisitorData);
          logger?.info?.('[YouTubeTokenManager] Successfully refreshed YouTube visitor token');
          return this.cachedVisitorData;
        }
      }
    } catch (err) {
      logger?.warn?.('[YouTubeTokenManager] Background visitor token refresh notice:', err?.message || err);
    } finally {
      this.isFetching = false;
    }
    return this.cachedVisitorData || this.fallbackVisitorData || null;
  }

  async getYtDlpExtractorArgs(url, isAnalysis = false) {
    try {
      const nodeBin = dependencyManager.getNodeExecutablePath() || 'node';
      const jsRuntime = nodeBin === 'node' ? 'node' : `node:${nodeBin}`;
      return ['--js-runtimes', jsRuntime, '--remote-components', 'ejs:github'];
    } catch (_) {
      return ['--remote-components', 'ejs:github'];
    }
  }
}

export const youtubeTokenManager = new YouTubeTokenManager();
