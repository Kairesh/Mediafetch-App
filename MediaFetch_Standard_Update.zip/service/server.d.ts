export declare class MediaFetchServer {
    private server?;
    private wss?;
    private port;
    private lockFilePath;
    private isShuttingDown;
    constructor(preferredPort?: number);
    start(): Promise<number>;
    stop(): Promise<void>;
    private writeLockFile;
    private removeLockFile;
    private setupProcessSignals;
    private setupQueueBridge;
    private setupWebSocket;
    private broadcast;
    private handleClientMessage;
    private handleHttpRequest;
}
