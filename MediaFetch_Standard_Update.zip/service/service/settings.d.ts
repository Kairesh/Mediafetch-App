import { MediaFetchSettings } from '../common/types.js';
export declare const DEFAULT_SETTINGS: MediaFetchSettings;
export declare class SettingsManager {
    private configPath;
    private currentSettings;
    constructor();
    private ensureDirectory;
    getSettings(): MediaFetchSettings;
    updateSettings(partial: Partial<MediaFetchSettings>): MediaFetchSettings;
    private load;
    private save;
}
export declare const settingsManager: SettingsManager;
