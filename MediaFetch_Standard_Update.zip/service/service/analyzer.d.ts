import { MediaMetadata, DownloadProfile } from '../common/types.js';
export declare class MetadataAnalyzer {
    /**
     * Validates if string is a basic well-formed HTTP/HTTPS URL.
     */
    isValidUrl(urlStr: string): boolean;
    /**
     * Analyzes media URL using yt-dlp.
     */
    analyzeUrl(url: string, timeoutMs?: number): Promise<MediaMetadata>;
    /**
     * Parses raw yt-dlp output into structured MediaMetadata.
     */
    parseYtDlpOutput(url: string, raw: any): MediaMetadata;
    /**
     * Generates smart format profiles available for this specific media.
     */
    getAvailableProfiles(metadata: MediaMetadata): DownloadProfile[];
}
export declare const metadataAnalyzer: MetadataAnalyzer;
