/**
 * MediaFetch & MediaSearch Settings Manager
 */
const Settings = (function () {
    const STORAGE_KEY = "mediafetch_search_settings";

    const defaultSettings = {
        // Built-in working fallback keys
        pixabayApiKey: "10547590-561862cf80d7e34284c5268bc",
        pixabayBackupApiKey: "23107835-0a6cc5a60b0978cc4eff8e5fa",
        pexelsApiKey: "nJhYrM3NMjdfzgsR092DY9sUSpWiYU2iXmbsAwnDLJHDxxp9F6vKwBnE",
        unsplashApiKey: "_Lo9ruec1rqQ_-ERrp_NHgqbfBdANyAzPYaSLwGdXh0",
        giphyApiKey: "sXpGFDGZs0Dv1mmNFvYaGUvYwKX0P4W5",
        jamendoClientId: "56d30c95",

        // Default Preferences
        downloadFolder: "", // Empty = use active project folder / default
        autoInsertTimeline: true,
        defaultVideoQuality: "1080p", // 4k, 1080p, 720p, audio-only
        defaultImageQuality: "high", // original, high, medium
        theme: "darkest",
        iconTheme: "core", // core, duotone, glass
        previewSoundVolume: 0.7,
        pausePreviewOnTabChange: false
    };

    function load() {
        try {
            const raw = localStorage.getItem(STORAGE_KEY);
            if (raw) {
                const parsed = JSON.parse(raw);
                // Migrate any old expired keys to fresh working keys
                if (!parsed.pixabayApiKey || parsed.pixabayApiKey.includes("45972822")) {
                    parsed.pixabayApiKey = defaultSettings.pixabayApiKey;
                }
                if (!parsed.pexelsApiKey || parsed.pexelsApiKey.includes("563492ad6f91700001000001dfa1f8db1f344df3bbbc9e829d592652")) {
                    parsed.pexelsApiKey = defaultSettings.pexelsApiKey;
                }
                if (!parsed.unsplashApiKey || parsed.unsplashApiKey.includes("k_U-aYk3j5Vz")) {
                    parsed.unsplashApiKey = defaultSettings.unsplashApiKey;
                }
                return Object.assign({}, defaultSettings, parsed);
            }
        } catch (e) {
            console.warn("Failed to load settings from localStorage:", e);
        }
        return Object.assign({}, defaultSettings);
    }

    function save(newSettings) {
        try {
            const current = load();
            const updated = Object.assign({}, current, newSettings);
            localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
            return updated;
        } catch (e) {
            console.error("Failed to save settings:", e);
            return load();
        }
    }

    function get(key) {
        const s = load();
        return s[key] !== undefined ? s[key] : defaultSettings[key];
    }

    function set(key, value) {
        const obj = {};
        obj[key] = value;
        return save(obj);
    }

    return {
        load: load,
        save: save,
        get: get,
        set: set,
        defaults: defaultSettings
    };
})();

if (typeof module !== "undefined" && module.exports) {
    module.exports = Settings;
} else {
    window.Settings = Settings;
}
