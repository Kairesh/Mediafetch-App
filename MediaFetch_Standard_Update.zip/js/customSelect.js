/**
 * MediaFetch Glass Custom Select Dropdown
 * Replaces OS-native <select> dropdown popups with 100% theme-synced glass UI.
 */
(() => {
  let activeDropdown = null;
  let activeWrapper = null;

  function closeActiveDropdown() {
    if (activeDropdown) {
      activeDropdown.classList.remove('visible');
      if (activeDropdown.parentNode) {
        activeDropdown.parentNode.removeChild(activeDropdown);
      }
      activeDropdown = null;
    }
    if (activeWrapper) {
      activeWrapper.classList.remove('open');
      activeWrapper = null;
    }
  }

  function positionDropdown(trigger, dropdown) {
    const rect = trigger.getBoundingClientRect();
    const dropdownHeight = Math.min(240, dropdown.scrollHeight || 180);
    const spaceBelow = window.innerHeight - rect.bottom;
    const spaceAbove = rect.top;

    dropdown.style.width = `${Math.max(rect.width, 180)}px`;
    dropdown.style.left = `${Math.max(4, Math.min(rect.left, window.innerWidth - rect.width - 8))}px`;

    if (spaceBelow < dropdownHeight + 10 && spaceAbove > spaceBelow) {
      // Open upwards
      dropdown.style.top = 'auto';
      dropdown.style.bottom = `${window.innerHeight - rect.top + 4}px`;
      dropdown.style.transformOrigin = 'bottom center';
    } else {
      // Open downwards
      dropdown.style.top = `${rect.bottom + 4}px`;
      dropdown.style.bottom = 'auto';
      dropdown.style.transformOrigin = 'top center';
    }
  }

  function enhanceSelect(selectEl) {
    if (!selectEl || selectEl.dataset.mfEnhanced === 'true') return;
    if (selectEl.tagName !== 'SELECT') return;

    selectEl.dataset.mfEnhanced = 'true';

    // Wrap or attach trigger
    const wrapper = document.createElement('div');
    wrapper.className = 'mf-select-wrapper';
    
    // Copy any inline styles related to flex/width
    if (selectEl.style.flex) wrapper.style.flex = selectEl.style.flex;
    if (selectEl.style.width && selectEl.style.width !== '100%') wrapper.style.width = selectEl.style.width;

    const trigger = document.createElement('div');
    trigger.className = 'mf-select-trigger';
    trigger.tabIndex = 0;
    trigger.setAttribute('role', 'combobox');
    trigger.setAttribute('aria-expanded', 'false');

    function updateTriggerText() {
      const selected = selectEl.options[selectEl.selectedIndex];
      trigger.textContent = selected ? selected.text : (selectEl.options[0]?.text || '');
    }

    updateTriggerText();

    // Insert wrapper before select, then move select into wrapper
    selectEl.parentNode.insertBefore(wrapper, selectEl);
    wrapper.appendChild(selectEl);
    wrapper.appendChild(trigger);
    selectEl.classList.add('mf-select-hidden');

    function openDropdown() {
      if (activeWrapper === wrapper) {
        closeActiveDropdown();
        return;
      }
      closeActiveDropdown();

      const dropdown = document.createElement('div');
      dropdown.className = 'mf-select-dropdown';

      // Build options from selectEl children
      Array.from(selectEl.children).forEach((child) => {
        if (child.tagName === 'OPTGROUP') {
          const groupLabel = document.createElement('div');
          groupLabel.className = 'mf-select-optgroup-label';
          groupLabel.textContent = child.label;
          dropdown.appendChild(groupLabel);

          Array.from(child.children).forEach((opt) => {
            appendOption(dropdown, opt);
          });

          const sep = document.createElement('div');
          sep.className = 'mf-select-separator';
          dropdown.appendChild(sep);
        } else if (child.tagName === 'OPTION') {
          appendOption(dropdown, child);
        }
      });

      function appendOption(parent, optionEl) {
        const item = document.createElement('div');
        item.className = 'mf-select-option';
        item.textContent = optionEl.text;
        item.dataset.value = optionEl.value;

        if (optionEl.value === selectEl.value) {
          item.classList.add('selected');
        }

        item.addEventListener('click', (e) => {
          e.stopPropagation();
          selectEl.value = optionEl.value;
          updateTriggerText();
          closeActiveDropdown();
          selectEl.dispatchEvent(new Event('change', { bubbles: true }));
          selectEl.dispatchEvent(new Event('input', { bubbles: true }));
        });

        parent.appendChild(item);
      }

      document.body.appendChild(dropdown);
      positionDropdown(trigger, dropdown);

      // Trigger reflow then visible class for animation
      void dropdown.offsetWidth;
      dropdown.classList.add('visible');
      wrapper.classList.add('open');
      trigger.setAttribute('aria-expanded', 'true');

      activeDropdown = dropdown;
      activeWrapper = wrapper;

      // Isolate wheel scrolling to dropdown so it scrolls the list without closing or scrolling background videos
      dropdown.addEventListener('wheel', (e) => {
        e.stopPropagation();
        dropdown.scrollTop += e.deltaY;
        e.preventDefault();
      }, { passive: false });

      // Scroll selected item into view
      const selectedItem = dropdown.querySelector('.mf-select-option.selected');
      if (selectedItem) {
        selectedItem.scrollIntoView({ block: 'nearest' });
      }
    }

    trigger.addEventListener('mousedown', (e) => {
      e.stopPropagation();
    });

    trigger.addEventListener('click', (e) => {
      e.stopPropagation();
      openDropdown();
    });

    trigger.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ' || e.key === 'ArrowDown') {
        e.preventDefault();
        openDropdown();
      } else if (e.key === 'Escape') {
        closeActiveDropdown();
      }
    });

    // Listen to changes triggered programmatically
    selectEl.addEventListener('change', () => {
      updateTriggerText();
    });

    // Watch for DOM changes inside select (e.g. options added/removed dynamically)
    const observer = new MutationObserver(() => {
      updateTriggerText();
    });
    observer.observe(selectEl, { childList: true, subtree: true, attributes: true });
  }

  function enhanceAllSelects() {
    const selects = document.querySelectorAll('select.select-input, select.studio-format-select, #profile-select, #format-select');
    selects.forEach((s) => {
      // Don't enhance hidden clipboard selector if tiny
      if (s.id === 'select-clipboard-format') return;
      enhanceSelect(s);
    });
  }

  // Global listeners to close dropdown on click outside or window resize
  document.addEventListener('click', (e) => {
    if (activeDropdown && !activeDropdown.contains(e.target) && !activeWrapper?.contains(e.target)) {
      closeActiveDropdown();
    }
  });

  window.addEventListener('resize', () => {
    closeActiveDropdown();
  });

  window.addEventListener('scroll', (e) => {
    if (activeDropdown && (e.target === activeDropdown || activeDropdown.contains(e.target))) {
      return;
    }
    closeActiveDropdown();
  }, true);

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeActiveDropdown();
    }
  });

  // Export to window
  window.enhanceCustomSelects = enhanceAllSelects;

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      enhanceAllSelects();
      setTimeout(enhanceAllSelects, 200);
      setTimeout(enhanceAllSelects, 600);
    });
  } else {
    enhanceAllSelects();
    setTimeout(enhanceAllSelects, 200);
    setTimeout(enhanceAllSelects, 600);
  }

  // MutationObserver for dynamically added selects (e.g. modals, playlists)
  const bodyObserver = new MutationObserver((mutations) => {
    let shouldEnhance = false;
    for (const m of mutations) {
      if (m.addedNodes.length > 0) {
        shouldEnhance = true;
        break;
      }
    }
    if (shouldEnhance) {
      enhanceAllSelects();
    }
  });
  bodyObserver.observe(document.body, { childList: true, subtree: true });
})();
