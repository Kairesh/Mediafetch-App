/**
 * YouTube Visitor Data & Token Helper for Adobe CEP Client
 */

const YouTubeTokenHelper = (() => {
    let cachedVisitorData = null;
    let lastFetched = 0;
    let isFetching = false;

    function isYouTubeUrl(url) {
        if (!url || typeof url !== 'string') return false;
        const lower = url.toLowerCase();
        return lower.includes('youtube.com') || lower.includes('youtu.be');
    }

    async function getVisitorData() {
        const age = Date.now() - lastFetched;
        if (age > 6 * 60 * 60 * 1000 && !isFetching && typeof fetch !== 'undefined') {
            refreshVisitorData().catch(() => {});
        }
        return cachedVisitorData || null;
    }

    async function refreshVisitorData() {
        if (isFetching || typeof fetch === 'undefined') return cachedVisitorData;
        isFetching = true;
        try {
            const res = await fetch('https://www.youtube.com', {
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'
                }
            });
            if (res.ok) {
                const html = await res.text();
                const match = html.match(/"VISITOR_DATA":\s*"([^"]+)"/);
                if (match && match[1]) {
                    cachedVisitorData = match[1];
                    lastFetched = Date.now();
                    return cachedVisitorData;
                }
            }
        } catch (e) {
            // Fallback silently
        } finally {
            isFetching = false;
        }
        return cachedVisitorData || null;
    }

    function getExtractorArgsSync(url) {
        const args = ['--js-runtimes', 'node', '--remote-components', 'ejs:github'];
        if (isYouTubeUrl(url)) {
            let vd = cachedVisitorData;
            if (!vd && typeof process !== 'undefined' && process.env) {
                try {
                    const _fs = typeof window !== 'undefined' && window.require ? window.require('fs') : null;
                    const _path = typeof window !== 'undefined' && window.require ? window.require('path') : null;
                    const localAppData = process.env.LOCALAPPDATA || '';
                    if (_fs && _path && localAppData) {
                        const tokenFile = _path.join(localAppData, 'MediaFetch', 'visitor_data.txt');
                        if (_fs.existsSync(tokenFile)) {
                            vd = _fs.readFileSync(tokenFile, 'utf8').trim();
                        }
                    }
                } catch (_) {}
            }
            if (vd) {
                args.push('--extractor-args', `youtube:visitor_data=${vd}`);
            }
        }
        return args;
    }

    return {
        isYouTubeUrl,
        getVisitorData,
        refreshVisitorData,
        getExtractorArgsSync
    };
})();

if (typeof module !== 'undefined' && module.exports) {
    module.exports = YouTubeTokenHelper;
}
