import { IHostAdapter, HostImportOptions } from './adapter-interface.js';
import { ProjectContext } from '../common/types.js';
import { getHostAppId } from './host-detector.js';
import { AfterEffectsHostAdapter } from './ae-adapter.js';

export class PremiereHostAdapter implements IHostAdapter {
  private themeListeners: ((theme: string) => void)[] = [];

  public async getProjectContext(): Promise<ProjectContext> {
    if (typeof getHostAppId === 'function' && getHostAppId() === 'aeft') {
      return new AfterEffectsHostAdapter().getProjectContext();
    }
    try {
      // 1. Try preloaded MediaFetchHost.getHostInfo() ExtendScript bridge first
      const hostInfoResult = await this.evalScript('MediaFetchHost.getHostInfo()');
      if (hostInfoResult && typeof hostInfoResult === 'string' && hostInfoResult !== 'EvalScript error.') {
        try {
          const parsedHost = JSON.parse(hostInfoResult);
          if (parsedHost && parsedHost.projectPath && parsedHost.projectPath.length > 0) {
            const cleanPath = parsedHost.projectPath.replace(/\\/g, '/');
            const dir = cleanPath.substring(0, cleanPath.lastIndexOf('/'));
            const name = parsedHost.projectName || cleanPath.substring(cleanPath.lastIndexOf('/') + 1) || 'Premiere Project';
            return {
              application: 'premierepro',
              applicationVersion: parsedHost.appVersion || '26.0',
              projectSaved: true,
              projectName: name,
              projectPath: parsedHost.projectPath,
              projectDirectory: dir.replace(/\//g, '\\')
            };
          }
        } catch (_) {}
      }

      // 2. Direct ExtendScript fallback
      const script = `
        (function() {
          try {
            if (app && app.project) {
              var pPath = "";
              if (app.project.path && app.project.path.length > 0) {
                pPath = app.project.path;
              } else if (app.project.documentPath && app.project.documentPath.length > 0) {
                pPath = app.project.documentPath;
              }

              if (pPath && pPath.length > 0) {
                return JSON.stringify({
                  saved: true,
                  path: pPath,
                  name: app.project.name || "Premiere Project",
                  version: app.version || "26.0"
                });
              } else {
                return JSON.stringify({
                  saved: false,
                  name: "Active Premiere Project (Unsaved)",
                  version: app.version || "26.0"
                });
              }
            }
          } catch (err) {
            return JSON.stringify({ saved: false, error: String(err) });
          }
          return JSON.stringify({ saved: false });
        })();
      `;

      const result = await this.evalScript(script);
      if (result && typeof result === 'string' && result !== 'EvalScript error.') {
          const parsed = JSON.parse(result);
          if (parsed) {
            if (parsed.saved && parsed.path) {
              const cleanPath = parsed.path.replace(/\\/g, '/');
              const dir = cleanPath.substring(0, cleanPath.lastIndexOf('/'));
              const name = cleanPath.substring(cleanPath.lastIndexOf('/') + 1) || parsed.name;
              return {
                application: 'premierepro',
                applicationVersion: parsed.version || '26.0',
                projectSaved: true,
                projectName: name,
                projectPath: parsed.path,
                projectDirectory: dir.replace(/\//g, '\\')
              };
            } else if (parsed.name) {
              return {
                application: 'premierepro',
                applicationVersion: parsed.version || '26.0',
                projectSaved: false,
                projectName: parsed.name
              };
            }
          }
      }
    } catch (e) {
      console.warn('Error reading Premiere Pro project context:', e);
    }

    return {
      application: 'premierepro',
      applicationVersion: '26.0',
      projectSaved: false
    };
  }

  public async revealInFinder(filePath: string): Promise<void> {
    try {
      if (typeof window !== 'undefined' && (window as any).require) {
        const cp = (window as any).require('child_process');
        if (cp?.exec) {
          cp.exec(`explorer.exe /select,"${filePath.replace(/\//g, '\\')}"`);
          return;
        }
      }
    } catch {}

    try {
      const script = `
        (function() {
          var f = new File("${filePath.replace(/\\/g, '/')}");
          if (f.exists) {
            f.execute();
          }
        })();
      `;
      await this.evalScript(script);
    } catch {}
  }

  public async openFile(filePath: string): Promise<void> {
    await this.revealInFinder(filePath);
  }

  public async importToProject(filePath: string, options?: HostImportOptions): Promise<boolean> {
    if (typeof getHostAppId === 'function' && getHostAppId() === 'aeft') {
      return new AfterEffectsHostAdapter().importToProject(filePath, options);
    }
    try {
      const cleanPath = filePath.replace(/\\/g, '/');
      const isCustom = options?.isCustomPath ? true : false;
      const isSimple = Boolean(options?.isSimplePath || options?.isSimple);
      const isCloud = options?.isCloud ? true : false;
      const isPlaylist = options?.isPlaylist ? true : false;
      const isBatch = options?.isBatch ? true : false;
      const isSingleLink = options?.isSingleLink !== undefined ? options.isSingleLink : (!isPlaylist && !isCloud && !isBatch);
      const shouldInsertTimeline = Boolean(options?.insertToTimeline && isSingleLink);
      const playlistTitle = (options?.playlistTitle || '').replace(/[\\/:"*?<>|]/g, ' ').trim();
      const customFolderName = (options?.customFolderName || '').replace(/[\\/:"*?<>|]/g, ' ').trim();
      const subFolderName = (options?.subFolderName || '').trim();
      const isClipboard = Boolean(options?.isClipboard || cleanPath.includes('Clipboard'));

      const optsJson = JSON.stringify({
        isCustomPath: isCustom,
        isSimplePath: isSimple,
        isSimple: isSimple,
        isCloud,
        isPlaylist,
        isBatch,
        isSingleLink,
        playlistTitle,
        customFolderName,
        subFolderName,
        isClipboard,
        addToTimeline: shouldInsertTimeline,
        insertToTimeline: shouldInsertTimeline
      });

      try {
        const evalResStr = await this.evalScript(`MediaFetchHost.importMedia(${JSON.stringify(cleanPath)}, ${shouldInsertTimeline ? 'true' : 'false'}, ${JSON.stringify(optsJson)})`);
        if (evalResStr && evalResStr !== 'EvalScript error.') {
          try {
            const parsed = JSON.parse(evalResStr);
            if (parsed && parsed.success && parsed.imported !== false) {
              console.log('[MediaFetch] HostScript importMedia succeeded:', parsed);
              return true;
            }
          } catch (_) {
            if (evalResStr === 'true' || evalResStr === true) return true;
          }
        }
      } catch (hErr) {
        console.warn('[MediaFetch] MediaFetchHost.importMedia attempt notice:', hErr);
      }

      const script = `
        (function() {
          try {
            if (!app || !app.project) return "no_project";
            var project = app.project;
            var root = project.rootItem;
            
            function getOrCreateBin(parentBin, binName) {
              if (!parentBin || !parentBin.children) return null;
              for (var i = 0; i < parentBin.children.numItems; i++) {
                var item = parentBin.children[i];
                if (item && item.type === 2 && item.name === binName) {
                  return item;
                }
              }
              try { return parentBin.createBin(binName); } catch (binErr) { return null; }
            }

            var targetPath = "${cleanPath}";
            var isCustom = ${isCustom ? 'true' : 'false'};
            var isCloud = ${isCloud ? 'true' : 'false'};
            var isPlaylist = ${isPlaylist ? 'true' : 'false'};
            var playlistTitle = "${playlistTitle.replace(/"/g, '\\"')}";
            var customFolderName = "${customFolderName.replace(/"/g, '\\"')}";
            var subFolderName = "${subFolderName.replace(/"/g, '\\"').replace(/\\/g, '/')}";

            var targetBin = null;

            if (isCustom) {
              // Custom Directory: create root bin outside MediaFetch named after the selected custom folder
              var rootBinName = customFolderName || (isPlaylist ? (playlistTitle || "Playlist") : (isCloud ? "Cloud Media" : ""));
              if (!rootBinName) {
                var pParts = targetPath.split('/');
                rootBinName = pParts.length > 1 ? pParts[pParts.length - 2] : "Downloads";
              }
              var customRootBin = getOrCreateBin(root, rootBinName);
              if (subFolderName) {
                var sParts = subFolderName.split('/');
                var cur = customRootBin;
                for (var s = 0; s < sParts.length; s++) {
                  if (sParts[s] && sParts[s].length > 0) {
                    cur = getOrCreateBin(cur, sParts[s]);
                  }
                }
                targetBin = cur || customRootBin;
              } else {
                targetBin = customRootBin;
              }
            } else {
              // Default Project Path: inside root "MediaFetch" bin
              var mediaFetchBin = getOrCreateBin(root, "MediaFetch");

              if (isCloud) {
                // MediaFetch -> Cloud Links -> [Cloud Folder Name] -> [Subfolders]
                var cloudRootBin = getOrCreateBin(mediaFetchBin, "Cloud Links");
                var cloudFolderBin = getOrCreateBin(cloudRootBin, customFolderName || "Cloud Media");
                if (subFolderName) {
                  var sParts = subFolderName.split('/');
                  var cur = cloudFolderBin;
                  for (var s = 0; s < sParts.length; s++) {
                    if (sParts[s] && sParts[s].length > 0) {
                      cur = getOrCreateBin(cur, sParts[s]);
                    }
                  }
                  targetBin = cur || cloudFolderBin;
                } else {
                  targetBin = cloudFolderBin;
                }
              } else if (isPlaylist) {
                // MediaFetch -> Playlists -> [Playlist Name]
                var playlistRootBin = getOrCreateBin(mediaFetchBin, "Playlists");
                var pName = playlistTitle || customFolderName || "Playlist 1";
                targetBin = getOrCreateBin(playlistRootBin, pName);
              } else {
                // Single link or Search or Clipboard
                var isClipboard = ${isClipboard ? 'true' : 'false'} || targetPath.indexOf("Clipboard") !== -1;
                var isSearch = targetPath.indexOf("SerachMediafetch") !== -1 || 
                               targetPath.indexOf("MediaFetch Assets") !== -1 || 
                               targetPath.indexOf("MediaSearch Assets") !== -1;
                var categoryBinName = isClipboard ? "Clipboard" : (isSearch ? "SerachMediafetch" : "LinkMediaFetch");
                var categoryBin = getOrCreateBin(mediaFetchBin, categoryBinName);

                var parts = targetPath.split('.');
                var ext = parts.length > 1 ? parts[parts.length - 1].toLowerCase().split('?')[0] : '';
                var isAudio = (ext === 'mp3' || ext === 'wav' || ext === 'm4a' || ext === 'flac' || ext === 'aac' || ext === 'ogg' || ext === 'opus' || ext === 'aiff');
                var isImage = (ext === 'jpg' || ext === 'jpeg' || ext === 'png' || ext === 'webp' || ext === 'gif' || ext === 'bmp' || ext === 'tiff' || ext === 'tif' || ext === 'svg');
                var typeBinName = isAudio ? "Audio" : (isImage ? "Images" : "Video");
                targetBin = getOrCreateBin(categoryBin, typeBinName) || categoryBin;
              }
            }

            if (!targetBin) targetBin = root;

            // Check if file is already imported in targetBin to avoid duplicates (unless timeline insertion requested)
            if (!${shouldInsertTimeline ? 'true' : 'false'}) {
              if (targetBin && targetBin.children) {
                for (var k = 0; k < targetBin.children.numItems; k++) {
                  var ch = targetBin.children[k];
                  try {
                    if (ch && ch.getMediaPath && (ch.getMediaPath() === targetPath || ch.getMediaPath() === "${filePath.replace(/\\/g, '\\\\')}")) {
                      return "true";
                    }
                  } catch (_) {}
                }
              }
            }

            var mediaF = new File(targetPath);
            var nativePath = mediaF.fsName;
            var cleanPath = targetPath.replace(/\\/g, '/');
            var cleanNorm = cleanPath.toLowerCase();
            var nativeNorm = nativePath.toLowerCase();
            var fileNameOnly = targetPath.split('/').pop().toLowerCase();
            var baseNameOnly = fileNameOnly.replace(/\.[^/.]+$/, "");

            function matchItem(ci) {
              if (!ci || ci.type === 2) return false;
              try {
                if (ci.getMediaPath) {
                  var mp = ci.getMediaPath().replace(/\\/g, '/').toLowerCase();
                  if (mp === cleanNorm || mp === nativeNorm || (baseNameOnly && mp.indexOf(baseNameOnly) !== -1)) {
                    return true;
                  }
                }
              } catch (_) {}
              try {
                if (ci.name) {
                  var nLow = ci.name.toLowerCase();
                  if (nLow === fileNameOnly || nLow === baseNameOnly || (baseNameOnly && nLow.indexOf(baseNameOnly) !== -1)) {
                    return true;
                  }
                }
              } catch (_) {}
              return false;
            }

            function scanBin(bin) {
              if (!bin || !bin.children) return null;
              for (var i = 0; i < bin.children.numItems; i++) {
                var it = bin.children[i];
                if (!it) continue;
                if (it.type !== 2) {
                  if (matchItem(it)) return it;
                } else if (it.type === 2) {
                  var f = scanBin(it);
                  if (f) return f;
                }
              }
              return null;
            }

            try {
              if (targetBin && typeof targetBin.select === 'function') {
                try { targetBin.select(); } catch (_) {}
              }
              project.importFiles([nativePath], true, targetBin, false);
            } catch (_) {
              try {
                project.importFiles([cleanPath], true, targetBin, false);
              } catch (_) {
                try {
                  project.importFiles([nativePath], 1, targetBin, 0);
                } catch (_) {
                  try {
                    project.importFiles([cleanPath], 1, targetBin, 0);
                  } catch (_) {}
                }
              }
            }

            var targetItem = scanBin(targetBin) || scanBin(root);

            if (!targetItem) {
              try {
                project.importFiles([nativePath], true, root, false);
              } catch (_) {
                try {
                  project.importFiles([cleanPath], true, root, false);
                } catch (_) {
                  try {
                    project.importFiles([nativePath], 1, root, 0);
                  } catch (_) {
                    try {
                      project.importFiles([cleanPath], 1, root, 0);
                    } catch (_) {}
                  }
                }
              }
              targetItem = scanBin(root) || scanBin(targetBin);
            }

            if (!targetItem) {
              try { $.sleep(120); } catch (_) {}
              targetItem = scanBin(targetBin) || scanBin(root);
            }

            if (!targetItem && targetBin && targetBin.children && targetBin.children.numItems > 0) {
              for (var bi = targetBin.children.numItems - 1; bi >= 0; bi--) {
                var cItem = targetBin.children[bi];
                if (cItem && cItem.type !== 2) {
                  targetItem = cItem;
                  break;
                }
              }
            }
            if (!targetItem && root && root.children && root.children.numItems > 0) {
              for (var ri = root.children.numItems - 1; ri >= 0; ri--) {
                var rItem = root.children[ri];
                if (rItem && rItem.type !== 2) {
                  targetItem = rItem;
                  break;
                }
              }
            }

            // Move item into targetBin if it was imported to root
            if (targetItem && targetBin && targetBin !== root) {
              try {
                if (typeof targetItem.moveBin === 'function') {
                  targetItem.moveBin(targetBin);
                }
              } catch (_) {}
            }

            var success = Boolean(targetItem);

            if (success) {

                if (targetItem && ${shouldInsertTimeline ? 'true' : 'false'}) {
                  var sName = targetItem.name || "MediaFetch Timeline";
                  var insertedToSeq = false;
                  var aSeq = project.activeSequence;

                  function getTargetVideoTrack(seq, playheadTime) {
                    if (!seq || !seq.videoTracks || seq.videoTracks.numTracks === 0) return null;
                    var numTracks = seq.videoTracks.numTracks;
                    for (var t = 0; t < numTracks; t++) {
                      var trk = seq.videoTracks[t];
                      if (trk && trk.clips && trk.clips.numItems === 0) return trk;
                    }
                    var pSec = (playheadTime && playheadTime.seconds !== undefined) ? playheadTime.seconds : (parseFloat(playheadTime) || 0);
                    for (var t2 = numTracks - 1; t2 >= 0; t2--) {
                      var trk2 = seq.videoTracks[t2];
                      if (!trk2 || !trk2.clips) continue;
                      var collision = false;
                      for (var c = 0; c < trk2.clips.numItems; c++) {
                        var cl = trk2.clips[c];
                        if (cl && cl.start && cl.end && cl.start.seconds <= pSec && cl.end.seconds > pSec) {
                          collision = true;
                          break;
                        }
                      }
                      if (!collision) return trk2;
                    }
                    return seq.videoTracks[numTracks - 1];
                  }

                  function getTargetAudioTrack(seq, playheadTime) {
                    if (!seq || !seq.audioTracks || seq.audioTracks.numTracks === 0) return null;
                    var numTracks = seq.audioTracks.numTracks;
                    for (var t = 0; t < numTracks; t++) {
                      var trk = seq.audioTracks[t];
                      if (trk && trk.clips && trk.clips.numItems === 0) return trk;
                    }
                    var pSec = (playheadTime && playheadTime.seconds !== undefined) ? playheadTime.seconds : (parseFloat(playheadTime) || 0);
                    for (var t2 = numTracks - 1; t2 >= 0; t2--) {
                      var trk2 = seq.audioTracks[t2];
                      if (!trk2 || !trk2.clips) continue;
                      var collision = false;
                      for (var c = 0; c < trk2.clips.numItems; c++) {
                        var cl = trk2.clips[c];
                        if (cl && cl.start && cl.end && cl.start.seconds <= pSec && cl.end.seconds > pSec) {
                          collision = true;
                          break;
                        }
                      }
                      if (!collision) return trk2;
                    }
                    return seq.audioTracks[numTracks - 1];
                  }

                  // 1. Insert directly into active sequence timeline at playhead position
                  if (aSeq) {
                    var pPos = aSeq.getPlayerPosition();
                    if (isAudio) {
                      var aTrk = getTargetAudioTrack(aSeq, pPos);
                      if (aTrk) {
                        try {
                          aTrk.insertClip(targetItem, pPos);
                          insertedToSeq = true;
                        } catch (_) {
                          try {
                            if (typeof aTrk.overwriteClip === "function") {
                              aTrk.overwriteClip(targetItem, pPos);
                              insertedToSeq = true;
                            }
                          } catch (_) {}
                        }
                      }
                    } else {
                      var vTrk = getTargetVideoTrack(aSeq, pPos);
                      if (vTrk) {
                        try {
                          vTrk.insertClip(targetItem, pPos);
                          insertedToSeq = true;
                        } catch (_) {
                          try {
                            if (typeof vTrk.overwriteClip === "function") {
                              vTrk.overwriteClip(targetItem, pPos);
                              insertedToSeq = true;
                            }
                          } catch (_) {}
                        }
                      }
                    }
                  }

                  // 2. Fallback: if no active sequence, create one
                  if (!insertedToSeq) {
                    if (typeof project.createNewSequenceFromClips === "function") {
                      var ns = project.createNewSequenceFromClips(sName, [targetItem], targetBin);
                      if (ns) {
                        insertedToSeq = true;
                        if (project.openSequence) project.openSequence(ns.sequenceID);
                      }
                    }
                  }
                }
              } catch (_) {}
            }
            return success ? "true" : "false";
          } catch (err) {
            return "error: " + err;
          }
        })();
      `;
      const res = await this.evalScript(script);
      console.log('[Premiere importToProject result]:', res);
      return res === 'true' || res === true;
    } catch {
      return false;
    }
  }

  public getHostTheme(): 'dark' | 'light' | 'darkest' | 'lightest' {
    if (typeof window !== 'undefined' && (window as any).__adobe_cep__) {
      try {
        const skin = (window as any).__adobe_cep__.getHostEnvironment()?.appSkinInfo;
        if (skin?.panelBackgroundColor?.color) {
          const r = skin.panelBackgroundColor.color.red;
          if (r < 50) return 'darkest';
          if (r < 100) return 'dark';
          if (r > 200) return 'lightest';
          return 'light';
        }
      } catch {}
    }
    return 'dark';
  }

  public onThemeChanged(callback: (theme: string) => void): void {
    this.themeListeners.push(callback);
    if (typeof window !== 'undefined' && (window as any).__adobe_cep__) {
      try {
        (window as any).__adobe_cep__.addEventListener('com.adobe.csxs.events.ThemeChanged', () => {
          callback(this.getHostTheme());
        });
      } catch {}
    }
  }

  private evalScript(script: string): Promise<any> {
    return new Promise((resolve) => {
      let resolved = false;
      const timer = setTimeout(() => {
        if (!resolved) {
          resolved = true;
          resolve(null);
        }
      }, 4000);

      try {
        if (typeof window !== 'undefined' && (window as any).__adobe_cep__) {
          (window as any).__adobe_cep__.evalScript(script, (result: any) => {
            if (!resolved) {
              resolved = true;
              clearTimeout(timer);
              resolve(result);
            }
          });
          return;
        }
        if (typeof window !== 'undefined' && (window as any).CSInterface) {
          const cs = new (window as any).CSInterface();
          cs.evalScript(script, (result: any) => {
            if (!resolved) {
              resolved = true;
              clearTimeout(timer);
              resolve(result);
            }
          });
          return;
        }
      } catch (e) {
        console.warn('evalScript error:', e);
      }
      if (!resolved) {
        resolved = true;
        clearTimeout(timer);
        resolve(null);
      }
    });
  }
}
