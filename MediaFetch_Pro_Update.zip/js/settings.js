/**
 * MediaFetch & MediaSearch Settings Manager
 * Shared persistence across Adobe Premiere Pro and After Effects
 */
const Settings = (function () {
    const STORAGE_KEY = "mediafetch_search_settings";

    // Known legacy author/default keys to clean out completely
    const BANNED_LEGACY_KEYS = [
        "10547590-561862cf80d7e34284c5268bc",
        "23107835-0a6cc5a60b0978cc4eff8e5fa",
        "45972822",
        "nJhYrM3NMjdfzgsR092DY9sUSpWiYU2iXmbsAwnDLJHDxxp9F6vKwBnE",
        "563492ad6f91700001000001dfa1f8db1f344df3bbbc9e829d592652",
        "_Lo9ruec1rqQ_-ERrp_NHgqbfBdANyAzPYaSLwGdXh0",
        "k_U-aYk3j5Vz",
        "sXpGFDGZs0Dv1mmNFvYaGUvYwKX0P4W5"
    ];

    const defaultSettings = {
        // User-entered personal API keys (empty by default)
        pixabayApiKey: "",
        pixabayBackupApiKey: "",
        pexelsApiKey: "",
        unsplashApiKey: "",
        giphyApiKey: "",
        jamendoClientId: "",

        // Default Preferences
        downloadFolder: "", // Empty = use active project folder / default
        autoInsertTimeline: true,
        defaultVideoQuality: "1080p", // 4k, 1080p, 720p, audio-only
        defaultImageQuality: "high", // original, high, medium
        theme: "darkest",
        iconTheme: "core", // core, duotone, glass
        previewSoundVolume: 0.7,
        pausePreviewOnTabChange: false
    };

    function getSharedFilePath() {
        try {
            if (typeof process !== "undefined" && process.env) {
                const fs = (typeof window !== "undefined" && window.require) ? window.require("fs") : (typeof require !== "undefined" ? require("fs") : null);
                const path = (typeof window !== "undefined" && window.require) ? window.require("path") : (typeof require !== "undefined" ? require("path") : null);
                if (fs && path) {
                    const baseDir = process.env.LOCALAPPDATA || process.env.APPDATA || (process.env.HOME ? path.join(process.env.HOME, "Library", "Application Support") : "");
                    if (baseDir) {
                        const targetDir = path.join(baseDir, "MediaFetch");
                        if (!fs.existsSync(targetDir)) {
                            try { fs.mkdirSync(targetDir, { recursive: true }); } catch (_) {}
                        }
                        return path.join(targetDir, "user_api_settings.json");
                    }
                }
            }
        } catch (_) {}
        return null;
    }

    function sanitizeKey(val) {
        if (!val || typeof val !== "string") return "";
        const trimmed = val.trim();
        for (let i = 0; i < BANNED_LEGACY_KEYS.length; i++) {
            if (trimmed === BANNED_LEGACY_KEYS[i] || trimmed.indexOf(BANNED_LEGACY_KEYS[i]) !== -1) {
                return "";
            }
        }
        return trimmed;
    }

    function loadFromDisk() {
        const filePath = getSharedFilePath();
        if (!filePath) return null;
        try {
            const fs = (typeof window !== "undefined" && window.require) ? window.require("fs") : (typeof require !== "undefined" ? require("fs") : null);
            if (fs && fs.existsSync(filePath)) {
                const raw = fs.readFileSync(filePath, "utf8");
                if (raw) return JSON.parse(raw);
            }
        } catch (_) {}
        return null;
    }

    function saveToDisk(data) {
        const filePath = getSharedFilePath();
        if (!filePath) return;
        try {
            const fs = (typeof window !== "undefined" && window.require) ? window.require("fs") : (typeof require !== "undefined" ? require("fs") : null);
            if (fs) {
                fs.writeFileSync(filePath, JSON.stringify(data, null, 2), "utf8");
            }
        } catch (_) {}
    }

    function load() {
        let parsed = {};
        try {
            const raw = localStorage.getItem(STORAGE_KEY);
            if (raw) parsed = JSON.parse(raw) || {};
        } catch (_) {}

        // Check shared disk file so AE and PR always stay synced
        const diskSettings = loadFromDisk();
        if (diskSettings && typeof diskSettings === "object") {
            parsed = Object.assign({}, parsed, diskSettings);
        }

        // Cleanse legacy author keys
        parsed.pixabayApiKey = sanitizeKey(parsed.pixabayApiKey);
        parsed.pixabayBackupApiKey = sanitizeKey(parsed.pixabayBackupApiKey);
        parsed.pexelsApiKey = sanitizeKey(parsed.pexelsApiKey);
        parsed.unsplashApiKey = sanitizeKey(parsed.unsplashApiKey);
        parsed.giphyApiKey = sanitizeKey(parsed.giphyApiKey);

        return Object.assign({}, defaultSettings, parsed);
    }

    function save(newSettings) {
        try {
            const current = load();
            const updated = Object.assign({}, current, newSettings);

            // Cleanse keys before persisting
            updated.pixabayApiKey = sanitizeKey(updated.pixabayApiKey);
            updated.pixabayBackupApiKey = sanitizeKey(updated.pixabayBackupApiKey);
            updated.pexelsApiKey = sanitizeKey(updated.pexelsApiKey);
            updated.unsplashApiKey = sanitizeKey(updated.unsplashApiKey);
            updated.giphyApiKey = sanitizeKey(updated.giphyApiKey);

            try {
                localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
            } catch (_) {}

            // Save to shared disk file so other host apps (AE/PR) read it instantly
            saveToDisk(updated);

            return updated;
        } catch (e) {
            console.error("Failed to save settings:", e);
            return load();
        }
    }

    function get(key) {
        const s = load();
        return s[key] !== undefined ? s[key] : defaultSettings[key];
    }

    function set(key, value) {
        const obj = {};
        obj[key] = value;
        return save(obj);
    }

    return {
        load: load,
        save: save,
        get: get,
        set: set,
        defaults: defaultSettings
    };
})();

if (typeof module !== "undefined" && module.exports) {
    module.exports = Settings;
} else {
    window.Settings = Settings;
}
