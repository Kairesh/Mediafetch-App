/**
 * MediaFetch & MediaSearch Settings Manager
 * Shared persistence across Adobe Premiere Pro and After Effects
 */
const Settings = (function () {
    const STORAGE_KEY = "mediafetch_search_settings";

    // Known legacy author/default keys to clean out completely
    const BANNED_LEGACY_KEYS = [
        "10547590-561862cf80d7e34284c5268bc",
        "23107835-0a6cc5a60b0978cc4eff8e5fa",
        "45972822",
        "nJhYrM3NMjdfzgsR092DY9sUSpWiYU2iXmbsAwnDLJHDxxp9F6vKwBnE",
        "563492ad6f91700001000001dfa1f8db1f344df3bbbc9e829d592652",
        "_Lo9ruec1rqQ_-ERrp_NHgqbfBdANyAzPYaSLwGdXh0",
        "k_U-aYk3j5Vz",
        "sXpGFDGZs0Dv1mmNFvYaGUvYwKX0P4W5"
    ];

    const defaultSettings = {
        // User-entered personal API keys (empty by default)
        pixabayApiKey: "",
        pixabayBackupApiKey: "",
        pexelsApiKey: "",
        unsplashApiKey: "",
        giphyApiKey: "",
        jamendoClientId: "",
        spotifyClientId: "",
        spotifyClientSecret: "",

        // Default Preferences
        downloadFolder: "", // Empty = use active project folder / default
        autoInsertTimeline: true,
        defaultVideoQuality: "1080p", // 4k, 1080p, 720p, audio-only
        defaultImageQuality: "high", // original, high, medium
        theme: "darkest",
        iconTheme: "core", // core, duotone, glass
        previewSoundVolume: 0.7,
        pausePreviewOnTabChange: false,

        // Cross-Application UI & Theme Sync (Premiere Pro & After Effects)
        glassTheme: "core",
        customThemeColor: "#0A84FF",
        ambientEnabled: true,
        ambientPreset: "crimson",
        ambientC1: "#0A84FF",
        ambientC2: "#E11D48",
        ambientCustomPresets: [],
        lowRamMode: false,
        preLowRamGlassTheme: "frosted",
        preLowRamAmbientEnabled: true,
        preLowRamAmbientPreset: "crimson",
        preLowRamAmbientC1: "#0A84FF",
        preLowRamAmbientC2: "#E11D48",
        downloadLocationMode: "simple",
        customLocation: "",
        autoImportToProject: true
    };

    function getNodeRequire() {
        if (typeof window !== "undefined") {
            if (window.require) return window.require;
            if (window.cep_node && window.cep_node.require) return window.cep_node.require;
        }
        if (typeof require !== "undefined") return require;
        return null;
    }

    function getSharedFilePath() {
        try {
            const _req = getNodeRequire();
            if (!_req) return null;
            const fs = _req("fs");
            const path = _req("path");
            let proc = typeof process !== "undefined" ? process : null;
            if (!proc) {
                try { proc = _req("process"); } catch (_) {}
            }
            const env = (proc && proc.env) ? proc.env : {};
            let baseDir = env.LOCALAPPDATA || env.APPDATA;
            if (!baseDir) {
                try {
                    const os = _req("os");
                    const home = os ? os.homedir() : "";
                    if (home) {
                        if (proc && proc.platform === "darwin") {
                            baseDir = path.join(home, "Library", "Application Support");
                        } else {
                            baseDir = path.join(home, "AppData", "Local");
                        }
                    }
                } catch (_) {}
            }
            if (fs && path && baseDir) {
                const targetDir = path.join(baseDir, "MediaFetch");
                if (!fs.existsSync(targetDir)) {
                    try { fs.mkdirSync(targetDir, { recursive: true }); } catch (_) {}
                }
                return path.join(targetDir, "user_api_settings.json");
            }
        } catch (_) {}
        return null;
    }

    function sanitizeKey(val) {
        if (!val || typeof val !== "string") return "";
        const trimmed = val.trim();
        for (let i = 0; i < BANNED_LEGACY_KEYS.length; i++) {
            if (trimmed === BANNED_LEGACY_KEYS[i] || trimmed.indexOf(BANNED_LEGACY_KEYS[i]) !== -1) {
                return "";
            }
        }
        return trimmed;
    }

    function loadFromDisk() {
        const filePath = getSharedFilePath();
        if (!filePath) return null;
        try {
            const _req = getNodeRequire();
            const fs = _req ? _req("fs") : null;
            if (fs && fs.existsSync(filePath)) {
                const raw = fs.readFileSync(filePath, "utf8");
                if (raw) return JSON.parse(raw);
            }
        } catch (_) {}
        return null;
    }

    function saveToDisk(data) {
        const filePath = getSharedFilePath();
        if (!filePath) return;
        try {
            const _req = getNodeRequire();
            const fs = _req ? _req("fs") : null;
            if (fs) {
                fs.writeFileSync(filePath, JSON.stringify(data, null, 2), "utf8");
            }
        } catch (_) {}
    }

    function load() {
        let parsed = {};
        try {
            const raw = localStorage.getItem(STORAGE_KEY);
            if (raw) parsed = JSON.parse(raw) || {};
        } catch (_) {}

        // Check shared disk file so AE and PR always stay synced
        const diskSettings = loadFromDisk();
        if (diskSettings && typeof diskSettings === "object") {
            parsed = Object.assign({}, parsed, diskSettings);
        }

        // Check daemon settings.json if location mode not explicitly configured
        if (!parsed.downloadLocationMode || parsed.downloadLocationMode === 'simple') {
            try {
                const _req = getNodeRequire();
                const fs = _req ? _req("fs") : null;
                const path = _req ? _req("path") : null;
                const sharedPath = getSharedFilePath();
                if (fs && path && sharedPath) {
                    const daemonSettingsPath = path.join(path.dirname(sharedPath), "settings.json");
                    if (fs.existsSync(daemonSettingsPath)) {
                        const rawDaemon = JSON.parse(fs.readFileSync(daemonSettingsPath, "utf8"));
                        if (rawDaemon && rawDaemon.downloads && rawDaemon.downloads.downloadLocationMode) {
                            parsed.downloadLocationMode = rawDaemon.downloads.downloadLocationMode;
                            if (rawDaemon.downloads.customLocation) {
                                parsed.customLocation = rawDaemon.downloads.customLocation;
                            }
                        }
                    }
                }
            } catch (_) {}
        }

        // Cleanse legacy author keys
        parsed.pixabayApiKey = sanitizeKey(parsed.pixabayApiKey);
        parsed.pixabayBackupApiKey = sanitizeKey(parsed.pixabayBackupApiKey);
        parsed.pexelsApiKey = sanitizeKey(parsed.pexelsApiKey);
        parsed.unsplashApiKey = sanitizeKey(parsed.unsplashApiKey);
        parsed.giphyApiKey = sanitizeKey(parsed.giphyApiKey);
        parsed.spotifyClientId = sanitizeKey(parsed.spotifyClientId);
        if (parsed.downloadLocationMode === 'project') {
            parsed.downloadLocationMode = 'simple';
        }

        return Object.assign({}, defaultSettings, parsed);
    }

    function save(newSettings) {
        try {
            const current = load();
            const updated = Object.assign({}, current, newSettings);

            // Cleanse keys before persisting
            updated.pixabayApiKey = sanitizeKey(updated.pixabayApiKey);
            updated.pixabayBackupApiKey = sanitizeKey(updated.pixabayBackupApiKey);
            updated.pexelsApiKey = sanitizeKey(updated.pexelsApiKey);
            updated.unsplashApiKey = sanitizeKey(updated.unsplashApiKey);
            updated.giphyApiKey = sanitizeKey(updated.giphyApiKey);
            updated.spotifyClientId = sanitizeKey(updated.spotifyClientId);
            updated.spotifyClientSecret = sanitizeKey(updated.spotifyClientSecret);

            try {
                localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
            } catch (_) {}

            // Save to shared disk file so other host apps (AE/PR) read it instantly
            saveToDisk(updated);

            return updated;
        } catch (e) {
            console.error("Failed to save settings:", e);
            return load();
        }
    }

    function get(key) {
        const s = load();
        return s[key] !== undefined ? s[key] : defaultSettings[key];
    }

    function set(key, value) {
        const obj = {};
        obj[key] = value;
        return save(obj);
    }

    function getSharedFileMtime() {
        const filePath = getSharedFilePath();
        if (!filePath) return 0;
        try {
            const _req = getNodeRequire();
            const fs = _req ? _req("fs") : null;
            if (fs && fs.existsSync(filePath)) {
                const stat = fs.statSync(filePath);
                return (stat.mtimeMs || (stat.mtime ? stat.mtime.getTime() : 0) || 0);
            }
        } catch (_) {}
        return 0;
    }

    return {
        load: load,
        save: save,
        get: get,
        set: set,
        defaults: defaultSettings,
        getLastModified: getSharedFileMtime
    };
})();

if (typeof module !== "undefined" && module.exports) {
    module.exports = Settings;
} else {
    window.Settings = Settings;
}
