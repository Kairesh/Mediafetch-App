/**
 * MediaSearch Unified Network Requester
 * Uses Node.js https/http inside Adobe CEP to completely bypass CORS restrictions.
 */
const Net = (function () {
    const isNode = (typeof window !== "undefined" && !!window.require) || (typeof process !== "undefined" && !!process.versions?.node);
    let https = null;
    let http = null;
    let zlib = null;
    let httpsAgent = null;
    let httpAgent = null;

    if (isNode) {
        try {
            const reqFn = (typeof window !== "undefined" && window.require) ? window.require : require;
            https = reqFn("https");
            http = reqFn("http");
            zlib = reqFn("zlib");
            if (https && https.Agent) {
                httpsAgent = new https.Agent({ keepAlive: true, maxSockets: 50, keepAliveMsecs: 30000 });
            }
            if (http && http.Agent) {
                httpAgent = new http.Agent({ keepAlive: true, maxSockets: 50, keepAliveMsecs: 30000 });
            }
        } catch (e) {
            console.warn("Net: Node https/http module unavailable", e);
        }
    }

    function request(urlStr, options = {}) {
        if (isNode && https && http) {
            return new Promise((resolve, reject) => {
                try {
                    const u = new URL(urlStr);
                    const isHttps = u.protocol === "https:";
                    const client = isHttps ? https : http;
                    const agent = isHttps ? httpsAgent : httpAgent;
                    const reqOptions = {
                        hostname: u.hostname,
                        port: u.port || (isHttps ? 443 : 80),
                        path: u.pathname + u.search,
                        method: options.method || "GET",
                        agent: agent,
                        headers: Object.assign({
                            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                            "Accept": "application/json, text/plain, text/html, */*",
                            "Accept-Encoding": zlib ? "gzip, deflate" : "identity"
                        }, options.headers || {})
                    };

                    if (options.body && !reqOptions.headers["Content-Length"]) {
                        const bodyStr = typeof options.body === "string" ? options.body : JSON.stringify(options.body);
                        reqOptions.headers["Content-Length"] = Buffer.byteLength(bodyStr);
                    }

                    const req = client.request(reqOptions, (res) => {
                        // Follow standard redirects (301, 302, 307)
                        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
                            const redirectUrl = new URL(res.headers.location, u).toString();
                            return resolve(request(redirectUrl, options));
                        }

                        let stream = res;
                        const enc = (res.headers["content-encoding"] || "").toLowerCase();
                        if (zlib) {
                            if (enc === "gzip") {
                                stream = res.pipe(zlib.createGunzip());
                            } else if (enc === "deflate") {
                                stream = res.pipe(zlib.createInflate());
                            }
                        }

                        let body = "";
                        stream.setEncoding("utf8");
                        stream.on("data", chunk => body += chunk);
                        stream.on("end", () => {
                            resolve({
                                ok: res.statusCode >= 200 && res.statusCode < 300,
                                status: res.statusCode,
                                headers: res.headers,
                                text: () => Promise.resolve(body),
                                json: () => {
                                    try {
                                        return Promise.resolve(JSON.parse(body));
                                    } catch (err) {
                                        return Promise.reject(new Error("Failed to parse JSON: " + err.message));
                                    }
                                }
                            });
                        });
                        stream.on("error", (err) => {
                            reject(err);
                        });
                    });

                    req.on("error", err => reject(err));
                    if (options.timeout) {
                        req.setTimeout(options.timeout, () => {
                            req.abort();
                            reject(new Error("Request timed out"));
                        });
                    }
                    if (options.body) {
                        req.write(typeof options.body === "string" ? options.body : JSON.stringify(options.body));
                    }
                    req.end();
                } catch (e) {
                    reject(e);
                }
            });
        } else {
            // Browser fetch fallback
            return window.fetch(urlStr, options);
        }
    }

    async function getJson(url, headers = {}) {
        const res = await request(url, { headers });
        if (!res.ok) {
            throw new Error(`HTTP ${res.status}`);
        }
        return await res.json();
    }

    async function getText(url, headers = {}) {
        const res = await request(url, { headers });
        if (!res.ok) {
            throw new Error(`HTTP ${res.status}`);
        }
        return await res.text();
    }

    return {
        request: request,
        getJson: getJson,
        getText: getText
    };
})();

if (typeof module !== "undefined" && module.exports) {
    module.exports = Net;
} else {
    window.Net = Net;
}
