/**
 * MediaFetch Commercial License Verification System
 * (c) 2026 MediaFetch Systems. All Rights Reserved.
 */

(function () {
  'use strict';

  // Commercial license protection flag (false = Personal unlocked, true = Commercial license enforced)
  const COMMERCIAL_MODE = false;

  // =========================================================================
  // 1. CONFIGURATION
  // =========================================================================
  const LICENSE_CONFIG = {
    // Primary: High-speed Cloudflare Worker license server:
    ENDPOINT_URL: "https://mediafetch-license-server.mediafetchprivate.workers.dev/api/licenses/verify",

    // Fallback: Google Apps Script Web App URL:
    FALLBACK_ENDPOINT_URL: "https://script.google.com/macros/s/AKfycbyZrxK3qvyjecpMx0saVBLfJsXajSHVYImZIMXvseHb5idQ_m8TMjyHuzmutpITJ3-l5g/exec",

    // Secret API Key
    API_SECRET: "#MediaFetchPlugin@123",

    // Support Email
    SUPPORT_EMAIL: "Mediafetch.plugin@gmail.com",

    // Website / store checkout link:
    PURCHASE_URL: "",

    // Offline grace period in days:
    OFFLINE_GRACE_DAYS: 7,

    STORAGE_KEY: "mf_lic_auth_v1"
  };

  // =========================================================================
  // 2. CEP KEYBOARD EVENTS & RUNTIME HELPERS
  // =========================================================================
  // Ensure Premiere Pro & After Effects DO NOT intercept Ctrl+V, Ctrl+C, Ctrl+A, Backspace, Delete
  function registerCepKeyEvents() {
    try {
      if (window.__adobe_cep__ && typeof window.__adobe_cep__.registerKeyEventsInterest === "function") {
        const keyEvents = [];
        for (let k = 0; k <= 255; k++) {
          keyEvents.push({ keyCode: k, ctrlKey: true, altKey: false, shiftKey: false, metaKey: false });
          keyEvents.push({ keyCode: k, ctrlKey: true, altKey: false, shiftKey: true, metaKey: false });
        }
        window.__adobe_cep__.registerKeyEventsInterest(JSON.stringify(keyEvents));
      }
    } catch (_) {}
  }
  registerCepKeyEvents();

  // Helper to access Node.js modules in CEP environment
  function getNodeFs() {
    try {
      const req = (typeof window !== 'undefined' && (window.require || (window.cep_node && window.cep_node.require))) || (typeof require !== 'undefined' ? require : null);
      if (req) {
        return { fs: req('fs'), path: req('path'), os: req('os'), child_process: req('child_process'), https: req('https'), http: req('http') };
      }
    } catch (_) {}
    return null;
  }

  function getSharedConfigDir() {
    try {
      const node = getNodeFs();
      if (node && node.fs && node.path) {
        const proc = typeof process !== 'undefined' ? process : (window.cep_node && window.cep_node.process);
        const appData = (proc && proc.env && proc.env.APPDATA) || (node.os && node.os.homedir && node.os.homedir()) || '';
        if (appData) {
          const dir = node.path.join(appData, 'MediaFetch');
          if (!node.fs.existsSync(dir)) {
            node.fs.mkdirSync(dir, { recursive: true });
          }
          return dir;
        }
      }
    } catch (_) {}
    return null;
  }

  let _cachedMachineId = null;

  function getDeterministicHardwareId() {
    const node = getNodeFs();
    let hostname = "";
    try {
      if (node && node.os && node.os.hostname) hostname = node.os.hostname();
    } catch (_) {}
    if (!hostname && typeof process !== 'undefined' && process.env) {
      hostname = process.env.COMPUTERNAME || process.env.HOSTNAME || "";
    }
    const cleanHost = (hostname || "WORKSTATION").toUpperCase().replace(/[^A-Z0-9-]/g, '').substring(0, 16);

    // 1. Windows: Query MachineGuid from registry (persists across reboots, uninstalls, and account changes)
    try {
      if (node && node.child_process) {
        const isWin = (typeof process !== 'undefined' && process.platform === 'win32') || 
                      (node.os && node.os.platform && node.os.platform() === 'win32');
        if (isWin) {
          const out = node.child_process.execSync('reg query HKLM\\Software\\Microsoft\\Cryptography /v MachineGuid', {
            encoding: 'utf8',
            timeout: 2000,
            stdio: ['pipe', 'pipe', 'ignore']
          });
          const m = out.match(/MachineGuid\s+REG_SZ\s+([A-Fa-f0-9-]+)/i);
          if (m && m[1]) {
            const guidHex = m[1].replace(/[^A-Fa-f0-9]/g, '').toUpperCase().substring(0, 12);
            if (guidHex.length >= 8) {
              return "MID-" + cleanHost + "-" + guidHex;
            }
          }
        }
      }
    } catch (_) {}

    // 2. macOS: Query IOPlatformUUID
    try {
      if (node && node.child_process) {
        const isMac = (typeof process !== 'undefined' && process.platform === 'darwin') || 
                      (node.os && node.os.platform && node.os.platform() === 'darwin');
        if (isMac) {
          const out = node.child_process.execSync('ioreg -rd1 -c IOPlatformExpertDevice', {
            encoding: 'utf8',
            timeout: 2000,
            stdio: ['pipe', 'pipe', 'ignore']
          });
          const m = out.match(/"IOPlatformUUID"\s*=\s*"([^"]+)"/i);
          if (m && m[1]) {
            const uuidHex = m[1].replace(/[^A-Fa-f0-9]/g, '').toUpperCase().substring(0, 12);
            if (uuidHex.length >= 8) {
              return "MID-" + cleanHost + "-" + uuidHex;
            }
          }
        }
      }
    } catch (_) {}

    // 3. Fallback deterministic hardware fingerprint
    let seed = cleanHost;
    try {
      if (node && node.os) {
        seed += "|" + (node.os.arch ? node.os.arch() : "");
        seed += "|" + (node.os.cpus && node.os.cpus()[0] ? node.os.cpus()[0].model : "");
        seed += "|" + (node.os.totalmem ? node.os.totalmem() : "");
      }
    } catch (_) {}
    if (typeof navigator !== 'undefined') {
      seed += "|" + (navigator.hardwareConcurrency || "") + "|" + (navigator.userAgent || "");
    }

    let h = 0x811c9dc5;
    for (let i = 0; i < seed.length; i++) {
      h ^= seed.charCodeAt(i);
      h = Math.imul(h, 0x01000193);
    }
    const hashHex = ((h >>> 0).toString(16)).toUpperCase().padStart(8, '0');
    return "MID-" + cleanHost + "-" + hashHex;
  }

  function getMachineId() {
    if (_cachedMachineId) return _cachedMachineId;

    const dir = getSharedConfigDir();
    const node = getNodeFs();
    if (dir && node && node.fs && node.path) {
      const midFile = node.path.join(dir, 'machine_id.txt');
      try {
        if (node.fs.existsSync(midFile)) {
          const fileMid = node.fs.readFileSync(midFile, 'utf8').trim();
          if (fileMid && fileMid.startsWith("MID-")) {
            _cachedMachineId = fileMid;
            localStorage.setItem("mf_machine_id", fileMid);
            return fileMid;
          }
        }
      } catch (_) {}
    }

    let mid = localStorage.getItem("mf_machine_id");
    if (!mid || !mid.startsWith("MID-")) {
      mid = getDeterministicHardwareId();
    }

    _cachedMachineId = mid;
    try { localStorage.setItem("mf_machine_id", mid); } catch (_) {}
    if (dir && node && node.fs && node.path) {
      try {
        const midFile = node.path.join(dir, 'machine_id.txt');
        node.fs.writeFileSync(midFile, mid, 'utf8');
      } catch (_) {}
    }
    return mid;
  }

  function generateHash(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash |= 0;
    }
    return Math.abs(hash).toString(16);
  }

  function getLocalLicense() {
    try {
      let raw = localStorage.getItem(LICENSE_CONFIG.STORAGE_KEY);

      // Check shared disk file if localStorage is empty
      if (!raw) {
        const dir = getSharedConfigDir();
        const node = getNodeFs();
        if (dir && node && node.fs && node.path) {
          const licFile = node.path.join(dir, 'license_auth.json');
          if (node.fs.existsSync(licFile)) {
            raw = node.fs.readFileSync(licFile, 'utf8').trim();
            if (raw) {
              localStorage.setItem(LICENSE_CONFIG.STORAGE_KEY, raw);
            }
          }
        }
      }

      if (!raw) return null;

      const jsonStr = decodeURIComponent(escape(atob(raw)));
      const lic = JSON.parse(jsonStr);

      if (!lic || !lic.key || !lic.hash) return null;

      const expectedHash = generateHash(lic.key + (lic.machineId || "") + (lic.activatedAt || "") + LICENSE_CONFIG.API_SECRET);
      if (lic.hash !== expectedHash) {
        console.warn("[MediaFetch License] License signature validation failed.");
        return null;
      }

      return lic;
    } catch (e) {
      console.warn("[MediaFetch License] Local license parsing error:", e);
      return null;
    }
  }

  function saveLocalLicense(key, serverResponse) {
    const machineId = getMachineId();
    const activatedAt = serverResponse.activatedAt || Date.now();
    const hash = generateHash(key + machineId + activatedAt + LICENSE_CONFIG.API_SECRET);

    const payload = {
      key: key,
      machineId: machineId,
      customer: serverResponse.customer || "Valued Customer",
      plan: serverResponse.plan || "Pro Lifetime Edition",
      expiry: serverResponse.expiry || "PERPETUAL",
      maxDevices: serverResponse.maxDevices || 2,
      devicesUsed: serverResponse.devicesUsed || 1,
      activatedAt: activatedAt,
      lastVerified: Date.now(),
      status: "ACTIVE",
      hash: hash
    };

    const encoded = btoa(unescape(encodeURIComponent(JSON.stringify(payload))));
    localStorage.setItem(LICENSE_CONFIG.STORAGE_KEY, encoded);

    // Save to shared disk file so Premiere Pro and After Effects share license automatically
    const dir = getSharedConfigDir();
    const node = getNodeFs();
    if (dir && node && node.fs && node.path) {
      try {
        const licFile = node.path.join(dir, 'license_auth.json');
        node.fs.writeFileSync(licFile, encoded, 'utf8');
      } catch (e) {
        console.warn("[MediaFetch License] Could not save license to shared disk:", e);
      }
    }
    return payload;
  }

  function clearLocalLicense() {
    localStorage.removeItem(LICENSE_CONFIG.STORAGE_KEY);
    const dir = getSharedConfigDir();
    const node = getNodeFs();
    if (dir && node && node.fs && node.path) {
      try {
        const licFile = node.path.join(dir, 'license_auth.json');
        if (node.fs.existsSync(licFile)) {
          node.fs.unlinkSync(licFile);
        }
      } catch (_) {}
    }
  }

  // =========================================================================
  // 3. FAST, ZERO-CORS NETWORK TRANSPORT (Node.js Native HTTPS + Fetch Fallback)
  // =========================================================================
  function httpRequest(urlStr, timeoutMs = 6000) {
    return new Promise((resolve) => {
      // 1. Try Node.js native https first (Instant OS socket, 0 CORS delays, never hangs in CEF)
      const node = getNodeFs();
      if (node && node.https && node.http) {
        try {
          const client = urlStr.startsWith('https') ? node.https : node.http;
          const request = client.get(urlStr, {
            timeout: timeoutMs,
            headers: {
              'Accept': 'application/json',
              'User-Agent': 'MediaFetch-Adobe-CEP/1.0'
            }
          }, (res) => {
            let data = '';
            res.on('data', chunk => { data += chunk; });
            res.on('end', () => {
              try {
                const parsed = JSON.parse(data);
                resolve(parsed);
              } catch (_) {
                resolve({ success: false, raw: data });
              }
            });
          });
          request.on('error', (err) => {
            console.warn("[MediaFetch] Node https error, falling back to fetch:", err.message);
            doFetch();
          });
          request.on('timeout', () => {
            request.destroy();
            console.warn("[MediaFetch] Node https timeout, falling back to fetch");
            doFetch();
          });
          return;
        } catch (_) {}
      }

      doFetch();

      function doFetch() {
        try {
          const controller = new AbortController();
          const tid = setTimeout(() => controller.abort(), timeoutMs);
          fetch(urlStr, { method: "GET", headers: { "Accept": "application/json" }, signal: controller.signal })
            .then(r => r.json())
            .then(d => { clearTimeout(tid); resolve(d); })
            .catch(err => {
              clearTimeout(tid);
              resolve({ success: false, networkError: true, error: err.message });
            });
        } catch (e) {
          resolve({ success: false, networkError: true, error: e.message });
        }
      }
    });
  }

  let _cachedClientIp = null;
  async function getClientIp() {
    if (_cachedClientIp) return _cachedClientIp;
    try {
      const controller = new AbortController();
      const tid = setTimeout(() => controller.abort(), 1800);
      const res = await fetch("https://api.ipify.org?format=json", { signal: controller.signal });
      clearTimeout(tid);
      const data = await res.json();
      if (data && data.ip) {
        _cachedClientIp = String(data.ip).trim();
        return _cachedClientIp;
      }
    } catch (_) {}
    return null;
  }

  async function callLicenseServer(action, key) {
    if (!LICENSE_CONFIG.ENDPOINT_URL || LICENSE_CONFIG.ENDPOINT_URL.includes("[INSERT_")) {
      return {
        success: false,
        message: "License verification server is not configured yet. Please contact support."
      };
    }

    const machineId = getMachineId();
    let devName = "";
    let osName = "";
    try {
      const node = getNodeFs();
      if (node && node.os) {
        if (typeof node.os.hostname === 'function') devName = node.os.hostname();
        if (typeof node.os.platform === 'function') {
          const plat = node.os.platform();
          osName = plat === 'win32' ? 'Windows' : (plat === 'darwin' ? 'macOS' : plat);
        }
      }
    } catch (_) {}
    if (!devName) {
      const parts = (machineId || "").split("-");
      if (parts.length >= 2 && parts[1]) devName = parts[1];
    }
    if (!osName) {
      osName = (typeof navigator !== 'undefined' && navigator.userAgent && navigator.userAgent.includes("Mac")) ? "macOS" : "Windows";
    }

    let clientIp = null;
    try { clientIp = await getClientIp(); } catch (_) {}

    async function attemptEndpoint(endpointUrl) {
      try {
        const url = new URL(endpointUrl);
        url.searchParams.append("action", action);
        url.searchParams.append("key", key);
        url.searchParams.append("secret", LICENSE_CONFIG.API_SECRET);
        url.searchParams.append("machineId", machineId);
        url.searchParams.append("deviceName", devName);
        url.searchParams.append("os", osName);
        url.searchParams.append("edition", "pro");
        if (clientIp) {
          url.searchParams.append("clientIp", clientIp);
        }
        url.searchParams.append("_t", Date.now().toString());

        const data = await httpRequest(url.toString(), 6500);
        return data;
      } catch (err) {
        return { success: false, networkError: true, error: err.message };
      }
    }

    // 1. Primary: High-speed Cloudflare Worker endpoint
    let res = await attemptEndpoint(LICENSE_CONFIG.ENDPOINT_URL);
    if (res && res.success && res.valid) {
      return res;
    }
    // If server returned an explicit edition mismatch or suspension, do not overwrite with fallback
    if (res && (res.editionMismatch || res.status === "BANNED" || res.status === "EXPIRED")) {
      return res;
    }

    // 2. Fallback: Google Apps Script Web App
    if (LICENSE_CONFIG.FALLBACK_ENDPOINT_URL && (!res || !res.valid || res.networkError)) {
      try {
        const fallbackRes = await attemptEndpoint(LICENSE_CONFIG.FALLBACK_ENDPOINT_URL);
        if (fallbackRes && fallbackRes.success && fallbackRes.valid) {
          return fallbackRes;
        }
      } catch (_) {}
    }

    return res || {
      success: false,
      message: "License key not found. Please verify your purchase or contact support."
    };
  }

  // =========================================================================
  // 4. CLIPBOARD & EXTERNAL URL HELPERS
  // =========================================================================
  async function readClipboardText() {
    // 1. Web Clipboard API
    try {
      if (navigator.clipboard && navigator.clipboard.readText) {
        const t = await navigator.clipboard.readText();
        if (t && t.trim()) return t.trim();
      }
    } catch (_) {}

    // 2. Node.js fallback (PowerShell on Windows, pbpaste on macOS)
    try {
      const node = getNodeFs();
      if (node && node.child_process) {
        const cmd = (process.platform === 'darwin') ? 'pbpaste' : 'powershell -NoProfile -Command Get-Clipboard';
        const clip = node.child_process.execSync(cmd, { encoding: 'utf8', timeout: 2000 });
        if (clip && clip.trim()) return clip.trim();
      }
    } catch (_) {}

    return "";
  }

  function copyTextToClipboard(text) {
    if (!text) return;
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text);
        return;
      }
    } catch (_) {}
    try {
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.focus();
      ta.select();
      document.execCommand("copy");
      ta.remove();
    } catch (_) {}
  }

  function openExternalUrl(url) {
    if (!url) return;
    try {
      if (window.__adobe_cep__ && typeof window.__adobe_cep__.openURLInDefaultBrowser === "function") {
        window.__adobe_cep__.openURLInDefaultBrowser(url);
        return true;
      }
    } catch (_) {}
    try {
      if (window.cep && window.cep.util && typeof window.cep.util.openURLInDefaultBrowser === "function") {
        window.cep.util.openURLInDefaultBrowser(url);
        return true;
      }
    } catch (_) {}
    try {
      const node = getNodeFs();
      if (node && node.child_process) {
        const cmd = (process.platform === 'win32') ? `start "" "${url}"` : `open "${url}"`;
        node.child_process.exec(cmd);
        return true;
      }
    } catch (_) {}
    try {
      window.open(url, '_blank');
      return true;
    } catch (_) {}
    return false;
  }
  window.openExternalUrl = openExternalUrl;

  function cleanKeyInput(str) {
    return String(str || "")
      .replace(/[\u2013\u2014\u2212]/g, "-")
      .replace(/[\u200B\u200C\u200D\uFEFF\u00A0]/g, "")
      .replace(/\s*-\s*/g, "-")
      .replace(/\s+/g, "")
      .toUpperCase()
      .replace(/[^A-Z0-9-]/g, "");
  }

  // =========================================================================
  // 5. ACTIVATION MODAL (Apple AMOLED HIG + One-Click Paste & Unlock)
  // =========================================================================
  function renderActivationModal(errorMessage) {
    registerCepKeyEvents();

    let existing = document.getElementById("mediafetch-license-overlay");
    if (existing) {
      existing.remove();
    }

    const overlay = document.createElement("div");
    overlay.id = "mediafetch-license-overlay";
    overlay.style.cssText = `
      position: fixed;
      top: 0; left: 0; right: 0; bottom: 0;
      background: rgba(10, 10, 14, 0.96);
      z-index: 999999;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 16px;
      box-sizing: border-box;
      font-family: -apple-system, BlinkMacSystemFont, "SF Pro Text", "Segoe UI", Roboto, sans-serif;
      color: #f5f5f7;
      transform: translateZ(0);
      user-select: none;
    `;

    const card = document.createElement("div");
    card.style.cssText = `
      width: 100%;
      max-width: 400px;
      background: #111116;
      border: 1px solid rgba(255, 255, 255, 0.12);
      border-radius: 14px;
      box-shadow: 0 16px 40px rgba(0, 0, 0, 0.8), 0 0 0 1px rgba(255, 255, 255, 0.05);
      padding: 26px 22px;
      box-sizing: border-box;
      text-align: center;
      transform: translateZ(0);
    `;

    const supportEmail = LICENSE_CONFIG.SUPPORT_EMAIL && !LICENSE_CONFIG.SUPPORT_EMAIL.includes("[INSERT_")
      ? LICENSE_CONFIG.SUPPORT_EMAIL
      : "Mediafetch.plugin@gmail.com";

    const buyLinkHtml = LICENSE_CONFIG.PURCHASE_URL && !LICENSE_CONFIG.PURCHASE_URL.includes("[INSERT_")
      ? `<div style="margin-top: 10px; font-size: 11px;">
           <button id="mf-lic-buy-btn" type="button" style="background: none; border: none; color: #0a84ff; text-decoration: underline; cursor: pointer; font-size: 11px; padding: 0;">
             Purchase a License Key
           </button>
         </div>`
      : "";

    card.innerHTML = `
      <div style="display: flex; align-items: center; justify-content: center; margin-bottom: 14px;">
        <div style="width: 48px; height: 48px; border-radius: 12px; background: rgba(10, 132, 255, 0.12); border: 1px solid rgba(10, 132, 255, 0.25); display: flex; align-items: center; justify-content: center;">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#0a84ff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
            <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
          </svg>
        </div>
      </div>
      <h2 style="font-size: 16px; font-weight: 600; margin: 0 0 6px 0; color: #ffffff; letter-spacing: -0.2px;">MediaFetch License Activation</h2>
      <p style="font-size: 11.5px; color: #86868b; margin: 0 0 18px 0; line-height: 1.45;">
        Enter your workstation license key provided with your purchase to unlock the full workstation suite.
      </p>

      <div style="margin-bottom: 12px; text-align: left;">
        <label style="display: block; font-size: 10px; font-weight: 600; letter-spacing: 0.4px; color: #86868b; margin-bottom: 6px; text-transform: uppercase;">License Key</label>
        <div style="display: flex; gap: 8px; align-items: center;">
          <input id="mf-lic-input" type="text" placeholder="MF-XXXX-XXXX-XXXX" autocomplete="off" spellcheck="false" style="
            flex: 1;
            height: 38px;
            background: #141418;
            border: 1px solid rgba(255, 255, 255, 0.14);
            border-radius: 8px;
            color: #ffffff;
            padding: 0 12px;
            font-size: 12.5px;
            font-family: -apple-system, BlinkMacSystemFont, 'SF Mono', ui-monospace, Menlo, monospace;
            letter-spacing: 0.8px;
            box-sizing: border-box;
            outline: none;
            text-transform: uppercase;
            transition: border-color 0.15s ease, box-shadow 0.15s ease;
          " />
          <button id="mf-lic-paste-btn" type="button" title="Paste from Clipboard" style="
            height: 38px;
            padding: 0 12px;
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(255, 255, 255, 0.15);
            border-radius: 8px;
            color: #0a84ff;
            font-size: 11.5px;
            font-weight: 500;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            white-space: nowrap;
            transition: all 0.15s ease;
          ">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"></path>
              <rect x="8" y="2" width="8" height="4" rx="1" ry="1"></rect>
            </svg>
            <span id="mf-lic-paste-label">Paste</span>
          </button>
        </div>
      </div>

      <div id="mf-lic-status" style="
        min-height: 20px;
        font-size: 11px;
        color: ${errorMessage ? "#ff453a" : "#86868b"};
        margin-bottom: 14px;
        line-height: 1.35;
        word-break: break-word;
      ">${errorMessage || ""}</div>

      <button id="mf-lic-activate-btn" style="
        width: 100%;
        height: 38px;
        background: #0071e3;
        color: #ffffff;
        border: 1px solid #0077ed;
        border-radius: 8px;
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.4);
        transition: background 0.15s ease, opacity 0.15s ease;
      ">
        Activate License
      </button>

      ${buyLinkHtml}

      <!-- Support Section -->
      <div style="margin-top: 18px; padding-top: 14px; border-top: 1px solid rgba(255, 255, 255, 0.08); display: flex; flex-direction: column; gap: 8px; align-items: center;">
        <span style="font-size: 11px; color: #86868b;">Need help or license recovery?</span>
        <div style="display: flex; gap: 8px; align-items: center; justify-content: center; flex-wrap: wrap;">
          <button id="mf-lic-support-btn" type="button" style="
            background: rgba(255, 255, 255, 0.06);
            border: 1px solid rgba(255, 255, 255, 0.12);
            border-radius: 8px;
            color: #0a84ff;
            font-size: 11px;
            font-weight: 500;
            padding: 5px 11px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            transition: all 0.15s ease;
          ">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
              <polyline points="22,6 12,13 2,6"></polyline>
            </svg>
            <span>Contact Support</span>
          </button>
          <button id="mf-lic-copy-email-btn" type="button" title="Copy Support Email to Clipboard" style="
            background: rgba(255, 255, 255, 0.06);
            border: 1px solid rgba(255, 255, 255, 0.12);
            border-radius: 8px;
            color: #98989d;
            font-size: 11px;
            padding: 5px 9px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            transition: all 0.15s ease;
          ">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
              <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
            </svg>
            <span id="mf-lic-copy-label">Copy Email</span>
          </button>
        </div>
        <div id="mf-support-notice" style="display: none; font-size: 10px; color: #30d158; margin-top: 2px;"></div>
      </div>
    `;

    overlay.appendChild(card);
    document.body.appendChild(overlay);

    const input = document.getElementById("mf-lic-input");
    const pasteBtn = document.getElementById("mf-lic-paste-btn");
    const pasteLabel = document.getElementById("mf-lic-paste-label");
    const btn = document.getElementById("mf-lic-activate-btn");
    const statusText = document.getElementById("mf-lic-status");
    const supportBtn = document.getElementById("mf-lic-support-btn");
    const copyEmailBtn = document.getElementById("mf-lic-copy-email-btn");
    const copyLabel = document.getElementById("mf-lic-copy-label");
    const supportNotice = document.getElementById("mf-support-notice");
    const buyBtn = document.getElementById("mf-lic-buy-btn");

    // License key input stays empty by default - user explicitly pastes or types
    if (input) {
      input.value = "";
    }

    if (input) {
      input.addEventListener("focus", () => {
        input.style.borderColor = "#0a84ff";
        input.style.boxShadow = "0 0 0 3px rgba(10, 132, 255, 0.25)";
      });
      input.addEventListener("blur", () => {
        input.style.borderColor = "rgba(255, 255, 255, 0.14)";
        input.style.boxShadow = "none";
        input.value = cleanKeyInput(input.value);
      });
      input.addEventListener("paste", () => {
        setTimeout(() => {
          input.value = cleanKeyInput(input.value);
        }, 10);
      });
      input.addEventListener("keydown", async (e) => {
        if ((e.ctrlKey || e.metaKey) && (e.key === 'v' || e.key === 'V' || e.keyCode === 86)) {
          setTimeout(async () => {
            if (!input.value) {
              const txt = await readClipboardText();
              if (txt) {
                input.value = cleanKeyInput(txt);
              }
            } else {
              input.value = cleanKeyInput(input.value);
            }
          }, 30);
        } else if (e.key === "Enter") {
          btn.click();
        }
      });
    }

    if (pasteBtn) {
      pasteBtn.addEventListener("click", async () => {
        const text = await readClipboardText();
        if (text) {
          const cleaned = cleanKeyInput(text);
          if (input) {
            input.value = cleaned;
            input.focus();
          }
          if (pasteLabel) pasteLabel.textContent = "✓ Pasted";
          if (statusText) {
            statusText.style.color = "#30d158";
            statusText.textContent = "✓ Key pasted! Click Activate License or press Enter.";
          }
          setTimeout(() => {
            if (pasteLabel) pasteLabel.textContent = "Paste";
          }, 2500);
        } else {
          if (statusText) {
            statusText.style.color = "#ff453a";
            statusText.textContent = "Clipboard is empty. Please copy your key and try again.";
          }
        }
      });
    }

    if (supportBtn) {
      supportBtn.addEventListener("click", (e) => {
        e.preventDefault();
        const mailUrl = `mailto:${supportEmail}?subject=MediaFetch%20Support%20Request&body=Hi%20MediaFetch%20Team,%0A%0AMy%20license%20issue%20or%20inquiry:%20`;
        openExternalUrl(mailUrl);
        copyTextToClipboard(supportEmail);
        if (supportNotice) {
          supportNotice.textContent = "✓ Mail client launched & email copied to clipboard!";
          supportNotice.style.display = "block";
          setTimeout(() => { if (supportNotice) supportNotice.style.display = "none"; }, 5000);
        }
      });
    }

    if (copyEmailBtn) {
      copyEmailBtn.addEventListener("click", (e) => {
        e.preventDefault();
        copyTextToClipboard(supportEmail);
        if (copyLabel) copyLabel.textContent = "✓ Copied!";
        if (supportNotice) {
          supportNotice.textContent = `✓ ${supportEmail} copied to clipboard`;
          supportNotice.style.display = "block";
          setTimeout(() => {
            if (copyLabel) copyLabel.textContent = "Copy Email";
            if (supportNotice) supportNotice.style.display = "none";
          }, 3000);
        }
      });
    }

    if (buyBtn) {
      buyBtn.addEventListener("click", (e) => {
        e.preventDefault();
        openExternalUrl(LICENSE_CONFIG.PURCHASE_URL);
      });
    }

    btn.addEventListener("click", async () => {
      let keyVal = cleanKeyInput(input ? input.value : "");
      if (input) input.value = keyVal;

      // If user clicked activate without entering key, try reading clipboard automatically
      if (!keyVal || keyVal.length < 5) {
        const clip = await readClipboardText();
        if (clip && clip.toUpperCase().startsWith("MF-")) {
          keyVal = cleanKeyInput(clip);
          if (input) input.value = keyVal;
        }
      }

      if (!keyVal || keyVal.length < 5) {
        statusText.style.color = "#ff453a";
        statusText.textContent = "Please enter or paste a valid workstation license key.";
        if (input) input.focus();
        return;
      }

      btn.disabled = true;
      btn.style.opacity = "0.75";
      btn.innerHTML = `<span style="display:inline-block;width:12px;height:12px;border:2px solid rgba(255,255,255,0.3);border-top-color:#fff;border-radius:50%;animation:spin 0.6s linear infinite;margin-right:6px;vertical-align:middle;"></span> Verifying Workstation...`;
      statusText.style.color = "#0a84ff";
      statusText.textContent = "Verifying license credentials with cloud server...";

      try {
        const res = await callLicenseServer("activate", keyVal);

        if (res.success && res.valid) {
          statusText.style.color = "#30d158";
          statusText.textContent = "✓ Activation verified! Unlocking workstation suite...";
          btn.innerHTML = "✓ Unlocked";
          saveLocalLicense(keyVal, res);
          setTimeout(() => {
            overlay.remove();
            updateSettingsLicenseBadge();
          }, 500);
        } else {
          btn.disabled = false;
          btn.style.opacity = "1";
          btn.innerHTML = "Activate License";
          statusText.style.color = "#ff453a";
          statusText.textContent = res.message || "Invalid license key.";
        }
      } catch (err) {
        btn.disabled = false;
        btn.style.opacity = "1";
        btn.innerHTML = "Activate License";
        statusText.style.color = "#ff453a";
        statusText.textContent = "Connection error. Please check your network and retry.";
      }
    });

    setTimeout(() => {
      if (input) input.focus();
    }, 100);
  }

  // =========================================================================
  // 6. SETTINGS DIALOG INTEGRATION
  // =========================================================================
  function updateSettingsLicenseBadge() {
    const lic = getLocalLicense();
    let container = document.getElementById("mf-settings-license-info");
    if (!container) {
      const settingsModal = document.querySelector("#modal-settings .modal-body") || document.querySelector(".settings-content");
      if (settingsModal) {
        container = document.createElement("div");
        container.id = "mf-settings-license-info";
        container.style.cssText = "margin-bottom: 12px; padding: 10px; background: #252525; border: 1px solid #3a3a3a; border-radius: 6px;";
        settingsModal.insertBefore(container, settingsModal.firstChild);
      }
    }

    if (container) {
      if (lic) {
        const maskedKey = lic.key.substring(0, 6) + "••••••••" + lic.key.substring(lic.key.length - 4);
        
        let lifeLabel = "Key life: Lifetime";
        let lifeColor = "#4caf50";

        const rawExpiry = lic.expiry;
        const isPerpetual = !rawExpiry || 
          rawExpiry === "PERPETUAL" || 
          rawExpiry === "LIFETIME" || 
          rawExpiry === "NEVER" || 
          (typeof lic.plan === "string" && lic.plan.toLowerCase().includes("lifetime"));

        if (!isPerpetual) {
          const expDate = new Date(rawExpiry);
          if (!isNaN(expDate.getTime())) {
            const now = Date.now();
            const diffMs = expDate.getTime() - now;
            if (diffMs <= 0) {
              lifeLabel = "Key life: Expired";
              lifeColor = "#ef4444";
            } else {
              const totalHours = Math.floor(diffMs / (1000 * 60 * 60));
              const days = Math.floor(totalHours / 24);
              const hours = totalHours % 24;

              const d = expDate.getDate();
              const s = ["th", "st", "nd", "rd"];
              const v = d % 100;
              const ord = d + (s[(v - 20) % 10] || s[v] || s[0]);
              const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
              const dateStr = `${ord} ${months[expDate.getMonth()]}`;

              if (days > 1) {
                lifeLabel = `Key life till ${dateStr} (${days} days left)`;
                lifeColor = days <= 3 ? "#ff9800" : "#4caf50";
              } else if (days === 1) {
                lifeLabel = `Key life: 1 day, ${hours} hours left (till ${dateStr})`;
                lifeColor = "#ff9800";
              } else {
                lifeLabel = `Key life: ${Math.max(1, totalHours)} hours left (till ${dateStr})`;
                lifeColor = "#ff9800";
              }
            }
          }
        }

        container.innerHTML = `
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px;">
            <span style="font-size: 11px; font-weight: 600; color: ${lifeColor}; display: flex; align-items: center; gap: 4px;">
              <span style="width: 7px; height: 7px; border-radius: 50%; background: ${lifeColor}; display: inline-block;"></span>
              ${lifeLabel}
            </span>
            <button id="mf-lic-deactivate-btn" style="background: transparent; border: 1px solid #555; border-radius: 4px; color: #aaa; font-size: 10px; padding: 3px 8px; cursor: pointer; transition: all 0.15s ease;">
              Deactivate
            </button>
          </div>
          <div style="font-size: 10px; color: #888; font-family: monospace;">Key: ${maskedKey}</div>
        `;

        const deactBtn = document.getElementById("mf-lic-deactivate-btn");
        if (deactBtn) {
          let confirmStage = false;
          let resetTimeout = null;
          deactBtn.onclick = async (e) => {
            e.stopPropagation();
            if (!confirmStage) {
              confirmStage = true;
              deactBtn.textContent = "Click to Confirm";
              deactBtn.style.color = "#ff453a";
              deactBtn.style.borderColor = "#ff453a";
              deactBtn.style.background = "rgba(255, 69, 58, 0.15)";
              resetTimeout = setTimeout(() => {
                confirmStage = false;
                deactBtn.textContent = "Deactivate";
                deactBtn.style.color = "#aaa";
                deactBtn.style.borderColor = "#555";
                deactBtn.style.background = "transparent";
              }, 4000);
              return;
            }
            if (resetTimeout) clearTimeout(resetTimeout);
            deactBtn.disabled = true;
            deactBtn.textContent = "Deactivating...";
            try {
              await callLicenseServer("deactivate", lic.key);
            } catch (_) {}
            clearLocalLicense();
            updateSettingsLicenseBadge();
            renderActivationModal();
          };
        }
        return;
      }

      if (!COMMERCIAL_MODE) {
        const editionTitle = document.title.includes("Pro") ? "MediaFetch Pro Personal Studio Edition" : "MediaFetch Personal Edition";
        container.innerHTML = `
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <span style="font-size: 11px; font-weight: 600; color: #4caf50; display: flex; align-items: center; gap: 6px;">
              <span style="width: 8px; height: 8px; border-radius: 50%; background: #4caf50; display: inline-block; box-shadow: 0 0 6px rgba(76,175,80,0.6);"></span>
              ${editionTitle}
            </span>
            <button id="mf-lic-activate-btn" style="background: transparent; border: 1px solid #555; border-radius: 4px; color: #4caf50; font-size: 10px; padding: 3px 8px; cursor: pointer; transition: all 0.15s ease;">
              Activate License
            </button>
          </div>
          <div style="font-size: 10px; color: #888; margin-top: 4px;">Personal Developer Edition • All features permanently enabled</div>
        `;
        const actBtn = document.getElementById("mf-lic-activate-btn");
        if (actBtn) {
          actBtn.onclick = (e) => {
            e.stopPropagation();
            renderActivationModal();
          };
        }
        return;
      }

      container.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: center;">
          <span style="font-size: 11px; font-weight: 600; color: #ff9800; display: flex; align-items: center; gap: 6px;">
            <span style="width: 8px; height: 8px; border-radius: 50%; background: #ff9800; display: inline-block;"></span>
            License Not Activated
          </span>
          <button id="mf-lic-activate-btn" style="background: transparent; border: 1px solid #ff9800; border-radius: 4px; color: #ff9800; font-size: 10px; padding: 3px 8px; cursor: pointer; transition: all 0.15s ease;">
            Activate Key
          </button>
        </div>
      `;
      const actBtn = document.getElementById("mf-lic-activate-btn");
      if (actBtn) {
        actBtn.onclick = (e) => {
          e.stopPropagation();
          renderActivationModal();
        };
      }
    }
  }

  // =========================================================================
  // 7. INITIALIZATION & SILENT BACKGROUND CHECK
  // =========================================================================
  async function initLicenseCheck() {
    registerCepKeyEvents();

    if (!COMMERCIAL_MODE) {
      console.log("[MediaFetch License] Running in Personal Studio Mode - All features permanently unlocked.");
      updateSettingsLicenseBadge();
      return;
    }

    const lic = getLocalLicense();

    // Not activated yet -> Show activation lock screen
    if (!lic) {
      renderActivationModal();
      return;
    }

    const now = Date.now();
    const daysSinceCheck = (now - (lic.lastVerified || 0)) / (1000 * 60 * 60 * 24);

    // Initial render from local cache
    updateSettingsLicenseBadge();

    // Perform live background verification when connected
    try {
      const res = await callLicenseServer("verify", lic.key);
      if (res.networkError) {
        // Offline: enforce grace period
        if (daysSinceCheck > LICENSE_CONFIG.OFFLINE_GRACE_DAYS * 2) {
          clearLocalLicense();
          renderActivationModal("Offline grace period expired. Please connect to the internet to verify your license.");
          return;
        }
      } else if (!res.valid || res.status === "PAUSED" || res.status === "REVOKED" || res.status === "EXPIRED" || res.status === "SUSPENDED") {
        clearLocalLicense();
        renderActivationModal(res.message || `This license is ${res.status ? res.status.toLowerCase() : "no longer active"}. Please contact support or your seller.`);
        return;
      } else {
        lic.lastVerified = now;
        saveLocalLicense(lic.key, res);
        updateSettingsLicenseBadge();
      }
    } catch (err) {
      console.warn("[MediaFetch License] Online check notice:", err);
    }
  }

  function isAuthorized() {
    if (!COMMERCIAL_MODE) return true;
    const lic = getLocalLicense();
    if (!lic || !lic.key || !lic.hash) return false;
    if (lic.status === "PAUSED" || lic.status === "REVOKED" || lic.status === "EXPIRED" || lic.status === "SUSPENDED") return false;
    const expectedHash = generateHash(lic.key + lic.machineId + (lic.activatedAt || "") + LICENSE_CONFIG.API_SECRET);
    return lic.hash === expectedHash;
  }

  // Export API to window
  window.MediaFetchLicense = {
    check: initLicenseCheck,
    showModal: renderActivationModal,
    getLocal: getLocalLicense,
    isAuthorized: isAuthorized,
    updateBadge: updateSettingsLicenseBadge
  };

  // Run automatically when DOM is ready
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initLicenseCheck);
  } else {
    initLicenseCheck();
  }
})();