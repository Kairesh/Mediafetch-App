/**
 * MediaFetch High-Performance Streaming Downloader & Transcoder
 * Direct-to-disk chunk piping (0 MB browser RAM overhead - optimized for low-end PCs)
 * Guarantees 100% Adobe After Effects & Premiere Pro codec compatibility (H.264 + AAC + yuv420p)
 * Prevents "The source compression type is not supported" error by auto-detecting VP9/AV1/Opus and transcoding.
 */
const Downloader = (function () {
    const isNode = typeof window !== "undefined" && !!window.require;
    let fs = null;
    let path = null;
    let https = null;
    let http = null;
    let child_process = null;
    let os = null;

    if (isNode) {
        try {
            fs = window.require("fs");
            path = window.require("path");
            https = window.require("https");
            http = window.require("http");
            child_process = window.require("child_process");
            os = window.require("os");
        } catch (e) {
            console.warn("Downloader: Node.js modules unavailable", e);
        }
    }

    /**
     * Locate bin directory containing yt-dlp, ffmpeg, ffprobe (Windows & macOS)
     */
    function getBinDir() {
        if (!isNode || !fs) return "";

        const isWin = typeof process !== "undefined" && process.platform === "win32";
        const homeDir = (typeof os !== "undefined" && os.homedir) ? os.homedir() : (process.env.HOME || process.env.USERPROFILE || "");

        const candidates = [
            path.join(process.env.LOCALAPPDATA || "", "MediaFetch", "bin"),
            path.join(process.env.APPDATA || "", "MediaFetch", "bin"),
            path.join(homeDir, "Library", "Application Support", "MediaFetch", "bin"),
            path.join(homeDir, ".mediafetch", "bin"),
            path.join(process.env.LOCALAPPDATA || "", "MediaSearch", "bin"),
            path.join(__dirname, "..", "service", "bin"),
            path.join(__dirname, "..", "bin"),
            path.join(__dirname, "bin")
        ];

        for (const dir of candidates) {
            if (dir && fs.existsSync(dir)) {
                return dir;
            }
        }
        return isWin
            ? path.join(process.env.LOCALAPPDATA || "", "MediaFetch", "bin")
            : path.join(homeDir, "Library", "Application Support", "MediaFetch", "bin");
    }

    function getYtDlpPath() {
        const isWin = typeof process !== "undefined" && process.platform === "win32";
        const binName = isWin ? "yt-dlp.exe" : "yt-dlp";
        const binDir = getBinDir();
        if (binDir) {
            const p = path.join(binDir, binName);
            if (fs.existsSync(p)) return p;
            if (!isWin) {
                const macP = path.join(binDir, "yt-dlp_macos");
                if (fs.existsSync(macP)) return macP;
            }
        }
        if (isWin) {
            const winCandidates = [
                path.join(process.env.LOCALAPPDATA || "", "Microsoft", "WinGet", "Links", binName),
                path.join(process.env.LOCALAPPDATA || "", "Programs", "Python", "Python314", "Scripts", binName),
                path.join(process.env.LOCALAPPDATA || "", "Programs", "Python", "Python313", "Scripts", binName),
                path.join(process.env.LOCALAPPDATA || "", "Programs", "Python", "Python312", "Scripts", binName),
                path.join(process.env.APPDATA || "", "blinkl.io", "resources", "io.any-paste.blinkl", "yt-dlp", binName),
                path.join(process.env.USERPROFILE || "", ".stacher", binName)
            ];
            for (const p of winCandidates) {
                if (p && fs.existsSync(p)) {
                    if (binDir && !fs.existsSync(path.join(binDir, binName))) {
                        try { fs.copyFileSync(p, path.join(binDir, binName)); } catch (_) {}
                    }
                    return p;
                }
            }
        }
        if (!isWin) {
            for (const macPath of ["/opt/homebrew/bin/yt-dlp", "/usr/local/bin/yt-dlp", "/usr/bin/yt-dlp"]) {
                if (fs.existsSync(macPath)) return macPath;
            }
        }
        return binName;
    }

    function getFfmpegPath() {
        const isWin = typeof process !== "undefined" && process.platform === "win32";
        const binName = isWin ? "ffmpeg.exe" : "ffmpeg";
        const binDir = getBinDir();
        if (binDir) {
            const p = path.join(binDir, binName);
            if (fs.existsSync(p)) return p;
        }
        if (isWin) {
            const winCandidates = [
                path.join(process.env.LOCALAPPDATA || "", "Microsoft", "WinGet", "Links", binName),
                path.join(process.env.PROGRAMFILES || "C:\\Program Files", "ffmpeg", "bin", binName),
                path.join(process.env["PROGRAMFILES(X86)"] || "C:\\Program Files (x86)", "ffmpeg", "bin", binName),
                path.join(process.env.USERPROFILE || "", "ffmpeg", "bin", binName),
                path.join(process.env.LOCALAPPDATA || "", "ffmpeg", "bin", binName),
                path.join(process.env.LOCALAPPDATA || "", "Programs", "ffmpeg", "bin", binName),
                path.join(process.env.APPDATA || "", "blinkl.io", "resources", "ffmpeg", binName),
                path.join(process.env.USERPROFILE || "", ".stacher", binName)
            ];
            for (const p of winCandidates) {
                if (p && fs.existsSync(p)) {
                    if (binDir && !fs.existsSync(path.join(binDir, binName))) {
                        try { fs.copyFileSync(p, path.join(binDir, binName)); } catch (_) {}
                    }
                    return p;
                }
            }
        }
        if (!isWin) {
            for (const macPath of ["/opt/homebrew/bin/ffmpeg", "/usr/local/bin/ffmpeg", "/usr/bin/ffmpeg"]) {
                if (fs.existsSync(macPath)) return macPath;
            }
        }
        return binName;
    }

    function getFfprobePath() {
        const isWin = typeof process !== "undefined" && process.platform === "win32";
        const binName = isWin ? "ffprobe.exe" : "ffprobe";
        const binDir = getBinDir();
        if (binDir) {
            const p = path.join(binDir, binName);
            if (fs.existsSync(p)) return p;
        }
        if (isWin) {
            const winCandidates = [
                path.join(process.env.LOCALAPPDATA || "", "Microsoft", "WinGet", "Links", binName),
                path.join(process.env.PROGRAMFILES || "C:\\Program Files", "ffmpeg", "bin", binName),
                path.join(process.env["PROGRAMFILES(X86)"] || "C:\\Program Files (x86)", "ffmpeg", "bin", binName),
                path.join(process.env.USERPROFILE || "", "ffmpeg", "bin", binName),
                path.join(process.env.LOCALAPPDATA || "", "ffmpeg", "bin", binName),
                path.join(process.env.LOCALAPPDATA || "", "Programs", "ffmpeg", "bin", binName),
                path.join(process.env.APPDATA || "", "blinkl.io", "resources", "ffmpeg", binName),
                path.join(process.env.USERPROFILE || "", ".stacher", binName)
            ];
            for (const p of winCandidates) {
                if (p && fs.existsSync(p)) {
                    if (binDir && !fs.existsSync(path.join(binDir, binName))) {
                        try { fs.copyFileSync(p, path.join(binDir, binName)); } catch (_) {}
                    }
                    return p;
                }
            }
        }
        if (!isWin) {
            for (const macPath of ["/opt/homebrew/bin/ffprobe", "/usr/local/bin/ffprobe", "/usr/bin/ffprobe"]) {
                if (fs.existsSync(macPath)) return macPath;
            }
        }
        return binName;
    }

    /**
     * Resolves the target folder to save downloaded media
     */
    async function getDownloadDirectory(csInterface, mediaType) {
        if (!mediaType) mediaType = "Video";
        let rootDir = "";

        // 1. User custom folder preference (Strictly when custom mode is chosen)
        let modeInput = typeof document !== "undefined" ? document.getElementById("setting-location-mode") : null;
        let isCustomMode = modeInput ? modeInput.value === "custom" : false;
        let customDir = "";
        if (isCustomMode) {
            customDir = Settings.get("downloadFolder");
            if (!customDir && typeof document !== "undefined") {
                const locInput = document.getElementById("setting-custom-location");
                if (locInput && locInput.value && locInput.value.trim()) {
                    customDir = locInput.value.trim();
                }
            }
            if (customDir && typeof customDir === "string" && customDir.trim().length > 0) {
                try {
                    const resolvedCustom = path.resolve(customDir.trim());
                    if (fs && !fs.existsSync(resolvedCustom)) {
                        fs.mkdirSync(resolvedCustom, { recursive: true });
                    }
                    rootDir = resolvedCustom;
                } catch (dirErr) {
                    console.warn("[MediaFetch] Custom folder error, falling back:", dirErr);
                }
            }
        }
        
        if (!rootDir && csInterface) {
            // 2. Active Adobe Project Directory
            try {
                const hostInfoStr = await new Promise(resolve => {
                    csInterface.evalScript("MediaFetchHost.getHostInfo()", resolve);
                });
                const hostInfo = JSON.parse(hostInfoStr);
                if (hostInfo && hostInfo.projectPath) {
                    rootDir = path.dirname(hostInfo.projectPath);
                }
            } catch (e) {
                // Fallback
            }
        }
        if (!rootDir) {
            // 3. User Downloads folder
            rootDir = path.join(os ? os.homedir() : "C:\\", "Downloads");
        }

        // Clean any existing trailing subfolders
        if (rootDir.toLowerCase().endsWith("mediafetch_assets") || rootDir.toLowerCase().endsWith("mediasearch assets")) {
            rootDir = path.dirname(rootDir);
        }
        if (rootDir.toLowerCase().endsWith("serachmediafetch") || rootDir.toLowerCase().endsWith("linkmediafetch")) {
            rootDir = path.dirname(rootDir);
        }
        if (!rootDir.toLowerCase().endsWith("mediafetch") && path.basename(rootDir).toLowerCase() !== "mediafetch") {
            rootDir = path.join(rootDir, "MediaFetch");
        }

        const targetDir = path.join(rootDir, "SerachMediafetch", mediaType);
        if (fs && !fs.existsSync(targetDir)) {
            fs.mkdirSync(targetDir, { recursive: true });
        }
        return targetDir;
    }

    /**
     * Retrieves active time range from Trimmer UI if open and populated
     */
    function toggleTrimPanel(e) {
        if (typeof window !== 'undefined' && typeof window.toggleTrimPanel === 'function' && window.toggleTrimPanel !== toggleTrimPanel) {
            return window.toggleTrimPanel(e);
        }
        if (typeof document === 'undefined') return;
        if (e) {
            try { e.preventDefault(); e.stopPropagation(); } catch (_) {}
        }
        const now = Date.now();
        if (window._lastTrimToggle && (now - window._lastTrimToggle < 250)) {
            return;
        }
        window._lastTrimToggle = now;

        const panel = document.getElementById('trim-inputs-panel');
        const arrow = document.getElementById('trim-toggle-arrow');
        if (!panel) return;

        const isHidden = window.getComputedStyle(panel).display === 'none' || panel.style.display === 'none' || !panel.style.display;
        panel.style.display = isHidden ? 'flex' : 'none';
        if (arrow) arrow.textContent = isHidden ? '▼' : '▶';
    }

    function parseSec(txt) {
        if (!txt) return 0;
        const clean = txt.toString().trim();
        if (!clean) return 0;
        const parts = clean.split(':').map(p => parseInt(p.trim(), 10) || 0);
        if (parts.length === 3) return (parts[0] * 3600) + (parts[1] * 60) + parts[2];
        if (parts.length === 2) return (parts[0] * 60) + parts[1];
        if (parts.length === 1) return parts[0];
        return 0;
    }

    function formatSec(sec) {
        if (!sec || isNaN(sec) || sec < 0) sec = 0;
        const h = Math.floor(sec / 3600);
        const m = Math.floor((sec % 3600) / 60);
        const s = Math.floor(sec % 60);
        if (h > 0) {
            return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
        }
        return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
    }

    function adjustTrim(addSeconds) {
        const startInput = document.getElementById('trim-start-input');
        const endInput = document.getElementById('trim-end-input');
        if (!endInput) return;
        let endVal = parseSec(endInput.value || '0');
        endVal += addSeconds;
        endInput.value = formatSec(endVal);
        updateTrimSummary();
    }

    function resetTrim() {
        const startInput = document.getElementById('trim-start-input');
        const endInput = document.getElementById('trim-end-input');
        const summary = document.getElementById('trim-summary-text');
        if (startInput) startInput.value = '';
        if (endInput) endInput.value = '';
        if (summary) summary.textContent = '';
    }

    function updateTrimSummary() {
        const startInput = document.getElementById('trim-start-input');
        const endInput = document.getElementById('trim-end-input');
        const summary = document.getElementById('trim-summary-text');
        if (!startInput || !endInput || !summary) return;
        const s = parseSec(startInput.value);
        const e = parseSec(endInput.value);
        if (e > s) {
            summary.textContent = `Clip: ${formatSec(e - s)}`;
        } else {
            summary.textContent = '';
        }
    }

    function getActiveTimeRange() {
        if (typeof document === 'undefined') return null;
        const trimCheckbox = document.getElementById('trim-checkbox') || document.getElementById('enable-trim-checkbox');
        if (trimCheckbox && !trimCheckbox.checked) return null;
        const trimPanel = document.getElementById('trim-panel');
        if (trimPanel && (trimPanel.style.display === 'none' || trimPanel.classList.contains('hidden'))) return null;
        const startInput = document.getElementById('trim-start-input');
        const endInput = document.getElementById('trim-end-input');
        if (startInput && endInput) {
            const s = (startInput.value || '').trim();
            const e = (endInput.value || '').trim();
            if (s || e) {
                return { start: s || '00:00:00', end: e || '99:59:59' };
            }
        }
        return null;
    }

    if (typeof window !== 'undefined') {
        if (!window.toggleTrimPanel) {
            window.toggleTrimPanel = toggleTrimPanel;
        }
        window.adjustTrim = adjustTrim;
        window.resetTrim = resetTrim;
        window.updateTrimSummary = updateTrimSummary;
    }

    function bindTrimmerUI() {
        // UI toggle handled exclusively by window.toggleTrimPanel / app.ts
    }

    if (typeof document !== 'undefined') {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', bindTrimmerUI);
        } else {
            bindTrimmerUI();
        }
    }

    /**
     * Sanitizes file names for Windows filesystem
     */
    function sanitizeFilename(name) {
        return (name || "asset")
            .replace(/[<>:"/\\|?*\x00-\x1F]/g, "_")
            .replace(/\s+/g, " ")
            .trim()
            .substring(0, 70);
    }

    /**
     * Guarantees 100% native Adobe After Effects & Premiere Pro codec compatibility.
     * Inspects the video & audio streams with FFprobe.
     * If video is VP9, AV1, VP8, or audio is Opus, Vorbis, WebM,
     * immediately transcodes to H.264 (yuv420p) + AAC audio so After Effects NEVER fails.
     */
    function ensureAdobeCompatible(inputPath, onProgress, hostApp) {
        return new Promise((resolve, reject) => {
            if (!isNode || !fs || !fs.existsSync(inputPath)) {
                return resolve(inputPath);
            }

            const ext = path.extname(inputPath).toLowerCase();

            // Native audio formats (MP3, WAV, M4A, FLAC, AAC) are already 100% Adobe compatible
            if (['.mp3', '.wav', '.m4a', '.flac', '.aac', '.ogg', '.aif', '.aiff'].includes(ext)) {
                return resolve(inputPath);
            }

            // WebP images: convert to PNG for After Effects compatibility
            if (ext === '.webp') {
                const pngPath = inputPath.replace(/\.webp$/i, '.png');
                const ffmpeg = getFfmpegPath();
                if (fs.existsSync(ffmpeg)) {
                    const proc = child_process.spawn(ffmpeg, ['-y', '-i', inputPath, pngPath], { windowsHide: true });
                    proc.on('close', code => {
                        if (code === 0 && fs.existsSync(pngPath)) {
                            try { fs.unlinkSync(inputPath); } catch (e) {}
                            return resolve(pngPath);
                        }
                        resolve(inputPath);
                    });
                    proc.on('error', () => resolve(inputPath));
                    return;
                }
                return resolve(inputPath);
            }

            // Inspect video & audio streams using FFprobe
            const ffprobe = getFfprobePath();
            let needsTranscode = false;

            let durationSec = 0;
            let videoHeight = 0;

            if (ext === '.webm' || ext === '.ogv' || ext === '.mkv') {
                needsTranscode = true;
            } else if (fs.existsSync(ffprobe)) {
                try {
                    const probeOut = child_process.execFileSync(ffprobe, [
                        '-v', 'error',
                        '-show_entries', 'stream=codec_name,codec_type,height:format=duration',
                        '-of', 'json',
                        inputPath
                    ], { windowsHide: true, encoding: 'utf8', timeout: 5000 });

                    const data = JSON.parse(probeOut);
                    const streams = data.streams || [];
                    const vStream = streams.find(s => s.codec_type === 'video');
                    const aStream = streams.find(s => s.codec_type === 'audio');
                    durationSec = parseFloat(data.format?.duration || '0') || 0;
                    if (vStream && vStream.height) videoHeight = parseInt(vStream.height, 10) || 0;

                    // After Effects rejects VP9, AV1, VP8, Theora
                    if (vStream) {
                        const vc = (vStream.codec_name || '').toLowerCase();
                        if (['vp9', 'av1', 'av01', 'vp8', 'theora'].includes(vc)) {
                            needsTranscode = true;
                        }
                    }
                    // After Effects rejects Opus, Vorbis
                    if (aStream) {
                        const ac = (aStream.codec_name || '').toLowerCase();
                        if (['opus', 'vorbis'].includes(ac)) {
                            needsTranscode = true;
                        }
                    }
                } catch (e) {
                    if (ext === '.webm' || ext === '.ogv') needsTranscode = true;
                }
            } else {
                if (ext === '.webm' || ext === '.ogv') needsTranscode = true;
            }

            if (!needsTranscode) {
                return resolve(inputPath);
            }

            // Perform rapid transcode to 100% Adobe compatible MP4 (H.264 + AAC + yuv420p)
            if (onProgress) onProgress(91, 1, 1);
            const ffmpeg = getFfmpegPath();
            if (!fs.existsSync(ffmpeg)) {
                return resolve(inputPath);
            }

            const cleanBase = inputPath.replace(/\.[^/.]+$/, "");
            const tempOutput = `${cleanBase}_adobe_ready.mp4`;

            // High-fidelity studio master quality settings (CRF 17 / NVENC CQ 16)
            // Delivers visually lossless clarity matching the 4K source with ultra-fast hardware acceleration
            let vCodecArgs = ["-c:v", "libx264", "-preset", "veryfast", "-crf", "17", "-threads", "0"];
            try {
                const encOut = child_process.execFileSync(ffmpeg, ["-hide_banner", "-encoders"], { encoding: "utf8", windowsHide: true, timeout: 2000 });
                if (encOut.includes("h264_nvenc")) {
                    vCodecArgs = ["-c:v", "h264_nvenc", "-preset", "p2", "-cq", "16", "-b:v", "0", "-maxrate", "120M", "-bufsize", "120M"];
                } else if (encOut.includes("h264_qsv")) {
                    vCodecArgs = ["-c:v", "h264_qsv", "-preset", "veryfast", "-global_quality", "17"];
                } else if (encOut.includes("h264_amf")) {
                    vCodecArgs = ["-c:v", "h264_amf", "-quality", "quality"];
                }
            } catch (e) {}

            const args = [
                "-y",
                "-i", inputPath,
                ...vCodecArgs,
                "-pix_fmt", "yuv420p",
                "-c:a", "aac",
                "-b:a", "320k",
                "-ar", "48000",
                "-movflags", "+faststart",
                tempOutput
            ];

            const proc = child_process.spawn(ffmpeg, args, {
                windowsHide: true,
                stdio: ["ignore", "ignore", "pipe"]
            });
            try {
                if (proc.pid && os && typeof os.setPriority === "function") {
                    os.setPriority(proc.pid, os.constants.priority.PRIORITY_BELOW_NORMAL);
                }
            } catch (_) {}

            // CRITICAL FIX: Drain and parse stderr to prevent 64KB pipe buffer deadlocks and report live progress
            let stderrBuf = "";
            if (proc.stderr) {
                proc.stderr.on("data", (chunk) => {
                    const text = chunk.toString();
                    stderrBuf = (stderrBuf + text).slice(-1500);
                    const timeMatch = text.match(/time=(\d+):(\d+):(\d+\.\d+)/);
                    if (timeMatch && durationSec > 0 && onProgress) {
                        const h = parseFloat(timeMatch[1]);
                        const m = parseFloat(timeMatch[2]);
                        const s = parseFloat(timeMatch[3]);
                        const curSec = (h * 3600) + (m * 60) + s;
                        const pct = Math.min(99, Math.max(91, 90 + Math.round((curSec / durationSec) * 9)));
                        onProgress(pct, 1, 1);
                    }
                });
            }

            proc.on("close", (code) => {
                if (code === 0 && fs.existsSync(tempOutput) && fs.statSync(tempOutput).size > 1000) {
                    try { fs.unlinkSync(inputPath); } catch (e) {}
                    try {
                        if (ext === '.mp4') {
                            fs.renameSync(tempOutput, inputPath);
                            return resolve(inputPath);
                        }
                    } catch (_) {}
                    resolve(tempOutput);
                } else {
                    console.warn("FFmpeg transcode notice (exit code " + code + "):", stderrBuf.slice(-400));
                    resolve(inputPath);
                }
            });

            proc.on("error", (err) => {
                console.warn("FFmpeg spawn error:", err);
                resolve(inputPath);
            });
        });
    }

    /**
     * Download direct HTTP/HTTPS stream directly to disk (64KB chunks, zero RAM overhead)
     */
    function downloadDirectStream(url, destPath, onProgress) {
        return new Promise((resolve, reject) => {
            function doRequest(targetUrl, redirectCount = 0) {
                if (redirectCount > 6) {
                    return reject(new Error("Too many HTTP redirects"));
                }

                const parsedUrl = new URL(targetUrl);
                const client = parsedUrl.protocol === "https:" ? https : http;

                const req = client.get(targetUrl, {
                    headers: {
                        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                        "Accept": "*/*"
                    }
                }, res => {
                    if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
                        const redirectUrl = new URL(res.headers.location, parsedUrl).toString();
                        return doRequest(redirectUrl, redirectCount + 1);
                    }

                    if (res.statusCode !== 200) {
                        return reject(new Error(`Download failed with HTTP status ${res.statusCode}`));
                    }

                    const totalBytes = parseInt(res.headers["content-length"] || "0", 10);
                    let receivedBytes = 0;

                    const fileStream = fs.createWriteStream(destPath);

                    res.on("data", chunk => {
                        receivedBytes += chunk.length;
                        if (totalBytes > 0 && onProgress) {
                            const pct = Math.round((receivedBytes / totalBytes) * 100);
                            onProgress(pct, receivedBytes, totalBytes);
                        }
                    });

                    res.pipe(fileStream);

                    fileStream.on("finish", () => {
                        fileStream.close(() => resolve(destPath));
                    });

                    fileStream.on("error", err => {
                        try { fs.unlinkSync(destPath); } catch (e) {}
                        reject(err);
                    });
                });

                req.on("error", err => {
                    try { fs.unlinkSync(destPath); } catch (e) {}
                    reject(err);
                });
            }

            doRequest(url);
        });
    }

    /**
     * Download YouTube video or audio using yt-dlp + ffmpeg
     */
    function downloadYouTubeStream(sourceUrl, format, destDir, filenameBase, onProgress) {
        return new Promise((resolve, reject) => {
            const ytdlp = getYtDlpPath();
            const binDir = getBinDir();

            if (!fs.existsSync(ytdlp)) {
                return reject(new Error("yt-dlp downloader binary not found."));
            }

            const isYouTube = sourceUrl.includes("youtube.com") || sourceUrl.includes("youtu.be");
            const cacheDir = path.join(process.env.LOCALAPPDATA || process.env.APPDATA || (os && os.tmpdir ? os.tmpdir() : "C:\\Temp"), "MediaFetch", ".cache");

            // Locate Node.js executable for JS challenges
            const nodeCandidates = [
                "C:\\Program Files\\nodejs\\node.exe",
                "C:\\Program Files (x86)\\nodejs\\node.exe",
                path.join(process.env.LOCALAPPDATA || "", "Programs", "node", "node.exe")
            ];
            let nodeBin = "node";
            for (const nc of nodeCandidates) {
                if (fs.existsSync(nc)) { nodeBin = nc; break; }
            }
            const jsRuntime = nodeBin === "node" ? "node" : `node:${nodeBin}`;

            // Load shared live visitor data token
            let visitorData = "CgtOR2NfOVFoTm9HYyiv0LPWBjIKCgJJThIEGgAgYGKzAgqwAkN1RUJDQVVTa3dFQjhRWnVac2NMUGktQlRuSVVoS3FVLV80NFdfOW95bkFwVDlDVzlxbUl1M3h6QkE3aWxMTHZhbFVEMHNzdnJVanZkLXlHSjNpLWgzUEczRHVzaV9OTmVRd21DdXZSd3BlRHVtV0loZkZQNVBHN1ZUM1VaT1pPdzJ2U1l0QVdTeHE4YnpjNVBNdmEzeWpPci02VHEwc0RRVzVDSEhYMU5ZREx5QklvU1F2cmh2V3RseHlJcW1FWkpHR2dnODY0ckhUNTFTc29CVEpGQWQ2cG5VOU5TRVNPM0lMWkZYeFNUZUEtbnFJdEM3eGdsWEU4eldqS2FCZDctamJ4ZERuUUxHYVFacXdRdGJ5djlUVWp4UjhGTkNuYmU2bi1idWZDMWE1OGFxTUw=";
            const visitorFile = path.join(process.env.LOCALAPPDATA || (os && os.homedir ? path.join(os.homedir(), "AppData", "Local") : "."), "MediaFetch", "visitor_data.txt");
            if (fs.existsSync(visitorFile)) {
                try {
                    const savedVd = fs.readFileSync(visitorFile, "utf8").trim();
                    if (savedVd && savedVd.length > 20) visitorData = savedVd;
                } catch (_) {}
            }

            const outputTemplate = path.join(destDir, `${filenameBase}.%(ext)s`);
            const args = [
                sourceUrl,
                "-o", outputTemplate,
                "--no-playlist",
                "--no-check-certificates",
                "--no-mtime",
                "--cache-dir", cacheDir,
                "--js-runtimes", jsRuntime,
                "--remote-components", "ejs:github",
                ...(isYouTube ? ["--extractor-args", `youtube:player_client=web,default;visitor_data=${visitorData}`] : []),
                "--buffer-size", "16M",
                "--http-chunk-size", "10M",
                "--newline",
                "--concurrent-fragments", "16",
                "--socket-timeout", "30"
            ];

            const localAppData = process.env.LOCALAPPDATA || (os && os.homedir ? path.join(os.homedir(), 'AppData', 'Local') : '');
            const cookiesFilePath = localAppData ? path.join(localAppData, 'MediaFetch', 'cookies.txt') : '';
            if (cookiesFilePath && fs.existsSync(cookiesFilePath) && fs.statSync(cookiesFilePath).size > 10) {
                args.push('--cookies', cookiesFilePath);
            }

            const actualFfmpeg = getFfmpegPath();
            const actualFfmpegDir = (actualFfmpeg && fs.existsSync(actualFfmpeg)) ? path.dirname(actualFfmpeg) : binDir;
            if (actualFfmpegDir) {
                args.push("--ffmpeg-location", actualFfmpegDir);
            }

            const tr = (format && format.timeRange) ? format.timeRange : null;
            const hasTimeRange = Boolean(tr && (tr.start || tr.end));

            const isWav = format && (format.ext === "wav" || format.quality === "audio-wav");
            const isFlac = format && (format.ext === "flac" || format.quality === "audio-flac");
            const isM4a = format && (format.ext === "m4a" || format.quality === "audio-m4a" || format.ext === "aac");
            const isAudio = format && (format.type === "audio" || format.quality === "audio" || isWav || isFlac || isM4a || format.ext === "mp3");

            if (isAudio) {
                if (isWav) {
                    args.push("-x", "--audio-format", "wav");
                } else if (isFlac) {
                    args.push("-x", "--audio-format", "flac");
                } else if (isM4a) {
                    args.push("-x", "--audio-format", "m4a");
                } else {
                    args.push("-x", "--audio-format", "mp3", "--audio-quality", "0");
                }
            } else {
                let targetRes = 1080;
                const q = String(format?.quality || "").toLowerCase();
                if (q === "2160" || q === "4k") targetRes = 2160;
                else if (q === "1440" || q === "2k") targetRes = 1440;
                else if (q === "1080") targetRes = 1080;
                else if (q === "720") targetRes = 720;
                else if (q === "480") targetRes = 480;
                else if (q === "360") targetRes = 360;
                else if (q === "best") targetRes = 9999;
                else if (typeof format?.resolution === "number" && format.resolution > 0) targetRes = format.resolution;

                if (targetRes >= 9999) {
                    args.push("-S", "res,codec:h264:vp9");
                    args.push("-f", "bestvideo[protocol^=m3u8]+bestaudio[protocol^=m3u8]/bestvideo[vcodec!*=av01]+bestaudio[ext=m4a]/bestvideo[vcodec!*=av01]+bestaudio/bestvideo+bestaudio/best");
                } else {
                    args.push("-S", `res:${targetRes},codec:h264:vp9`);
                    args.push("-f", `bestvideo[height<=?${targetRes}][protocol^=m3u8]+bestaudio[protocol^=m3u8]/bestvideo[height<=?${targetRes}][vcodec!*=av01]+bestaudio[ext=m4a]/bestvideo[height<=?${targetRes}][vcodec!*=av01]+bestaudio/bestvideo+bestaudio/best`);
                }
                args.push("--merge-output-format", "mp4");
            }

            if (!isAudio) {
                args.push("--merge-output-format", "mp4");
            }

            const proc = child_process.spawn(ytdlp, args, {
                windowsHide: true,
                stdio: ["ignore", "pipe", "pipe"]
            });
            try {
                if (proc.pid && os && typeof os.setPriority === "function") {
                    os.setPriority(proc.pid, os.constants.priority.PRIORITY_BELOW_NORMAL);
                }
            } catch (_) {}

            let finalFilePath = "";
            let stderrBuf = "";
            let lastProgressTime = 0;
            const throttledProgress = (pct, recv, tot) => {
                const now = Date.now();
                if (pct === 100 || now - lastProgressTime >= 150) {
                    lastProgressTime = now;
                    if (onProgress) onProgress(pct, recv, tot);
                }
            };

            proc.stdout.on("data", data => {
                const text = data.toString();
                const match = text.match(/\[download\]\s+([\d\.]+)%/);
                if (match) {
                    const pct = Math.round(parseFloat(match[1]));
                    throttledProgress(pct, 0, 0);
                }

                const destMatch = text.match(/\[(?:download|Merger|ExtractAudio|VideoConvertor)\] Destination:\s+(.+)$/m)
                    || text.match(/\[download\]\s+(.+?)\s+has already been downloaded/m);
                if (destMatch) {
                    finalFilePath = destMatch[1].trim();
                }
            });

            proc.stderr.on("data", data => {
                const text = data.toString();
                stderrBuf = (stderrBuf + text).slice(-1500);
            });

            proc.on("close", code => {
                if (code === 0) {
                    if (!finalFilePath || !fs.existsSync(finalFilePath) || (!isAudio && /\.(m4a|mp3|aac|ogg|opus)$/i.test(finalFilePath))) {
                        const files = fs.readdirSync(destDir);
                        const candidates = files.filter(f => f.startsWith(filenameBase) && !f.endsWith('.part') && !f.endsWith('.ytdl'));
                        if (candidates.length > 0) {
                            if (!isAudio) {
                                const videoFile = candidates.find(f => /\.(mp4|mov|mkv|webm)$/i.test(f));
                                if (videoFile) {
                                    finalFilePath = path.join(destDir, videoFile);
                                } else if (!finalFilePath || !fs.existsSync(finalFilePath)) {
                                    finalFilePath = path.join(destDir, candidates[0]);
                                }
                            } else {
                                const audioFile = candidates.find(f => /\.(mp3|wav|m4a|flac|aac|ogg)$/i.test(f));
                                if (audioFile) {
                                    finalFilePath = path.join(destDir, audioFile);
                                } else if (!finalFilePath || !fs.existsSync(finalFilePath)) {
                                    finalFilePath = path.join(destDir, candidates[0]);
                                }
                            }
                        }
                    }

                    // Instant lossless stream copy trim (0.01s - 100% master quality)
                    if (hasTimeRange && finalFilePath && fs.existsSync(finalFilePath)) {
                        const ffmpeg = getFfmpegPath();
                        if (fs.existsSync(ffmpeg)) {
                            const ext = path.extname(finalFilePath) || (isAudio ? ".mp3" : ".mp4");
                            const trimmedPath = path.join(destDir, `${filenameBase}_clip${ext}`);
                            const s = (tr.start || "00:00:00").trim();
                            const e = (tr.end || "99:59:59").trim();
                            try {
                                child_process.execFileSync(ffmpeg, [
                                    "-y", "-ss", s, "-to", e, "-i", finalFilePath, "-c", "copy", "-movflags", "+faststart", trimmedPath
                                ], { windowsHide: true, timeout: 20000 });
                                if (fs.existsSync(trimmedPath) && fs.statSync(trimmedPath).size > 1000) {
                                    try { fs.unlinkSync(finalFilePath); } catch (_) {}
                                    finalFilePath = trimmedPath;
                                }
                            } catch (trimErr) {
                                console.warn("[MediaFetch] Post-download stream copy notice:", trimErr);
                            }
                        }
                    }

                    resolve(finalFilePath || path.join(destDir, `${filenameBase}.${format.ext || (isAudio ? "mp3" : "mp4")}`));
                } else {
                    const cleanErr = (stderrBuf || "").trim() || `yt-dlp exited with code ${code}`;
                    reject(new Error(cleanErr));
                }
            });

            proc.on("error", err => reject(err));
        });
    }

    /**
     * Master download & import entry point
     */
    async function downloadAndImport(item, selectedFormat, csInterface, onProgress) {
        if (!isNode) {
            throw new Error("Cannot download files outside Adobe CEP environment.");
        }

        // License Authorization Guard
        if (typeof window !== "undefined" && window.MediaFetchLicense && typeof window.MediaFetchLicense.isAuthorized === "function") {
            if (!window.MediaFetchLicense.isAuthorized()) {
                if (typeof window.MediaFetchLicense.showModal === "function") {
                    window.MediaFetchLicense.showModal("A valid license is required to download media.");
                }
                throw new Error("License verification required.");
            }
        }

        const rawExt = (selectedFormat && selectedFormat.ext) || "mp4";
        const cleanExt = rawExt.split("?")[0].toLowerCase().replace(/^\./, '');
        let mediaType = "Video";
        if (['mp3', 'wav', 'm4a', 'flac', 'aac', 'ogg', 'opus', 'aiff'].includes(cleanExt) || item.mediaType === 'audio') {
            mediaType = "Audio";
        } else if (['jpg', 'jpeg', 'png', 'webp', 'gif', 'bmp', 'svg', 'tiff', 'tif'].includes(cleanExt) || item.mediaType === 'image' || item.type === 'image') {
            mediaType = "Image";
        }

        const destDir = await getDownloadDirectory(csInterface, mediaType);
        const cleanTitle = sanitizeFilename(item.title || "media_asset");
        const finalFilename = `${cleanTitle}_${Date.now()}.${cleanExt}`;
        const destPath = path.join(destDir, finalFilename);

        let downloadedFilePath = destPath;

        // 1. Download
        if (item.source === "youtube" || (item.pageUrl && item.pageUrl.includes("youtube.com"))) {
            const filenameBase = `${cleanTitle}_${Date.now()}`;
            downloadedFilePath = await downloadYouTubeStream(item.pageUrl, selectedFormat, destDir, filenameBase, onProgress);
        } else if (item.source === "songs" || item.source === "itunes" || item.source === "spotify" || item.subtype === "song") {
            const filenameBase = `${cleanTitle}_${Date.now()}`;
            const targetQuery = (selectedFormat && selectedFormat.query) || `${item.title} ${item.author || ""} audio`;
            const searchQuery = `ytsearch1:${targetQuery}`;
            downloadedFilePath = await downloadYouTubeStream(searchQuery, selectedFormat, destDir, filenameBase, onProgress);
        } else {
            const downloadUrl = (selectedFormat && selectedFormat.url) || item.downloadFormats[0].url;
            await downloadDirectStream(downloadUrl, destPath, onProgress);
        }

        if (onProgress) onProgress(90, 1, 1);

        // 2. Resolve Host Application (Premiere Pro vs After Effects)
        let hostApp = "";
        if (csInterface) {
            try {
                if (typeof csInterface.getHostEnvironment === "function") {
                    const env = csInterface.getHostEnvironment();
                    if (env && env.appId) {
                        const aid = env.appId.toUpperCase();
                        if (aid.includes("PPRO") || aid.includes("PREM")) hostApp = "premierepro";
                        else if (aid.includes("AEFT") || aid.includes("AE")) hostApp = "aftereffects";
                    }
                }
            } catch (e) {}
            if (!hostApp) {
                try {
                    const hostInfoStr = await new Promise(resolve => {
                        csInterface.evalScript("MediaFetchHost.getHostInfo()", resolve);
                    });
                    const hInfo = JSON.parse(hostInfoStr);
                    if (hInfo && hInfo.appName) hostApp = hInfo.appName.toLowerCase();
                } catch (e) {}
            }
        }

        // 3. Guarantee 100% Adobe Premiere Pro & After Effects compatibility (preserving 100% master quality)
        downloadedFilePath = await ensureAdobeCompatible(downloadedFilePath, onProgress, hostApp);

        if (onProgress) onProgress(100, 1, 1);

        // 4. Auto-import cleanly into Adobe Premiere or After Effects Project Bin / Timeline based on UI checkboxes
        if (csInterface && fs.existsSync(downloadedFilePath)) {
            let shouldImportToProject = true;
            let shouldAddToTimeline = false;
            if (typeof document !== "undefined") {
                const projChk = document.getElementById("studio-auto-import-chk") || document.getElementById("main-auto-import-chk");
                const timelineChk = document.getElementById("studio-auto-timeline-chk") || document.getElementById("main-auto-timeline-chk");
                if (projChk) shouldImportToProject = Boolean(projChk.checked);
                if (timelineChk) shouldAddToTimeline = Boolean(timelineChk.checked);
            }

            // If user unchecked both Project and Timeline checkboxes, save file to disk only without importing
            if (!shouldImportToProject && !shouldAddToTimeline) {
                console.log("[MediaFetch] Both Project and Timeline checkboxes are unchecked. Keeping downloaded media file on disk without Adobe import.");
                return {
                    filePath: downloadedFilePath,
                    imported: false,
                    hostResult: { success: true, imported: false, skipped: true }
                };
            }

            const addToTimeline = shouldAddToTimeline;
            const escapedPath = downloadedFilePath.replace(/\\/g, "/");
            const optsJson = JSON.stringify({
                isSingleLink: true,
                addToTimeline: addToTimeline,
                importToProject: shouldImportToProject,
                autoImportToProject: shouldImportToProject
            });

            return new Promise((resolve, reject) => {
                csInterface.evalScript(`MediaFetchHost.importMedia("${escapedPath}", ${addToTimeline}, '${optsJson}')`, async (res) => {
                    let result = {};
                    try {
                        result = JSON.parse(res);
                    } catch (e) {
                        result = { success: false, error: res };
                    }

                    if (result && result.success === false) {
                        const isAudioFile = ['mp3', 'wav', 'm4a', 'flac', 'aac', 'ogg', 'opus', 'aiff'].includes(cleanExt) || mediaType === 'Audio';
                        if (isAudioFile && cleanExt !== 'wav') {
                            try {
                                const wavDest = downloadedFilePath.replace(/\.[a-zA-Z0-9]+$/, '_master.wav');
                                const ffmpegBin = getFfmpegPath();
                                if (ffmpegBin && fs.existsSync(ffmpegBin)) {
                                    await new Promise((resWav, rejWav) => {
                                        child_process.execFile(ffmpegBin, ['-y', '-i', downloadedFilePath, '-ar', '48000', '-ac', '2', wavDest], { windowsHide: true }, (err) => {
                                            if (err || !fs.existsSync(wavDest)) rejWav(err || new Error("WAV transcode failed"));
                                            else resWav();
                                        });
                                    });
                                    const retryWavEscaped = wavDest.replace(/\\/g, "/");
                                    csInterface.evalScript(`MediaFetchHost.importMedia("${retryWavEscaped}", ${addToTimeline}, '${optsJson}')`, (wavRes) => {
                                        let wObj = {};
                                        try { wObj = JSON.parse(wavRes); } catch (e) {}
                                        if (wObj && wObj.success !== false) {
                                            return resolve({ filePath: wavDest, imported: true, hostResult: wObj });
                                        }
                                        return reject(new Error((wObj && wObj.error) || "Adobe failed to import audio"));
                                    });
                                    return;
                                }
                            } catch (_) {}
                        }

                        // Fallback: If Premiere Pro or After Effects failed on stream, transcode to master H.264 and retry import
                        if (downloadedFilePath === destPath || downloadedFilePath.toLowerCase().endsWith('.webm')) {
                            try {
                                const fallbackPath = await ensureAdobeCompatible(downloadedFilePath, onProgress, "aftereffects");
                                const retryEscaped = fallbackPath.replace(/\\/g, "/");
                                csInterface.evalScript(`MediaFetchHost.importMedia("${retryEscaped}", ${addToTimeline}, '${optsJson}')`, (retryRes) => {
                                    let rObj = {};
                                    try { rObj = JSON.parse(retryRes); } catch (e) {}
                                    if (rObj && rObj.success === false) {
                                        return reject(new Error(rObj.error || "Adobe failed to import media"));
                                    }
                                    return resolve({ filePath: fallbackPath, imported: true, hostResult: rObj });
                                });
                                return;
                            } catch (fallbackErr) {
                                return reject(fallbackErr);
                            }
                        }
                        return reject(new Error(result.error || "Adobe failed to import media"));
                    }

                    resolve({
                        filePath: downloadedFilePath,
                        imported: true,
                        hostResult: result
                    });
                });
            });
        }

        return { filePath: downloadedFilePath, imported: false };
    }

    return {
        downloadAndImport: downloadAndImport,
        getDownloadDirectory: getDownloadDirectory
    };
})();

if (typeof module !== "undefined" && module.exports) {
    module.exports = Downloader;
} else {
    window.Downloader = Downloader;
}
