/**
 * MediaFetch Search Studio Engine
 * Orchestrates 18+ Platforms across 5 Categories with direct Premiere Pro & After Effects Import
 */
const SearchStudio = (function () {
    const csInterface = typeof CSInterface !== "undefined" ? new CSInterface() : null;

    function showStudioNotification(msg, duration = 4000) {
        if (typeof window !== "undefined" && window.app && typeof window.app.showHeaderToast === "function") {
            window.app.showHeaderToast(msg, duration);
            return;
        }
        let toast = document.getElementById("studio-toast-banner");
        if (!toast) {
            toast = document.createElement("div");
            toast.id = "studio-toast-banner";
            toast.style.cssText = "position:fixed; bottom:24px; left:50%; transform:translateX(-50%); background:rgba(20,20,24,0.96); border:1px solid rgba(255,255,255,0.18); color:#f0f0f0; padding:10px 18px; border-radius:8px; font-size:12px; z-index:999999; box-shadow:0 8px 24px rgba(0,0,0,0.6); pointer-events:none; transition:opacity 0.25s ease; opacity:0; font-family:sans-serif; text-align:center; max-width:90%;";
            document.body.appendChild(toast);
        }
        toast.textContent = msg;
        toast.style.opacity = "1";
        clearTimeout(toast._timer);
        toast._timer = setTimeout(() => {
            toast.style.opacity = "0";
        }, duration);
    }

    // Platform Configuration - 100% Working, Keyless, Reliable Platforms
    const categoryConfig = {
        video: {
            placeholder: "Search 4K B-Roll, drone shots, documentary clips...",
            platforms: [
                { id: "all", label: "All Video Sources" },
                { id: "youtube", label: "YouTube 4K/HD" },
                { id: "pexels", label: "Pexels 4K/HD" },
                { id: "pixabay", label: "Pixabay Video" },
                { id: "wikimedia", label: "Wikimedia 4K/HD" }
            ]
        },
        photo: {
            placeholder: "Search 700M+ photos, 4K/8K wallpapers, textures, art...",
            platforms: [
                { id: "all", label: "All Photos & Art" },
                { id: "unsplash", label: "Unsplash HD" },
                { id: "pexels", label: "Pexels Photos" },
                { id: "pixabay", label: "Pixabay Photos" },
                { id: "wallhaven", label: "Wallhaven 4K/8K" },
                { id: "openverse", label: "Openverse (700M+)" },
                { id: "wikimedia", label: "Wikimedia Art" }
            ]
        },
        audio: {
            placeholder: "Search songs, background music, foley, sound effects...",
            platforms: [
                { id: "all", label: "All Music & SFX" },
                { id: "songs", label: "Songs" },
                { id: "jamendo", label: "Jamendo Music" },
                { id: "youtube_audio", label: "YouTube Audio" },
                { id: "freesound", label: "FreeSound / Foley" }
            ]
        }
    };

    let currentCategory = "video";
    let currentPlatform = "all";
    let currentOrientationFilter = "all"; // "all" | "landscape" | "portrait"
    let currentSongFilter = "all"; // "all" | "songs" | "albums" | "artists" | "playlists"
    let isSearching = false;
    let progressiveQueue = [];
    let isProcessingQueue = false;

    // Single global audio preview player
    const globalAudio = new Audio();
    let currentPlayBtn = null;

    globalAudio.addEventListener("ended", () => {
        if (currentPlayBtn) {
            currentPlayBtn.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>`;
            currentPlayBtn = null;
        }
    });

    // Single global active video preview tracker
    let activeVideoPreview = null;
    let fadeTimer = null;
    let currentSearchId = 0;
    let renderedItemIds = new Set();
    let userMidWidth = null;
    let userMidHeight = null;
    let activeTheaterItem = null;
    let currentStreamRequestId = 0;
    let activeStreamAbortController = null;
    const playbackTimelineMemory = new Map();

    function matchesOrientationFilter(item, orientation) {
        if (!item || !orientation || orientation === "all") return true;
        if (item.type === "audio" || item.mediaType === "audio") return true;

        let w = item.width || 0;
        let h = item.height || 0;

        if ((!w || !h) && item.downloadFormats && item.downloadFormats.length > 0) {
            for (const f of item.downloadFormats) {
                if (f.width && f.height) {
                    w = f.width;
                    h = f.height;
                    break;
                }
            }
        }

        // When physical width and height exist, aspect ratio is authoritative
        if (w > 0 && h > 0) {
            const ratio = w / h;
            if (orientation === "landscape") {
                return ratio >= 1.15;
            } else if (orientation === "portrait") {
                return ratio <= 0.85;
            } else if (orientation === "square") {
                return ratio > 0.85 && ratio < 1.15;
            }
            return true;
        }

        // Fallback heuristics ONLY when physical dimensions are unknown
        function isShortDuration(d) {
            if (!d) return false;
            if (typeof d === "number") return d > 0 && d <= 60;
            if (typeof d !== "string") return false;
            d = d.trim().toLowerCase();
            if (d === "short" || d.includes("short")) return true;
            const parts = d.split(":").map(p => parseInt(p, 10));
            if (parts.some(isNaN)) return false;
            if (parts.length === 1) return parts[0] <= 60;
            if (parts.length === 2) return (parts[0] * 60 + parts[1]) <= 60;
            return false;
        }

        const isShortByDur = isShortDuration(item.durationString) || isShortDuration(item.duration);
        const hasShortsTag = typeof item.title === "string" && (/#shorts\b|#short\b|\bshorts\b|\bvertical\b|\btiktok\b|\breel\b/i.test(item.title));
        const isUrlShort = typeof item.pageUrl === "string" && (item.pageUrl.includes("/shorts/") || item.pageUrl.includes("/reel/"));
        const isExplicitShort = Boolean(
            item.isShort ||
            item.subtype === "short" ||
            item.badge === "SHORT" ||
            item.durationString === "Short" ||
            item.duration === "Short" ||
            item.source === "tiktok" ||
            item.platform === "tiktok" ||
            hasShortsTag ||
            isUrlShort ||
            (isShortByDur && (hasShortsTag || item.source === "tiktok"))
        );

        if (orientation === "landscape") {
            return !isExplicitShort;
        } else if (orientation === "portrait") {
            return isExplicitShort;
        }

        return true;
    }

    function getResumeLimit() {
        try {
            const raw = localStorage.getItem("mf_resume_history_limit");
            if (raw === "all") return Infinity;
            const parsed = parseInt(raw, 10);
            return (!isNaN(parsed) && parsed > 0) ? parsed : 3; // Default 3 videos for memory optimization
        } catch (_) {
            return 3;
        }
    }

    function recordPlaybackTimeline(key, currentTime) {
        if (!key || typeof currentTime !== "number" || currentTime <= 0) return;
        const curSec = Math.floor(currentTime);

        playbackTimelineMemory.set(key, curSec);
        try {
            sessionStorage.setItem("mf_resume_" + key, String(curSec));
            localStorage.setItem("mf_resume_" + key, String(curSec));

            // LRU queue tracking
            let order = [];
            try {
                const storedOrder = localStorage.getItem("mf_resume_keys_order");
                if (storedOrder) order = JSON.parse(storedOrder);
            } catch (_) {}

            if (!Array.isArray(order)) order = [];
            order = order.filter(k => k !== key && k !== ("yt_" + key));
            order.unshift(key);

            const limit = getResumeLimit();
            while (order.length > limit) {
                const purgedKey = order.pop();
                if (purgedKey) {
                    playbackTimelineMemory.delete(purgedKey);
                    playbackTimelineMemory.delete("yt_" + purgedKey);
                    sessionStorage.removeItem("mf_resume_" + purgedKey);
                    sessionStorage.removeItem("mf_resume_yt_" + purgedKey);
                    localStorage.removeItem("mf_resume_" + purgedKey);
                    localStorage.removeItem("mf_resume_yt_" + purgedKey);
                }
            }

            localStorage.setItem("mf_resume_keys_order", JSON.stringify(order));
        } catch (_) {}
    }

    function pruneStoredResumeHistory() {
        const limit = getResumeLimit();
        try {
            let order = [];
            const storedOrder = localStorage.getItem("mf_resume_keys_order");
            if (storedOrder) order = JSON.parse(storedOrder);
            if (Array.isArray(order) && order.length > limit) {
                while (order.length > limit) {
                    const purged = order.pop();
                    if (purged) {
                        playbackTimelineMemory.delete(purged);
                        playbackTimelineMemory.delete("yt_" + purged);
                        sessionStorage.removeItem("mf_resume_" + purged);
                        localStorage.removeItem("mf_resume_" + purged);
                    }
                }
                localStorage.setItem("mf_resume_keys_order", JSON.stringify(order));
            }
        } catch (_) {}
    }

    function getStudioServicePort() {
        if (typeof window.getServicePort === "function") return window.getServicePort();
        if (window.MF_SERVICE_PORT) return window.MF_SERVICE_PORT;
        if (window.location && window.location.port && window.location.protocol.startsWith("http")) return window.location.port;
        return (document.title && document.title.includes("Pro")) ? 48924 : 48923;
    }

    function getYouTubePlayerUrl(vidId, startSeconds = 0, quality = "") {
        const q = quality || localStorage.getItem("mf_default_stream_quality") || "720";
        const p = getStudioServicePort();
        let url = `http://127.0.0.1:${p}/youtube-player.html?v=${encodeURIComponent(vidId)}&port=${p}&autoplay=1&quality=${encodeURIComponent(q)}`;
        if (startSeconds && startSeconds > 0) {
            url += `&start=${Math.floor(startSeconds)}`;
        }
        return url;
    }

    function openMediaInDefaultBrowser(url) {
        if (!url) return;
        try {
            if (window.__adobe_cep__ && typeof window.__adobe_cep__.openURLInDefaultBrowser === "function") {
                window.__adobe_cep__.openURLInDefaultBrowser(url);
                return;
            }
            if (window.cep && window.cep.util && typeof window.cep.util.openURLInDefaultBrowser === "function") {
                window.cep.util.openURLInDefaultBrowser(url);
                return;
            }
        } catch (_) {}
        try {
            window.open(url, "_blank");
        } catch (_) {}
    }

    // Capture playback time reports, embed restriction signals, and open browser requests
    window.addEventListener("message", (e) => {
        try {
            if (e.data && e.data.type === "MF_PLAYBACK_TIME") {
                const cur = typeof e.data.currentTime === "number" ? e.data.currentTime : parseFloat(e.data.currentTime);
                if (cur > 0) {
                    if (e.data.videoId) {
                        recordPlaybackTimeline(e.data.videoId, cur);
                        recordPlaybackTimeline("yt_" + e.data.videoId, cur);
                    }
                    if (activeTheaterItem && activeTheaterItem.id) {
                        recordPlaybackTimeline(activeTheaterItem.id, cur);
                    }
                }
            } else if (e.data && e.data.type === "MF_FULLSCREEN_CHANGE") {
                if (e.data.isFullscreen && !isCurrentFullscreen()) {
                    toggleTheaterFullscreen();
                } else if (!e.data.isFullscreen && isCurrentFullscreen()) {
                    toggleTheaterFullscreen();
                }
            } else if (e.data && e.data.type === "MF_OPEN_BROWSER" && e.data.url) {
                openMediaInDefaultBrowser(e.data.url);
            } else if (e.data && e.data.type === "MF_EMBED_RESTRICTED") {
                const formatSelect = document.getElementById("theater-format-select");
                if (formatSelect && formatSelect.value === "embed") {
                    const defaultQuality = localStorage.getItem("mf_default_stream_quality") || "720";
                    formatSelect.value = "direct-" + defaultQuality;
                    if (typeof formatSelect.onchange === "function") {
                        formatSelect.onchange();
                    }
                }
            }
        } catch (_) {}
    });

    function stopActiveVideoPreview() {
        if (!activeVideoPreview) return;
        try {
            if (activeVideoPreview.type === "youtube" && activeVideoPreview.iframe) {
                try { activeVideoPreview.iframe.src = "about:blank"; } catch (_) {}
                activeVideoPreview.iframe.remove();
            } else if (activeVideoPreview.type === "html5" && activeVideoPreview.video) {
                activeVideoPreview.video.pause();
                activeVideoPreview.video.removeAttribute("src");
                try { activeVideoPreview.video.load(); } catch (_) {}
                activeVideoPreview.video.remove();
            }
            if (activeVideoPreview.container) {
                activeVideoPreview.container.style.display = "none";
                activeVideoPreview.container.innerHTML = "";
            }
            if (activeVideoPreview.playBtn) {
                const isAudioBtn = activeVideoPreview.playBtn.classList.contains("studio-audio-play-btn");
                const sz = isAudioBtn ? 13 : 14;
                activeVideoPreview.playBtn.innerHTML = `<svg width="${sz}" height="${sz}" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>`;
                activeVideoPreview.playBtn.classList.remove("playing", "faded");
                activeVideoPreview.playBtn.title = isAudioBtn ? "Play Audio Preview" : "Play Video Preview";
            }
        } catch (_) {}
        if (fadeTimer) {
            clearTimeout(fadeTimer);
            fadeTimer = null;
        }
        activeVideoPreview = null;
    }

    function pauseActiveVideo() {
        if (!activeVideoPreview || !activeVideoPreview.isPlaying) return;
        try {
            if (activeVideoPreview.type === "youtube" && activeVideoPreview.iframe) {
                activeVideoPreview.iframe.contentWindow.postMessage('{"event":"command","func":"pauseVideo","args":""}', '*');
            } else if (activeVideoPreview.type === "html5" && activeVideoPreview.video) {
                activeVideoPreview.video.pause();
            }
            activeVideoPreview.isPlaying = false;
            if (activeVideoPreview.playBtn) {
                const isAudioBtn = activeVideoPreview.playBtn.classList.contains("studio-audio-play-btn");
                const sz = isAudioBtn ? 13 : 14;
                activeVideoPreview.playBtn.innerHTML = `<svg width="${sz}" height="${sz}" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>`;
                activeVideoPreview.playBtn.classList.remove("playing", "faded");
                activeVideoPreview.playBtn.title = isAudioBtn ? "Resume Audio Preview" : "Resume Video Preview";
            }
            if (fadeTimer) {
                clearTimeout(fadeTimer);
                fadeTimer = null;
            }
        } catch (_) {}
    }

    function resumeActiveVideo() {
        if (!activeVideoPreview || activeVideoPreview.isPlaying) return;
        try {
            if (activeVideoPreview.type === "youtube" && activeVideoPreview.iframe) {
                activeVideoPreview.iframe.contentWindow.postMessage('{"event":"command","func":"playVideo","args":""}', '*');
            } else if (activeVideoPreview.type === "html5" && activeVideoPreview.video) {
                activeVideoPreview.video.play().catch(() => {});
            }
            activeVideoPreview.isPlaying = true;
            if (activeVideoPreview.playBtn) {
                const isAudioBtn = activeVideoPreview.playBtn.classList.contains("studio-audio-play-btn");
                const sz = isAudioBtn ? 13 : 14;
                activeVideoPreview.playBtn.innerHTML = `<svg width="${sz}" height="${sz}" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16"></rect><rect x="14" y="4" width="4" height="16"></rect></svg>`;
                activeVideoPreview.playBtn.classList.add("playing");
                activeVideoPreview.playBtn.title = isAudioBtn ? "Pause Audio Preview" : "Pause Video Preview";
            }
            scheduleFadeOut();
        } catch (_) {}
    }

    function scheduleFadeOut() {
        if (fadeTimer) clearTimeout(fadeTimer);
        fadeTimer = setTimeout(() => {
            if (activeVideoPreview && activeVideoPreview.isPlaying && activeVideoPreview.playBtn) {
                activeVideoPreview.playBtn.classList.add("faded");
            }
        }, 1200); // 1.2 seconds auto fade so button doesn't linger
    }

    function showPlayButton() {
        if (activeVideoPreview && activeVideoPreview.playBtn) {
            activeVideoPreview.playBtn.classList.remove("faded");
            if (activeVideoPreview.isPlaying) {
                scheduleFadeOut();
            }
        }
    }

    function init() {
        bindStudioSettings();
        bindModeToggle();
        bindCategoryTabs();
        bindSearchInput();
        bindFilterDropdown();
        bindTheaterModal();
        renderPlatformPills();

        const studioContent = document.querySelector("#mediaSearchView .studio-content");
        if (studioContent) {
            studioContent.addEventListener("scroll", () => {
                if (progressiveQueue.length > 0 && !isProcessingQueue) {
                    const scrollRemaining = studioContent.scrollHeight - (studioContent.scrollTop + studioContent.clientHeight);
                    if (scrollRemaining < 800) {
                        scheduleNextChunk(currentSearchId);
                    }
                }
            }, { passive: true });
        }
    }

    
    // Wire Studio Settings into Unified Settings Modal
    function bindStudioSettings() {
        const modal = document.getElementById("modal-settings");
        const btnOpenHeader = document.getElementById("btn-top-settings");
        const btnSave = document.getElementById("btn-save-settings");

        function loadStudioSettings() {
            const pexelsInput = document.getElementById("setting-studio-pexels-key");
            const pixabayInput = document.getElementById("setting-studio-pixabay-key");
            const unsplashInput = document.getElementById("setting-studio-unsplash-key");
            const giphyInput = document.getElementById("setting-studio-giphy-key");
            const spotifyIdInput = document.getElementById("setting-studio-spotify-id");
            const spotifySecretInput = document.getElementById("setting-studio-spotify-secret");
            const timelineCheck = document.getElementById("setting-studio-auto-timeline");
            const pauseTabCheck = document.getElementById("setting-studio-pause-tab-change");

            if (typeof Settings !== "undefined") {
                const s = Settings.load();
                if (pexelsInput) pexelsInput.value = s.pexelsApiKey || "";
                if (pixabayInput) pixabayInput.value = s.pixabayApiKey || "";
                if (unsplashInput) unsplashInput.value = s.unsplashApiKey || "";
                if (giphyInput) giphyInput.value = s.giphyApiKey || "";
                if (spotifyIdInput) spotifyIdInput.value = s.spotifyClientId || "";
                if (spotifySecretInput) spotifySecretInput.value = s.spotifyClientSecret || "";
                if (timelineCheck) timelineCheck.checked = s.autoInsertTimeline !== false;
                if (pauseTabCheck) pauseTabCheck.checked = s.pausePreviewOnTabChange === true;
            }

            const engineSel = document.getElementById("setting-studio-player-engine");
            const qualitySel = document.getElementById("setting-studio-stream-quality");
            if (engineSel) {
                engineSel.value = localStorage.getItem("mf_default_player_engine") || "embed";
            }
            if (qualitySel) {
                qualitySel.value = localStorage.getItem("mf_default_stream_quality") || "720";
            }

            const resumeLimitSel = document.getElementById("setting-studio-resume-limit");
            if (resumeLimitSel) {
                const savedLimit = localStorage.getItem("mf_resume_history_limit") || "3";
                resumeLimitSel.value = savedLimit;
                resumeLimitSel.onchange = () => {
                    localStorage.setItem("mf_resume_history_limit", resumeLimitSel.value);
                    pruneStoredResumeHistory();
                };
            }
        }

        function saveStudioSettings() {
            const pexelsInput = document.getElementById("setting-studio-pexels-key");
            const pixabayInput = document.getElementById("setting-studio-pixabay-key");
            const unsplashInput = document.getElementById("setting-studio-unsplash-key");
            const giphyInput = document.getElementById("setting-studio-giphy-key");
            const spotifyIdInput = document.getElementById("setting-studio-spotify-id");
            const spotifySecretInput = document.getElementById("setting-studio-spotify-secret");
            const customLoc = document.getElementById("setting-custom-location");
            const modeSel = document.getElementById("setting-location-mode");
            const pauseTabCheck = document.getElementById("setting-studio-pause-tab-change");
            const resumeLimitSel = document.getElementById("setting-studio-resume-limit");
            const engineSel = document.getElementById("setting-studio-player-engine");
            const qualitySel = document.getElementById("setting-studio-stream-quality");

            if (engineSel) {
                localStorage.setItem("mf_default_player_engine", engineSel.value || "embed");
            }
            if (qualitySel) {
                localStorage.setItem("mf_default_stream_quality", qualitySel.value || "720");
            }

            if (resumeLimitSel) {
                localStorage.setItem("mf_resume_history_limit", resumeLimitSel.value || "3");
                pruneStoredResumeHistory();
            }

            if (typeof Settings !== "undefined") {
                const existing = Settings.load() || {};
                Settings.save({
                    downloadFolder: (modeSel && modeSel.value === "custom" && customLoc) ? customLoc.value.trim() : "",
                    pexelsApiKey: pexelsInput ? pexelsInput.value.trim() : "",
                    pixabayApiKey: pixabayInput ? pixabayInput.value.trim() : "",
                    unsplashApiKey: unsplashInput ? unsplashInput.value.trim() : "",
                    giphyApiKey: giphyInput ? giphyInput.value.trim() : "",
                    spotifyClientId: spotifyIdInput ? spotifyIdInput.value.trim() : (existing.spotifyClientId || ""),
                    spotifyClientSecret: spotifySecretInput ? spotifySecretInput.value.trim() : (existing.spotifyClientSecret || ""),
                    pausePreviewOnTabChange: pauseTabCheck ? pauseTabCheck.checked : false,
                    autoInsertTimeline: false
                });
            }
        }

        if (btnOpenHeader) {
            btnOpenHeader.addEventListener("click", () => {
                loadStudioSettings();
                if (modal) {
                    modal.classList.add("active");
                }
            });
        }

        if (btnSave) {
            btnSave.addEventListener("click", () => {
                saveStudioSettings();
            });
        }

        const btnOpenApiGuide = document.getElementById("btn-open-api-guide");
        const modalApiGuide = document.getElementById("modal-api-guide");
        const btnCloseApiGuide = document.getElementById("btn-close-api-guide");
        const btnDoneApiGuide = document.getElementById("btn-done-api-guide");

        function closeApiGuideModal() {
            if (modalApiGuide) {
                modalApiGuide.style.display = "none";
                modalApiGuide.classList.remove("active");
            }
        }

        if (btnOpenApiGuide && modalApiGuide) {
            btnOpenApiGuide.addEventListener("click", () => {
                modalApiGuide.style.display = "flex";
                modalApiGuide.classList.add("active");
            });
        }
        if (btnCloseApiGuide) btnCloseApiGuide.addEventListener("click", closeApiGuideModal);
        if (btnDoneApiGuide) btnDoneApiGuide.addEventListener("click", closeApiGuideModal);

        document.querySelectorAll(".btn-api-external-link").forEach(btn => {
            if (btn._hasStudioLinkAttached) return;
            btn._hasStudioLinkAttached = true;
            btn.addEventListener("click", (e) => {
                e.preventDefault();
                e.stopPropagation();
                const u = btn.getAttribute("data-url");
                if (u && typeof window.__mfSafeOpenExternal === "function") {
                    window.__mfSafeOpenExternal(u);
                } else if (u) {
                    if (window.__adobe_cep__ && typeof window.__adobe_cep__.openURLInDefaultBrowser === "function") {
                        window.__adobe_cep__.openURLInDefaultBrowser(u);
                    } else if (window.cep && window.cep.util && typeof window.cep.util.openURLInDefaultBrowser === "function") {
                        window.cep.util.openURLInDefaultBrowser(u);
                    } else {
                        window.open(u, "_blank");
                    }
                }
            });
        });
    }

    function bindModeToggle() {
        const btnDownload = document.getElementById("mode-btn-download");
        const btnSearch = document.getElementById("mode-btn-search");
        const fetchView = document.getElementById("mediaFetchView");
        const searchView = document.getElementById("mediaSearchView");

        if (!btnDownload || !btnSearch || !fetchView || !searchView) return;

        btnDownload.addEventListener("click", () => {
            btnDownload.classList.add("active");
            btnSearch.classList.remove("active");
            fetchView.style.display = "flex";
            searchView.style.display = "none";

            // If user enabled "Pause video preview when switching tabs", pause playback. Otherwise keep it running smoothly!
            const shouldPause = (typeof Settings !== "undefined" && Settings.get("pausePreviewOnTabChange"));
            if (shouldPause && typeof pauseActiveVideo === "function") {
                pauseActiveVideo();
            }

            // Proactive memory cleanup
            const isLowRam = typeof localStorage !== "undefined" && localStorage.getItem("mediafetch_low_ram_mode") === "true";
            if (isLowRam && typeof window.clearStudioMemoryCache === "function") {
                window.clearStudioMemoryCache();
            }
            if (typeof window.triggerMemoryCleanup === "function") {
                window.triggerMemoryCleanup();
            } else if (typeof window !== "undefined" && typeof window.gc === "function") {
                try { window.gc(); } catch (_) {}
            }
        });

        btnSearch.addEventListener("click", () => {
            btnSearch.classList.add("active");
            btnDownload.classList.remove("active");
            fetchView.style.display = "none";
            searchView.style.display = "flex";
        });
    }

    function scrollElementIntoViewSmart(el, container) {
        if (!el || !container) return;
        const containerWidth = container.clientWidth;
        const elLeft = el.offsetLeft;
        const elWidth = el.offsetWidth;

        // Auto-center the clicked element inside the horizontal container,
        // so if the user clicks the last visible button on the right, it slides over
        // and reveals the next buttons on the right!
        const targetScroll = elLeft - (containerWidth / 2) + (elWidth / 2);
        container.scrollTo({
            left: Math.max(0, targetScroll),
            behavior: "smooth"
        });
    }

    function setupHorizontalScroll(container) {
        if (!container || container._hasHScroll) return;
        container._hasHScroll = true;

        // Mouse wheel smooth horizontal scrolling (no scrollbar needed)
        container.addEventListener("wheel", (e) => {
            if (e.deltaY !== 0 || e.deltaX !== 0) {
                e.preventDefault();
                const delta = e.deltaY !== 0 ? e.deltaY : e.deltaX;
                container.scrollLeft += delta * 0.8;
            }
        }, { passive: false });

        // Touch / mouse drag-to-slide
        let isDown = false;
        let startX = 0;
        let scrollStart = 0;

        container.addEventListener("mousedown", (e) => {
            isDown = true;
            container._dragMoved = false;
            startX = e.pageX;
            scrollStart = container.scrollLeft;
        });

        window.addEventListener("mousemove", (e) => {
            if (!isDown) return;
            const diff = e.pageX - startX;
            if (Math.abs(diff) > 4) {
                container._dragMoved = true;
                container.classList.add("is-dragging");
            }
            container.scrollLeft = scrollStart - diff;
        });

        window.addEventListener("mouseup", () => {
            if (isDown) {
                isDown = false;
                container.classList.remove("is-dragging");
                setTimeout(() => {
                    container._dragMoved = false;
                }, 60);
            }
        });
    }

    function bindCategoryTabs() {
        const studioNav = document.querySelector(".studio-nav");
        if (studioNav) setupHorizontalScroll(studioNav);

        const tabs = document.querySelectorAll(".studio-tab");
        tabs.forEach(tab => {
            tab.addEventListener("click", () => {
                if (studioNav && studioNav._dragMoved) return;
                tabs.forEach(t => t.classList.remove("active"));
                tab.classList.add("active");
                currentCategory = tab.dataset.category;
                currentPlatform = "all";

                if (studioNav) scrollElementIntoViewSmart(tab, studioNav);

                renderPlatformPills();
                const input = document.getElementById("studio-search-input");
                if (input && input.value.trim()) {
                    performSearch(input.value.trim());
                }
            });
        });
    }


    function renderPlatformPills() {
        const platformBar = document.getElementById("studio-platform-bar");
        const input = document.getElementById("studio-search-input");
        if (!platformBar) return;

        setupHorizontalScroll(platformBar);
        platformBar.innerHTML = "";
        const config = categoryConfig[currentCategory] || categoryConfig.video;
        if (input) {
            if (currentCategory === "audio" && currentPlatform === "songs") {
                input.placeholder = "Search songs, tracks, artists, albums, playlists...";
            } else {
                input.placeholder = config.placeholder;
            }
        }

        config.platforms.forEach(plat => {
            const pill = document.createElement("button");
            pill.className = `platform-pill ${plat.id === currentPlatform ? "active" : ""}`;
            pill.textContent = plat.label;

            pill.addEventListener("click", () => {
                if (platformBar._dragMoved) return;
                platformBar.querySelectorAll(".platform-pill").forEach(p => p.classList.remove("active"));
                pill.classList.add("active");
                currentPlatform = plat.id;

                if (currentCategory === "audio" && currentPlatform === "songs") {
                    if (input) input.placeholder = "Search songs, tracks, artists, albums, playlists...";
                } else if (input) {
                    input.placeholder = config.placeholder;
                }

                renderFilterDropdownOptions();

                // Auto-slide: Centers this pill and automatically reveals the hidden options on the right/left
                scrollElementIntoViewSmart(pill, platformBar);

                if (plat.id === "direct" || plat.id === "universal") {
                    const btnDownload = document.getElementById("mode-btn-download");
                    if (btnDownload) btnDownload.click();
                    return;
                }

                if (input && input.value.trim()) {
                    performSearch(input.value.trim());
                }
            });

            platformBar.appendChild(pill);
        });

        renderFilterDropdownOptions();

        // Ensure active pill is scrolled into view smoothly
        const activePill = platformBar.querySelector(".platform-pill.active");
        if (activePill) {
            setTimeout(() => {
                scrollElementIntoViewSmart(activePill, platformBar);
            }, 60);
        }
    }

    function bindSearchInput() {
        const input = document.getElementById("studio-search-input");
        const btn = document.getElementById("studio-search-btn");

        if (btn && input) {
            btn.addEventListener("click", () => {
                const q = input.value.trim();
                if (q) performSearch(q);
            });

            input.addEventListener("keydown", (e) => {
                if (e.key === "Enter") {
                    const q = input.value.trim();
                    if (q) performSearch(q);
                }
            });
        }
    }

    function renderFilterDropdownOptions() {
        const filterDropdown = document.getElementById("studio-filter-dropdown");
        const filterBtn = document.getElementById("studio-filter-btn");
        const filterLabel = document.getElementById("studio-filter-label");
        const searchInput = document.getElementById("studio-search-input");
        const filterContainer = document.querySelector(".studio-filter-container");
        if (!filterDropdown) return;

        const isSongMode = (currentCategory === "audio" && currentPlatform === "songs") || currentCategory === "songs";

        if (isSongMode) {
            filterDropdown.innerHTML = `
                <div class="studio-filter-header">Filter Songs &amp; Music</div>
                <div class="studio-filter-option ${currentSongFilter === 'all' ? 'active' : ''}" data-ratio="all">
                    <span class="studio-filter-icon"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg></span>
                    <div class="studio-filter-text">
                        <div class="studio-filter-title">All Categories</div>
                        <div class="studio-filter-sub">Songs, Albums, Artists, Playlists</div>
                    </div>
                    <span class="studio-filter-check"><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></span>
                </div>
                <div class="studio-filter-option ${currentSongFilter === 'songs' ? 'active' : ''}" data-ratio="songs">
                    <span class="studio-filter-icon"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18V5l12-2v13"></path><circle cx="6" cy="18" r="3"></circle><circle cx="18" cy="16" r="3"></circle></svg></span>
                    <div class="studio-filter-text">
                        <div class="studio-filter-title">Songs &amp; Hits</div>
                        <div class="studio-filter-sub">Single songs &amp; high quality tracks</div>
                    </div>
                    <span class="studio-filter-check"><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></span>
                </div>
                <div class="studio-filter-option ${currentSongFilter === 'albums' ? 'active' : ''}" data-ratio="albums">
                    <span class="studio-filter-icon"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><circle cx="12" cy="12" r="3"></circle></svg></span>
                    <div class="studio-filter-text">
                        <div class="studio-filter-title">Albums</div>
                        <div class="studio-filter-sub">Full discographies &amp; track sets</div>
                    </div>
                    <span class="studio-filter-check"><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></span>
                </div>
                <div class="studio-filter-option ${currentSongFilter === 'artists' ? 'active' : ''}" data-ratio="artists">
                    <span class="studio-filter-icon"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"></path><path d="M19 10v2a7 7 0 0 1-14 0v-2"></path><line x1="12" y1="19" x2="12" y2="23"></line><line x1="8" y1="23" x2="16" y2="23"></line></svg></span>
                    <div class="studio-filter-text">
                        <div class="studio-filter-title">Artists</div>
                        <div class="studio-filter-sub">Verified artists &amp; artist profiles</div>
                    </div>
                    <span class="studio-filter-check"><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></span>
                </div>
                <div class="studio-filter-option ${currentSongFilter === 'playlists' ? 'active' : ''}" data-ratio="playlists">
                    <span class="studio-filter-icon"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline></svg></span>
                    <div class="studio-filter-text">
                        <div class="studio-filter-title">Playlists</div>
                        <div class="studio-filter-sub">Curated collections &amp; popular mixes</div>
                    </div>
                    <span class="studio-filter-check"><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></span>
                </div>
            `;
            if (filterLabel) {
                const map = { all: "All", songs: "Songs", albums: "Albums", artists: "Artists", playlists: "Playlists" };
                filterLabel.textContent = map[currentSongFilter] || "All";
            }
            if (filterBtn) {
                if (currentSongFilter !== "all") filterBtn.classList.add("active-filter");
                else filterBtn.classList.remove("active-filter");
            }
        } else {
            filterDropdown.innerHTML = `
                <div class="studio-filter-header">Format &amp; Ratio</div>
                <div class="studio-filter-option ${currentOrientationFilter === 'all' ? 'active' : ''}" data-ratio="all">
                    <span class="studio-filter-icon"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg></span>
                    <div class="studio-filter-text">
                        <div class="studio-filter-title">All Formats</div>
                        <div class="studio-filter-sub">Widescreen, Shorts, Reels &amp; any ratio</div>
                    </div>
                    <span class="studio-filter-check"><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></span>
                </div>
                <div class="studio-filter-option ${currentOrientationFilter === 'landscape' ? 'active' : ''}" data-ratio="landscape">
                    <span class="studio-filter-icon"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect><line x1="8" y1="21" x2="16" y2="21"></line><line x1="12" y1="17" x2="12" y2="21"></line></svg></span>
                    <div class="studio-filter-text">
                        <div class="studio-filter-title">16:9 Landscape</div>
                        <div class="studio-filter-sub">Standard widescreen / horizontal videos</div>
                    </div>
                    <span class="studio-filter-check"><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></span>
                </div>
                <div class="studio-filter-option ${currentOrientationFilter === 'portrait' ? 'active' : ''}" data-ratio="portrait">
                    <span class="studio-filter-icon"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="5" y="2" width="14" height="20" rx="2" ry="2"></rect><line x1="12" y1="18" x2="12.01" y2="18"></line></svg></span>
                    <div class="studio-filter-text">
                        <div class="studio-filter-title">9:16 Portrait</div>
                        <div class="studio-filter-sub">Vertical / Shorts / Reels / TikToks</div>
                    </div>
                    <span class="studio-filter-check"><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></span>
                </div>
            `;
            if (filterLabel) {
                if (currentOrientationFilter === "landscape") filterLabel.textContent = "16:9";
                else if (currentOrientationFilter === "portrait") filterLabel.textContent = "9:16";
                else filterLabel.textContent = "All";
            }
            if (filterBtn) {
                if (currentOrientationFilter !== "all") filterBtn.classList.add("active-filter");
                else filterBtn.classList.remove("active-filter");
            }
        }

        filterDropdown.querySelectorAll(".studio-filter-option").forEach(opt => {
            opt.addEventListener("click", (e) => {
                e.stopPropagation();
                const ratio = opt.getAttribute("data-ratio") || "all";
                const isSongMode = (currentCategory === "audio" && currentPlatform === "songs") || currentCategory === "songs";

                if (isSongMode) {
                    currentSongFilter = ratio;
                    if (filterLabel) {
                        const map = { all: "All", songs: "Songs", albums: "Albums", artists: "Artists", playlists: "Playlists" };
                        filterLabel.textContent = map[ratio] || "All";
                    }
                    if (filterBtn) {
                        if (ratio !== "all") filterBtn.classList.add("active-filter");
                        else filterBtn.classList.remove("active-filter");
                    }
                } else {
                    currentOrientationFilter = ratio;
                    if (filterLabel) {
                        if (ratio === "landscape") filterLabel.textContent = "16:9";
                        else if (ratio === "portrait") filterLabel.textContent = "9:16";
                        else filterLabel.textContent = "All";
                    }
                    if (filterBtn) {
                        if (ratio !== "all") filterBtn.classList.add("active-filter");
                        else filterBtn.classList.remove("active-filter");
                    }
                }

                filterDropdown.querySelectorAll(".studio-filter-option").forEach(o => o.classList.remove("active"));
                opt.classList.add("active");
                filterDropdown.style.display = "none";
                if (filterContainer) filterContainer.classList.remove("open");

                if (searchInput && searchInput.value.trim()) {
                    performSearch(searchInput.value.trim());
                }
            });
        });
    }

    function bindFilterDropdown() {
        const filterBtn = document.getElementById("studio-filter-btn");
        const filterDropdown = document.getElementById("studio-filter-dropdown");
        const filterContainer = document.querySelector(".studio-filter-container");

        if (!filterBtn || !filterDropdown) return;

        filterBtn.addEventListener("click", (e) => {
            e.stopPropagation();
            const isOpen = filterDropdown.style.display === "block";
            filterDropdown.style.display = isOpen ? "none" : "block";
            if (filterContainer) {
                filterContainer.classList.toggle("open", !isOpen);
            }
        });

        renderFilterDropdownOptions();

        document.addEventListener("click", (e) => {
            if (filterContainer && !filterContainer.contains(e.target)) {
                filterDropdown.style.display = "none";
                filterContainer.classList.remove("open");
            }
        });
    }

    async function performSearch(query) {
        currentSearchId++;
        const thisSearchId = currentSearchId;
        isSearching = true;
        progressiveQueue = [];
        isProcessingQueue = false;

        stopActiveVideoPreview();

        const grid = document.getElementById("studio-results-grid");
        const emptyState = document.getElementById("studio-empty-state");
        const loadingState = document.getElementById("studio-loading-state");

        if (grid) {
            const imgs = grid.querySelectorAll("img");
            imgs.forEach(i => { try { i.src = ""; i.remove(); } catch (_) {} });
            grid.innerHTML = "";
        }
        renderedItemIds.clear();
        const queuedItemIds = new Set();

        function isDuplicateItem(it) {
            if (!it) return true;
            if (it.id && (renderedItemIds.has(it.id) || queuedItemIds.has(it.id))) return true;
            if (it.videoId && (renderedItemIds.has(it.videoId) || queuedItemIds.has(it.videoId))) return true;
            if (it.title && typeof it.title === "string") {
                const normTitle = it.title.toLowerCase().replace(/[^a-z0-9]/g, "").trim();
                if (normTitle.length > 5 && (renderedItemIds.has(normTitle) || queuedItemIds.has(normTitle))) return true;
            }
            return false;
        }

        function markItemSeen(it) {
            if (!it) return;
            if (it.id) queuedItemIds.add(it.id);
            if (it.videoId) queuedItemIds.add(it.videoId);
            if (it.title && typeof it.title === 'string') {
                const normTitle = it.title.toLowerCase().replace(/[^a-z0-9]/g, '').trim();
                if (normTitle.length > 5) queuedItemIds.add(normTitle);
            }
        }

        if (typeof window !== "undefined" && typeof window.gc === "function") {
            try { window.gc(); } catch (_) {}
        }
        if (emptyState) emptyState.style.display = "none";
        if (loadingState) loadingState.style.display = "flex";

        const platformBuckets = new Map();
        let flushScheduled = false;

        function flushPlatformBuckets(isFinal = false) {
            flushScheduled = false;
            if (thisSearchId !== currentSearchId) return;

            const isLowRam = typeof localStorage !== "undefined" && localStorage.getItem("mediafetch_low_ram_mode") === "true";
            const maxCards = isLowRam ? 40 : 100;
            if (renderedItemIds.size >= maxCards) return;

            const pulledItems = [];
            // When initial search is still running across parallel APIs, limit per-platform burst to 3 items
            // so faster platforms don't crowd out slower ones before they arrive.
            const maxPerPlatformPerTick = (!isFinal && isSearching) ? 3 : Infinity;
            const tickCounts = new Map();

            let hadItems = true;
            while (hadItems && (renderedItemIds.size + pulledItems.length < maxCards)) {
                hadItems = false;
                for (const [platformKey, items] of platformBuckets.entries()) {
                    const currentTickCount = tickCounts.get(platformKey) || 0;
                    if (currentTickCount < maxPerPlatformPerTick && items && items.length > 0) {
                        const nextItem = items.shift();
                        if (nextItem && nextItem.id && !renderedItemIds.has(nextItem.id)) {
                            pulledItems.push(nextItem);
                            renderedItemIds.add(nextItem.id);
                            if (nextItem.videoId) renderedItemIds.add(nextItem.videoId);
                            if (nextItem.title && typeof nextItem.title === 'string') {
                                const normTitle = nextItem.title.toLowerCase().replace(/[^a-z0-9]/g, '').trim();
                                if (normTitle.length > 5) renderedItemIds.add(normTitle);
                            }
                            tickCounts.set(platformKey, currentTickCount + 1);
                            hadItems = true;
                            if (renderedItemIds.size + pulledItems.length >= maxCards) break;
                        }
                    }
                }
            }

            if (pulledItems.length > 0) {
                if (loadingState) loadingState.style.display = "none";
                if (emptyState) emptyState.style.display = "none";
                appendCardsToGrid(pulledItems, thisSearchId);
            }
        }

        function handleIncomingBatch(newItems, sourceTag) {
            if (thisSearchId !== currentSearchId) return;
            if (!newItems || newItems.length === 0) return;
            const isLowRam = typeof localStorage !== "undefined" && localStorage.getItem("mediafetch_low_ram_mode") === "true";
            const maxCards = isLowRam ? 40 : 100;
            if (renderedItemIds.size >= maxCards) return;

            const filtered = newItems.filter(it => {
                if (!it || !it.id) return false;
                // Category strictness: never leak photos into video tab or videos into photo tab
                if (currentCategory === "video") {
                    if (it.type === "photo" || it.type === "image" || it.mediaType === "image" || it.isImage || it.source === "unsplash" || it.source === "wallhaven") return false;
                } else if (currentCategory === "photo") {
                    if (it.type === "video" || it.mediaType === "video" || it.type === "audio") return false;
                } else if (currentCategory === "audio") {
                    if (it.type === "video" || it.type === "photo" || it.type === "image") return false;
                }
                return matchesOrientationFilter(it, currentOrientationFilter);
            });
            const unique = filtered.filter(it => !isDuplicateItem(it));
            unique.forEach(it => markItemSeen(it));
            if (unique.length === 0) return;

            if (currentPlatform !== "all") {
                const sliceLimit = Math.max(0, maxCards - renderedItemIds.size);
                const toAdd = unique.slice(0, sliceLimit);
                toAdd.forEach(it => renderedItemIds.add(it.id));

                if (loadingState) loadingState.style.display = "none";
                if (emptyState) emptyState.style.display = "none";

                appendCardsToGrid(toAdd, thisSearchId);
                return;
            }

            // Multi-platform round-robin pool: tag by platform
            const tag = sourceTag || (unique[0] && unique[0].source ? unique[0].source.toLowerCase() : "general");
            if (!platformBuckets.has(tag)) {
                platformBuckets.set(tag, []);
            }
            const bucket = platformBuckets.get(tag);
            const bucketIds = new Set(bucket.map(b => b.id));
            for (const item of unique) {
                if (!bucketIds.has(item.id)) {
                    bucket.push(item);
                    bucketIds.add(item.id);
                }
            }

            if (!flushScheduled) {
                flushScheduled = true;
                setTimeout(() => flushPlatformBuckets(false), 20);
            }
        }

        try {
            const searchPromises = [];
            const apiOptions = {
                orientation: currentOrientationFilter !== "all" ? currentOrientationFilter : ""
            };

            // Direct URL Check
            if (query.startsWith("http://") || query.startsWith("https://")) {
                const item = {
                    id: "direct_" + Date.now(),
                    source: "direct link",
                    type: "video",
                    title: query.split("/").pop().split("?")[0] || "Direct Web Media",
                    author: "Web Source",
                    thumbnail: "https://commons.wikimedia.org/w/resources/assets/file-type-icons/fileicon-video.png",
                    hoverPreviewUrl: "",
                    downloadFormats: [
                        { label: "Direct MP4 Download", url: query, ext: "mp4", type: "video" },
                        { label: "MP3 Audio Extraction", url: query, ext: "mp3", type: "audio" }
                    ],
                    pageUrl: query
                };
                if (loadingState) loadingState.style.display = "none";
                renderResults([item]);
                isSearching = false;
                return;
            }

            // 1. Video & B-Roll (100% Working, Free & 4K)
            if (currentCategory === "video") {
                if ((currentPlatform === "all" || currentPlatform === "youtube") && typeof YouTubeAPI !== "undefined") {
                    searchPromises.push(
                        YouTubeAPI.searchVideos(query, {
                            limit: (currentPlatform === "all" ? 100 : 120),
                            orientation: currentOrientationFilter,
                            onBatch: (batch) => handleIncomingBatch(batch, "youtube")
                        }).then(r => handleIncomingBatch(r.items || [], "youtube")).catch(() => [])
                    );
                }
                if ((currentPlatform === "all" || currentPlatform === "pexels") && typeof PexelsAPI !== "undefined") {
                    searchPromises.push(PexelsAPI.searchVideos(query, Object.assign({ perPage: 60 }, apiOptions)).then(r => handleIncomingBatch(r.items || [], "pexels")).catch(() => []));
                }
                if ((currentPlatform === "all" || currentPlatform === "pixabay") && typeof PixabayAPI !== "undefined") {
                    searchPromises.push(PixabayAPI.searchVideos(query, Object.assign({ perPage: 60 }, apiOptions)).then(r => handleIncomingBatch(r.items || [], "pixabay")).catch(() => []));
                }
                if ((currentPlatform === "all" || currentPlatform === "wikimedia") && typeof WikimediaAPI !== "undefined") {
                    searchPromises.push(WikimediaAPI.searchVideos(query, Object.assign({ perPage: 50 }, apiOptions)).then(r => handleIncomingBatch(r.items || [], "wikimedia")).catch(() => []));
                }
            }

            // 2. Photos, 4K & Art (100% Working, Free & High-Res)
            else if (currentCategory === "photo") {
                if ((currentPlatform === "all" || currentPlatform === "unsplash") && typeof UnsplashAPI !== "undefined") {
                    searchPromises.push(UnsplashAPI.searchPhotos(query, Object.assign({ perPage: 50 }, apiOptions)).then(r => handleIncomingBatch(r.items || [], "unsplash")).catch(() => []));
                }
                if ((currentPlatform === "all" || currentPlatform === "pexels") && typeof PexelsAPI !== "undefined") {
                    searchPromises.push(PexelsAPI.searchPhotos(query, Object.assign({ perPage: 60 }, apiOptions)).then(r => handleIncomingBatch(r.items || [], "pexels")).catch(() => []));
                }
                if ((currentPlatform === "all" || currentPlatform === "pixabay") && typeof PixabayAPI !== "undefined") {
                    searchPromises.push(PixabayAPI.searchPhotos(query, Object.assign({ perPage: 60 }, apiOptions)).then(r => handleIncomingBatch(r.items || [], "pixabay")).catch(() => []));
                }
                if ((currentPlatform === "all" || currentPlatform === "wikimedia") && typeof WikimediaAPI !== "undefined") {
                    searchPromises.push(WikimediaAPI.searchPhotos(query, Object.assign({ perPage: 50 }, apiOptions)).then(r => handleIncomingBatch(r.items || [], "wikimedia")).catch(() => []));
                }
                if ((currentPlatform === "all" || currentPlatform === "wallhaven") && typeof WallhavenAPI !== "undefined") {
                    searchPromises.push(WallhavenAPI.searchWallpapers(query, apiOptions).then(r => handleIncomingBatch(r.items || [], "wallhaven")).catch(() => []));
                }
                if ((currentPlatform === "all" || currentPlatform === "openverse") && typeof OpenverseAPI !== "undefined") {
                    searchPromises.push(OpenverseAPI.searchPhotos(query, Object.assign({ perPage: 50 }, apiOptions)).then(r => handleIncomingBatch(r.items || [], "openverse")).catch(() => []));
                }
            }

            // 3. Music & SFX (Universal Keyless Songs, Foley, Jamendo, FreeSound, YouTube Audio)
            else if (currentCategory === "audio") {
                if (currentPlatform === "songs") {
                    if (typeof SongsAPI !== "undefined") {
                        const filter = (currentSongFilter === "all" ? "all" : currentSongFilter);
                        searchPromises.push(SongsAPI.search(query, filter, 60).then(r => {
                            const formatted = (r.items || []).map(it => {
                                const sub = it.subtype || "song";
                                const defaultQualities = [
                                    { label: "320 kbps (Ultra MP3)", ext: "mp3", quality: "audio-320k", type: "audio", bitrate: 320, query: `${it.title} ${it.author} audio` },
                                    { label: "WAV (Lossless 24-bit)", ext: "wav", quality: "audio-wav", type: "audio", bitrate: 0, query: `${it.title} ${it.author} audio` },
                                    { label: "256 kbps (High MP3)", ext: "mp3", quality: "audio-256k", type: "audio", bitrate: 256, query: `${it.title} ${it.author} audio` },
                                    { label: "192 kbps (Standard)", ext: "mp3", quality: "audio-192k", type: "audio", bitrate: 192, query: `${it.title} ${it.author} audio` }
                                ];
                                return Object.assign({}, it, {
                                    type: "audio",
                                    subtype: sub,
                                    badge: it.badge || (sub ? sub.toUpperCase() : "SONG"),
                                    downloadFormats: (it.qualities && it.qualities.length > 0) ? it.qualities.map(q => ({
                                        label: q.label,
                                        ext: q.format,
                                        quality: q.id,
                                        type: "audio",
                                        bitrate: q.bitrate,
                                        query: q.query || `${it.title} ${it.author} audio`
                                    })) : (sub === "song" ? defaultQualities : []),
                                    audioPreviewUrl: it.hoverPreviewUrl || ""
                                });
                            });
                            handleIncomingBatch(formatted, "songs");
                        }).catch(err => {
                            console.error("[SearchStudio] SongsAPI search error:", err);
                            return [];
                        }));
                    }
                } else {
                    if (currentPlatform === "all" && typeof SongsAPI !== "undefined") {
                        searchPromises.push(SongsAPI.search(query, "songs", 30).then(r => {
                            const formatted = (r.items || []).map(it => {
                                const defaultQualities = [
                                    { label: "320 kbps (Ultra MP3)", ext: "mp3", quality: "audio-320k", type: "audio", bitrate: 320, query: `${it.title} ${it.author} audio` },
                                    { label: "WAV (Lossless 24-bit)", ext: "wav", quality: "audio-wav", type: "audio", bitrate: 0, query: `${it.title} ${it.author} audio` }
                                ];
                                return Object.assign({}, it, {
                                    type: "audio",
                                    subtype: it.subtype || "song",
                                    badge: "SONG",
                                    downloadFormats: defaultQualities,
                                    audioPreviewUrl: it.hoverPreviewUrl || ""
                                });
                            });
                            handleIncomingBatch(formatted, "songs");
                        }).catch(() => []));
                    }
                    if ((currentPlatform === "all" || currentPlatform === "jamendo") && typeof JamendoAPI !== "undefined") {
                        searchPromises.push(JamendoAPI.searchTracks(query).then(r => handleIncomingBatch(r.items || [], "jamendo")).catch(() => []));
                    }
                    if ((currentPlatform === "all" || currentPlatform === "youtube_audio") && typeof YouTubeAPI !== "undefined") {
                        searchPromises.push(YouTubeAPI.searchVideos(query, {
                            limit: (currentPlatform === "all" ? 40 : 60),
                            onBatch: (batch) => {
                                const audioBatch = (batch || []).map(it => Object.assign({}, it, {
                                    type: "audio",
                                    downloadFormats: [
                                        { label: "MP3 320kbps Audio", ext: "mp3", quality: "audio", type: "audio" },
                                        { label: "WAV Lossless Audio", ext: "wav", quality: "audio-wav", type: "audio" }
                                    ]
                                }));
                                handleIncomingBatch(audioBatch, "youtube_audio");
                            }
                        }).then(r => {
                            const audioItems = (r.items || []).map(it => Object.assign({}, it, {
                                type: "audio",
                                downloadFormats: [
                                    { label: "MP3 320kbps Audio", ext: "mp3", quality: "audio", type: "audio" },
                                    { label: "WAV Lossless Audio", ext: "wav", quality: "audio-wav", type: "audio" }
                                ]
                            }));
                            handleIncomingBatch(audioItems, "youtube_audio");
                        }).catch(() => []));
                    }
                    if ((currentPlatform === "all" || currentPlatform === "freesound") && typeof OpenverseAPI !== "undefined") {
                        searchPromises.push(OpenverseAPI.searchAudio(query).then(r => handleIncomingBatch(r.items || [], "freesound")).catch(() => []));
                    }
                }
            }

            await Promise.allSettled(searchPromises);

            if (thisSearchId === currentSearchId) {
                flushPlatformBuckets(true);
                if (loadingState) loadingState.style.display = "none";
                if (renderedItemIds.size === 0 && emptyState) {
                    emptyState.style.display = "flex";
                }
            }
        } catch (err) {
            console.error("Search error:", err);
            if (thisSearchId === currentSearchId) {
                flushPlatformBuckets(true);
                if (loadingState) loadingState.style.display = "none";
                if (renderedItemIds.size === 0 && emptyState) emptyState.style.display = "flex";
            }
        } finally {
            if (thisSearchId === currentSearchId) {
                isSearching = false;
                flushPlatformBuckets(true);
            }
        }
    }

    function formatSourceLabel(src) {
        if (!src) return "Source";
        const s = String(src).toLowerCase();
        if (s.includes("apple_music") || s.includes("applemusic") || s.includes("apple")) return "Apple Music";
        if (s.includes("spotify")) return "Spotify";
        if (s.includes("behance")) return "Behance";
        if (s.includes("vimeo")) return "Vimeo";
        if (s.includes("freesound")) return "FreeSound";
        if (s.includes("youtube")) return "YouTube";
        if (s.includes("jamendo")) return "Jamendo";
        if (s.includes("openverse")) return "Openverse";
        if (s.includes("wikimedia")) return "Wikimedia";
        if (s.includes("wallhaven")) return "Wallhaven";
        if (s.includes("pexels")) return "Pexels";
        if (s.includes("pixabay")) return "Pixabay";
        if (s.includes("unsplash")) return "Unsplash";
        if (s.includes("giphy")) return "Giphy";
        if (s.includes("songs") || s.includes("itunes")) return "Songs";
        return src.replace(/\s*\([^)]*\)/g, "").trim();
    }

    function renderResults(items) {
        const grid = document.getElementById("studio-results-grid");
        if (!grid) return;
        grid.innerHTML = "";
        renderedItemIds.clear();
        progressiveQueue = [];
        isProcessingQueue = false;
        appendCardsToGrid(items, currentSearchId);
    }

    function scheduleNextChunk(searchId) {
        if (isProcessingQueue || progressiveQueue.length === 0) return;
        isProcessingQueue = true;

        setTimeout(() => {
            if (searchId !== currentSearchId) {
                progressiveQueue = [];
                isProcessingQueue = false;
                return;
            }

            const chunk = progressiveQueue.splice(0, 15);
            if (chunk.length > 0) {
                mountCardsChunk(chunk);
            }
            isProcessingQueue = false;

            if (progressiveQueue.length > 0 && searchId === currentSearchId) {
                scheduleNextChunk(searchId);
            }
        }, 25);
    }

    function mountCardsChunk(items) {
        const grid = document.getElementById("studio-results-grid");
        if (!grid || !items || items.length === 0) return;
        const fragment = document.createDocumentFragment();
        items.forEach(item => {
            try {
                const card = buildCardElement(item);
                if (card) fragment.appendChild(card);
            } catch (err) {
                console.warn("Failed to render card:", err);
            }
        });
        grid.appendChild(fragment);
    }

    function appendCardsToGrid(items, searchId) {
        const grid = document.getElementById("studio-results-grid");
        if (!grid || !items || items.length === 0) return;
        const targetSearchId = searchId || currentSearchId;

        // Instant rendering of top media cards in milliseconds
        if (grid.children.length === 0) {
            const firstChunk = items.slice(0, 15);
            mountCardsChunk(firstChunk);
            const remainder = items.slice(15);
            if (remainder.length > 0) {
                progressiveQueue.push(...remainder);
                scheduleNextChunk(targetSearchId);
            }
        } else {
            // Smooth progressive rendering for subsequent sections without UI stutter
            progressiveQueue.push(...items);
            scheduleNextChunk(targetSearchId);
        }
    }

    function buildCardElement(item) {
        const card = document.createElement("div");
            card.className = "studio-card";

            const sourceClean = formatSourceLabel(item.source);
            const isArtist = item.subtype === "artist";
            const isAlbum = item.subtype === "album";
            const isPlaylist = item.subtype === "playlist";
            const isSong = item.subtype === "song";
            const isCollection = isArtist || isAlbum || isPlaylist;

            let badgeText = item.badge || sourceClean;
            let badgeStyle = "";
            if (isArtist) {
                badgeText = "ARTIST";
                badgeStyle = 'style="background: rgba(168, 85, 247, 0.25); color: #c084fc; border: 1px solid rgba(168, 85, 247, 0.4);"';
            } else if (isAlbum) {
                badgeText = "ALBUM";
                badgeStyle = 'style="background: rgba(59, 130, 246, 0.25); color: #60a5fa; border: 1px solid rgba(59, 130, 246, 0.4);"';
            } else if (isPlaylist) {
                badgeText = "PLAYLIST";
                badgeStyle = 'style="background: rgba(245, 158, 11, 0.25); color: #fbbf24; border: 1px solid rgba(245, 158, 11, 0.4);"';
            } else if (isSong) {
                badgeText = "SONG";
                badgeStyle = 'style="background: rgba(16, 185, 129, 0.25); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.4);"';
            }

            let durBadge = item.durationString ? `<span class="studio-badge-dur">${item.durationString}</span>` : "";
            if (item.durationFormatted) {
                durBadge = `<span class="studio-badge-dur">${item.durationFormatted}</span>`;
            }

            let previewHtml = "";

            if (isArtist) {
                previewHtml = `
                    <div class="studio-card-preview studio-card-artist-preview" data-card-id="${item.id}" style="display: flex; flex-direction: column; align-items: center; justify-content: center; min-height: 120px; background: radial-gradient(circle, rgba(168,85,247,0.18) 0%, rgba(20,20,24,0.6) 70%);">
                        <button class="studio-thumb-link-btn" title="Open in Link Downloader to trim or custom format">
                            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path></svg>
                        </button>
                        <span class="studio-badge-source" ${badgeStyle}>${badgeText}</span>
                        ${durBadge}
                        <img class="studio-card-thumb" src="${item.thumbnail}" alt="${item.title}" onerror="this.onerror=null;this.src='https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=600';" style="width: 76px; height: 76px; border-radius: 50%; object-fit: cover; border: 2px solid rgba(168,85,247,0.5); box-shadow: 0 4px 14px rgba(0,0,0,0.6);" loading="lazy" decoding="async" />
                    </div>
                `;
            } else if (item.type === "audio") {
                const isYtAudio = item.source === "youtube" || (item.id && item.id.startsWith("yt_")) || !!item.videoId;
                const ytVidId = item.videoId || (isYtAudio ? (item.id || "").replace("yt_", "") : "");

                if (item.thumbnail) {
                    // Audio item with visual video cover (e.g. YouTube audio, Jamendo, Songs)
                    previewHtml = `
                        <div class="studio-card-preview" data-card-id="${item.id}">
                            <button class="studio-thumb-link-btn" title="Open in Link Downloader to trim or custom format">
                                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path></svg>
                            </button>
                            <button class="studio-thumb-zoom-btn" title="Expand Preview (Mid-screen / Fullscreen)">
                                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 3 21 3 21 9"></polyline><polyline points="9 21 3 21 3 15"></polyline><line x1="21" y1="3" x2="14" y2="10"></line><line x1="3" y1="21" x2="10" y2="14"></line></svg>
                            </button>
                            <span class="studio-badge-source" ${badgeStyle}>${badgeText}</span>
                            ${durBadge}
                            <img class="studio-card-thumb" src="${item.thumbnail}" alt="${item.title}" loading="lazy" decoding="async" />
                            <div class="studio-thumb-overlay"></div>
                            <div class="studio-video-player-container"></div>
                            <div class="studio-audio-center-action">
                                <button class="studio-audio-play-btn" data-audio-url="${item.audioPreviewUrl || ''}" data-video-id="${ytVidId}" title="Play Audio Preview">
                                    <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>
                                </button>
                            </div>
                        </div>
                    `;
                } else {
                    // Audio item without thumbnail (e.g. FreeSound SFX) -> Clean waveform graphic
                    previewHtml = `
                        <div class="studio-card-preview" data-card-id="${item.id}">
                            <button class="studio-thumb-link-btn" title="Open in Link Downloader to trim or custom format">
                                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path></svg>
                            </button>
                            <button class="studio-thumb-zoom-btn" title="Expand Preview (Mid-screen / Fullscreen)">
                                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 3 21 3 21 9"></polyline><polyline points="9 21 3 21 3 15"></polyline><line x1="21" y1="3" x2="14" y2="10"></line><line x1="3" y1="21" x2="10" y2="14"></line></svg>
                            </button>
                            <span class="studio-badge-source" ${badgeStyle}>${badgeText}</span>
                            ${durBadge}
                            <div class="studio-waveform-cover">
                                <svg class="studio-waveform-svg" viewBox="0 0 100 40" preserveAspectRatio="none">
                                    <rect x="5" y="14" width="3" height="12" rx="1.5" fill="rgba(255,255,255,0.2)"/>
                                    <rect x="12" y="8" width="3" height="24" rx="1.5" fill="rgba(255,255,255,0.25)"/>
                                    <rect x="19" y="12" width="3" height="16" rx="1.5" fill="rgba(255,255,255,0.2)"/>
                                    <rect x="26" y="5" width="3" height="30" rx="1.5" fill="rgba(20,115,230,0.5)"/>
                                    <rect x="33" y="10" width="3" height="20" rx="1.5" fill="rgba(255,255,255,0.2)"/>
                                    <rect x="40" y="15" width="3" height="10" rx="1.5" fill="rgba(255,255,255,0.2)"/>
                                    <rect x="47" y="3" width="3" height="34" rx="1.5" fill="rgba(0,209,178,0.5)"/>
                                    <rect x="54" y="9" width="3" height="22" rx="1.5" fill="rgba(255,255,255,0.25)"/>
                                    <rect x="61" y="13" width="3" height="14" rx="1.5" fill="rgba(255,255,255,0.2)"/>
                                    <rect x="68" y="7" width="3" height="26" rx="1.5" fill="rgba(20,115,230,0.5)"/>
                                    <rect x="75" y="12" width="3" height="16" rx="1.5" fill="rgba(255,255,255,0.2)"/>
                                    <rect x="82" y="8" width="3" height="24" rx="1.5" fill="rgba(255,255,255,0.25)"/>
                                    <rect x="89" y="14" width="3" height="12" rx="1.5" fill="rgba(255,255,255,0.2)"/>
                                </svg>
                                <div class="studio-audio-center-action">
                                    <button class="studio-audio-play-btn" data-audio-url="${item.audioPreviewUrl || ''}" data-video-id="${ytVidId}" title="Play Audio Preview">
                                        <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>
                                    </button>
                                </div>
                            </div>
                        </div>
                    `;
                }
            } else {
                // Video & Photo Cards
                const isVideo = item.type === "video";
                const playOverlay = isVideo ? `
                    <button class="studio-video-play-btn" title="Watch Video Preview">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>
                    </button>
                ` : "";

                previewHtml = `
                    <div class="studio-card-preview" data-card-id="${item.id}">
                        <button class="studio-thumb-link-btn" title="Open in Link Downloader to trim or custom format">
                            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path></svg>
                        </button>
                        <button class="studio-thumb-zoom-btn" title="Expand Preview (Mid-screen / Fullscreen)">
                            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 3 21 3 21 9"></polyline><polyline points="9 21 3 21 3 15"></polyline><line x1="21" y1="3" x2="14" y2="10"></line><line x1="3" y1="21" x2="10" y2="14"></line></svg>
                        </button>
                        <span class="studio-badge-source" ${badgeStyle}>${badgeText}</span>
                        ${durBadge}
                        <img class="studio-card-thumb" src="${item.thumbnail}" alt="${item.title}" loading="lazy" decoding="async" />
                        <div class="studio-video-player-container"></div>
                        ${playOverlay}
                    </div>
                `;
            }

            let actionsHtml = "";
            if (isArtist) {
                actionsHtml = `
                    <button class="studio-btn-import studio-btn-collection" style="width: 100%; justify-content: center; background: linear-gradient(135deg, #a855f7 0%, #7c3aed 100%);">
                        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>
                        <span>Explore Top Songs</span>
                    </button>
                `;
            } else if (isAlbum) {
                actionsHtml = `
                    <button class="studio-btn-import studio-btn-collection" style="width: 100%; justify-content: center; background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);">
                        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"></circle><circle cx="12" cy="12" r="3"></circle></svg>
                        <span>View Album Tracks</span>
                    </button>
                `;
            } else if (isPlaylist) {
                actionsHtml = `
                    <button class="studio-btn-import studio-btn-collection" style="width: 100%; justify-content: center; background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);">
                        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="8" y1="6" x2="21" y2="6"></line><line x1="8" y1="12" x2="21" y2="12"></line><line x1="8" y1="18" x2="21" y2="18"></line><line x1="3" y1="6" x2="3.01" y2="6"></line><line x1="3" y1="12" x2="3.01" y2="12"></line><line x1="3" y1="18" x2="3.01" y2="18"></line></svg>
                        <span>View Playlist</span>
                    </button>
                `;
            } else {
                let optionsHtml = "";
                (item.downloadFormats || item.qualities || []).forEach((f, idx) => {
                    optionsHtml += `<option value="${idx}">${f.label}</option>`;
                });
                actionsHtml = `
                    <select class="studio-format-select">
                        ${optionsHtml}
                    </select>
                    <button class="studio-btn-import" title="Download and import to timeline">
                        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
                        <span>Import</span>
                    </button>
                `;
            }

            card.innerHTML = `
                ${previewHtml}
                <div class="studio-card-info">
                    <div class="studio-card-title" title="${item.title}">${item.title}</div>
                    <div class="studio-card-meta">${item.author || "Creator"}</div>
                    <div class="studio-card-actions">
                        ${actionsHtml}
                    </div>
                </div>
            `;

            // Zoom Button Listener -> Opens Theater Preview (Mid-Screen / Fullscreen)
            const zoomBtn = card.querySelector(".studio-thumb-zoom-btn");
            if (zoomBtn) {
                zoomBtn.addEventListener("click", (e) => {
                    e.stopPropagation();
                    openTheaterPreview(item);
                });
            }

            // Video Play / Pause Button Listener (Inline Responsive Preview with Auto Fade-Out)
            const videoPlayBtn = card.querySelector(".studio-video-play-btn");
            const previewContainer = card.querySelector(".studio-card-preview");
            const playerBox = card.querySelector(".studio-video-player-container");

            if (videoPlayBtn && previewContainer && playerBox) {
                // Mouse movements over card bring back play button and restart fade timer
                previewContainer.addEventListener("mousemove", () => {
                    if (activeVideoPreview && activeVideoPreview.card === card) {
                        showPlayButton();
                    }
                });

                previewContainer.addEventListener("mouseenter", () => {
                    if (activeVideoPreview && activeVideoPreview.card === card) {
                        showPlayButton();
                    }
                });

                previewContainer.addEventListener("mouseleave", () => {
                    if (activeVideoPreview && activeVideoPreview.card === card && activeVideoPreview.isPlaying) {
                        if (fadeTimer) clearTimeout(fadeTimer);
                        fadeTimer = setTimeout(() => {
                            if (activeVideoPreview && activeVideoPreview.playBtn) {
                                activeVideoPreview.playBtn.classList.add("faded");
                            }
                        }, 400);
                    }
                });

                videoPlayBtn.addEventListener("click", (e) => {
                    e.stopPropagation();

                    // If this exact card is already active:
                    if (activeVideoPreview && activeVideoPreview.card === card) {
                        if (activeVideoPreview.isPlaying) {
                            pauseActiveVideo();
                        } else {
                            resumeActiveVideo();
                        }
                        return;
                    }

                    // Otherwise, stop any previously active video preview
                    stopActiveVideoPreview();

                    // Stop global audio preview if playing
                    if (!globalAudio.paused) {
                        globalAudio.pause();
                        if (currentPlayBtn) {
                            currentPlayBtn.innerHTML = `<svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>`;
                            currentPlayBtn = null;
                        }
                    }

                    // Mount video on THIS card
                    playerBox.style.display = "block";
                    playerBox.innerHTML = "";

                    const isYouTube = item.source === "youtube" || (item.id && item.id.startsWith("yt_")) || !!item.videoId;

                    if (isYouTube) {
                        const vidId = item.videoId || item.id.replace("yt_", "");
                        const iframe = document.createElement("iframe");
                        iframe.className = "studio-card-iframe";
                        iframe.src = getYouTubePlayerUrl(vidId);
                        iframe.allow = "autoplay; encrypted-media";
                        iframe.setAttribute("frameborder", "0");
                        iframe.setAttribute("referrerpolicy", "strict-origin-when-cross-origin");
                        playerBox.appendChild(iframe);

                        activeVideoPreview = {
                            card: card,
                            playBtn: videoPlayBtn,
                            container: playerBox,
                            type: "youtube",
                            iframe: iframe,
                            isPlaying: true
                        };
                    } else {
                        // Wikimedia / Direct Video file
                        // Pick 480p or lowest bandwidth format for instant loading
                        let srcUrl = item.previewUrl || item.hoverPreviewUrl;
                        if (!srcUrl && item.downloadFormats && item.downloadFormats.length > 0) {
                            const sd = item.downloadFormats.find(f => (f.height && f.height <= 480) || (f.label && (f.label.includes("480") || f.label.includes("360") || f.label.includes("SD"))));
                            if (sd && sd.url) srcUrl = sd.url;
                            else if (item.downloadFormats[0].url) srcUrl = item.downloadFormats[0].url;
                        }

                        const vid = document.createElement("video");
                        vid.className = "studio-card-html5-video";
                        vid.setAttribute("playsinline", "");
                        vid.setAttribute("webkit-playsinline", "");
                        vid.preload = "auto";
                        vid.src = srcUrl || item.pageUrl;
                        vid.muted = true; // Essential for browser autoplay policy compliance
                        vid.volume = 0.8;
                        vid.addEventListener("ended", () => {
                            stopActiveVideoPreview();
                        });

                        const playPromise = vid.play();
                        if (playPromise !== undefined) {
                            playPromise.catch(() => {
                                vid.muted = true;
                                vid.play().catch(() => {});
                            });
                        }

                        vid.onerror = () => {
                            if (item.downloadFormats && item.downloadFormats.length > 1) {
                                const fallback = item.downloadFormats.find(f => f.url && f.url !== vid.src);
                                if (fallback && fallback.url) {
                                    vid.src = fallback.url;
                                    vid.play().catch(() => {});
                                }
                            }
                        };

                        playerBox.appendChild(vid);

                        activeVideoPreview = {
                            card: card,
                            playBtn: videoPlayBtn,
                            container: playerBox,
                            type: "html5",
                            video: vid,
                            isPlaying: true
                        };
                    }

                    // Update button icon to Pause
                    videoPlayBtn.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16"></rect><rect x="14" y="4" width="4" height="16"></rect></svg>`;
                    videoPlayBtn.classList.add("playing");
                    videoPlayBtn.classList.remove("faded");
                    videoPlayBtn.title = "Pause Video Preview";

                    scheduleFadeOut();
                });
            }

            // Audio Play Button Listener
            if (item.type === "audio") {
                const playBtn = card.querySelector(".studio-audio-play-btn");
                const previewContainer = card.querySelector(".studio-card-preview");
                const playerBox = card.querySelector(".studio-video-player-container");

                if (playBtn) {
                    if (previewContainer) {
                        previewContainer.addEventListener("mousemove", () => {
                            if (activeVideoPreview && activeVideoPreview.card === card) {
                                showPlayButton();
                            }
                        });
                        previewContainer.addEventListener("mouseenter", () => {
                            if (activeVideoPreview && activeVideoPreview.card === card) {
                                showPlayButton();
                            }
                        });
                        previewContainer.addEventListener("mouseleave", () => {
                            if (activeVideoPreview && activeVideoPreview.card === card && activeVideoPreview.isPlaying) {
                                if (fadeTimer) clearTimeout(fadeTimer);
                                fadeTimer = setTimeout(() => {
                                    if (activeVideoPreview && activeVideoPreview.playBtn) {
                                        activeVideoPreview.playBtn.classList.add("faded");
                                    }
                                }, 600);
                            }
                        });
                    }

                    playBtn.addEventListener("click", (e) => {
                        e.stopPropagation();
                        const audioUrl = playBtn.dataset.audioUrl;
                        const ytVidId = playBtn.dataset.videoId;

                        // Case 1: YouTube Audio item (plays via embedded player with full sound)
                        if (ytVidId) {
                            if (activeVideoPreview && activeVideoPreview.card === card) {
                                if (activeVideoPreview.isPlaying) {
                                    pauseActiveVideo();
                                } else {
                                    resumeActiveVideo();
                                }
                                return;
                            }

                            stopActiveVideoPreview();
                            if (!globalAudio.paused) {
                                globalAudio.pause();
                                if (currentPlayBtn) {
                                    currentPlayBtn.innerHTML = `<svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>`;
                                    currentPlayBtn = null;
                                }
                            }

                            if (playerBox) {
                                playerBox.style.display = "block";
                                playerBox.innerHTML = "";
                                const iframe = document.createElement("iframe");
                                iframe.className = "studio-card-iframe";
                                iframe.src = getYouTubePlayerUrl(ytVidId);
                                iframe.allow = "autoplay; encrypted-media";
                                iframe.setAttribute("frameborder", "0");
                                iframe.setAttribute("referrerpolicy", "strict-origin-when-cross-origin");
                                playerBox.appendChild(iframe);

                                activeVideoPreview = {
                                    card: card,
                                    playBtn: playBtn,
                                    container: playerBox,
                                    type: "youtube",
                                    iframe: iframe,
                                    isPlaying: true
                                };

                                playBtn.innerHTML = `<svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16"></rect><rect x="14" y="4" width="4" height="16"></rect></svg>`;
                                playBtn.classList.add("playing");
                                playBtn.classList.remove("faded");
                                playBtn.title = "Pause Audio Preview";
                                scheduleFadeOut();
                            }
                            return;
                        }

                        // Case 2: Jamendo / FreeSound direct audio file stream
                        if (!audioUrl) {
                            handleSendToLinkDownloader(e);
                            return;
                        }

                        stopActiveVideoPreview();

                        if (currentPlayBtn === playBtn && !globalAudio.paused) {
                            globalAudio.pause();
                            playBtn.innerHTML = `<svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>`;
                            currentPlayBtn = null;
                        } else {
                            if (currentPlayBtn) {
                                currentPlayBtn.innerHTML = `<svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>`;
                            }
                            globalAudio.src = audioUrl;
                            globalAudio.play().catch(() => {});
                            playBtn.innerHTML = `<svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16"></rect><rect x="14" y="4" width="4" height="16"></rect></svg>`;
                            currentPlayBtn = playBtn;
                        }
                    });
                }
            }

            // Send Link to Link Downloader (Autofill URL & Open Timeline Trimmer)
            const thumbLinkBtn = card.querySelector(".studio-thumb-link-btn");

            const handleSendToLinkDownloader = (e) => {
                if (e) {
                    try { e.preventDefault(); e.stopPropagation(); } catch (_) {}
                }
                const targetUrl = item.pageUrl || item.sourceUrl || item.url || (item.downloadFormats && item.downloadFormats[0]?.sourceUrl) || (item.id && !String(item.id).startsWith("link_") ? (String(item.id).startsWith("yt_") ? `https://www.youtube.com/watch?v=${item.id.replace("yt_", "")}` : `https://www.youtube.com/watch?v=${item.id}`) : "");
                if (!targetUrl) return;

                const isAudioItem = item.mediaType === "audio" || item.type === "audio" || item.source === "songs" || item.badge === "SONG" || /(?:music\.apple\.com|spotify|soundcloud|deezer|bandcamp|audiomack)/i.test(targetUrl);

                if (window.mediaFetchApp && typeof window.mediaFetchApp.loadUrlIntoDownloader === "function") {
                    window.mediaFetchApp.loadUrlIntoDownloader(targetUrl, {
                        isAudio: isAudioItem,
                        isVideo: !isAudioItem,
                        openTrimmer: true
                    });
                    return;
                }

                // Fallback DOM handling if mediaFetchApp not attached
                const modeBtnDownload = document.getElementById("mode-btn-download");
                if (modeBtnDownload) modeBtnDownload.click();

                if (isAudioItem) {
                    const audioOnlyBtn = document.getElementById("mode-audio-only");
                    if (audioOnlyBtn) audioOnlyBtn.click();
                } else {
                    const videoAudioBtn = document.getElementById("mode-video-audio");
                    if (videoAudioBtn) videoAudioBtn.click();
                }

                if (typeof window.resetTrim === "function") window.resetTrim();
                const cardSection = document.getElementById("media-card-section");
                if (cardSection) cardSection.style.display = "none";

                const urlInput = document.getElementById("url-input");
                if (urlInput) {
                    urlInput.value = targetUrl;
                    urlInput.dispatchEvent(new Event("input", { bubbles: true }));
                    urlInput.dispatchEvent(new Event("change", { bubbles: true }));
                    urlInput.focus();
                }

                const trimPanel = document.getElementById("trim-inputs-panel");
                const trimArrow = document.getElementById("trim-toggle-arrow");
                if (trimPanel) {
                    trimPanel.style.display = "flex";
                    if (trimArrow) trimArrow.textContent = "▼";
                }

                const btnAnalyze = document.getElementById("btn-analyze");
                if (btnAnalyze) {
                    setTimeout(() => {
                        btnAnalyze.click();
                    }, 120);
                }
            };

            if (thumbLinkBtn) thumbLinkBtn.addEventListener("click", handleSendToLinkDownloader);

            // Collection Button Listener (Artists, Albums, Playlists)
            const collBtn = card.querySelector(".studio-btn-collection");
            if (collBtn) {
                collBtn.addEventListener("click", async (e) => {
                    e.stopPropagation();
                    const labelSpan = collBtn.querySelector("span");
                    const prevText = labelSpan ? labelSpan.textContent : "";
                    if (labelSpan) labelSpan.textContent = "Loading tracks...";
                    collBtn.disabled = true;

                    try {
                        let tracks = [];
                        let modalTitle = item.title;
                        let uploader = item.author || "MediaFetch Music";

                        if (typeof SongsAPI !== "undefined") {
                            if (item.subtype === "artist") {
                                tracks = await SongsAPI.getArtistTopTracks(item.rawId || item.id, item.title);
                                modalTitle = `${item.title} - Top Tracks`;
                                uploader = item.title;
                            } else if (item.subtype === "album") {
                                tracks = await SongsAPI.getAlbumTracks(item.rawId || item.id, item.title, item.author);
                                modalTitle = `${item.title} (${item.author})`;
                                uploader = item.author;
                            } else if (item.subtype === "playlist") {
                                tracks = await SongsAPI.getAlbumTracks(item.rawId || item.id, item.title, item.author);
                                modalTitle = item.title;
                                uploader = item.author || "Curated Playlist";
                            }
                        }

                        if (!tracks || tracks.length === 0) {
                            if (typeof SongsAPI !== "undefined") {
                                const fallbackRes = await SongsAPI.search(item.title, "songs", 30);
                                tracks = (fallbackRes.items || []).map(t => ({
                                    id: t.id,
                                    title: t.title,
                                    artist: t.author,
                                    album: t.album,
                                    duration: t.durationFormatted,
                                    durationSeconds: t.durationSeconds,
                                    thumbnail: t.thumbnail,
                                    previewUrl: t.hoverPreviewUrl
                                }));
                            }
                        }

                        const playlistPayload = {
                            title: modalTitle,
                            uploader: uploader,
                            itemCount: (tracks && tracks.length) ? tracks.length : 1,
                            url: item.pageUrl || "",
                            items: (tracks || []).map((t, idx) => ({
                                id: t.id,
                                index: idx + 1,
                                title: t.title,
                                uploader: t.artist || uploader,
                                duration: t.durationSeconds || 210,
                                thumbnail: t.thumbnail || item.thumbnail,
                                url: t.previewUrl || `https://music.apple.com/search?term=${encodeURIComponent(t.title + ' ' + (t.artist || ''))}`,
                                downloadQuery: `${t.title} ${t.artist || uploader} audio`
                            }))
                        };

                        const app = window.mediaFetchApp || window.mfApp;
                        if (app && typeof app.renderPlaylistModal === "function") {
                            app.renderPlaylistModal(playlistPayload);
                        } else if (typeof window.renderPlaylistModal === "function") {
                            window.renderPlaylistModal(playlistPayload);
                        } else {
                            try {
                                const titleEl = document.getElementById("playlist-title");
                                const countEl = document.getElementById("playlist-count");
                                const uploaderEl = document.getElementById("playlist-uploader");
                                const allCountEl = document.getElementById("playlist-all-count");
                                const listContainer = document.getElementById("playlist-items-list");
                                if (titleEl) titleEl.textContent = playlistPayload.title;
                                if (countEl) countEl.textContent = `${playlistPayload.itemCount} items`;
                                if (uploaderEl) uploaderEl.textContent = playlistPayload.uploader;
                                if (allCountEl) allCountEl.textContent = String(playlistPayload.itemCount);
                                if (listContainer) {
                                    listContainer.innerHTML = "";
                                    (playlistPayload.items || []).forEach(it => {
                                        const row = document.createElement("div");
                                        row.className = "playlist-item-row";
                                        row.style.cssText = "display: flex; align-items: center; gap: 6px; padding: 4px 6px; border-bottom: 1px solid rgba(255,255,255,0.06); font-size: 11px;";
                                        const rawType = ((it.type || it.mediaType || '').toLowerCase());
                                        let itemType = 'video';
                                        if (rawType === 'image' || rawType === 'photo' || /\.(jpe?g|png|webp|gif|bmp|svg)($|\?)/i.test(it.title || it.url)) {
                                            itemType = 'image';
                                        } else if (rawType === 'audio' || /\.(mp3|wav|m4a|aac|flac|ogg)($|\?)/i.test(it.title || it.url)) {
                                            itemType = 'audio';
                                        }
                                        let typeBadge = '';
                                        if (itemType === 'image') {
                                            typeBadge = '<span style="color:#00d1b2; font-weight:700; font-size:9px; background:rgba(0,209,178,0.14); border:1px solid rgba(0,209,178,0.3); padding:1px 5px; border-radius:3px; white-space:nowrap;">IMAGE</span>';
                                        } else if (itemType === 'audio') {
                                            typeBadge = '<span style="color:#a855f7; font-weight:700; font-size:9px; background:rgba(168,85,247,0.14); border:1px solid rgba(168,85,247,0.3); padding:1px 5px; border-radius:3px; white-space:nowrap;">AUDIO</span>';
                                        } else {
                                            typeBadge = '<span style="color:#3b82f6; font-weight:700; font-size:9px; background:rgba(59,130,246,0.14); border:1px solid rgba(59,130,246,0.3); padding:1px 5px; border-radius:3px; white-space:nowrap;">VIDEO</span>';
                                        }
                                        row.innerHTML = `
                                            <input type="checkbox" class="playlist-checkbox" data-url="${it.url}" data-title="${it.title.replace(/"/g, "&quot;")}" data-thumb="${it.thumbnail || ""}" data-dur="${it.duration || 0}" data-query="${it.downloadQuery || ""}" data-uploader="${it.uploader || ""}" checked style="cursor:pointer;">
                                            <span style="color:var(--text-muted); font-size:10px; width:20px;">#${it.index}</span>
                                            ${typeBadge}
                                            <span style="flex:1; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; cursor:pointer;" class="playlist-item-title" title="${it.title}">${it.title}</span>
                                            <button type="button" class="btn-playlist-preview" title="Preview in player" style="background:rgba(255,255,255,0.08); border:1px solid rgba(255,255,255,0.18); color:#e0e0e0; border-radius:4px; padding:2px 6px; cursor:pointer; font-size:10px; display:inline-flex; align-items:center; gap:3px;">
                                                <svg width="9" height="9" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg> Preview
                                            </button>
                                        `;
                                        const cb = row.querySelector('.playlist-checkbox');
                                        row.querySelector('.playlist-item-title')?.addEventListener('click', () => {
                                            if (cb) cb.checked = !cb.checked;
                                        });
                                        const previewBtn = row.querySelector('.btn-playlist-preview');
                                        previewBtn?.addEventListener('click', (e) => {
                                            e.preventDefault();
                                            e.stopPropagation();
                                            openTheaterPreview({
                                                id: it.id || 'pl_' + Date.now(),
                                                title: it.title,
                                                uploader: it.uploader || playlistPayload.uploader || 'Creator',
                                                author: it.uploader || playlistPayload.uploader || 'Creator',
                                                thumbnail: it.thumbnail,
                                                url: it.url,
                                                pageUrl: it.url,
                                                type: itemType,
                                                mediaType: itemType,
                                                directStreamUrl: it.directStreamUrl || it.downloadQuery || it.url,
                                                previewUrl: it.directStreamUrl || it.previewUrl || it.url,
                                                downloadFormats: it.downloadFormats || []
                                            });
                                        });
                                        listContainer.appendChild(row);
                                    });
                                }
                                const modal = document.getElementById("modal-playlist");
                                if (modal) modal.classList.add("active");
                            } catch (_) {}
                        }
                    } catch (err) {
                        console.error("[SearchStudio] Error loading collection tracks:", err);
                        showStudioNotification("Notice: Could not load tracks: " + (err.message || err));
                    } finally {
                        if (labelSpan) labelSpan.textContent = prevText;
                        collBtn.disabled = false;
                    }
                });
            }

            // Download & Import to Adobe Host
            const importBtn = card.querySelector(".studio-btn-import:not(.studio-btn-collection)");
            const formatSelect = card.querySelector(".studio-format-select");

            if (importBtn && formatSelect) {
                importBtn.addEventListener("click", async () => {
                    if (importBtn.classList.contains("downloading")) return;
                    if (typeof stopActiveVideoPreview === "function") stopActiveVideoPreview();
                    if (typeof globalAudio !== "undefined" && globalAudio && !globalAudio.paused) globalAudio.pause();

                    const formats = (item && (item.downloadFormats || item.qualities)) || [];
                    const val = formatSelect ? formatSelect.value : "0";
                    let selectedIdx = parseInt(val, 10);
                    if (isNaN(selectedIdx)) selectedIdx = 0;
                    let selectedFormat = formats[selectedIdx] || formats[0] || null;

                    if (!selectedFormat) {
                        const rawUrl = item.url || item.sourceUrl || item.pageUrl || item.directStreamUrl || "";
                        const isAudio = item.mediaType === "audio" || (item.category && item.category === "audio");
                        const isImg = item.mediaType === "photo" || item.mediaType === "image" || (item.category && item.category === "photo");
                        selectedFormat = {
                            quality: "1080",
                            label: isAudio ? "MP3 Audio" : (isImg ? "High Res Image" : "1080p Full HD"),
                            ext: isAudio ? "mp3" : (isImg ? "png" : "mp4"),
                            url: rawUrl
                        };
                    }

                    importBtn.classList.add("downloading");
                    const labelSpan = importBtn.querySelector("span");
                    labelSpan.textContent = "0%";

                    try {
                        const dlRes = await Downloader.downloadAndImport(item, selectedFormat, csInterface, (pct) => {
                            labelSpan.textContent = `${pct}%`;
                        });

                        importBtn.classList.remove("downloading");
                        importBtn.classList.add("imported");
                        importBtn.innerHTML = `<span>Downloaded</span>`;
                        if (dlRes && dlRes.noProject) {
                            showStudioNotification("Downloaded to disk! Open a project in Premiere Pro to auto-import.");
                        }
                    } catch (err) {
                        importBtn.classList.remove("downloading");
                        importBtn.classList.remove("imported");
                        labelSpan.textContent = "Import";
                        console.error("Download failed:", err);
                        const errMsg = (err && err.message) ? err.message : String(err);
                        const cleanMsg = errMsg
                            .replace(/WARNING:[^\n]*/gi, '')
                            .replace(/\[(?:download|Merger|ExtractAudio)\][^\n]*/gi, '')
                            .replace(/See\s+https:\/\/[^\s]+/gi, '')
                            .replace(/ERROR:\s*/gi, '')
                            .trim();
                        if (errMsg.includes("Sign in to confirm") || errMsg.includes("bot") || errMsg.includes("po_token") || errMsg.includes("gvs")) {
                            showStudioNotification("Notice: YouTube restricted stream. Trying alternative source...");
                        } else if (cleanMsg.length > 0) {
                            showStudioNotification("Notice: " + cleanMsg.substring(0, 120));
                        }
                    }
                });
            }

            return card;
    }

    function openTheaterPreview(item) {
        if (!item) return;

        if (activeStreamAbortController) {
            try { activeStreamAbortController.abort(); } catch (_) {}
            activeStreamAbortController = null;
        }
        currentStreamRequestId++;

        // 1. Immediately pause and kill any mini size card preview running anywhere in the search grid
        if (activeVideoPreview) {
            if (activeVideoPreview.type === "youtube" && activeVideoPreview.iframe) {
                try {
                    activeVideoPreview.iframe.contentWindow.postMessage('{"event":"command","func":"pauseVideo","args":""}', '*');
                } catch (_) {}
            }
            stopActiveVideoPreview();
        }
        if (typeof globalAudio !== "undefined" && globalAudio && !globalAudio.paused) {
            globalAudio.pause();
            if (typeof currentPlayBtn !== "undefined" && currentPlayBtn) {
                currentPlayBtn.innerHTML = `<svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>`;
                currentPlayBtn = null;
            }
        }
        try {
            document.querySelectorAll(".studio-card-preview iframe, .studio-video-player-container iframe").forEach(iframe => {
                try { iframe.contentWindow.postMessage('{"event":"command","func":"pauseVideo","args":""}', '*'); } catch (_) {}
                try { iframe.remove(); } catch (_) {}
            });
            document.querySelectorAll(".studio-card-html5-video, .studio-card-preview video").forEach(v => {
                try { v.pause(); v.removeAttribute("src"); v.remove(); } catch (_) {}
            });
            document.querySelectorAll(".studio-video-player-container").forEach(c => {
                c.style.display = "none";
                c.innerHTML = "";
            });
            document.querySelectorAll(".studio-video-play-btn, .studio-audio-play-btn").forEach(btn => {
                const isAudio = btn.classList.contains("studio-audio-play-btn");
                const sz = isAudio ? 13 : 14;
                btn.innerHTML = `<svg width="${sz}" height="${sz}" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>`;
                btn.classList.remove("playing", "faded");
                btn.title = isAudio ? "Play Audio Preview" : "Play Video Preview";
            });
        } catch (_) {}

        const overlay = document.getElementById("modal-theater-preview");
        const container = document.getElementById("theater-modal-container");
        const titleEl = document.getElementById("theater-preview-title");
        const authorEl = document.getElementById("theater-preview-author");
        const badgeEl = document.getElementById("theater-badge-source");
        const videoEl = document.getElementById("theater-preview-video");
        const imgEl = document.getElementById("theater-preview-img");
        const iframeMount = document.getElementById("theater-iframe-container");
        const formatSelect = document.getElementById("theater-format-select");
        const btnImport = document.getElementById("btn-theater-import");
        const btnDownloader = document.getElementById("btn-theater-open-downloader");

        if (!overlay || !container) return;

        // Reset to mid-screen stage by default (covers ~75-80% screen, showing AE/Pr project behind dimmed backdrop)
        container.classList.remove("fullscreen");
        container.classList.add("mid-screen");
        container.style.position = "";
        container.style.left = "";
        container.style.top = "";
        container.style.transform = "";

        if (userMidWidth && userMidHeight) {
            container.style.width = userMidWidth + "px";
            container.style.height = userMidHeight + "px";
        } else {
            container.style.width = "";
            container.style.height = "";
        }
        updateTheaterZoomIcons(false);

        // Update titles & labels
        if (titleEl) titleEl.textContent = item.title || "Media Preview";
        if (authorEl) authorEl.textContent = `${item.author || "Creator"} • ${formatSourceLabel(item.source)}`;
        if (badgeEl) badgeEl.textContent = (item.type || "VIDEO").toUpperCase();

        // Populate format select dropdown for switching video quality / formats
        if (formatSelect) {
            formatSelect.innerHTML = "";
            const formats = item.downloadFormats || [];
            if (formats.length > 0) {
                formats.forEach((f, idx) => {
                    const opt = document.createElement("option");
                    opt.value = idx;
                    opt.textContent = f.label || `${f.ext || "mp4"} (${f.quality || "Default"})`;
                    formatSelect.appendChild(opt);
                });
                formatSelect.style.display = "block";
                const syncDirectFormatTrigger = () => {
                    if (formatSelect.parentElement && formatSelect.parentElement.classList.contains("mf-select-wrapper")) {
                        const trg = formatSelect.parentElement.querySelector(".mf-select-trigger");
                        const selOpt = formatSelect.options[formatSelect.selectedIndex];
                        if (trg && selOpt) trg.textContent = selOpt.text;
                    }
                };

                formatSelect.onchange = () => {
                    const selIdx = parseInt(formatSelect.value, 10) || 0;
                    const chosen = formats[selIdx];
                    if (chosen && videoEl && videoEl.style.display !== "none") {
                        const playUrl = (item.platform === "tiktok" && (chosen.previewUrl || formats.find(f => f.formatId === "tiktok_sd_nowm" || f.quality === "720")?.url)) ? (chosen.previewUrl || formats.find(f => f.formatId === "tiktok_sd_nowm" || f.quality === "720")?.url) : chosen.url;
                        if (playUrl) {
                            const curTime = videoEl.currentTime || 0;
                            videoEl.src = playUrl;
                            videoEl.currentTime = curTime;
                            videoEl.play().catch(() => {
                                videoEl.muted = true;
                                videoEl.play().catch(() => {});
                            });
                        }
                    } else if (chosen && imgEl && imgEl.style.display !== "none") {
                        if (chosen.url) imgEl.src = chosen.url;
                    }
                    syncDirectFormatTrigger();
                };

                formatSelect.value = "0";
                syncDirectFormatTrigger();
            } else {
                formatSelect.style.display = "none";
            }
        }

        // Save active item and check for saved playback timeline position
        activeTheaterItem = item;
        let savedTime = 0;
        let vidId = (item.videoId && item.videoId.length === 11) ? item.videoId : (item.id && !String(item.id).startsWith("link_") ? String(item.id).replace("yt_", "") : "");
        if (!vidId || vidId.length !== 11) {
            const urlToCheck = item.pageUrl || item.sourceUrl || item.url || "";
            const m = urlToCheck.match(/(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=|shorts\/|live\/))([a-zA-Z0-9_-]{11})/);
            if (m) vidId = m[1];
        }

        if (vidId) {
            if (playbackTimelineMemory.has(vidId)) savedTime = playbackTimelineMemory.get(vidId);
            else if (playbackTimelineMemory.has("yt_" + vidId)) savedTime = playbackTimelineMemory.get("yt_" + vidId);
            try {
                const ss = sessionStorage.getItem("mf_resume_" + vidId) || localStorage.getItem("mf_resume_" + vidId);
                if (ss && parseFloat(ss) > 0) savedTime = Math.max(savedTime, parseFloat(ss));
            } catch (_) {}
        }
        if (!savedTime && item.id) {
            if (playbackTimelineMemory.has(item.id)) savedTime = playbackTimelineMemory.get(item.id);
            try {
                const ss = sessionStorage.getItem("mf_resume_" + item.id) || localStorage.getItem("mf_resume_" + item.id);
                if (ss && parseFloat(ss) > 0) savedTime = Math.max(savedTime, parseFloat(ss));
            } catch (_) {}
        }

        const audioContainer = document.getElementById("theater-audio-container");
        const audioEl = document.getElementById("theater-preview-audio");
        const audioTitle = document.getElementById("theater-audio-title");
        const audioAuthor = document.getElementById("theater-audio-author");

        // Reset player displays
        if (videoEl) {
            try { videoEl.pause(); } catch (_) {}
            videoEl.removeAttribute("src");
            try { videoEl.load(); } catch (_) {}
            videoEl.style.display = "none";
            videoEl.muted = false;
            videoEl.volume = 1.0;
        }
        if (imgEl) { imgEl.src = ""; imgEl.style.display = "none"; }
        if (audioEl) { try { audioEl.pause(); } catch (_) {} audioEl.src = ""; try { audioEl.load(); } catch (_) {} }
        if (audioContainer) { audioContainer.style.display = "none"; }
        if (iframeMount) { iframeMount.innerHTML = ""; iframeMount.style.display = "none"; }

        const isAppleMusic = Boolean(item.isAppleMusic || item.source === "apple_music" || item.platform === "apple_music" || (item.pageUrl && /music\.apple\.com|itunes\.apple\.com/i.test(item.pageUrl)) || (item.url && /music\.apple\.com|itunes\.apple\.com/i.test(item.url)));
        const isSpotify = Boolean(item.isSpotify || item.source === "spotify" || item.platform === "spotify" || (item.pageUrl && /spotify\.com/i.test(item.pageUrl)) || (item.url && /spotify\.com/i.test(item.url)));
        const isTikTokMusic = Boolean((item.platform === "tiktok" || (item.pageUrl && /tiktok\.com/i.test(item.pageUrl)) || (item.url && /tiktok\.com/i.test(item.url))) && ((item.pageUrl && /tiktok\.com\/music\//i.test(item.pageUrl)) || (item.url && /tiktok\.com\/music\//i.test(item.url))));
        const isAudio = item.type === "audio" || item.mediaType === "audio" || isAppleMusic || isSpotify || isTikTokMusic || Boolean(item.audioPreviewUrl) || (typeof item.directStreamUrl === "string" && /\.(mp3|wav|m4a|aac|flac|ogg)($|\?)/i.test(item.directStreamUrl));
        const isPhoto = !isAudio && (item.type === "photo" || item.type === "image" || item.mediaType === "image" || Boolean(item.isImage) || Boolean(item.isGif) || (item.platform === "pinterest" && !item.hasVideo && !item.directVideoUrl) || (typeof item.directStreamUrl === "string" && /\.(jpe?g|png|webp|gif|bmp|svg)($|\?)/i.test(item.directStreamUrl)));
        const isBehance = item.platform === "behance" || item.source === "behance" || (item.url && /behance\.(?:net|com)/i.test(item.url)) || (item.pageUrl && /behance\.(?:net|com)/i.test(item.pageUrl));
        const isDribbble = item.platform === "dribbble" || item.source === "dribbble" || (item.url && /dribbble\.com/i.test(item.url)) || (item.pageUrl && /dribbble\.com/i.test(item.pageUrl));
        const isFiverr = item.platform === "fiverr" || item.source === "fiverr" || (item.url && /fiverr\.com/i.test(item.url)) || (item.pageUrl && /fiverr\.com/i.test(item.pageUrl));
        const isArtStation = item.platform === "artstation" || item.source === "artstation" || (item.url && /artstation\.com/i.test(item.url)) || (item.pageUrl && /artstation\.com/i.test(item.pageUrl));
        const isExplicitVideo = !isAudio && !isPhoto;
        const isYouTube = !isAudio && !isPhoto && !isAppleMusic && !isSpotify && !isBehance && !isDribbble && !isFiverr && !isArtStation && (
                          item.source === "youtube" || 
                          item.platform === "youtube" ||
                          (item.id && String(item.id).startsWith("yt_")) || 
                          (item.pageUrl && /(?:youtu\.be|youtube\.com)/i.test(item.pageUrl)) ||
                          (item.sourceUrl && /(?:youtu\.be|youtube\.com)/i.test(item.sourceUrl)) ||
                          (item.url && /(?:youtu\.be|youtube\.com)/i.test(item.url)));

        if (isPhoto) {
            if (badgeEl) {
                badgeEl.textContent = item.isGif ? "GIF" : "PHOTO";
                badgeEl.style.background = "";
                badgeEl.style.color = "";
            }
            if (videoEl) {
                try { videoEl.pause(); } catch (_) {}
                videoEl.removeAttribute("src");
                videoEl.style.display = "none";
                videoEl.style.setProperty("display", "none", "important");
            }
            if (iframeMount) {
                iframeMount.innerHTML = "";
                iframeMount.style.display = "none";
                iframeMount.style.setProperty("display", "none", "important");
            }
            if (audioContainer) {
                audioContainer.style.display = "none";
            }
            if (imgEl) {
                imgEl.src = item.hoverPreviewUrl || item.thumbnail || (item.downloadFormats && item.downloadFormats[0]?.url) || item.directStreamUrl || "";
                imgEl.style.display = "block";
                imgEl.style.setProperty("display", "block", "important");
            }
        } else if (isAudio) {
            if (isAppleMusic) {
                if (badgeEl) {
                    badgeEl.textContent = "APPLE MUSIC";
                    badgeEl.style.background = "#fc3c44";
                    badgeEl.style.color = "#fff";
                }
            } else if (isSpotify) {
                if (badgeEl) {
                    badgeEl.textContent = "SPOTIFY";
                    badgeEl.style.background = "#1db954";
                    badgeEl.style.color = "#000";
                }
            } else {
                if (badgeEl) {
                    badgeEl.textContent = "AUDIO";
                    badgeEl.style.background = "";
                    badgeEl.style.color = "";
                }
            }
            if (formatSelect) {
                formatSelect.style.display = "none";
            }
            if (audioContainer && audioEl) {
                audioContainer.style.display = "flex";
                if (audioTitle) audioTitle.textContent = item.title || "Audio Track";
                const sourceLabel = isAppleMusic ? "Apple Music" : (isSpotify ? "Spotify" : formatSourceLabel(item.source));
                if (audioAuthor) audioAuthor.textContent = `${item.author || item.uploader || "Artist"} • ${sourceLabel}`;
                
                // Show artwork in the avatar if available
                const avatarEl = audioContainer.querySelector(".theater-audio-avatar");
                if (avatarEl) {
                    if (item.thumbnail) {
                        avatarEl.innerHTML = `<img src="${item.thumbnail}" style="width: 100%; height: 100%; border-radius: 50%; object-fit: cover;" alt="Cover" />`;
                    } else {
                        avatarEl.innerHTML = `<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18V5l12-2v13"></path><circle cx="6" cy="18" r="3"></circle><circle cx="18" cy="16" r="3"></circle></svg>`;
                    }
                }

                let audioUrl = item.audioPreviewUrl || item.previewUrl || item.hoverPreviewUrl;
                if (!audioUrl && item.downloadFormats && item.downloadFormats.length > 0) {
                    const chosen = item.downloadFormats.find(f => f.url);
                    if (chosen) audioUrl = chosen.url;
                }
                audioEl.src = audioUrl || "";
                if (savedTime > 0) {
                    const onAudioSeekReady = () => {
                        try { audioEl.currentTime = savedTime; } catch (_) {}
                        audioEl.removeEventListener("loadedmetadata", onAudioSeekReady);
                        audioEl.removeEventListener("canplay", onAudioSeekReady);
                    };
                    audioEl.addEventListener("loadedmetadata", onAudioSeekReady);
                    audioEl.addEventListener("canplay", onAudioSeekReady);
                }
                audioEl.ontimeupdate = () => {
                    if (audioEl.currentTime > 0 && activeTheaterItem && activeTheaterItem.id) {
                        recordPlaybackTimeline(activeTheaterItem.id, audioEl.currentTime);
                    }
                };
                if (audioUrl) {
                    audioEl.play().catch(() => {});
                }
            }
        } else if (isYouTube) {
            if (badgeEl) {
                badgeEl.textContent = "YOUTUBE";
                badgeEl.style.background = "";
                badgeEl.style.color = "";
            }
            // Standard Player starts instantly with zero buffering and no rate-limits.
            // Direct Stream is available in the dropdown with a smart 3.5s watchdog fallback so it never freezes at 0:00.
            const defaultQuality = localStorage.getItem("mf_default_stream_quality") || "720";
            let directWatchdog = null;
            let playbackStarted = false;

            const cancelDirectWatchdog = () => {
                if (directWatchdog) {
                    clearTimeout(directWatchdog);
                    directWatchdog = null;
                }
            };

            const startDirectWatchdog = () => {
                cancelDirectWatchdog();
                playbackStarted = false;
                directWatchdog = setTimeout(() => {
                    if (!playbackStarted && videoEl && (videoEl.paused || videoEl.currentTime === 0) && activeTheaterItem && isYouTube) {
                        console.warn("[MediaFetch] Direct stream throttled at 0:00. Auto-falling back to Standard Player.");
                        showStudioNotification("Direct stream throttled by provider. Switched to Standard Player for instant playback.");
                        if (formatSelect) formatSelect.value = "embed";
                        loadStandardEmbed();
                    }
                }, 3500);
            };

            const loadStandardEmbed = () => {
                cancelDirectWatchdog();
                if (videoEl) {
                    try { videoEl.pause(); } catch (_) {}
                    videoEl.src = "";
                    videoEl.style.display = "none";
                    videoEl.style.setProperty("display", "none", "important");
                }
                if (imgEl) {
                    imgEl.src = "";
                    imgEl.style.display = "none";
                    imgEl.style.setProperty("display", "none", "important");
                }
                if (iframeMount && vidId) {
                    iframeMount.style.display = "block";
                    iframeMount.innerHTML = "";
                    const iframe = document.createElement("iframe");
                    iframe.style.width = "100%";
                    iframe.style.height = "100%";
                    iframe.style.border = "none";
                    iframe.allow = "autoplay; encrypted-media; picture-in-picture";
                    iframe.setAttribute("frameborder", "0");
                    iframe.setAttribute("referrerpolicy", "strict-origin-when-cross-origin");
                    iframe.src = getYouTubePlayerUrl(vidId, Math.floor(savedTime), defaultQuality);
                    iframeMount.appendChild(iframe);
                }
            };

            const loadDirectStream = async (targetQuality) => {
                cancelDirectWatchdog();
                const q = targetQuality || defaultQuality;
                if (iframeMount) { iframeMount.innerHTML = ""; iframeMount.style.display = "none"; }
                if (videoEl) {
                try { videoEl.pause(); } catch (_) {}
                videoEl.removeAttribute("src");
                try { videoEl.load(); } catch (_) {}
                videoEl.style.display = "block";
                videoEl.style.setProperty("display", "block", "important");
                if (imgEl) {
                    imgEl.src = "";
                    imgEl.style.display = "none";
                    imgEl.style.setProperty("display", "none", "important");
                }
                videoEl.poster = item.thumbnail || "";
                    videoEl.poster = item.thumbnail || "";

                    if (activeStreamAbortController) {
                        try { activeStreamAbortController.abort(); } catch (_) {}
                    }
                    activeStreamAbortController = new AbortController();
                    const thisReqId = ++currentStreamRequestId;
                    const thisItemId = item.id;

                    startDirectWatchdog();

                    try {
                        const p = getStudioServicePort();
                        const portsToTry = [p, 48924, 48923];
                        let data = null;
                        const targetParam = vidId || item.pageUrl || item.sourceUrl || item.url || "";
                        for (const pt of portsToTry) {
                            try {
                                const res = await fetch(`http://127.0.0.1:${pt}/api/stream-url?v=${encodeURIComponent(targetParam)}&quality=${encodeURIComponent(q)}`, {
                                    signal: activeStreamAbortController.signal
                                });
                                if (res && res.ok) {
                                    data = await res.json().catch(() => ({}));
                                    if (data && data.success && data.streamUrl) break;
                                }
                            } catch (fErr) {
                                if (fErr && fErr.name === "AbortError") { cancelDirectWatchdog(); return; }
                            }
                        }

                        // Stale request protection: if user switched video or closed modal, ignore
                        if (thisReqId !== currentStreamRequestId || !activeTheaterItem || activeTheaterItem.id !== thisItemId) {
                            cancelDirectWatchdog();
                            return;
                        }

                        if (data && data.success && data.streamUrl) {
                            videoEl.src = data.streamUrl;
                            videoEl.onerror = () => {
                                console.warn("Direct stream playback error for quality " + q);
                                cancelDirectWatchdog();
                                if (formatSelect) formatSelect.value = "embed";
                                loadStandardEmbed();
                            };
                            videoEl.onstalled = () => {
                                if (!playbackStarted && isYouTube) {
                                    console.warn("Direct stream stalled at 0:00");
                                    cancelDirectWatchdog();
                                    if (formatSelect) formatSelect.value = "embed";
                                    loadStandardEmbed();
                                }
                            };
                            const onVideoPlaying = () => {
                                playbackStarted = true;
                                cancelDirectWatchdog();
                            };
                            videoEl.onplaying = onVideoPlaying;
                            if (savedTime > 0) {
                                const onCanPlay = () => {
                                    try { videoEl.currentTime = savedTime; } catch (_) {}
                                    videoEl.removeEventListener("canplay", onCanPlay);
                                };
                                videoEl.addEventListener("canplay", onCanPlay);
                            }
                            videoEl.ontimeupdate = () => {
                                if (videoEl.currentTime > 0) {
                                    onVideoPlaying();
                                    if (activeTheaterItem && activeTheaterItem.id) {
                                        recordPlaybackTimeline(activeTheaterItem.id, videoEl.currentTime);
                                    }
                                }
                            };
                            videoEl.play().catch(() => {});
                        } else {
                            cancelDirectWatchdog();
                            if (formatSelect) formatSelect.value = "embed";
                            loadStandardEmbed();
                        }
                    } catch (e) {
                        cancelDirectWatchdog();
                        if (e && e.name === "AbortError") return;
                        if (thisReqId !== currentStreamRequestId || !activeTheaterItem || activeTheaterItem.id !== thisItemId) return;
                        if (formatSelect) formatSelect.value = "embed";
                        loadStandardEmbed();
                    }
                }
            };

            if (formatSelect) {
                formatSelect.innerHTML = "";
                const optEmbed = document.createElement("option");
                optEmbed.value = "embed";
                optEmbed.textContent = "Standard Player";
                formatSelect.appendChild(optEmbed);

                const qualities = [
                    { value: "direct-1080", label: "Direct Stream (1080p)" },
                    { value: "direct-720", label: "Direct Stream (720p HD)" },
                    { value: "direct-480", label: "Direct Stream (480p)" },
                    { value: "direct-360", label: "Direct Stream (360p)" }
                ];

                qualities.forEach(qOpt => {
                    const opt = document.createElement("option");
                    opt.value = qOpt.value;
                    opt.textContent = qOpt.label;
                    formatSelect.appendChild(opt);
                });

                formatSelect.style.display = "block";

                const handleFormatSwitch = () => {
                    const val = formatSelect.value;
                    if (formatSelect.parentElement && formatSelect.parentElement.classList.contains("mf-select-wrapper")) {
                        const trg = formatSelect.parentElement.querySelector(".mf-select-trigger");
                        const selOpt = formatSelect.options[formatSelect.selectedIndex];
                        if (trg && selOpt) trg.textContent = selOpt.text;
                    }
                    if (val.startsWith("direct-")) {
                        const targetQ = val.replace("direct-", "");
                        loadDirectStream(targetQ);
                    } else {
                        loadStandardEmbed();
                    }
                };

                formatSelect.onchange = handleFormatSwitch;
                formatSelect.addEventListener("change", handleFormatSwitch);

                // Default to Standard Player and sync trigger
                formatSelect.value = "embed";
                if (formatSelect.parentElement && formatSelect.parentElement.classList.contains("mf-select-wrapper")) {
                    const trg = formatSelect.parentElement.querySelector(".mf-select-trigger");
                    if (trg) trg.textContent = "Standard Player";
                }
                loadStandardEmbed();
            } else {
                loadStandardEmbed();
            }
        } else {
            const isBehance = item.source === "behance" || item.platform === "behance" || (item.pageUrl && /behance\.(?:net|com)/i.test(item.pageUrl)) || (item.url && /behance\.(?:net|com)/i.test(item.url));
            const isDribbble = item.source === "dribbble" || item.platform === "dribbble" || (item.pageUrl && /dribbble\.com/i.test(item.pageUrl)) || (item.url && /dribbble\.com/i.test(item.url));
            const isFiverr = item.source === "fiverr" || item.platform === "fiverr" || (item.pageUrl && /fiverr\.com/i.test(item.pageUrl)) || (item.url && /fiverr\.com/i.test(item.url));
            const isArtStation = item.source === "artstation" || item.platform === "artstation" || (item.pageUrl && /artstation\.com/i.test(item.pageUrl)) || (item.url && /artstation\.com/i.test(item.url));

            if (badgeEl) {
                if (isBehance) { badgeEl.textContent = "BEHANCE"; badgeEl.style.background = "#0057ff"; badgeEl.style.color = "#fff"; }
                else if (isDribbble) { badgeEl.textContent = "DRIBBBLE"; badgeEl.style.background = "#ea4c89"; badgeEl.style.color = "#fff"; }
                else if (isFiverr) { badgeEl.textContent = "FIVERR"; badgeEl.style.background = "#1dbf73"; badgeEl.style.color = "#fff"; }
                else if (isArtStation) { badgeEl.textContent = "ARTSTATION"; badgeEl.style.background = "#13aff0"; badgeEl.style.color = "#fff"; }
                else if (item.platform) { badgeEl.textContent = item.platform.toUpperCase(); badgeEl.style.background = ""; badgeEl.style.color = ""; }
                else { badgeEl.textContent = "VIDEO"; badgeEl.style.background = ""; badgeEl.style.color = ""; }
            }
            if (item.embedUrl) {
                if (videoEl) { videoEl.pause(); videoEl.src = ""; videoEl.style.display = "none"; }
                if (iframeMount) {
                    iframeMount.style.display = "block";
                    iframeMount.innerHTML = `<iframe src="${item.embedUrl}" style="width:100%; height:100%; border:none;" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen></iframe>`;
                }
            } else {
                // HTML5 video (Wikimedia, Pexels, Pixabay, TikTok, Instagram, Direct Web URLs, Behance direct MP4, Fiverr, Dribbble)
                // Prefer lightweight fast-loading 480p/720p derivative preview streams
                let streamUrl = item.previewUrl || item.hoverPreviewUrl || item.directStreamUrl;
            if (item.platform === "tiktok") {
                const h264Stream = item.downloadFormats?.find(f => f.formatId === "tiktok_sd_nowm" || f.quality === "720")?.url || item.previewUrl;
                if (h264Stream) streamUrl = h264Stream;
            } else if (!streamUrl && item.downloadFormats && item.downloadFormats.length > 0) {
                // Strictly exclude unplayable .ogv, .ogg, .mov codecs in Chromium
                const playableFormats = item.downloadFormats.filter(f => f.url && !/\.(ogv|ogg|mov)($|\?)/i.test(f.url));
                const pool = playableFormats.length > 0 ? playableFormats : item.downloadFormats;
                const sd = pool.find(f => f.url && ((f.height && f.height <= 720 && f.height >= 360) || (f.label && (f.label.includes("480") || f.label.includes("720") || f.label.includes("SD")))));
                const anyPlayable = pool.find(f => f.url && !f.isAudioOnly);
                if (sd && sd.url) streamUrl = sd.url;
                else if (anyPlayable && anyPlayable.url) streamUrl = anyPlayable.url;
                else streamUrl = pool[0].url;
            }
            if (streamUrl && streamUrl.includes('cloudinary.com') && streamUrl.includes('/video/') && !/\.(mp4|webm|m3u8|mov)($|\?)/i.test(streamUrl)) {
                streamUrl += '.mp4';
            }
            const isDirectFile = streamUrl && (/\.(mp4|webm|m3u8|mov|ogg)($|\?)/i.test(streamUrl) || streamUrl.includes('/video/upload/') || item.platform === "tiktok" || /tiktokcdn|mime_type=video_mp4/i.test(streamUrl) || item.type === "video" || item.mediaType === "video" || (streamUrl.startsWith('http') && !streamUrl.includes('youtube.com') && !streamUrl.includes('youtu.be')));
            if (videoEl) {
                try { videoEl.pause(); } catch (_) {}
                videoEl.removeAttribute("src");
                try { videoEl.load(); } catch (_) {}
                videoEl.style.display = "block";
                videoEl.style.setProperty("display", "block", "important");
                if (imgEl) {
                    imgEl.src = "";
                    imgEl.style.display = "none";
                    imgEl.style.setProperty("display", "none", "important");
                }
                videoEl.removeAttribute("crossorigin");
                videoEl.setAttribute("playsinline", "");
                videoEl.preload = "auto";
                videoEl.muted = false;
                videoEl.volume = 1.0;

                const startDirectPlayback = () => {
                    const playPromise = videoEl.play();
                    if (playPromise !== undefined) {
                        playPromise.catch(err => {
                            console.warn("[MediaFetch] Direct player unmuted play blocked, retrying muted:", err);
                            videoEl.muted = true;
                            videoEl.play().catch(e => console.warn("[MediaFetch] Muted play failed:", e));
                        });
                    }
                };

                videoEl.onerror = () => {
                    console.warn("[MediaFetch] Direct video playback error for:", videoEl.src);
                    if (item.downloadFormats && item.downloadFormats.length > 1) {
                        const fallback = item.downloadFormats.find(f => f.url && f.url !== videoEl.src && !/\.(ogv|ogg|mov)($|\?)/i.test(f.url));
                        if (fallback && fallback.url) {
                            console.log("[MediaFetch] Switching to alternative derivative format:", fallback.url);
                            videoEl.src = fallback.url;
                            startDirectPlayback();
                        }
                    }
                };

                if (formatSelect && item.downloadFormats && item.downloadFormats.length > 0) {
                    const activeIdx = item.downloadFormats.findIndex(f => f.url === streamUrl || f.cleanUrl === streamUrl);
                    if (activeIdx >= 0) {
                        formatSelect.value = String(activeIdx);
                        if (formatSelect.parentElement && formatSelect.parentElement.classList.contains("mf-select-wrapper")) {
                            const trg = formatSelect.parentElement.querySelector(".mf-select-trigger");
                            const selOpt = formatSelect.options[formatSelect.selectedIndex];
                            if (trg && selOpt) trg.textContent = selOpt.text;
                        }
                    }
                }
                if (isDirectFile) {
                    videoEl.src = streamUrl;
                    startDirectPlayback();
                } else {
                    const targetU = item.pageUrl || item.sourceUrl || item.url || streamUrl;
                    if (targetU) {
                        if (activeStreamAbortController) {
                            try { activeStreamAbortController.abort(); } catch (_) {}
                        }
                        activeStreamAbortController = new AbortController();
                        const thisReqId = ++currentStreamRequestId;
                        const thisItemId = item.id;

                        const p = getStudioServicePort();
                        fetch(`http://127.0.0.1:${p}/api/stream-url?v=${encodeURIComponent(targetU)}`, {
                            signal: activeStreamAbortController.signal
                        })
                            .then(r => r.json())
                            .then(data => {
                                if (thisReqId !== currentStreamRequestId || !activeTheaterItem || activeTheaterItem.id !== thisItemId) return;
                                if (data && data.success && data.streamUrl && videoEl) {
                                    videoEl.src = data.streamUrl;
                                    videoEl.play().catch(() => {});
                                }
                            })
                            .catch(fErr => {
                                if (fErr && fErr.name === "AbortError") return;
                                if (thisReqId !== currentStreamRequestId || !activeTheaterItem || activeTheaterItem.id !== thisItemId) return;
                                if (streamUrl && videoEl) videoEl.src = streamUrl;
                            });
                    } else if (streamUrl) {
                        videoEl.src = streamUrl;
                    }
                }
                if (savedTime > 0) {
                    const onSeekReady = () => {
                        try { videoEl.currentTime = savedTime; } catch (_) {}
                        videoEl.removeEventListener("loadedmetadata", onSeekReady);
                        videoEl.removeEventListener("canplay", onSeekReady);
                    };
                    videoEl.addEventListener("loadedmetadata", onSeekReady);
                    videoEl.addEventListener("canplay", onSeekReady);
                }
                videoEl.ontimeupdate = () => {
                    if (videoEl.currentTime > 0 && activeTheaterItem && activeTheaterItem.id) {
                        recordPlaybackTimeline(activeTheaterItem.id, videoEl.currentTime);
                    }
                };
            }
            }
        }

        // Wire Action Buttons in modal
        if (btnDownloader) {
            btnDownloader.onclick = () => {
                closeTheaterPreview();
                const targetUrl = item.pageUrl || item.sourceUrl || item.url || (item.downloadFormats && item.downloadFormats[0]?.sourceUrl) || (item.id && !String(item.id).startsWith("link_") ? (String(item.id).startsWith("yt_") ? `https://www.youtube.com/watch?v=${item.id.replace("yt_", "")}` : `https://www.youtube.com/watch?v=${item.id}`) : "");
                if (targetUrl) {
                    const isAudioItem = !isExplicitVideo && (item.mediaType === "audio" || item.type === "audio" || item.source === "songs" || item.badge === "SONG" || /(?:music\.apple\.com|spotify|soundcloud|deezer|bandcamp|audiomack)/i.test(targetUrl));

                    if (window.mediaFetchApp && typeof window.mediaFetchApp.loadUrlIntoDownloader === "function") {
                        window.mediaFetchApp.loadUrlIntoDownloader(targetUrl, {
                            isAudio: isAudioItem,
                            isVideo: !isAudioItem,
                            openTrimmer: true
                        });
                        return;
                    }

                    const modeBtnDownload = document.getElementById("mode-btn-download");
                    if (modeBtnDownload) modeBtnDownload.click();
                    if (isAudioItem) {
                        const audioOnlyBtn = document.getElementById("mode-audio-only");
                        if (audioOnlyBtn) audioOnlyBtn.click();
                    } else {
                        const videoAudioBtn = document.getElementById("mode-video-audio");
                        if (videoAudioBtn) videoAudioBtn.click();
                    }

                    if (typeof window.resetTrim === "function") window.resetTrim();
                    const cardSection = document.getElementById("media-card-section");
                    if (cardSection) cardSection.style.display = "none";

                    const urlInput = document.getElementById("url-input");
                    if (urlInput) {
                        urlInput.value = targetUrl;
                        urlInput.dispatchEvent(new Event("input", { bubbles: true }));
                        urlInput.dispatchEvent(new Event("change", { bubbles: true }));
                        urlInput.focus();
                    }

                    const trimPanel = document.getElementById("trim-inputs-panel");
                    const trimArrow = document.getElementById("trim-toggle-arrow");
                    if (trimPanel) {
                        trimPanel.style.display = "flex";
                        if (trimArrow) trimArrow.textContent = "▼";
                    }

                    const btnAnalyze = document.getElementById("btn-analyze");
                    if (btnAnalyze) {
                        setTimeout(() => {
                            btnAnalyze.click();
                        }, 120);
                    }
                }
            };
        }

        if (btnImport) {
            btnImport.onclick = async () => {
                const formats = (item && (item.downloadFormats || item.qualities)) || [];
                const selIdx = formatSelect ? (parseInt(formatSelect.value, 10) || 0) : 0;
                let format = formats[selIdx] || formats[0];
                if (!format) {
                    const rawUrl = item.url || item.sourceUrl || item.pageUrl || item.directStreamUrl || "";
                    const isAudio = item.mediaType === "audio" || (item.category && item.category === "audio");
                    const isImg = item.mediaType === "photo" || item.mediaType === "image" || (item.category && item.category === "photo");
                    format = {
                        quality: "1080",
                        label: isAudio ? "MP3 Audio" : (isImg ? "High Res Image" : "1080p Full HD"),
                        ext: isAudio ? "mp3" : (isImg ? "png" : "mp4"),
                        url: rawUrl
                    };
                }
                closeTheaterPreview();
                if (typeof Downloader !== "undefined") {
                    try {
                        const dlRes = await Downloader.downloadAndImport(item, format, csInterface, () => {});
                        if (dlRes && dlRes.noProject) {
                            showStudioNotification("Downloaded to disk! Open a project in Premiere Pro to auto-import.");
                        }
                    } catch (err) {
                        console.error("Theater import error:", err);
                        const errMsg = (err && err.message) ? err.message : String(err);
                        const cleanMsg = errMsg
                            .replace(/WARNING:[^\n]*/gi, '')
                            .replace(/\[(?:download|Merger|ExtractAudio)\][^\n]*/gi, '')
                            .replace(/See\s+https:\/\/[^\s]+/gi, '')
                            .replace(/ERROR:\s*/gi, '')
                            .trim();
                        if (cleanMsg.length > 0) {
                            showStudioNotification("Notice: " + cleanMsg.substring(0, 120));
                        }
                    }
                }
            };
        }

        // Show overlay with dark dim background
        overlay.classList.add("active");
    }

    function isCurrentFullscreen() {
        const container = document.getElementById("theater-modal-container");
        return !!(container && container.classList.contains("fullscreen"));
    }

    function toggleTheaterFullscreen() {
        const container = document.getElementById("theater-modal-container");
        const overlay = document.getElementById("modal-theater-preview");
        if (!container || !overlay) return;

        const isFull = isCurrentFullscreen();

        if (isFull) {
            // Exit Fullscreen -> Return to Mid-Screen (Pure CSS - zero CEF window lockup)
            container.classList.remove("fullscreen");
            container.classList.add("mid-screen");
            container.style.position = "";
            container.style.left = "";
            container.style.top = "";
            container.style.transform = "";

            if (userMidWidth && userMidHeight && userMidWidth < window.innerWidth && userMidHeight < window.innerHeight) {
                container.style.width = userMidWidth + "px";
                container.style.height = userMidHeight + "px";
            } else {
                container.style.width = "";
                container.style.height = "";
            }
            updateTheaterZoomIcons(false);
        } else {
            // Enter Fullscreen: Save current mid-screen size before going fullscreen
            const rect = container.getBoundingClientRect();
            if (rect.width > 120 && rect.width < window.innerWidth && rect.height > 100 && rect.height < window.innerHeight) {
                userMidWidth = rect.width;
                userMidHeight = rect.height;
            }

            container.classList.remove("mid-screen");
            container.classList.add("fullscreen");
            container.style.width = "100vw";
            container.style.height = "100vh";
            container.style.position = "fixed";
            container.style.left = "0";
            container.style.top = "0";
            container.style.transform = "none";
            updateTheaterZoomIcons(true);
        }
    }

    function updateTheaterZoomIcons(isFullscreen) {
        const iconExpand = document.getElementById("theater-zoom-icon-expand");
        const iconCompress = document.getElementById("theater-zoom-icon-compress");
        const cornerExpand = document.getElementById("theater-corner-icon-expand");
        const cornerCompress = document.getElementById("theater-corner-icon-compress");
        const cornerBtn = document.getElementById("btn-theater-corner-fullscreen");

        if (iconExpand && iconCompress) {
            iconExpand.style.display = isFullscreen ? "none" : "inline-block";
            iconCompress.style.display = isFullscreen ? "inline-block" : "none";
        }
        if (cornerExpand && cornerCompress) {
            cornerExpand.style.display = isFullscreen ? "none" : "inline-block";
            cornerCompress.style.display = isFullscreen ? "inline-block" : "none";
        }
        if (cornerBtn) {
            cornerBtn.title = isFullscreen ? "Exit Fullscreen (Return to Mid-Screen)" : "Toggle Fullscreen";
        }
        const btnZoom = document.getElementById("btn-theater-zoom-toggle");
        if (btnZoom) {
            btnZoom.title = isFullscreen ? "Exit Fullscreen (Return to Mid-Screen)" : "Toggle Fullscreen";
        }
    }

    function closeTheaterPreview() {
        const overlay = document.getElementById("modal-theater-preview");
        const container = document.getElementById("theater-modal-container");
        const videoEl = document.getElementById("theater-preview-video");
        const audioEl = document.getElementById("theater-preview-audio");
        const audioContainer = document.getElementById("theater-audio-container");
        const imgEl = document.getElementById("theater-preview-img");
        const iframeMount = document.getElementById("theater-iframe-container");

        // Preserve current playback time in memory before unmounting
        if (videoEl && activeTheaterItem && activeTheaterItem.id && videoEl.currentTime > 0) {
            recordPlaybackTimeline(activeTheaterItem.id, videoEl.currentTime);
        }
        if (audioEl && activeTheaterItem && activeTheaterItem.id && audioEl.currentTime > 0) {
            recordPlaybackTimeline(activeTheaterItem.id, audioEl.currentTime);
        }

        if (container) {
            container.classList.remove("fullscreen");
            container.classList.add("mid-screen");
            container.style.position = "";
            container.style.left = "";
            container.style.top = "";
            container.style.transform = "";
            updateTheaterZoomIcons(false);
        }

        if (document.fullscreenElement || document.webkitFullscreenElement) {
            try {
                if (document.exitFullscreen) document.exitFullscreen();
                else if (document.webkitExitFullscreen) document.webkitExitFullscreen();
            } catch (_) {}
        }

        // Instant hardware video decoder & audio release without UI freeze
        if (videoEl) {
            videoEl.pause();
            videoEl.removeAttribute("src");
            videoEl.load();
            videoEl.style.display = "none";
            videoEl.style.setProperty("display", "none", "important");
        }
        if (audioEl) {
            audioEl.pause();
            audioEl.removeAttribute("src");
            audioEl.load();
        }
        if (audioContainer) {
            audioContainer.style.display = "none";
        }
        if (imgEl) {
            imgEl.src = "";
            imgEl.style.display = "none";
            imgEl.style.setProperty("display", "none", "important");
        }
        if (iframeMount) {
            const iframes = iframeMount.querySelectorAll("iframe");
            iframes.forEach(f => {
                try { f.src = "about:blank"; } catch (_) {}
                try { f.remove(); } catch (_) {}
            });
            iframeMount.innerHTML = "";
            iframeMount.style.display = "none";
        }
        if (overlay) {
            overlay.classList.remove("active");
        }
        if (activeStreamAbortController) {
            try { activeStreamAbortController.abort(); } catch (_) {}
            activeStreamAbortController = null;
        }
        currentStreamRequestId++;
        activeTheaterItem = null;
        if (typeof window !== "undefined" && typeof window.triggerMemoryCleanup === "function") {
            window.triggerMemoryCleanup();
        }
    }

    function bindTheaterModal() {
        const overlay = document.getElementById("modal-theater-preview");
        const container = document.getElementById("theater-modal-container");
        const btnClose = document.getElementById("btn-theater-close");
        const btnZoom = document.getElementById("btn-theater-zoom-toggle");
        const btnCornerToggle = document.getElementById("btn-theater-corner-fullscreen");
        const btnCornerClose = document.getElementById("btn-theater-corner-close");
        const btnFloatingCompress = document.getElementById("btn-floating-compress");
        const btnFloatingClose = document.getElementById("btn-floating-close");
        const shield = document.getElementById("theater-drag-shield");
        const header = container ? container.querySelector(".theater-header") : null;
        const resizers = container ? container.querySelectorAll(".theater-resizer") : [];


        // Escape key listener to exit fullscreen or close theater preview
        document.addEventListener("keydown", (e) => {
            if (e.key === "Escape" || e.keyCode === 27) {
                if (overlay && overlay.classList.contains("active")) {
                    if (container && container.classList.contains("fullscreen")) {
                        toggleTheaterFullscreen();
                    } else {
                        closeTheaterPreview();
                    }
                }
            }
        });

        // Fullscreen Toggle in modal header
        if (btnZoom) {
            btnZoom.addEventListener("click", (e) => {
                e.stopPropagation();
                toggleTheaterFullscreen();
            });
        }

        // Bottom-Right Corner Fullscreen / Mid-Screen Toggle Button (Direct fix for cyan box interaction)
        if (btnCornerToggle) {
            btnCornerToggle.addEventListener("click", (e) => {
                e.stopPropagation();
                toggleTheaterFullscreen();
            });
        }

        // Bottom-Right Corner Close Button
        if (btnCornerClose) {
            btnCornerClose.addEventListener("click", (e) => {
                e.stopPropagation();
                closeTheaterPreview();
            });
        }

        // Floating controls (visible when player covers header in fullscreen)
        if (btnFloatingCompress) {
            btnFloatingCompress.addEventListener("click", (e) => {
                e.stopPropagation();
                toggleTheaterFullscreen();
            });
        }
        if (btnFloatingClose) {
            btnFloatingClose.addEventListener("click", (e) => {
                e.stopPropagation();
                closeTheaterPreview();
            });
        }

        // Fullscreen state listener
        const onFullscreenChange = () => {
            const isFull = !!(document.fullscreenElement || document.webkitFullscreenElement);
            if (!container) return;
            if (isFull) {
                container.classList.remove("mid-screen");
                container.classList.add("fullscreen");
                container.style.width = "100vw";
                container.style.height = "100vh";
                container.style.position = "fixed";
                container.style.left = "0";
                container.style.top = "0";
                container.style.transform = "none";
                updateTheaterZoomIcons(true);
            } else if (!isFull && container.classList.contains("fullscreen")) {
                container.classList.remove("fullscreen");
                container.classList.add("mid-screen");
                container.style.position = "";
                container.style.left = "";
                container.style.top = "";
                container.style.transform = "";
                if (userMidWidth && userMidHeight && userMidWidth < window.innerWidth && userMidHeight < window.innerHeight) {
                    container.style.width = userMidWidth + "px";
                    container.style.height = userMidHeight + "px";
                } else {
                    container.style.width = "";
                    container.style.height = "";
                }
                updateTheaterZoomIcons(false);
            }
        };
        document.addEventListener("fullscreenchange", onFullscreenChange);
        document.addEventListener("webkitfullscreenchange", onFullscreenChange);

        // Click outside container (on the dimmed black overlay backdrop) closes the preview instantly
        if (overlay) {
            overlay.addEventListener("click", (e) => {
                if (e.target === overlay) {
                    closeTheaterPreview();
                }
            });
        }

        if (btnClose) {
            btnClose.addEventListener("click", (e) => {
                e.stopPropagation();
                closeTheaterPreview();
            });
        }

        // 8-Directional Window Resizers for Mid-Screen
        let isResizing = false;
        let isDragging = false;
        let startX = 0, startY = 0;
        let startW = 0, startH = 0;
        let startLeft = 0, startTop = 0;
        let currentDir = "";

        resizers.forEach((resizer) => {
            resizer.addEventListener("mousedown", (e) => {
                if (container.classList.contains("fullscreen")) return;
                e.preventDefault();
                e.stopPropagation();

                isResizing = true;
                currentDir = resizer.dataset.dir || "";
                startX = e.clientX;
                startY = e.clientY;

                const rect = container.getBoundingClientRect();
                startW = rect.width;
                startH = rect.height;

                if (shield) {
                    shield.style.display = "block";
                    shield.style.cursor = window.getComputedStyle(resizer).cursor;
                }
                document.body.style.userSelect = "none";

                const onResizeMove = (moveEvt) => {
                    if (!isResizing) return;
                    moveEvt.preventDefault();

                    const dx = moveEvt.clientX - startX;
                    const dy = moveEvt.clientY - startY;

                    let newW = startW;
                    let newH = startH;

                    if (currentDir.includes("e")) newW = startW + dx;
                    if (currentDir.includes("w")) newW = startW - dx;
                    if (currentDir.includes("s")) newH = startH + dy;
                    if (currentDir.includes("n")) newH = startH - dy;

                    const minW = 320;
                    const minH = 200;
                    const maxW = window.innerWidth * 0.98;
                    const maxH = window.innerHeight * 0.98;

                    newW = Math.max(minW, Math.min(maxW, newW));
                    newH = Math.max(minH, Math.min(maxH, newH));

                    container.style.width = `${newW}px`;
                    container.style.height = `${newH}px`;
                    userMidWidth = newW;
                    userMidHeight = newH;
                };

                const onResizeUp = () => {
                    isResizing = false;
                    currentDir = "";
                    if (shield) shield.style.display = "none";
                    document.body.style.userSelect = "";
                    window.removeEventListener("mousemove", onResizeMove);
                    window.removeEventListener("mouseup", onResizeUp);
                };

                window.addEventListener("mousemove", onResizeMove);
                window.addEventListener("mouseup", onResizeUp);
            });
        });

        // Header Dragging for Repositioning Window
        if (header) {
            header.addEventListener("mousedown", (e) => {
                if (e.target.closest("button") || e.target.closest("select") || e.target.closest(".mf-select-wrapper") || e.target.closest(".mf-select-trigger") || e.target.closest(".mf-select-dropdown") || container.classList.contains("fullscreen")) {
                    return;
                }
                isDragging = true;
                startX = e.clientX;
                startY = e.clientY;

                const rect = container.getBoundingClientRect();
                startLeft = rect.left;
                startTop = rect.top;

                header.classList.add("dragging");
                if (shield) {
                    shield.style.display = "block";
                    shield.style.cursor = "grabbing";
                }
                document.body.style.userSelect = "none";

                container.style.position = "fixed";

                const onDragMove = (moveEvt) => {
                    if (!isDragging) return;
                    moveEvt.preventDefault();

                    const dx = moveEvt.clientX - startX;
                    const dy = moveEvt.clientY - startY;

                    const newLeft = Math.max(0, Math.min(window.innerWidth - 80, startLeft + dx));
                    const newTop = Math.max(0, Math.min(window.innerHeight - 40, startTop + dy));

                    container.style.left = `${newLeft}px`;
                    container.style.top = `${newTop}px`;
                    container.style.transform = "none";
                };

                const onDragUp = () => {
                    isDragging = false;
                    header.classList.remove("dragging");
                    if (shield) shield.style.display = "none";
                    document.body.style.userSelect = "";
                    window.removeEventListener("mousemove", onDragMove);
                    window.removeEventListener("mouseup", onDragUp);
                };

                window.addEventListener("mousemove", onDragMove);
                window.addEventListener("mouseup", onDragUp);
            });
        }
    }

    window.clearStudioMemoryCache = function() {
        const grid = document.getElementById("studio-results-grid");
        if (grid) {
            const mediaEls = grid.querySelectorAll("img, video, audio, iframe");
            mediaEls.forEach(el => {
                try {
                    if (el.pause) el.pause();
                    el.src = "";
                    el.removeAttribute("src");
                    el.remove();
                } catch (_) {}
            });
            grid.innerHTML = "";
        }
        renderedItemIds.clear();
        platformBuckets.clear();
        if (typeof window !== "undefined" && typeof window.gc === "function") {
            try { window.gc(); } catch (_) {}
        }
    };

    window.openTheaterPreview = openTheaterPreview;
    window.closeTheaterPreview = closeTheaterPreview;

    return {
        init: init,
        performSearch: performSearch,
        loadSettings: bindStudioSettings,
        openPreview: openTheaterPreview,
        openTheaterPreview: openTheaterPreview,
        closeTheaterPreview: closeTheaterPreview,
        clearMemory: window.clearStudioMemoryCache
    };
})();

if (typeof window !== 'undefined') {
    window.SearchStudio = SearchStudio;
}

if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => {
        SearchStudio.init();
    });
} else {
    SearchStudio.init();
}

// Low-end RAM garbage collection sweeps on idle
document.addEventListener("visibilitychange", () => {
    if (document.hidden && typeof window !== "undefined" && typeof window.gc === "function") {
        try { window.gc(); } catch (_) {}
    }
});
window.addEventListener("blur", () => {
    if (typeof window !== "undefined" && typeof window.gc === "function") {
        try { window.gc(); } catch (_) {}
    }
});



