/**
 * MediaFetch Search Studio Engine
 * Orchestrates 18+ Platforms across 5 Categories with direct Premiere Pro & After Effects Import
 */
const SearchStudio = (function () {
    const csInterface = typeof CSInterface !== "undefined" ? new CSInterface() : null;

    // Platform Configuration - 100% Working, Keyless, Reliable Platforms
    const categoryConfig = {
        video: {
            placeholder: "Search 4K B-Roll, drone shots, documentary clips...",
            platforms: [
                { id: "all", label: "✨ All Video Sources" },
                { id: "youtube", label: "▶️ YouTube 4K/HD" },
                { id: "pexels", label: "🎥 Pexels 4K/HD" },
                { id: "pixabay", label: "🎞️ Pixabay Video" },
                { id: "wikimedia", label: "🌐 Wikimedia 4K/HD" },
                { id: "unsplash", label: "📸 Unsplash 4K B-Roll" }
            ]
        },
        photo: {
            placeholder: "Search 700M+ photos, 4K/8K wallpapers, textures, art...",
            platforms: [
                { id: "all", label: "✨ All Photos & Art" },
                { id: "unsplash", label: "📸 Unsplash HD" },
                { id: "pexels", label: "🌿 Pexels Photos" },
                { id: "pixabay", label: "🖼️ Pixabay Photos" },
                { id: "wallhaven", label: "🌌 Wallhaven 4K/8K" },
                { id: "openverse", label: "🌍 Openverse (700M+)" },
                { id: "wikimedia", label: "🏛️ Wikimedia Art" }
            ]
        },
        audio: {
            placeholder: "Search foley, whooshes, impacts, background music...",
            platforms: [
                { id: "all", label: "✨ All Music & SFX" },
                { id: "jamendo", label: "🎸 Jamendo Music" },
                { id: "youtube_audio", label: "🎵 YouTube Audio" },
                { id: "freesound", label: "🔊 FreeSound / Foley" }
            ]
        }
    };

    let currentCategory = "video";
    let currentPlatform = "all";
    let currentOrientationFilter = "all"; // "all" | "landscape" | "portrait"
    let isSearching = false;
    let progressiveQueue = [];
    let isProcessingQueue = false;

    // Single global audio preview player
    const globalAudio = new Audio();
    let currentPlayBtn = null;

    globalAudio.addEventListener("ended", () => {
        if (currentPlayBtn) {
            currentPlayBtn.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>`;
            currentPlayBtn = null;
        }
    });

    // Single global active video preview tracker
    let activeVideoPreview = null;
    let fadeTimer = null;
    let currentSearchId = 0;
    let renderedItemIds = new Set();
    let userMidWidth = null;
    let userMidHeight = null;
    let activeTheaterItem = null;
    const playbackTimelineMemory = new Map();

    function getResumeLimit() {
        try {
            const raw = localStorage.getItem("mf_resume_history_limit");
            if (raw === "all") return Infinity;
            const parsed = parseInt(raw, 10);
            return (!isNaN(parsed) && parsed > 0) ? parsed : 3; // Default 3 videos for memory optimization
        } catch (_) {
            return 3;
        }
    }

    function recordPlaybackTimeline(key, currentTime) {
        if (!key || typeof currentTime !== "number" || currentTime <= 0) return;
        const curSec = Math.floor(currentTime);

        playbackTimelineMemory.set(key, curSec);
        try {
            sessionStorage.setItem("mf_resume_" + key, String(curSec));
            localStorage.setItem("mf_resume_" + key, String(curSec));

            // LRU queue tracking
            let order = [];
            try {
                const storedOrder = localStorage.getItem("mf_resume_keys_order");
                if (storedOrder) order = JSON.parse(storedOrder);
            } catch (_) {}

            if (!Array.isArray(order)) order = [];
            order = order.filter(k => k !== key && k !== ("yt_" + key));
            order.unshift(key);

            const limit = getResumeLimit();
            while (order.length > limit) {
                const purgedKey = order.pop();
                if (purgedKey) {
                    playbackTimelineMemory.delete(purgedKey);
                    playbackTimelineMemory.delete("yt_" + purgedKey);
                    sessionStorage.removeItem("mf_resume_" + purgedKey);
                    sessionStorage.removeItem("mf_resume_yt_" + purgedKey);
                    localStorage.removeItem("mf_resume_" + purgedKey);
                    localStorage.removeItem("mf_resume_yt_" + purgedKey);
                }
            }

            localStorage.setItem("mf_resume_keys_order", JSON.stringify(order));
        } catch (_) {}
    }

    function pruneStoredResumeHistory() {
        const limit = getResumeLimit();
        try {
            let order = [];
            const storedOrder = localStorage.getItem("mf_resume_keys_order");
            if (storedOrder) order = JSON.parse(storedOrder);
            if (Array.isArray(order) && order.length > limit) {
                while (order.length > limit) {
                    const purged = order.pop();
                    if (purged) {
                        playbackTimelineMemory.delete(purged);
                        playbackTimelineMemory.delete("yt_" + purged);
                        sessionStorage.removeItem("mf_resume_" + purged);
                        localStorage.removeItem("mf_resume_" + purged);
                    }
                }
                localStorage.setItem("mf_resume_keys_order", JSON.stringify(order));
            }
        } catch (_) {}
    }

    function getYouTubePlayerUrl(vidId, startSeconds = 0, quality = "") {
        const q = quality || localStorage.getItem("mf_default_stream_quality") || "720";
        let url = `http://127.0.0.1:48924/youtube-player.html?v=${encodeURIComponent(vidId)}&autoplay=1&quality=${encodeURIComponent(q)}`;
        if (startSeconds && startSeconds > 0) {
            url += `&start=${Math.floor(startSeconds)}`;
        }
        return url;
    }

    // Capture playback time reports and embed restriction signals from YouTube player
    window.addEventListener("message", (e) => {
        try {
            if (e.data && e.data.type === "MF_PLAYBACK_TIME") {
                const cur = typeof e.data.currentTime === "number" ? e.data.currentTime : parseFloat(e.data.currentTime);
                if (cur > 0) {
                    if (e.data.videoId) {
                        recordPlaybackTimeline(e.data.videoId, cur);
                        recordPlaybackTimeline("yt_" + e.data.videoId, cur);
                    }
                    if (activeTheaterItem && activeTheaterItem.id) {
                        recordPlaybackTimeline(activeTheaterItem.id, cur);
                    }
                }
            } else if (e.data && e.data.type === "MF_FULLSCREEN_CHANGE") {
                if (e.data.isFullscreen && !isCurrentFullscreen()) {
                    toggleTheaterFullscreen();
                } else if (!e.data.isFullscreen && isCurrentFullscreen()) {
                    toggleTheaterFullscreen();
                }
            } else if (e.data && e.data.type === "MF_EMBED_RESTRICTED") {
                const formatSelect = document.getElementById("theater-format-select");
                if (formatSelect && formatSelect.value === "embed") {
                    const defaultQuality = localStorage.getItem("mf_default_stream_quality") || "720";
                    formatSelect.value = "direct-" + defaultQuality;
                    if (typeof formatSelect.onchange === "function") {
                        formatSelect.onchange();
                    }
                }
            }
        } catch (_) {}
    });

    function stopActiveVideoPreview() {
        if (!activeVideoPreview) return;
        try {
            if (activeVideoPreview.type === "youtube" && activeVideoPreview.iframe) {
                try { activeVideoPreview.iframe.src = "about:blank"; } catch (_) {}
                activeVideoPreview.iframe.remove();
            } else if (activeVideoPreview.type === "html5" && activeVideoPreview.video) {
                activeVideoPreview.video.pause();
                activeVideoPreview.video.removeAttribute("src");
                try { activeVideoPreview.video.load(); } catch (_) {}
                activeVideoPreview.video.remove();
            }
            if (activeVideoPreview.container) {
                activeVideoPreview.container.style.display = "none";
                activeVideoPreview.container.innerHTML = "";
            }
            if (activeVideoPreview.playBtn) {
                const isAudioBtn = activeVideoPreview.playBtn.classList.contains("studio-audio-play-btn");
                const sz = isAudioBtn ? 13 : 14;
                activeVideoPreview.playBtn.innerHTML = `<svg width="${sz}" height="${sz}" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>`;
                activeVideoPreview.playBtn.classList.remove("playing", "faded");
                activeVideoPreview.playBtn.title = isAudioBtn ? "Play Audio Preview" : "Play Video Preview";
            }
        } catch (_) {}
        if (fadeTimer) {
            clearTimeout(fadeTimer);
            fadeTimer = null;
        }
        activeVideoPreview = null;
    }

    function pauseActiveVideo() {
        if (!activeVideoPreview || !activeVideoPreview.isPlaying) return;
        try {
            if (activeVideoPreview.type === "youtube" && activeVideoPreview.iframe) {
                activeVideoPreview.iframe.contentWindow.postMessage('{"event":"command","func":"pauseVideo","args":""}', '*');
            } else if (activeVideoPreview.type === "html5" && activeVideoPreview.video) {
                activeVideoPreview.video.pause();
            }
            activeVideoPreview.isPlaying = false;
            if (activeVideoPreview.playBtn) {
                const isAudioBtn = activeVideoPreview.playBtn.classList.contains("studio-audio-play-btn");
                const sz = isAudioBtn ? 13 : 14;
                activeVideoPreview.playBtn.innerHTML = `<svg width="${sz}" height="${sz}" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>`;
                activeVideoPreview.playBtn.classList.remove("playing", "faded");
                activeVideoPreview.playBtn.title = isAudioBtn ? "Resume Audio Preview" : "Resume Video Preview";
            }
            if (fadeTimer) {
                clearTimeout(fadeTimer);
                fadeTimer = null;
            }
        } catch (_) {}
    }

    function resumeActiveVideo() {
        if (!activeVideoPreview || activeVideoPreview.isPlaying) return;
        try {
            if (activeVideoPreview.type === "youtube" && activeVideoPreview.iframe) {
                activeVideoPreview.iframe.contentWindow.postMessage('{"event":"command","func":"playVideo","args":""}', '*');
            } else if (activeVideoPreview.type === "html5" && activeVideoPreview.video) {
                activeVideoPreview.video.play().catch(() => {});
            }
            activeVideoPreview.isPlaying = true;
            if (activeVideoPreview.playBtn) {
                const isAudioBtn = activeVideoPreview.playBtn.classList.contains("studio-audio-play-btn");
                const sz = isAudioBtn ? 13 : 14;
                activeVideoPreview.playBtn.innerHTML = `<svg width="${sz}" height="${sz}" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16"></rect><rect x="14" y="4" width="4" height="16"></rect></svg>`;
                activeVideoPreview.playBtn.classList.add("playing");
                activeVideoPreview.playBtn.title = isAudioBtn ? "Pause Audio Preview" : "Pause Video Preview";
            }
            scheduleFadeOut();
        } catch (_) {}
    }

    function scheduleFadeOut() {
        if (fadeTimer) clearTimeout(fadeTimer);
        fadeTimer = setTimeout(() => {
            if (activeVideoPreview && activeVideoPreview.isPlaying && activeVideoPreview.playBtn) {
                activeVideoPreview.playBtn.classList.add("faded");
            }
        }, 1200); // 1.2 seconds auto fade so button doesn't linger
    }

    function showPlayButton() {
        if (activeVideoPreview && activeVideoPreview.playBtn) {
            activeVideoPreview.playBtn.classList.remove("faded");
            if (activeVideoPreview.isPlaying) {
                scheduleFadeOut();
            }
        }
    }

    function init() {
        bindStudioSettings();
        bindModeToggle();
        bindCategoryTabs();
        bindSearchInput();
        bindFilterDropdown();
        bindTheaterModal();
        renderPlatformPills();

        const studioContent = document.querySelector("#mediaSearchView .studio-content");
        if (studioContent) {
            studioContent.addEventListener("scroll", () => {
                if (progressiveQueue.length > 0 && !isProcessingQueue) {
                    const scrollRemaining = studioContent.scrollHeight - (studioContent.scrollTop + studioContent.clientHeight);
                    if (scrollRemaining < 800) {
                        scheduleNextChunk(currentSearchId);
                    }
                }
            }, { passive: true });
        }
    }

    
    // Wire Studio Settings into Unified Settings Modal
    function bindStudioSettings() {
        const modal = document.getElementById("modal-settings");
        const btnOpenHeader = document.getElementById("btn-top-settings");
        const btnSave = document.getElementById("btn-save-settings");

        function loadStudioSettings() {
            const pexelsInput = document.getElementById("setting-studio-pexels-key");
            const pixabayInput = document.getElementById("setting-studio-pixabay-key");
            const unsplashInput = document.getElementById("setting-studio-unsplash-key");
            const giphyInput = document.getElementById("setting-studio-giphy-key");
            const timelineCheck = document.getElementById("setting-studio-auto-timeline");
            const pauseTabCheck = document.getElementById("setting-studio-pause-tab-change");

            if (typeof Settings !== "undefined") {
                const s = Settings.load();
                if (pexelsInput) pexelsInput.value = s.pexelsApiKey || "";
                if (pixabayInput) pixabayInput.value = s.pixabayApiKey || "";
                if (unsplashInput) unsplashInput.value = s.unsplashApiKey || "";
                if (giphyInput) giphyInput.value = s.giphyApiKey || "";
                if (timelineCheck) timelineCheck.checked = s.autoInsertTimeline !== false;
                if (pauseTabCheck) pauseTabCheck.checked = s.pausePreviewOnTabChange === true;
            }

            const engineSel = document.getElementById("setting-studio-player-engine");
            const qualitySel = document.getElementById("setting-studio-stream-quality");
            if (engineSel) {
                engineSel.value = localStorage.getItem("mf_default_player_engine") || "embed";
            }
            if (qualitySel) {
                qualitySel.value = localStorage.getItem("mf_default_stream_quality") || "720";
            }

            const resumeLimitSel = document.getElementById("setting-studio-resume-limit");
            if (resumeLimitSel) {
                const savedLimit = localStorage.getItem("mf_resume_history_limit") || "3";
                resumeLimitSel.value = savedLimit;
                resumeLimitSel.onchange = () => {
                    localStorage.setItem("mf_resume_history_limit", resumeLimitSel.value);
                    pruneStoredResumeHistory();
                };
            }
        }

        function saveStudioSettings() {
            const pexelsInput = document.getElementById("setting-studio-pexels-key");
            const pixabayInput = document.getElementById("setting-studio-pixabay-key");
            const unsplashInput = document.getElementById("setting-studio-unsplash-key");
            const giphyInput = document.getElementById("setting-studio-giphy-key");
            const customLoc = document.getElementById("setting-custom-location");
            const modeSel = document.getElementById("setting-location-mode");
            const pauseTabCheck = document.getElementById("setting-studio-pause-tab-change");
            const resumeLimitSel = document.getElementById("setting-studio-resume-limit");
            const engineSel = document.getElementById("setting-studio-player-engine");
            const qualitySel = document.getElementById("setting-studio-stream-quality");

            if (engineSel) {
                localStorage.setItem("mf_default_player_engine", engineSel.value || "embed");
            }
            if (qualitySel) {
                localStorage.setItem("mf_default_stream_quality", qualitySel.value || "720");
            }

            if (resumeLimitSel) {
                localStorage.setItem("mf_resume_history_limit", resumeLimitSel.value || "3");
                pruneStoredResumeHistory();
            }

            if (typeof Settings !== "undefined") {
                Settings.save({
                    downloadFolder: (modeSel && modeSel.value === "custom" && customLoc) ? customLoc.value.trim() : "",
                    pexelsApiKey: pexelsInput ? pexelsInput.value.trim() : "",
                    pixabayApiKey: pixabayInput ? pixabayInput.value.trim() : "",
                    unsplashApiKey: unsplashInput ? unsplashInput.value.trim() : "",
                    giphyApiKey: giphyInput ? giphyInput.value.trim() : "",
                    pausePreviewOnTabChange: pauseTabCheck ? pauseTabCheck.checked : false,
                    autoInsertTimeline: false
                });
            }
        }

        if (btnOpenHeader) {
            btnOpenHeader.addEventListener("click", () => {
                loadStudioSettings();
                if (modal) {
                    modal.classList.add("active");
                }
            });
        }

        if (btnSave) {
            btnSave.addEventListener("click", () => {
                saveStudioSettings();
            });
        }

        const btnOpenApiGuide = document.getElementById("btn-open-api-guide");
        const modalApiGuide = document.getElementById("modal-api-guide");
        const btnCloseApiGuide = document.getElementById("btn-close-api-guide");
        const btnDoneApiGuide = document.getElementById("btn-done-api-guide");

        function closeApiGuideModal() {
            if (modalApiGuide) {
                modalApiGuide.style.display = "none";
                modalApiGuide.classList.remove("active");
            }
        }

        if (btnOpenApiGuide && modalApiGuide) {
            btnOpenApiGuide.addEventListener("click", () => {
                modalApiGuide.style.display = "flex";
                modalApiGuide.classList.add("active");
            });
        }
        if (btnCloseApiGuide) btnCloseApiGuide.addEventListener("click", closeApiGuideModal);
        if (btnDoneApiGuide) btnDoneApiGuide.addEventListener("click", closeApiGuideModal);

        document.querySelectorAll(".btn-api-external-link").forEach(btn => {
            btn.addEventListener("click", (e) => {
                const u = btn.getAttribute("data-url");
                if (u) {
                    if (window.__adobe_cep__ && typeof window.__adobe_cep__.openURLInDefaultBrowser === "function") {
                        window.__adobe_cep__.openURLInDefaultBrowser(u);
                    } else if (window.cep && window.cep.util && typeof window.cep.util.openURLInDefaultBrowser === "function") {
                        window.cep.util.openURLInDefaultBrowser(u);
                    } else {
                        window.open(u, "_blank");
                    }
                }
            });
        });
    }

    function bindModeToggle() {
        const btnDownload = document.getElementById("mode-btn-download");
        const btnSearch = document.getElementById("mode-btn-search");
        const fetchView = document.getElementById("mediaFetchView");
        const searchView = document.getElementById("mediaSearchView");

        if (!btnDownload || !btnSearch || !fetchView || !searchView) return;

        btnDownload.addEventListener("click", () => {
            btnDownload.classList.add("active");
            btnSearch.classList.remove("active");
            fetchView.style.display = "flex";
            searchView.style.display = "none";

            // If user enabled "Pause video preview when switching tabs", pause playback. Otherwise keep it running smoothly!
            const shouldPause = (typeof Settings !== "undefined" && Settings.get("pausePreviewOnTabChange"));
            if (shouldPause && typeof pauseActiveVideo === "function") {
                pauseActiveVideo();
            }

            // Proactive memory cleanup
            if (typeof window.triggerMemoryCleanup === "function") {
                window.triggerMemoryCleanup();
            } else if (typeof window !== "undefined" && typeof window.gc === "function") {
                try { window.gc(); } catch (_) {}
            }
        });

        btnSearch.addEventListener("click", () => {
            btnSearch.classList.add("active");
            btnDownload.classList.remove("active");
            fetchView.style.display = "none";
            searchView.style.display = "flex";
        });
    }

    function scrollElementIntoViewSmart(el, container) {
        if (!el || !container) return;
        const containerWidth = container.clientWidth;
        const elLeft = el.offsetLeft;
        const elWidth = el.offsetWidth;

        // Auto-center the clicked element inside the horizontal container,
        // so if the user clicks the last visible button on the right, it slides over
        // and reveals the next buttons on the right!
        const targetScroll = elLeft - (containerWidth / 2) + (elWidth / 2);
        container.scrollTo({
            left: Math.max(0, targetScroll),
            behavior: "smooth"
        });
    }

    function setupHorizontalScroll(container) {
        if (!container || container._hasHScroll) return;
        container._hasHScroll = true;

        // Mouse wheel smooth horizontal scrolling (no scrollbar needed)
        container.addEventListener("wheel", (e) => {
            if (e.deltaY !== 0 || e.deltaX !== 0) {
                e.preventDefault();
                const delta = e.deltaY !== 0 ? e.deltaY : e.deltaX;
                container.scrollLeft += delta * 0.8;
            }
        }, { passive: false });

        // Touch / mouse drag-to-slide
        let isDown = false;
        let startX = 0;
        let scrollStart = 0;

        container.addEventListener("mousedown", (e) => {
            isDown = true;
            container._dragMoved = false;
            startX = e.pageX;
            scrollStart = container.scrollLeft;
        });

        window.addEventListener("mousemove", (e) => {
            if (!isDown) return;
            const diff = e.pageX - startX;
            if (Math.abs(diff) > 4) {
                container._dragMoved = true;
                container.classList.add("is-dragging");
            }
            container.scrollLeft = scrollStart - diff;
        });

        window.addEventListener("mouseup", () => {
            if (isDown) {
                isDown = false;
                container.classList.remove("is-dragging");
                setTimeout(() => {
                    container._dragMoved = false;
                }, 60);
            }
        });
    }

    function bindCategoryTabs() {
        const studioNav = document.querySelector(".studio-nav");
        if (studioNav) setupHorizontalScroll(studioNav);

        const tabs = document.querySelectorAll(".studio-tab");
        tabs.forEach(tab => {
            tab.addEventListener("click", () => {
                if (studioNav && studioNav._dragMoved) return;
                tabs.forEach(t => t.classList.remove("active"));
                tab.classList.add("active");
                currentCategory = tab.dataset.category;
                currentPlatform = "all";

                if (studioNav) scrollElementIntoViewSmart(tab, studioNav);

                renderPlatformPills();
                const input = document.getElementById("studio-search-input");
                if (input && input.value.trim()) {
                    performSearch(input.value.trim());
                }
            });
        });
    }

    function renderPlatformPills() {
        const platformBar = document.getElementById("studio-platform-bar");
        const input = document.getElementById("studio-search-input");
        if (!platformBar) return;

        setupHorizontalScroll(platformBar);
        platformBar.innerHTML = "";
        const config = categoryConfig[currentCategory] || categoryConfig.video;
        if (input) input.placeholder = config.placeholder;

        config.platforms.forEach(plat => {
            const pill = document.createElement("button");
            pill.className = `platform-pill ${plat.id === currentPlatform ? "active" : ""}`;
            pill.textContent = plat.label;

            pill.addEventListener("click", () => {
                if (platformBar._dragMoved) return;
                platformBar.querySelectorAll(".platform-pill").forEach(p => p.classList.remove("active"));
                pill.classList.add("active");
                currentPlatform = plat.id;

                // Auto-slide: Centers this pill and automatically reveals the hidden options on the right/left
                scrollElementIntoViewSmart(pill, platformBar);

                if (plat.id === "direct" || plat.id === "universal") {
                    const btnDownload = document.getElementById("mode-btn-download");
                    if (btnDownload) btnDownload.click();
                    return;
                }

                if (input && input.value.trim()) {
                    performSearch(input.value.trim());
                }
            });

            platformBar.appendChild(pill);
        });

        // Ensure active pill is scrolled into view smoothly
        const activePill = platformBar.querySelector(".platform-pill.active");
        if (activePill) {
            setTimeout(() => {
                scrollElementIntoViewSmart(activePill, platformBar);
            }, 60);
        }
    }

    function bindSearchInput() {
        const input = document.getElementById("studio-search-input");
        const btn = document.getElementById("studio-search-btn");

        if (btn && input) {
            btn.addEventListener("click", () => {
                const q = input.value.trim();
                if (q) performSearch(q);
            });

            input.addEventListener("keydown", (e) => {
                if (e.key === "Enter") {
                    const q = input.value.trim();
                    if (q) performSearch(q);
                }
            });
        }
    }

    function bindFilterDropdown() {
        const filterBtn = document.getElementById("studio-filter-btn");
        const filterDropdown = document.getElementById("studio-filter-dropdown");
        const filterContainer = document.querySelector(".studio-filter-container");
        const filterLabel = document.getElementById("studio-filter-label");
        const filterOptions = document.querySelectorAll(".studio-filter-option");
        const searchInput = document.getElementById("studio-search-input");

        if (!filterBtn || !filterDropdown) return;

        filterBtn.addEventListener("click", (e) => {
            e.stopPropagation();
            const isOpen = filterDropdown.style.display === "block";
            filterDropdown.style.display = isOpen ? "none" : "block";
            if (filterContainer) {
                filterContainer.classList.toggle("open", !isOpen);
            }
        });

        filterOptions.forEach(opt => {
            opt.addEventListener("click", (e) => {
                e.stopPropagation();
                const ratio = opt.getAttribute("data-ratio") || "all";
                currentOrientationFilter = ratio;

                filterOptions.forEach(o => o.classList.remove("active"));
                opt.classList.add("active");

                if (filterLabel) {
                    if (ratio === "landscape") filterLabel.textContent = "16:9";
                    else if (ratio === "portrait") filterLabel.textContent = "9:16";
                    else filterLabel.textContent = "All";
                }

                if (ratio !== "all") {
                    filterBtn.classList.add("active-filter");
                } else {
                    filterBtn.classList.remove("active-filter");
                }

                filterDropdown.style.display = "none";
                if (filterContainer) filterContainer.classList.remove("open");

                if (searchInput && searchInput.value.trim()) {
                    performSearch(searchInput.value.trim());
                }
            });
        });

        document.addEventListener("click", (e) => {
            if (filterContainer && !filterContainer.contains(e.target)) {
                filterDropdown.style.display = "none";
                filterContainer.classList.remove("open");
            }
        });
    }

    async function performSearch(query) {
        currentSearchId++;
        const thisSearchId = currentSearchId;
        isSearching = true;
        progressiveQueue = [];
        isProcessingQueue = false;

        stopActiveVideoPreview();

        const grid = document.getElementById("studio-results-grid");
        const emptyState = document.getElementById("studio-empty-state");
        const loadingState = document.getElementById("studio-loading-state");

        if (grid) {
            const imgs = grid.querySelectorAll("img");
            imgs.forEach(i => { try { i.src = ""; i.remove(); } catch (_) {} });
            grid.innerHTML = "";
        }
        renderedItemIds.clear();
        if (typeof window !== "undefined" && typeof window.gc === "function") {
            try { window.gc(); } catch (_) {}
        }
        if (emptyState) emptyState.style.display = "none";
        if (loadingState) loadingState.style.display = "flex";

        const platformBuckets = new Map();
        let flushScheduled = false;

        function flushPlatformBuckets(isFinal = false) {
            flushScheduled = false;
            if (thisSearchId !== currentSearchId) return;

            const isLowRam = typeof localStorage !== "undefined" && localStorage.getItem("mediafetch_low_ram_mode") === "true";
            const maxCards = isLowRam ? 80 : 200; // Maximized volume matching official platforms (up to 200 cards)
            if (renderedItemIds.size >= maxCards) return;

            const pulledItems = [];
            // When initial search is still running across parallel APIs, limit per-platform burst to 3 items
            // so faster platforms don't crowd out slower ones before they arrive.
            const maxPerPlatformPerTick = (!isFinal && isSearching) ? 3 : Infinity;
            const tickCounts = new Map();

            let hadItems = true;
            while (hadItems && (renderedItemIds.size + pulledItems.length < maxCards)) {
                hadItems = false;
                for (const [platformKey, items] of platformBuckets.entries()) {
                    const currentTickCount = tickCounts.get(platformKey) || 0;
                    if (currentTickCount < maxPerPlatformPerTick && items && items.length > 0) {
                        const nextItem = items.shift();
                        if (nextItem && nextItem.id && !renderedItemIds.has(nextItem.id)) {
                            pulledItems.push(nextItem);
                            renderedItemIds.add(nextItem.id);
                            tickCounts.set(platformKey, currentTickCount + 1);
                            hadItems = true;
                            if (renderedItemIds.size + pulledItems.length >= maxCards) break;
                        }
                    }
                }
            }

            if (pulledItems.length > 0) {
                if (loadingState) loadingState.style.display = "none";
                if (emptyState) emptyState.style.display = "none";
                appendCardsToGrid(pulledItems, thisSearchId);
            }
        }

        function handleIncomingBatch(newItems, sourceTag) {
            if (thisSearchId !== currentSearchId) return;
            if (!newItems || newItems.length === 0) return;
            const isLowRam = typeof localStorage !== "undefined" && localStorage.getItem("mediafetch_low_ram_mode") === "true";
            const maxCards = isLowRam ? 80 : 200;
            if (renderedItemIds.size >= maxCards) return;

            const unique = newItems.filter(it => it && it.id && !renderedItemIds.has(it.id));
            if (unique.length === 0) return;

            if (currentPlatform !== "all") {
                const sliceLimit = Math.max(0, maxCards - renderedItemIds.size);
                const toAdd = unique.slice(0, sliceLimit);
                toAdd.forEach(it => renderedItemIds.add(it.id));

                if (loadingState) loadingState.style.display = "none";
                if (emptyState) emptyState.style.display = "none";

                appendCardsToGrid(toAdd, thisSearchId);
                return;
            }

            // Multi-platform round-robin pool: tag by platform
            const tag = sourceTag || (unique[0] && unique[0].source ? unique[0].source.toLowerCase() : "general");
            if (!platformBuckets.has(tag)) {
                platformBuckets.set(tag, []);
            }
            const bucket = platformBuckets.get(tag);
            const bucketIds = new Set(bucket.map(b => b.id));
            for (const item of unique) {
                if (!bucketIds.has(item.id)) {
                    bucket.push(item);
                    bucketIds.add(item.id);
                }
            }

            if (!flushScheduled) {
                flushScheduled = true;
                setTimeout(() => flushPlatformBuckets(false), 20);
            }
        }

        try {
            const searchPromises = [];
            const apiOptions = {
                orientation: currentOrientationFilter !== "all" ? currentOrientationFilter : ""
            };

            // Direct URL Check
            if (query.startsWith("http://") || query.startsWith("https://")) {
                const item = {
                    id: "direct_" + Date.now(),
                    source: "direct link",
                    type: "video",
                    title: query.split("/").pop().split("?")[0] || "Direct Web Media",
                    author: "Web Source",
                    thumbnail: "https://commons.wikimedia.org/w/resources/assets/file-type-icons/fileicon-video.png",
                    hoverPreviewUrl: "",
                    downloadFormats: [
                        { label: "Direct MP4 Download", url: query, ext: "mp4", type: "video" },
                        { label: "MP3 Audio Extraction", url: query, ext: "mp3", type: "audio" }
                    ],
                    pageUrl: query
                };
                if (loadingState) loadingState.style.display = "none";
                renderResults([item]);
                isSearching = false;
                return;
            }

            // 1. Video & B-Roll (100% Working, Free & 4K)
            if (currentCategory === "video") {
                if ((currentPlatform === "all" || currentPlatform === "youtube") && typeof YouTubeAPI !== "undefined") {
                    searchPromises.push(
                        YouTubeAPI.searchVideos(query, {
                            limit: (currentPlatform === "all" ? 100 : 120),
                            orientation: currentOrientationFilter,
                            onBatch: (batch) => handleIncomingBatch(batch, "youtube")
                        }).then(r => handleIncomingBatch(r.items || [], "youtube")).catch(() => [])
                    );
                }
                if ((currentPlatform === "all" || currentPlatform === "pexels") && typeof PexelsAPI !== "undefined") {
                    searchPromises.push(PexelsAPI.searchVideos(query, Object.assign({ perPage: 60 }, apiOptions)).then(r => handleIncomingBatch(r.items || [], "pexels")).catch(() => []));
                }
                if ((currentPlatform === "all" || currentPlatform === "pixabay") && typeof PixabayAPI !== "undefined") {
                    searchPromises.push(PixabayAPI.searchVideos(query, Object.assign({ perPage: 60 }, apiOptions)).then(r => handleIncomingBatch(r.items || [], "pixabay")).catch(() => []));
                }
                if ((currentPlatform === "all" || currentPlatform === "wikimedia") && typeof WikimediaAPI !== "undefined") {
                    searchPromises.push(WikimediaAPI.searchVideos(query, Object.assign({ perPage: 50 }, apiOptions)).then(r => handleIncomingBatch(r.items || [], "wikimedia")).catch(() => []));
                }
                if ((currentPlatform === "all" || currentPlatform === "unsplash") && typeof UnsplashAPI !== "undefined") {
                    searchPromises.push(UnsplashAPI.searchPhotos(query, Object.assign({ perPage: 50 }, apiOptions)).then(r => handleIncomingBatch(r.items || [], "unsplash")).catch(() => []));
                }
            }

            // 2. Photos, 4K & Art (100% Working, Free & High-Res)
            else if (currentCategory === "photo") {
                if ((currentPlatform === "all" || currentPlatform === "unsplash") && typeof UnsplashAPI !== "undefined") {
                    searchPromises.push(UnsplashAPI.searchPhotos(query, Object.assign({ perPage: 50 }, apiOptions)).then(r => handleIncomingBatch(r.items || [], "unsplash")).catch(() => []));
                }
                if ((currentPlatform === "all" || currentPlatform === "pexels") && typeof PexelsAPI !== "undefined") {
                    searchPromises.push(PexelsAPI.searchPhotos(query, Object.assign({ perPage: 60 }, apiOptions)).then(r => handleIncomingBatch(r.items || [], "pexels")).catch(() => []));
                }
                if ((currentPlatform === "all" || currentPlatform === "pixabay") && typeof PixabayAPI !== "undefined") {
                    searchPromises.push(PixabayAPI.searchPhotos(query, Object.assign({ perPage: 60 }, apiOptions)).then(r => handleIncomingBatch(r.items || [], "pixabay")).catch(() => []));
                }
                if ((currentPlatform === "all" || currentPlatform === "wikimedia") && typeof WikimediaAPI !== "undefined") {
                    searchPromises.push(WikimediaAPI.searchPhotos(query, Object.assign({ perPage: 50 }, apiOptions)).then(r => handleIncomingBatch(r.items || [], "wikimedia")).catch(() => []));
                }
                if ((currentPlatform === "all" || currentPlatform === "wallhaven") && typeof WallhavenAPI !== "undefined") {
                    searchPromises.push(WallhavenAPI.searchWallpapers(query, apiOptions).then(r => handleIncomingBatch(r.items || [], "wallhaven")).catch(() => []));
                }
                if ((currentPlatform === "all" || currentPlatform === "openverse") && typeof OpenverseAPI !== "undefined") {
                    searchPromises.push(OpenverseAPI.searchPhotos(query, Object.assign({ perPage: 50 }, apiOptions)).then(r => handleIncomingBatch(r.items || [], "openverse")).catch(() => []));
                }
            }

            // 3. Music & SFX (100% Working, Free & Royalty-Free)
            else if (currentCategory === "audio") {
                if ((currentPlatform === "all" || currentPlatform === "jamendo") && typeof JamendoAPI !== "undefined") {
                    searchPromises.push(JamendoAPI.searchTracks(query).then(r => handleIncomingBatch(r.items || [], "jamendo")).catch(() => []));
                }
                if ((currentPlatform === "all" || currentPlatform === "youtube_audio") && typeof YouTubeAPI !== "undefined") {
                    searchPromises.push(YouTubeAPI.searchVideos(query, {
                        limit: (currentPlatform === "all" ? 40 : 60),
                        onBatch: (batch) => {
                            const audioBatch = (batch || []).map(it => Object.assign({}, it, {
                                type: "audio",
                                downloadFormats: [
                                    { label: "MP3 320kbps Audio", ext: "mp3", quality: "audio", type: "audio" },
                                    { label: "WAV Lossless Audio", ext: "wav", quality: "audio-wav", type: "audio" }
                                ]
                            }));
                            handleIncomingBatch(audioBatch, "youtube_audio");
                        }
                    }).then(r => {
                        const audioItems = (r.items || []).map(it => Object.assign({}, it, {
                            type: "audio",
                            downloadFormats: [
                                { label: "MP3 320kbps Audio", ext: "mp3", quality: "audio", type: "audio" },
                                { label: "WAV Lossless Audio", ext: "wav", quality: "audio-wav", type: "audio" }
                            ]
                        }));
                        handleIncomingBatch(audioItems, "youtube_audio");
                    }).catch(() => []));
                }
                if ((currentPlatform === "all" || currentPlatform === "freesound") && typeof OpenverseAPI !== "undefined") {
                    searchPromises.push(OpenverseAPI.searchAudio(query).then(r => handleIncomingBatch(r.items || [], "freesound")).catch(() => []));
                }
            }

            await Promise.allSettled(searchPromises);

            if (thisSearchId === currentSearchId) {
                flushPlatformBuckets(true);
                if (loadingState) loadingState.style.display = "none";
                if (renderedItemIds.size === 0 && emptyState) {
                    emptyState.style.display = "flex";
                }
            }
        } catch (err) {
            console.error("Search error:", err);
            if (thisSearchId === currentSearchId) {
                flushPlatformBuckets(true);
                if (loadingState) loadingState.style.display = "none";
                if (renderedItemIds.size === 0 && emptyState) emptyState.style.display = "flex";
            }
        } finally {
            if (thisSearchId === currentSearchId) {
                isSearching = false;
                flushPlatformBuckets(true);
            }
        }
    }

    function formatSourceLabel(src) {
        if (!src) return "Source";
        const s = src.toLowerCase();
        if (s.includes("freesound")) return "FreeSound";
        if (s.includes("youtube")) return "YouTube";
        if (s.includes("jamendo")) return "Jamendo";
        if (s.includes("openverse")) return "Openverse";
        if (s.includes("wikimedia")) return "Wikimedia";
        if (s.includes("wallhaven")) return "Wallhaven";
        if (s.includes("pexels")) return "Pexels";
        if (s.includes("pixabay")) return "Pixabay";
        if (s.includes("unsplash")) return "Unsplash";
        if (s.includes("giphy")) return "Giphy";
        return src.replace(/\s*\([^)]*\)/g, "").trim();
    }

    function renderResults(items) {
        const grid = document.getElementById("studio-results-grid");
        if (!grid) return;
        grid.innerHTML = "";
        renderedItemIds.clear();
        progressiveQueue = [];
        isProcessingQueue = false;
        appendCardsToGrid(items, currentSearchId);
    }

    function scheduleNextChunk(searchId) {
        if (isProcessingQueue || progressiveQueue.length === 0) return;
        isProcessingQueue = true;

        setTimeout(() => {
            if (searchId !== currentSearchId) {
                progressiveQueue = [];
                isProcessingQueue = false;
                return;
            }

            const chunk = progressiveQueue.splice(0, 15);
            if (chunk.length > 0) {
                mountCardsChunk(chunk);
            }
            isProcessingQueue = false;

            if (progressiveQueue.length > 0 && searchId === currentSearchId) {
                scheduleNextChunk(searchId);
            }
        }, 25);
    }

    function mountCardsChunk(items) {
        const grid = document.getElementById("studio-results-grid");
        if (!grid || !items || items.length === 0) return;
        const fragment = document.createDocumentFragment();
        items.forEach(item => {
            try {
                const card = buildCardElement(item);
                if (card) fragment.appendChild(card);
            } catch (err) {
                console.warn("Failed to render card:", err);
            }
        });
        grid.appendChild(fragment);
    }

    function appendCardsToGrid(items, searchId) {
        const grid = document.getElementById("studio-results-grid");
        if (!grid || !items || items.length === 0) return;
        const targetSearchId = searchId || currentSearchId;

        // Instant rendering of top media cards in milliseconds
        if (grid.children.length === 0) {
            const firstChunk = items.slice(0, 15);
            mountCardsChunk(firstChunk);
            const remainder = items.slice(15);
            if (remainder.length > 0) {
                progressiveQueue.push(...remainder);
                scheduleNextChunk(targetSearchId);
            }
        } else {
            // Smooth progressive rendering for subsequent sections without UI stutter
            progressiveQueue.push(...items);
            scheduleNextChunk(targetSearchId);
        }
    }

    function buildCardElement(item) {
        const card = document.createElement("div");
            card.className = "studio-card";

            const sourceClean = formatSourceLabel(item.source);
            const durBadge = item.durationString ? `<span class="studio-badge-dur">${item.durationString}</span>` : "";

            let previewHtml = "";

            if (item.type === "audio") {
                const isYtAudio = item.source === "youtube" || (item.id && item.id.startsWith("yt_")) || !!item.videoId;
                const ytVidId = item.videoId || (isYtAudio ? (item.id || "").replace("yt_", "") : "");

                if (item.thumbnail) {
                    // Audio item with visual video cover (e.g. YouTube audio, Jamendo)
                    previewHtml = `
                        <div class="studio-card-preview" data-card-id="${item.id}">
                            <button class="studio-thumb-link-btn" title="Open in Link Downloader to trim or custom format">
                                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path></svg>
                            </button>
                            <button class="studio-thumb-zoom-btn" title="Expand Preview (Mid-screen / Fullscreen)">
                                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 3 21 3 21 9"></polyline><polyline points="9 21 3 21 3 15"></polyline><line x1="21" y1="3" x2="14" y2="10"></line><line x1="3" y1="21" x2="10" y2="14"></line></svg>
                            </button>
                            <span class="studio-badge-source">${sourceClean}</span>
                            ${durBadge}
                            <img class="studio-card-thumb" src="${item.thumbnail}" alt="${item.title}" loading="lazy" decoding="async" />
                            <div class="studio-thumb-overlay"></div>
                            <div class="studio-video-player-container"></div>
                            <div class="studio-audio-center-action">
                                <button class="studio-audio-play-btn" data-audio-url="${item.audioPreviewUrl || ''}" data-video-id="${ytVidId}" title="Play Audio Preview">
                                    <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>
                                </button>
                            </div>
                        </div>
                    `;
                } else {
                    // Audio item without thumbnail (e.g. FreeSound SFX) -> Clean waveform graphic
                    previewHtml = `
                        <div class="studio-card-preview" data-card-id="${item.id}">
                            <button class="studio-thumb-link-btn" title="Open in Link Downloader to trim or custom format">
                                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path></svg>
                            </button>
                            <button class="studio-thumb-zoom-btn" title="Expand Preview (Mid-screen / Fullscreen)">
                                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 3 21 3 21 9"></polyline><polyline points="9 21 3 21 3 15"></polyline><line x1="21" y1="3" x2="14" y2="10"></line><line x1="3" y1="21" x2="10" y2="14"></line></svg>
                            </button>
                            <span class="studio-badge-source">${sourceClean}</span>
                            ${durBadge}
                            <div class="studio-waveform-cover">
                                <svg class="studio-waveform-svg" viewBox="0 0 100 40" preserveAspectRatio="none">
                                    <rect x="5" y="14" width="3" height="12" rx="1.5" fill="rgba(255,255,255,0.2)"/>
                                    <rect x="12" y="8" width="3" height="24" rx="1.5" fill="rgba(255,255,255,0.25)"/>
                                    <rect x="19" y="12" width="3" height="16" rx="1.5" fill="rgba(255,255,255,0.2)"/>
                                    <rect x="26" y="5" width="3" height="30" rx="1.5" fill="rgba(20,115,230,0.5)"/>
                                    <rect x="33" y="10" width="3" height="20" rx="1.5" fill="rgba(255,255,255,0.2)"/>
                                    <rect x="40" y="15" width="3" height="10" rx="1.5" fill="rgba(255,255,255,0.2)"/>
                                    <rect x="47" y="3" width="3" height="34" rx="1.5" fill="rgba(0,209,178,0.5)"/>
                                    <rect x="54" y="9" width="3" height="22" rx="1.5" fill="rgba(255,255,255,0.25)"/>
                                    <rect x="61" y="13" width="3" height="14" rx="1.5" fill="rgba(255,255,255,0.2)"/>
                                    <rect x="68" y="7" width="3" height="26" rx="1.5" fill="rgba(20,115,230,0.5)"/>
                                    <rect x="75" y="12" width="3" height="16" rx="1.5" fill="rgba(255,255,255,0.2)"/>
                                    <rect x="82" y="8" width="3" height="24" rx="1.5" fill="rgba(255,255,255,0.25)"/>
                                    <rect x="89" y="14" width="3" height="12" rx="1.5" fill="rgba(255,255,255,0.2)"/>
                                </svg>
                                <div class="studio-audio-center-action">
                                    <button class="studio-audio-play-btn" data-audio-url="${item.audioPreviewUrl || ''}" data-video-id="${ytVidId}" title="Play Audio Preview">
                                        <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>
                                    </button>
                                </div>
                            </div>
                        </div>
                    `;
                }
            } else {
                // Video & Photo Cards
                const isVideo = item.type === "video";
                const playOverlay = isVideo ? `
                    <button class="studio-video-play-btn" title="Watch Video Preview">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>
                    </button>
                ` : "";

                previewHtml = `
                    <div class="studio-card-preview" data-card-id="${item.id}">
                        <button class="studio-thumb-link-btn" title="Open in Link Downloader to trim or custom format">
                            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path></svg>
                        </button>
                        <button class="studio-thumb-zoom-btn" title="Expand Preview (Mid-screen / Fullscreen)">
                            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 3 21 3 21 9"></polyline><polyline points="9 21 3 21 3 15"></polyline><line x1="21" y1="3" x2="14" y2="10"></line><line x1="3" y1="21" x2="10" y2="14"></line></svg>
                        </button>
                        <span class="studio-badge-source">${sourceClean}</span>
                        ${durBadge}
                        <img class="studio-card-thumb" src="${item.thumbnail}" alt="${item.title}" loading="lazy" decoding="async" />
                        <div class="studio-video-player-container"></div>
                        ${playOverlay}
                    </div>
                `;
            }

            let optionsHtml = "";
            (item.downloadFormats || []).forEach((f, idx) => {
                optionsHtml += `<option value="${idx}">${f.label}</option>`;
            });

            card.innerHTML = `
                ${previewHtml}
                <div class="studio-card-info">
                    <div class="studio-card-title" title="${item.title}">${item.title}</div>
                    <div class="studio-card-meta">${item.author || "Creator"}</div>
                    <div class="studio-card-actions">
                        <select class="studio-format-select">
                            ${optionsHtml}
                        </select>
                        <button class="studio-btn-import" title="Download and import to timeline">
                            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
                            <span>Import</span>
                        </button>
                    </div>
                </div>
            `;

            // Zoom Button Listener -> Opens Theater Preview (Mid-Screen / Fullscreen)
            const zoomBtn = card.querySelector(".studio-thumb-zoom-btn");
            if (zoomBtn) {
                zoomBtn.addEventListener("click", (e) => {
                    e.stopPropagation();
                    openTheaterPreview(item);
                });
            }

            // Video Play / Pause Button Listener (Inline Responsive Preview with Auto Fade-Out)
            const videoPlayBtn = card.querySelector(".studio-video-play-btn");
            const previewContainer = card.querySelector(".studio-card-preview");
            const playerBox = card.querySelector(".studio-video-player-container");

            if (videoPlayBtn && previewContainer && playerBox) {
                // Mouse movements over card bring back play button and restart fade timer
                previewContainer.addEventListener("mousemove", () => {
                    if (activeVideoPreview && activeVideoPreview.card === card) {
                        showPlayButton();
                    }
                });

                previewContainer.addEventListener("mouseenter", () => {
                    if (activeVideoPreview && activeVideoPreview.card === card) {
                        showPlayButton();
                    }
                });

                previewContainer.addEventListener("mouseleave", () => {
                    if (activeVideoPreview && activeVideoPreview.card === card && activeVideoPreview.isPlaying) {
                        if (fadeTimer) clearTimeout(fadeTimer);
                        fadeTimer = setTimeout(() => {
                            if (activeVideoPreview && activeVideoPreview.playBtn) {
                                activeVideoPreview.playBtn.classList.add("faded");
                            }
                        }, 400);
                    }
                });

                videoPlayBtn.addEventListener("click", (e) => {
                    e.stopPropagation();

                    // If this exact card is already active:
                    if (activeVideoPreview && activeVideoPreview.card === card) {
                        if (activeVideoPreview.isPlaying) {
                            pauseActiveVideo();
                        } else {
                            resumeActiveVideo();
                        }
                        return;
                    }

                    // Otherwise, stop any previously active video preview
                    stopActiveVideoPreview();

                    // Stop global audio preview if playing
                    if (!globalAudio.paused) {
                        globalAudio.pause();
                        if (currentPlayBtn) {
                            currentPlayBtn.innerHTML = `<svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>`;
                            currentPlayBtn = null;
                        }
                    }

                    // Mount video on THIS card
                    playerBox.style.display = "block";
                    playerBox.innerHTML = "";

                    const isYouTube = item.source === "youtube" || (item.id && item.id.startsWith("yt_")) || !!item.videoId;

                    if (isYouTube) {
                        const vidId = item.videoId || item.id.replace("yt_", "");
                        const iframe = document.createElement("iframe");
                        iframe.className = "studio-card-iframe";
                        iframe.src = getYouTubePlayerUrl(vidId);
                        iframe.allow = "autoplay; encrypted-media";
                        iframe.setAttribute("frameborder", "0");
                        iframe.setAttribute("referrerpolicy", "strict-origin-when-cross-origin");
                        playerBox.appendChild(iframe);

                        activeVideoPreview = {
                            card: card,
                            playBtn: videoPlayBtn,
                            container: playerBox,
                            type: "youtube",
                            iframe: iframe,
                            isPlaying: true
                        };
                    } else {
                        // Wikimedia / Direct Video file
                        // Pick 480p or lowest bandwidth format for instant loading
                        let srcUrl = item.hoverPreviewUrl;
                        if (item.downloadFormats && item.downloadFormats.length > 0) {
                            const sd = item.downloadFormats.find(f => (f.height && f.height <= 480) || (f.label && (f.label.includes("480") || f.label.includes("360") || f.label.includes("SD"))));
                            if (sd && sd.url) srcUrl = sd.url;
                            else if (item.downloadFormats[0].url) srcUrl = item.downloadFormats[0].url;
                        }

                        const vid = document.createElement("video");
                        vid.className = "studio-card-html5-video";
                        vid.src = srcUrl || item.pageUrl;
                        vid.autoplay = true;
                        vid.playsInline = true;
                        vid.volume = 0.8;
                        vid.addEventListener("ended", () => {
                            stopActiveVideoPreview();
                        });
                        playerBox.appendChild(vid);

                        activeVideoPreview = {
                            card: card,
                            playBtn: videoPlayBtn,
                            container: playerBox,
                            type: "html5",
                            video: vid,
                            isPlaying: true
                        };
                    }

                    // Update button icon to Pause
                    videoPlayBtn.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16"></rect><rect x="14" y="4" width="4" height="16"></rect></svg>`;
                    videoPlayBtn.classList.add("playing");
                    videoPlayBtn.classList.remove("faded");
                    videoPlayBtn.title = "Pause Video Preview";

                    scheduleFadeOut();
                });
            }

            // Audio Play Button Listener
            if (item.type === "audio") {
                const playBtn = card.querySelector(".studio-audio-play-btn");
                const previewContainer = card.querySelector(".studio-card-preview");
                const playerBox = card.querySelector(".studio-video-player-container");

                if (playBtn) {
                    if (previewContainer) {
                        previewContainer.addEventListener("mousemove", () => {
                            if (activeVideoPreview && activeVideoPreview.card === card) {
                                showPlayButton();
                            }
                        });
                        previewContainer.addEventListener("mouseenter", () => {
                            if (activeVideoPreview && activeVideoPreview.card === card) {
                                showPlayButton();
                            }
                        });
                        previewContainer.addEventListener("mouseleave", () => {
                            if (activeVideoPreview && activeVideoPreview.card === card && activeVideoPreview.isPlaying) {
                                if (fadeTimer) clearTimeout(fadeTimer);
                                fadeTimer = setTimeout(() => {
                                    if (activeVideoPreview && activeVideoPreview.playBtn) {
                                        activeVideoPreview.playBtn.classList.add("faded");
                                    }
                                }, 600);
                            }
                        });
                    }

                    playBtn.addEventListener("click", (e) => {
                        e.stopPropagation();
                        const audioUrl = playBtn.dataset.audioUrl;
                        const ytVidId = playBtn.dataset.videoId;

                        // Case 1: YouTube Audio item (plays via embedded player with full sound)
                        if (ytVidId) {
                            if (activeVideoPreview && activeVideoPreview.card === card) {
                                if (activeVideoPreview.isPlaying) {
                                    pauseActiveVideo();
                                } else {
                                    resumeActiveVideo();
                                }
                                return;
                            }

                            stopActiveVideoPreview();
                            if (!globalAudio.paused) {
                                globalAudio.pause();
                                if (currentPlayBtn) {
                                    currentPlayBtn.innerHTML = `<svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>`;
                                    currentPlayBtn = null;
                                }
                            }

                            if (playerBox) {
                                playerBox.style.display = "block";
                                playerBox.innerHTML = "";
                                const iframe = document.createElement("iframe");
                                iframe.className = "studio-card-iframe";
                                iframe.src = getYouTubePlayerUrl(ytVidId);
                                iframe.allow = "autoplay; encrypted-media";
                                iframe.setAttribute("frameborder", "0");
                                iframe.setAttribute("referrerpolicy", "strict-origin-when-cross-origin");
                                playerBox.appendChild(iframe);

                                activeVideoPreview = {
                                    card: card,
                                    playBtn: playBtn,
                                    container: playerBox,
                                    type: "youtube",
                                    iframe: iframe,
                                    isPlaying: true
                                };

                                playBtn.innerHTML = `<svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16"></rect><rect x="14" y="4" width="4" height="16"></rect></svg>`;
                                playBtn.classList.add("playing");
                                playBtn.classList.remove("faded");
                                playBtn.title = "Pause Audio Preview";
                                scheduleFadeOut();
                            }
                            return;
                        }

                        // Case 2: Jamendo / FreeSound direct audio file stream
                        if (!audioUrl) {
                            handleSendToLinkDownloader(e);
                            return;
                        }

                        stopActiveVideoPreview();

                        if (currentPlayBtn === playBtn && !globalAudio.paused) {
                            globalAudio.pause();
                            playBtn.innerHTML = `<svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>`;
                            currentPlayBtn = null;
                        } else {
                            if (currentPlayBtn) {
                                currentPlayBtn.innerHTML = `<svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>`;
                            }
                            globalAudio.src = audioUrl;
                            globalAudio.play().catch(() => {});
                            playBtn.innerHTML = `<svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16"></rect><rect x="14" y="4" width="4" height="16"></rect></svg>`;
                            currentPlayBtn = playBtn;
                        }
                    });
                }
            }

            // Send Link to Link Downloader (Autofill URL & Open Timeline Trimmer)
            const thumbLinkBtn = card.querySelector(".studio-thumb-link-btn");

            const handleSendToLinkDownloader = (e) => {
                if (e) {
                    try { e.preventDefault(); e.stopPropagation(); } catch (_) {}
                }
                const targetUrl = item.pageUrl || item.sourceUrl || (item.downloadFormats && item.downloadFormats[0]?.sourceUrl) || (item.id && item.id.startsWith("yt_") ? `https://www.youtube.com/watch?v=${item.id.replace("yt_", "")}` : "");
                if (!targetUrl) return;

                // 1. Switch active view to Link Downloader
                const modeBtnDownload = document.getElementById("mode-btn-download");
                if (modeBtnDownload) {
                    modeBtnDownload.click();
                }

                // 2. Autofill URL input field
                const urlInput = document.getElementById("url-input");
                if (urlInput) {
                    urlInput.value = targetUrl;
                    urlInput.dispatchEvent(new Event("input", { bubbles: true }));
                    urlInput.dispatchEvent(new Event("change", { bubbles: true }));
                    urlInput.focus();
                }

                // 3. Open the Trim Time Range panel so user can immediately trim
                const trimPanel = document.getElementById("trim-inputs-panel");
                const trimArrow = document.getElementById("trim-toggle-arrow");
                if (trimPanel) {
                    trimPanel.style.display = "flex";
                    if (trimArrow) trimArrow.textContent = "▼";
                }

                // 4. Auto-trigger Analyze so metadata and duration load
                const btnAnalyze = document.getElementById("btn-analyze");
                if (btnAnalyze) {
                    setTimeout(() => {
                        btnAnalyze.click();
                    }, 120);
                }
            };

            if (thumbLinkBtn) thumbLinkBtn.addEventListener("click", handleSendToLinkDownloader);

            // Download & Import to Adobe Host
            const importBtn = card.querySelector(".studio-btn-import");
            const formatSelect = card.querySelector(".studio-format-select");

            importBtn.addEventListener("click", async () => {
                if (importBtn.classList.contains("downloading")) return;
                if (typeof stopActiveVideoPreview === "function") stopActiveVideoPreview();
                if (typeof globalAudio !== "undefined" && globalAudio && !globalAudio.paused) globalAudio.pause();

                const selectedIdx = parseInt(formatSelect.value, 10) || 0;
                const selectedFormat = item.downloadFormats[selectedIdx] || item.downloadFormats[0];

                importBtn.classList.add("downloading");
                const labelSpan = importBtn.querySelector("span");
                labelSpan.textContent = "0%";

                try {
                    await Downloader.downloadAndImport(item, selectedFormat, csInterface, (pct) => {
                        labelSpan.textContent = `${pct}%`;
                    });

                    importBtn.classList.remove("downloading");
                    importBtn.classList.add("imported");
                    importBtn.innerHTML = `<span>✓ Added</span>`;
                } catch (err) {
                    importBtn.classList.remove("downloading");
                    labelSpan.textContent = "Import";
                    console.error("Download failed:", err);
                    const errMsg = (err && err.message) ? err.message : String(err);
                    if (errMsg.includes("Sign in to confirm") || errMsg.includes("bot")) {
                        alert("YouTube Anti-Bot Challenge: Opening in Link Downloader or syncing browser cookies in Settings will resolve restricted videos.");
                    } else {
                        alert("Download Notice: " + errMsg.substring(0, 150));
                    }
                }
            });

            return card;
    }

    function openTheaterPreview(item) {
        if (!item) return;

        // 1. Immediately pause and kill any mini size card preview running anywhere in the search grid
        if (activeVideoPreview) {
            if (activeVideoPreview.type === "youtube" && activeVideoPreview.iframe) {
                try {
                    activeVideoPreview.iframe.contentWindow.postMessage('{"event":"command","func":"pauseVideo","args":""}', '*');
                } catch (_) {}
            }
            stopActiveVideoPreview();
        }
        if (typeof globalAudio !== "undefined" && globalAudio && !globalAudio.paused) {
            globalAudio.pause();
            if (typeof currentPlayBtn !== "undefined" && currentPlayBtn) {
                currentPlayBtn.innerHTML = `<svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>`;
                currentPlayBtn = null;
            }
        }
        try {
            document.querySelectorAll(".studio-card-preview iframe, .studio-video-player-container iframe").forEach(iframe => {
                try { iframe.contentWindow.postMessage('{"event":"command","func":"pauseVideo","args":""}', '*'); } catch (_) {}
                try { iframe.remove(); } catch (_) {}
            });
            document.querySelectorAll(".studio-card-html5-video, .studio-card-preview video").forEach(v => {
                try { v.pause(); v.removeAttribute("src"); v.remove(); } catch (_) {}
            });
            document.querySelectorAll(".studio-video-player-container").forEach(c => {
                c.style.display = "none";
                c.innerHTML = "";
            });
            document.querySelectorAll(".studio-video-play-btn, .studio-audio-play-btn").forEach(btn => {
                const isAudio = btn.classList.contains("studio-audio-play-btn");
                const sz = isAudio ? 13 : 14;
                btn.innerHTML = `<svg width="${sz}" height="${sz}" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>`;
                btn.classList.remove("playing", "faded");
                btn.title = isAudio ? "Play Audio Preview" : "Play Video Preview";
            });
        } catch (_) {}

        const overlay = document.getElementById("modal-theater-preview");
        const container = document.getElementById("theater-modal-container");
        const titleEl = document.getElementById("theater-preview-title");
        const authorEl = document.getElementById("theater-preview-author");
        const badgeEl = document.getElementById("theater-badge-source");
        const videoEl = document.getElementById("theater-preview-video");
        const imgEl = document.getElementById("theater-preview-img");
        const iframeMount = document.getElementById("theater-iframe-container");
        const formatSelect = document.getElementById("theater-format-select");
        const btnImport = document.getElementById("btn-theater-import");
        const btnDownloader = document.getElementById("btn-theater-open-downloader");

        if (!overlay || !container) return;

        // Reset to mid-screen stage by default (covers ~75-80% screen, showing AE/Pr project behind dimmed backdrop)
        container.classList.remove("fullscreen");
        container.classList.add("mid-screen");
        container.style.position = "";
        container.style.left = "";
        container.style.top = "";
        container.style.transform = "";

        if (userMidWidth && userMidHeight) {
            container.style.width = userMidWidth + "px";
            container.style.height = userMidHeight + "px";
        } else {
            container.style.width = "";
            container.style.height = "";
        }
        updateTheaterZoomIcons(false);

        // Update titles & labels
        if (titleEl) titleEl.textContent = item.title || "Media Preview";
        if (authorEl) authorEl.textContent = `${item.author || "Creator"} • ${formatSourceLabel(item.source)}`;
        if (badgeEl) badgeEl.textContent = (item.type || "VIDEO").toUpperCase();

        // Populate format select dropdown for switching video quality / formats
        if (formatSelect) {
            formatSelect.innerHTML = "";
            const formats = item.downloadFormats || [];
            if (formats.length > 0) {
                formats.forEach((f, idx) => {
                    const opt = document.createElement("option");
                    opt.value = idx;
                    opt.textContent = f.label || `${f.ext || "mp4"} (${f.quality || "Default"})`;
                    formatSelect.appendChild(opt);
                });
                formatSelect.style.display = "block";
                formatSelect.onchange = () => {
                    const selIdx = parseInt(formatSelect.value, 10) || 0;
                    const chosen = formats[selIdx];
                    if (chosen && chosen.url && videoEl && videoEl.style.display !== "none") {
                        const curTime = videoEl.currentTime || 0;
                        videoEl.src = chosen.url;
                        videoEl.currentTime = curTime;
                        videoEl.play().catch(() => {});
                    }
                };
            } else {
                formatSelect.style.display = "none";
            }
        }

        // Save active item and check for saved playback timeline position
        activeTheaterItem = item;
        let savedTime = 0;
        let vidId = item.videoId || (item.id && !String(item.id).startsWith("link_") ? String(item.id).replace("yt_", "") : "");
        if (!vidId || vidId.length > 25) {
            const urlToCheck = item.pageUrl || item.sourceUrl || "";
            const m = urlToCheck.match(/(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=|shorts\/))([a-zA-Z0-9_-]{11})/);
            if (m) vidId = m[1];
        }

        if (vidId) {
            if (playbackTimelineMemory.has(vidId)) savedTime = playbackTimelineMemory.get(vidId);
            else if (playbackTimelineMemory.has("yt_" + vidId)) savedTime = playbackTimelineMemory.get("yt_" + vidId);
            try {
                const ss = sessionStorage.getItem("mf_resume_" + vidId) || localStorage.getItem("mf_resume_" + vidId);
                if (ss && parseFloat(ss) > 0) savedTime = Math.max(savedTime, parseFloat(ss));
            } catch (_) {}
        }
        if (!savedTime && item.id) {
            if (playbackTimelineMemory.has(item.id)) savedTime = playbackTimelineMemory.get(item.id);
            try {
                const ss = sessionStorage.getItem("mf_resume_" + item.id) || localStorage.getItem("mf_resume_" + item.id);
                if (ss && parseFloat(ss) > 0) savedTime = Math.max(savedTime, parseFloat(ss));
            } catch (_) {}
        }

        const audioContainer = document.getElementById("theater-audio-container");
        const audioEl = document.getElementById("theater-preview-audio");
        const audioTitle = document.getElementById("theater-audio-title");
        const audioAuthor = document.getElementById("theater-audio-author");

        // Reset player displays
        if (videoEl) { videoEl.pause(); videoEl.src = ""; videoEl.style.display = "none"; }
        if (imgEl) { imgEl.src = ""; imgEl.style.display = "none"; }
        if (audioEl) { audioEl.pause(); audioEl.src = ""; }
        if (audioContainer) { audioContainer.style.display = "none"; }
        if (iframeMount) { iframeMount.innerHTML = ""; iframeMount.style.display = "none"; }

        const isPhoto = item.type === "photo" || item.type === "image";
        const isAudio = item.type === "audio";
        const isYouTube = item.source === "youtube" || 
                          (item.id && String(item.id).startsWith("yt_")) || 
                          !!item.videoId || 
                          (item.pageUrl && /youtu\.?be/i.test(item.pageUrl)) ||
                          (item.sourceUrl && /youtu\.?be/i.test(item.sourceUrl));

        if (isPhoto) {
            if (badgeEl) badgeEl.textContent = "PHOTO";
            if (imgEl) {
                imgEl.src = item.hoverPreviewUrl || item.thumbnail || (item.downloadFormats && item.downloadFormats[0]?.url) || "";
                imgEl.style.display = "block";
            }
        } else if (isAudio) {
            if (badgeEl) badgeEl.textContent = "AUDIO";
            if (audioContainer && audioEl) {
                audioContainer.style.display = "flex";
                if (audioTitle) audioTitle.textContent = item.title || "Audio Track";
                if (audioAuthor) audioAuthor.textContent = `${item.author || "Artist"} • ${formatSourceLabel(item.source)}`;
                let audioUrl = item.hoverPreviewUrl;
                if (item.downloadFormats && item.downloadFormats.length > 0) {
                    const chosen = item.downloadFormats.find(f => f.url);
                    if (chosen) audioUrl = chosen.url;
                }
                audioEl.src = audioUrl || item.pageUrl || item.sourceUrl || "";
                if (savedTime > 0) {
                    const onAudioSeekReady = () => {
                        try { audioEl.currentTime = savedTime; } catch (_) {}
                        audioEl.removeEventListener("loadedmetadata", onAudioSeekReady);
                        audioEl.removeEventListener("canplay", onAudioSeekReady);
                    };
                    audioEl.addEventListener("loadedmetadata", onAudioSeekReady);
                    audioEl.addEventListener("canplay", onAudioSeekReady);
                }
                audioEl.ontimeupdate = () => {
                    if (audioEl.currentTime > 0 && activeTheaterItem && activeTheaterItem.id) {
                        recordPlaybackTimeline(activeTheaterItem.id, audioEl.currentTime);
                    }
                };
                audioEl.play().catch(() => {});
            }
        } else if (isYouTube) {
            if (badgeEl) badgeEl.textContent = "YOUTUBE";
            const defaultEngine = localStorage.getItem("mf_default_player_engine") || "embed";
            const defaultQuality = localStorage.getItem("mf_default_stream_quality") || "720";

            const loadDirectStream = async (targetQuality) => {
                const q = targetQuality || localStorage.getItem("mf_default_stream_quality") || "720";
                if (iframeMount) { iframeMount.innerHTML = ""; iframeMount.style.display = "none"; }
                if (videoEl) {
                    videoEl.style.display = "block";
                    videoEl.poster = item.thumbnail || "";
                    try {
                        const res = await fetch(`http://127.0.0.1:48924/api/stream-url?v=${encodeURIComponent(vidId)}&quality=${encodeURIComponent(q)}`);
                        const data = await res.json();
                        if (data && data.success && data.streamUrl) {
                            videoEl.src = data.streamUrl;
                            if (savedTime > 0) {
                                const onCanPlay = () => {
                                    try { videoEl.currentTime = savedTime; } catch (_) {}
                                    videoEl.removeEventListener("canplay", onCanPlay);
                                };
                                videoEl.addEventListener("canplay", onCanPlay);
                            }
                            videoEl.ontimeupdate = () => {
                                if (videoEl.currentTime > 0 && activeTheaterItem && activeTheaterItem.id) {
                                    recordPlaybackTimeline(activeTheaterItem.id, videoEl.currentTime);
                                }
                            };
                            videoEl.play().catch(() => {});
                        }
                    } catch (e) {
                        console.warn("Failed to load direct stream:", e);
                    }
                }
            };

            const loadStandardEmbed = () => {
                if (videoEl) { videoEl.pause(); videoEl.src = ""; videoEl.style.display = "none"; }
                if (iframeMount && vidId) {
                    iframeMount.style.display = "block";
                    iframeMount.innerHTML = "";
                    const iframe = document.createElement("iframe");
                    iframe.style.width = "100%";
                    iframe.style.height = "100%";
                    iframe.style.border = "none";
                    iframe.allow = "autoplay; encrypted-media; picture-in-picture";
                    iframe.setAttribute("frameborder", "0");
                    iframe.setAttribute("referrerpolicy", "strict-origin-when-cross-origin");
                    iframe.src = getYouTubePlayerUrl(vidId, Math.floor(savedTime), defaultQuality);
                    iframeMount.appendChild(iframe);
                }
            };

            if (formatSelect) {
                formatSelect.innerHTML = "";
                const optEmbed = document.createElement("option");
                optEmbed.value = "embed";
                optEmbed.textContent = "Standard Player";
                formatSelect.appendChild(optEmbed);

                const qualities = [
                    { value: "direct-1080", label: "Direct Stream (1080p)" },
                    { value: "direct-720", label: "Direct Stream (720p HD)" },
                    { value: "direct-480", label: "Direct Stream (480p)" },
                    { value: "direct-360", label: "Direct Stream (360p)" }
                ];

                qualities.forEach(qOpt => {
                    const opt = document.createElement("option");
                    opt.value = qOpt.value;
                    opt.textContent = qOpt.label;
                    formatSelect.appendChild(opt);
                });

                formatSelect.style.display = "block";

                formatSelect.onchange = () => {
                    const val = formatSelect.value;
                    if (val.startsWith("direct-")) {
                        const targetQ = val.replace("direct-", "");
                        loadDirectStream(targetQ);
                    } else {
                        loadStandardEmbed();
                    }
                };

                if (defaultEngine === "direct") {
                    formatSelect.value = "direct-" + defaultQuality;
                    loadDirectStream(defaultQuality);
                } else {
                    formatSelect.value = "embed";
                    loadStandardEmbed();
                }
            } else {
                if (defaultEngine === "direct") {
                    loadDirectStream(defaultQuality);
                } else {
                    loadStandardEmbed();
                }
            }
        } else {
            if (badgeEl) badgeEl.textContent = "VIDEO";
            // HTML5 video (Wikimedia, Pexels, Pixabay, TikTok, Instagram, Direct Web URLs)
            let streamUrl = item.hoverPreviewUrl;
            if (item.downloadFormats && item.downloadFormats.length > 0) {
                const hq = item.downloadFormats.find(f => f.url && (f.quality === "1080" || f.quality === "720" || (f.label && (f.label.includes("1080") || f.label.includes("720")))));
                if (hq && hq.url) streamUrl = hq.url;
                else {
                    const anyPlayable = item.downloadFormats.find(f => f.url && (f.ext === "mp4" || f.ext === "webm" || (f.type && f.type.includes("video"))));
                    if (anyPlayable && anyPlayable.url) streamUrl = anyPlayable.url;
                    else if (item.downloadFormats[0].url) streamUrl = item.downloadFormats[0].url;
                }
            }
            const isDirectFile = streamUrl && /\.(mp4|webm|m3u8|mov|ogg)($|\?)/i.test(streamUrl);
            if (videoEl) {
                videoEl.style.display = "block";
                if (isDirectFile) {
                    videoEl.src = streamUrl;
                    videoEl.play().catch(() => {});
                } else {
                    const targetU = item.pageUrl || item.sourceUrl || item.url || streamUrl;
                    if (targetU) {
                        fetch(`http://127.0.0.1:48924/api/stream-url?v=${encodeURIComponent(targetU)}`)
                            .then(r => r.json())
                            .then(data => {
                                if (data && data.success && data.streamUrl && videoEl) {
                                    videoEl.src = data.streamUrl;
                                    videoEl.play().catch(() => {});
                                }
                            })
                            .catch(() => {
                                if (streamUrl) videoEl.src = streamUrl;
                            });
                    } else if (streamUrl) {
                        videoEl.src = streamUrl;
                    }
                }
                if (savedTime > 0) {
                    const onSeekReady = () => {
                        try { videoEl.currentTime = savedTime; } catch (_) {}
                        videoEl.removeEventListener("loadedmetadata", onSeekReady);
                        videoEl.removeEventListener("canplay", onSeekReady);
                    };
                    videoEl.addEventListener("loadedmetadata", onSeekReady);
                    videoEl.addEventListener("canplay", onSeekReady);
                }
                videoEl.ontimeupdate = () => {
                    if (videoEl.currentTime > 0 && activeTheaterItem && activeTheaterItem.id) {
                        recordPlaybackTimeline(activeTheaterItem.id, videoEl.currentTime);
                    }
                };
            }
        }

        // Wire Action Buttons in modal
        if (btnDownloader) {
            btnDownloader.onclick = () => {
                closeTheaterPreview();
                const targetUrl = item.pageUrl || item.sourceUrl || (item.downloadFormats && item.downloadFormats[0]?.sourceUrl) || (item.id && String(item.id).startsWith("yt_") ? `https://www.youtube.com/watch?v=${item.id.replace("yt_", "")}` : "");
                if (targetUrl) {
                    const modeBtnDownload = document.getElementById("mode-btn-download");
                    if (modeBtnDownload) modeBtnDownload.click();
                    const urlInput = document.getElementById("url-input");
                    if (urlInput) {
                        urlInput.value = targetUrl;
                        urlInput.dispatchEvent(new Event("input", { bubbles: true }));
                        urlInput.focus();
                    }
                }
            };
        }

        if (btnImport) {
            btnImport.onclick = async () => {
                const formats = item.downloadFormats || [];
                const selIdx = formatSelect ? (parseInt(formatSelect.value, 10) || 0) : 0;
                const format = formats[selIdx] || formats[0];
                closeTheaterPreview();
                if (format && typeof Downloader !== "undefined") {
                    try {
                        await Downloader.downloadAndImport(item, format, csInterface, () => {});
                    } catch (err) {
                        console.error("Theater import error:", err);
                    }
                }
            };
        }

        // Show overlay with dark dim background
        overlay.classList.add("active");
    }

    function isCurrentFullscreen() {
        const container = document.getElementById("theater-modal-container");
        return !!(container && container.classList.contains("fullscreen"));
    }

    function toggleTheaterFullscreen() {
        const container = document.getElementById("theater-modal-container");
        const overlay = document.getElementById("modal-theater-preview");
        if (!container || !overlay) return;

        const isFull = isCurrentFullscreen();

        if (isFull) {
            // Exit Fullscreen -> Return to Mid-Screen (Pure CSS - zero CEF window lockup)
            container.classList.remove("fullscreen");
            container.classList.add("mid-screen");
            container.style.position = "";
            container.style.left = "";
            container.style.top = "";
            container.style.transform = "";

            if (userMidWidth && userMidHeight && userMidWidth < window.innerWidth && userMidHeight < window.innerHeight) {
                container.style.width = userMidWidth + "px";
                container.style.height = userMidHeight + "px";
            } else {
                container.style.width = "";
                container.style.height = "";
            }
            updateTheaterZoomIcons(false);
        } else {
            // Enter Fullscreen: Save current mid-screen size before going fullscreen
            const rect = container.getBoundingClientRect();
            if (rect.width > 120 && rect.width < window.innerWidth && rect.height > 100 && rect.height < window.innerHeight) {
                userMidWidth = rect.width;
                userMidHeight = rect.height;
            }

            container.classList.remove("mid-screen");
            container.classList.add("fullscreen");
            container.style.width = "100vw";
            container.style.height = "100vh";
            container.style.position = "fixed";
            container.style.left = "0";
            container.style.top = "0";
            container.style.transform = "none";
            updateTheaterZoomIcons(true);
        }
    }

    function updateTheaterZoomIcons(isFullscreen) {
        const iconExpand = document.getElementById("theater-zoom-icon-expand");
        const iconCompress = document.getElementById("theater-zoom-icon-compress");
        const cornerExpand = document.getElementById("theater-corner-icon-expand");
        const cornerCompress = document.getElementById("theater-corner-icon-compress");
        const cornerBtn = document.getElementById("btn-theater-corner-fullscreen");

        if (iconExpand && iconCompress) {
            iconExpand.style.display = isFullscreen ? "none" : "inline-block";
            iconCompress.style.display = isFullscreen ? "inline-block" : "none";
        }
        if (cornerExpand && cornerCompress) {
            cornerExpand.style.display = isFullscreen ? "none" : "inline-block";
            cornerCompress.style.display = isFullscreen ? "inline-block" : "none";
        }
        if (cornerBtn) {
            cornerBtn.title = isFullscreen ? "Exit Fullscreen (Return to Mid-Screen)" : "Toggle Fullscreen";
        }
    }

    function closeTheaterPreview() {
        const overlay = document.getElementById("modal-theater-preview");
        const container = document.getElementById("theater-modal-container");
        const videoEl = document.getElementById("theater-preview-video");
        const audioEl = document.getElementById("theater-preview-audio");
        const audioContainer = document.getElementById("theater-audio-container");
        const imgEl = document.getElementById("theater-preview-img");
        const iframeMount = document.getElementById("theater-iframe-container");

        // Preserve current playback time in memory before unmounting
        if (videoEl && activeTheaterItem && activeTheaterItem.id && videoEl.currentTime > 0) {
            recordPlaybackTimeline(activeTheaterItem.id, videoEl.currentTime);
        }
        if (audioEl && activeTheaterItem && activeTheaterItem.id && audioEl.currentTime > 0) {
            recordPlaybackTimeline(activeTheaterItem.id, audioEl.currentTime);
        }

        if (container) {
            container.classList.remove("fullscreen");
            container.classList.add("mid-screen");
            container.style.position = "";
            container.style.left = "";
            container.style.top = "";
            container.style.transform = "";
            updateTheaterZoomIcons(false);
        }

        if (document.fullscreenElement || document.webkitFullscreenElement) {
            try {
                if (document.exitFullscreen) document.exitFullscreen();
                else if (document.webkitExitFullscreen) document.webkitExitFullscreen();
            } catch (_) {}
        }

        // Instant hardware video decoder & audio release without UI freeze
        if (videoEl) {
            videoEl.pause();
            videoEl.removeAttribute("src");
            videoEl.load();
            videoEl.style.display = "none";
        }
        if (audioEl) {
            audioEl.pause();
            audioEl.removeAttribute("src");
            audioEl.load();
        }
        if (audioContainer) {
            audioContainer.style.display = "none";
        }
        if (imgEl) {
            imgEl.src = "";
            imgEl.style.display = "none";
        }
        if (iframeMount) {
            const iframes = iframeMount.querySelectorAll("iframe");
            iframes.forEach(f => {
                try { f.src = "about:blank"; } catch (_) {}
                try { f.remove(); } catch (_) {}
            });
            iframeMount.innerHTML = "";
            iframeMount.style.display = "none";
        }
        if (overlay) {
            overlay.classList.remove("active");
        }
        if (typeof window !== "undefined" && typeof window.triggerMemoryCleanup === "function") {
            window.triggerMemoryCleanup();
        }
    }

    function bindTheaterModal() {
        const overlay = document.getElementById("modal-theater-preview");
        const container = document.getElementById("theater-modal-container");
        const btnClose = document.getElementById("btn-theater-close");
        const btnZoom = document.getElementById("btn-theater-zoom-toggle");
        const btnCornerToggle = document.getElementById("btn-theater-corner-fullscreen");
        const btnCornerClose = document.getElementById("btn-theater-corner-close");
        const btnFloatingCompress = document.getElementById("btn-floating-compress");
        const btnFloatingClose = document.getElementById("btn-floating-close");
        const shield = document.getElementById("theater-drag-shield");
        const header = container ? container.querySelector(".theater-header") : null;
        const resizers = container ? container.querySelectorAll(".theater-resizer") : [];

        // Fullscreen Toggle in modal header
        if (btnZoom) {
            btnZoom.addEventListener("click", (e) => {
                e.stopPropagation();
                toggleTheaterFullscreen();
            });
        }

        // Bottom-Right Corner Fullscreen / Mid-Screen Toggle Button (Direct fix for cyan box interaction)
        if (btnCornerToggle) {
            btnCornerToggle.addEventListener("click", (e) => {
                e.stopPropagation();
                toggleTheaterFullscreen();
            });
        }

        // Bottom-Right Corner Close Button
        if (btnCornerClose) {
            btnCornerClose.addEventListener("click", (e) => {
                e.stopPropagation();
                closeTheaterPreview();
            });
        }

        // Floating controls (visible when player covers header in fullscreen)
        if (btnFloatingCompress) {
            btnFloatingCompress.addEventListener("click", (e) => {
                e.stopPropagation();
                toggleTheaterFullscreen();
            });
        }
        if (btnFloatingClose) {
            btnFloatingClose.addEventListener("click", (e) => {
                e.stopPropagation();
                closeTheaterPreview();
            });
        }

        // Fullscreen state listener
        const onFullscreenChange = () => {
            const isFull = !!(document.fullscreenElement || document.webkitFullscreenElement);
            if (!container) return;
            if (isFull) {
                container.classList.remove("mid-screen");
                container.classList.add("fullscreen");
                container.style.width = "100vw";
                container.style.height = "100vh";
                container.style.position = "fixed";
                container.style.left = "0";
                container.style.top = "0";
                container.style.transform = "none";
                updateTheaterZoomIcons(true);
            } else if (!isFull && container.classList.contains("fullscreen")) {
                container.classList.remove("fullscreen");
                container.classList.add("mid-screen");
                container.style.position = "";
                container.style.left = "";
                container.style.top = "";
                container.style.transform = "";
                if (userMidWidth && userMidHeight && userMidWidth < window.innerWidth && userMidHeight < window.innerHeight) {
                    container.style.width = userMidWidth + "px";
                    container.style.height = userMidHeight + "px";
                } else {
                    container.style.width = "";
                    container.style.height = "";
                }
                updateTheaterZoomIcons(false);
            }
        };
        document.addEventListener("fullscreenchange", onFullscreenChange);
        document.addEventListener("webkitfullscreenchange", onFullscreenChange);

        // Click outside container (on the dimmed black overlay backdrop) closes the preview instantly
        if (overlay) {
            overlay.addEventListener("click", (e) => {
                if (e.target === overlay) {
                    closeTheaterPreview();
                }
            });
        }

        if (btnClose) {
            btnClose.addEventListener("click", (e) => {
                e.stopPropagation();
                closeTheaterPreview();
            });
        }

        // 8-Directional Window Resizers for Mid-Screen
        let isResizing = false;
        let isDragging = false;
        let startX = 0, startY = 0;
        let startW = 0, startH = 0;
        let startLeft = 0, startTop = 0;
        let currentDir = "";

        resizers.forEach((resizer) => {
            resizer.addEventListener("mousedown", (e) => {
                if (container.classList.contains("fullscreen")) return;
                e.preventDefault();
                e.stopPropagation();

                isResizing = true;
                currentDir = resizer.dataset.dir || "";
                startX = e.clientX;
                startY = e.clientY;

                const rect = container.getBoundingClientRect();
                startW = rect.width;
                startH = rect.height;

                if (shield) {
                    shield.style.display = "block";
                    shield.style.cursor = window.getComputedStyle(resizer).cursor;
                }
                document.body.style.userSelect = "none";

                const onResizeMove = (moveEvt) => {
                    if (!isResizing) return;
                    moveEvt.preventDefault();

                    const dx = moveEvt.clientX - startX;
                    const dy = moveEvt.clientY - startY;

                    let newW = startW;
                    let newH = startH;

                    if (currentDir.includes("e")) newW = startW + dx;
                    if (currentDir.includes("w")) newW = startW - dx;
                    if (currentDir.includes("s")) newH = startH + dy;
                    if (currentDir.includes("n")) newH = startH - dy;

                    const minW = 320;
                    const minH = 200;
                    const maxW = window.innerWidth * 0.98;
                    const maxH = window.innerHeight * 0.98;

                    newW = Math.max(minW, Math.min(maxW, newW));
                    newH = Math.max(minH, Math.min(maxH, newH));

                    container.style.width = `${newW}px`;
                    container.style.height = `${newH}px`;
                    userMidWidth = newW;
                    userMidHeight = newH;
                };

                const onResizeUp = () => {
                    isResizing = false;
                    currentDir = "";
                    if (shield) shield.style.display = "none";
                    document.body.style.userSelect = "";
                    window.removeEventListener("mousemove", onResizeMove);
                    window.removeEventListener("mouseup", onResizeUp);
                };

                window.addEventListener("mousemove", onResizeMove);
                window.addEventListener("mouseup", onResizeUp);
            });
        });

        // Header Dragging for Repositioning Window
        if (header) {
            header.addEventListener("mousedown", (e) => {
                if (e.target.closest("button") || e.target.closest("select") || container.classList.contains("fullscreen")) {
                    return;
                }
                isDragging = true;
                startX = e.clientX;
                startY = e.clientY;

                const rect = container.getBoundingClientRect();
                startLeft = rect.left;
                startTop = rect.top;

                header.classList.add("dragging");
                if (shield) {
                    shield.style.display = "block";
                    shield.style.cursor = "grabbing";
                }
                document.body.style.userSelect = "none";

                container.style.position = "fixed";

                const onDragMove = (moveEvt) => {
                    if (!isDragging) return;
                    moveEvt.preventDefault();

                    const dx = moveEvt.clientX - startX;
                    const dy = moveEvt.clientY - startY;

                    const newLeft = Math.max(0, Math.min(window.innerWidth - 80, startLeft + dx));
                    const newTop = Math.max(0, Math.min(window.innerHeight - 40, startTop + dy));

                    container.style.left = `${newLeft}px`;
                    container.style.top = `${newTop}px`;
                    container.style.transform = "none";
                };

                const onDragUp = () => {
                    isDragging = false;
                    header.classList.remove("dragging");
                    if (shield) shield.style.display = "none";
                    document.body.style.userSelect = "";
                    window.removeEventListener("mousemove", onDragMove);
                    window.removeEventListener("mouseup", onDragUp);
                };

                window.addEventListener("mousemove", onDragMove);
                window.addEventListener("mouseup", onDragUp);
            });
        }
    }

    window.clearStudioMemoryCache = function() {
        const grid = document.getElementById("studio-results-grid");
        if (grid) {
            const imgs = grid.querySelectorAll("img");
            imgs.forEach(i => { try { i.src = ""; i.remove(); } catch (_) {} });
            grid.innerHTML = "";
        }
        renderedItemIds.clear();
        if (typeof window !== "undefined" && typeof window.gc === "function") {
            try { window.gc(); } catch (_) {}
        }
    };

    window.openTheaterPreview = openTheaterPreview;
    window.closeTheaterPreview = closeTheaterPreview;

    return {
        init: init,
        performSearch: performSearch,
        loadSettings: bindStudioSettings,
        openPreview: openTheaterPreview,
        openTheaterPreview: openTheaterPreview,
        closeTheaterPreview: closeTheaterPreview,
        clearMemory: window.clearStudioMemoryCache
    };
})();

if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => {
        SearchStudio.init();
    });
} else {
    SearchStudio.init();
}

// Low-end RAM garbage collection sweeps on idle
document.addEventListener("visibilitychange", () => {
    if (document.hidden && typeof window !== "undefined" && typeof window.gc === "function") {
        try { window.gc(); } catch (_) {}
    }
});
window.addEventListener("blur", () => {
    if (typeof window !== "undefined" && typeof window.gc === "function") {
        try { window.gc(); } catch (_) {}
    }
});



