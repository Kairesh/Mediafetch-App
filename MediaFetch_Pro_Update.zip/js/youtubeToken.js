/**
 * YouTube Visitor Data & Token Helper for Adobe CEP Client
 */

const YouTubeTokenHelper = (() => {
    const fallbackVisitorData = 'CgtTc2tTLUNYUnIxYyjyy67VBjIKCgJJThIEGgAgZ2LfAgrcAjIxLllUPUw5eHFxdkFYeXVXcDNMX0t3cHBGNEVsbVR1NU5vSS1nWDRyZk4xZEFWSF9UajFRUFRGNGdWU0VwMThSNUx0Nlg5Nmhra292cnF6TXBJaHJnMndRUEMwekdpYW45RzRwc3JMZmhHcUtWLTBRdWllZ1RiaWxqUFJ0b2ZWQnIzUThoRkZTMnc4Y2lZWndudUFiNDFvdm1xeTlxRHVCdWI1SWRTRWY4Q244UWpuQUZOaUdzR1U1ZVg4U291WnB2UFN5UDU2ZFJHclJ0dXhZZVU1OEhpbHE1QkdNMUJHY3A0b2RlRURBY2VwRTVQS1l2X21kSU1sTGRFellKMWwxVDRjWDZoN0E1bmdiSW1kQWhyeUV1a2tvTV9tb3dGMTB6ZEU3eE1pTHFJVVlRbkhvWEtqVWw2V1VadUFpZWpNeU9wY2V1bnpaWDQwcktJOE1BbWlhY0xvU00tdw%3D%3D';
    let cachedVisitorData = fallbackVisitorData;
    let lastFetched = Date.now();
    let isFetching = false;

    function isYouTubeUrl(url) {
        if (!url || typeof url !== 'string') return false;
        const lower = url.toLowerCase();
        return lower.includes('youtube.com') || lower.includes('youtu.be');
    }

    async function getVisitorData() {
        const age = Date.now() - lastFetched;
        if (age > 12 * 60 * 60 * 1000 && !isFetching && typeof fetch !== 'undefined') {
            refreshVisitorData().catch(() => {});
        }
        return cachedVisitorData || fallbackVisitorData;
    }

    async function refreshVisitorData() {
        if (isFetching || typeof fetch === 'undefined') return cachedVisitorData;
        isFetching = true;
        try {
            const res = await fetch('https://www.youtube.com', {
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'
                }
            });
            if (res.ok) {
                const html = await res.text();
                const match = html.match(/"VISITOR_DATA":\s*"([^"]+)"/);
                if (match && match[1]) {
                    cachedVisitorData = match[1];
                    lastFetched = Date.now();
                    return cachedVisitorData;
                }
            }
        } catch (e) {
            // Fallback silently
        } finally {
            isFetching = false;
        }
        return cachedVisitorData || fallbackVisitorData;
    }

    function getExtractorArgsSync(url) {
        const args = ['--js-runtimes', 'node'];
        if (isYouTubeUrl(url)) {
            const token = cachedVisitorData || fallbackVisitorData;
            args.push('--extractor-args', `youtube:visitor_data=${token}`);
        }
        return args;
    }

    return {
        isYouTubeUrl,
        getVisitorData,
        refreshVisitorData,
        getExtractorArgsSync
    };
})();

if (typeof module !== 'undefined' && module.exports) {
    module.exports = YouTubeTokenHelper;
} else if (typeof window !== 'undefined') {
    window.YouTubeTokenHelper = YouTubeTokenHelper;
}
