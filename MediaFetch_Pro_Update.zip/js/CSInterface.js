/**
 * CSInterface - Adobe CEP Extension Bridge (Lightweight & High-Performance)
 */
function CSInterface() {}

CSInterface.prototype.getHostEnvironment = function () {
    if (window.__adobe_cep__) {
        var str = window.__adobe_cep__.getHostEnvironment();
        return JSON.parse(str);
    }
    return { appName: "BROWSER", appVersion: "1.0" };
};

CSInterface.prototype.evalScript = function (script, callback) {
    if (window.__adobe_cep__) {
        window.__adobe_cep__.evalScript(script, callback || function () {});
    } else {
        if (callback) callback('{"error":"Not running inside Adobe CEP"}');
    }
};

CSInterface.prototype.openURLInDefaultBrowser = function (url) {
    if (window.__adobe_cep__) {
        window.__adobe_cep__.openURLInDefaultBrowser(url);
    } else if (window.require) {
        try {
            var shell = window.require('electron').shell;
            shell.openExternal(url);
        } catch (e) {
            window.open(url, '_blank');
        }
    } else {
        window.open(url, '_blank');
    }
};

CSInterface.prototype.closeExtension = function () {
    if (window.__adobe_cep__) {
        window.__adobe_cep__.closeExtension();
    }
};

CSInterface.prototype.addEventListener = function (type, listener, obj) {
    if (window.__adobe_cep__) {
        window.__adobe_cep__.addEventListener(type, listener, obj);
    }
};

CSInterface.prototype.removeEventListener = function (type, listener, obj) {
    if (window.__adobe_cep__) {
        window.__adobe_cep__.removeEventListener(type, listener, obj);
    }
};

CSInterface.prototype.dispatchEvent = function (event) {
    if (window.__adobe_cep__) {
        window.__adobe_cep__.dispatchEvent(event);
    }
};

CSInterface.prototype.getSystemPath = function (pathType) {
    if (window.__adobe_cep__) {
        return window.__adobe_cep__.getSystemPath(pathType);
    }
    return "";
};

CSInterface.prototype.requestOpenExtension = function (extensionId, params) {
    if (window.__adobe_cep__) {
        return window.__adobe_cep__.requestOpenExtension(extensionId, params || "");
    }
    return null;
};

function CSEvent(type, scope, appId, extensionId) {
    this.type = type;
    this.scope = scope || "APPLICATION";
    this.appId = appId || "com.mediafetch.adobe";
    this.extensionId = extensionId || "";
    this.data = "";
}

window.CSEvent = CSEvent;
window.CSInterface = CSInterface;

