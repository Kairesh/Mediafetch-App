/**
 * Wikimedia Commons API Integration (Videos & Photos)
 * Clean URLs, proper image thumbnails, and clean format labels.
 */
const WikimediaAPI = (function () {
    const BASE_URL = "https://commons.wikimedia.org/w/api.php";

    async function searchVideos(query, options = {}) {
        const limit = options.perPage || 35;
        const url = `${BASE_URL}?action=query&generator=search&gsrnamespace=6&gsrsearch=filetype:video%20${encodeURIComponent(query)}&gsrlimit=${limit}&prop=imageinfo&iiprop=url|size|mime|dimensions&iiurlwidth=480&format=json`;

        try {
            const data = await Net.getJson(url, {
                "User-Agent": "MediaFetch/1.0 (https://github.com/Kairesh/MediafetchPlugin; mediafetch.plugin@gmail.com)"
            });
            const pages = Object.values(data.query?.pages || {});

            const items = pages
                .filter(p => {
                    if (!p.imageinfo || !p.imageinfo[0] || !p.imageinfo[0].url) return false;
                    const info = p.imageinfo[0];
                    if (options.orientation === "landscape") {
                        if ((info.width || 1920) < (info.height || 1080)) return false;
                    } else if (options.orientation === "portrait") {
                        if ((info.height || 1080) <= (info.width || 1920)) return false;
                    }
                    return true;
                })
                .map(p => {
                    const info = p.imageinfo[0];
                    const cleanTitle = p.title
                        .replace(/^File:/i, "")
                        .replace(/\.[^/.]+$/, "")
                        .replace(/[_-]/g, " ")
                        .trim();

                    // Strip query string from media URL to get true clean extension
                    const rawUrl = info.url || "";
                    const cleanUrl = rawUrl.split("?")[0];
                    const ext = (cleanUrl.split(".").pop() || "mp4").toLowerCase();

                    // High quality poster thumbnail from iiurlwidth
                    const thumb = info.thumburl || (info.thumburl_width ? info.thumburl_width : "") || "https://upload.wikimedia.org/wikipedia/commons/thumb/b/b1/Loading_icon.gif/400px-Loading_icon.gif";

                    const formats = [
                        {
                            label: `${info.width || 1920}x${info.height || 1080} (${ext.toUpperCase()})`,
                            url: rawUrl,
                            cleanUrl: cleanUrl,
                            ext: ext,
                            type: "video"
                        }
                    ];

                    return {
                        id: "wiki_v_" + p.pageid,
                        source: "wikimedia",
                        type: "video",
                        title: cleanTitle,
                        author: "Wikimedia Commons",
                        duration: info.duration ? Math.round(info.duration) : 0,
                        durationString: info.duration ? `${Math.floor(info.duration / 60)}:${Math.round(info.duration % 60).toString().padStart(2, '0')}` : "",
                        thumbnail: thumb,
                        hoverPreviewUrl: rawUrl,
                        downloadFormats: formats,
                        pageUrl: info.descriptionurl || `https://commons.wikimedia.org/?curid=${p.pageid}`
                    };
                });

            return { items: items, total: items.length, page: 1, hasMore: false };
        } catch (err) {
            console.warn("Wikimedia video search failed:", err);
            return { items: [], total: 0, error: err.message };
        }
    }

    async function searchPhotos(query, options = {}) {
        const limit = options.perPage || 16;
        const url = `${BASE_URL}?action=query&generator=search&gsrnamespace=6&gsrsearch=filetype:bitmap%20${encodeURIComponent(query)}&gsrlimit=${limit}&prop=imageinfo&iiprop=url|size|mime|dimensions&iiurlwidth=480&format=json`;

        try {
            const data = await Net.getJson(url, {
                "User-Agent": "MediaFetch/1.0 (https://github.com/Kairesh/MediafetchPlugin; mediafetch.plugin@gmail.com)"
            });
            const pages = Object.values(data.query?.pages || {});

            const items = pages
                .filter(p => {
                    if (!p.imageinfo || !p.imageinfo[0] || !p.imageinfo[0].url) return false;
                    const info = p.imageinfo[0];
                    if (options.orientation === "landscape") {
                        if ((info.width || 1920) < (info.height || 1080)) return false;
                    } else if (options.orientation === "portrait") {
                        if ((info.height || 1080) <= (info.width || 1920)) return false;
                    }
                    return true;
                })
                .map(p => {
                    const info = p.imageinfo[0];
                    const cleanTitle = p.title
                        .replace(/^File:/i, "")
                        .replace(/\.[^/.]+$/, "")
                        .replace(/[_-]/g, " ")
                        .trim();

                    const rawUrl = info.url || "";
                    const cleanUrl = rawUrl.split("?")[0];
                    const ext = (cleanUrl.split(".").pop() || "jpg").toLowerCase();
                    const thumb = info.thumburl || rawUrl;

                    const formats = [
                        {
                            label: `Full ${info.width || 1920}x${info.height || 1080}`,
                            url: rawUrl,
                            cleanUrl: cleanUrl,
                            ext: ext,
                            type: "image"
                        }
                    ];

                    return {
                        id: "wiki_p_" + p.pageid,
                        source: "wikimedia",
                        type: "image",
                        title: cleanTitle,
                        author: "Wikimedia Commons",
                        thumbnail: thumb,
                        hoverPreviewUrl: rawUrl,
                        downloadFormats: formats,
                        pageUrl: info.descriptionurl || `https://commons.wikimedia.org/?curid=${p.pageid}`
                    };
                });

            return { items: items, total: items.length, page: 1, hasMore: false };
        } catch (err) {
            console.warn("Wikimedia photo search failed:", err);
            return { items: [], total: 0, error: err.message };
        }
    }

    return {
        searchVideos: searchVideos,
        searchPhotos: searchPhotos
    };
})();

if (typeof module !== "undefined" && module.exports) {
    module.exports = WikimediaAPI;
} else {
    window.WikimediaAPI = WikimediaAPI;
}
