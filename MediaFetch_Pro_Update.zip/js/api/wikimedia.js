/**
 * Wikimedia Commons API Integration (Videos & Photos)
 * Clean URLs, proper image thumbnails, fast transcode derivative streams, and clean format labels.
 */
const WikimediaAPI = (function () {
    const BASE_URL = "https://commons.wikimedia.org/w/api.php";
    const USER_AGENT = "MediaFetch/1.0 (https://github.com/Kairesh/MediafetchPlugin; mediafetch.plugin@gmail.com)";

    function buildDerivativeUrl(rawUrl, transcodeSuffix) {
        if (!rawUrl || typeof rawUrl !== "string") return "";
        const clean = rawUrl.split("?")[0];
        const m = clean.match(/wikipedia\/commons\/([0-9a-f]\/[0-9a-f]{2}\/)([^/?#]+)/i);
        if (m) {
            const pathPrefix = m[1];
            const fileName = m[2];
            return `https://upload.wikimedia.org/wikipedia/commons/transcoded/${pathPrefix}${fileName}/${fileName}.${transcodeSuffix}`;
        }
        return "";
    }

    async function searchVideos(query, options = {}) {
        const orientation = options.orientation || "all";
        let searchQuery = `filetype:video ${query}`.trim();
        if (orientation === "portrait") {
            searchQuery = `filetype:video (vertical OR portrait OR shorts OR "9:16") ${query}`.trim();
        }

        const buildUrl = (offset = 0) => {
            let u = `${BASE_URL}?action=query&generator=search&gsrnamespace=6&gsrsearch=${encodeURIComponent(searchQuery)}&gsrlimit=50&prop=videoinfo|imageinfo&iiprop=url|size|mime|dimensions&iiurlwidth=480&viprop=url|size|mime|dimensions|derivatives&format=json`;
            if (offset > 0) u += `&gsroffset=${offset}`;
            return u;
        };

        try {
            // Fetch three batches in parallel to maximize wiki search results (up to 150 items)
            const [resp1, resp2, resp3] = await Promise.allSettled([
                Net.getJson(buildUrl(0), { "User-Agent": USER_AGENT }),
                Net.getJson(buildUrl(50), { "User-Agent": USER_AGENT }),
                Net.getJson(buildUrl(100), { "User-Agent": USER_AGENT })
            ]);

            const pagesMap = new Map();
            [resp1, resp2, resp3].forEach(r => {
                if (r.status === "fulfilled" && r.value?.query?.pages) {
                    Object.values(r.value.query.pages).forEach(p => {
                        if (p && p.pageid && !pagesMap.has(p.pageid)) pagesMap.set(p.pageid, p);
                    });
                }
            });

            const pages = Array.from(pagesMap.values());

            const items = pages
                .filter(p => {
                    const info = (p.videoinfo && p.videoinfo[0]) || (p.imageinfo && p.imageinfo[0]);
                    if (!info || !info.url) return false;
                    const w = info.width || 0;
                    const h = info.height || 0;

                    if (orientation === "landscape") {
                        if (w > 0 && h > 0) {
                            if ((w / h) < 1.25) return false; // Must be horizontal widescreen (reject square & vertical)
                        } else {
                            if ((info.width || 1920) < (info.height || 1080)) return false;
                        }
                    } else if (orientation === "portrait") {
                        if (w > 0 && h > 0) {
                            if ((w / h) > 0.85) return false; // Must be vertical (reject square & horizontal)
                        } else {
                            if ((info.height || 1080) <= (info.width || 1920)) return false;
                        }
                    }
                    return true;
                })
                .map(p => {
                    const vinfo = (p.videoinfo && p.videoinfo[0]) || {};
                    const iinfo = (p.imageinfo && p.imageinfo[0]) || {};
                    const info = (p.videoinfo && p.videoinfo[0]) ? vinfo : iinfo;

                    const cleanTitle = p.title
                        .replace(/^File:/i, "")
                        .replace(/\.[^/.]+$/, "")
                        .replace(/[_-]/g, " ")
                        .trim();

                    const rawUrl = info.url || "";
                    const cleanUrl = rawUrl.split("?")[0];
                    const ext = (cleanUrl.split(".").pop() || "mp4").toLowerCase();
                    const w = info.width || 1920;
                    const h = info.height || 1080;
                    const durationSec = info.duration ? Math.round(info.duration) : 0;

                    // High quality poster thumbnail from iiurlwidth
                    const thumb = iinfo.thumburl || (iinfo.thumburl_width ? iinfo.thumburl_width : "") || info.thumburl || "https://upload.wikimedia.org/wikipedia/commons/thumb/b/b1/Loading_icon.gif/400px-Loading_icon.gif";

                    const derivatives = vinfo.derivatives || [];
                    const formats = [];
                    let bestPreviewUrl = "";

                    // Exclude unplayable .mov, .mpeg4, .ogv, .ogg codecs in Chromium (strictly WebM & H.264 MP4 only)
                    const playable = derivatives.filter(d => {
                        if (!d || !d.src) return false;
                        const dClean = d.src.split("?")[0].toLowerCase();
                        if (dClean.endsWith(".mov") || dClean.endsWith(".ogv") || dClean.endsWith(".ogg") || dClean.endsWith(".avi")) return false;
                        if (d.type && (d.type.includes("quicktime") || d.type.includes("mp4v") || d.type.includes("ogg") || d.type.includes("theora"))) return false;
                        return dClean.endsWith(".webm") || dClean.endsWith(".mp4");
                    });

                    // 1. Add Transcoded Playable Derivatives FIRST (VP9 WebM, MPEG4, etc.)
                    if (playable.length > 0) {
                        playable.forEach(d => {
                            if (!d.src || d.src === rawUrl) return;
                            const dClean = d.src.split("?")[0];
                            const dExt = (dClean.split(".").pop() || "webm").toLowerCase();
                            const dKey = d.transcodekey ? d.transcodekey.replace(/\.[^/.]+$/, "").toUpperCase() : `${d.width}x${d.height}`;
                            formats.push({
                                label: `${d.width || '?'}x${d.height || '?'} (${dKey})`,
                                url: d.src,
                                cleanUrl: dClean,
                                ext: dExt,
                                width: d.width || 0,
                                height: d.height || 0,
                                type: "video"
                            });
                        });

                        // Select 480p or 720p VP9/WebM derivative for instant zero-buffer preview
                        const d480 = playable.find(d => (d.transcodekey && d.transcodekey.includes("480p.vp9")) || (d.height && d.height <= 480 && d.height >= 360 && d.src.includes(".webm")));
                        const d720 = playable.find(d => (d.transcodekey && d.transcodekey.includes("720p.vp9")) || (d.height && d.height <= 720 && d.height >= 480 && d.src.includes(".webm")));
                        const d360 = playable.find(d => (d.transcodekey && d.transcodekey.includes("360p.vp9")));
                        const anySD = playable.find(d => d.src && d.src.includes(".webm") && d.src !== rawUrl);
                        if (d480 && d480.src) bestPreviewUrl = d480.src;
                        else if (d720 && d720.src) bestPreviewUrl = d720.src;
                        else if (d360 && d360.src) bestPreviewUrl = d360.src;
                        else if (anySD && anySD.src) bestPreviewUrl = anySD.src;
                        else if (playable.length > 0 && playable[0].src) bestPreviewUrl = playable[0].src;
                    }

                    // Fallback derivative URL if API didn't return playable derivatives
                    if (!bestPreviewUrl || bestPreviewUrl.endsWith(".ogv") || bestPreviewUrl.endsWith(".ogg") || bestPreviewUrl.endsWith(".mov")) {
                        const fallbackVp9 = buildDerivativeUrl(rawUrl, "480p.vp9.webm");
                        if (fallbackVp9) {
                            bestPreviewUrl = fallbackVp9;
                            formats.unshift({
                                label: `480p SD (VP9 WEBM)`,
                                url: fallbackVp9,
                                cleanUrl: fallbackVp9,
                                ext: "webm",
                                width: 854,
                                height: 480,
                                type: "video"
                            });
                        } else if (!rawUrl.endsWith(".ogv") && !rawUrl.endsWith(".ogg")) {
                            bestPreviewUrl = rawUrl;
                        }
                    }

                    // 2. Original Master Full File (appended last so player never picks unplayable master by default)
                    formats.push({
                        label: `Master (${w}x${h} ${ext.toUpperCase()})`,
                        url: rawUrl,
                        cleanUrl: cleanUrl,
                        ext: ext,
                        width: w,
                        height: h,
                        type: "video"
                    });

                    return {
                        id: "wiki_v_" + p.pageid,
                        source: "wikimedia",
                        type: "video",
                        title: cleanTitle,
                        author: "Wikimedia Commons",
                        duration: durationSec,
                        durationString: durationSec ? `${Math.floor(durationSec / 60)}:${Math.round(durationSec % 60).toString().padStart(2, '0')}` : "",
                        thumbnail: thumb,
                        hoverPreviewUrl: bestPreviewUrl,
                        previewUrl: bestPreviewUrl,
                        directStreamUrl: bestPreviewUrl,
                        downloadFormats: formats,
                        pageUrl: info.descriptionurl || `https://commons.wikimedia.org/?curid=${p.pageid}`,
                        width: w,
                        height: h
                    };
                });

            return { items: items, total: items.length, page: 1, hasMore: false };
        } catch (err) {
            console.warn("Wikimedia video search failed:", err);
            return { items: [], total: 0, error: err.message };
        }
    }

    async function searchPhotos(query, options = {}) {
        const orientation = options.orientation || "all";
        let searchQuery = `filetype:bitmap ${query}`.trim();

        const buildUrl = (offset = 0) => {
            let u = `${BASE_URL}?action=query&generator=search&gsrnamespace=6&gsrsearch=${encodeURIComponent(searchQuery)}&gsrlimit=50&prop=imageinfo&iiprop=url|size|mime|dimensions&iiurlwidth=480&format=json`;
            if (offset > 0) u += `&gsroffset=${offset}`;
            return u;
        };

        try {
            // Parallel fetch to maximize photo results (up to 150 items)
            const [resp1, resp2, resp3] = await Promise.allSettled([
                Net.getJson(buildUrl(0), { "User-Agent": USER_AGENT }),
                Net.getJson(buildUrl(50), { "User-Agent": USER_AGENT }),
                Net.getJson(buildUrl(100), { "User-Agent": USER_AGENT })
            ]);

            const pagesMap = new Map();
            [resp1, resp2, resp3].forEach(r => {
                if (r.status === "fulfilled" && r.value?.query?.pages) {
                    Object.values(r.value.query.pages).forEach(p => {
                        if (p && p.pageid && !pagesMap.has(p.pageid)) pagesMap.set(p.pageid, p);
                    });
                }
            });

            const pages = Array.from(pagesMap.values());

            const items = pages
                .filter(p => {
                    if (!p.imageinfo || !p.imageinfo[0] || !p.imageinfo[0].url) return false;
                    const info = p.imageinfo[0];
                    const w = info.width || 0;
                    const h = info.height || 0;

                    if (orientation === "landscape") {
                        if (w > 0 && h > 0) {
                            if ((w / h) < 1.25) return false;
                        } else {
                            if ((info.width || 1920) < (info.height || 1080)) return false;
                        }
                    } else if (orientation === "portrait") {
                        if (w > 0 && h > 0) {
                            if ((w / h) > 0.85) return false;
                        } else {
                            if ((info.height || 1080) <= (info.width || 1920)) return false;
                        }
                    }
                    return true;
                })
                .map(p => {
                    const info = p.imageinfo[0];
                    const cleanTitle = p.title
                        .replace(/^File:/i, "")
                        .replace(/\.[^/.]+$/, "")
                        .replace(/[_-]/g, " ")
                        .trim();

                    const rawUrl = info.url || "";
                    const cleanUrl = rawUrl.split("?")[0];
                    const ext = (cleanUrl.split(".").pop() || "jpg").toLowerCase();
                    const thumb = info.thumburl || rawUrl;
                    const w = info.width || 1920;
                    const h = info.height || 1080;

                    const formats = [
                        {
                            label: `Full ${w}x${h}`,
                            url: rawUrl,
                            cleanUrl: cleanUrl,
                            ext: ext,
                            width: w,
                            height: h,
                            type: "image"
                        }
                    ];

                    return {
                        id: "wiki_p_" + p.pageid,
                        source: "wikimedia",
                        type: "image",
                        title: cleanTitle,
                        author: "Wikimedia Commons",
                        thumbnail: thumb,
                        hoverPreviewUrl: rawUrl,
                        downloadFormats: formats,
                        pageUrl: info.descriptionurl || `https://commons.wikimedia.org/?curid=${p.pageid}`,
                        width: w,
                        height: h
                    };
                });

            return { items: items, total: items.length, page: 1, hasMore: false };
        } catch (err) {
            console.warn("Wikimedia photo search failed:", err);
            return { items: [], total: 0, error: err.message };
        }
    }

    return {
        searchVideos: searchVideos,
        searchPhotos: searchPhotos
    };
})();

if (typeof module !== "undefined" && module.exports) {
    module.exports = WikimediaAPI;
} else {
    window.WikimediaAPI = WikimediaAPI;
}
