/**
 * Pexels API Integration (Videos & Photos) via Net module
 * Direct royalty-free 4K/HD stock footage and photography
 */
const PexelsAPI = (function () {
    const BASE_URL = "https://api.pexels.com";

    function getApiKey() {
        const userKey = typeof Settings !== "undefined" ? Settings.get("pexelsApiKey") : "";
        if (userKey && typeof userKey === "string") {
            const k = userKey.trim();
            if (k && !k.includes("563492ad6f91700001000001dfa1f8db1f344df3bbbc9e829d592652") && !k.includes("nJhYrM3NMjdfzgsR092DY9sUSpWiYU2iXmbsAwnDLJHDxxp9F6vKwBnE")) {
                return k;
            }
        }
        return "";
    }

    function formatDuration(sec) {
        if (!sec || isNaN(sec)) return "";
        const m = Math.floor(sec / 60);
        const s = Math.floor(sec % 60).toString().padStart(2, "0");
        return `${m}:${s}`;
    }

    async function searchVideos(query, options = {}) {
        const apiKey = getApiKey();
        if (!apiKey) return { items: [], total: 0 };

        const page = options.page || 1;
        const perPage = Math.max(1, Math.min(80, options.perPage || 60));
        const orientation = options.orientation || "";

        let url = `${BASE_URL}/videos/search?query=${encodeURIComponent(query)}&page=${page}&per_page=${perPage}`;
        if (orientation) url += `&orientation=${orientation}`;

        try {
            const res = await Net.request(url, {
                headers: { Authorization: apiKey }
            });
            if (!res.ok) return { items: [], total: 0 };
            const data = await res.json();

            const items = (data.videos || []).map(v => {
                const files = v.video_files || [];
                const hoverVideo = files.find(f => f.quality === "sd" || (f.height && f.height <= 480)) || files[0];
                const qualities = files
                    .filter(f => f.link && f.file_type === "video/mp4")
                    .map(f => ({
                        label: `${f.width}x${f.height} (${f.quality ? f.quality.toUpperCase() : "MP4"})`,
                        width: f.width,
                        height: f.height,
                        url: f.link,
                        ext: "mp4",
                        type: "video"
                    }))
                    .sort((a, b) => (b.width || 0) - (a.width || 0));

                const titleClean = v.url.split("/").filter(Boolean).pop().replace(/-\d+$/, "").replace(/-/g, " ") || `Pexels Footage #${v.id}`;

                return {
                    id: "pexels_v_" + v.id,
                    source: "Pexels",
                    type: "video",
                    title: titleClean.charAt(0).toUpperCase() + titleClean.slice(1),
                    author: v.user ? v.user.name : "Pexels Creator",
                    authorUrl: v.user ? v.user.url : "",
                    duration: v.duration,
                    durationString: formatDuration(v.duration),
                    thumbnail: (v.image && v.image.includes("?")) ? v.image.replace(/&w=\d+/, "&w=320") : ((v.image || "") + (v.image && v.image.includes("?") ? "&w=320" : "?auto=compress&cs=tinysrgb&dpr=1&w=320")),
                    hoverPreviewUrl: hoverVideo ? hoverVideo.link : "",
                    downloadFormats: qualities,
                    pageUrl: v.url
                };
            });

            return { items: items, total: data.total_results || items.length, page: data.page, hasMore: false };
        } catch (err) {
            console.warn("Pexels video search error:", err);
            return { items: [], total: 0 };
        }
    }

    async function searchPhotos(query, options = {}) {
        const apiKey = getApiKey();
        if (!apiKey) return { items: [], total: 0 };

        const page = options.page || 1;
        const perPage = Math.max(1, Math.min(80, options.perPage || 60));
        const orientation = options.orientation || "";

        let url = `${BASE_URL}/v1/search?query=${encodeURIComponent(query)}&page=${page}&per_page=${perPage}`;
        if (orientation) url += `&orientation=${orientation}`;

        try {
            const res = await Net.request(url, {
                headers: { Authorization: apiKey }
            });
            if (!res.ok) return { items: [], total: 0 };
            const data = await res.json();

            const items = (data.photos || []).map(p => {
                const formats = [
                    { label: `Original (${p.width}x${p.height})`, url: p.src.original, ext: "jpg", type: "image" },
                    { label: "Large 2K", url: p.src.large2x, ext: "jpg", type: "image" },
                    { label: "Medium HD", url: p.src.medium, ext: "jpg", type: "image" }
                ];

                return {
                    id: "pexels_p_" + p.id,
                    source: "Pexels",
                    type: "image",
                    title: p.alt || `Pexels Photo #${p.id}`,
                    author: p.photographer,
                    authorUrl: p.photographer_url,
                    thumbnail: p.src.medium || p.src.tiny,
                    hoverPreviewUrl: p.src.large || p.src.medium,
                    downloadFormats: formats,
                    pageUrl: p.url
                };
            });

            return { items: items, total: data.total_results || items.length, page: data.page, hasMore: false };
        } catch (err) {
            console.warn("Pexels photo search error:", err);
            return { items: [], total: 0 };
        }
    }

    return {
        searchVideos: searchVideos,
        searchPhotos: searchPhotos
    };
})();

if (typeof module !== "undefined" && module.exports) {
    module.exports = PexelsAPI;
} else {
    window.PexelsAPI = PexelsAPI;
}
