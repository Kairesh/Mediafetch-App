/**
 * Openverse API Integration (Photos & FreeSound Audio / SFX)
 * Over 700+ Million Creative Commons Assets - Free & Zero Key Needed!
 */
const OpenverseAPI = (function () {
    const BASE_URL = "https://api.openverse.org/v1";
    const CLIENT_ID = "3BxSLlsIHJf4LN2nJLMMMmzzOnaBMVKFatj8lLST";
    const CLIENT_SECRET = "H8LuUkqOU94uc54Xrk9GQ82MrhGT5WP98oJpcWZVf0lnUnY1VcfmhocAWQIoCP7d2dj3NJ0gpOfO4jfgH0WTU4UqkKBF6oVnFMJoMlaUViMd31Uj66saPVVDJyhyAcV3";
    let cachedToken = "vcyAzKHpexHf74mmV3L6Rmecv1zkuA";
    let tokenExpiry = Date.now() + 40000 * 1000;

    async function getAuthHeader() {
        if (cachedToken && Date.now() < tokenExpiry) {
            return { Authorization: `Bearer ${cachedToken}` };
        }
        try {
            const body = `client_id=${CLIENT_ID}&client_secret=${CLIENT_SECRET}&grant_type=client_credentials`;
            const res = await Net.request(`${BASE_URL}/auth_tokens/token/`, {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: body
            });
            if (res && res.ok) {
                const data = await res.json();
                if (data && data.access_token) {
                    cachedToken = data.access_token;
                    tokenExpiry = Date.now() + ((data.expires_in || 3600) - 300) * 1000;
                    return { Authorization: `Bearer ${cachedToken}` };
                }
            }
        } catch (_) {}
        return cachedToken ? { Authorization: `Bearer ${cachedToken}` } : {};
    }

    async function searchPhotos(query, options = {}) {
        const page = options.page || 1;
        const pageSize = Math.max(5, Math.min(50, options.perPage || 40));
        let ratioParam = "";
        if (options.orientation === "landscape") ratioParam = "&aspect_ratio=wide";
        else if (options.orientation === "portrait") ratioParam = "&aspect_ratio=tall";

        const url = `${BASE_URL}/images/?q=${encodeURIComponent(query)}&page=${page}&page_size=${pageSize}${ratioParam}`;

        try {
            const authHeader = await getAuthHeader();
            const res = await Net.request(url, { headers: authHeader });
            if (!res.ok) return { items: [], total: 0 };
            const data = await res.json();
            const items = (data.results || []).map(item => {
                const formats = [
                    { label: `Original (${item.width || 1920}x${item.height || 1080})`, url: item.url, ext: "jpg", type: "image" },
                    { label: "Medium", url: item.thumbnail || item.url, ext: "jpg", type: "image" }
                ];

                return {
                    id: "openverse_p_" + item.id,
                    source: "Openverse",
                    type: "image",
                    title: item.title || `Creative Commons Photo #${item.id.substring(0, 8)}`,
                    author: item.creator || "Openverse Creator",
                    authorUrl: item.creator_url || item.foreign_landing_url,
                    thumbnail: item.thumbnail || item.url,
                    hoverPreviewUrl: item.url,
                    downloadFormats: formats,
                    pageUrl: item.foreign_landing_url || item.detail_url
                };
            });

            return {
                items: items,
                total: data.result_count || items.length,
                page: page,
                hasMore: !!data.next
            };
        } catch (err) {
            console.warn("Openverse photo search failed:", err);
            return { items: [], total: 0, error: err.message };
        }
    }

    async function searchAudio(query, options = {}) {
        const page = options.page || 1;
        const pageSize = Math.max(5, Math.min(50, options.perPage || 40));
        const url = `${BASE_URL}/audio/?q=${encodeURIComponent(query)}&page=${page}&page_size=${pageSize}`;

        try {
            const authHeader = await getAuthHeader();
            const res = await Net.request(url, { headers: authHeader });
            if (!res.ok) return { items: [], total: 0 };
            const data = await res.json();
            const items = (data.results || []).map(item => {
                const mp3Url = item.url || (item.alt_files && item.alt_files[0] && item.alt_files[0].url) || "";
                const durSec = item.duration ? Math.round(item.duration / 1000) : 0;
                const durStr = durSec > 0 ? `${Math.floor(durSec / 60)}:${(durSec % 60).toString().padStart(2, '0')}` : "SFX";

                const formats = [
                    { label: "HQ MP3 Audio", url: mp3Url, ext: "mp3", type: "audio" }
                ];

                return {
                    id: "openverse_a_" + item.id,
                    source: ((item.provider || "").toLowerCase().includes("freesound") ? "FreeSound" : "Openverse"),
                    type: "audio",
                    title: item.title || `Sound Effect #${item.id.substring(0, 8)}`,
                    author: item.creator || "Sound Designer",
                    duration: durSec,
                    durationString: durStr,
                    thumbnail: "",
                    audioPreviewUrl: mp3Url,
                    downloadFormats: formats,
                    pageUrl: item.foreign_landing_url || item.detail_url
                };
            });

            return {
                items: items,
                total: data.result_count || items.length,
                page: page,
                hasMore: !!data.next
            };
        } catch (err) {
            console.warn("Openverse audio search failed:", err);
            return { items: [], total: 0, error: err.message };
        }
    }

    return {
        searchPhotos: searchPhotos,
        searchAudio: searchAudio
    };
})();

if (typeof module !== "undefined" && module.exports) {
    module.exports = OpenverseAPI;
} else {
    window.OpenverseAPI = OpenverseAPI;
}
