/**
 * Pixabay API Integration via Net module
 * Direct royalty-free 4K/HD stock footage and high-res photography
 */
const PixabayAPI = (function () {
    const BASE_URL = "https://pixabay.com/api";

    function getApiKey() {
        const userKey = typeof Settings !== "undefined" ? Settings.get("pixabayApiKey") : "";
        if (userKey && typeof userKey === "string") {
            const k = userKey.trim();
            if (k && !k.includes("45972822") && !k.includes("10547590") && !k.includes("23107835")) {
                return k;
            }
        }
        return "";
    }

    function formatDuration(sec) {
        if (!sec || isNaN(sec)) return "";
        const m = Math.floor(sec / 60);
        const s = Math.floor(sec % 60).toString().padStart(2, "0");
        return `${m}:${s}`;
    }

    async function searchVideos(query, options = {}) {
        const apiKey = getApiKey();
        if (!apiKey) return { items: [], total: 0 };
        const page = options.page || 1;
        const perPage = Math.max(3, Math.min(100, options.perPage || 60));
        let orientationParam = "";
        if (options.orientation === "landscape" || options.orientation === "horizontal") {
            orientationParam = "&orientation=horizontal";
        } else if (options.orientation === "portrait" || options.orientation === "vertical") {
            orientationParam = "&orientation=vertical";
        }

        const keysToTry = [apiKey];
        for (const currentKey of keysToTry) {
            const url = `${BASE_URL}/videos/?key=${currentKey}&q=${encodeURIComponent(query)}&page=${page}&per_page=${perPage}&safesearch=true${orientationParam}`;
            try {
                const res = await Net.request(url);
                if (!res.ok) {
                    if (res.status === 429) continue; // rate limited, try next key
                    continue;
                }
                const data = await res.json();
                if (!data || !data.hits) continue;

                const items = (data.hits || []).map(v => {
                    const formats = [];
                    if (v.videos) {
                        if (v.videos.large && v.videos.large.url) {
                            formats.push({
                                label: `4K/Large (${v.videos.large.width}x${v.videos.large.height})`,
                                url: v.videos.large.url,
                                width: v.videos.large.width,
                                height: v.videos.large.height,
                                ext: "mp4",
                                type: "video"
                            });
                        }
                        if (v.videos.medium && v.videos.medium.url) {
                            formats.push({
                                label: `HD (${v.videos.medium.width}x${v.videos.medium.height})`,
                                url: v.videos.medium.url,
                                width: v.videos.medium.width,
                                height: v.videos.medium.height,
                                ext: "mp4",
                                type: "video"
                            });
                        }
                        if (v.videos.small && v.videos.small.url) {
                            formats.push({
                                label: `SD 480p (${v.videos.small.width}x${v.videos.small.height})`,
                                url: v.videos.small.url,
                                width: v.videos.small.width,
                                height: v.videos.small.height,
                                ext: "mp4",
                                type: "video"
                            });
                        }
                    }

                    const hoverUrl = (v.videos && v.videos.small && v.videos.small.url) ||
                        (v.videos && v.videos.tiny && v.videos.tiny.url) ||
                        (v.videos && v.videos.medium && v.videos.medium.url) || "";

                    const thumb = (v.videos && v.videos.medium && v.videos.medium.thumbnail) ||
                        (v.videos && v.videos.small && v.videos.small.thumbnail) ||
                        (v.videos && v.videos.large && v.videos.large.thumbnail) ||
                        (v.videos && v.videos.tiny && v.videos.tiny.thumbnail) ||
                        (v.picture_id ? `https://i.vimeocdn.com/video/${v.picture_id}_295x166.jpg` : "") ||
                        (v.userImageURL || "");

                    const titleStr = v.tags ? v.tags.split(",").slice(0, 3).map(s => s.trim()).join(" • ") : `Pixabay Footage #${v.id}`;

                    return {
                        id: "pixabay_v_" + v.id,
                        source: "Pixabay",
                        type: "video",
                        title: titleStr,
                        author: v.user || "Pixabay Creator",
                        duration: v.duration,
                        durationString: formatDuration(v.duration),
                        thumbnail: thumb,
                        hoverPreviewUrl: hoverUrl,
                        downloadFormats: formats,
                        pageUrl: v.pageURL
                    };
                });

                return { items: items, total: data.totalHits || items.length, page: page, hasMore: false };
            } catch (err) {
                console.warn("Pixabay video search error with key:", err);
            }
        }
        return { items: [], total: 0 };
    }

    async function searchPhotos(query, options = {}) {
        const apiKey = getApiKey();
        if (!apiKey) return { items: [], total: 0 };
        const page = options.page || 1;
        const perPage = Math.max(3, Math.min(100, options.perPage || 60));
        let orientationParam = "";
        if (options.orientation === "landscape" || options.orientation === "horizontal") {
            orientationParam = "&orientation=horizontal";
        } else if (options.orientation === "portrait" || options.orientation === "vertical") {
            orientationParam = "&orientation=vertical";
        }

        const keysToTry = [apiKey];
        for (const currentKey of keysToTry) {
            const url = `${BASE_URL}/?key=${currentKey}&q=${encodeURIComponent(query)}&page=${page}&per_page=${perPage}&safesearch=true${orientationParam}`;
            try {
                const res = await Net.request(url);
                if (!res.ok) {
                    if (res.status === 429) continue;
                    continue;
                }
                const data = await res.json();
                if (!data || !data.hits) continue;

                const items = (data.hits || []).map(p => {
                    const formats = [
                        { label: `Full Res (${p.imageWidth}x${p.imageHeight})`, url: p.largeImageURL, ext: "jpg", type: "image" },
                        { label: "Web HD", url: p.webformatURL, ext: "jpg", type: "image" }
                    ];

                    const titleStr = p.tags ? p.tags.split(",").slice(0, 3).map(s => s.trim()).join(" • ") : `Pixabay Photo #${p.id}`;

                    return {
                        id: "pixabay_p_" + p.id,
                        source: "Pixabay",
                        type: "image",
                        title: titleStr,
                        author: p.user || "Pixabay Creator",
                        thumbnail: p.webformatURL || p.previewURL,
                        hoverPreviewUrl: p.webformatURL,
                        downloadFormats: formats,
                        pageUrl: p.pageURL
                    };
                });

                return { items: items, total: data.totalHits || items.length, page: page, hasMore: false };
            } catch (err) {
                console.warn("Pixabay photo search error:", err);
            }
        }
        return { items: [], total: 0 };
    }

    return {
        searchVideos: searchVideos,
        searchPhotos: searchPhotos
    };
})();

if (typeof module !== "undefined" && module.exports) {
    module.exports = PixabayAPI;
} else {
    window.PixabayAPI = PixabayAPI;
}
