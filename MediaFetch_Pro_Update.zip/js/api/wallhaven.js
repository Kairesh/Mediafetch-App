/**
 * Wallhaven 4K & 8K Wallpaper API Integration
 * Ultra-HD desktop & mobile wallpapers, digital art, and backgrounds - Zero Key Needed!
 */
const WallhavenAPI = (function () {
    const BASE_URL = "https://wallhaven.cc/api/v1";

    async function searchWallpapers(query, options = {}) {
        const page = options.page || 1;
        let ratiosParam = "";
        if (options.orientation === "landscape") ratiosParam = "&ratios=landscape,16x9,16x10,21x9";
        else if (options.orientation === "portrait") ratiosParam = "&ratios=portrait,9x16,10x16";

        const url = `${BASE_URL}/search?q=${encodeURIComponent(query)}&page=${page}&sorting=relevance${ratiosParam}`;

        try {
            const data = await Net.getJson(url);
            const items = (data.data || []).map(w => {
                const ext = w.file_type ? w.file_type.split("/").pop() : "jpg";
                const formats = [
                    {
                        label: `Ultra-HD ${w.resolution || "4K"} (${(w.file_size ? (w.file_size / (1024 * 1024)).toFixed(1) + " MB" : ext.toUpperCase())})`,
                        url: w.path,
                        ext: ext,
                        type: "image"
                    }
                ];

                return {
                    id: "wallhaven_" + w.id,
                    source: "wallhaven 4k",
                    type: "image",
                    title: `Wallhaven ${w.resolution || "4K"} #${w.id}`,
                    author: w.uploader ? w.uploader.username : "Digital Artist",
                    thumbnail: (w.thumbs && (w.thumbs.small || w.thumbs.original)) || w.path,
                    hoverPreviewUrl: (w.thumbs && w.thumbs.large) || w.path,
                    downloadFormats: formats,
                    pageUrl: w.url
                };
            });

            return { items: items, total: (data.meta && data.meta.total) || items.length, page: page, hasMore: false };
        } catch (err) {
            console.warn("Wallhaven search failed:", err);
            return { items: [], total: 0, error: err.message };
        }
    }

    return {
        searchWallpapers: searchWallpapers
    };
})();

if (typeof module !== "undefined" && module.exports) {
    module.exports = WallhavenAPI;
} else {
    window.WallhavenAPI = WallhavenAPI;
}
