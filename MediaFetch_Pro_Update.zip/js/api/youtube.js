/**
 * YouTube Search & Stream Resolver (CORS-Bypassed via Node.js)
 * High-Throughput Harvester: extracts all standard videos, movies, clips, and shorts
 */
const YouTubeAPI = (function () {
    /**
     * Fast keyword search by parsing YouTube search results directly via Net module
     */
    async function searchVideos(query, options = {}) {
        // Unrestricted query URL or targeted shorts query based on orientation
        let url = `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`;
        if (options.orientation === "portrait") {
            const qLower = query.toLowerCase();
            if (!qLower.includes("short") && !qLower.includes("vertical") && !qLower.includes("reel")) {
                url = `https://www.youtube.com/results?search_query=${encodeURIComponent(query + " shorts")}`;
            }
        }

        try {
            const html = await Net.getText(url, {
                "Accept-Language": "en-US,en;q=0.9",
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            });

            // Extract ytInitialData
            const match = html.match(/var ytInitialData\s*=\s*({.+?});<\/script>/) || html.match(/window\["ytInitialData"\]\s*=\s*({.+?});/);
            if (!match) {
                return { items: [], total: 0 };
            }

            const data = JSON.parse(match[1]);
            const items = [];
            const seen = new Set();
            const maxResults = options.limit || 80;
            const orientation = options.orientation || "all";

            function isShortDuration(durationStr) {
                if (!durationStr || typeof durationStr !== "string") return false;
                const d = durationStr.trim().toLowerCase();
                if (d === "short" || d.includes("short")) return true;
                const parts = d.split(":").map(p => parseInt(p, 10));
                if (parts.some(isNaN)) return false;
                if (parts.length === 1) return parts[0] <= 60;
                if (parts.length === 2) return (parts[0] * 60 + parts[1]) <= 60;
                return false;
            }

            function getLowRamThumb(thumbs, id) {
                if (thumbs && thumbs.length > 0) {
                    const target = thumbs.length > 2 ? thumbs[1] : thumbs[0];
                    if (target && target.url) {
                        return target.url;
                    }
                }
                return `https://i.ytimg.com/vi/${id}/mqdefault.jpg`;
            }

            function addVideoItem(id, title, channel, duration, thumb, isShort = false) {
                if (!id || seen.has(id)) return;
                // Exclude playlists, mixes, and channels
                if (id.startsWith("PL") || id.startsWith("RD") || id.startsWith("VL") || id.startsWith("UC")) return;

                // Format & Orientation filtering
                if (orientation === "landscape") {
                    if (isShort || duration === "Short") return;
                } else if (orientation === "portrait") {
                    if (!isShort && duration !== "Short" && !isShortDuration(duration)) return;
                }

                seen.add(id);

                const videoUrl = `https://www.youtube.com/watch?v=${id}`;
                const formats = [
                    { label: "4K Ultra HD (2160p)", ext: "mp4", quality: "2160", type: "video", sourceUrl: videoUrl },
                    { label: "2K Quad HD (1440p)", ext: "mp4", quality: "1440", type: "video", sourceUrl: videoUrl },
                    { label: "1080p Full HD (MP4)", ext: "mp4", quality: "1080", type: "video", sourceUrl: videoUrl },
                    { label: "720p HD (MP4)", ext: "mp4", quality: "720", type: "video", sourceUrl: videoUrl },
                    { label: "Best Available (Highest)", ext: "mp4", quality: "best", type: "video", sourceUrl: videoUrl },
                    { label: "MP3 Audio (320kbps)", ext: "mp3", quality: "audio", type: "audio", sourceUrl: videoUrl },
                    { label: "WAV Audio (Lossless PCM)", ext: "wav", quality: "audio-wav", type: "audio", sourceUrl: videoUrl },
                    { label: "M4A Audio (AAC)", ext: "m4a", quality: "audio-m4a", type: "audio", sourceUrl: videoUrl },
                    { label: "FLAC Audio (Lossless)", ext: "flac", quality: "audio-flac", type: "audio", sourceUrl: videoUrl }
                ];

                items.push({
                    id: "yt_" + id,
                    videoId: id,
                    source: "youtube",
                    type: "video",
                    title: title || "YouTube Video",
                    author: channel || "YouTube Creator",
                    durationString: duration || "",
                    thumbnail: thumb,
                    hoverPreviewUrl: "", // Handled natively by interactive preview engine
                    downloadFormats: formats,
                    pageUrl: videoUrl
                });
            }

            // Recursive JSON walker to harvest all videos from modern & classic YouTube structures
            function walk(node) {
                if (!node || typeof node !== "object" || items.length >= maxResults) return;

                // 1. Classic videoRenderer
                if (node.videoRenderer) {
                    const v = node.videoRenderer;
                    const id = v.videoId;
                    if (id) {
                        const title = v.title?.runs?.map(r => r.text).join("") || v.title?.simpleText || "YouTube Video";
                        const channel = v.ownerText?.runs?.map(r => r.text).join("") || v.shortBylineText?.runs?.map(r => r.text).join("") || "YouTube Creator";
                        const duration = v.lengthText?.simpleText || "";
                        const thumbs = v.thumbnail?.thumbnails || [];
                        const thumb = getLowRamThumb(thumbs, id);
                        addVideoItem(id, title, channel, duration, thumb, false);
                    }
                }

                // 2. Modern lockupViewModel (standard videos)
                if (node.lockupViewModel && node.lockupViewModel.contentId) {
                    const vm = node.lockupViewModel;
                    const id = vm.contentId;
                    if (id && !id.startsWith("PL") && !id.startsWith("RD") && !id.startsWith("VL") && !id.startsWith("UC")) {
                        const title = vm.metadata?.lockupMetadataViewModel?.title?.content || "YouTube Video";
                        const channel = vm.metadata?.lockupMetadataViewModel?.metadata?.contentMetadataViewModel?.metadataRows?.[0]?.parts?.[0]?.text?.content || "YouTube Creator";
                        const duration = vm.contentImage?.thumbnailOverlayBadgeViewModel?.badge?.badgeViewModel?.label || "";
                        const thumbs = vm.contentImage?.collectionThumbnailViewModel?.primaryThumbnail?.thumbnailViewModel?.image?.sources || [];
                        const thumb = getLowRamThumb(thumbs, id);
                        addVideoItem(id, title, channel, duration, thumb, false);
                    }
                }

                // 3. shortsLockupViewModel (YouTube Shorts)
                if (node.shortsLockupViewModel) {
                    const s = node.shortsLockupViewModel;
                    const entityId = s.entityId || "";
                    const id = s.onTap?.innertubeCommand?.reelWatchEndpoint?.videoId || entityId.replace("shorts-shelf-item-", "") || "";
                    if (id) {
                        const title = s.overlayMetadata?.primaryText?.content || s.accessibilityText?.split(",")[0] || "YouTube Short";
                        const thumbs = s.thumbnail?.sources || [];
                        const thumb = getLowRamThumb(thumbs, id);
                        addVideoItem(id, title, "YouTube Shorts", "Short", thumb, true);
                    }
                }

                // 4. reelItemRenderer (YouTube Shorts)
                if (node.reelItemRenderer) {
                    const r = node.reelItemRenderer;
                    const id = r.videoId;
                    if (id) {
                        const title = r.headline?.simpleText || "YouTube Short";
                        const thumbs = r.thumbnail?.thumbnails || [];
                        const thumb = getLowRamThumb(thumbs, id);
                        addVideoItem(id, title, "YouTube Shorts", "Short", thumb, true);
                    }
                }

                // 5. compactVideoRenderer
                if (node.compactVideoRenderer) {
                    const cv = node.compactVideoRenderer;
                    const id = cv.videoId;
                    if (id) {
                        const title = cv.title?.runs?.map(r => r.text).join("") || cv.title?.simpleText || "YouTube Video";
                        const channel = cv.shortBylineText?.runs?.map(r => r.text).join("") || "YouTube Creator";
                        const duration = cv.lengthText?.simpleText || "";
                        const thumbs = cv.thumbnail?.thumbnails || [];
                        const thumb = getLowRamThumb(thumbs, id);
                        addVideoItem(id, title, channel, duration, thumb, false);
                    }
                }

                // 6. gridVideoRenderer (shelf & grid videos)
                if (node.gridVideoRenderer) {
                    const gv = node.gridVideoRenderer;
                    const id = gv.videoId;
                    if (id) {
                        const title = gv.title?.runs?.map(r => r.text).join("") || gv.title?.simpleText || "YouTube Video";
                        const channel = gv.shortBylineText?.runs?.map(r => r.text).join("") || "YouTube Creator";
                        const duration = gv.thumbnailOverlays?.find(o => o.thumbnailOverlayTimeStatusRenderer)?.thumbnailOverlayTimeStatusRenderer?.text?.simpleText || "";
                        const thumbs = gv.thumbnail?.thumbnails || [];
                        const thumb = getLowRamThumb(thumbs, id);
                        addVideoItem(id, title, channel, duration, thumb, false);
                    }
                }

                // Recurse into children
                if (Array.isArray(node)) {
                    for (let i = 0; i < node.length; i++) {
                        walk(node[i]);
                        if (items.length >= maxResults) break;
                    }
                } else {
                    const keys = Object.keys(node);
                    for (let i = 0; i < keys.length; i++) {
                        walk(node[keys[i]]);
                        if (items.length >= maxResults) break;
                    }
                }
            }

            walk(data);

            // Stream initial batch immediately so the UI renders the top section in milliseconds
            if (typeof options.onBatch === "function" && items.length > 0) {
                try { options.onBatch(items.slice()); } catch (_) {}
            }

            // Harvest additional pages progressively to match official platform search volumes (100+ videos)
            let token = null;
            function findToken(n) {
                if (!n || typeof n !== "object") return;
                if (n.continuationCommand && n.continuationCommand.token) {
                    token = n.continuationCommand.token;
                    return;
                }
                const k = Object.keys(n);
                for (let i = 0; i < k.length; i++) {
                    findToken(n[k[i]]);
                    if (token) return;
                }
            }
            findToken(data);

            const keyMatch = html.match(/"INNERTUBE_API_KEY":"([^"]+)"/);
            const clientVerMatch = html.match(/"clientVersion":"([^"]+)"/);

            if (token && keyMatch && items.length < maxResults) {
                const apiKey = keyMatch[1];
                const clientVersion = clientVerMatch ? clientVerMatch[1] : "2.20261002.01.00";
                
                try {
                    for (let pageNum = 0; pageNum < 4 && token && items.length < maxResults; pageNum++) {
                        const postData = JSON.stringify({
                            context: {
                                client: {
                                    clientName: "WEB",
                                    clientVersion: clientVersion,
                                    hl: "en",
                                    gl: "US"
                                }
                            },
                            continuation: token
                        });
                        const res2 = await Net.request("https://www.youtube.com/youtubei/v1/search?key=" + apiKey, {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json"
                            },
                            body: postData
                        });
                        if (res2 && res2.ok) {
                            const pData = await res2.json();
                            const prevCount = items.length;
                            walk(pData);
                            if (items.length > prevCount && typeof options.onBatch === "function") {
                                try { options.onBatch(items.slice()); } catch (_) {}
                            }
                            token = null;
                            findToken(pData);
                        } else {
                            break;
                        }
                    }
                } catch (_) {}
            }

            return { items: items, total: items.length, page: 1, hasMore: false };
        } catch (err) {
            console.warn("YouTube search error:", err);
            return { items: [], total: 0, error: err.message };
        }
    }

    return {
        searchVideos: searchVideos
    };
})();

if (typeof module !== "undefined" && module.exports) {
    module.exports = YouTubeAPI;
} else {
    window.YouTubeAPI = YouTubeAPI;
}
