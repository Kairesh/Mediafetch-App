/**
 * MediaFetch Universal Songs & Music Engine
 * Provides comprehensive music search across Songs, Albums, Artists, and Playlists.
 * Dual-Mode: Keyless Public Music Catalog (Default, 0 setup, unblockable) + Official Spotify Web API (Optional in Settings)
 */
const SongsAPI = (function () {
    let spotifyToken = "";
    let spotifyTokenExpiry = 0;

    function getSpotifyCredentials() {
        if (typeof Settings === "undefined") return { clientId: "", clientSecret: "" };
        const clientId = (Settings.get("spotifyClientId") || "").trim();
        const clientSecret = (Settings.get("spotifyClientSecret") || "").trim();
        return { clientId, clientSecret };
    }

    async function getSpotifyAccessToken() {
        const { clientId, clientSecret } = getSpotifyCredentials();
        if (!clientId || !clientSecret) return "";

        if (spotifyToken && Date.now() < spotifyTokenExpiry) {
            return spotifyToken;
        }

        try {
            const authStr = typeof btoa !== "undefined"
                ? btoa(`${clientId}:${clientSecret}`)
                : Buffer.from(`${clientId}:${clientSecret}`).toString("base64");

            const res = await Net.request("https://accounts.spotify.com/api/token", {
                method: "POST",
                headers: {
                    "Authorization": `Basic ${authStr}`,
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                body: "grant_type=client_credentials"
            });

            if (res && res.ok) {
                const data = await res.json();
                if (data && data.access_token) {
                    spotifyToken = data.access_token;
                    spotifyTokenExpiry = Date.now() + ((data.expires_in || 3600) - 120) * 1000;
                    return spotifyToken;
                }
            }
        } catch (err) {
            console.warn("[SongsAPI] Spotify token acquisition notice:", err);
        }
        return "";
    }

    function formatDuration(ms) {
        if (!ms || isNaN(ms)) return "3:30";
        const sec = Math.floor(ms / 1000);
        const m = Math.floor(sec / 60);
        const s = sec % 60;
        return `${m}:${s < 10 ? '0' : ''}${s}`;
    }

    function getHighResArt(url, size = 600) {
        if (!url) return "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=600";
        return url.replace(/\/\d+x\d+bb\./, `/${size}x${size}bb.`);
    }

    function getDefaultAudioQualities(trackTitle, artist) {
        const downloadQuery = `${trackTitle} ${artist} audio`.trim();
        return [
            { id: "mp3_320", label: "320 kbps (Ultra MP3)", format: "mp3", bitrate: 320, query: downloadQuery },
            { id: "wav_lossless", label: "WAV (Lossless 24-bit)", format: "wav", bitrate: 0, query: downloadQuery },
            { id: "mp3_256", label: "256 kbps (High MP3)", format: "mp3", bitrate: 256, query: downloadQuery },
            { id: "mp3_192", label: "192 kbps (Standard)", format: "mp3", bitrate: 192, query: downloadQuery }
        ];
    }

    /**
     * Search via iTunes Public Music Catalog (Zero Key, 100M+ songs, instant)
     */
    async function searchKeylessCatalog(query, filter = "all", limit = 50) {
        const clean = encodeURIComponent(query.trim());
        const results = [];

        try {
            if (filter === "songs" || filter === "all") {
                const songUrl = `https://itunes.apple.com/search?term=${clean}&entity=song&limit=${filter === 'all' ? 25 : limit}`;
                const res = await Net.request(songUrl);
                if (res && res.ok) {
                    const data = await res.json();
                    if (data && data.results) {
                        data.results.forEach((t) => {
                            results.push({
                                id: `song_${t.trackId}`,
                                rawId: t.trackId,
                                type: "audio",
                                subtype: "song",
                                badge: "SONG",
                                title: t.trackName || "Untitled Track",
                                author: t.artistName || "Unknown Artist",
                                album: t.collectionName || "",
                                durationFormatted: formatDuration(t.trackTimeMillis),
                                durationSeconds: Math.round((t.trackTimeMillis || 210000) / 1000),
                                thumbnail: getHighResArt(t.artworkUrl100, 600),
                                hoverPreviewUrl: t.previewUrl || "",
                                pageUrl: t.trackViewUrl || `https://music.apple.com/search?term=${clean}`,
                                source: "songs",
                                sourceLabel: "Song",
                                qualities: getDefaultAudioQualities(t.trackName, t.artistName)
                            });
                        });
                    }
                }
            }

            if (filter === "artists" || filter === "all") {
                const artistUrl = `https://itunes.apple.com/search?term=${clean}&entity=musicArtist&limit=${filter === 'all' ? 6 : limit}`;
                const res = await Net.request(artistUrl);
                if (res && res.ok) {
                    const data = await res.json();
                    if (data && data.results) {
                        data.results.forEach((a) => {
                            // Find corresponding artist art from first top song match
                            results.push({
                                id: `artist_${a.artistId}`,
                                rawId: a.artistId,
                                type: "audio",
                                subtype: "artist",
                                badge: "ARTIST",
                                title: a.artistName || "Unknown Artist",
                                author: a.primaryGenreName ? `${a.primaryGenreName} Artist` : "Verified Artist",
                                album: "Artist Discography",
                                durationFormatted: "Explore Hits",
                                durationSeconds: 0,
                                thumbnail: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=600",
                                hoverPreviewUrl: "",
                                pageUrl: a.artistLinkUrl || `https://music.apple.com/search?term=${clean}`,
                                source: "songs",
                                sourceLabel: "Artist",
                                qualities: []
                            });
                        });
                    }
                }
            }

            if (filter === "albums" || filter === "all") {
                const albumUrl = `https://itunes.apple.com/search?term=${clean}&entity=album&limit=${filter === 'all' ? 12 : limit}`;
                const res = await Net.request(albumUrl);
                if (res && res.ok) {
                    const data = await res.json();
                    if (data && data.results) {
                        data.results.forEach((al) => {
                            results.push({
                                id: `album_${al.collectionId}`,
                                rawId: al.collectionId,
                                type: "audio",
                                subtype: "album",
                                badge: "ALBUM",
                                title: al.collectionName || "Untitled Album",
                                author: al.artistName || "Unknown Artist",
                                album: al.collectionName || "",
                                durationFormatted: `${al.trackCount || 10} Tracks`,
                                durationSeconds: 0,
                                thumbnail: getHighResArt(al.artworkUrl100, 600),
                                hoverPreviewUrl: "",
                                pageUrl: al.collectionViewUrl || `https://music.apple.com/search?term=${clean}`,
                                source: "songs",
                                sourceLabel: "Album",
                                qualities: []
                            });
                        });
                    }
                }
            }

            if (filter === "playlists") {
                // Return curated popular music sets & collections for the query
                const plUrl = `https://itunes.apple.com/search?term=${clean}&entity=album&limit=25`;
                const res = await Net.request(plUrl);
                if (res && res.ok) {
                    const data = await res.json();
                    if (data && data.results) {
                        data.results.forEach((pl) => {
                            results.push({
                                id: `playlist_${pl.collectionId}`,
                                rawId: pl.collectionId,
                                type: "audio",
                                subtype: "playlist",
                                badge: "PLAYLIST",
                                title: `${pl.collectionName || clean} (Curated Set)`,
                                author: pl.artistName || "Curated Playlist",
                                album: "Playlist Collection",
                                durationFormatted: `${pl.trackCount || 12} Songs`,
                                durationSeconds: 0,
                                thumbnail: getHighResArt(pl.artworkUrl100, 600),
                                hoverPreviewUrl: "",
                                pageUrl: pl.collectionViewUrl || "",
                                source: "songs",
                                sourceLabel: "Playlist",
                                qualities: []
                            });
                        });
                    }
                }
            }
        } catch (e) {
            console.error("[SongsAPI] Search error:", e);
        }

        return { items: results, total: results.length };
    }

    /**
     * Search via Official Spotify Web API (if client ID & secret configured)
     */
    async function searchSpotifyCatalog(token, query, filter = "all", limit = 50) {
        let typeStr = "track,album,artist,playlist";
        if (filter === "songs") typeStr = "track";
        if (filter === "albums") typeStr = "album";
        if (filter === "artists") typeStr = "artist";
        if (filter === "playlists") typeStr = "playlist";

        const url = `https://api.spotify.com/v1/search?q=${encodeURIComponent(query)}&type=${typeStr}&limit=${limit}`;
        const res = await Net.request(url, {
            headers: { "Authorization": `Bearer ${token}` }
        });

        if (!res || !res.ok) {
            throw new Error(`Spotify API returned HTTP ${res ? res.status : 'error'}`);
        }

        const data = await res.json();
        const results = [];

        // 1. Tracks (Songs)
        if (data.tracks && data.tracks.items) {
            data.tracks.items.forEach((t) => {
                const artistName = t.artists?.map(a => a.name).join(", ") || "Artist";
                const art = t.album?.images?.[0]?.url || t.album?.images?.[1]?.url || "";
                results.push({
                    id: `spotify_song_${t.id}`,
                    rawId: t.id,
                    type: "audio",
                    subtype: "song",
                    badge: "SONG",
                    title: t.name,
                    author: artistName,
                    album: t.album?.name || "",
                    durationFormatted: formatDuration(t.duration_ms),
                    durationSeconds: Math.round((t.duration_ms || 200000) / 1000),
                    thumbnail: art || "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=600",
                    hoverPreviewUrl: t.preview_url || "",
                    pageUrl: t.external_urls?.spotify || `https://open.spotify.com/track/${t.id}`,
                    source: "songs",
                    sourceLabel: "Spotify Track",
                    qualities: getDefaultAudioQualities(t.name, artistName)
                });
            });
        }

        // 2. Artists
        if (data.artists && data.artists.items) {
            data.artists.items.forEach((a) => {
                const art = a.images?.[0]?.url || a.images?.[1]?.url || "";
                results.push({
                    id: `spotify_artist_${a.id}`,
                    rawId: a.id,
                    type: "audio",
                    subtype: "artist",
                    badge: "ARTIST",
                    title: a.name,
                    author: `${a.followers?.total ? a.followers.total.toLocaleString() + ' Followers' : 'Verified Artist'}`,
                    album: "Spotify Discography",
                    durationFormatted: "Top Songs",
                    durationSeconds: 0,
                    thumbnail: art || "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=600",
                    hoverPreviewUrl: "",
                    pageUrl: a.external_urls?.spotify || `https://open.spotify.com/artist/${a.id}`,
                    source: "songs",
                    sourceLabel: "Spotify Artist",
                    qualities: []
                });
            });
        }

        // 3. Albums
        if (data.albums && data.albums.items) {
            data.albums.items.forEach((al) => {
                const artistName = al.artists?.map(a => a.name).join(", ") || "Artist";
                const art = al.images?.[0]?.url || al.images?.[1]?.url || "";
                results.push({
                    id: `spotify_album_${al.id}`,
                    rawId: al.id,
                    type: "audio",
                    subtype: "album",
                    badge: "ALBUM",
                    title: al.name,
                    author: artistName,
                    album: al.name,
                    durationFormatted: `${al.total_tracks || 10} Tracks`,
                    durationSeconds: 0,
                    thumbnail: art || "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=600",
                    hoverPreviewUrl: "",
                    pageUrl: al.external_urls?.spotify || `https://open.spotify.com/album/${al.id}`,
                    source: "songs",
                    sourceLabel: "Spotify Album",
                    qualities: []
                });
            });
        }

        // 4. Playlists
        if (data.playlists && data.playlists.items) {
            data.playlists.items.forEach((p) => {
                if (!p) return;
                const art = p.images?.[0]?.url || "";
                results.push({
                    id: `spotify_playlist_${p.id}`,
                    rawId: p.id,
                    type: "audio",
                    subtype: "playlist",
                    badge: "PLAYLIST",
                    title: p.name,
                    author: `By ${p.owner?.display_name || "Spotify"}`,
                    album: "Spotify Playlist",
                    durationFormatted: `${p.tracks?.total || 25} Tracks`,
                    durationSeconds: 0,
                    thumbnail: art || "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=600",
                    hoverPreviewUrl: "",
                    pageUrl: p.external_urls?.spotify || `https://open.spotify.com/playlist/${p.id}`,
                    source: "songs",
                    sourceLabel: "Spotify Playlist",
                    qualities: []
                });
            });
        }

        return { items: results, total: results.length };
    }

    return {
        /**
         * Main Search Method
         * @param {string} query Search keyword
         * @param {string} filter 'all' | 'songs' | 'albums' | 'artists' | 'playlists'
         * @param {number} limit Max results to harvest
         */
        search: async function (query, filter = "all", limit = 50) {
            if (!query || !query.trim()) return { items: [], total: 0 };

            // Check if user has Spotify credentials configured
            const token = await getSpotifyAccessToken();
            if (token) {
                try {
                    const spResults = await searchSpotifyCatalog(token, query, filter, limit);
                    if (spResults && spResults.items && spResults.items.length > 0) {
                        return spResults;
                    }
                } catch (spErr) {
                    console.warn("[SongsAPI] Spotify search failed, switching to keyless catalog fallback:", spErr.message);
                }
            }

            // High-throughput keyless music catalog
            return await searchKeylessCatalog(query, filter, limit);
        },

        /**
         * Lookup Top Songs for an Artist (Opens in Artist Modal)
         */
        getArtistTopTracks: async function (artistId, artistName) {
            const token = await getSpotifyAccessToken();
            if (token && String(artistId).startsWith("spotify_artist_")) {
                const raw = artistId.replace("spotify_artist_", "");
                try {
                    const res = await Net.request(`https://api.spotify.com/v1/artists/${raw}/top-tracks?market=US`, {
                        headers: { "Authorization": `Bearer ${token}` }
                    });
                    if (res && res.ok) {
                        const data = await res.json();
                        if (data && data.tracks) {
                            return data.tracks.map((t) => ({
                                id: `spotify_song_${t.id}`,
                                title: t.name,
                                artist: t.artists?.map(a => a.name).join(", ") || artistName,
                                album: t.album?.name || "",
                                duration: formatDuration(t.duration_ms),
                                durationSeconds: Math.round((t.duration_ms || 200000) / 1000),
                                thumbnail: t.album?.images?.[0]?.url || "",
                                previewUrl: t.preview_url || "",
                                qualities: getDefaultAudioQualities(t.name, artistName)
                            }));
                        }
                    }
                } catch (_) {}
            }

            // Keyless Artist Lookup via Apple Music index
            try {
                const numericId = String(artistId).replace("artist_", "").replace("spotify_artist_", "");
                const lookupUrl = `https://itunes.apple.com/lookup?id=${numericId}&entity=song&limit=30`;
                const res = await Net.request(lookupUrl);
                if (res && res.ok) {
                    const data = await res.json();
                    if (data && data.results) {
                        const tracks = data.results.filter(r => r.wrapperType === 'track');
                        return tracks.map((t) => ({
                            id: `song_${t.trackId}`,
                            title: t.trackName || "Track",
                            artist: t.artistName || artistName,
                            album: t.collectionName || "",
                            duration: formatDuration(t.trackTimeMillis),
                            durationSeconds: Math.round((t.trackTimeMillis || 200000) / 1000),
                            thumbnail: getHighResArt(t.artworkUrl100, 600),
                            previewUrl: t.previewUrl || "",
                            qualities: getDefaultAudioQualities(t.trackName, t.artistName)
                        }));
                    }
                }
            } catch (err) {
                console.error("[SongsAPI] Artist lookup error:", err);
            }

            // Fallback: search top songs by artist name
            const sRes = await searchKeylessCatalog(artistName, "songs", 25);
            return sRes.items.map(i => ({
                id: i.id,
                title: i.title,
                artist: i.author,
                album: i.album,
                duration: i.durationFormatted,
                durationSeconds: i.durationSeconds,
                thumbnail: i.thumbnail,
                previewUrl: i.hoverPreviewUrl,
                qualities: i.qualities
            }));
        },

        /**
         * Lookup Tracks for an Album (Opens in Album Modal)
         */
        getAlbumTracks: async function (albumId, albumName, artistName) {
            const token = await getSpotifyAccessToken();
            if (token && String(albumId).startsWith("spotify_album_")) {
                const raw = albumId.replace("spotify_album_", "");
                try {
                    const res = await Net.request(`https://api.spotify.com/v1/albums/${raw}/tracks?limit=50`, {
                        headers: { "Authorization": `Bearer ${token}` }
                    });
                    if (res && res.ok) {
                        const data = await res.json();
                        if (data && data.items) {
                            return data.items.map((t) => ({
                                id: `spotify_song_${t.id}`,
                                title: t.name,
                                artist: t.artists?.map(a => a.name).join(", ") || artistName,
                                album: albumName,
                                duration: formatDuration(t.duration_ms),
                                durationSeconds: Math.round((t.duration_ms || 200000) / 1000),
                                thumbnail: "",
                                previewUrl: t.preview_url || "",
                                qualities: getDefaultAudioQualities(t.name, artistName)
                            }));
                        }
                    }
                } catch (_) {}
            }

            // Keyless Album Lookup via Apple Music index
            try {
                const numericId = String(albumId).replace("album_", "").replace("spotify_album_", "");
                const lookupUrl = `https://itunes.apple.com/lookup?id=${numericId}&entity=song&limit=50`;
                const res = await Net.request(lookupUrl);
                if (res && res.ok) {
                    const data = await res.json();
                    if (data && data.results) {
                        const tracks = data.results.filter(r => r.wrapperType === 'track');
                        return tracks.map((t) => ({
                            id: `song_${t.trackId}`,
                            title: t.trackName || "Track",
                            artist: t.artistName || artistName,
                            album: t.collectionName || albumName,
                            duration: formatDuration(t.trackTimeMillis),
                            durationSeconds: Math.round((t.trackTimeMillis || 200000) / 1000),
                            thumbnail: getHighResArt(t.artworkUrl100, 600),
                            previewUrl: t.previewUrl || "",
                            qualities: getDefaultAudioQualities(t.trackName, t.artistName)
                        }));
                    }
                }
            } catch (err) {
                console.error("[SongsAPI] Album lookup error:", err);
            }
            return [];
        }
    };
})();
