/**
 * Giphy API Integration (Memes, Reactions & Animated GIFs/MP4s)
 */
const GiphyAPI = (function () {
    const BASE_URL = "https://api.giphy.com/v1";

    function getApiKey() {
        const userKey = typeof Settings !== "undefined" ? Settings.get("giphyApiKey") : "";
        if (userKey && typeof userKey === "string") {
            const k = userKey.trim();
            if (k && !k.includes("sXpGFDGZs0Dv1mmNFvYaGUvYwKX0P4W5")) {
                return k;
            }
        }
        return "";
    }

    async function searchGifs(query, options = {}) {
        const apiKey = getApiKey();
        if (!apiKey) return { items: [], total: 0 };
        const page = options.page || 1;
        const limit = options.perPage || 16;
        const offset = (page - 1) * limit;

        const url = `${BASE_URL}/gifs/search?api_key=${apiKey}&q=${encodeURIComponent(query)}&limit=${limit}&offset=${offset}&rating=pg-13`;

        try {
            const res = await fetch(url);
            if (!res.ok) throw new Error(`Giphy API error: ${res.status}`);
            const data = await res.json();

            const items = (data.data || []).map(g => {
                const formats = [];
                // Video editors love MP4 format because Premiere/AE timeline plays it smoothly
                if (g.images && g.images.original && g.images.original.mp4) {
                    formats.push({
                        label: "MP4 Video (Smooth Timeline)",
                        url: g.images.original.mp4,
                        ext: "mp4",
                        type: "video"
                    });
                }
                if (g.images && g.images.original && g.images.original.url) {
                    formats.push({
                        label: "Original GIF",
                        url: g.images.original.url,
                        ext: "gif",
                        type: "image"
                    });
                }

                // Low-res thumbnail for fast scrolling
                const thumb = (g.images && g.images.fixed_height_small && g.images.fixed_height_small.url)
                    || (g.images && g.images.preview_gif && g.images.preview_gif.url)
                    || (g.images && g.images.original && g.images.original.url);

                const hoverPreview = (g.images && g.images.fixed_height && g.images.fixed_height.mp4)
                    || (g.images && g.images.fixed_height && g.images.fixed_height.url);

                return {
                    id: "giphy_" + g.id,
                    source: "giphy",
                    type: "gif",
                    title: g.title || "Giphy Reaction Meme",
                    author: g.username || "Giphy Creator",
                    authorUrl: g.user ? g.user.profile_url : "",
                    thumbnail: thumb,
                    hoverPreviewUrl: hoverPreview,
                    downloadFormats: formats,
                    pageUrl: g.url
                };
            });

            return {
                items: items,
                total: (data.pagination && data.pagination.total_count) || items.length,
                page: page,
                hasMore: (offset + limit) < ((data.pagination && data.pagination.total_count) || 0)
            };
        } catch (err) {
            console.error("Giphy search failed:", err);
            return { items: [], total: 0, error: err.message };
        }
    }

    return {
        searchGifs: searchGifs
    };
})();

if (typeof module !== "undefined" && module.exports) {
    module.exports = GiphyAPI;
} else {
    window.GiphyAPI = GiphyAPI;
}
