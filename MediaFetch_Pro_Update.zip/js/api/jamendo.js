/**
 * Jamendo Music Community API
 * Direct access to 600,000+ royalty-free music tracks, background beats & soundtracks
 */
const JamendoAPI = (function () {
    const CLIENT_ID = "3dce8b55";
    const BASE_URL = "https://api.jamendo.com/v3.0/tracks/";

    function formatDuration(sec) {
        if (!sec || isNaN(sec)) return "Music";
        const m = Math.floor(sec / 60);
        const s = Math.floor(sec % 60).toString().padStart(2, "0");
        return `${m}:${s}`;
    }

    async function searchTracks(query, options = {}) {
        const limit = Math.max(5, Math.min(50, options.perPage || 40));
        const page = options.page || 1;
        const offset = (page - 1) * limit;
        const q = encodeURIComponent(query || "cinematic");
        const url = `${BASE_URL}?client_id=${CLIENT_ID}&format=jsonpretty&limit=${limit}&offset=${offset}&namesearch=${q}`;

        try {
            const data = await Net.getJson(url);
            const results = (data && data.results) || [];

            const items = results.map(t => {
                const durSec = t.duration || 0;
                const durStr = formatDuration(durSec);
                const mp3Url = t.audio || t.audiodownload || "";

                return {
                    id: "jamendo_" + t.id,
                    source: "Jamendo",
                    type: "audio",
                    title: t.name || `Jamendo Track #${t.id}`,
                    author: t.artist_name || "Jamendo Artist",
                    duration: durSec,
                    durationString: durStr,
                    thumbnail: t.album_image || t.image || "",
                    audioPreviewUrl: mp3Url,
                    downloadFormats: [
                        { label: "HQ MP3 Music (320kbps)", url: t.audiodownload || mp3Url, ext: "mp3", type: "audio" }
                    ],
                    pageUrl: t.shareurl || t.shorturl || `https://www.jamendo.com/track/${t.id}`
                };
            });

            return {
                items: items,
                total: (data && data.headers && data.headers.results_count) || items.length,
                page: page,
                hasMore: results.length >= limit
            };
        } catch (err) {
            console.warn("Jamendo search error:", err);
            return { items: [], total: 0, error: err.message };
        }
    }

    return {
        searchTracks: searchTracks
    };
})();

if (typeof module !== "undefined" && module.exports) {
    module.exports = JamendoAPI;
} else {
    window.JamendoAPI = JamendoAPI;
}
