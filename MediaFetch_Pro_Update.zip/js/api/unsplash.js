/**
 * Unsplash API Integration via Net module
 * Direct royalty-free high-res photography
 */
const UnsplashAPI = (function () {
    const BASE_URL = "https://api.unsplash.com";

    function getApiKey() {
        const userKey = typeof Settings !== "undefined" ? Settings.get("unsplashApiKey") : "";
        if (userKey && typeof userKey === "string") {
            const k = userKey.trim();
            if (k && !k.includes("k_U-aYk3j5Vz") && !k.includes("_Lo9ruec1rqQ_-ERrp_NHgqbfBdANyAzPYaSLwGdXh0")) {
                return k;
            }
        }
        return "";
    }

    async function searchPhotos(query, options = {}) {
        const apiKey = getApiKey();
        if (!apiKey) return { items: [], total: 0 };

        const page = options.page || 1;
        const perPage = Math.min(30, options.perPage || 30);
        let orientationParam = "";
        if (options.orientation === "landscape") orientationParam = "&orientation=landscape";
        else if (options.orientation === "portrait") orientationParam = "&orientation=portrait";

        let url1 = `${BASE_URL}/search/photos?query=${encodeURIComponent(query)}&page=${page}&per_page=${perPage}${orientationParam}`;
        let url2 = `${BASE_URL}/search/photos?query=${encodeURIComponent(query)}&page=${page + 1}&per_page=${perPage}${orientationParam}`;

        try {
            const reqs = [
                Net.request(url1, { headers: { Authorization: `Client-ID ${apiKey}` } })
            ];
            if (page === 1) {
                reqs.push(Net.request(url2, { headers: { Authorization: `Client-ID ${apiKey}` } }).catch(() => null));
            }
            const responses = await Promise.all(reqs);
            let rawResults = [];
            let totalCount = 0;

            for (const res of responses) {
                if (res && res.ok) {
                    const d = await res.json();
                    if (d && d.results) {
                        rawResults.push(...d.results);
                        totalCount = d.total || totalCount;
                    }
                }
            }
            if (rawResults.length === 0) return { items: [], total: 0 };

            const items = rawResults.map(p => {
                const formats = [
                    { label: `Raw Original (${p.width}x${p.height})`, url: p.urls.raw, ext: "jpg", type: "image" },
                    { label: "Full HD", url: p.urls.full, ext: "jpg", type: "image" },
                    { label: "Regular HD", url: p.urls.regular, ext: "jpg", type: "image" }
                ];

                const titleStr = p.description || p.alt_description || `Unsplash Photo #${p.id}`;

                return {
                    id: "unsplash_p_" + p.id,
                    source: "Unsplash",
                    type: "image",
                    title: titleStr.charAt(0).toUpperCase() + titleStr.slice(1),
                    author: p.user ? p.user.name : "Unsplash Artist",
                    authorUrl: p.user && p.user.links ? p.user.links.html : "",
                    thumbnail: p.urls.small || p.urls.thumb,
                    hoverPreviewUrl: p.urls.regular,
                    downloadFormats: formats,
                    pageUrl: p.links ? p.links.html : `https://unsplash.com/photos/${p.id}`
                };
            });

            return { items: items, total: totalCount || items.length, page: page, hasMore: false };
        } catch (err) {
            console.warn("Unsplash photo search error:", err);
            return { items: [], total: 0 };
        }
    }

    return {
        searchPhotos: searchPhotos
    };
})();

if (typeof module !== "undefined" && module.exports) {
    module.exports = UnsplashAPI;
} else {
    window.UnsplashAPI = UnsplashAPI;
}
