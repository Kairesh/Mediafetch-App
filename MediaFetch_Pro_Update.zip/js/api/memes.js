/**
 * Memes & Reaction Assets API
 * Includes 100+ High-Resolution Meme Templates (Imgflip) + Giphy Integration
 */
const MemesAPI = (function () {
    let cachedMemes = null;

    async function fetchAllMemes() {
        if (cachedMemes) return cachedMemes;
        try {
            const data = await Net.getJson("https://api.imgflip.com/get_memes");
            if (data.success && data.data && data.data.memes) {
                cachedMemes = data.data.memes;
                return cachedMemes;
            }
        } catch (e) {
            console.warn("Imgflip meme fetch failed:", e);
        }
        return [];
    }

    async function searchMemes(query, options = {}) {
        const memes = await fetchAllMemes();
        const q = (query || "").toLowerCase().trim();

        // If specific keyword, filter; if empty or generic, return top memes
        let filtered = memes;
        if (q && q !== "all" && q !== "meme" && q !== "memes") {
            const tokens = q.split(/\s+/);
            filtered = memes.filter(m => {
                const name = m.name.toLowerCase();
                return tokens.some(t => name.includes(t));
            });
            // If no strict match, return all
            if (filtered.length === 0) filtered = memes.slice(0, 30);
        }

        const items = filtered.slice(0, 24).map(m => {
            const ext = m.url.split(".").pop().split("?")[0] || "jpg";
            return {
                id: "meme_" + m.id,
                source: "meme template",
                type: "image",
                title: m.name,
                author: "Meme Community",
                thumbnail: m.url,
                hoverPreviewUrl: m.url,
                downloadFormats: [
                    { label: `Full HD (${m.width}x${m.height})`, url: m.url, ext: ext, type: "image" }
                ],
                pageUrl: m.url
            };
        });

        // Also check if user has Giphy key configured
        const giphyKey = typeof Settings !== "undefined" ? Settings.get("giphyApiKey") : "";
        if (giphyKey && typeof GiphyAPI !== "undefined") {
            try {
                const gResults = await GiphyAPI.searchGifs(query, options);
                if (gResults.items && gResults.items.length > 0) {
                    items.unshift(...gResults.items.slice(0, 10));
                }
            } catch (err) {
                // Ignore Giphy fallback error
            }
        }

        return { items: items, total: items.length, page: 1, hasMore: false };
    }

    return {
        searchMemes: searchMemes
    };
})();

if (typeof module !== "undefined" && module.exports) {
    module.exports = MemesAPI;
} else {
    window.MemesAPI = MemesAPI;
}
