/**
 * Soundboard SFX Engine
 * Curated bank of top viral video editor SFX + direct FreeSound query fallback
 */
const SoundboardAPI = (function () {
    const curatedSounds = [
        { title: "Vine Boom", author: "Soundboard", url: "https://cdn.pixabay.com/download/audio/2022/03/10/audio_c8c8a73467.mp3?filename=boom-geebs-101186.mp3", duration: "1s" },
        { title: "Bruh Sound Effect", author: "Meme SFX", url: "https://www.myinstants.com/media/sounds/bruh.mp3", duration: "1s" },
        { title: "Emotional Damage", author: "Steven He", url: "https://www.myinstants.com/media/sounds/emotional-damage-meme.mp3", duration: "2s" },
        { title: "Metal Pipe Falling", author: "Soundboard", url: "https://www.myinstants.com/media/sounds/metal-pipe-clang.mp3", duration: "2s" },
        { title: "FBI Open Up!", author: "Meme SFX", url: "https://www.myinstants.com/media/sounds/fbi-open-up_m2HAlca.mp3", duration: "3s" },
        { title: "Anime Wow Sound", author: "Anime SFX", url: "https://www.myinstants.com/media/sounds/anime-wow-sound-effect.mp3", duration: "1s" },
        { title: "Windows XP Error", author: "System SFX", url: "https://www.myinstants.com/media/sounds/windows-xp-error.mp3", duration: "1s" },
        { title: "Sad Violin", author: "Dramatic SFX", url: "https://www.myinstants.com/media/sounds/sad-violin.mp3", duration: "6s" },
        { title: "MLG Airhorn", author: "Gaming SFX", url: "https://www.myinstants.com/media/sounds/air-horn-club-sample_1.mp3", duration: "2s" },
        { title: "Drum Roll", author: "Percussion", url: "https://cdn.pixabay.com/download/audio/2022/03/15/audio_13a36db2e9.mp3?filename=drum-roll-5-228399.mp3", duration: "3s" },
        { title: "Record Scratch", author: "DJ Foley", url: "https://cdn.pixabay.com/download/audio/2021/08/04/audio_12b0c7443c.mp3?filename=scratch-1-100220.mp3", duration: "1s" },
        { title: "Huh? Cat Sound", author: "Cat SFX", url: "https://www.myinstants.com/media/sounds/huh_4.mp3", duration: "1s" },
        { title: "Discord Ping", author: "UI Sound", url: "https://www.myinstants.com/media/sounds/discord-notification.mp3", duration: "1s" },
        { title: "Cinematic Whoosh Transition", author: "Cinema Foley", url: "https://cdn.pixabay.com/download/audio/2022/01/18/audio_d0a13f69d2.mp3?filename=whoosh-6316.mp3", duration: "1s" },
        { title: "Heavy Cinematic Sub Bass Impact", author: "Cinema Foley", url: "https://cdn.pixabay.com/download/audio/2022/03/10/audio_c8c8a73467.mp3?filename=sub-impact.mp3", duration: "2s" },
        { title: "Cartoon Boing Jump", author: "Animation SFX", url: "https://cdn.pixabay.com/download/audio/2022/03/15/audio_c7694ff8a3.mp3?filename=boing-43868.mp3", duration: "1s" },
        { title: "Tada! Fanfare Win", author: "Soundboard", url: "https://cdn.pixabay.com/download/audio/2021/08/04/audio_3d1a89cbb6.mp3?filename=tada-fanfare-a-6313.mp3", duration: "2s" },
        { title: "Camera Shutter Click", author: "Foley SFX", url: "https://cdn.pixabay.com/download/audio/2022/01/18/audio_29e31d4560.mp3?filename=camera-shutter-6305.mp3", duration: "1s" },
        { title: "Glitch Digital Static", author: "Tech SFX", url: "https://cdn.pixabay.com/download/audio/2022/03/15/audio_e6e580e7d5.mp3?filename=glitch-sound-effect-9-192536.mp3", duration: "1s" },
        { title: "Slap Sound Effect", author: "Punch SFX", url: "https://www.myinstants.com/media/sounds/slap-sound-effect-free.mp3", duration: "1s" }
    ];

    async function searchSounds(query, options = {}) {
        const q = (query || "").toLowerCase().trim();
        let matched = curatedSounds;

        if (q && q !== "all" && q !== "sfx" && q !== "sound" && q !== "soundboard") {
            const tokens = q.split(/\s+/);
            matched = curatedSounds.filter(s => {
                const t = s.title.toLowerCase();
                return tokens.some(token => t.includes(token));
            });
        }

        const items = matched.map((s, idx) => ({
            id: "sfx_curated_" + idx,
            source: "soundboard sfx",
            type: "audio",
            title: s.title,
            author: s.author,
            durationString: s.duration,
            thumbnail: "",
            audioPreviewUrl: s.url,
            downloadFormats: [
                { label: "HQ MP3 SFX", url: s.url, ext: "mp3", type: "audio" }
            ],
            pageUrl: s.url
        }));

        // Also query Openverse Audio if query was specific and we want more results
        if (q && q !== "all" && typeof OpenverseAPI !== "undefined") {
            try {
                const openRes = await OpenverseAPI.searchAudio(query, { perPage: 12 });
                if (openRes.items && openRes.items.length > 0) {
                    items.push(...openRes.items);
                }
            } catch (e) {
                // Ignore fallback error
            }
        }

        return { items: items, total: items.length, page: 1, hasMore: false };
    }

    return {
        searchSounds: searchSounds
    };
})();

if (typeof module !== "undefined" && module.exports) {
    module.exports = SoundboardAPI;
} else {
    window.SoundboardAPI = SoundboardAPI;
}
