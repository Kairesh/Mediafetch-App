(() => {
  var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
    get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
  }) : x)(function(x) {
    if (typeof require !== "undefined") return require.apply(this, arguments);
    throw Error('Dynamic require of "' + x + '" is not supported');
  });

  // src/ui/services/client.ts
  function cleanExt(p) {
    if (!p) return "";
    let s = String(p);
    try {
      s = decodeURIComponent(s);
    } catch (_) {
    }
    s = s.replace(/^file:[\\\/]+/, "");
    if (/^[\\\/]?[A-Za-z]:/.test(s)) {
      s = s.replace(/^[\\\/]([A-Za-z]:)/, "");
      return s.replace(/\//g, "\\");
    }
    if (!s.startsWith("/") && !s.startsWith("\\")) s = "/" + s;
    return s;
  }
  var ServiceClient = class {
    ws;
    port = 48924;
    isConnected = false;
    listeners = [];
    reconnectTimer;
    statusListeners = [];
    constructor(preferredPort = 48924) {
      this.port = preferredPort;
    }
    isOnline() {
      return this.isConnected;
    }
    onStatusChanged(cb) {
      this.statusListeners.push(cb);
      cb(this.isConnected);
    }
    subscribe(listener) {
      this.listeners.push(listener);
      return () => {
        this.listeners = this.listeners.filter((l) => l !== listener);
      };
    }
    notifyStatus(online) {
      this.isConnected = online;
      for (const cb of this.statusListeners) {
        cb(online);
      }
    }
    notifyListeners(msg) {
      for (const l of this.listeners) {
        try {
          l(msg);
        } catch (err) {
          console.error("Error in message listener:", err);
        }
      }
    }
    pendingQueue = [];
    connect() {
      if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
        return;
      }
      try {
        this.ws = new WebSocket(`ws://127.0.0.1:${this.port}`);
        this.ws.onopen = () => {
          console.log("Connected to MediaFetch service daemon.");
          this.notifyStatus(true);
          this.autoStartAttempts = 0;
          if (this.reconnectTimer) {
            clearTimeout(this.reconnectTimer);
            this.reconnectTimer = void 0;
          }
          while (this.pendingQueue.length > 0) {
            const m = this.pendingQueue.shift();
            if (m) {
              try {
                this.ws?.send(JSON.stringify(m));
              } catch (_) {
              }
            }
          }
          try {
            if (typeof window !== "undefined" && window.mediaFetchApp?.checkPendingImports) {
              window.mediaFetchApp.checkPendingImports();
            }
          } catch (_) {
          }
        };
        this.ws.onmessage = (event) => {
          try {
            const parsed = JSON.parse(event.data);
            if (parsed && (parsed.type === "ANALYSIS_SUCCESS" || parsed.type === "METADATA_RESULT" || parsed.type === "PLAYLIST_ANALYSIS_SUCCESS" || parsed.type === "PLAYLIST_METADATA_RESULT" || parsed.type === "ANALYSIS_ERROR" || parsed.type === "ANALYSIS_FAILED" || parsed.type === "PLAYLIST_ANALYSIS_ERROR")) {
              if (this._analysisFallbackTimer) {
                clearTimeout(this._analysisFallbackTimer);
                this._analysisFallbackTimer = void 0;
              }
            }
            this.notifyListeners(parsed);
          } catch (e) {
            console.error("Failed to parse WebSocket message:", e);
          }
        };
        this.ws.onclose = () => {
          this.notifyStatus(false);
          this.tryAutoStartDaemon();
          this.scheduleReconnect();
        };
        this.ws.onerror = () => {
          this.notifyStatus(false);
          this.tryAutoStartDaemon();
        };
      } catch {
        this.notifyStatus(false);
        this.tryAutoStartDaemon();
        this.scheduleReconnect();
      }
    }
    autoStartAttempts = 0;
    lastAutoStartReset = Date.now();
    tryAutoStartDaemon(force = false) {
      if (force || Date.now() - this.lastAutoStartReset > 15e3) {
        this.autoStartAttempts = 0;
        this.lastAutoStartReset = Date.now();
      }
      if (this.autoStartAttempts > 10) return;
      this.autoStartAttempts++;
      try {
        if (typeof window !== "undefined") {
          const nodeRequire = window.require || window.cep_node?.require;
          if (nodeRequire) {
            let cleanExt2 = function(p) {
              if (!p) return "";
              let s = String(p);
              try {
                s = decodeURIComponent(s);
              } catch (_) {
              }
              s = s.replace(/^file:[\\\/]+/, "");
              if (/^[\\\/]?[A-Za-z]:/.test(s)) {
                s = s.replace(/^[\\\/]([A-Za-z]:)/, "");
                return s.replace(/\//g, "\\");
              }
              if (!s.startsWith("/") && !s.startsWith("\\")) s = "/" + s;
              return s;
            };
            const path = nodeRequire("path");
            const fs = nodeRequire("fs");
            let proc = null;
            try {
              proc = typeof process !== "undefined" ? process : nodeRequire("process");
            } catch {
            }
            const appData = proc?.env?.APPDATA || "";
            const localAppData = proc?.env?.LOCALAPPDATA || "";
            let extDir = "";
            try {
              if (window.__adobe_cep__?.getSystemPath) {
                extDir = cleanExt2(window.__adobe_cep__.getSystemPath("extension"));
              } else if (window.CSInterface) {
                extDir = cleanExt2(new window.CSInterface().getSystemPath("extension"));
              }
            } catch {
            }
            if (!extDir && window.location && window.location.pathname) {
              let p = cleanExt2(window.location.pathname);
              extDir = p.substring(0, Math.max(p.lastIndexOf("/"), p.lastIndexOf("\\")));
            }
            const candidates = [
              extDir ? path.join(extDir, "service", "server.bundle.js") : "",
              extDir ? path.join(extDir, "service", "server.js") : "",
              appData ? path.join(appData, "Adobe", "CEP", "extensions", "com.mediafetch.adobe.pro", "service", "server.bundle.js") : "",
              appData ? path.join(appData, "Adobe", "CEP", "extensions", "com.mediafetch.adobe.pro", "service", "server.js") : "",
              appData ? path.join(appData, "Adobe", "CEP", "extensions", "com.mediafetch.adobe", "service", "server.bundle.js") : "",
              appData ? path.join(appData, "Adobe", "CEP", "extensions", "com.mediafetch.adobe", "service", "server.js") : "",
              appData ? path.join(appData, "Adobe", "CEP", "extensions", "com.mediafetch.adobe.beta", "service", "server.bundle.js") : "",
              appData ? path.join(appData, "Adobe", "CEP", "extensions", "com.mediafetch.adobe.beta", "service", "server.js") : "",
              "C:\\Program Files (x86)\\Common Files\\Adobe\\CEP\\extensions\\com.mediafetch.adobe.pro\\service\\server.bundle.js",
              "C:\\Program Files (x86)\\Common Files\\Adobe\\CEP\\extensions\\com.mediafetch.adobe\\service\\server.bundle.js",
              "C:\\Program Files\\Common Files\\Adobe\\CEP\\extensions\\com.mediafetch.adobe.pro\\service\\server.bundle.js",
              "C:\\Program Files\\Common Files\\Adobe\\CEP\\extensions\\com.mediafetch.adobe\\service\\server.bundle.js",
              "/Library/Application Support/Adobe/CEP/extensions/com.mediafetch.adobe.pro/service/server.bundle.js",
              "/Library/Application Support/Adobe/CEP/extensions/com.mediafetch.adobe/service/server.bundle.js",
              localAppData ? path.join(localAppData, "MediaFetchPro", "server.bundle.js") : "",
              localAppData ? path.join(localAppData, "MediaFetchPro", "server.js") : ""
            ].filter(Boolean);
            const nodeExecutables = [
              "C:\\Program Files\\Common Files\\Adobe\\Creative Cloud Libraries\\libs\\node.exe",
              "C:\\Program Files (x86)\\Common Files\\Adobe\\Creative Cloud Libraries\\libs\\node.exe",
              "C:\\Program Files\\Adobe\\Adobe Creative Cloud Experience\\libs\\node.exe",
              "C:\\Program Files (x86)\\Adobe\\Adobe Creative Cloud Experience\\libs\\node.exe",
              "/Library/Application Support/Adobe/Creative Cloud Libraries/libs/node",
              "/Applications/Utilities/Adobe Creative Cloud Experience/libs/node",
              localAppData ? path.join(localAppData, "Programs", "nodejs", "node.exe") : "",
              appData ? path.join(appData, "nvm", "current", "node.exe") : "",
              "C:\\Program Files\\nodejs\\node.exe",
              "C:\\Program Files (x86)\\nodejs\\node.exe",
              "C:\\ProgramData\\chocolatey\\bin\\node.exe",
              localAppData ? path.join(localAppData, "Programs", "scoop", "shims", "node.exe") : "",
              "/opt/homebrew/bin/node",
              "/usr/local/bin/node",
              "/usr/bin/node",
              "node"
            ].filter((exe) => {
              if (!exe) return false;
              if (exe === "node") return true;
              try {
                return fs.existsSync(exe);
              } catch (_) {
                return false;
              }
            });
            const logDir = localAppData ? path.join(localAppData, "MediaFetch", "logs") : "";
            let outFd = "ignore";
            if (logDir) {
              try {
                fs.mkdirSync(logDir, { recursive: true });
              } catch (_) {
              }
              try {
                outFd = fs.openSync(path.join(logDir, "service.log"), "a");
              } catch (_) {
              }
            }
            for (const candidate of candidates) {
              if (fs.existsSync(candidate)) {
                console.log("[MediaFetch] Attempting auto-start from:", candidate);
                try {
                  const cp = nodeRequire("child_process");
                  for (const nodeExe of nodeExecutables) {
                    if (nodeExe !== "node") {
                      try {
                        if (!fs.existsSync(nodeExe)) continue;
                      } catch (_) {
                        continue;
                      }
                    }
                    try {
                      const child = cp.spawn(nodeExe, ["--expose-gc", "--max-old-space-size=512", candidate], {
                        detached: true,
                        stdio: ["ignore", outFd, outFd],
                        windowsHide: true,
                        env: { ...proc?.env, PORT: "48924" }
                      });
                      child.on("error", (err) => {
                        console.warn(`[MediaFetch] Daemon spawn error on ${nodeExe}:`, err);
                      });
                      child.unref();
                      console.log(`[MediaFetch] Spawned daemon with ${nodeExe}: ${candidate}`);
                      setTimeout(() => this.connect(), 600);
                      setTimeout(() => this.connect(), 1200);
                      return;
                    } catch {
                    }
                  }
                } catch {
                }
                if (nodeRequire) {
                  try {
                    console.log("[MediaFetch] Starting embedded in-process service from client supervisor:", candidate);
                    const srvModule = nodeRequire(candidate);
                    if (srvModule) {
                      if (typeof srvModule.startInProcessServer === "function") {
                        srvModule.startInProcessServer(48924);
                      } else if (srvModule.MediaFetchServer && !(window.__mediaFetchServerInstance || globalThis.__mediaFetchServerInstance)) {
                        const inst = new srvModule.MediaFetchServer(48924);
                        window.__mediaFetchServerInstance = inst;
                        inst.start().catch((e) => console.warn("[MediaFetch] In-process server start notice:", e));
                      }
                    }
                    setTimeout(() => this.connect(), 400);
                    setTimeout(() => this.connect(), 1e3);
                    return;
                  } catch (err) {
                    console.error("[MediaFetch] In-process start failed:", err);
                  }
                }
              }
            }
          }
        }
      } catch (e) {
        console.warn("[MediaFetch] Auto-start daemon error:", e);
      }
    }
    supervisorInterval;
    startSupervisor() {
      if (this.supervisorInterval) return;
      this.supervisorInterval = window.setInterval(async () => {
        if (!this.isConnected) {
          this.tryAutoStartDaemon();
          this.connect();
        } else {
          try {
            const res = await fetch(`http://127.0.0.1:${this.port}/api/health`, { cache: "no-store" }).catch(() => null);
            if (!res || !res.ok) {
              console.warn("[MediaFetch] Service health ping failed, attempting restart...");
              this.tryAutoStartDaemon(true);
            }
          } catch (_) {
          }
        }
      }, 1e4);
    }
    scheduleReconnect() {
      if (this.reconnectTimer) return;
      this.reconnectTimer = window.setTimeout(() => {
        this.reconnectTimer = void 0;
        this.connect();
      }, 1200);
    }
    send(msg) {
      msg.edition = "pro";
      if (msg.payload && typeof msg.payload === "object") {
        msg.payload.edition = "pro";
      }
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        try {
          this.ws.send(JSON.stringify(msg));
          return;
        } catch (err) {
          console.warn("[MediaFetch] ws.send error, queueing message:", err);
        }
      }
      this.pendingQueue.push(msg);
      this.connect();
      this.tryAutoStartDaemon(true);
    }
    markItemImported(id, ok, error) {
      this.send({
        type: "ITEM_IMPORTED",
        payload: { id, ok, error }
      });
    }
    inProcessAnalysisActive = false;
    async runInProcessAnalysis(url, timeoutMs = 25e3) {
      if (this.inProcessAnalysisActive) return;
      if (typeof window === "undefined") return;
      const nodeRequire = window.require || window.cep_node?.require;
      if (!nodeRequire) return;
      this.inProcessAnalysisActive = true;
      try {
        let extDir = "";
        try {
          if (window.__adobe_cep__?.getSystemPath) {
            extDir = cleanExt(window.__adobe_cep__.getSystemPath("extension"));
          } else if (window.CSInterface) {
            extDir = cleanExt(new window.CSInterface().getSystemPath("extension"));
          }
        } catch (_) {
        }
        if (!extDir && window.location && window.location.pathname) {
          let p = cleanExt(window.location.pathname);
          extDir = p.substring(0, Math.max(p.lastIndexOf("/"), p.lastIndexOf("\\")));
        }
        const path = nodeRequire("path");
        const fs = nodeRequire("fs");
        const candidates = [
          extDir ? path.join(extDir, "service", "server.bundle.js") : "",
          extDir ? path.join(extDir, "service", "server.js") : "",
          extDir ? path.join(extDir, "service", "analyzer.js") : ""
        ].filter(Boolean);
        let analyzer = null;
        for (const cand of candidates) {
          if (fs.existsSync(cand)) {
            try {
              if (nodeRequire.cache) {
                try {
                  const resolved = nodeRequire.resolve(cand);
                  if (nodeRequire.cache[resolved]) delete nodeRequire.cache[resolved];
                } catch (_) {}
                if (nodeRequire.cache[cand]) delete nodeRequire.cache[cand];
              }
              const mod = nodeRequire(cand);
              if (mod && (mod.metadataAnalyzer || mod.MetadataAnalyzer)) {
                analyzer = mod.metadataAnalyzer || (mod.MetadataAnalyzer ? new mod.MetadataAnalyzer() : null);
                break;
              }
            } catch (_) {
            }
          }
        }
        if (!analyzer) return;
        console.log("[MediaFetch] Running high-speed in-process analysis for:", url);
        this.notifyListeners({ type: "ANALYSIS_STARTED", payload: { url } });
        if (analyzer.isPlaylistUrl(url)) {
          const playlist = await analyzer.analyzePlaylist(url, timeoutMs);
          this.notifyListeners({ type: "PLAYLIST_ANALYSIS_SUCCESS", payload: playlist });
          this.notifyListeners({ type: "PLAYLIST_METADATA_RESULT", payload: playlist });
        } else {
          const meta = await analyzer.analyzeUrl(url, timeoutMs);
          if (meta.isPlaylist || meta.isCarousel) {
            this.notifyListeners({ type: "PLAYLIST_ANALYSIS_SUCCESS", payload: meta });
            this.notifyListeners({ type: "PLAYLIST_METADATA_RESULT", payload: meta });
          } else {
            this.notifyListeners({ type: "ANALYSIS_SUCCESS", payload: meta });
            this.notifyListeners({ type: "METADATA_RESULT", payload: meta });
          }
        }
      } catch (err) {
        console.warn("[MediaFetch] In-process analysis notice:", err?.message || err);
        this.notifyListeners({
          type: "ANALYSIS_ERROR",
          payload: { url, error: err?.message || "Analysis failed", details: err?.details, category: err?.category || "EXTRACTION_ERROR" }
        });
      } finally {
        this.inProcessAnalysisActive = false;
      }
    }
    analyzeUrl(url, timeoutMs = 45e3) {
      if (typeof window !== "undefined" && (window.require || window.cep_node?.require)) {
        this.runInProcessAnalysis(url, timeoutMs);
      }
      if (this.isConnected) {
        this.send({ type: "ANALYZE_URL", payload: { url, timeoutMs } });
      }
    }
    analyzePlaylist(url, timeoutMs = 45e3) {
      if (typeof window !== "undefined" && (window.require || window.cep_node?.require)) {
        this.runInProcessAnalysis(url, timeoutMs);
      }
      if (this.isConnected) {
        this.send({ type: "ANALYZE_PLAYLIST", payload: { url, timeoutMs } });
      }
    }
    startDownload(url, profile, projectContext, targetDirectory, metadata) {
      const isPro = window.__MF_EDITION__ === "pro" || window.location.pathname.includes(".pro") || document.title.includes("Pro");
      const edition = isPro ? "pro" : "standard";
      const targetHost = window.__MF_HOST_ID__ || typeof window.hostAdapter !== "undefined" && window.hostAdapter.hostId || "ppro";
      this.send({
        type: "START_DOWNLOAD",
        payload: { url, profile, projectContext, targetDirectory, metadata: { ...metadata || {}, edition, targetHost }, edition, targetHost }
      });
    }
    startPlaylistDownload(items, profile, projectContext, targetDirectory, options) {
      const isPro = window.__MF_EDITION__ === "pro" || window.location.pathname.includes(".pro") || document.title.includes("Pro");
      const edition = isPro ? "pro" : "standard";
      const targetHost = window.__MF_HOST_ID__ || typeof window.hostAdapter !== "undefined" && window.hostAdapter.hostId || "ppro";
      this.send({
        type: "START_PLAYLIST_DOWNLOAD",
        payload: {
          items,
          profile,
          projectContext,
          targetDirectory,
          customFolderName: options?.customFolderName,
          preserveSubfolders: options?.preserveSubfolders,
          autoImport: options?.autoImport,
          zipPackage: options?.zipPackage,
          playlistTitle: options?.playlistTitle,
          isCloud: options?.isCloud,
          edition,
          targetHost
        }
      });
    }
    pauseDownload(id) {
      this.send({ type: "PAUSE_DOWNLOAD", payload: { id } });
    }
    resumeDownload(id) {
      this.send({ type: "RESUME_DOWNLOAD", payload: { id } });
    }
    cancelDownload(id) {
      this.send({ type: "CANCEL_DOWNLOAD", payload: { id } });
    }
    retryDownload(id) {
      this.send({ type: "RETRY_DOWNLOAD", payload: { id } });
    }
    clearCompleted() {
      const isPro = window.__MF_EDITION__ === "pro" || window.location.pathname.includes(".pro") || document.title.includes("Pro");
      const edition = isPro ? "pro" : "standard";
      this.send({ type: "CLEAR_COMPLETED", payload: { edition }, edition });
    }
    clearAll() {
      const isPro = window.__MF_EDITION__ === "pro" || window.location.pathname.includes(".pro") || document.title.includes("Pro");
      const edition = isPro ? "pro" : "standard";
      this.send({ type: "CLEAR_ALL", payload: { edition }, edition });
    }
    getSettings() {
      this.send({ type: "GET_SETTINGS" });
    }
    updateSettings(settings) {
      this.send({ type: "UPDATE_SETTINGS", payload: settings });
    }
    getDiagnostics() {
      this.send({ type: "GET_DIAGNOSTICS" });
    }
    runSystemCheck() {
      this.send({ type: "RUN_SYSTEM_CHECK" });
    }
    installDependency(name) {
      this.send({ type: "INSTALL_DEPENDENCY", payload: { name } });
    }
    updateYtDlp() {
      this.send({ type: "UPDATE_YTDLP" });
    }
    getHistory() {
      this.send({ type: "GET_HISTORY" });
    }
    clearHistory() {
      this.send({ type: "CLEAR_HISTORY" });
    }
    removeHistoryItem(id) {
      this.send({ type: "REMOVE_HISTORY_ITEM", payload: { id } });
    }
    checkDuplicate(title, container, targetDirectory) {
      this.send({
        type: "CHECK_DUPLICATE",
        payload: { title, container, targetDirectory }
      });
    }
    openFolderDialog() {
      this.send({ type: "OPEN_FOLDER_DIALOG" });
    }
  };
  var serviceClient = new ServiceClient();

  // src/host/ae-adapter.ts
  var AfterEffectsHostAdapter = class {
    themeListeners = [];
    async getProjectContext() {
      if (typeof getHostAppId === "function" && getHostAppId() === "ppro") {
        return new PremiereHostAdapter().getProjectContext();
      }
      try {
        const hostInfoResult = await this.evalScript("MediaFetchHost.getHostInfo()");
        if (hostInfoResult && typeof hostInfoResult === "string" && hostInfoResult !== "EvalScript error.") {
          try {
            const parsedHost = JSON.parse(hostInfoResult);
            if (parsedHost && parsedHost.projectPath && parsedHost.projectPath.length > 0) {
              const cleanPath = parsedHost.projectPath.replace(/\\/g, "/");
              const dir = cleanPath.substring(0, cleanPath.lastIndexOf("/"));
              const name = parsedHost.projectName || cleanPath.substring(cleanPath.lastIndexOf("/") + 1) || "After Effects Project";
              return {
                application: "aftereffects",
                applicationVersion: parsedHost.appVersion || "26.0",
                projectSaved: true,
                projectName: name,
                projectPath: parsedHost.projectPath,
                projectDirectory: dir.replace(/\//g, "\\")
              };
            }
          } catch (_) {
          }
        }
        const script = `
        (function() {
          try {
            if (app && app.project) {
              if (app.project.file && app.project.file.exists) {
                return JSON.stringify({
                  saved: true,
                  path: app.project.file.fsName,
                  name: app.project.file.displayName || "After Effects Project",
                  version: app.version || "26.0"
                });
              } else {
                return JSON.stringify({
                  saved: false,
                  name: "Active AE Project (Unsaved)",
                  version: app.version || "26.0"
                });
              }
            }
          } catch (err) {
            return JSON.stringify({ saved: false, error: String(err) });
          }
          return JSON.stringify({ saved: false });
        })();
      `;
        const result = await this.evalScript(script);
        if (result && typeof result === "string" && result !== "EvalScript error.") {
          const parsed = JSON.parse(result);
          if (parsed) {
            if (parsed.saved && parsed.path) {
              const cleanPath = parsed.path.replace(/\\/g, "/");
              const dir = cleanPath.substring(0, cleanPath.lastIndexOf("/"));
              const name = cleanPath.substring(cleanPath.lastIndexOf("/") + 1) || parsed.name;
              return {
                application: "aftereffects",
                applicationVersion: parsed.version || "26.0",
                projectSaved: true,
                projectName: name,
                projectPath: parsed.path,
                projectDirectory: dir.replace(/\//g, "\\")
              };
            } else if (parsed.name) {
              return {
                application: "aftereffects",
                applicationVersion: parsed.version || "26.0",
                projectSaved: false,
                projectName: parsed.name
              };
            }
          }
        }
      } catch (e) {
        console.warn("Error reading After Effects project context:", e);
      }
      return {
        application: "aftereffects",
        applicationVersion: "26.0",
        projectSaved: false
      };
    }
    async revealInFinder(filePath) {
      try {
        if (typeof window !== "undefined" && window.require) {
          const cp = window.require("child_process");
          if (cp?.exec) {
            cp.exec(`explorer.exe /select,"${filePath.replace(/\//g, "\\")}"`);
            return;
          }
        }
      } catch {
      }
      try {
        const script = `
        (function() {
          var f = new File("${filePath.replace(/\\/g, "/")}");
          if (f.exists) {
            f.execute();
          }
        })();
      `;
        await this.evalScript(script);
      } catch {
      }
    }
    async openFile(filePath) {
      await this.revealInFinder(filePath);
    }
    async importToProject(filePath, options) {
      if (typeof getHostAppId === "function" && getHostAppId() === "ppro") {
        return new PremiereHostAdapter().importToProject(filePath, options);
      }
      try {
        const cleanPath = filePath.replace(/\\/g, "/");
        const locMode = options?.downloadLocationMode || (options?.isCustomFlat ? "custom_flat" : options?.isCustomPath ? "custom" : "simple");
        const isCustomFlat = locMode === "custom_flat" || Boolean(options?.isCustomFlat);
        const isCustom = !isCustomFlat && (locMode === "custom" || Boolean(options?.isCustomPath));
        const isSimple = !isCustom && !isCustomFlat;
        const isCloud = options?.isCloud ? true : false;
        const isPlaylist = options?.isPlaylist ? true : false;
        const isBatch = options?.isBatch ? true : false;
        const isSingleLink = options?.isSingleLink !== void 0 ? options.isSingleLink : !isPlaylist && !isCloud && !isBatch;
        const shouldInsertTimeline = Boolean((options?.insertToTimeline || options?.addToTimeline || options?.isClipboard) && isSingleLink);
        const playlistTitle = (options?.playlistTitle || "").replace(/[\\/:"*?<>|]/g, " ").trim();
        const customFolderName = (options?.customFolderName || "").replace(/[\\/:"*?<>|]/g, " ").trim();
        const subFolderName = (options?.subFolderName || "").trim();
        const isClipboard = Boolean(options?.isClipboard || cleanPath.includes("Clipboard"));
        const optsJson = JSON.stringify({
          downloadLocationMode: locMode,
          isCustomPath: isCustom,
          isCustomFlat,
          isSimplePath: isSimple,
          isSimple,
          isCloud,
          isPlaylist,
          isBatch,
          isSingleLink,
          playlistTitle,
          customFolderName,
          subFolderName,
          isClipboard,
          addToTimeline: shouldInsertTimeline,
          insertToTimeline: shouldInsertTimeline
        });
        try {
          const evalResStr = await this.evalScript(`MediaFetchHost.importMedia(${JSON.stringify(cleanPath)}, ${shouldInsertTimeline ? "true" : "false"}, ${optsJson})`);
          if (evalResStr && evalResStr !== "EvalScript error.") {
            try {
              const parsed = JSON.parse(evalResStr);
              if (parsed && parsed.success && parsed.imported !== false) {
                console.log("[MediaFetch] AE HostScript importMedia succeeded:", parsed);
                return true;
              }
            } catch (_) {
              if (evalResStr === "true" || evalResStr === true) return true;
            }
          }
        } catch (hErr) {
          console.warn("[MediaFetch] AE MediaFetchHost.importMedia attempt notice:", hErr);
        }
        const script = `
        (function() {
          try {
            if (typeof app === "undefined" || !app.project) return "no_project";
            var proj = app.project;
            
            function getOrCreateAeFolder(proj, parentFolder, folderName) {
              for (var i = 1; i <= proj.numItems; i++) {
                var it = proj.item(i);
                if (it && (it instanceof FolderItem || it.typeName === "Folder") && it.name === folderName) {
                  if (!parentFolder && (!it.parentFolder || it.parentFolder === proj.rootFolder)) {
                    return it;
                  }
                  if (parentFolder && it.parentFolder === parentFolder) {
                    return it;
                  }
                }
              }
              var newFolder = null;
              try {
                newFolder = proj.items.addFolder(folderName);
                if (parentFolder && newFolder) {
                  newFolder.parentFolder = parentFolder;
                }
              } catch (_) {}
              return newFolder;
            }

            var targetPath = "${cleanPath}";
            var isCustom = ${isCustom ? "true" : "false"};
            var isCloud = ${isCloud ? "true" : "false"};
            var isPlaylist = ${isPlaylist ? "true" : "false"};
            var playlistTitle = "${playlistTitle.replace(/"/g, '\\"')}";
            var customFolderName = "${customFolderName.replace(/"/g, '\\"')}";
            var subFolderName = "${subFolderName.replace(/"/g, '\\"').replace(/\\/g, "/")}";

            var targetFolder = null;

            if (isCustom) {
              // Custom Directory: create root bin outside MediaFetch named after the selected custom folder
              var rootBinName = customFolderName || (isPlaylist ? (playlistTitle || "Playlist") : (isCloud ? "Cloud Media" : ""));
              if (!rootBinName) {
                var pParts = targetPath.split('/');
                rootBinName = pParts.length > 1 ? pParts[pParts.length - 2] : "Downloads";
              }
              var customRootFolder = getOrCreateAeFolder(proj, null, rootBinName);
              if (subFolderName) {
                var sParts = subFolderName.split('/');
                var cur = customRootFolder;
                for (var s = 0; s < sParts.length; s++) {
                  if (sParts[s] && sParts[s].length > 0) {
                    cur = getOrCreateAeFolder(proj, cur, sParts[s]);
                  }
                }
                targetFolder = cur || customRootFolder;
              } else {
                targetFolder = customRootFolder;
              }
            } else {
              // Default Project Path: inside root "MediaFetch" bin
              var mediaFetchFolder = getOrCreateAeFolder(proj, null, "MediaFetch");

              if (isCloud) {
                // MediaFetch -> Cloud Links -> [Cloud Folder Name] -> [Subfolders]
                var cloudRoot = getOrCreateAeFolder(proj, mediaFetchFolder, "Cloud Links");
                var cloudFolder = getOrCreateAeFolder(proj, cloudRoot, customFolderName || "Cloud Media");
                if (subFolderName) {
                  var sParts = subFolderName.split('/');
                  var cur = cloudFolder;
                  for (var s = 0; s < sParts.length; s++) {
                    if (sParts[s] && sParts[s].length > 0) {
                      cur = getOrCreateAeFolder(proj, cur, sParts[s]);
                    }
                  }
                  targetFolder = cur || cloudFolder;
                } else {
                  targetFolder = cloudFolder;
                }
              } else if (isPlaylist) {
                // MediaFetch -> Playlists -> [Playlist Name]
                var playlistRoot = getOrCreateAeFolder(proj, mediaFetchFolder, "Playlists");
                var pName = playlistTitle || customFolderName || "Playlist 1";
                targetFolder = getOrCreateAeFolder(proj, playlistRoot, pName);
              } else {
                // Single link or Search or Clipboard
                var isClipboard = ${isClipboard ? "true" : "false"} || targetPath.indexOf("Clipboard") !== -1;
                var isSearch = targetPath.indexOf("SerachMediafetch") !== -1 || 
                               targetPath.indexOf("MediaFetch Assets") !== -1 || 
                               targetPath.indexOf("MediaSearch Assets") !== -1;
                var categoryFolderName = isClipboard ? "Clipboard" : (isSearch ? "SerachMediafetch" : "LinkMediaFetch");
                var categoryFolder = getOrCreateAeFolder(proj, mediaFetchFolder, categoryFolderName);

                var parts = targetPath.split('.');
                var ext = parts.length > 1 ? parts[parts.length - 1].toLowerCase().split('?')[0] : '';
                var isAudio = (ext === 'mp3' || ext === 'wav' || ext === 'm4a' || ext === 'flac' || ext === 'aac' || ext === 'ogg' || ext === 'opus' || ext === 'aiff');
                var isImage = (ext === 'jpg' || ext === 'jpeg' || ext === 'png' || ext === 'webp' || ext === 'gif' || ext === 'bmp' || ext === 'tiff' || ext === 'tif' || ext === 'svg');
                var typeFolderName = isAudio ? "Audio" : (isImage ? "Images" : "Video");
                targetFolder = getOrCreateAeFolder(proj, categoryFolder, typeFolderName) || categoryFolder;
              }
            }

            var mediaFile = new File(targetPath);
            if (!mediaFile.exists) {
              mediaFile = new File(targetPath.replace(///g, '\\'));
            }
            if (!mediaFile.exists) {
              return "file_not_found: " + targetPath;
            }

            // Check if file is ALREADY imported in project (only return early if not inserting to timeline)
            if (!${shouldInsertTimeline ? "true" : "false"}) {
              for (var j = 1; j <= proj.numItems; j++) {
                var existingItem = proj.item(j);
                if (existingItem && existingItem.file && existingItem.file.fsName === mediaFile.fsName) {
                  return "true";
                }
              }
            }

            // Import media into target folder
            var importedItem = null;
            try {
              var io = new ImportOptions();
              io.file = mediaFile;
              importedItem = proj.importFile(io);
            } catch (_) {
              try {
                for (var j2 = 1; j2 <= proj.numItems; j2++) {
                  var ex = proj.item(j2);
                  if (ex && ex.file && ex.file.fsName === mediaFile.fsName) {
                    importedItem = ex;
                    break;
                  }
                }
              } catch (_) {}
            }
            if (importedItem) {
              importedItem.parentFolder = targetFolder || proj.rootFolder;
              if (${shouldInsertTimeline ? "true" : "false"}) {
                try {
                  var comp = proj.activeItem;
                  if (!comp || !(comp instanceof CompItem)) {
                    for (var cIdx = 1; cIdx <= proj.numItems; cIdx++) {
                      if (proj.item(cIdx) instanceof CompItem) {
                        comp = proj.item(cIdx);
                        break;
                      }
                    }
                  }
                  if (!comp || !(comp instanceof CompItem)) {
                    var w = (importedItem.width && importedItem.width > 0) ? importedItem.width : 1920;
                    var h = (importedItem.height && importedItem.height > 0) ? importedItem.height : 1080;
                    var dur = (importedItem.duration && importedItem.duration > 0) ? importedItem.duration : 30;
                    var fps = (importedItem.frameRate && importedItem.frameRate > 0) ? importedItem.frameRate : 30;
                    var rawName = importedItem.name || "MediaFetch Comp";
                    var dotIdx = rawName.lastIndexOf(".");
                    var cName = (dotIdx > 0) ? rawName.substring(0, dotIdx) : rawName;
                    comp = proj.items.addComposition(cName, w, h, 1.0, dur, fps);
                  }
                  if (comp && comp instanceof CompItem) {
                    var playheadTime = (comp.time !== undefined && comp.time !== null) ? comp.time : 0;
                    var minNextInPoint = Infinity;
                    var defaultDur = (importedItem.duration && importedItem.duration > 0) ? importedItem.duration : 5;
                    var targetDur = defaultDur;

                    // Only gap-fit image media: videos and audios keep their full natural length
                    if (isImage && !isPlaylist) {
                      for (var l2 = 1; l2 <= comp.numLayers; l2++) {
                        var exLay = comp.layer(l2);
                        if (!exLay) continue;
                        try {
                          if (exLay.locked) continue;
                          var lIn = exLay.inPoint;
                          if (lIn > playheadTime + 0.05) {
                            if (lIn < minNextInPoint) {
                              minNextInPoint = lIn;
                            }
                          }
                        } catch (_) {}
                      }
                      if (minNextInPoint !== Infinity && minNextInPoint > playheadTime + 0.05) {
                        var gap = minNextInPoint - playheadTime;
                        if (gap > 0.05) {
                          targetDur = gap;
                        }
                      }
                    }

                    var layer = comp.layers.add(importedItem);
                    if (layer) {
                      layer.startTime = playheadTime;
                      layer.inPoint = playheadTime;
                      layer.outPoint = playheadTime + targetDur;

                      var insertBelowIndex = 1;
                      for (var li = 1; li <= comp.numLayers; li++) {
                        var exTop = comp.layer(li);
                        if (exTop && exTop !== layer) {
                          if (exTop.adjustmentLayer || (typeof TextLayer !== "undefined" && exTop instanceof TextLayer)) {
                            insertBelowIndex = li + 1;
                          } else {
                            break;
                          }
                        }
                      }
                      if (insertBelowIndex > 1 && insertBelowIndex <= comp.numLayers) {
                        try { layer.moveAfter(comp.layer(insertBelowIndex - 1)); } catch (_) { layer.moveToBeginning(); }
                      } else {
                        layer.moveToBeginning();
                      }
                      comp.time = playheadTime;
                    }
                    if (typeof comp.openInViewer === "function") comp.openInViewer();
                  }
                } catch (_) {}
              }
              return "true";
            }
            return "cannot_import";
          } catch (err) {
            return "error: " + err;
          }
        })();
      `;
        const res = await this.evalScript(script);
        console.log("[AfterEffects importToProject result]:", res);
        return res === "true" || res === true;
      } catch {
        return false;
      }
    }
    getHostTheme() {
      if (typeof window !== "undefined" && window.__adobe_cep__) {
        try {
          const skin = window.__adobe_cep__.getHostEnvironment()?.appSkinInfo;
          if (skin?.panelBackgroundColor?.color) {
            const r = skin.panelBackgroundColor.color.red;
            if (r < 50) return "darkest";
            if (r < 100) return "dark";
            if (r > 200) return "lightest";
            return "light";
          }
        } catch {
        }
      }
      return "dark";
    }
    onThemeChanged(callback) {
      this.themeListeners.push(callback);
      if (typeof window !== "undefined" && window.__adobe_cep__) {
        try {
          window.__adobe_cep__.addEventListener("com.adobe.csxs.events.ThemeChanged", () => {
            callback(this.getHostTheme());
          });
        } catch {
        }
      }
    }
    evalScript(script) {
      return new Promise((resolve) => {
        let resolved = false;
        const timer = setTimeout(() => {
          if (!resolved) {
            resolved = true;
            resolve(null);
          }
        }, 12e4);
        try {
          if (typeof window !== "undefined" && window.__adobe_cep__) {
            window.__adobe_cep__.evalScript(script, (result) => {
              if (!resolved) {
                resolved = true;
                clearTimeout(timer);
                resolve(result);
              }
            });
            return;
          }
          if (typeof window !== "undefined" && window.CSInterface) {
            const cs = new window.CSInterface();
            cs.evalScript(script, (result) => {
              if (!resolved) {
                resolved = true;
                clearTimeout(timer);
                resolve(result);
              }
            });
            return;
          }
        } catch (e) {
          console.warn("evalScript error:", e);
        }
        if (!resolved) {
          resolved = true;
          clearTimeout(timer);
          resolve(null);
        }
      });
    }
  };

  // src/host/premiere-adapter.ts
  var PremiereHostAdapter = class {
    themeListeners = [];
    async getProjectContext() {
      if (typeof getHostAppId === "function" && getHostAppId() === "aeft") {
        return new AfterEffectsHostAdapter().getProjectContext();
      }
      try {
        const hostInfoResult = await this.evalScript("MediaFetchHost.getHostInfo()");
        if (hostInfoResult && typeof hostInfoResult === "string" && hostInfoResult !== "EvalScript error.") {
          try {
            const parsedHost = JSON.parse(hostInfoResult);
            if (parsedHost && parsedHost.projectPath && parsedHost.projectPath.length > 0) {
              const cleanPath = parsedHost.projectPath.replace(/\\/g, "/");
              const dir = cleanPath.substring(0, cleanPath.lastIndexOf("/"));
              const name = parsedHost.projectName || cleanPath.substring(cleanPath.lastIndexOf("/") + 1) || "Premiere Project";
              return {
                application: "premierepro",
                applicationVersion: parsedHost.appVersion || "26.0",
                projectSaved: true,
                projectName: name,
                projectPath: parsedHost.projectPath,
                projectDirectory: dir.replace(/\//g, "\\")
              };
            }
          } catch (_) {
          }
        }
        const script = `
        (function() {
          try {
            if (app && app.project) {
              var pPath = "";
              if (app.project.path && app.project.path.length > 0) {
                pPath = app.project.path;
              } else if (app.project.documentPath && app.project.documentPath.length > 0) {
                pPath = app.project.documentPath;
              }

              if (pPath && pPath.length > 0) {
                return JSON.stringify({
                  saved: true,
                  path: pPath,
                  name: app.project.name || "Premiere Project",
                  version: app.version || "26.0"
                });
              } else {
                return JSON.stringify({
                  saved: false,
                  name: "Active Premiere Project (Unsaved)",
                  version: app.version || "26.0"
                });
              }
            }
          } catch (err) {
            return JSON.stringify({ saved: false, error: String(err) });
          }
          return JSON.stringify({ saved: false });
        })();
      `;
        const result = await this.evalScript(script);
        if (result && typeof result === "string" && result !== "EvalScript error.") {
          const parsed = JSON.parse(result);
          if (parsed) {
            if (parsed.saved && parsed.path) {
              const cleanPath = parsed.path.replace(/\\/g, "/");
              const dir = cleanPath.substring(0, cleanPath.lastIndexOf("/"));
              const name = cleanPath.substring(cleanPath.lastIndexOf("/") + 1) || parsed.name;
              return {
                application: "premierepro",
                applicationVersion: parsed.version || "26.0",
                projectSaved: true,
                projectName: name,
                projectPath: parsed.path,
                projectDirectory: dir.replace(/\//g, "\\")
              };
            } else if (parsed.name) {
              return {
                application: "premierepro",
                applicationVersion: parsed.version || "26.0",
                projectSaved: false,
                projectName: parsed.name
              };
            }
          }
        }
      } catch (e) {
        console.warn("Error reading Premiere Pro project context:", e);
      }
      return {
        application: "premierepro",
        applicationVersion: "26.0",
        projectSaved: false
      };
    }
    async revealInFinder(filePath) {
      try {
        if (typeof window !== "undefined" && window.require) {
          const cp = window.require("child_process");
          if (cp?.exec) {
            cp.exec(`explorer.exe /select,"${filePath.replace(/\//g, "\\")}"`);
            return;
          }
        }
      } catch {
      }
      try {
        const script = `
        (function() {
          var f = new File("${filePath.replace(/\\/g, "/")}");
          if (f.exists) {
            f.execute();
          }
        })();
      `;
        await this.evalScript(script);
      } catch {
      }
    }
    async openFile(filePath) {
      await this.revealInFinder(filePath);
    }
    async importToProject(filePath, options) {
      if (typeof getHostAppId === "function" && getHostAppId() === "aeft") {
        return new AfterEffectsHostAdapter().importToProject(filePath, options);
      }
      try {
        const cleanPath = filePath.replace(/\\/g, "/");
        const locMode = options?.downloadLocationMode || (options?.isCustomFlat ? "custom_flat" : options?.isCustomPath ? "custom" : "simple");
        const isCustomFlat = locMode === "custom_flat" || Boolean(options?.isCustomFlat);
        const isCustom = !isCustomFlat && (locMode === "custom" || Boolean(options?.isCustomPath));
        const isSimple = !isCustom && !isCustomFlat;
        const isCloud = options?.isCloud ? true : false;
        const isPlaylist = options?.isPlaylist ? true : false;
        const isBatch = options?.isBatch ? true : false;
        const isSingleLink = options?.isSingleLink !== void 0 ? options.isSingleLink : !isPlaylist && !isCloud && !isBatch;
        const shouldInsertTimeline = Boolean((options?.insertToTimeline || options?.addToTimeline || options?.isClipboard) && isSingleLink);
        const playlistTitle = (options?.playlistTitle || "").replace(/[\\/:"*?<>|]/g, " ").trim();
        const customFolderName = (options?.customFolderName || "").replace(/[\\/:"*?<>|]/g, " ").trim();
        const subFolderName = (options?.subFolderName || "").trim();
        const isClipboard = Boolean(options?.isClipboard || cleanPath.includes("Clipboard"));
        const optsObj = {
          downloadLocationMode: locMode,
          isCustomPath: isCustom,
          isCustomFlat,
          isSimplePath: isSimple,
          isSimple,
          isCloud,
          isPlaylist,
          isBatch,
          isSingleLink,
          playlistTitle,
          customFolderName,
          subFolderName,
          isClipboard,
          targetProjectPath: options?.targetProjectPath || "",
          addToTimeline: shouldInsertTimeline,
          insertToTimeline: shouldInsertTimeline
        };
        const optsJson = JSON.stringify(optsObj);
        try {
          let extDir = "";
          if (typeof window !== "undefined") {
            if (window.__adobe_cep__?.getSystemPath) {
              extDir = window.__adobe_cep__.getSystemPath("extension");
            } else if (window.CSInterface) {
              extDir = new window.CSInterface().getSystemPath("extension");
            }
          }
          if (extDir) {
            try {
              extDir = decodeURIComponent(extDir);
            } catch (_) {
            }
            extDir = extDir.replace(/^file:[\\\/]+/, "");
            if (/^[\\\/]?[A-Za-z]:/.test(extDir)) {
              extDir = extDir.replace(/^[\\\/]([A-Za-z]:)/, "$1");
            }
            extDir = extDir.replace(/\\/g, "/");
            const jsxP = extDir + "/jsx/hostscript.jsx";
            await this.evalScript(`(function(){ try { var f = new File("${jsxP}"); if (f.exists) { $.evalFile(f); return "loaded"; } } catch(e){} return "none"; })()`);
          }
        } catch (_) {
        }
        try {
          const evalResStr = await this.evalScript(`MediaFetchHost.importMedia(${JSON.stringify(cleanPath)}, ${shouldInsertTimeline ? "true" : "false"}, ${optsJson})`);
          if (evalResStr && evalResStr !== "EvalScript error.") {
            try {
              const parsed = JSON.parse(evalResStr);
              if (parsed && parsed.success && parsed.imported !== false) {
                console.log("[MediaFetch] HostScript importMedia succeeded:", parsed);
                return true;
              }
            } catch (_) {
              if (evalResStr === "true" || evalResStr === true) return true;
            }
          }
        } catch (hErr) {
          console.warn("[MediaFetch] MediaFetchHost.importMedia attempt notice:", hErr);
        }
        const script = `
        (function() {
          try {
            if (!app || !app.project) return "no_project";
            var project = app.project;
            var root = project.rootItem;
            
            function getOrCreateBin(parentBin, binName) {
              if (!parentBin || !parentBin.children) return null;
              for (var i = 0; i < parentBin.children.numItems; i++) {
                var item = parentBin.children[i];
                if (item && item.type === 2 && item.name === binName) {
                  return item;
                }
              }
              try { return parentBin.createBin(binName); } catch (binErr) { return null; }
            }

            var targetPath = "${cleanPath}";
            var isCustomFlat = ${isCustomFlat ? "true" : "false"};
            var isCustom = ${isCustom ? "true" : "false"};
            var isCloud = ${isCloud ? "true" : "false"};
            var isPlaylist = ${isPlaylist ? "true" : "false"};
            var playlistTitle = "${playlistTitle.replace(/"/g, '\\"')}";
            var customFolderName = "${customFolderName.replace(/"/g, '\\"')}";
            var subFolderName = "${subFolderName.replace(/"/g, '\\"').replace(/\\/g, "/")}";

            var targetBin = null;

            if (isCustomFlat) {
              // Direct Custom Flat Folder
              var pPartsFlat = targetPath.split('/');
              var parentNameFlat = pPartsFlat.length > 1 ? pPartsFlat[pPartsFlat.length - 2] : "Downloads";
              var rootBinNameFlat = customFolderName || parentNameFlat || "Downloads";
              targetBin = getOrCreateBin(root, rootBinNameFlat) || root;
            } else if (isCustom) {
              // Custom Directory: create root bin outside MediaFetch named after the selected custom folder
              var pParts = targetPath.split('/');
              var parentName = pParts.length > 1 ? pParts[pParts.length - 2] : "";
              var isStrictThreeFolder = (parentName === "Video" || parentName === "Audio" || parentName === "Images" || parentName === "Image");
              var parts = targetPath.split('.');
              var ext = parts.length > 1 ? parts[parts.length - 1].toLowerCase().split('?')[0] : '';
              var isAudio = (ext === 'mp3' || ext === 'wav' || ext === 'm4a' || ext === 'flac' || ext === 'aac' || ext === 'ogg' || ext === 'opus' || ext === 'aiff');
              var isImage = (ext === 'jpg' || ext === 'jpeg' || ext === 'png' || ext === 'webp' || ext === 'gif' || ext === 'bmp' || ext === 'tiff' || ext === 'tif' || ext === 'svg');
              var typeBinName = isAudio ? "Audio" : (isImage ? "Images" : "Video");

              if (isStrictThreeFolder) {
                var grandParentName = pParts.length > 2 ? pParts[pParts.length - 3] : "";
                var customRootBin = grandParentName ? getOrCreateBin(root, grandParentName) : root;
                targetBin = getOrCreateBin(customRootBin || root, typeBinName) || customRootBin;
              } else {
                var rootBinName = customFolderName || (isPlaylist ? (playlistTitle || "Playlist") : (isCloud ? "Cloud Media" : ""));
                if (!rootBinName) {
                  rootBinName = parentName || "Downloads";
                }
                var customRootBin = getOrCreateBin(root, rootBinName);
                if (subFolderName) {
                  var sParts = subFolderName.split('/');
                  var cur = customRootBin;
                  for (var s = 0; s < sParts.length; s++) {
                    if (sParts[s] && sParts[s].length > 0) {
                      cur = getOrCreateBin(cur, sParts[s]);
                    }
                  }
                  targetBin = cur || customRootBin;
                } else {
                  targetBin = getOrCreateBin(customRootBin, typeBinName) || customRootBin;
                }
              }
            } else {
              // Default Project Path: inside root "MediaFetch" bin
              var mediaFetchBin = getOrCreateBin(root, "MediaFetch");

              if (isCloud) {
                // MediaFetch -> Cloud Links -> [Cloud Folder Name] -> [Subfolders]
                var cloudRootBin = getOrCreateBin(mediaFetchBin, "Cloud Links");
                var cloudFolderBin = getOrCreateBin(cloudRootBin, customFolderName || "Cloud Media");
                if (subFolderName) {
                  var sParts = subFolderName.split('/');
                  var cur = cloudFolderBin;
                  for (var s = 0; s < sParts.length; s++) {
                    if (sParts[s] && sParts[s].length > 0) {
                      cur = getOrCreateBin(cur, sParts[s]);
                    }
                  }
                  targetBin = cur || cloudFolderBin;
                } else {
                  targetBin = cloudFolderBin;
                }
              } else if (isPlaylist) {
                // MediaFetch -> Playlists -> [Playlist Name]
                var playlistRootBin = getOrCreateBin(mediaFetchBin, "Playlists");
                var pName = playlistTitle || customFolderName || "Playlist 1";
                targetBin = getOrCreateBin(playlistRootBin, pName);
              } else {
                // Single link or Search or Clipboard
                var isClipboard = ${isClipboard ? "true" : "false"} || targetPath.indexOf("Clipboard") !== -1;
                var isSearch = targetPath.indexOf("SerachMediafetch") !== -1 || 
                               targetPath.indexOf("MediaFetch Assets") !== -1 || 
                               targetPath.indexOf("MediaSearch Assets") !== -1;
                var categoryBinName = isClipboard ? "Clipboard" : (isSearch ? "SerachMediafetch" : "LinkMediaFetch");
                var categoryBin = getOrCreateBin(mediaFetchBin, categoryBinName);

                var parts = targetPath.split('.');
                var ext = parts.length > 1 ? parts[parts.length - 1].toLowerCase().split('?')[0] : '';
                var isAudio = (ext === 'mp3' || ext === 'wav' || ext === 'm4a' || ext === 'flac' || ext === 'aac' || ext === 'ogg' || ext === 'opus' || ext === 'aiff');
                var isImage = (ext === 'jpg' || ext === 'jpeg' || ext === 'png' || ext === 'webp' || ext === 'gif' || ext === 'bmp' || ext === 'tiff' || ext === 'tif' || ext === 'svg');
                var typeBinName = isAudio ? "Audio" : (isImage ? "Images" : "Video");
                targetBin = getOrCreateBin(categoryBin, typeBinName) || categoryBin;
              }
            }

            if (!targetBin) targetBin = root;

            // Check if file is already imported in targetBin to avoid duplicates (unless timeline insertion requested)
            if (!${shouldInsertTimeline ? "true" : "false"}) {
              if (targetBin && targetBin.children) {
                for (var k = 0; k < targetBin.children.numItems; k++) {
                  var ch = targetBin.children[k];
                  try {
                    if (ch && ch.getMediaPath && (ch.getMediaPath() === targetPath || ch.getMediaPath() === "${filePath.replace(/\\/g, "\\\\")}")) {
                      return "true";
                    }
                  } catch (_) {}
                }
              }
            }

            var mediaF = new File(targetPath);
            var nativePath = mediaF.fsName;
            var cleanPath = targetPath.replace(/\\/g, '/');
            var rawName = "";
            try {
              if (mediaF.name) rawName = File.decode(mediaF.name);
            } catch (_) {}
            if (!rawName && mediaF.fsName) {
              var fnParts = mediaF.fsName.replace(/\\/g, '/').split('/');
              rawName = fnParts[fnParts.length - 1];
            }
            if (!rawName) rawName = targetPath.split('/').pop() || "";

            var fileNameOnly = rawName.toLowerCase();
            var baseNameOnly = fileNameOnly;
            var dotIdx = fileNameOnly.lastIndexOf('.');
            if (dotIdx > 0) {
              baseNameOnly = fileNameOnly.substring(0, dotIdx);
            }

            var cleanNorm = cleanPath.toLowerCase();
            var nativeNorm = nativePath.toLowerCase();

            function cleanStrMatch(str) {
              if (!str) return "";
              var s = String(str);
              try { s = File.decode(s); } catch (_) {}
              return s.toLowerCase().replace(/\\/g, '/').replace(/[^wd]/g, '');
            }

            var cleanAlphaNorm = cleanStrMatch(fileNameOnly);
            var baseAlphaNorm = cleanStrMatch(baseNameOnly);

            function matchItem(ci) {
              if (!ci || ci.type === 2) return false;
              try {
                if (ci.getMediaPath) {
                  var mp = ci.getMediaPath();
                  if (mp && mp.length > 0) {
                    var mpNorm = mp.replace(/\\/g, '/').toLowerCase();
                    var tpNorm = targetPath.replace(/\\/g, '/').toLowerCase();
                    if (mpNorm === tpNorm || mp.toLowerCase() === nativeNorm) return true;
                    var mpAlpha = cleanStrMatch(mp);
                    if (mpAlpha && cleanAlphaNorm && (mpAlpha === cleanAlphaNorm || mpAlpha === baseAlphaNorm)) return true;
                  }
                }
              } catch (_) {}
              try {
                if (ci.name) {
                  var nLow = ci.name.toLowerCase();
                  if (nLow === fileNameOnly || nLow === baseNameOnly) return true;
                  var dot = nLow.lastIndexOf('.');
                  var nBase = dot > 0 ? nLow.substring(0, dot) : nLow;
                  if (nBase === baseNameOnly) return true;
                  var nAlpha = cleanStrMatch(ci.name);
                  if (nAlpha && (nAlpha === cleanAlphaNorm || nAlpha === baseAlphaNorm)) return true;
                }
              } catch (_) {}
              return false;
            }

            function scanBin(bin) {
              if (!bin || !bin.children) return null;
              for (var i = 0; i < bin.children.numItems; i++) {
                var it = bin.children[i];
                if (!it) continue;
                if (it.type !== 2) {
                  if (matchItem(it)) return it;
                } else if (it.type === 2) {
                  var f = scanBin(it);
                  if (f) return f;
                }
              }
              return null;
            }

            var prevTargetCount = (targetBin && targetBin.children) ? targetBin.children.numItems : 0;
            var prevRootCount = (root && root.children) ? root.children.numItems : 0;
            var didImportFallback = false;
            var targetItem = null;

            var pathsToTry = [cleanPath, nativePath];
            if (targetPath !== cleanPath && targetPath !== nativePath) {
              pathsToTry.push(targetPath);
            }

            // Check if file is already present with exact path
            targetItem = scanBin(targetBin) || scanBin(root);

            if (!targetItem) {
              // Attempt 1: Import directly into targetBin or root with lock retries
              for (var p1 = 0; p1 < pathsToTry.length && !didImportFallback; p1++) {
                var pPath1 = pathsToTry[p1];
                for (var lockAttempt = 0; lockAttempt < 5 && !didImportFallback; lockAttempt++) {
                  if (lockAttempt > 0) { try { $.sleep(300); } catch (_) {} }
                  
                  // Try targetBin first
                  if (targetBin && targetBin !== root) {
                    try {
                      var r1 = project.importFiles([pPath1], true, targetBin, false);
                      if (r1 === true || r1 === 1 || (targetBin.children && targetBin.children.numItems > prevTargetCount)) {
                        didImportFallback = true;
                        break;
                      }
                      var itCheck = scanBin(targetBin);
                      if (itCheck) {
                        targetItem = itCheck;
                        didImportFallback = true;
                        break;
                      }
                    } catch (_) {}
                  }

                  // If targetBin rejected or failed, import directly into root!
                  if (!didImportFallback && !targetItem) {
                    try {
                      var r2 = project.importFiles([pPath1], true);
                      if (r2 === true || r2 === 1 || (root && root.children && root.children.numItems > prevRootCount)) {
                        didImportFallback = true;
                        break;
                      }
                    } catch (_) {}
                  }

                  // Flag fallback
                  if (!didImportFallback && !targetItem) {
                    try {
                      var r3 = (targetBin && targetBin !== root) ?
                        project.importFiles([pPath1], 1, targetBin, 0) :
                        project.importFiles([pPath1]);
                      if (r3 === true || r3 === 1 || (targetBin && targetBin.children && targetBin.children.numItems > prevTargetCount) || (root && root.children && root.children.numItems > prevRootCount)) {
                        didImportFallback = true;
                        break;
                      }
                    } catch (_) {}
                  }

                  // Plain importFiles
                  if (!didImportFallback && !targetItem) {
                    try {
                      var r4 = project.importFiles([pPath1]);
                      if (r4 === true || r4 === 1 || (root && root.children && root.children.numItems > prevRootCount)) {
                        didImportFallback = true;
                        break;
                      }
                    } catch (_) {}
                  }
                }
              }

              // Safe Ingestion Polling: wait max 1s (4 x 250ms) to avoid CEP evalScript watchdog timeout
              for (var poll = 0; poll < 4 && !targetItem; poll++) {
                try { $.sleep(250); } catch (_) {}
                if (targetBin && targetBin.children && targetBin.children.numItems > prevTargetCount) {
                  for (var ci = targetBin.children.numItems - 1; ci >= 0; ci--) {
                    var cand = targetBin.children[ci];
                    if (cand && cand.type !== 2 && matchItem(cand)) {
                      targetItem = cand;
                      break;
                    }
                  }
                }
                if (!targetItem && root && root.children && root.children.numItems > prevRootCount) {
                  for (var ri0 = root.children.numItems - 1; ri0 >= 0; ri0--) {
                    var rCand0 = root.children[ri0];
                    if (rCand0 && rCand0.type !== 2 && matchItem(rCand0)) {
                      targetItem = rCand0;
                      break;
                    }
                  }
                }
                if (!targetItem) {
                  targetItem = scanBin(targetBin) || scanBin(root);
                }
              }
            }

            // Move item into targetBin if it was imported to root
            if (targetItem && targetBin && targetBin !== root) {
              try {
                if (typeof targetItem.moveBin === 'function') {
                  targetItem.moveBin(targetBin);
                }
              } catch (_) {}
            }

            var success = Boolean(targetItem) || Boolean(didImportFallback);

            if (success) {
                try {
                if (targetItem && ${shouldInsertTimeline ? "true" : "false"}) {
                  var sName = targetItem.name || "MediaFetch Timeline";
                  var insertedToSeq = false;
                  var aSeq = project.activeSequence;

                  function findSmartVideoTrackAndGap(seq, playheadTime) {
                    if (!seq || !seq.videoTracks || seq.videoTracks.numTracks === 0) return null;
                    var numTracks = seq.videoTracks.numTracks;
                    var pSec = (playheadTime && playheadTime.seconds !== undefined) ? playheadTime.seconds : (parseFloat(playheadTime) || 0);

                    var minUsableGap = 0.05;
                    var bestTrack = null;
                    var bestGap = Infinity;
                    var bestTrackIndex = -1;

                    // Start scanning from V2 (index 1) upwards to protect V1 base/footage track.
                    var startIdx = numTracks > 1 ? 1 : 0;

                    for (var t = startIdx; t < numTracks; t++) {
                      var trk = seq.videoTracks[t];
                      if (!trk) continue;
                      try {
                        if (trk.isLocked && trk.isLocked()) continue;
                      } catch (_) {}

                      var hasCollision = false;
                      var nextClipStart = Infinity;
                      var numClips = (trk.clips && trk.clips.numItems) ? trk.clips.numItems : 0;

                      for (var c = 0; c < numClips; c++) {
                        var cl = trk.clips[c];
                        if (!cl || !cl.start || !cl.end) continue;
                        var cStart = cl.start.seconds !== undefined ? cl.start.seconds : parseFloat(cl.start);
                        var cEnd = cl.end.seconds !== undefined ? cl.end.seconds : parseFloat(cl.end);

                        if (cStart <= pSec + 0.001 && cEnd > pSec + 0.001) {
                          hasCollision = true;
                          break;
                        }

                        if (cStart > pSec + 0.001) {
                          if (cStart < nextClipStart) {
                            nextClipStart = cStart;
                          }
                        }
                      }

                      if (!hasCollision) {
                        var gap = (nextClipStart !== Infinity) ? (nextClipStart - pSec) : Infinity;
                        if (gap >= minUsableGap) {
                          bestTrack = trk;
                          bestGap = gap;
                          bestTrackIndex = t;
                          break;
                        }
                      }
                    }

                    if (!bestTrack && startIdx > 0) {
                      var v1Trk = seq.videoTracks[0];
                      if (v1Trk) {
                        var v1Locked = false;
                        try { v1Locked = (v1Trk.isLocked && v1Trk.isLocked()); } catch (_) {}
                        if (!v1Locked) {
                          var v1Collision = false;
                          var v1NextStart = Infinity;
                          var v1NumClips = (v1Trk.clips && v1Trk.clips.numItems) ? v1Trk.clips.numItems : 0;
                          for (var c1 = 0; c1 < v1NumClips; c1++) {
                            var cl1 = v1Trk.clips[c1];
                            if (!cl1 || !cl1.start || !cl1.end) continue;
                            var cs1 = cl1.start.seconds !== undefined ? cl1.start.seconds : parseFloat(cl1.start);
                            var ce1 = cl1.end.seconds !== undefined ? cl1.end.seconds : parseFloat(cl1.end);
                            if (cs1 <= pSec + 0.001 && ce1 > pSec + 0.001) {
                              v1Collision = true;
                              break;
                            }
                            if (cs1 > pSec + 0.001 && cs1 < v1NextStart) {
                              v1NextStart = cs1;
                            }
                          }
                          if (!v1Collision) {
                            var v1Gap = (v1NextStart !== Infinity) ? (v1NextStart - pSec) : Infinity;
                            if (v1Gap >= minUsableGap) {
                              bestTrack = v1Trk;
                              bestGap = v1Gap;
                              bestTrackIndex = 0;
                            }
                          }
                        }
                      }
                    }

                    if (!bestTrack) {
                      bestTrackIndex = numTracks - 1;
                      bestTrack = seq.videoTracks[bestTrackIndex];
                      bestGap = Infinity;
                    }

                    return { track: bestTrack, gapDuration: bestGap, trackIndex: bestTrackIndex };
                  }

                  function getTargetVideoTrack(seq, playheadTime) {
                    var res = findSmartVideoTrackAndGap(seq, playheadTime);
                    return res ? res.track : null;
                  }

                  function findClearVideoTrack(seq, playheadTime) {
                    if (!seq || !seq.videoTracks || seq.videoTracks.numTracks === 0) return null;
                    var numTracks = seq.videoTracks.numTracks;
                    var pSec = (playheadTime && playheadTime.seconds !== undefined) ? playheadTime.seconds : (parseFloat(playheadTime) || 0);

                    var bestTrack = null;
                    var bestTrackIndex = -1;

                    // Check the top-most video track (newest / highest layer)
                    var topIdx = numTracks - 1;
                    var topTrk = seq.videoTracks[topIdx];
                    var topLocked = false;
                    try { topLocked = (topTrk && topTrk.isLocked && topTrk.isLocked()); } catch (_) {}

                    if (topTrk && !topLocked) {
                      var hasCollision = false;
                      var hasClipsAfter = false;
                      var numClips = (topTrk.clips && topTrk.clips.numItems) ? topTrk.clips.numItems : 0;

                      for (var c = 0; c < numClips; c++) {
                        var cl = topTrk.clips[c];
                        if (!cl || !cl.start || !cl.end) continue;
                        var cStart = cl.start.seconds !== undefined ? cl.start.seconds : parseFloat(cl.start);
                        var cEnd = cl.end.seconds !== undefined ? cl.end.seconds : parseFloat(cl.end);

                        if (cStart <= pSec + 0.001 && cEnd > pSec + 0.001) {
                          hasCollision = true;
                          break;
                        }
                        if (cStart > pSec + 0.001) {
                          hasClipsAfter = true;
                          break;
                        }
                      }

                      // If top track has space from playhead to infinity, use it!
                      if (!hasCollision && !hasClipsAfter) {
                        bestTrack = topTrk;
                        bestTrackIndex = topIdx;
                      }
                    }

                    // If top track does not have space, CREATE A NEW TOP VIDEO LAYER!
                    if (!bestTrack) {
                      try {
                        if (typeof app.enableQE === "function") app.enableQE();
                        if (typeof qe !== "undefined" && qe.project) {
                          var qSeq = qe.project.getActiveSequence();
                          if (qSeq && typeof qSeq.addTracks === "function") {
                            qSeq.addTracks(1, seq.videoTracks.numTracks, 0, 0, 0);
                            if (seq.videoTracks.numTracks > numTracks) {
                              bestTrackIndex = seq.videoTracks.numTracks - 1;
                              bestTrack = seq.videoTracks[bestTrackIndex];
                            }
                          }
                        }
                      } catch (_) {}
                      if (!bestTrack) {
                        bestTrackIndex = numTracks - 1;
                        bestTrack = seq.videoTracks[bestTrackIndex];
                      }
                    }

                    return { track: bestTrack, trackIndex: bestTrackIndex, gapDuration: Infinity };
                  }

                  function findClearAudioTrack(seq, playheadTime) {
                    if (!seq || !seq.audioTracks || seq.audioTracks.numTracks === 0) return null;
                    var numTracks = seq.audioTracks.numTracks;
                    var pSec = (playheadTime && playheadTime.seconds !== undefined) ? playheadTime.seconds : (parseFloat(playheadTime) || 0);

                    var bestTrack = null;
                    var bestTrackIndex = -1;

                    // Check the bottom-most audio track (newest / lowest layer)
                    var botIdx = numTracks - 1;
                    var botTrk = seq.audioTracks[botIdx];
                    var botLocked = false;
                    try { botLocked = (botTrk && botTrk.isLocked && botTrk.isLocked()); } catch (_) {}

                    if (botTrk && !botLocked) {
                      var hasCollision = false;
                      var hasClipsAfter = false;
                      var numClips = (botTrk.clips && botTrk.clips.numItems) ? botTrk.clips.numItems : 0;

                      for (var c = 0; c < numClips; c++) {
                        var cl = botTrk.clips[c];
                        if (!cl || !cl.start || !cl.end) continue;
                        var cStart = cl.start.seconds !== undefined ? cl.start.seconds : parseFloat(cl.start);
                        var cEnd = cl.end.seconds !== undefined ? cl.end.seconds : parseFloat(cl.end);

                        if (cStart <= pSec + 0.001 && cEnd > pSec + 0.001) {
                          hasCollision = true;
                          break;
                        }
                        if (cStart > pSec + 0.001) {
                          hasClipsAfter = true;
                          break;
                        }
                      }

                      // If bottom track has space from playhead to infinity, use it!
                      if (!hasCollision && !hasClipsAfter) {
                        bestTrack = botTrk;
                        bestTrackIndex = botIdx;
                      }
                    }

                    // If bottom track does not have space, CREATE A NEW STEREO AUDIO LAYER AT BOTTOM!
                    if (!bestTrack) {
                      try {
                        if (typeof app.enableQE === "function") app.enableQE();
                        if (typeof qe !== "undefined" && qe.project) {
                          var qSeq = qe.project.getActiveSequence();
                          if (qSeq && typeof qSeq.addTracks === "function") {
                            qSeq.addTracks(0, 0, 1, 1, seq.audioTracks.numTracks);
                            if (seq.audioTracks.numTracks > numTracks) {
                              bestTrackIndex = seq.audioTracks.numTracks - 1;
                              bestTrack = seq.audioTracks[bestTrackIndex];
                            }
                          }
                        }
                      } catch (_) {}
                      if (!bestTrack) {
                        bestTrackIndex = numTracks - 1;
                        bestTrack = seq.audioTracks[bestTrackIndex];
                      }
                    }

                    return { track: bestTrack, trackIndex: bestTrackIndex, gapDuration: Infinity };
                  }

                  function targetTracks(seq, videoTrackIndex, audioTrackIndex) {
                    if (!seq) return;
                    try {
                      if (seq.videoTracks) {
                        for (var vt = 0; vt < seq.videoTracks.numTracks; vt++) {
                          try {
                            if (typeof seq.videoTracks[vt].setTargeted === "function") {
                              seq.videoTracks[vt].setTargeted(videoTrackIndex !== null && videoTrackIndex !== undefined && vt === videoTrackIndex);
                            }
                          } catch (_) {}
                        }
                      }
                    } catch (_) {}
                    try {
                      if (seq.audioTracks) {
                        for (var at = 0; at < seq.audioTracks.numTracks; at++) {
                          try {
                            if (typeof seq.audioTracks[at].setTargeted === "function") {
                              seq.audioTracks[at].setTargeted(audioTrackIndex !== null && audioTrackIndex !== undefined && at === audioTrackIndex);
                            }
                          } catch (_) {}
                        }
                      }
                    } catch (_) {}
                  }

                  function findSmartAudioTrackAndGap(seq, playheadTime) {
                    return findClearAudioTrack(seq, playheadTime);
                  }

                  function getTargetAudioTrack(seq, playheadTime) {
                    var res = findClearAudioTrack(seq, playheadTime);
                    return res ? res.track : null;
                  }

                  // 1. Insert directly into active sequence timeline at playhead position
                  if (aSeq) {
                    var pPos = aSeq.getPlayerPosition();
                    var pTicks = "0";
                    var pSec = 0;
                    if (pPos) {
                      if (pPos.ticks !== undefined && pPos.ticks !== null && String(pPos.ticks).length > 0) {
                        pTicks = String(pPos.ticks);
                      }
                      if (pPos.seconds !== undefined) {
                        pSec = pPos.seconds;
                        if (pTicks === "0") pTicks = String(Math.round(parseFloat(pPos.seconds) * 254016000000));
                      } else {
                        pSec = parseFloat(pPos) || 0;
                        if (pTicks === "0" && pSec > 0) pTicks = String(Math.round(pSec * 254016000000));
                      }
                    }
                    for (var insTry = 0; insTry < 4 && !insertedToSeq; insTry++) {
                      if (insTry > 0) { try { $.sleep(250); } catch (_) {} }
                      if (isAudio) {
                        // AUDIO ONLY: Clear track, full duration
                        var clearAudio = findClearAudioTrack(aSeq, pPos);
                        var aTrk = clearAudio ? clearAudio.track : null;
                        var aIdx = clearAudio ? clearAudio.trackIndex : -1;
                        if (aTrk) {
                          targetTracks(aSeq, null, aIdx);
                          if (pTicks && pTicks !== "0" && typeof aTrk.overwriteClip === "function") {
                            try { aTrk.overwriteClip(targetItem, pTicks); insertedToSeq = true; } catch (_) {}
                          }
                          if (!insertedToSeq && pPos && typeof aTrk.overwriteClip === "function") {
                            try { aTrk.overwriteClip(targetItem, pPos); insertedToSeq = true; } catch (_) {}
                          }
                          if (!insertedToSeq && pPos) { try { aTrk.insertClip(targetItem, pPos); insertedToSeq = true; } catch (_) {} }
                          if (!insertedToSeq && pTicks && pTicks !== "0") { try { aTrk.insertClip(targetItem, pTicks); insertedToSeq = true; } catch (_) {} }
                          if (!insertedToSeq) { try { aTrk.insertClip(targetItem, "0"); insertedToSeq = true; } catch (_) {} }
                        }
                      } else if (isImage) {
                        // IMAGE MEDIA ONLY: Smart gap-fitting & auto-trim duration (NEVER FOR VIDEO OR AUDIO)
                        var smartVideo = findSmartVideoTrackAndGap(aSeq, pPos);
                        var vTrk = smartVideo ? smartVideo.track : null;
                        var vGap = smartVideo ? smartVideo.gapDuration : Infinity;
                        var vIdx = smartVideo ? smartVideo.trackIndex : -1;
                        if (vTrk) {
                          targetTracks(aSeq, vIdx, null);
                          var targetDurSec = (vGap !== Infinity && vGap > 0) ? vGap : 5.0;
                          try {
                            var tIn = new Time();
                            tIn.ticks = "0";
                            try { targetItem.setInPoint(tIn, 4); } catch (_) { try { targetItem.setInPoint(tIn); } catch (_) {} }
                            var tOut = new Time();
                            tOut.ticks = String(Math.round(targetDurSec * 254016000000));
                            try { targetItem.setOutPoint(tOut, 4); } catch (_) { try { targetItem.setOutPoint(tOut); } catch (_) {} }
                          } catch (_) {}

                          // OverwriteClip preserves timeline boundaries best
                          if (vIdx >= 0 && vGap !== Infinity) {
                            try {
                              if (typeof app.enableQE === "function") app.enableQE();
                              if (typeof qe !== "undefined" && qe.project) {
                                var qSeq = qe.project.getActiveSequence();
                                if (qSeq && typeof qSeq.getVideoTrackAt === "function") {
                                  var qTrk = qSeq.getVideoTrackAt(vIdx);
                                  if (qTrk && typeof qTrk.overwriteClip === "function") {
                                    if (pTicks && pTicks !== "0") {
                                      try { qTrk.overwriteClip(targetItem, pTicks); insertedToSeq = true; } catch (_) {}
                                    }
                                    if (!insertedToSeq) {
                                      try { qTrk.overwriteClip(targetItem, pPos); insertedToSeq = true; } catch (_) {}
                                    }
                                  }
                                }
                              }
                            } catch (_) {}
                          }

                          if (!insertedToSeq && pTicks && pTicks !== "0" && typeof vTrk.overwriteClip === "function") {
                            try { vTrk.overwriteClip(targetItem, pTicks); insertedToSeq = true; } catch (_) {}
                          }
                          if (!insertedToSeq && pPos && typeof vTrk.overwriteClip === "function") {
                            try { vTrk.overwriteClip(targetItem, pPos); insertedToSeq = true; } catch (_) {}
                          }
                          if (!insertedToSeq && pTicks && pTicks !== "0") {
                            try { vTrk.insertClip(targetItem, pTicks); insertedToSeq = true; } catch (_) {}
                          }
                          if (!insertedToSeq && pPos) {
                            try { vTrk.insertClip(targetItem, pPos); insertedToSeq = true; } catch (_) {}
                          }
                          if (!insertedToSeq) { try { vTrk.insertClip(targetItem, "0"); insertedToSeq = true; } catch (_) {} }

                          // Clamp image to gap
                          if (insertedToSeq && vGap !== Infinity && vGap > 0 && vTrk.clips) {
                            try {
                              var pSecVal = (pPos && pPos.seconds !== undefined) ? pPos.seconds : (parseFloat(pPos) || 0);
                              var maxAllowedEnd = pSecVal + vGap;
                              for (var cChk = 0; cChk < vTrk.clips.numItems; cChk++) {
                                var plClip = vTrk.clips[cChk];
                                if (!plClip || !plClip.start || !plClip.end) continue;
                                var plStartSec = plClip.start.seconds !== undefined ? plClip.start.seconds : parseFloat(plClip.start);
                                if (Math.abs(plStartSec - pSecVal) < 0.05) {
                                  var plEndSec = plClip.end.seconds !== undefined ? plClip.end.seconds : parseFloat(plClip.end);
                                  if (plEndSec > maxAllowedEnd + 0.01) {
                                    try {
                                      var eTime = new Time();
                                      eTime.ticks = String(Math.round(maxAllowedEnd * 254016000000));
                                      plClip.end = eTime;
                                    } catch (_) {
                                      try { plClip.end = maxAllowedEnd; } catch (_) {}
                                    }
                                    try {
                                      var oTime = new Time();
                                      oTime.ticks = String(Math.round(vGap * 254016000000));
                                      plClip.outPoint = oTime;
                                    } catch (_) {}
                                  }
                                  break;
                                }
                              }
                            } catch (_) {}
                          }
                        }
                      } else {
                        // VIDEO MEDIA: Clear track for both video and audio, full duration, zero clips cut on the right
                        var clearVid = findClearVideoTrack(aSeq, pPos);
                        var clearAud = findClearAudioTrack(aSeq, pPos);
                        var vTrk = clearVid ? clearVid.track : null;
                        var vIdx = clearVid ? clearVid.trackIndex : -1;
                        var aIdx = clearAud ? clearAud.trackIndex : -1;

                        if (vTrk) {
                          targetTracks(aSeq, vIdx, aIdx);
                          if (pTicks && pTicks !== "0" && typeof vTrk.overwriteClip === "function") {
                            try { vTrk.overwriteClip(targetItem, pTicks); insertedToSeq = true; } catch (_) {}
                          }
                          if (!insertedToSeq && pPos && typeof vTrk.overwriteClip === "function") {
                            try { vTrk.overwriteClip(targetItem, pPos); insertedToSeq = true; } catch (_) {}
                          }
                          if (!insertedToSeq && pTicks && pTicks !== "0") {
                            try { vTrk.insertClip(targetItem, pTicks); insertedToSeq = true; } catch (_) {}
                          }
                          if (!insertedToSeq && pPos) {
                            try { vTrk.insertClip(targetItem, pPos); insertedToSeq = true; } catch (_) {}
                          }
                          if (!insertedToSeq) { try { vTrk.insertClip(targetItem, "0"); insertedToSeq = true; } catch (_) {} }
                        }
                      }
                    }
                    if (insertedToSeq && pPos) {
                      try {
                        if (typeof aSeq.setPlayerPosition === 'function') {
                          try {
                            aSeq.setPlayerPosition(pPos);
                          } catch (_) {
                            try {
                              var tOrig = new Time();
                              tOrig.ticks = pTicks;
                              aSeq.setPlayerPosition(tOrig);
                            } catch (_) {
                              try { aSeq.setPlayerPosition(pTicks); } catch (_) {}
                            }
                          }
                        }
                      } catch (_) {}
                    }
                  }

                  // 2. Fallback: if no active sequence, create one
                  if (!insertedToSeq) {
                    if (typeof project.createNewSequenceFromClips === "function") {
                      var ns = project.createNewSequenceFromClips(sName, [targetItem], targetBin);
                      if (ns) {
                        insertedToSeq = true;
                        if (project.openSequence) project.openSequence(ns.sequenceID);
                      }
                    }
                    if (insertedToSeq && pPos) {
                      try {
                        if (typeof aSeq.setPlayerPosition === 'function') {
                          try {
                            aSeq.setPlayerPosition(pPos);
                          } catch (_) {
                            try {
                              var tOrig = new Time();
                              tOrig.ticks = pTicks;
                              aSeq.setPlayerPosition(tOrig);
                            } catch (_) {
                              try { aSeq.setPlayerPosition(pTicks); } catch (_) {}
                            }
                          }
                        }
                      } catch (_) {}
                    }
                  }
                }
              } catch (_) {}
            }
            return success ? "true" : "false";
          } catch (err) {
            return "error: " + err;
          }
        })();
      `;
        const res = await this.evalScript(script);
        console.log("[Premiere importToProject result]:", res);
        return res === "true" || res === true;
      } catch {
        return false;
      }
    }
    getHostTheme() {
      if (typeof window !== "undefined" && window.__adobe_cep__) {
        try {
          const skin = window.__adobe_cep__.getHostEnvironment()?.appSkinInfo;
          if (skin?.panelBackgroundColor?.color) {
            const r = skin.panelBackgroundColor.color.red;
            if (r < 50) return "darkest";
            if (r < 100) return "dark";
            if (r > 200) return "lightest";
            return "light";
          }
        } catch {
        }
      }
      return "dark";
    }
    onThemeChanged(callback) {
      this.themeListeners.push(callback);
      if (typeof window !== "undefined" && window.__adobe_cep__) {
        try {
          window.__adobe_cep__.addEventListener("com.adobe.csxs.events.ThemeChanged", () => {
            callback(this.getHostTheme());
          });
        } catch {
        }
      }
    }
    evalScript(script) {
      return new Promise((resolve) => {
        let resolved = false;
        const timer = setTimeout(() => {
          if (!resolved) {
            resolved = true;
            resolve(null);
          }
        }, 12e4);
        try {
          if (typeof window !== "undefined" && window.__adobe_cep__) {
            window.__adobe_cep__.evalScript(script, (result) => {
              if (!resolved) {
                resolved = true;
                clearTimeout(timer);
                resolve(result);
              }
            });
            return;
          }
          if (typeof window !== "undefined" && window.CSInterface) {
            const cs = new window.CSInterface();
            cs.evalScript(script, (result) => {
              if (!resolved) {
                resolved = true;
                clearTimeout(timer);
                resolve(result);
              }
            });
            return;
          }
        } catch (e) {
          console.warn("evalScript error:", e);
        }
        if (!resolved) {
          resolved = true;
          clearTimeout(timer);
          resolve(null);
        }
      });
    }
  };

  // src/host/host-detector.ts
  function getHostAppId() {
    if (typeof window !== "undefined") {
      if (window.__adobe_cep__) {
        try {
          const raw = window.__adobe_cep__.getHostEnvironment();
          const obj = typeof raw === "string" ? JSON.parse(raw) : raw;
          const aid = (obj && obj.appId || "").toLowerCase();
          if (aid.includes("pr")) return "ppro";
          if (aid.includes("ae") || aid.includes("fx")) return "aeft";
        } catch (_) {
        }
      }
      if (window.CSInterface) {
        try {
          const cs = new window.CSInterface();
          const env = cs.getHostEnvironment();
          const aid = (env && env.appId || "").toLowerCase();
          if (aid.includes("pr")) return "ppro";
          if (aid.includes("ae") || aid.includes("fx")) return "aeft";
        } catch (_) {
        }
      }
      if (window.__MF_HOST_ID__ && (window.__MF_HOST_ID__ === "ppro" || window.__MF_HOST_ID__ === "aeft")) {
        return window.__MF_HOST_ID__;
      }
      if (typeof window.hostAdapter !== "undefined" && window.hostAdapter && window.hostAdapter.hostId) {
        return window.hostAdapter.hostId;
      }
    }
    return "";
  }
  function createHostAdapter() {
    let hostId = "";
    if (typeof window !== "undefined") {
      if (window.__adobe_cep__) {
        try {
          const rawEnv = window.__adobe_cep__.getHostEnvironment();
          if (typeof rawEnv === "string") {
            try {
              const parsed = JSON.parse(rawEnv);
              hostId = (parsed.appId || "").toLowerCase();
            } catch {
            }
          } else if (rawEnv && typeof rawEnv === "object") {
            hostId = (rawEnv.appId || "").toLowerCase();
          }
          console.log("[HostDetector] Detected CEP host ID:", hostId);
        } catch (e) {
          console.warn("[HostDetector] Error reading CEP environment:", e);
        }
      }
      if (!hostId && window.CSInterface) {
        try {
          const cs = new window.CSInterface();
          const env = cs.getHostEnvironment();
          hostId = (env && env.appId || "").toLowerCase();
        } catch (_) {
        }
      }
      if (hostId.includes("pr") || hostId.includes("premiere")) {
        const adapter = new PremiereHostAdapter();
        adapter.hostId = "ppro";
        window.__MF_HOST_ID__ = "ppro";
        return adapter;
      } else if (hostId.includes("ae") || hostId.includes("fx") || hostId.includes("aftereffects")) {
        const adapter = new AfterEffectsHostAdapter();
        adapter.hostId = "aeft";
        window.__MF_HOST_ID__ = "aeft";
        return adapter;
      }
      if (window.require) {
        try {
          const uxp = window.require("uxp");
          const host = uxp?.host;
          const hostName = (host?.name || "").toLowerCase();
          if (hostName.includes("premiere") || hostName.includes("pr")) {
            const adapter = new PremiereHostAdapter();
            adapter.hostId = "ppro";
            window.__MF_HOST_ID__ = "ppro";
            return adapter;
          } else if (hostName.includes("aftereffects") || hostName.includes("ae") || hostName.includes("fx")) {
            const adapter = new AfterEffectsHostAdapter();
            adapter.hostId = "aeft";
            window.__MF_HOST_ID__ = "aeft";
            return adapter;
          }
        } catch {
        }
      }
    }
    const title = (typeof document !== "undefined" && document.title ? document.title : "").toLowerCase();
    if (title.includes("ae") || title.includes("after effects")) {
      const fallbackAe = new AfterEffectsHostAdapter();
      fallbackAe.hostId = "aeft";
      window.__MF_HOST_ID__ = "aeft";
      return fallbackAe;
    }
    const fallbackPr = new PremiereHostAdapter();
    fallbackPr.hostId = "ppro";
    window.__MF_HOST_ID__ = "ppro";
    return fallbackPr;
  }
  var hostAdapter = createHostAdapter();

  // src/ui/app.ts
  if (typeof AbortSignal !== "undefined" && !AbortSignal.timeout) {
    AbortSignal.timeout = function(ms) {
      const controller = new AbortController();
      setTimeout(() => controller.abort(), ms);
      return controller.signal;
    };
  }
  var ICONS = {
    PAUSE: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="6" y="4" width="4" height="16"></rect><rect x="14" y="4" width="4" height="16"></rect></svg>',
    PLAY: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>',
    CLOSE: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>',
    RETRY: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M23 4v6h-6"></path><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path></svg>',
    FOLDER: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>',
    SEARCH: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>',
    CHECK: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>'
  };
  var MediaFetchApp = class {
    projectContext = {
      application: "standalone",
      applicationVersion: "1.0.0",
      projectSaved: false
    };
    currentMode = "video-audio";
    currentMetadata = null;
    currentPlaylist = null;
    queue = [];
    settings = null;
    history = [];
    isAnalyzing = false;
    analysisTimeout;
    pendingDownloadParams = null;
    toastTimeout = null;
    processedImportItemIds = /* @__PURE__ */ new Set();
    importSweepInterval = null;
    playlistCustomTargetDir = "";
    constructor() {
      if (typeof window !== "undefined") {
        window.mediaFetchApp = this;
      }
      this.init();
    }
    async init() {
      try {
        const cached = localStorage.getItem("mf_saved_settings");
        if (cached) {
          this.settings = JSON.parse(cached);
          if (this.settings && this.settings.downloads && this.settings.general) {
            this.populateSettingsForm(this.settings);
            if (this.settings?.downloads?.autoProjectPath) {
            const curKey = this.normalizeProjectPath(this.projectContext?.projectPath);
            this.savePerProjectPathOverride(curKey, targetMode, folderPath);
          }
          this.updateTargetDirDisplay();
          }
        }
      } catch (_) {
      }
      this.bindDomEvents();
      this.setupTheme();
      this.setupServiceClient();
      this.updateDropdownsForMode(this.currentMode);
      this.updateProjectStatusUI();
      this.autoStartServiceIfInCep();
      serviceClient.connect();
      setTimeout(() => {
        const urlInput = document.getElementById("url-input");
        urlInput?.focus();
      }, 100);
      this.refreshProjectContext();
      window.addEventListener("focus", () => this.refreshProjectContext());
      setInterval(() => {
        if (!document.hidden) this.refreshProjectContext();
      }, 2500);
    }
    normalizeProjectPath(p) {
      if (!p) return "";
      return String(p).replace(/^\\\\\?\\/, "").replace(/\\/g, "/").trim().toLowerCase();
    }
    getPerProjectPathsMap() {
      try {
        return JSON.parse(localStorage.getItem("mf_per_project_paths") || "{}") || {};
      } catch (_) {
        return {};
      }
    }
    savePerProjectPathOverride(projKey, downloadLocationMode, customLocation) {
      if (!projKey) return;
      try {
        const map = this.getPerProjectPathsMap();
        map[projKey] = { downloadLocationMode, customLocation };
        localStorage.setItem("mf_per_project_paths", JSON.stringify(map));
      } catch (_) {}
    }
    applyProjectPathOnSwitch(newProjKey, hasSavedDir) {
      if (!this.settings?.downloads?.autoProjectPath) return;
      const map = this.getPerProjectPathsMap();
      const savedPref = newProjKey ? map[newProjKey] : null;
      const nextMode = savedPref?.downloadLocationMode || "simple";
      const nextCustom = savedPref ? (savedPref.customLocation || "") : "";
      const updatedDownloads = {
        ...this.settings.downloads,
        downloadLocationMode: nextMode,
        customLocation: nextCustom
      };
      this.settings.downloads = updatedDownloads;
      try {
        const saved = JSON.parse(localStorage.getItem("mf_saved_settings") || "{}");
        saved.downloads = { ...saved.downloads || {}, ...updatedDownloads };
        localStorage.setItem("mf_saved_settings", JSON.stringify(saved));
      } catch (_) {}
      serviceClient.updateSettings({ downloads: updatedDownloads });
      const modeSel = document.getElementById("setting-location-mode");
      const customLocInput = document.getElementById("setting-custom-location");
      if (modeSel) modeSel.value = nextMode;
      if (customLocInput) customLocInput.value = nextCustom;
      this.updateDownloadLocationModeUI();
      if (typeof window.Settings !== "undefined") {
        window.Settings.save({
          downloadLocationMode: nextMode,
          customLocation: nextCustom,
          downloadFolder: (nextMode === "custom" || nextMode === "custom_flat") ? nextCustom : ""
        });
      }
    }
    async refreshProjectContext() {
      try {
        const prevKey = this.normalizeProjectPath(this.projectContext?.projectPath);
        const nextCtx = await hostAdapter.getProjectContext();
        this.projectContext = nextCtx;
        const newKey = this.normalizeProjectPath(nextCtx?.projectPath);
        if (this._lastSeenProjectKey === void 0) {
          this._lastSeenProjectKey = newKey;
        } else if (newKey !== prevKey || newKey !== this._lastSeenProjectKey) {
          this._lastSeenProjectKey = newKey;
          this.applyProjectPathOnSwitch(newKey, Boolean(nextCtx?.projectSaved && nextCtx?.projectDirectory));
          if (this.settings?.downloads?.perProjectQueue) {
            this.renderQueue();
          }
        }
        this.updateProjectStatusUI();
      } catch (e) {
        console.warn("Failed to resolve host project context:", e);
        this.updateProjectStatusUI();
      }
    }
    autoStartServiceIfInCep() {
      try {
        let cleanExt2 = function(p) {
          if (!p) return "";
          let s = String(p);
          try {
            s = decodeURIComponent(s);
          } catch (_) {
          }
          s = s.replace(/^file:[\\\/]+/, "");
          if (/^[\\\/]?[A-Za-z]:/.test(s)) {
            s = s.replace(/^[\\\/]([A-Za-z]:)/, "");
            return s.replace(/\//g, "\\");
          }
          if (!s.startsWith("/") && !s.startsWith("\\")) s = "/" + s;
          return s;
        };
        if (typeof window === "undefined") return;
        const nodeRequire = window.require || window.cep_node?.require || (typeof __require !== "undefined" ? __require : null);
        let proc = null;
        try {
          proc = typeof process !== "undefined" ? process : nodeRequire ? nodeRequire("process") : null;
        } catch {
        }
        const appData = proc?.env?.APPDATA || "";
        const localAppData = proc?.env?.LOCALAPPDATA || "";
        let extDir = "";
        try {
          if (window.__adobe_cep__?.getSystemPath) {
            extDir = cleanExt2(window.__adobe_cep__.getSystemPath("extension"));
          } else if (window.CSInterface) {
            extDir = cleanExt2(new window.CSInterface().getSystemPath("extension"));
          }
        } catch {
        }
        if (!extDir && typeof window.location !== "undefined" && window.location.pathname) {
          let p = cleanExt2(window.location.pathname);
          extDir = p.substring(0, Math.max(p.lastIndexOf("/"), p.lastIndexOf("\\")));
        }
        const candidatePaths = [
          extDir ? `${extDir}/service/server.bundle.js`.replace(/\//g, "\\") : "",
          extDir ? `${extDir}/service/server.js`.replace(/\//g, "\\") : "",
          appData ? `${appData}\\Adobe\\CEP\\extensions\\com.mediafetch.adobe.pro\\service\\server.bundle.js` : "",
          appData ? `${appData}\\Adobe\\CEP\\extensions\\com.mediafetch.adobe.pro\\service\\server.js` : "",
          appData ? `${appData}\\Adobe\\CEP\\extensions\\com.mediafetch.adobe\\service\\server.bundle.js` : "",
          appData ? `${appData}\\Adobe\\CEP\\extensions\\com.mediafetch.adobe\\service\\server.js` : "",
          appData ? `${appData}\\Adobe\\CEP\\extensions\\com.mediafetch.adobe.beta\\service\\server.bundle.js` : "",
          appData ? `${appData}\\Adobe\\CEP\\extensions\\com.mediafetch.adobe.beta\\service\\server.js` : "",
          "C:\\Program Files (x86)\\Common Files\\Adobe\\CEP\\extensions\\com.mediafetch.adobe.pro\\service\\server.bundle.js",
          "C:\\Program Files (x86)\\Common Files\\Adobe\\CEP\\extensions\\com.mediafetch.adobe\\service\\server.bundle.js",
          "C:\\Program Files\\Common Files\\Adobe\\CEP\\extensions\\com.mediafetch.adobe.pro\\service\\server.bundle.js",
          "C:\\Program Files\\Common Files\\Adobe\\CEP\\extensions\\com.mediafetch.adobe\\service\\server.bundle.js",
          "/Library/Application Support/Adobe/CEP/extensions/com.mediafetch.adobe.pro/service/server.bundle.js",
          "/Library/Application Support/Adobe/CEP/extensions/com.mediafetch.adobe/service/server.bundle.js",
          localAppData ? `${localAppData}\\MediaFetchPro\\server.bundle.js` : "",
          localAppData ? `${localAppData}\\MediaFetchPro\\server.js` : ""
        ].filter(Boolean);
        const fsMod = nodeRequire ? (() => {
          try {
            return nodeRequire("fs");
          } catch (_) {
            return null;
          }
        })() : null;
        const nodeExeCandidates = [
          "C:\\Program Files\\Common Files\\Adobe\\Creative Cloud Libraries\\libs\\node.exe",
          "C:\\Program Files (x86)\\Common Files\\Adobe\\Creative Cloud Libraries\\libs\\node.exe",
          "C:\\Program Files\\Adobe\\Adobe Creative Cloud Experience\\libs\\node.exe",
          "C:\\Program Files (x86)\\Adobe\\Adobe Creative Cloud Experience\\libs\\node.exe",
          "/Library/Application Support/Adobe/Creative Cloud Libraries/libs/node",
          "/Applications/Utilities/Adobe Creative Cloud Experience/libs/node",
          localAppData ? `${localAppData}\\Programs\\nodejs\\node.exe` : "",
          appData ? `${appData}\\nvm\\current\\node.exe` : "",
          "C:\\Program Files\\nodejs\\node.exe",
          "C:\\Program Files (x86)\\nodejs\\node.exe",
          "C:\\ProgramData\\chocolatey\\bin\\node.exe",
          localAppData ? `${localAppData}\\Programs\\scoop\\shims\\node.exe` : "",
          "/opt/homebrew/bin/node",
          "/usr/local/bin/node",
          "/usr/bin/node",
          "node"
        ].filter((exe) => {
          if (!exe) return false;
          if (exe === "node") return true;
          if (fsMod) {
            try {
              return fsMod.existsSync(exe);
            } catch (_) {
              return false;
            }
          }
          return true;
        });
        const logDir = localAppData ? `${localAppData}\\MediaFetch\\logs` : "";
        let outFd = "ignore";
        if (nodeRequire && logDir) {
          try {
            const fs = nodeRequire("fs");
            fs.mkdirSync(logDir, { recursive: true });
            outFd = fs.openSync(`${logDir}\\service.log`, "a");
          } catch (_) {
          }
        }
        const startServiceScript = (scriptPath) => {
          if (nodeRequire) {
            try {
              const cp = nodeRequire("child_process");
              for (const nodeExe of nodeExeCandidates) {
                if (nodeExe !== "node" && fsMod) {
                  try {
                    if (!fsMod.existsSync(nodeExe)) continue;
                  } catch (_) {
                    continue;
                  }
                }
                try {
                  const child = cp.spawn(nodeExe, ["--expose-gc", "--max-old-space-size=512", scriptPath], {
                    detached: true,
                    stdio: ["ignore", outFd, outFd],
                    windowsHide: true,
                    env: { ...proc?.env, PORT: "48924" }
                  });
                  child.on("error", (err) => {
                    console.warn(`[MediaFetch] Daemon spawn error on ${nodeExe}:`, err);
                  });
                  child.unref();
                  console.log(`[MediaFetch Pro] Daemon spawned with ${nodeExe}: ${scriptPath}`);
                  setTimeout(() => serviceClient.connect(), 800);
                  return true;
                } catch {
                }
              }
            } catch {
            }
          }
          if (window.cep?.process?.createProcess) {
            try {
              for (const nodeExe of nodeExeCandidates) {
                if (nodeExe !== "node" && fsMod) {
                  try {
                    if (!fsMod.existsSync(nodeExe)) continue;
                  } catch (_) {
                    continue;
                  }
                }
                const res = window.cep.process.createProcess(nodeExe, scriptPath);
                if (res && res.err === 0) {
                  console.log(`[MediaFetch Pro] CEP createProcess spawned daemon: ${nodeExe}`);
                  setTimeout(() => serviceClient.connect(), 800);
                  return true;
                }
              }
            } catch {
            }
          }
          if (nodeRequire) {
            try {
              console.log("[MediaFetch] Starting embedded in-process service:", scriptPath);
              const srvModule = nodeRequire(scriptPath);
              if (srvModule) {
                if (typeof srvModule.startInProcessServer === "function") {
                  srvModule.startInProcessServer(48924);
                } else if (srvModule.MediaFetchServer && !(window.__mediaFetchServerInstance || globalThis.__mediaFetchServerInstance)) {
                  const inst = new srvModule.MediaFetchServer(48924);
                  window.__mediaFetchServerInstance = inst;
                  inst.start().catch((e) => console.warn("[MediaFetch] In-process server start notice:", e));
                }
              }
              setTimeout(() => serviceClient.connect(), 400);
              setTimeout(() => serviceClient.connect(), 1e3);
              return true;
            } catch (e) {
              console.error("[MediaFetch] In-process service startup error:", e);
            }
          }
          return false;
        };
        if (nodeRequire) {
          try {
            const http = nodeRequire("http");
            const req = http.get("http://127.0.0.1:48924/health", (res) => {
              if (res.statusCode === 200) {
                console.log("[MediaFetch Pro] Service already running on port 48924.");
                serviceClient.connect();
              }
            });
            req.on("error", () => {
              for (const scriptPath of candidatePaths) {
                if (startServiceScript(scriptPath)) break;
              }
            });
            return;
          } catch {
          }
        }
        for (const scriptPath of candidatePaths) {
          if (startServiceScript(scriptPath)) break;
        }
      } catch (e) {
        console.warn("[MediaFetch] autoStartService error:", e);
      }
    }
    setupTheme() {
      const applyTheme = (themeName) => {
        document.body.classList.remove("theme-light", "theme-darkest");
        if (themeName === "light" || themeName === "lightest") {
          document.body.classList.add("theme-light");
        } else if (themeName === "darkest") {
          document.body.classList.add("theme-darkest");
        }
      };
      hostAdapter.onThemeChanged((theme) => {
        if (this.settings?.general.theme === "host") {
          applyTheme(theme);
        }
      });
      const initialHostTheme = hostAdapter.getHostTheme();
      applyTheme(initialHostTheme);
    }
    showHeaderToast(message, durationMs = 6e3) {
      const toast = document.getElementById("header-alert-toast");
      const textEl = document.getElementById("header-alert-text");
      if (!toast || !textEl) return;
      if (this.toastTimeout) {
        clearTimeout(this.toastTimeout);
        this.toastTimeout = null;
      }
      textEl.textContent = message;
      toast.style.display = "flex";
      this.toastTimeout = setTimeout(() => {
        toast.style.display = "none";
        this.toastTimeout = null;
      }, durationMs);
    }
    dismissHeaderToast() {
      const toast = document.getElementById("header-alert-toast");
      if (toast) toast.style.display = "none";
      if (this.toastTimeout) {
        clearTimeout(this.toastTimeout);
        this.toastTimeout = null;
      }
    }
    dismissHeaderToastIf(keyword) {
      const textEl = document.getElementById("header-alert-text");
      if (textEl && textEl.textContent && textEl.textContent.includes(keyword)) {
        this.dismissHeaderToast();
      }
    }
    pendingFolderCallback = null;
    selectFolderModern(callback) {
      try {
        const cepFs = window.cep?.fs;
        if (cepFs && typeof cepFs.showOpenDialogEx === "function") {
          const res = cepFs.showOpenDialogEx(false, true, "Select MediaFetch Destination Folder", "", []);
          if (res && res.data && res.data.length > 0 && res.data[0]) {
            callback(res.data[0]);
            return;
          } else if (res && Array.isArray(res.data)) {
            return;
          }
        }
        if (cepFs && typeof cepFs.showOpenDialog === "function") {
          const res = cepFs.showOpenDialog(false, true, "Select MediaFetch Destination Folder", "", []);
          if (res && res.data && res.data.length > 0 && res.data[0]) {
            callback(res.data[0]);
            return;
          } else if (res && Array.isArray(res.data)) {
            return;
          }
        }
      } catch (e) {
        console.warn("[MediaFetch Pro] CEP showOpenDialog failed:", e);
      }
      try {
        if (this.csInterface && typeof this.csInterface.evalScript === "function") {
          this.csInterface.evalScript("selectDownloadFolder()", (res) => {
            const cleaned = (res || "").trim();
            if (cleaned && cleaned !== "undefined" && cleaned !== "null" && cleaned !== "false") {
              callback(cleaned);
            }
          });
          return;
        }
      } catch (e) {
        console.warn("[MediaFetch Pro] ExtendScript selectDownloadFolder failed:", e);
      }
      this.pendingFolderCallback = callback;
      serviceClient.openFolderDialog();
    }
    updateTargetDirDisplay() {
      const targetDirDisplay = document.getElementById("target-dir-display");
      if (!targetDirDisplay) return;
      const locMode = (this.settings?.downloads?.downloadLocationMode === "project" ? "simple" : this.settings?.downloads?.downloadLocationMode) || "simple";
      const isCustom = (locMode === "custom" || locMode === "custom_flat") && this.settings?.downloads?.customLocation;
      if (isCustom) {
        targetDirDisplay.textContent = `Target: ${this.settings.downloads.customLocation}`;
        targetDirDisplay.title = `Target: ${this.settings.downloads.customLocation} (Click to change)`;
        return;
      }
      const isSaved = this.projectContext.projectSaved && this.projectContext.projectDirectory;
      if (isSaved) {
        targetDirDisplay.textContent = `Target: ${this.projectContext.projectDirectory}\\MediaFetch\\`;
        targetDirDisplay.title = `Target: ${this.projectContext.projectDirectory}\\MediaFetch\\ (Click to change)`;
      } else {
        targetDirDisplay.textContent = "Target: Downloads\\MediaFetch\\";
        targetDirDisplay.title = "Target: Downloads\\MediaFetch\\ (Click to change)";
      }
    }
    updateProjectStatusUI() {
      const label = document.getElementById("project-status-label");
      if (!label) return;
      const pName = this.projectContext.projectName;
      const isSaved = this.projectContext.projectSaved && this.projectContext.projectDirectory;
      const appName = this.projectContext.application;
      if (pName && pName !== "standalone" && pName !== "Unknown") {
        label.textContent = `Project: ${pName}${isSaved ? "" : " (Active)"}`;
        label.title = isSaved ? this.projectContext.projectDirectory : "Active Project - Downloads route to default MediaFetch folder";
      } else if (isSaved) {
        label.textContent = `Project: ${this.projectContext.projectName || "Active"}`;
        label.title = this.projectContext.projectDirectory;
      } else {
        const hostLabel = appName && appName !== "standalone" ? `${appName === "premierepro" ? "Premiere Pro" : "After Effects"} (Active)` : "Active / Default Bin";
        label.textContent = `Project: ${hostLabel}`;
        label.title = "Downloads saved to Downloads\\MediaFetch and auto-imported into host project";
      }
      this.updateTargetDirDisplay();
    }
    checkUrlForPlatform(url) {
      const isSpotify = /spotify\.(?:com|link)/i.test(url);
      const isAudioPlatform = isSpotify || /(?:music\.apple\.com|soundcloud\.com|deezer\.com|bandcamp\.com|tidal\.com|audiomack\.com)/i.test(url);
      const videoAudioBtn = document.getElementById("mode-video-audio");
      const videoOnlyBtn = document.getElementById("mode-video-only");
      if (isAudioPlatform) {
        if (videoAudioBtn) videoAudioBtn.style.display = "none";
        if (videoOnlyBtn) videoOnlyBtn.style.display = "none";
        if (this.currentMode === "video-audio" || this.currentMode === "video-only") {
          this.updateDropdownsForMode("audio-only");
        }
      } else {
        if (videoAudioBtn) videoAudioBtn.style.display = "inline-flex";
        if (videoOnlyBtn) videoOnlyBtn.style.display = "inline-flex";
      }
    }
    updateDropdownsForMode(mode) {
      this.currentMode = mode;
      document.querySelectorAll(".mode-icon-group .segment-icon-btn, .segment-btn[data-mode]").forEach((btn) => {
        const bMode = btn.getAttribute("data-mode");
        if (bMode === mode) {
          btn.classList.add("active");
        } else {
          btn.classList.remove("active");
        }
      });
      const badge = document.getElementById("current-mode-badge");
      if (badge) {
        if (mode === "audio-only") {
          badge.textContent = "Audio Only";
          badge.style.background = "#8e44ad";
        } else if (mode === "video-only") {
          badge.textContent = "Video Only";
          badge.style.background = "#d35400";
        } else if (mode === "image") {
          badge.textContent = "Photo / Cover";
          badge.style.background = "#27ae60";
        } else {
          badge.textContent = "Video + Audio";
          badge.style.background = "#1473e6";
        }
      }
      const durationTag = document.getElementById("media-duration-tag");
      if (durationTag) {
        if (mode === "image") {
          durationTag.textContent = "PHOTO";
        } else if (mode === "audio-only") {
          if (!this.currentMetadata || !this.currentMetadata.duration) {
            durationTag.textContent = "AUDIO";
          }
        } else {
          const isCloud = this.currentMetadata && Boolean(
            this.currentMetadata.isCloud || this.currentMetadata.extractor === "cloud" ||
            (this.currentMetadata.uploader && this.currentMetadata.uploader.toLowerCase().includes("cloud")) ||
            (this.currentMetadata.url && (this.currentMetadata.url.includes("drive.google.com") || this.currentMetadata.url.includes("dropbox.com") || this.currentMetadata.url.includes("onedrive") || this.currentMetadata.url.includes("1drv.ms") || this.currentMetadata.url.includes("mega.nz")))
          );
          if (isCloud) {
            if (this.currentMetadata && (this.currentMetadata.mediaType === "image" || this.currentMetadata.isImage)) {
              durationTag.textContent = "PHOTO";
            } else if (this.currentMetadata && this.currentMetadata.mediaType === "audio") {
              durationTag.textContent = "AUDIO";
            } else {
              durationTag.textContent = "CLOUD";
            }
          } else if (this.currentMetadata && this.currentMetadata.duration > 0) {
            durationTag.textContent = this.formatDuration(this.currentMetadata.duration);
          } else if (this.currentMetadata && (this.currentMetadata.mediaType === "image" || this.currentMetadata.isImage)) {
            durationTag.textContent = "PHOTO";
          } else if (this.currentMetadata && this.currentMetadata.mediaType === "audio") {
            durationTag.textContent = "AUDIO";
          } else {
            durationTag.textContent = "VIDEO";
          }
        }
      }
      const profileSelect = document.getElementById("profile-select");
      const formatSelect = document.getElementById("format-select");
      const formatGroup = document.getElementById("format-select-group");
      const formatLabel = document.getElementById("format-select-label");
      if (!profileSelect || !formatSelect) return;
      profileSelect.innerHTML = "";
      formatSelect.innerHTML = "";
      if (mode === "image") {
        if (formatSelect) {
          formatSelect.disabled = false;
          formatSelect.title = "";
        }
        if (formatGroup) {
          formatGroup.style.opacity = "1";
          formatGroup.style.pointerEvents = "auto";
        }
        if (formatLabel) formatLabel.textContent = "Format / Container";
        profileSelect.appendChild(new Option("Original Thumbnail (Max Resolution / Ultra HD)", "image-orig", true, true));
        profileSelect.appendChild(new Option("Full HD Cover Art (1080p)", "image-1080p"));
        profileSelect.appendChild(new Option("WebP Cover Art (Compact)", "image-webp"));
        profileSelect.appendChild(new Option("Lossless PNG Cover Art", "image-png"));
        formatSelect.appendChild(new Option("JPG Image", "jpg", true, true));
        formatSelect.appendChild(new Option("PNG Image", "png"));
        formatSelect.appendChild(new Option("WEBP Image", "webp"));
      } else if (mode === "audio-only") {
        if (formatSelect) {
          formatSelect.disabled = true;
          formatSelect.title = "Format is automatically determined by your selected Quality Profile.";
        }
        if (formatGroup) {
          formatGroup.style.opacity = "0.45";
          formatGroup.style.pointerEvents = "none";
        }
        if (formatLabel) formatLabel.textContent = "Format / Container (Auto-locked by Quality Profile)";
        profileSelect.appendChild(new Option("Best Audio Quality (Auto)", "best-audio", true, true));
        profileSelect.appendChild(new Option("MP3 Studio Master (320 kbps High Quality)", "audio-mp3-320"));
        profileSelect.appendChild(new Option("MP3 Standard (192 kbps)", "audio-mp3-192"));
        profileSelect.appendChild(new Option("MP3 Data Saver / Low Compressed (128 kbps)", "audio-mp3-128"));
        profileSelect.appendChild(new Option("M4A (AAC 256 kbps)", "audio-m4a"));
        profileSelect.appendChild(new Option("WAV (Uncompressed Studio Audio 1411 kbps)", "audio-wav"));
        profileSelect.appendChild(new Option("FLAC (Lossless Audio)", "audio-flac"));
        profileSelect.appendChild(new Option("Audio Only (Native Stream)", "audio-only"));
        formatSelect.appendChild(new Option("MP3 (Auto from Profile)", "mp3", true, true));
        formatSelect.appendChild(new Option("M4A (Auto from Profile)", "m4a"));
        formatSelect.appendChild(new Option("WAV (Auto from Profile)", "wav"));
        formatSelect.appendChild(new Option("FLAC (Auto from Profile)", "flac"));
        profileSelect.onchange = () => {
          const pVal = profileSelect.value;
          if (pVal === "audio-wav") formatSelect.value = "wav";
          else if (pVal === "audio-flac") formatSelect.value = "flac";
          else if (pVal === "audio-m4a") formatSelect.value = "m4a";
          else formatSelect.value = "mp3";
        };
      } else if (mode === "video-only") {
        if (formatSelect) {
          formatSelect.disabled = false;
          formatSelect.title = "";
        }
        if (formatGroup) {
          formatGroup.style.opacity = "1";
          formatGroup.style.pointerEvents = "auto";
        }
        if (formatLabel) formatLabel.textContent = "Format / Container";
        profileSelect.appendChild(new Option("1080p Full HD (1080p) \u2022 Recommended (Fast & Balanced)", "video-1080p", true, true));
        profileSelect.appendChild(new Option("Best Video Only (Auto-Optimized)", "video-only"));
        profileSelect.appendChild(new Option("4K Ultra HD (2160p) \u2022 Studio Master (Slower \u2022 Largest File)", "video-4k"));
        profileSelect.appendChild(new Option("1440p Quad HD (2K) \u2022 High Quality (Moderate Speed)", "video-1440p"));
        profileSelect.appendChild(new Option("720p HD (720p) \u2022 Very Fast (Light File)", "video-720p"));
        profileSelect.appendChild(new Option("480p SD \u2022 Super Fast / Instant (Small File)", "video-480p"));
        formatSelect.appendChild(new Option("MP4 (H.264 / AAC - Recommended for Adobe)", "mp4", true, true));
        formatSelect.appendChild(new Option("MOV (QuickTime)", "mov"));
        formatSelect.appendChild(new Option("MKV (Matroska)", "mkv"));
        formatSelect.appendChild(new Option("WEBM (VP9 / Opus)", "webm"));
      } else {
        if (formatSelect) {
          formatSelect.disabled = false;
          formatSelect.title = "";
        }
        if (formatGroup) {
          formatGroup.style.opacity = "1";
          formatGroup.style.pointerEvents = "auto";
        }
        if (formatLabel) formatLabel.textContent = "Format / Container";
        profileSelect.appendChild(new Option("1080p Full HD (1080p) \u2022 Recommended (Fast & Balanced)", "video-1080p", true, true));
        profileSelect.appendChild(new Option("Best Available Quality (Auto-Optimized)", "best-available"));
        profileSelect.appendChild(new Option("4K Ultra HD (2160p) \u2022 Studio Master (Slower \u2022 Largest File)", "video-4k"));
        profileSelect.appendChild(new Option("1440p Quad HD (2K) \u2022 High Quality (Moderate Speed)", "video-1440p"));
        profileSelect.appendChild(new Option("720p HD (720p) \u2022 Very Fast (Light File)", "video-720p"));
        profileSelect.appendChild(new Option("480p SD \u2022 Super Fast / Instant (Small File)", "video-480p"));
        formatSelect.appendChild(new Option("MP4 (H.264 / AAC - Recommended for Adobe)", "mp4", true, true));
        formatSelect.appendChild(new Option("MOV (Apple ProRes / QuickTime)", "mov"));
        formatSelect.appendChild(new Option("MKV (Matroska)", "mkv"));
        formatSelect.appendChild(new Option("WEBM (VP9 / Opus)", "webm"));
      }
    }
    setupServiceClient() {
      serviceClient.onStatusChanged((online) => {
        const dot = document.getElementById("connection-dot");
        if (dot) {
          dot.className = `connection-dot ${online ? "online" : "offline"}`;
          dot.title = online ? "MediaFetch Pro service connected (Port 48924)" : "Service offline (Click Diagnostics to check)";
        }
        if (online && Array.isArray(this.queue)) {
          for (const it of this.queue) {
            if (it && it.status === "completed" && it.importStatus === "pending" && (it.outputPath || it.downloadedPath)) {
              this.importCompletedItem(it);
            }
          }
        }
      });
      if (this.importSweepInterval) clearInterval(this.importSweepInterval);
      this.importSweepInterval = setInterval(() => {
        if (serviceClient.isOnline() && Array.isArray(this.queue)) {
          for (const it of this.queue) {
            if (it && it.status === "completed" && it.importStatus === "pending" && (it.outputPath || it.downloadedPath)) {
              this.importCompletedItem(it);
            }
          }
        }
      }, 5e3);
      serviceClient.subscribe((msg) => {
        switch (msg.type) {
          case "ANALYSIS_STARTED":
            this.setAnalysisLoading(true);
            break;
          case "ANALYSIS_SUCCESS":
          case "METADATA_RESULT":
            this.setAnalysisLoading(false);
            this.hideUrlError();
            if (msg.payload?.isPlaylist || msg.payload?.isCarousel || msg.payload?.items && msg.payload.items.length > 1) {
              this.renderPlaylistModal(msg.payload);
            } else {
              this.renderMediaCard(msg.payload);
            }
            break;
          case "ANALYSIS_ERROR":
          case "ANALYSIS_FAILED":
            this.setAnalysisLoading(false);
            this.showUrlError(`${msg.payload.error || "Media analysis failed"} (${msg.payload.category || "ERROR"})`);
            break;
          case "PLAYLIST_ANALYSIS_SUCCESS":
          case "PLAYLIST_METADATA_RESULT":
            this.setAnalysisLoading(false);
            this.renderPlaylistModal(msg.payload);
            break;
          case "PLAYLIST_ANALYSIS_ERROR":
          case "PLAYLIST_ANALYSIS_FAILED":
            this.setAnalysisLoading(false);
            this.showUrlError(`Playlist extraction failed: ${msg.payload.error}`);
            break;
          case "QUEUE_UPDATED":
            this.queue = msg.payload;
            this.renderQueue();
            if (Array.isArray(this.queue)) {
              for (const it of this.queue) {
                if (it && it.status === "completed" && it.importStatus === "pending" && (it.outputPath || it.downloadedPath)) {
                  this.importCompletedItem(it);
                }
              }
            }
            break;
          case "DOWNLOAD_PROGRESS": {
            const idx = this.queue.findIndex((i) => i.id === msg.payload.id);
            if (idx >= 0) {
              this.queue[idx] = msg.payload.item;
              this.updateQueueItemDOM(msg.payload.item);
            }
            break;
          }
          case "DOWNLOAD_COMPLETED": {
            console.log("[MediaFetch] Panel received DOWNLOAD_COMPLETED for item:", msg.payload.id || msg.payload.item?.id);
            const idx = this.queue.findIndex((i) => i.id === msg.payload.id);
            if (idx >= 0) {
              this.queue[idx] = msg.payload.item;
              this.updateQueueItemDOM(msg.payload.item);
            }
            this.importCompletedItem(msg.payload.item);
            break;
          }
          case "DOWNLOAD_FAILED": {
            const idx = this.queue.findIndex((i) => i.id === msg.payload.id);
            if (idx >= 0) {
              this.queue[idx] = msg.payload.item;
              this.updateQueueItemDOM(msg.payload.item);
            }
            break;
          }
          case "SETTINGS_LOADED":
            this.settings = msg.payload;
            try {
              localStorage.setItem("mf_saved_settings", JSON.stringify(msg.payload));
            } catch (_) {
            }
            this.populateSettingsForm(msg.payload);
            if (this.settings?.downloads?.autoProjectPath) {
            const curKey = this.normalizeProjectPath(this.projectContext?.projectPath);
            this.savePerProjectPathOverride(curKey, targetMode, folderPath);
          }
          this.updateTargetDirDisplay();
            if (msg.payload && msg.payload.general) {
              if (msg.payload.general.theme && typeof this.applyTheme === "function") {
                if (msg.payload.general.theme === "host") {
                  this.applyTheme(hostAdapter.getHostTheme());
                } else {
                  this.applyTheme(msg.payload.general.theme);
                }
              }
              if (msg.payload.general.customThemeColor) {
                if (typeof window.applyCustomThemeColor === "function") {
                  window.applyCustomThemeColor(msg.payload.general.customThemeColor, false);
                }
              } else if (msg.payload.general.customThemeColor === "") {
                if (typeof window.resetCustomTheme === "function") {
                  window.resetCustomTheme(false);
                }
              }
              if (msg.payload.general.iconTheme && typeof window.applyIconTheme === "function") {
                window.applyIconTheme(msg.payload.general.iconTheme, false);
              }
            }
            if (msg.payload && msg.payload.downloads && msg.payload.downloads.clipboardFormat) {
              try {
                localStorage.setItem("mf_clipboard_img_format", msg.payload.downloads.clipboardFormat);
                const hf = document.getElementById("select-clipboard-format");
                if (hf) hf.value = msg.payload.downloads.clipboardFormat;
                const sf = document.getElementById("setting-clipboard-format");
                if (sf) sf.value = msg.payload.downloads.clipboardFormat;
              } catch (_) {
              }
            }
            break;
          case "DIAGNOSTICS_RESULT":
            this.renderDiagnostics(msg.payload);
            this.updateSetupWizardStatus(msg.payload);
            break;
          case "HISTORY_LOADED":
            this.history = msg.payload;
            this.renderHistoryList();
            break;
          case "DUPLICATE_CHECK_RESULT":
            if (msg.payload.exists && this.pendingDownloadParams) {
              this.showDuplicateModal(msg.payload.existingFilePath || "");
            } else if (this.pendingDownloadParams) {
              this.executePendingDownload();
            }
            break;
          case "DEPENDENCY_INSTALL_PROGRESS":
            this.showInstallProgress(msg.payload);
            break;
          case "DEPENDENCY_INSTALL_RESULT":
            this.handleInstallResult(msg.payload);
            break;
          case "ZIP_PACKAGE_COMPLETED": {
            const zipPath = msg.payload?.zipPath || msg.zipPath;
            if (zipPath) {
              const fileName = zipPath.split(/[\\\/]/).pop();
              this.showHeaderToast(`ZIP Archive created: ${fileName}`, 7e3);
            }
            break;
          }
          case "PANEL_RELOAD": {
            console.log("[MediaFetch] Received PANEL_RELOAD signal, refreshing panel...");
            window.location.reload();
            break;
          }
          case "FOLDER_SELECTED": {
            const folder = msg.payload?.folderPath;
            if (folder && this.pendingFolderCallback) {
              this.pendingFolderCallback(folder);
              this.pendingFolderCallback = null;
            }
            break;
          }
        }
      });
    }
    importCompletedItem(item) {
      if (!item || !item.id) return;
      if (this.processedImportItemIds.has(item.id)) return;
      if (item.status !== "completed" || item.importStatus !== "pending") return;
      const targetFilePath = item.outputPath || item.downloadedPath;
      if (!targetFilePath) return;
      const itemEdition = item.edition;
      const isPro = window.__MF_EDITION__ === "pro" || window.location.pathname.includes(".pro") || document.title.includes("Pro");
      const myEdition = isPro ? "pro" : "standard";
      if (itemEdition && itemEdition !== myEdition) return;
      const itemTargetHost = item.targetHost;
      const myHost = (typeof window.getHostAppId === "function" ? window.getHostAppId() : "") || window.__MF_HOST_ID__ || typeof hostAdapter !== "undefined" && hostAdapter.hostId;
      if (itemTargetHost && myHost && (itemTargetHost === "ppro" || itemTargetHost === "aeft") && (myHost === "ppro" || myHost === "aeft") && itemTargetHost !== myHost) {
        return;
      }
      this.processedImportItemIds.add(item.id);
      const mainAutoImportChk = document.getElementById("main-auto-import-chk");
      const mainAutoTimelineChk = document.getElementById("main-auto-timeline-chk");
      const autoImportEnabled = mainAutoImportChk ? mainAutoImportChk.checked : this.settings?.general?.autoImportToProject ?? true;
      const autoTimelineEnabled = mainAutoTimelineChk ? mainAutoTimelineChk.checked : false;
      const isZip = Boolean(item.zipPackage || item.metadata?.zipPackage);
      const itemAutoImport = !isZip && item.autoImport !== false && item.metadata?.autoImport !== false;
      if (!itemAutoImport || !autoImportEnabled && !autoTimelineEnabled) {
        serviceClient.markItemImported(item.id, true);
        return;
      }
      const startTime = Date.now();
      console.log(`[MediaFetch] importCompletedItem started for item: ${item.id}`, { targetFilePath });
      const locMode = (this.settings?.downloads?.downloadLocationMode === "project" ? "simple" : this.settings?.downloads?.downloadLocationMode) || "simple";
      const isCustomLocation = locMode === "custom" || locMode === "custom_flat" || Boolean(item.targetDirectory);
      const isCustomFlatLocation = locMode === "custom_flat";
      const isSimpleLocation = locMode === "simple";
      const isCloud = Boolean(item.isCloud || item.metadata?.isCloud || item.customFolderName?.toLowerCase().includes("cloud") || item.metadata?.uploader?.toLowerCase().includes("cloud"));
      const isPlaylist = Boolean(item.isPlaylist || item.metadata?.isPlaylist || item.playlistTitle);
      const isBatch = Boolean(item.isBatch || item.metadata?.isBatch);
      const isSearch = Boolean(item.isSearch || item.metadata?.isSearch || item.source === "search" || targetFilePath && (targetFilePath.includes("/Search/") || targetFilePath.includes("\\Search\\") || targetFilePath.includes("SerachMediafetch") || targetFilePath.includes("SearchMediafetch")));
      const isSingleLink = !isPlaylist && !isCloud && !isBatch;
      const playlistTitle = item.playlistTitle || item.metadata?.playlistTitle || "";
      const customFolderName = item.customFolderName || item.metadata?.customFolderName || "";
      const subFolderName = item.subFolderName || item.metadata?.subFolderName || "";
      hostAdapter.importToProject(targetFilePath, {
        downloadLocationMode: locMode,
        isCustomPath: isCustomLocation,
        isCustomFlat: isCustomFlatLocation,
        isSimplePath: isSimpleLocation,
        isSimple: isSimpleLocation,
        isCloud,
        isPlaylist,
        isSingleLink,
        isSearch,
        playlistTitle,
        customFolderName,
        subFolderName,
        targetProjectPath: item.projectContext?.projectPath || "",
        addToTimeline: autoTimelineEnabled && isSingleLink,
        insertToTimeline: autoTimelineEnabled && isSingleLink
      }).then((success) => {
        const elapsedMs = Date.now() - startTime;
        console.log(`[MediaFetch] importCompletedItem ended for item: ${item.id} (elapsed: ${elapsedMs}ms, result: ${success ? "success" : "failed"})`);
        if (success) {
          serviceClient.markItemImported(item.id, true);
          this.showHeaderToast("Imported media into Project bin" + (autoTimelineEnabled ? " and timeline" : "") + "!", 4e3);
        } else {
          serviceClient.markItemImported(item.id, false, "Import returned false");
          this.showHeaderToast("Auto-import failed for " + (item.title || "media"), 5e3);
        }
      }).catch((err) => {
        const elapsedMs = Date.now() - startTime;
        console.warn(`[MediaFetch] importCompletedItem ended for item: ${item.id} (elapsed: ${elapsedMs}ms, result: failed, error: ${err})`);
        serviceClient.markItemImported(item.id, false, String(err));
        this.showHeaderToast("Auto-import failed: " + (err?.message || err), 5e3);
      });
    }
    bindDomEvents() {
      const urlInput = document.getElementById("url-input");
      const onUrlChanged = (val) => {
        const trimmed = (val || "").trim();
        if (this.currentMetadata && this.currentMetadata.url !== trimmed && this.currentMetadata.webpage_url !== trimmed) {
          this.currentMetadata = null;
          const cardSection = document.getElementById("media-card-section");
          if (cardSection) cardSection.style.display = "none";
        }
        this.checkUrlForPlatform(trimmed);
      };
      urlInput?.addEventListener("input", (e) => onUrlChanged(e.target.value));
      urlInput?.addEventListener("paste", () => setTimeout(() => onUrlChanged(urlInput?.value || ""), 50));
      document.querySelectorAll(".mode-icon-group .segment-icon-btn, .segment-btn[data-mode]").forEach((btn) => {
        btn.addEventListener("click", (e) => {
          document.querySelectorAll(".mode-icon-group .segment-icon-btn, .segment-btn[data-mode]").forEach((b) => b.classList.remove("active"));
          const target = e.currentTarget;
          target.classList.add("active");
          const mode = target.getAttribute("data-mode") || "video-audio";
          this.updateDropdownsForMode(mode);
        });
      });
      const cardFormatSelect = document.getElementById("format-select");
      cardFormatSelect?.addEventListener("change", () => {
        const val = (cardFormatSelect.value || "").toLowerCase();
        if (["mp4", "mov", "mkv", "webm"].includes(val)) {
          if (this.currentMode === "audio-only") {
            this.updateDropdownsForMode("video-audio");
          }
        } else if (["mp3", "wav", "m4a", "flac"].includes(val)) {
          if (this.currentMode === "video-audio" || this.currentMode === "video-only") {
            this.updateDropdownsForMode("audio-only");
          }
        }
      });
      const cardProfileSelect = document.getElementById("profile-select");
      cardProfileSelect?.addEventListener("change", () => {
        const pVal = cardProfileSelect.value || "";
        const is4K = pVal === "res-2160" || pVal === "video-4k" || pVal.includes("2160");
        if (is4K) {
          this.showHeaderToast(
            "4K Ultra HD selected: Studio quality master. Note: 4K files take a bit longer to download and optimize.",
            4500
          );
        } else {
          this.dismissHeaderToastIf("4K");
        }
      });
      document.getElementById("btn-close-header-alert")?.addEventListener("click", () => {
        this.dismissHeaderToast();
      });
      const mainTimelineChk = document.getElementById("main-auto-timeline-chk");
      if (mainTimelineChk) {
        mainTimelineChk.addEventListener("change", () => {
          if (mainTimelineChk.checked) {
            const mainProjChk = document.getElementById("main-auto-import-chk");
            if (mainProjChk && !mainProjChk.checked) {
              mainProjChk.checked = true;
            }
            this.showHeaderToast(
              "Auto-Timeline: Files will import directly into your active timeline/top layer. Import may cause a brief pause.",
              6e3
            );
          } else {
            this.dismissHeaderToastIf("Auto-Timeline");
          }
        });
      }
      document.getElementById("setting-location-mode")?.addEventListener("change", () => {
        this.updateDownloadLocationModeUI();
      });
      document.getElementById("btn-browse-custom-location")?.addEventListener("click", () => {
        const modeSel = document.getElementById("setting-location-mode");
        const currentMode = modeSel?.value || (this.settings?.downloads?.downloadLocationMode === "project" ? "simple" : this.settings?.downloads?.downloadLocationMode) || "custom";
        const targetMode = currentMode === "custom_flat" ? "custom_flat" : "custom";
        this.selectFolderModern((folderPath) => {
          const input = document.getElementById("setting-custom-location");
          if (input) input.value = folderPath;
          if (modeSel) modeSel.value = targetMode;
          this.updateDownloadLocationModeUI();
        });
      });
      document.getElementById("target-dir-display")?.addEventListener("click", () => {
        this.selectFolderModern((folderPath) => {
          const modeSel = document.getElementById("setting-location-mode");
          const currentMode = modeSel?.value || (this.settings?.downloads?.downloadLocationMode === "project" ? "simple" : this.settings?.downloads?.downloadLocationMode) || "custom_flat";
          const targetMode = currentMode === "custom_flat" ? "custom_flat" : "custom";
          const updatedDownloads = {
            ...this.settings?.downloads,
            downloadLocationMode: targetMode,
            customLocation: folderPath
          };
          if (this.settings) {
            this.settings.downloads = updatedDownloads;
          }
          try {
            const saved = JSON.parse(localStorage.getItem("mf_saved_settings") || "{}");
            saved.downloads = { ...saved.downloads || {}, ...updatedDownloads };
            localStorage.setItem("mf_saved_settings", JSON.stringify(saved));
          } catch (_) {
          }
          serviceClient.updateSettings({
            downloads: updatedDownloads
          });
          if (typeof window.Settings !== "undefined") {
            window.Settings.save({
              downloadLocationMode: targetMode,
              customLocation: folderPath,
              downloadFolder: folderPath
            });
          }
          if (this.settings?.downloads?.autoProjectPath) {
            const curKey = this.normalizeProjectPath(this.projectContext?.projectPath);
            this.savePerProjectPathOverride(curKey, targetMode, folderPath);
          }
          this.updateTargetDirDisplay();
          const customLocInput = document.getElementById("setting-custom-location");
          if (customLocInput) customLocInput.value = folderPath;
          if (modeSel) modeSel.value = targetMode;
          this.updateDownloadLocationModeUI();
        });
      });
      document.getElementById("btn-analyze")?.addEventListener("click", () => this.handleAnalyze());
      urlInput?.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
          this.handleAnalyze();
        }
      });
      document.getElementById("btn-paste")?.addEventListener("click", async () => {
        await this.handlePasteAction();
        onUrlChanged(urlInput?.value || "");
      });
      document.getElementById("btn-paste-url")?.addEventListener("click", async () => {
        await this.handlePasteAction();
        onUrlChanged(urlInput?.value || "");
      });
      document.getElementById("btn-close-card")?.addEventListener("click", () => {
        const card = document.getElementById("media-card-section");
        if (card) card.style.display = "none";
        this.currentMetadata = null;
      });
      document.getElementById("btn-download-action")?.addEventListener("click", async () => {
        await this.refreshProjectContext();
        this.handleDownloadClick();
      });
      document.getElementById("btn-pause-all")?.addEventListener("click", () => {
        for (const item of this.queue) {
          if (item.status === "downloading" || item.status === "waiting") {
            serviceClient.pauseDownload(item.id);
          }
        }
        serviceClient.send({ type: "PAUSE_DOWNLOAD", payload: {} });
      });
      document.getElementById("btn-resume-all")?.addEventListener("click", () => {
        let count = 0;
        for (const item of this.queue) {
          if (item.status === "paused" || item.status === "failed" || item.status === "downloading") {
            serviceClient.resumeDownload(item.id);
            count++;
          }
        }
        serviceClient.send({ type: "RESUME_DOWNLOAD", payload: {} });
      });
      document.getElementById("btn-clear-completed")?.addEventListener("click", () => {
        serviceClient.clearCompleted();
        this.queue = this.queue.filter((i) => i.status === "downloading" || i.status === "waiting");
        this.renderQueue();
      });
      const queueContainer = document.getElementById("queue-container");
      queueContainer?.addEventListener("click", (e) => {
        const btn = e.target.closest("button");
        if (!btn) return;
        const itemEl = btn.closest(".queue-item");
        const itemId = itemEl?.id?.replace("q-item-", "");
        if (!itemId) return;
        if (btn.classList.contains("btn-pause")) {
          serviceClient.pauseDownload(itemId);
        } else if (btn.classList.contains("btn-resume")) {
          serviceClient.resumeDownload(itemId);
        } else if (btn.classList.contains("btn-cancel")) {
          serviceClient.cancelDownload(itemId);
          this.queue = this.queue.filter((i) => i.id !== itemId);
          this.renderQueue();
        } else if (btn.classList.contains("btn-retry")) {
          serviceClient.retryDownload(itemId);
        } else if (btn.classList.contains("btn-reveal")) {
          const item = this.queue.find((i) => i.id === itemId);
          if (item?.outputPath) hostAdapter.revealInFinder(item.outputPath);
        } else if (btn.classList.contains("btn-import")) {
          const item = this.queue.find((i) => i.id === itemId);
          const targetPath = item?.outputPath || item?.downloadedPath;
          if (targetPath) {
            btn.setAttribute("disabled", "true");
            btn.style.opacity = "0.5";
            this.showHeaderToast(`Importing "${item?.title || "media"}" to Project Panel...`, 3e3);
            const locMode = (this.settings?.downloads?.downloadLocationMode === "project" ? "simple" : this.settings?.downloads?.downloadLocationMode) || "simple";
            const isCustomLocation = locMode === "custom" || locMode === "custom_flat" || Boolean(item?.targetDirectory);
            const isCustomFlatLocation = locMode === "custom_flat";
            const isSimpleLocation = locMode === "simple";
            const isCloud = Boolean(item?.isCloud || item?.metadata?.isCloud || item?.customFolderName?.toLowerCase().includes("cloud") || item?.metadata?.uploader?.toLowerCase().includes("cloud"));
            const isPlaylist = Boolean(item?.isPlaylist || item?.metadata?.isPlaylist || item?.playlistTitle);
            const isBatch = Boolean(item?.isBatch || item?.metadata?.isBatch);
            const isSingleLink = !isPlaylist && !isCloud && !isBatch;
            const autoTimelineEnabled = document.getElementById("main-auto-timeline-chk")?.checked || false;
            hostAdapter.importToProject(targetPath, {
              downloadLocationMode: locMode,
              isCustomPath: isCustomLocation,
              isCustomFlat: isCustomFlatLocation,
              isSimplePath: isSimpleLocation,
              isSimple: isSimpleLocation,
              isCloud,
              isPlaylist,
              isSingleLink,
              playlistTitle: item?.playlistTitle || item?.metadata?.playlistTitle || "",
              customFolderName: item?.customFolderName || item?.metadata?.customFolderName || "",
              subFolderName: item?.subFolderName || item?.metadata?.subFolderName || "",
              addToTimeline: autoTimelineEnabled && isSingleLink,
              insertToTimeline: autoTimelineEnabled && isSingleLink
            }).then((success) => {
              btn.removeAttribute("disabled");
              btn.style.opacity = "1";
              if (success) {
                this.showHeaderToast(`Imported "${item?.title || "media"}" into Project bin${autoTimelineEnabled ? " and Timeline" : ""}!`, 4e3);
              } else {
                this.showHeaderToast("Could not import media to Project Panel. Please ensure project bin is unlocked or retry.", 5e3);
              }
            }).catch((err) => {
              btn.removeAttribute("disabled");
              btn.style.opacity = "1";
              console.error("[MediaFetch] Manual import error:", err);
              this.showHeaderToast("Import failed: " + (err?.message || err), 5e3);
            });
          } else {
            this.showHeaderToast("Media file path not found on disk.", 4e3);
          }
        }
      });
      const openUnifiedSettings = () => {
        serviceClient.getSettings();
        serviceClient.getDiagnostics();
        if (typeof window.Settings !== "undefined") {
          const s = window.Settings.load();
          const pexelsInput = document.getElementById("setting-studio-pexels-key");
          const pixabayInput = document.getElementById("setting-studio-pixabay-key");
          const unsplashInput = document.getElementById("setting-studio-unsplash-key");
          const giphyInput = document.getElementById("setting-studio-giphy-key");
          const timelineCheck = document.getElementById("setting-studio-auto-timeline");
          if (pexelsInput) pexelsInput.value = s.pexelsApiKey || "";
          if (pixabayInput) pixabayInput.value = s.pixabayApiKey || "";
          if (unsplashInput) unsplashInput.value = s.unsplashApiKey || "";
          if (giphyInput) giphyInput.value = s.giphyApiKey || "";
          if (timelineCheck) timelineCheck.checked = s.autoInsertTimeline !== false;
        }
        if (typeof window.MediaFetchLicense?.updateBadge === "function") {
          window.MediaFetchLicense.updateBadge();
        }
        this.openModal("modal-settings");
      };
      document.getElementById("btn-top-settings")?.addEventListener("click", openUnifiedSettings);
      document.getElementById("btn-settings")?.addEventListener("click", openUnifiedSettings);
      const executeInstantClipboardPaste = async (passedBlob) => {
        if (window.__MF_IS_PASTING_CLIPBOARD__) {
          console.log("[MediaFetch] Clipboard paste already in progress, ignoring duplicate trigger.");
          return;
        }
        window.__MF_IS_PASTING_CLIPBOARD__ = true;
        const btn = document.getElementById("btn-clipboard-paste");
        if (btn) {
          btn.style.opacity = "0.7";
          btn.style.pointerEvents = "none";
        }
        const safetyResetTimer = setTimeout(() => {
          window.__MF_IS_PASTING_CLIPBOARD__ = false;
          if (btn) {
            btn.style.opacity = "1";
            btn.style.pointerEvents = "auto";
          }
        }, 8e3);
        try {
          let imported = false;
          const formatSelect = document.getElementById("select-clipboard-format");
          let preferredFormat = (formatSelect?.value || localStorage.getItem("mf_clipboard_img_format") || "png").toLowerCase().trim();
          if (preferredFormat === "jpeg") preferredFormat = "jpg";
          if (!["png", "jpg", "webp"].includes(preferredFormat)) preferredFormat = "png";
          try {
            if (!this.projectContext || !this.projectContext.projectDirectory) {
              this.projectContext = await hostAdapter.getProjectContext();
            }
          } catch (_) {
          }
          let activeProjDir = this.projectContext?.projectDirectory || "";
          if (!activeProjDir && typeof window.CSInterface !== "undefined") {
            try {
              const cs = new window.CSInterface();
              const hInfoStr = await new Promise((res) => cs.evalScript("MediaFetchHost.getHostInfo()", res));
              const hInfo = JSON.parse(hInfoStr);
              if (hInfo && hInfo.projectPath) {
                const pClean = hInfo.projectPath.replace(/\\/g, "/");
                activeProjDir = pClean.substring(0, pClean.lastIndexOf("/")).replace(/\//g, "\\");
              }
            } catch (_) {
            }
          }
          if (!activeProjDir && typeof window.__adobe_cep__ !== "undefined") {
            try {
              const hInfoStr = await new Promise((res) => {
                window.__adobe_cep__.evalScript("MediaFetchHost.getHostInfo()", res);
              });
              const hInfo = JSON.parse(hInfoStr);
              if (hInfo && hInfo.projectPath) {
                const pClean = hInfo.projectPath.replace(/\\/g, "/");
                activeProjDir = pClean.substring(0, pClean.lastIndexOf("/")).replace(/\//g, "\\");
              }
            } catch (_) {
            }
          }
          const nodeRequire = window.require || window.cep_node?.require || (typeof __require !== "undefined" ? __require : null);
          const fsMod = nodeRequire ? (() => {
            try {
              return nodeRequire("fs");
            } catch (_) {
              return null;
            }
          })() : null;
          const pathMod = nodeRequire ? (() => {
            try {
              return nodeRequire("path");
            } catch (_) {
              return null;
            }
          })() : null;
          const osMod = nodeRequire ? (() => {
            try {
              return nodeRequire("os");
            } catch (_) {
              return null;
            }
          })() : null;
          const locMode = (this.settings?.downloads?.downloadLocationMode === "project" ? "simple" : this.settings?.downloads?.downloadLocationMode) || "simple";
          const customLoc = (this.settings?.downloads?.customLocation || "").trim();
          const isCustomFlat = locMode === "custom_flat";
          const isCustom = locMode === "custom";
          const isSimple = !isCustom && !isCustomFlat;
          const customFolderName = (isCustom || isCustomFlat) && customLoc ? pathMod ? pathMod.basename(customLoc) : "" : "";
          let targetDir = "";
          if (isCustomFlat && customLoc && fsMod) {
            try {
              if (!fsMod.existsSync(customLoc)) fsMod.mkdirSync(customLoc, { recursive: true });
              targetDir = customLoc;
            } catch (_) {
              targetDir = "";
            }
          } else if (isCustom && customLoc && fsMod && pathMod) {
            try {
              const imgDir = pathMod.join(customLoc, "Images");
              if (!fsMod.existsSync(imgDir)) fsMod.mkdirSync(imgDir, { recursive: true });
              targetDir = imgDir;
            } catch (_) {
              targetDir = "";
            }
          }
          if (!targetDir && activeProjDir && fsMod && pathMod) {
            try {
              const projImgDir = pathMod.join(activeProjDir, "MediaFetch", "Images");
              if (!fsMod.existsSync(projImgDir)) fsMod.mkdirSync(projImgDir, { recursive: true });
              targetDir = projImgDir;
            } catch (_) {
              targetDir = "";
            }
          }
          if (!targetDir && osMod && pathMod && fsMod) {
            try {
              const dlDir = pathMod.join(osMod.homedir(), "Downloads", "MediaFetch", "Images");
              if (!fsMod.existsSync(dlDir)) fsMod.mkdirSync(dlDir, { recursive: true });
              targetDir = dlDir;
            } catch (_) {
            }
          }
          if (!targetDir && osMod && pathMod && fsMod) {
            try {
              const tmpDir = pathMod.join(osMod.tmpdir(), "MediaFetch", "Images");
              if (!fsMod.existsSync(tmpDir)) fsMod.mkdirSync(tmpDir, { recursive: true });
              targetDir = tmpDir;
            } catch (_) {
            }
          }
          const shouldInsertTimeline = true;
          const mainProjChk = document.getElementById("main-auto-import-chk");
          const studioProjChk = document.getElementById("studio-auto-import-chk");
          const shouldImportProject = (mainProjChk ? mainProjChk.checked : true) && (studioProjChk ? studioProjChk.checked : true);
          let clipboardBlob = passedBlob || null;
          if (!clipboardBlob && navigator.clipboard && typeof navigator.clipboard.read === "function") {
            try {
              const items = await navigator.clipboard.read();
              for (const item of items) {
                const imgType = item.types.find((t) => t.startsWith("image/"));
                if (imgType) {
                  clipboardBlob = await item.getType(imgType);
                  break;
                }
              }
            } catch (clipErr) {
              console.log("[MediaFetch] Direct navigator.clipboard.read note:", clipErr);
            }
          }
          if (clipboardBlob && fsMod && pathMod && targetDir) {
            try {
              const nowStr = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
              let finalBlob = clipboardBlob;
              let ext = preferredFormat;
              if (preferredFormat === "jpg" || preferredFormat === "jpeg") {
                ext = "jpg";
                const bmp = await createImageBitmap(clipboardBlob);
                const canvas = document.createElement("canvas");
                canvas.width = bmp.width;
                canvas.height = bmp.height;
                const ctx = canvas.getContext("2d");
                if (ctx) {
                  ctx.fillStyle = "#ffffff";
                  ctx.fillRect(0, 0, canvas.width, canvas.height);
                  ctx.drawImage(bmp, 0, 0);
                  const converted = await new Promise((r) => canvas.toBlob(r, "image/jpeg", 1));
                  if (converted) finalBlob = converted;
                }
              } else if (preferredFormat === "webp") {
                ext = "webp";
                const bmp = await createImageBitmap(clipboardBlob);
                const canvas = document.createElement("canvas");
                canvas.width = bmp.width;
                canvas.height = bmp.height;
                const ctx = canvas.getContext("2d");
                if (ctx) {
                  ctx.drawImage(bmp, 0, 0);
                  const converted = await new Promise((r) => canvas.toBlob(r, "image/webp", 1));
                  if (converted) finalBlob = converted;
                }
              } else {
                ext = "png";
              }
              const fileName = `Clipboard_${nowStr}.${ext}`;
              const filePath = pathMod.join(targetDir, fileName);
              const arrayBuf = await finalBlob.arrayBuffer();
              fsMod.writeFileSync(filePath, new Uint8Array(arrayBuf));
              if (fsMod.existsSync(filePath) && fsMod.statSync(filePath).size > 100) {
                let importOk = false;
                if (shouldImportProject || shouldInsertTimeline) {
                  importOk = await hostAdapter.importToProject(filePath, {
                    isSingleLink: true,
                    addToTimeline: shouldInsertTimeline,
                    insertToTimeline: shouldInsertTimeline,
                    isClipboard: true,
                    projectDirectory: activeProjDir,
                    downloadLocationMode: locMode,
                    isCustomFlat,
                    isCustomPath: isCustom,
                    isSimplePath: isSimple,
                    isSimple,
                    customFolderName
                  });
                }
                if (shouldInsertTimeline && importOk) {
                  this.showHeaderToast(`Pasted "${fileName}" into Project & Timeline!`, 4e3);
                } else if (importOk) {
                  this.showHeaderToast(`Pasted "${fileName}" into Adobe project bin!`, 4e3);
                } else {
                  this.showHeaderToast(`Saved clipboard image "${fileName}" to disk!`, 4e3);
                }
                imported = true;
              }
            } catch (fastPasteErr) {
              console.warn("[MediaFetch] Fast in-memory paste error, falling back to service:", fastPasteErr);
            }
          }
          if (!imported && nodeRequire && fsMod && pathMod && targetDir) {
            try {
              const cp = nodeRequire("child_process");
              const nowStr = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
              const outExt = preferredFormat === "jpg" ? "jpg" : preferredFormat === "webp" ? "webp" : "png";
              const outImg = pathMod.join(targetDir, `Clipboard_${nowStr}.${outExt}`);
              const escapedPath = outImg.replace(/'/g, "''");
              const psScript = `
Add-Type -AssemblyName System.Windows.Forms;
Add-Type -AssemblyName System.Drawing;

function Save-ImageFromClipboard {
    param([string]$DestPath, [string]$Fmt)

    try {
        $img = Get-Clipboard -Format Image;
        if ($img -ne $null) {
            $saveFmt = if ($Fmt -eq 'jpg') { [System.Drawing.Imaging.ImageFormat]::Jpeg } else { [System.Drawing.Imaging.ImageFormat]::Png };
            $img.Save($DestPath, $saveFmt);
            $img.Dispose();
            if (Test-Path $DestPath) {
                Write-Output ('SAVED_IMAGE:' + $DestPath);
                return $true;
            }
        }
    } catch {}

    $data = [System.Windows.Forms.Clipboard]::GetDataObject();
    if ($null -eq $data) { return $false; }

    if ($data.GetDataPresent('PNG')) {
        try {
            $stream = $data.GetData('PNG');
            if ($stream -is [System.IO.MemoryStream]) {
                if ($Fmt -eq 'jpg') {
                    $bmp = [System.Drawing.Image]::FromStream($stream);
                    $bmp.Save($DestPath, [System.Drawing.Imaging.ImageFormat]::Jpeg);
                    $bmp.Dispose();
                } else {
                    [System.IO.File]::WriteAllBytes($DestPath, $stream.ToArray());
                }
                $stream.Dispose();
                if (Test-Path $DestPath) {
                    Write-Output ('SAVED_IMAGE:' + $DestPath);
                    return $true;
                }
            }
        } catch {}
    }

    if ($data.GetDataPresent('DeviceIndependentBitmap')) {
        try {
            $dibStream = $data.GetData('DeviceIndependentBitmap');
            if ($dibStream -is [System.IO.MemoryStream]) {
                $dibBytes = $dibStream.ToArray();
                $dibStream.Dispose();
                if ($dibBytes.Length -gt 40) {
                    $headerSize = [BitConverter]::ToInt32($dibBytes, 0);
                    $bitCount = [BitConverter]::ToInt16($dibBytes, 14);
                    $compression = [BitConverter]::ToInt32($dibBytes, 16);
                    $clrUsed = [BitConverter]::ToInt32($dibBytes, 32);

                    $paletteSize = 0;
                    if ($clrUsed -gt 0) {
                        $paletteSize = $clrUsed * 4;
                    } elseif ($bitCount -le 8) {
                        $paletteSize = [Math]::Pow(2, $bitCount) * 4;
                    } elseif ($compression -eq 3) {
                        $paletteSize = 12;
                    }

                    $offBits = 14 + $headerSize + $paletteSize;
                    $fileSize = 14 + $dibBytes.Length;

                    $bmpBytes = New-Object byte[] $fileSize;
                    $bmpBytes[0] = 0x42;
                    $bmpBytes[1] = 0x4D;
                    [Array]::Copy([BitConverter]::GetBytes([int]$fileSize), 0, $bmpBytes, 2, 4);
                    [Array]::Copy([BitConverter]::GetBytes([int]$offBits), 0, $bmpBytes, 10, 4);
                    [Array]::Copy($dibBytes, 0, $bmpBytes, 14, $dibBytes.Length);

                    $ms = New-Object System.IO.MemoryStream(,$bmpBytes);
                    $bmp = [System.Drawing.Image]::FromStream($ms);
                    $saveFmt = if ($Fmt -eq 'jpg') { [System.Drawing.Imaging.ImageFormat]::Jpeg } else { [System.Drawing.Imaging.ImageFormat]::Png };
                    $bmp.Save($DestPath, $saveFmt);
                    $bmp.Dispose();
                    $ms.Dispose();

                    if (Test-Path $DestPath) {
                        Write-Output ('SAVED_IMAGE:' + $DestPath);
                        return $true;
                    }
                }
            }
        } catch {}
    }

    if ([System.Windows.Forms.Clipboard]::ContainsImage()) {
        try {
            $img = [System.Windows.Forms.Clipboard]::GetImage();
            if ($img -ne $null) {
                $saveFmt = if ($Fmt -eq 'jpg') { [System.Drawing.Imaging.ImageFormat]::Jpeg } else { [System.Drawing.Imaging.ImageFormat]::Png };
                $img.Save($DestPath, $saveFmt);
                $img.Dispose();
                if (Test-Path $DestPath) {
                    Write-Output ('SAVED_IMAGE:' + $DestPath);
                    return $true;
                }
            }
        } catch {}
    }

    return $false;
}

Save-ImageFromClipboard -DestPath '${escapedPath}' -Fmt '${preferredFormat}';
`;
              const stdout = cp.execSync(
                'powershell.exe -STA -NoProfile -ExecutionPolicy Bypass -Command "' + psScript.replace(/\r?\n/g, " ") + '"',
                { encoding: "utf8", timeout: 5e3, windowsHide: true }
              ) || "";
              let savedPath = "";
              if (stdout.includes("SAVED_IMAGE:")) {
                const line = stdout.split("\n").find((l) => l.includes("SAVED_IMAGE:")) || "";
                savedPath = line.substring(line.indexOf("SAVED_IMAGE:") + "SAVED_IMAGE:".length).trim();
              } else if (fsMod.existsSync(outImg) && fsMod.statSync(outImg).size > 100) {
                savedPath = outImg;
              }
              if (savedPath && fsMod.existsSync(savedPath) && fsMod.statSync(savedPath).size > 100) {
                let importOk = false;
                if (shouldImportProject || shouldInsertTimeline) {
                  importOk = await hostAdapter.importToProject(savedPath, {
                    isSingleLink: true,
                    addToTimeline: shouldInsertTimeline,
                    insertToTimeline: shouldInsertTimeline,
                    isClipboard: true,
                    projectDirectory: activeProjDir,
                    downloadLocationMode: locMode,
                    isCustomFlat,
                    isCustomPath: isCustom,
                    isSimplePath: isSimple,
                    isSimple,
                    customFolderName
                  });
                }
                const fileName = pathMod.basename(savedPath);
                if (shouldInsertTimeline && importOk) {
                  this.showHeaderToast(`Pasted "${fileName}" into Project & Timeline!`, 4e3);
                } else if (importOk) {
                  this.showHeaderToast(`Pasted "${fileName}" into Adobe project bin!`, 4e3);
                } else {
                  this.showHeaderToast(`Saved clipboard image "${fileName}" to disk!`, 4e3);
                }
                imported = true;
              }
            } catch (directExtractErr) {
              console.warn("[MediaFetch] Direct in-panel clipboard extraction error:", directExtractErr);
            }
          }
          if (!imported) {
            const port = window.__MF_PORT__ || 48924;
            const qParams = new URLSearchParams();
            if (activeProjDir) qParams.set("projectDir", activeProjDir);
            qParams.set("format", preferredFormat);
            if (locMode) qParams.set("downloadLocationMode", locMode);
            if (customLoc) qParams.set("customLocation", customLoc);
            let data = null;
            try {
              const res = await fetch(`http://127.0.0.1:${port}/api/clipboard/paste-media?${qParams.toString()}`, {
                signal: AbortSignal.timeout(8e3)
              });
              data = await res.json();
            } catch (_) {
              try {
                const res = await fetch(`http://127.0.0.1:48924/api/clipboard/paste-media?${qParams.toString()}`, {
                  signal: AbortSignal.timeout(8e3)
                });
                data = await res.json();
              } catch (e) {
                console.warn("[MediaFetch] Could not reach clipboard service:", e);
              }
            }
            if (data && data.success) {
              if (data.type === "image" || data.type === "file") {
                let importOk = false;
                if (shouldImportProject || shouldInsertTimeline) {
                  importOk = await hostAdapter.importToProject(data.filePath, {
                    isSingleLink: true,
                    addToTimeline: shouldInsertTimeline,
                    insertToTimeline: shouldInsertTimeline,
                    isClipboard: true,
                    projectDirectory: activeProjDir,
                    downloadLocationMode: locMode,
                    isCustomFlat,
                    isCustomPath: isCustom,
                    isSimplePath: isSimple,
                    isSimple,
                    customFolderName
                  });
                }
                if (shouldInsertTimeline && importOk) {
                  this.showHeaderToast(`Pasted "${data.fileName || "image"}" into Project & Timeline!`, 4e3);
                } else if (importOk) {
                  this.showHeaderToast(`Pasted "${data.fileName || "image"}" into Adobe project bin!`, 4e3);
                } else {
                  this.showHeaderToast(`Saved clipboard image "${data.fileName || "image"}" to disk!`, 4e3);
                }
                imported = true;
              } else if (data.type === "text" && data.text) {
                const urlInput2 = document.getElementById("url-input");
                if (urlInput2) {
                  urlInput2.value = data.text;
                  urlInput2.dispatchEvent(new Event("input", { bubbles: true }));
                  this.showHeaderToast("Pasted link from clipboard!", 4e3);
                  imported = true;
                }
              }
            }
          }
          if (!imported) {
            this.showHeaderToast("Clipboard has no image or media. Copy an image or screenshot first!", 4e3);
          }
        } catch (err) {
          console.warn("[MediaFetch] Clipboard paste error:", err);
          this.showHeaderToast("Clipboard paste error: " + (err?.message || "Error"), 4e3);
        } finally {
          window.__MF_IS_PASTING_CLIPBOARD__ = false;
          clearTimeout(safetyResetTimer);
          if (btn) {
            btn.style.opacity = "1";
            btn.style.pointerEvents = "auto";
          }
        }
      };
      document.getElementById("btn-clipboard-paste")?.addEventListener("click", () => executeInstantClipboardPaste());
      window.addEventListener("paste", async (e) => {
        const activeEl = document.activeElement;
        const isInput = activeEl && (activeEl.tagName === "INPUT" || activeEl.tagName === "TEXTAREA" || activeEl.isContentEditable);
        if (isInput) return;
        const items = e.clipboardData?.items;
        let imageFile = null;
        if (items) {
          for (let i = 0; i < items.length; i++) {
            if (items[i].type.startsWith("image/")) {
              imageFile = items[i].getAsFile();
              break;
            }
          }
        }
        if (imageFile) {
          e.preventDefault();
          await executeInstantClipboardPaste(imageFile);
        }
      });
      document.getElementById("btn-history")?.addEventListener("click", () => {
        serviceClient.getHistory();
        this.openModal("modal-history");
      });
      document.getElementById("btn-diagnostics")?.addEventListener("click", () => {
        serviceClient.getDiagnostics();
        this.openModal("modal-diagnostics");
      });
      document.getElementById("btn-setup-wizard-trigger")?.addEventListener("click", () => {
        this.closeModal("modal-diagnostics");
        this.openModal("modal-setup");
        serviceClient.runSystemCheck();
      });
      document.querySelectorAll(".modal-close-btn").forEach((btn) => {
        btn.addEventListener("click", (e) => {
          const overlay = e.target.closest(".modal-overlay");
          if (overlay) overlay.classList.remove("active");
        });
      });
      const modalApiGuide = document.getElementById("modal-api-guide");
      const btnOpenApiGuide = document.getElementById("btn-open-api-guide");
      const btnCloseApiGuide = document.getElementById("btn-close-api-guide");
      const btnDoneApiGuide = document.getElementById("btn-done-api-guide");
      const closeApiGuide = () => {
        if (modalApiGuide) {
          modalApiGuide.style.display = "none";
          modalApiGuide.classList.remove("active");
        }
      };
      btnOpenApiGuide?.addEventListener("click", () => {
        if (modalApiGuide) {
          modalApiGuide.style.display = "flex";
          modalApiGuide.classList.add("active");
        }
      });
      btnCloseApiGuide?.addEventListener("click", closeApiGuide);
      btnDoneApiGuide?.addEventListener("click", closeApiGuide);
      document.querySelectorAll(".btn-api-external-link").forEach((linkBtn) => {
        linkBtn.addEventListener("click", (e) => {
          const u = e.currentTarget.getAttribute("data-url");
          if (u) {
            if (window.__adobe_cep__ && typeof window.__adobe_cep__.openURLInDefaultBrowser === "function") {
              window.__adobe_cep__.openURLInDefaultBrowser(u);
            } else if (window.cep?.util?.openURLInDefaultBrowser) {
              window.cep.util.openURLInDefaultBrowser(u);
            } else {
              window.open(u, "_blank");
            }
          }
        });
      });
      document.querySelectorAll(".tab-btn").forEach((btn) => {
        btn.addEventListener("click", (e) => {
          const targetTab = e.currentTarget.getAttribute("data-tab");
          document.querySelectorAll(".tab-btn").forEach((b) => b.classList.remove("active"));
          document.querySelectorAll(".tab-pane").forEach((p) => p.style.display = "none");
          e.currentTarget.classList.add("active");
          if (targetTab) {
            const pane = document.getElementById(targetTab);
            if (pane) pane.style.display = "block";
          }
        });
      });
      document.getElementById("btn-save-settings")?.addEventListener("click", () => {
        this.saveSettingsFromForm();
        this.closeModal("modal-settings");
      });
      document.getElementById("btn-update-ytdlp")?.addEventListener("click", () => {
        const btn = document.getElementById("btn-update-ytdlp");
        const statusEl = document.getElementById("engine-update-status");
        if (btn) {
          btn.disabled = true;
          btn.textContent = "Checking for updates...";
        }
        if (statusEl) {
          statusEl.style.display = "block";
          statusEl.style.color = "var(--text-secondary, #aaa)";
          statusEl.textContent = "Connecting to official yt-dlp repository...";
        }
        serviceClient.updateYtDlp();
      });
      document.getElementById("btn-setup-install-all")?.addEventListener("click", () => {
        const progRow = document.getElementById("setup-progress-row");
        if (progRow) progRow.style.display = "flex";
        serviceClient.installDependency("all");
      });
      document.getElementById("btn-dup-cancel")?.addEventListener("click", () => {
        this.pendingDownloadParams = null;
        this.closeModal("modal-duplicate");
      });
      document.getElementById("btn-dup-use-existing")?.addEventListener("click", () => {
        this.pendingDownloadParams = null;
        this.closeModal("modal-duplicate");
      });
      document.getElementById("btn-dup-download-new")?.addEventListener("click", () => {
        this.closeModal("modal-duplicate");
        this.executePendingDownload();
      });
      document.getElementById("btn-playlist-select-all")?.addEventListener("click", () => {
        document.querySelectorAll(".playlist-checkbox").forEach((cb) => cb.checked = true);
        document.querySelectorAll(".folder-group-cb").forEach((cb) => {
          cb.checked = true;
          cb.indeterminate = false;
        });
        this.updatePlaylistSelectedCount();
      });
      document.getElementById("btn-playlist-deselect-all")?.addEventListener("click", () => {
        document.querySelectorAll(".playlist-checkbox").forEach((cb) => cb.checked = false);
        document.querySelectorAll(".folder-group-cb").forEach((cb) => {
          cb.checked = false;
          cb.indeterminate = false;
        });
        this.updatePlaylistSelectedCount();
      });
      document.querySelectorAll('input[name="playlist-mode"]').forEach((r) => {
        r.addEventListener("change", (e) => {
          const val = e.target.value;
          const wrapper = document.getElementById("playlist-items-wrapper");
          if (wrapper) {
            wrapper.style.display = val === "selected" ? "block" : "none";
          }
          if (val === "all") {
            document.querySelectorAll(".playlist-checkbox").forEach((cb) => cb.checked = true);
            document.querySelectorAll(".folder-group-cb").forEach((cb) => {
              cb.checked = true;
              cb.indeterminate = false;
            });
          }
          this.updatePlaylistSelectedCount();
        });
      });
      document.getElementById("btn-playlist-confirm-download")?.addEventListener("click", () => {
        this.handlePlaylistDownloadSubmit();
      });
      document.getElementById("btn-playlist-browse-folder")?.addEventListener("click", () => {
        this.selectFolderModern((folderPath) => {
          this.playlistCustomTargetDir = folderPath;
          const pathEl = document.getElementById("playlist-destination-path");
          if (pathEl) pathEl.textContent = folderPath;
        });
      });
      const zipCb = document.getElementById("playlist-zip-package-cb");
      const autoImportCb = document.getElementById("playlist-auto-import-cb");
      const autoImportLabel = autoImportCb?.closest("label");
      zipCb?.addEventListener("change", () => {
        if (zipCb.checked) {
          if (autoImportCb) {
            autoImportCb.checked = false;
            autoImportCb.disabled = true;
          }
          if (autoImportLabel) {
            autoImportLabel.style.opacity = "0.45";
            autoImportLabel.title = "Auto-import is disabled when packaging as ZIP archive";
          }
        } else {
          if (autoImportCb) {
            autoImportCb.disabled = false;
          }
          if (autoImportLabel) {
            autoImportLabel.style.opacity = "1";
            autoImportLabel.title = "";
          }
        }
      });
      autoImportCb?.addEventListener("change", () => {
        if (autoImportCb.checked && zipCb) {
          zipCb.checked = false;
        }
      });
      document.getElementById("btn-link-preview-play")?.addEventListener("click", (e) => {
        e.stopPropagation();
        this.openMediaPreview(this.currentMetadata);
      });
      document.getElementById("link-downloader-thumb-box")?.addEventListener("click", () => {
        this.openMediaPreview(this.currentMetadata);
      });
      document.getElementById("btn-close-media-preview")?.addEventListener("click", () => {
        this.closeMediaPreview();
      });
      const toggleTrimBtn = document.getElementById("btn-toggle-trim");
      if (toggleTrimBtn) {
        toggleTrimBtn.onclick = (e) => {
          if (typeof window.toggleTrimPanel === "function") {
            window.toggleTrimPanel(e);
          }
        };
      }
      document.querySelectorAll(".modal-overlay").forEach((overlay) => {
        overlay.addEventListener("click", (e) => {
          if (e.target === overlay) {
            const id = overlay.id;
            if (id === "modal-media-preview") {
              this.closeMediaPreview();
            } else {
              this.closeModal(id);
            }
          }
        });
      });
      document.getElementById("btn-clear-history")?.addEventListener("click", () => {
        serviceClient.clearHistory();
      });
      document.getElementById("history-search-input")?.addEventListener("input", (e) => {
        const query = e.target.value;
        this.renderHistoryList(query);
      });
    }
    closeCard() {
      const card = document.getElementById("media-card-section");
      if (card) card.style.display = "none";
      this.currentMetadata = null;
    }
    async handlePasteAction() {
      const urlInput = document.getElementById("url-input");
      const pasteBtn = document.getElementById("btn-paste-url");
      if (!urlInput) return;
      let text = "";
      try {
        const nodeReq = window.require;
        if (nodeReq) {
          const cp = nodeReq("child_process");
          if (typeof process !== "undefined" && process.platform === "win32") {
            text = (cp.execSync("powershell.exe -NoProfile -ExecutionPolicy Bypass -Command Get-Clipboard", { encoding: "utf8", timeout: 4e3, windowsHide: true }) || "").trim();
          } else if (typeof process !== "undefined" && process.platform === "darwin") {
            text = (cp.execSync("pbpaste", { encoding: "utf8", timeout: 2e3 }) || "").trim();
          }
        }
      } catch (_) {
      }
      if (!text) {
        try {
          const resp = await fetch("http://127.0.0.1:48924/api/clipboard", { signal: AbortSignal.timeout(3e3) });
          const data = await resp.json();
          if (data && data.success && data.text) {
            text = data.text.trim();
          }
        } catch (_) {
        }
      }
      if (!text) {
        try {
          if (navigator.clipboard && navigator.clipboard.readText) {
            const clip = await navigator.clipboard.readText();
            if (clip && clip.trim().length > 0) {
              text = clip.trim();
            }
          }
        } catch (_) {
        }
      }
      if (!text) {
        try {
          urlInput.focus();
          urlInput.select();
          const success = document.execCommand("paste");
          if (success && urlInput.value && urlInput.value.trim().length > 0) {
            text = urlInput.value.trim();
          }
        } catch (_) {
        }
      }
      if (text && text.trim().length > 0) {
        urlInput.value = text.trim();
        this.hideUrlError();
        urlInput.dispatchEvent(new Event("input", { bubbles: true }));
        if (pasteBtn) {
          const origHtml = pasteBtn.innerHTML;
          pasteBtn.innerHTML = `<span style="color:#00d1b2; font-weight:700; display:inline-flex; align-items:center; gap:4px;">${ICONS.CHECK} Pasted</span>`;
          setTimeout(() => {
            pasteBtn.innerHTML = origHtml;
          }, 1200);
        }
        return;
      }
      urlInput.focus();
      this.showUrlError("No URL found in clipboard. Copy a media link first.");
    }
    get isPro() {
      return window.__MF_EDITION__ === "pro" || window.location.pathname.includes(".pro") || document.title.includes("Pro");
    }
    isCloudUrl(url) {
      const lower = (url || "").toLowerCase();
      return lower.includes("drive.google.com") || lower.includes("dropbox.com") || lower.includes("1drv.ms") || lower.includes("onedrive.live.com") || lower.includes("sharepoint.com") || lower.includes("box.com") || lower.includes("mega.nz");
    }
    isPlaylistUrl(url) {
      const lower = (url || "").toLowerCase();
      const isAppleTrack = (lower.includes("music.apple.com") || lower.includes("itunes.apple.com")) && (lower.includes("?i=") || lower.includes("&i=") || lower.includes("?track=") || lower.includes("&track="));
      if (isAppleTrack) return false;
      return lower.includes("list=") || lower.includes("/playlist") || lower.includes("/sets/") || lower.includes("/album/") || lower.includes("spotify.") && (lower.includes("/playlist/") || lower.includes("/album/") || lower.includes("/artist/")) || lower.includes("drive.google.com/drive/folders/") || lower.includes("drive.google.com/drive/u/") || lower.includes("drive.google.com/folderview") || lower.includes("dropbox.com") && (lower.includes("/scl/fo/") || lower.includes("/sh/") || lower.includes("/folder/")) || lower.includes("1drv.ms") || lower.includes("onedrive.live.com") || lower.includes("sharepoint.com") || lower.includes("box.com/s/") || lower.includes("box.com/folder/") || lower.includes("mega.nz/folder/") || lower.includes("mega.nz/#f!") || lower.includes("pinterest.") && lower.includes("/boards/") || lower.includes("instagram.com/stories/") || lower.includes("behance.net/gallery/") || lower.includes("threads.net/") || lower.includes("threads.com/") || lower.includes("linkedin.com/posts/") || lower.includes("linkedin.com/feed/update/");
    }
    handleAnalyze() {
      const input = document.getElementById("url-input");
      const url = input?.value?.trim();
      this.hideUrlError();
      if (!url) {
        this.showUrlError("Please enter or paste a valid media URL.");
        return;
      }
      if (!this.isPro && this.isCloudUrl(url)) {
        this.showUrlError("Cloud links (Google Drive, Dropbox, OneDrive, Mega) are exclusive to MediaFetch Pro. Upgrade to MediaFetch Pro to download cloud storage files.");
        this.showHeaderToast("Cloud links are exclusive to MediaFetch Pro", 5e3);
        return;
      }
      this.setAnalysisLoading(true);
      if (this.analysisTimeout) clearTimeout(this.analysisTimeout);
      this.analysisTimeout = window.setTimeout(() => {
        if (this.isAnalyzing) {
          this.setAnalysisLoading(false);
          this.showUrlError("Analysis timed out. Please verify your internet connection or check that the URL is public.");
        }
      }, 6e4);
      if (this.isPlaylistUrl(url)) {
        serviceClient.analyzePlaylist(url, 45e3);
        return;
      }
      serviceClient.analyzeUrl(url, 45e3);
    }
    setAnalysisLoading(loading) {
      this.isAnalyzing = loading;
      if (!loading && this.analysisTimeout) {
        clearTimeout(this.analysisTimeout);
        this.analysisTimeout = void 0;
      }
      const btn = document.getElementById("btn-analyze");
      const text = document.getElementById("analyze-btn-text");
      if (btn) {
        btn.disabled = loading;
      }
      if (text) {
        text.textContent = loading ? "Analyzing\u2026" : "Analyze";
      }
    }
    showUrlError(msg) {
      const el = document.getElementById("url-error-msg");
      if (el) {
        el.textContent = msg;
        el.style.display = "block";
      }
    }
    hideUrlError() {
      const el = document.getElementById("url-error-msg");
      if (el) {
        el.style.display = "none";
        el.textContent = "";
      }
    }
    renderMediaCard(meta) {
      this.currentMetadata = meta;
      this.hideUrlError();
      const cardSection = document.getElementById("media-card-section");
      if (!cardSection) return;
      cardSection.style.display = "block";
      const titleEl = document.getElementById("media-card-title");
      const uploaderEl = document.getElementById("media-uploader-name");
      const extractorEl = document.getElementById("media-extractor-tag");
      const thumbImg = document.getElementById("media-thumb-img");
      const durationTag = document.getElementById("media-duration-tag");
      const resTag = document.getElementById("media-resolutions-tag");
      if (resTag) resTag.textContent = "";
      const availableResolutions = meta.availableResolutions || [];
      const realResolutions = availableResolutions.filter((r) => r >= 144 && r <= 2160);
      if (titleEl) titleEl.textContent = meta.title;
      if (uploaderEl) uploaderEl.textContent = meta.uploader || meta.channel || "Unknown Creator";
      if (extractorEl) extractorEl.textContent = meta.extractor || "Web";
      if (thumbImg) {
        thumbImg.src = meta.thumbnail || "";
        thumbImg.onerror = () => {
          if (thumbImg.src && thumbImg.src.includes("maxresdefault.jpg")) {
            thumbImg.src = thumbImg.src.replace("maxresdefault.jpg", "hqdefault.jpg");
          }
        };
      }
      const isCloudEarly = Boolean(
        meta.isCloud || meta.extractor === "cloud" ||
        (meta.uploader && meta.uploader.toLowerCase().includes("cloud")) ||
        (meta.url && (meta.url.includes("drive.google.com") || meta.url.includes("dropbox.com") || meta.url.includes("onedrive") || meta.url.includes("1drv.ms") || meta.url.includes("mega.nz")))
      );
      if (meta.isUpcoming) {
        if (durationTag) durationTag.textContent = "UPCOMING";
        if (resTag) resTag.textContent = "\u23F3 Upcoming Premiere / Live Event \u2022 HD Cover Photo is Ready to Download";
        this.updateDropdownsForMode("image");
        this.showHeaderToast("Upcoming broadcast detected. High-res Photo / Cover is ready to download.", 6e3);
      } else if (isCloudEarly) {
        if (durationTag) {
          if (meta.mediaType === "audio" || meta.isAudio) {
            durationTag.textContent = "AUDIO";
          } else if (meta.mediaType === "image" || meta.isImage) {
            durationTag.textContent = "PHOTO";
          } else {
            durationTag.textContent = "CLOUD";
          }
        }
        if (resTag) {
          if (meta.mediaType === "image" || meta.isImage) {
            resTag.textContent = "Direct Cloud Image Download \u2022 Original Quality";
          } else if (meta.mediaType === "audio" || meta.isAudio) {
            resTag.textContent = "Direct Cloud Audio Download";
          } else {
            resTag.textContent = "Direct Cloud Download \u2022 Original Quality";
          }
        }
        if (meta.mediaType === "image" || meta.isImage) {
          this.updateDropdownsForMode("image");
        }
      } else if (meta.mediaType === "image" || meta.isImage) {
        if (durationTag) durationTag.textContent = "PHOTO";
        if (resTag) resTag.textContent = meta.resolution ? `Resolution: ${meta.resolution}` : "Original High-Res Photo / Cover";
        this.updateDropdownsForMode("image");
      } else {
        if (resTag) {
          if (realResolutions.length > 0) {
            resTag.textContent = `Available Stream Resolutions: ${realResolutions.map((r) => r + "p").join(", ")}`;
          } else {
            resTag.textContent = meta.resolution || (meta.mediaType === "audio" ? "Audio Stream" : "High Quality Stream");
          }
        }
        if (durationTag) {
          if (meta.mediaType === "image" || meta.isImage) {
            durationTag.textContent = "PHOTO";
          } else if (meta.duration && meta.duration > 0) {
            durationTag.textContent = this.formatDuration(meta.duration);
          } else {
            durationTag.textContent = meta.mediaType === "audio" ? "AUDIO" : meta.mediaType === "video" ? "VIDEO" : "00:00";
          }
        }
      }
      if (meta.mediaType === "video" && (!meta.duration || meta.duration <= 0) && (meta.directStreamUrl || meta.url)) {
        try {
          const probeTarget = meta.directStreamUrl || (meta.url && meta.url.includes(".mp4") ? meta.url : "");
          if (probeTarget) {
            const probeVid = document.createElement("video");
            probeVid.preload = "metadata";
            probeVid.src = probeTarget;
            probeVid.onloadedmetadata = () => {
              if (probeVid.duration && !isNaN(probeVid.duration) && probeVid.duration > 0) {
                meta.duration = Math.round(probeVid.duration);
                if (durationTag) durationTag.textContent = this.formatDuration(meta.duration);
              }
            };
          }
        } catch (_) {
        }
      }
      const isCloud = Boolean(
        meta.isCloud || meta.uploader && meta.uploader.toLowerCase().includes("cloud") || meta.url && (meta.url.includes("drive.google.com") || meta.url.includes("dropbox.com") || meta.url.includes("onedrive") || meta.url.includes("1drv.ms") || meta.url.includes("mega.nz"))
      );
      const profileGroup = document.getElementById("profile-select-group");
      const isMultiCarousel = Boolean(meta.carouselSlides && meta.carouselSlides.length > 1);
      if (isMultiCarousel) {
        if (profileGroup) profileGroup.style.display = "none";
      } else {
        if (profileGroup) profileGroup.style.display = "block";
      }
      const profileSelect = document.getElementById("profile-select");
      const formatSelect = document.getElementById("format-select");
      if ((isCloud || meta.mediaType === "image" || meta.isImage) && profileSelect) {
        profileSelect.innerHTML = "";
        if (meta.mediaType === "video" || meta.hasVideo) {
          profileSelect.appendChild(new Option("Original Video (Master Quality)", "best-available", true, true));
          profileSelect.appendChild(new Option("Lossless Audio (WAV / FLAC)", "audio-wav"));
          profileSelect.appendChild(new Option("MP3 Audio (320 kbps High Quality)", "audio-mp3-320"));
          if (formatSelect) {
            formatSelect.value = "mp4";
          }
          profileSelect.onchange = () => {
            if (profileSelect.value === "audio-wav") {
              if (formatSelect) formatSelect.value = "wav";
            } else if (profileSelect.value === "audio-mp3-320") {
              if (formatSelect) formatSelect.value = "mp3";
            } else {
              if (formatSelect) formatSelect.value = "mp4";
            }
          };
        } else if (meta.mediaType === "audio" || meta.isAudio) {
          profileSelect.appendChild(new Option("Original Audio / Lossless (WAV)", "audio-wav", true, true));
          profileSelect.appendChild(new Option("MP3 Audio (320 kbps High Quality)", "audio-mp3-320"));
          if (formatSelect) {
            formatSelect.value = "wav";
          }
          profileSelect.onchange = () => {
            if (formatSelect) formatSelect.value = profileSelect.value === "audio-mp3-320" ? "mp3" : "wav";
          };
        } else if (meta.mediaType === "image" || meta.isImage) {
          profileSelect.appendChild(new Option("Original Photo (Master Quality)", "image-orig", true, true));
          if (formatSelect) formatSelect.value = "jpg";
        }
        profileSelect.dispatchEvent(new Event("change"));
      } else if (!meta.isUpcoming && realResolutions.length > 0 && profileSelect && this.currentMode !== "audio-only") {
        profileSelect.innerHTML = "";
        const has4K = realResolutions.some((r) => r >= 2160);
        const has1080 = realResolutions.includes(1080);
        const recommendedRes = has1080 ? 1080 : realResolutions.find((r) => r <= 1080) || realResolutions[realResolutions.length - 1];
        for (const res of realResolutions) {
          let label = "";
          const isRec = res === recommendedRes;
          if (res >= 2160) {
            label = "4K Ultra HD (2160p) - Studio Master (Slower, Largest File)";
          } else if (res >= 1440) {
            label = "1440p Quad HD (2K) - High Quality (Moderate Speed)";
          } else if (res >= 1080) {
            label = isRec ? "1080p Full HD - Recommended (Fast & Balanced)" : "1080p Full HD - Standard (Fast & Balanced)";
          } else if (res >= 720) {
            label = isRec ? "720p HD - Recommended (Light File)" : "720p HD - Very Fast (Light File)";
          } else if (res >= 480) {
            label = isRec ? "480p SD - Recommended (Standard Quality)" : "480p SD - Lightweight (Fast Download)";
          } else {
            label = isRec ? `${res}p - Recommended (Small File)` : `${res}p - Super Fast / Instant (Small File)`;
          }
          const opt = new Option(label, `res-${res}`, isRec, isRec);
          profileSelect.appendChild(opt);
        }
        profileSelect.appendChild(new Option("MP3 Studio Master (320 kbps High Quality Audio)", "audio-mp3-320"));
        profileSelect.appendChild(new Option("Lossless WAV (48kHz Uncompressed Audio)", "audio-wav"));
        profileSelect.onchange = () => {
          if (profileSelect.value === "audio-wav") {
            if (formatSelect) formatSelect.value = "wav";
          } else if (profileSelect.value === "audio-mp3-320") {
            if (formatSelect) formatSelect.value = "mp3";
          } else {
            if (formatSelect && (formatSelect.value === "mp3" || formatSelect.value === "wav")) {
              formatSelect.value = "mp4";
            }
          }
        };
        if (has4K) {
          this.showHeaderToast(
            "4K Ultra HD is available for this video! Auto-selected 1080p for fast editing. Select 4K in Quality Profile if you need master resolution.",
            7e3
          );
        }
        profileSelect.dispatchEvent(new Event("change"));
      }
      const carouselWrapper = document.getElementById("media-carousel-wrapper");
      const carouselTrack = document.getElementById("carousel-track");
      const carouselCount = document.getElementById("carousel-slide-count");
      const btnCarouselDownloadAll = document.getElementById("btn-carousel-download-all");
      if (meta.carouselSlides && meta.carouselSlides.length > 0) {
        if (carouselWrapper) carouselWrapper.style.display = "block";
        if (carouselCount) carouselCount.textContent = String(meta.carouselSlides.length);
        if (carouselTrack) {
          carouselTrack.innerHTML = "";
          meta.carouselSlides.forEach((slide) => {
            const slideCard = document.createElement("div");
            slideCard.style.cssText = "position: relative; flex: 0 0 85px; height: 110px; border-radius: 4px; overflow: hidden; background: #222; border: 1px solid #444; display: flex; flex-direction: column;";
            const isVid = slide.mediaType === "video";
            slideCard.innerHTML = `
            <div style="position: relative; flex: 1; overflow: hidden;">
              <img src="${slide.thumbnail || slide.url}" style="width: 100%; height: 100%; object-fit: cover;" onerror="this.src='data:image/svg+xml;utf8,<svg xmlns=\\'http://www.w3.org/2000/svg\\' width=\\'85\\' height=\\'80\\' fill=\\'%23333\\'><rect width=\\'100%\\' height=\\'100%\\'/></svg>'">
              <span style="position: absolute; top: 2px; left: 2px; background: rgba(0,0,0,0.7); font-size: 8px; padding: 1px 4px; border-radius: 3px; color: #fff;">#${slide.slideIndex} ${isVid ? "VIDEO" : "IMAGE"}</span>
            </div>
            <button class="btn btn-primary btn-sm btn-slide-import" style="border-radius: 0; font-size: 9px; padding: 3px 2px; text-align: center; width: 100%; cursor: pointer;" title="Download & Import Slide #${slide.slideIndex}">
              Import
            </button>
          `;
            slideCard.querySelector(".btn-slide-import")?.addEventListener("click", () => {
              this.handleDirectSlideDownload(slide, meta);
            });
            carouselTrack.appendChild(slideCard);
          });
        }
        if (btnCarouselDownloadAll) {
          btnCarouselDownloadAll.onclick = () => {
            this.handleDownloadAllSlides(meta);
          };
        }
      } else {
        if (carouselWrapper) carouselWrapper.style.display = "none";
        if (carouselTrack) carouselTrack.innerHTML = "";
      }
    }
    handleDirectSlideDownload(slide, meta) {
      const isVid = slide.mediaType === "video";
      const profile = {
        type: isVid ? "video" : "image",
        presetId: isVid ? "video-1080p" : "best-available",
        label: isVid ? `Slide #${slide.slideIndex} Video` : `Slide #${slide.slideIndex} Photo`,
        container: isVid ? "mp4" : "jpg",
        remuxToMp4: isVid
      };
      serviceClient.startDownload(slide.url, profile, this.projectContext, void 0, {
        title: `${meta.title || "Slide"} - Slide ${slide.slideIndex}`,
        thumbnail: slide.thumbnail || slide.url
      });
    }
    handleDownloadAllSlides(meta) {
      if (!meta.carouselSlides || meta.carouselSlides.length === 0) return;
      for (const slide of meta.carouselSlides) {
        this.handleDirectSlideDownload(slide, meta);
      }
    }
    renderPlaylistModal(playlist) {
      this.currentPlaylist = playlist;
      this.playlistCustomTargetDir = "";
      const isCloud = Boolean(
        playlist.isCloud || playlist.uploader && playlist.uploader.toLowerCase().includes("cloud") || playlist.url && (playlist.url.includes("drive.google.com") || playlist.url.includes("dropbox.com") || playlist.url.includes("onedrive") || playlist.url.includes("1drv.ms") || playlist.url.includes("mega.nz"))
      );
      const titleEl = document.getElementById("playlist-title");
      const countEl = document.getElementById("playlist-count");
      const uploaderEl = document.getElementById("playlist-uploader");
      const allCountEl = document.getElementById("playlist-all-count");
      const listContainer = document.getElementById("playlist-items-list");
      if (titleEl) titleEl.textContent = playlist.title;
      if (countEl) countEl.textContent = `${playlist.itemCount} items`;
      if (uploaderEl) uploaderEl.textContent = playlist.uploader || (isCloud ? "Cloud Storage" : "Creator");
      if (allCountEl) allCountEl.textContent = String(playlist.itemCount);
      const modalTitleHeader = document.getElementById("modal-playlist-title-header");
      if (modalTitleHeader) modalTitleHeader.textContent = isCloud ? "Cloud Folder Detected" : "Playlist Detected";
      const itemsHeaderLabel = document.getElementById("playlist-items-header-label");
      if (itemsHeaderLabel) itemsHeaderLabel.textContent = isCloud ? "Cloud Files" : "Playlist Items";
      const modeAllLabel = document.getElementById("playlist-mode-all-label");
      if (modeAllLabel) {
        modeAllLabel.innerHTML = isCloud ? `<strong>Download All Files</strong> in this folder (<span id="playlist-all-count">${playlist.itemCount}</span> files)` : `<strong>Download All Items</strong> in this playlist (<span id="playlist-all-count">${playlist.itemCount}</span> items)`;
      }
      const presetFolderLabel = document.getElementById("playlist-preset-folder-label");
      const presetFolderCb = document.getElementById("playlist-use-preset-folder");
      const currentLocMode = (this.settings?.downloads?.downloadLocationMode === "project" ? "simple" : this.settings?.downloads?.downloadLocationMode) || "simple";
      const hasCustomFolderConfigured = Boolean(this.settings?.downloads?.customLocation?.trim()) && (currentLocMode === "custom" || currentLocMode === "custom_flat");
      if (presetFolderLabel) {
        presetFolderLabel.style.display = hasCustomFolderConfigured ? "flex" : "none";
      }
      if (presetFolderCb) {
        presetFolderCb.checked = false;
      }
      const cloudStructureWrapper = document.getElementById("cloud-folder-structure-wrapper");
      if (cloudStructureWrapper) {
        cloudStructureWrapper.style.display = isCloud ? "block" : "none";
      }
      const folderNameInput = document.getElementById("playlist-folder-name");
      if (folderNameInput) {
        const plTitle = (playlist.title || "").trim();
        const defaultName = plTitle && plTitle !== "Playlist" && plTitle !== "Media Playlist" ? plTitle : playlist.uploader && !playlist.uploader.toLowerCase().includes("creator") ? `${playlist.uploader} - Playlist` : isCloud ? "Cloud Media" : "Media Playlist";
        folderNameInput.value = defaultName;
      }
      const destPathEl = document.getElementById("playlist-destination-path");
      if (destPathEl) {
        const locMode = (this.settings?.downloads?.downloadLocationMode === "project" ? "simple" : this.settings?.downloads?.downloadLocationMode) || "simple";
        const projDir = this.projectContext?.projectDirectory;
        if (locMode === "custom" || locMode === "custom_flat") {
          destPathEl.textContent = this.settings?.downloads?.customLocation || "Custom Folder (Select in Settings)";
        } else if (projDir) {
          destPathEl.textContent = `${projDir}\\MediaFetch\\`;
        } else {
          destPathEl.textContent = "Active Adobe Project Folder";
        }
      }
      const modalZipCb = document.getElementById("playlist-zip-package-cb");
      const modalAutoImportCb = document.getElementById("playlist-auto-import-cb");
      const modalAutoImportLabel = modalAutoImportCb?.closest("label");
      if (modalZipCb) {
        modalZipCb.checked = false;
        modalZipCb.onchange = () => {
          if (modalZipCb.checked) {
            if (modalAutoImportCb) {
              modalAutoImportCb.checked = false;
              modalAutoImportCb.disabled = true;
            }
            if (modalAutoImportLabel) {
              modalAutoImportLabel.style.opacity = "0.5";
              modalAutoImportLabel.title = "Cannot auto-import ZIP files into Adobe timeline";
            }
          } else {
            if (modalAutoImportCb) {
              modalAutoImportCb.disabled = false;
              modalAutoImportCb.checked = true;
            }
            if (modalAutoImportLabel) {
              modalAutoImportLabel.style.opacity = "1";
              modalAutoImportLabel.title = "";
            }
          }
        };
      }
      if (modalAutoImportCb) {
        modalAutoImportCb.checked = true;
        modalAutoImportCb.disabled = false;
        modalAutoImportCb.onchange = () => {
          if (modalAutoImportCb.checked && modalZipCb) {
            modalZipCb.checked = false;
          }
        };
      }
      if (modalAutoImportLabel) {
        modalAutoImportLabel.style.opacity = "1";
        modalAutoImportLabel.title = "";
      }
      const singleVideoWrapper = document.getElementById("playlist-single-video-wrapper");
      const hasSingleVideoInPlaylist = Boolean(
        playlist.url && (playlist.url.includes("v=") || playlist.url.includes("/watch/")) && playlist.url.includes("list=")
      );
      if (singleVideoWrapper) {
        singleVideoWrapper.style.display = hasSingleVideoInPlaylist ? "block" : "none";
      }
      const isSpotify = playlist.uploader && playlist.uploader.toLowerCase().includes("spotify") || playlist.title && playlist.title.toLowerCase().includes("spotify") || playlist.url && playlist.url.toLowerCase().includes("spotify") || playlist.items.some((it) => it.url && it.url.toLowerCase().includes("spotify"));
      const isMultiMedia = isCloud || playlist.items && playlist.items.length > 1;
      const qualityContainer = document.getElementById("playlist-quality-picker")?.parentElement;
      if (qualityContainer) {
        qualityContainer.style.display = isMultiMedia ? "none" : "flex";
      }
      const qualityPicker = document.getElementById("playlist-quality-picker");
      if (qualityPicker) {
        qualityPicker.innerHTML = "";
        if (isSpotify) {
          qualityPicker.appendChild(new Option("MP3 Studio Master (320 kbps High Quality Audio)", "audio_mp3_320", true, true));
          qualityPicker.appendChild(new Option("MP3 Standard (192 kbps Clean Audio)", "audio_mp3_192"));
          qualityPicker.appendChild(new Option("MP3 Data Saver (128 kbps Low Compressed)", "audio_mp3_128"));
          qualityPicker.appendChild(new Option("Lossless WAV (48kHz Uncompressed Audio)", "audio_wav"));
          qualityPicker.appendChild(new Option("High-Res Album Cover Art", "image_cover"));
        } else {
          qualityPicker.appendChild(new Option("1080p Full HD Video - Recommended (Fast & Balanced)", "1080p", true, true));
          qualityPicker.appendChild(new Option("4K Ultra HD Video (2160p) - Studio Quality (Slower)", "4k"));
          qualityPicker.appendChild(new Option("720p HD Video - High Speed (Light File)", "720p"));
          qualityPicker.appendChild(new Option("480p Standard Definition - Fast", "480p"));
          qualityPicker.appendChild(new Option("MP3 Studio Master (320 kbps Audio)", "audio_mp3_320"));
          qualityPicker.appendChild(new Option("Lossless WAV (48kHz Uncompressed Audio)", "audio_wav"));
          qualityPicker.appendChild(new Option("Video Cover Art / Thumbnail", "image_cover"));
        }
      }
      if (listContainer) {
        listContainer.innerHTML = "";
        listContainer.onwheel = (e) => {
          if (listContainer.scrollHeight > listContainer.clientHeight) {
            listContainer.scrollTop += e.deltaY;
            e.preventDefault();
          }
        };
        const inputUrl = document.getElementById("url-input")?.value?.trim() || "";
        let targetVideoId = playlist.targetVideoId || null;
        const candidateUrls = [inputUrl, playlist.url, playlist.original_url, playlist.webpage_url].filter(Boolean);
        for (const u of candidateUrls) {
          if (targetVideoId) break;
          try {
            const parsedUrl = new URL(u);
            const v = parsedUrl.searchParams.get("v");
            if (v) targetVideoId = v;
          } catch (_) {
          }
          if (!targetVideoId) {
            const vMatch = u.match(/(?:v=|\/watch\/|\/embed\/|youtu\.be\/)([a-zA-Z0-9_-]{11})/);
            if (vMatch) targetVideoId = vMatch[1];
          }
        }
        const hasMatchingSong = Boolean(
          targetVideoId && playlist.items.some((it) => {
            return it.id && (it.id === targetVideoId || String(it.id).includes(targetVideoId)) || it.url && (it.url.includes(`v=${targetVideoId}`) || it.url.includes(targetVideoId));
          })
        );
        const createItemRow = (it, displayIndex) => {
          const row = document.createElement("div");
          row.style.cssText = "display:flex; align-items:center; gap:6px; font-size:11px; padding:3px 4px; border-bottom:1px solid var(--border-subtle); flex-shrink:0;";
          const rawType = (it.type || it.mediaType || "").toLowerCase();
          const urlStr = String(it.url || it.downloadTarget || it.directStreamUrl || "");
          const titleStr = String(it.title || "");
          let itemType = "video";
          if (rawType === "image" || rawType === "photo" || it.isImage || /\.(jpe?g|png|webp|gif|bmp|svg|avif)($|\?)/i.test(urlStr) || /\.(jpe?g|png|webp|gif|bmp|svg|avif)($|\?)/i.test(titleStr) || /(?:image|photo|wallpaper|artwork)/i.test(it.resolution || "") || playlist.isPinterest) {
            itemType = "image";
          } else if (rawType === "audio" || it.isAudio || isSpotify || playlist.isAppleMusic || /\.(mp3|wav|m4a|aac|flac|ogg|opus|aiff)($|\?)/i.test(urlStr) || /\.(mp3|wav|m4a|aac|flac|ogg|opus|aiff)($|\?)/i.test(titleStr) || urlStr.includes("spotify.com") || urlStr.includes("music.apple.com") || urlStr.includes("p.scdn.co")) {
            itemType = "audio";
          } else {
            itemType = "video";
          }
          let durationBadge = "";
          if (it.duration && it.duration > 0) {
            durationBadge = this.formatDuration(it.duration);
          } else if (itemType === "image") {
            durationBadge = "PHOTO";
          } else {
            const extMatch = it.title.match(/\.([0-9a-z]+)$/i);
            durationBadge = extMatch ? extMatch[1].toUpperCase() : isCloud ? "CLOUD FILE" : "";
          }
          const isCurrentSong = Boolean(
            targetVideoId && (it.id && (it.id === targetVideoId || String(it.id).includes(targetVideoId)) || it.url && (it.url.includes(`v=${targetVideoId}`) || it.url.includes(targetVideoId)))
          );
          const isChecked = targetVideoId ? isCurrentSong : true;
          const currentSongBadge = isCurrentSong ? '<span class="playlist-current-badge" style="color:#0a84ff; font-weight:700; font-size:9.5px; background:rgba(10,132,255,0.18); border:1px solid rgba(10,132,255,0.35); padding:1px 5px; border-radius:3px; white-space:nowrap;">Current Video</span>' : "";
          let typeBadge = "";
          if (itemType === "image") {
            typeBadge = '<span style="color:#00e5c9; font-weight:800; font-size:9.5px; background:rgba(0,229,201,0.15); border:1px solid rgba(0,229,201,0.4); padding:1px 5px; border-radius:3px; white-space:nowrap; letter-spacing:0.5px;">IMG</span>';
          } else if (itemType === "audio") {
            typeBadge = '<span style="color:#a855f7; font-weight:800; font-size:9.5px; background:rgba(168,85,247,0.15); border:1px solid rgba(168,85,247,0.4); padding:1px 5px; border-radius:3px; white-space:nowrap; letter-spacing:0.5px;">AUD</span>';
          } else {
            typeBadge = '<span style="color:#3b82f6; font-weight:800; font-size:9.5px; background:rgba(59,130,246,0.15); border:1px solid rgba(59,130,246,0.4); padding:1px 5px; border-radius:3px; white-space:nowrap; letter-spacing:0.5px;">VID</span>';
          }
          row.innerHTML = `
          <input type="checkbox" class="playlist-checkbox" data-url="${it.url}" data-title="${it.title.replace(/"/g, "&quot;")}" data-thumb="${it.thumbnail || ""}" data-dur="${it.duration || 0}" data-sub="${it.subFolderName || ""}" data-query="${it.downloadQuery || ""}" data-uploader="${it.uploader || it.channel || ""}" data-type="${itemType}" ${isChecked ? "checked" : ""} style="cursor:pointer;">
          <span style="color:var(--text-muted); font-size:10px; width:24px; text-align:right; margin-right:2px; flex-shrink:0;">#${displayIndex !== void 0 ? displayIndex : it.index || ""}</span>
          ${typeBadge}
          <span style="flex:1; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; cursor:pointer;" class="playlist-item-title" title="${it.title}">${it.title}</span>
          ${currentSongBadge}
          ${durationBadge ? `<span style="color:var(--text-muted); font-size:9.5px; background:rgba(255,255,255,0.06); padding:1px 5px; border-radius:3px; white-space:nowrap;">${durationBadge}</span>` : ""}
          <button type="button" class="btn-playlist-preview" title="Preview in player" style="background:rgba(255,255,255,0.08); border:1px solid rgba(255,255,255,0.18); color:#e0e0e0; border-radius:4px; padding:2px 6px; cursor:pointer; font-size:10px; display:inline-flex; align-items:center; gap:3px;">
            <svg width="9" height="9" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg> Preview
          </button>
        `;
          const cb = row.querySelector(".playlist-checkbox");
          cb?.addEventListener("change", () => this.updatePlaylistSelectedCount());
          row.querySelector(".playlist-item-title")?.addEventListener("click", () => {
            if (cb) {
              cb.checked = !cb.checked;
              this.updatePlaylistSelectedCount();
            }
          });
          const previewBtn = row.querySelector(".btn-playlist-preview");
          previewBtn?.addEventListener("click", (e) => {
            e.preventDefault();
            e.stopPropagation();
            const streamTarget = it.directStreamUrl || it.audioPreviewUrl || it.downloadTarget || it.url;
            const itemAsMeta = {
              id: it.id || "pl_" + Date.now(),
              url: it.url,
              title: it.title,
              thumbnail: it.thumbnail,
              duration: it.duration || 0,
              uploader: it.uploader || it.channel || playlist.uploader || "Creator",
              mediaType: itemType,
              type: itemType,
              isSpotify: isSpotify || it.isSpotify,
              audioPreviewUrl: it.audioPreviewUrl || (itemType === "audio" ? streamTarget : ""),
              embedUrl: it.embedUrl || "",
              directStreamUrl: streamTarget,
              downloadTarget: streamTarget,
              formats: it.formats || (streamTarget ? [{
                formatId: "preview",
                ext: itemType === "audio" ? "mp3" : itemType === "image" ? "jpg" : "mp4",
                url: streamTarget,
                hasAudioAndVideo: itemType === "video",
                isVideo: itemType === "video",
                isAudio: itemType === "audio",
                isImage: itemType === "image"
              }] : [])
            };
            this.openMediaPreview(itemAsMeta);
          });
          return row;
        };
        const hasFolders = Boolean(playlist.folders && playlist.folders.length > 0);
        if (hasFolders) {
          const folderList = playlist.folders;
          folderList.forEach((folder, folderIdx) => {
            if (!folder.items || folder.items.length === 0) return;
            const groupEl = document.createElement("div");
            groupEl.className = "playlist-folder-group";
            groupEl.style.cssText = "margin-bottom:6px; border:1px solid rgba(255,255,255,0.08); border-radius:4px; overflow:hidden; background:rgba(255,255,255,0.02); flex-shrink:0;";
            const headerEl = document.createElement("div");
            headerEl.className = "playlist-folder-header";
            headerEl.style.cssText = "display:flex; align-items:center; gap:6px; padding:5px 8px; background:rgba(255,255,255,0.06); cursor:pointer; user-select:none; border-bottom:1px solid rgba(255,255,255,0.06);";
            const isInitiallyOpen = folderIdx === 0 || folderList.length === 1;
            headerEl.innerHTML = `
            <span class="folder-toggle-icon" style="display:inline-block; font-size:11px; font-weight:700; color:${isInitiallyOpen ? "#fff" : "#aaa"}; transition:transform 0.2s ease; width:12px; text-align:center; transform:${isInitiallyOpen ? "rotate(90deg)" : "rotate(0deg)"};">></span>
            <input type="checkbox" class="folder-group-cb" checked style="cursor:pointer;" title="Select/Deselect all in folder">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="#f59e0b" style="flex-shrink:0;"><path d="M10 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z"/></svg>
            <span style="font-weight:600; font-size:11px; color:var(--text-primary); flex:1; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${folder.name}</span>
            <span style="font-size:9.5px; color:var(--text-muted); background:rgba(255,255,255,0.08); padding:1px 6px; border-radius:10px;">${folder.items.length} files</span>
          `;
            const itemsContainer = document.createElement("div");
            itemsContainer.className = "playlist-folder-items";
            itemsContainer.style.cssText = `display:${isInitiallyOpen ? "flex" : "none"}; flex-direction:column; gap:2px; padding:3px 4px; max-height:220px; overflow-y:auto; overflow-x:hidden; background:rgba(0,0,0,0.18); border-radius:3px; margin:2px 0;`;
            itemsContainer.addEventListener("wheel", (e) => {
              if (itemsContainer.scrollHeight > itemsContainer.clientHeight) {
                itemsContainer.scrollTop += e.deltaY;
                e.preventDefault();
                e.stopPropagation();
              }
            }, { passive: false });
            const toggleIcon = headerEl.querySelector(".folder-toggle-icon");
            const folderCb = headerEl.querySelector(".folder-group-cb");
            headerEl.addEventListener("click", (e) => {
              if (e.target === folderCb) return;
              const isClosed = itemsContainer.style.display === "none";
              itemsContainer.style.display = isClosed ? "flex" : "none";
              if (toggleIcon) {
                toggleIcon.style.transform = isClosed ? "rotate(90deg)" : "rotate(0deg)";
                toggleIcon.style.color = isClosed ? "#fff" : "#aaa";
              }
            });
            folderCb.addEventListener("change", () => {
              const cbs = itemsContainer.querySelectorAll(".playlist-checkbox");
              cbs.forEach((cb) => {
                cb.checked = folderCb.checked;
              });
              this.updatePlaylistSelectedCount();
            });
            folder.items.forEach((it, idx) => {
              const row = createItemRow(it, idx + 1);
              const itemCb = row.querySelector(".playlist-checkbox");
              itemCb?.addEventListener("change", () => {
                const allCbs = Array.from(itemsContainer.querySelectorAll(".playlist-checkbox"));
                const someChecked = allCbs.some((c) => c.checked);
                const allChecked = allCbs.every((c) => c.checked);
                folderCb.checked = allChecked;
                folderCb.indeterminate = someChecked && !allChecked;
              });
              itemsContainer.appendChild(row);
            });
            groupEl.appendChild(headerEl);
            groupEl.appendChild(itemsContainer);
            listContainer.appendChild(groupEl);
          });
        } else {
          playlist.items.forEach((it, idx) => {
            const row = createItemRow(it, it.index || idx + 1);
            listContainer.appendChild(row);
          });
        }
        const radioAll = document.querySelector('input[name="playlist-mode"][value="all"]');
        const radioSelected = document.querySelector('input[name="playlist-mode"][value="selected"]');
        const itemsWrapper = document.getElementById("playlist-items-wrapper");
        if (targetVideoId) {
          if (radioSelected) radioSelected.checked = true;
          if (radioAll) radioAll.checked = false;
          if (itemsWrapper) itemsWrapper.style.display = "block";
          setTimeout(() => {
            const badge = listContainer.querySelector(".playlist-current-badge");
            if (badge) {
              badge.scrollIntoView({ behavior: "smooth", block: "center" });
            }
          }, 150);
        } else {
          if (radioAll) radioAll.checked = true;
          if (radioSelected) radioSelected.checked = false;
        }
      }
      this.updatePlaylistSelectedCount();
      this.openModal("modal-playlist");
    }
    updatePlaylistSelectedCount() {
      const checked = document.querySelectorAll(".playlist-checkbox:checked");
      const selCountEl = document.getElementById("playlist-selected-count");
      if (selCountEl) selCountEl.textContent = String(checked.length);
      const radioSelCount = document.getElementById("playlist-selected-radio-count");
      if (radioSelCount) radioSelCount.textContent = String(checked.length);
    }
    async handlePlaylistDownloadSubmit() {
      if (!this.currentPlaylist) return;
      if (typeof window.MediaFetchLicense?.isAuthorized === "function") {
        if (!window.MediaFetchLicense.isAuthorized()) {
          window.MediaFetchLicense.showModal?.("A valid commercial license is required to download media.");
          return;
        }
      }
      const isCloud = Boolean(
        this.currentPlaylist.isCloud || this.currentPlaylist.uploader && this.currentPlaylist.uploader.toLowerCase().includes("cloud") || this.currentPlaylist.url && (this.currentPlaylist.url.includes("drive.google.com") || this.currentPlaylist.url.includes("dropbox.com") || this.currentPlaylist.url.includes("onedrive") || this.currentPlaylist.url.includes("1drv.ms") || this.currentPlaylist.url.includes("mega.nz"))
      );
      const isMultiMedia = isCloud || this.currentPlaylist.items && this.currentPlaylist.items.length > 1;
      const qualityPicker = document.getElementById("playlist-quality-picker");
      const chosenQuality = isMultiMedia ? "best-available" : qualityPicker?.value || "1080p";
      let profileType = "video";
      let selectedPresetId = "video-1080p";
      let container = "mp4";
      let label = "1080p Full HD Video (Batch)";
      if (chosenQuality === "best-available") {
        profileType = "video";
        selectedPresetId = "best-available";
        container = "mp4";
        label = "Native Master Quality (Batch)";
      } else if (chosenQuality === "4k") {
        profileType = "video";
        selectedPresetId = "video-4k";
        container = "mp4";
        label = "4K Ultra HD Video (Batch)";
      } else if (chosenQuality === "720p") {
        profileType = "video";
        selectedPresetId = "video-720p";
        container = "mp4";
        label = "720p HD Video (Batch)";
      } else if (chosenQuality === "480p") {
        profileType = "video";
        selectedPresetId = "video-480p";
        container = "mp4";
        label = "480p SD Video (Batch)";
      } else if (chosenQuality === "audio_mp3_320") {
        profileType = "audio";
        selectedPresetId = "audio-mp3-320";
        container = "mp3";
        label = "MP3 Studio Master 320kbps (Batch)";
      } else if (chosenQuality === "audio_mp3_192") {
        profileType = "audio";
        selectedPresetId = "audio-mp3-192";
        container = "mp3";
        label = "MP3 Standard 192kbps (Batch)";
      } else if (chosenQuality === "audio_mp3_128") {
        profileType = "audio";
        selectedPresetId = "audio-mp3-128";
        container = "mp3";
        label = "MP3 Data Saver 128kbps (Batch)";
      } else if (chosenQuality === "audio_wav") {
        profileType = "audio";
        selectedPresetId = "audio-wav";
        container = "wav";
        label = "Lossless WAV Audio (Batch)";
      } else if (chosenQuality === "image_cover") {
        profileType = "image";
        selectedPresetId = "image-orig";
        container = "jpg";
        label = "Cover Art (Batch)";
      } else {
        profileType = "video";
        selectedPresetId = "video-1080p";
        container = "mp4";
        label = "1080p Full HD Video (Batch)";
      }
      const profile = {
        type: profileType,
        presetId: selectedPresetId,
        label,
        container,
        remuxToMp4: container === "mp4"
      };
      const mode = document.querySelector('input[name="playlist-mode"]:checked')?.value || "all";
      let selectedItems = [];
      if (mode === "single") {
        const inputUrl = document.getElementById("url-input")?.value?.trim() || "";
        let targetVid = this.currentPlaylist.targetVideoId || null;
        const candidateUrls = [inputUrl, this.currentPlaylist.url, this.currentPlaylist.original_url, this.currentPlaylist.webpage_url].filter(Boolean);
        for (const u of candidateUrls) {
          if (targetVid) break;
          try {
            targetVid = new URL(u).searchParams.get("v");
          } catch (_) {
          }
          if (!targetVid) {
            const vMatch = u.match(/(?:v=|\/watch\/|\/embed\/|youtu\.be\/)([a-zA-Z0-9_-]{11})/);
            if (vMatch) targetVid = vMatch[1];
          }
        }
        const targetItem = (this.currentPlaylist.items || []).find((it) => {
          return targetVid && (it.id && (it.id === targetVid || String(it.id).includes(targetVid)) || it.url && (it.url.includes(`v=${targetVid}`) || it.url.includes(targetVid)));
        }) || this.currentPlaylist.items[0];
        if (targetItem) {
          selectedItems = [{
            url: targetItem.url,
            title: targetItem.title,
            thumbnail: targetItem.thumbnail,
            duration: targetItem.duration,
            subFolderName: targetItem.subFolderName,
            downloadQuery: targetItem.downloadQuery,
            uploader: targetItem.uploader || targetItem.channel
          }];
        }
      } else {
        document.querySelectorAll(".playlist-checkbox:checked").forEach((cb) => {
          const el = cb;
          const itType = el.getAttribute("data-type") || void 0;
          selectedItems.push({
            url: el.getAttribute("data-url") || "",
            title: el.getAttribute("data-title") || "Video",
            thumbnail: el.getAttribute("data-thumb") || void 0,
            duration: parseFloat(el.getAttribute("data-dur") || "0") || void 0,
            subFolderName: el.getAttribute("data-sub") || void 0,
            downloadQuery: el.getAttribute("data-query") || void 0,
            uploader: el.getAttribute("data-uploader") || void 0,
            type: itType,
            mediaType: itType
          });
        });
      }
      if (selectedItems.length === 0) {
        alert("Please select at least one item to download.");
        return;
      }
      const folderNameInput = document.getElementById("playlist-folder-name");
      const usePresetFolder = document.getElementById("playlist-use-preset-folder")?.checked;
      let customFolderName = folderNameInput?.value?.trim() || this.currentPlaylist.title || (isCloud ? "Cloud Media" : "Media Playlist");
      if (usePresetFolder) {
        customFolderName = "";
      }
      const structureMode = document.querySelector('input[name="cloud-structure-mode"]:checked')?.value;
      const preserveSubfolders = structureMode !== "flatten";
      const zipPackage = document.getElementById("playlist-zip-package-cb")?.checked || false;
      const autoImport = zipPackage ? false : document.getElementById("playlist-auto-import-cb")?.checked !== false;
      try {
        this.projectContext = await hostAdapter.getProjectContext();
      } catch (_) {
      }
      const locMode = (this.settings?.downloads?.downloadLocationMode === "project" ? "simple" : this.settings?.downloads?.downloadLocationMode) || "simple";
      let effectiveTargetDir = this.playlistCustomTargetDir;
      if (!effectiveTargetDir && (locMode === "custom" || locMode === "custom_flat")) {
        const customInput = document.getElementById("setting-custom-location");
        effectiveTargetDir = customInput?.value?.trim() || this.settings?.downloads?.customLocation?.trim();
      }
      serviceClient.startPlaylistDownload(
        selectedItems,
        profile,
        this.projectContext,
        effectiveTargetDir || void 0,
        {
          customFolderName,
          preserveSubfolders,
          autoImport,
          zipPackage,
          playlistTitle: this.currentPlaylist.title,
          isCloud
        }
      );
      this.closeModal("modal-playlist");
      const input = document.getElementById("url-input");
      if (input) input.value = "";
      this.showHeaderToast(`Added ${selectedItems.length} items to download queue`, 5e3);
    }
    async handleDownloadClick() {
      try {
        this.projectContext = await hostAdapter.getProjectContext();
      } catch (_) {
      }
      if (typeof window.MediaFetchLicense?.isAuthorized === "function") {
        if (!window.MediaFetchLicense.isAuthorized()) {
          window.MediaFetchLicense.showModal?.("A valid commercial license is required to download media.");
          return;
        }
      }
      const urlInput = document.getElementById("url-input");
      const rawInput = urlInput?.value?.trim() || "";
      if (!rawInput) {
        this.showUrlError("Please enter or paste a media URL before downloading.");
        return;
      }
      const urls = rawInput.split(/[\r\n,\s]+/).map((u) => u.trim()).filter((u) => u.startsWith("http://") || u.startsWith("https://"));
      if (urls.length === 0) {
        this.showUrlError("Please enter a valid http/https URL.");
        return;
      }
      if (!this.isPro && urls.some((u) => this.isCloudUrl(u))) {
        this.showUrlError("Cloud links (Google Drive, Dropbox, OneDrive, Mega) are exclusive to MediaFetch Pro. Upgrade to MediaFetch Pro to download cloud storage files.");
        this.showHeaderToast("Cloud links are exclusive to MediaFetch Pro", 5e3);
        return;
      }
      const profileSelect = document.getElementById("profile-select");
      const formatSelect = document.getElementById("format-select");
      const selectedPresetId = profileSelect?.value || "best-available";
      const rawFormatValue = (formatSelect?.value || "").toLowerCase();
      const isExplicitVideoContainer = ["mp4", "mov", "webm", "mkv", "avi"].includes(rawFormatValue);
      const isExplicitAudioContainer = ["mp3", "wav", "m4a", "flac", "aac", "ogg"].includes(rawFormatValue);
      const isImageMode = this.currentMode === "image" || selectedPresetId.startsWith("image") || Boolean(this.currentMetadata?.isUpcoming) || this.currentMetadata?.mediaType === "image" || Boolean(this.currentMetadata?.isImage);
      let profileType = isImageMode ? "image" : this.currentMode === "audio-only" || selectedPresetId.startsWith("audio") ? "audio" : this.currentMode === "video-only" ? "video-only" : "video";
      if (this.currentMetadata?.isUpcoming) {
        profileType = "image";
        this.showHeaderToast("Downloading high-res cover thumbnail for upcoming broadcast...", 4e3);
      } else if (isExplicitVideoContainer) {
        if (profileType === "audio") {
          profileType = this.currentMode === "video-only" ? "video-only" : "video";
        }
      } else if (isExplicitAudioContainer && !isImageMode) {
        profileType = "audio";
      }
      const customFilenameInput = document.getElementById("custom-filename-input");
      const customFilename = customFilenameInput?.value?.trim() || void 0;
      const trimStartInput = document.getElementById("trim-start-input");
      const trimEndInput = document.getElementById("trim-end-input");
      const rawStart = trimStartInput?.value?.trim() || void 0;
      const rawEnd = trimEndInput?.value?.trim() || void 0;
      let timeRange;
      if (rawStart || rawEnd) {
        const sSec = this.parseTimeToSec(rawStart);
        const eSec = this.parseTimeToSec(rawEnd);
        const start = rawStart ? this.formatDuration(sSec) : "00:00:00";
        const end = rawEnd ? this.formatDuration(eSec) : void 0;
        timeRange = { start, end };
      }
      let container = rawFormatValue || (profileType === "audio" ? "mp3" : profileType === "image" ? "jpg" : "mp4");
      if (isExplicitVideoContainer) {
        container = rawFormatValue;
      } else if (selectedPresetId === "audio-wav" || rawFormatValue === "wav") {
        container = "wav";
      } else if (selectedPresetId === "audio-flac" || rawFormatValue === "flac") {
        container = "flac";
      } else if (selectedPresetId === "audio-m4a" || rawFormatValue === "m4a") {
        container = "m4a";
      } else if (selectedPresetId.startsWith("audio-mp3") || rawFormatValue === "mp3") {
        container = "mp3";
      }
      let explicitResolution;
      if (typeof selectedPresetId === "string" && selectedPresetId.startsWith("res-")) {
        const parsed = parseInt(selectedPresetId.replace("res-", ""), 10);
        if (!isNaN(parsed) && parsed > 0) explicitResolution = parsed;
      } else if (selectedPresetId === "video-4k") explicitResolution = 2160;
      else if (selectedPresetId === "video-1440p") explicitResolution = 1440;
      else if (selectedPresetId === "video-1080p") explicitResolution = 1080;
      else if (selectedPresetId === "video-720p") explicitResolution = 720;
      else if (selectedPresetId === "video-480p") explicitResolution = 480;
      const baseProfile = {
        type: profileType,
        presetId: selectedPresetId,
        resolution: explicitResolution,
        label: profileSelect?.selectedOptions[0]?.text || (profileType === "audio" ? "Audio Download" : profileType === "video-only" ? "Video Only Download" : "Video Download"),
        container,
        remuxToMp4: container === "mp4",
        customFilename,
        timeRange
      };
      let targetDirectory = void 0;
      const modeInput = document.getElementById("setting-location-mode");
      const activeLocMode = modeInput?.value || (this.settings?.downloads?.downloadLocationMode === "project" ? "simple" : this.settings?.downloads?.downloadLocationMode) || "simple";
      if (activeLocMode === "custom" || activeLocMode === "custom_flat") {
        const customInput = document.getElementById("setting-custom-location");
        const customPath = customInput?.value?.trim() || this.settings?.downloads?.customLocation?.trim();
        if (customPath) {
          targetDirectory = customPath;
        }
      }
      if (urls.length > 1) {
        for (const singleUrl of urls) {
          serviceClient.startDownload(singleUrl, { ...baseProfile }, this.projectContext, targetDirectory);
        }
        urlInput.value = "";
        this.closeCard();
        return;
      }
      const url = urls[0];
      if (this.isPlaylistUrl(url)) {
        const isMatchingPlaylist = Boolean(this.currentPlaylist && (this.currentPlaylist.url === url || this.currentPlaylist.webpage_url === url || this.currentPlaylist.id && url.includes(this.currentPlaylist.id) || url.replace(/https?:\/\/(www\.)?/, "").split("&list=")[0] === (this.currentPlaylist.url || "").replace(/https?:\/\/(www\.)?/, "").split("&list=")[0]));
        if (isMatchingPlaylist && this.currentPlaylist) {
          this.renderPlaylistModal(this.currentPlaylist);
          return;
        }
        this.setAnalysisLoading(true);
        if (url.includes("instagram.com/p/") || url.includes("instagram.com/reel/") || url.includes("instagram.com/reels/") || url.includes("threads.net/") || url.includes("threads.com/") || url.includes("behance.net/gallery/")) {
          serviceClient.analyzeUrl(url, 25e3);
        } else {
          serviceClient.analyzePlaylist(url, 25e3);
        }
        return;
      }
      const isMatchingMeta = Boolean(this.currentMetadata && (
        this.currentMetadata.url === url || 
        this.currentMetadata.webpage_url === url || 
        this.currentMetadata.originalUrl === url || 
        this.currentMetadata.directUrl === url || 
        this.currentMetadata.directStreamUrl === url || 
        (this.currentMetadata.id && url.includes(this.currentMetadata.id)) ||
        (this.currentMetadata.isCloud && (
          (url.includes("drive.google.com") && (this.currentMetadata.url?.includes("drive.google.com") || this.currentMetadata.directUrl?.includes("drive."))) ||
          (url.includes("dropbox.com") && (this.currentMetadata.url?.includes("dropbox.com") || this.currentMetadata.directUrl?.includes("dropbox.")))
        ))
      ));
      if (isMatchingMeta && this.currentMetadata) {
        if (this.currentMetadata.isPlaylist || this.currentMetadata.isCarousel || this.currentMetadata.items && this.currentMetadata.items.length > 1 || this.currentMetadata.carouselSlides && this.currentMetadata.carouselSlides.length > 1) {
          const rawItems = this.currentMetadata.items || (this.currentMetadata.carouselSlides || []);
          this.renderPlaylistModal({
            id: this.currentMetadata.id || "multi_" + Date.now(),
            url: this.currentMetadata.url || url,
            title: this.currentMetadata.title || "Multi-Media Project",
            uploader: this.currentMetadata.uploader || "Creator",
            itemCount: rawItems.length,
            items: rawItems.map((s, idx) => ({
              id: s.id || `item_${idx + 1}`,
              title: s.title || `${this.currentMetadata?.title || "Item"} (${s.slideIndex || idx + 1})`,
              url: s.url,
              thumbnail: s.thumbnail || s.url,
              duration: s.duration || 0,
              downloadQuery: s.downloadQuery || s.url,
              downloadTarget: s.downloadTarget || s.url,
              directStreamUrl: s.directStreamUrl || s.url,
              type: s.type || s.mediaType || "video",
              mediaType: s.mediaType || s.type || "video",
              uploader: s.uploader || this.currentMetadata?.uploader
            }))
          });
          return;
        }
      } else {
        const isMatchingPlaylist = Boolean(this.currentPlaylist && (this.currentPlaylist.url === url || this.currentPlaylist.webpage_url === url || url.replace(/https?:\/\/(www\.)?/, "").split("?")[0].replace(/\/$/, "") === (this.currentPlaylist.url || "").replace(/https?:\/\/(www\.)?/, "").split("?")[0].replace(/\/$/, "")));
        if (isMatchingPlaylist && this.currentPlaylist) {
          this.renderPlaylistModal(this.currentPlaylist);
          return;
        }
        if (this.isPlaylistUrl(url)) {
          this.setAnalysisLoading(true);
          if (url.includes("instagram.com/p/") || url.includes("instagram.com/reel/") || url.includes("instagram.com/reels/") || url.includes("threads.net/") || url.includes("threads.com/") || url.includes("behance.net/gallery/")) {
            serviceClient.analyzeUrl(url, 25e3);
          } else {
            serviceClient.analyzePlaylist(url, 25e3);
          }
          return;
        }
      }
      const validMeta = isMatchingMeta ? this.currentMetadata : null;
      const title = validMeta?.title || "";
      this.pendingDownloadParams = {
        url,
        profile: baseProfile,
        projectContext: this.projectContext,
        targetDirectory,
        metadata: validMeta ? {
          ...validMeta,
          title: title || validMeta.title || "",
          thumbnail: validMeta.thumbnail,
          duration: validMeta.duration,
          downloadQuery: validMeta.downloadQuery,
          directStreamUrl: validMeta.directStreamUrl || validMeta.directUrl,
          downloadTarget: validMeta.downloadTarget || validMeta.directUrl || validMeta.directStreamUrl,
          mediaType: validMeta.mediaType,
          uploader: validMeta.uploader || validMeta.channel
        } : void 0
      };
      this.executePendingDownload();
    }
    executePendingDownload() {
      if (!this.pendingDownloadParams) return;
      serviceClient.startDownload(
        this.pendingDownloadParams.url,
        this.pendingDownloadParams.profile,
        this.pendingDownloadParams.projectContext,
        this.pendingDownloadParams.targetDirectory,
        this.pendingDownloadParams.metadata
      );
      this.pendingDownloadParams = null;
      const input = document.getElementById("url-input");
      if (input) input.value = "";
      const card = document.getElementById("media-card-section");
      if (card) card.style.display = "none";
      this.showHeaderToast("Added item to download queue", 4e3);
    }
    getVisibleQueue() {
      const isPro = window.__MF_EDITION__ === "pro" || window.location.pathname.includes(".pro") || document.title.includes("Pro");
      const myEdition = isPro ? "pro" : "standard";
      const perProject = Boolean(this.settings?.downloads?.perProjectQueue);
      const activeKey = perProject ? this.normalizeProjectPath(this.projectContext?.projectPath) : "";
      return (this.queue || []).filter((item) => {
        if (!item) return false;
        if (!item.edition) {
          if (myEdition !== "pro") return false;
        } else if (item.edition !== myEdition) {
          return false;
        }
        if (perProject) {
          if (item.status === "downloading" || item.status === "waiting") return true;
          const itemKey = this.normalizeProjectPath(item.projectContext?.projectPath);
          return itemKey === activeKey;
        }
        return true;
      });
    }
    renderQueue() {
      const container = document.getElementById("queue-container");
      const countEl = document.getElementById("queue-count");
      if (!container) return;
      const visibleItems = this.getVisibleQueue();
      if (countEl) countEl.textContent = String(visibleItems.length);
      if (visibleItems.length === 0) {
        container.innerHTML = '<div class="queue-empty-state">No active downloads. Paste a URL and click Download to start.</div>';
        return;
      }
      container.innerHTML = "";
      for (const item of visibleItems) {
        container.appendChild(this.createQueueItemElement(item));
      }
    }
    createQueueItemElement(item) {
      const el = document.createElement("div");
      el.className = "queue-item";
      el.id = `q-item-${item.id}`;
      el.setAttribute("data-status", item.status);
      const badgeClass = `badge-${item.status}`;
      const fillClass = item.status === "completed" ? "success" : item.status === "failed" ? "error" : "";
      let statsText = item.stageDescription || item.status.toUpperCase();
      if (item.status === "downloading") {
        const downMB = (item.downloadedBytes / (1024 * 1024)).toFixed(1);
        const totalMB = item.totalBytes > 0 ? (item.totalBytes / (1024 * 1024)).toFixed(1) + " MB" : "\u2026";
        const speed = item.speed || "";
        const eta = item.eta ? ` • ETA ${item.eta}` : "";
        const hasMeaningfulStage = item.stageDescription && (item.stageDescription.toLowerCase().includes("process") || item.stageDescription.toLowerCase().includes("trim") || item.stageDescription.toLowerCase().includes("optimi") || item.stageDescription.toLowerCase().includes("remux") || item.stageDescription.toLowerCase().includes("merg") || item.stageDescription.toLowerCase().includes("wait") || item.stageDescription.toLowerCase().includes("start") || item.stageDescription.toLowerCase().includes("seek") || item.stageDescription.toLowerCase().includes("prepar") || item.stageDescription.toLowerCase().includes("clip") || item.stageDescription.toLowerCase().includes("cut") || item.stageDescription.toLowerCase().includes("resolv") || item.stageDescription.toLowerCase().includes("negotiat"));
        if (hasMeaningfulStage) {
          statsText = `${item.stageDescription}${speed ? ` • ${speed}` : ""}${eta}`;
        } else if (item.downloadedBytes > 0 && item.totalBytes > 0) {
          statsText = `${downMB} MB / ${totalMB}${speed ? ` • ${speed}` : ""}${eta}`;
        } else {
          statsText = item.stageDescription || "Downloading stream...";
        }
      }
      el.innerHTML = `
      <div class="queue-item-header">
        <span class="queue-item-title" title="${item.title}">${item.title}</span>
        <span class="queue-item-badge ${badgeClass}">${item.status}</span>
      </div>
      <div class="progress-bar-container">
        <div class="progress-bar-fill ${fillClass}" style="width: ${item.progress}%;"></div>
      </div>
      <div class="queue-item-stats">
        <span class="item-stats-text">${statsText}</span>
        <div class="queue-item-actions">
          ${this.renderItemActionButtons(item)}
        </div>
      </div>
    `;
      this.bindItemActionEvents(el, item);
      return el;
    }
    renderItemActionButtons(item) {
      if (item.status === "downloading" || item.status === "waiting") {
        return `
        <button class="btn btn-icon btn-sm btn-pause" title="Pause">${ICONS.PAUSE}</button>
        <button class="btn btn-icon btn-sm btn-cancel" title="Cancel">${ICONS.CLOSE}</button>
      `;
      } else if (item.status === "paused") {
        return `
        <button class="btn btn-icon btn-sm btn-resume" title="Resume">${ICONS.PLAY}</button>
        <button class="btn btn-icon btn-sm btn-cancel" title="Cancel">${ICONS.CLOSE}</button>
      `;
      } else if (item.status === "failed") {
        return `
        <button class="btn btn-icon btn-sm btn-retry" title="Retry">${ICONS.RETRY}</button>
        <button class="btn btn-icon btn-sm btn-cancel" title="Remove">${ICONS.CLOSE}</button>
      `;
      } else if (item.status === "completed") {
        return `
        <button class="btn btn-icon btn-sm btn-reveal" title="Show in Folder">${ICONS.FOLDER}</button>
        <button class="btn btn-icon btn-sm btn-retry" title="Retry / Re-download">${ICONS.RETRY}</button>
        <button class="btn btn-icon btn-sm btn-cancel" title="Remove from queue">${ICONS.CLOSE}</button>
      `;
      }
      return `<button class="btn btn-icon btn-sm btn-cancel" title="Remove">${ICONS.CLOSE}</button>`;
    }
    bindItemActionEvents(_el, _item) {
    }
    updateQueueItemDOM(item) {
      if (typeof window !== "undefined" && window.requestAnimationFrame) {
        window.requestAnimationFrame(() => this._applyQueueItemDOM(item));
      } else {
        this._applyQueueItemDOM(item);
      }
    }
    _applyQueueItemDOM(item) {
      const existing = document.getElementById(`q-item-${item.id}`);
      if (existing) {
        const title = existing.querySelector(".queue-item-title");
        const badge = existing.querySelector(".queue-item-badge");
        const fill = existing.querySelector(".progress-bar-fill");
        const stats = existing.querySelector(".item-stats-text");
        if (title && item.title) {
          title.textContent = item.title;
          title.title = item.title;
        }
        if (badge) {
          badge.className = `queue-item-badge badge-${item.status}`;
          badge.textContent = item.status;
        }
        if (fill) {
          fill.style.width = `${item.progress}%`;
          fill.className = `progress-bar-fill ${item.status === "completed" ? "success" : item.status === "failed" ? "error" : ""}`;
        }
        if (stats) {
          let statsText = item.stageDescription || item.status.toUpperCase();
          if (item.status === "downloading") {
            const downMB = (item.downloadedBytes / (1024 * 1024)).toFixed(1);
            const totalMB = item.totalBytes > 0 ? (item.totalBytes / (1024 * 1024)).toFixed(1) + " MB" : "\u2026";
            const speed = item.speed || "";
            const eta = item.eta ? ` • ETA ${item.eta}` : "";
            const hasMeaningfulStage = item.stageDescription && (item.stageDescription.toLowerCase().includes("process") || item.stageDescription.toLowerCase().includes("trim") || item.stageDescription.toLowerCase().includes("optimi") || item.stageDescription.toLowerCase().includes("remux") || item.stageDescription.toLowerCase().includes("merg") || item.stageDescription.toLowerCase().includes("wait") || item.stageDescription.toLowerCase().includes("start") || item.stageDescription.toLowerCase().includes("seek") || item.stageDescription.toLowerCase().includes("prepar") || item.stageDescription.toLowerCase().includes("clip") || item.stageDescription.toLowerCase().includes("cut") || item.stageDescription.toLowerCase().includes("resolv") || item.stageDescription.toLowerCase().includes("negotiat"));
            if (hasMeaningfulStage) {
              statsText = `${item.stageDescription}${speed ? ` • ${speed}` : ""}${eta}`;
            } else if (item.downloadedBytes > 0 && item.totalBytes > 0) {
              statsText = `${downMB} MB / ${totalMB}${speed ? ` • ${speed}` : ""}${eta}`;
            } else {
              statsText = item.stageDescription || "Downloading stream...";
            }
          }
          stats.textContent = statsText;
        }
        const prevStatus = existing.getAttribute("data-status");
        if (prevStatus !== item.status) {
          existing.setAttribute("data-status", item.status);
          const actions = existing.querySelector(".queue-item-actions");
          if (actions) {
            actions.innerHTML = this.renderItemActionButtons(item);
            this.bindItemActionEvents(existing, item);
          }
        }
      } else {
        this.renderQueue();
      }
    }
    renderDiagnostics(diag) {
      const osEl = document.getElementById("diag-os");
      const nodeEl = document.getElementById("diag-node");
      const adobeEl = document.getElementById("diag-adobe");
      const portEl = document.getElementById("diag-port");
      const ytdlpEl = document.getElementById("diag-ytdlp");
      const ffmpegEl = document.getElementById("diag-ffmpeg");
      const logsBox = document.getElementById("diag-logs-box");
      if (osEl) osEl.textContent = diag.os;
      if (nodeEl) nodeEl.textContent = diag.nodeVersion;
      if (adobeEl) adobeEl.textContent = `${diag.adobeApp || "Adobe App"} (${diag.adobeVersion || "Auto"})`;
      if (portEl) portEl.textContent = String(diag.servicePort);
      if (ytdlpEl) ytdlpEl.textContent = diag.ytdlp.available ? `v${diag.ytdlp.version || "OK"}` : "Missing";
      if (ffmpegEl) ffmpegEl.textContent = diag.ffmpeg.available ? `v${diag.ffmpeg.version || "OK"}` : "Missing";
      const engineYtDlp = document.getElementById("engine-ytdlp-ver");
      const engineFfmpeg = document.getElementById("engine-ffmpeg-ver");
      if (engineYtDlp) {
        engineYtDlp.textContent = diag.ytdlp?.available ? `v${diag.ytdlp.version || "OK"}` : "Missing / Not Installed";
        engineYtDlp.style.color = diag.ytdlp?.available ? "var(--status-success, #22c55e)" : "var(--status-error, #ef4444)";
      }
      if (engineFfmpeg) {
        engineFfmpeg.textContent = diag.ffmpeg?.available ? `v${diag.ffmpeg.version || "OK"}` : "Missing / Not Installed";
        engineFfmpeg.style.color = diag.ffmpeg?.available ? "var(--status-success, #22c55e)" : "var(--status-error, #ef4444)";
      }
      fetch(`http://127.0.0.1:${diag.servicePort}/api/diagnostics/logs`).then((r) => r.json()).then((data) => {
        if (logsBox && Array.isArray(data.logs)) {
          logsBox.textContent = data.logs.join("\n");
          logsBox.scrollTop = logsBox.scrollHeight;
        }
      }).catch(() => {
      });
    }
    updateSetupWizardStatus(diag) {
      const ytdlpStat = document.getElementById("setup-status-ytdlp");
      const ffmpegStat = document.getElementById("setup-status-ffmpeg");
      if (ytdlpStat) {
        ytdlpStat.textContent = diag.ytdlp.available ? `Ready (v${diag.ytdlp.version || ""})` : "Missing";
        ytdlpStat.style.color = diag.ytdlp.available ? "var(--status-success)" : "var(--status-error)";
      }
      if (ffmpegStat) {
        ffmpegStat.textContent = diag.ffmpeg.available ? `Ready (${diag.ffmpeg.version || ""})` : "Missing";
        ffmpegStat.style.color = diag.ffmpeg.available ? "var(--status-success)" : "var(--status-error)";
      }
      const installBtn = document.getElementById("btn-setup-install-all");
      if (installBtn) {
        if (diag.ytdlp.available && diag.ffmpeg.available) {
          installBtn.textContent = "All Components Ready";
          installBtn.disabled = true;
        } else {
          installBtn.textContent = "Install Missing Components";
          installBtn.disabled = false;
        }
      }
    }
    showInstallProgress(payload) {
      const progRow = document.getElementById("setup-progress-row");
      const progLabel = document.getElementById("setup-progress-label");
      const progFill = document.getElementById("setup-progress-fill");
      if (progRow) progRow.style.display = "flex";
      if (progLabel) progLabel.textContent = `[${payload.name}] ${payload.message}`;
      if (progFill) progFill.style.width = `${payload.progress}%`;
      const engineStatus = document.getElementById("engine-update-status");
      if (engineStatus) {
        engineStatus.style.display = "block";
        engineStatus.style.color = "var(--text-secondary, #aaa)";
        engineStatus.textContent = payload.message || "Updating yt-dlp engine...";
      }
    }
    handleInstallResult(payload) {
      const progLabel = document.getElementById("setup-progress-label");
      if (progLabel) {
        if (payload.success) {
          progLabel.textContent = `${payload.name} installation completed successfully.`;
        } else {
          progLabel.textContent = `Failed to install ${payload.name}: ${payload.error}`;
        }
      }
      const btnUpdate = document.getElementById("btn-update-ytdlp");
      if (btnUpdate) {
        btnUpdate.disabled = false;
        btnUpdate.textContent = "Check & Update yt-dlp";
      }
      const engineStatus = document.getElementById("engine-update-status");
      if (engineStatus) {
        engineStatus.style.display = "block";
        if (payload.success) {
          engineStatus.style.color = "var(--status-success, #22c55e)";
          engineStatus.textContent = payload.message || "yt-dlp is up to date!";
        } else {
          engineStatus.style.color = "var(--status-error, #ef4444)";
          engineStatus.textContent = `Update notice: ${payload.error || "Check network connection"}`;
        }
      }
      serviceClient.runSystemCheck();
      serviceClient.getDiagnostics();
    }
    updateDownloadLocationModeUI() {
      const modeSel = document.getElementById("setting-location-mode");
      const customLoc = document.getElementById("setting-custom-location");
      const customBrowseBtn = document.getElementById("btn-browse-custom-location");
      const customGroup = document.getElementById("setting-custom-location-group") || customLoc?.parentElement?.parentElement;
      const isCustom = modeSel?.value === "custom" || modeSel?.value === "custom_flat";
      if (customLoc) customLoc.disabled = !isCustom;
      if (customBrowseBtn) customBrowseBtn.disabled = !isCustom;
      if (customGroup) {
        customGroup.style.opacity = isCustom ? "1" : "0.45";
        customGroup.style.pointerEvents = isCustom ? "auto" : "none";
      }
    }
    populateSettingsForm(s) {
      const themeSel = document.getElementById("setting-theme");
      const autoImportChk = document.getElementById("setting-auto-import");
      const confirmChk = document.getElementById("setting-confirm-overwrite");
      const cleanupChk = document.getElementById("setting-auto-cleanup");
      const modeSel = document.getElementById("setting-location-mode");
      const playlistSel = document.getElementById("setting-playlist-behavior");
      const customLoc = document.getElementById("setting-custom-location");
      const concSel = document.getElementById("setting-concurrency");
      const retriesSel = document.getElementById("setting-max-retries");
      const timeoutInput = document.getElementById("setting-timeout");
      const debugChk = document.getElementById("setting-debug-logging");
      const cookiesSel = document.getElementById("setting-browser-cookies");
      const autoProjPathChk = document.getElementById("setting-auto-project-path");
      const perProjQueueChk = document.getElementById("setting-per-project-queue");
      if (themeSel) themeSel.value = s.general.theme;
      if (autoImportChk) autoImportChk.checked = s.general.autoImportToProject ?? true;
      if (confirmChk) confirmChk.checked = s.general.confirmOverwrite;
      if (cleanupChk) cleanupChk.checked = s.general.autoCleanupTemp;
      if (modeSel) modeSel.value = (s.downloads.downloadLocationMode === "project" ? "simple" : s.downloads.downloadLocationMode) || "simple";
      if (playlistSel) playlistSel.value = s.downloads.playlistBehavior || "ask";
      if (customLoc) customLoc.value = s.downloads.customLocation;
      if (concSel) concSel.value = String(s.downloads.concurrency);
      if (retriesSel) retriesSel.value = String(s.downloads.maxRetries);
      if (timeoutInput) timeoutInput.value = String(s.advanced.networkTimeoutMs);
      if (debugChk) debugChk.checked = s.advanced.debugLogging;
      if (cookiesSel) cookiesSel.value = s.engine.browserCookies || "none";
      if (autoProjPathChk) autoProjPathChk.checked = Boolean(s.downloads.autoProjectPath);
      if (perProjQueueChk) perProjQueueChk.checked = Boolean(s.downloads.perProjectQueue);
      this.updateDownloadLocationModeUI();
    }
    saveSettingsFromForm() {
      const themeSel = document.getElementById("setting-theme");
      const autoImportChk = document.getElementById("setting-auto-import");
      const confirmChk = document.getElementById("setting-confirm-overwrite");
      const cleanupChk = document.getElementById("setting-auto-cleanup");
      const modeSel = document.getElementById("setting-location-mode");
      const playlistSel = document.getElementById("setting-playlist-behavior");
      const customLoc = document.getElementById("setting-custom-location");
      const concSel = document.getElementById("setting-concurrency");
      const retriesSel = document.getElementById("setting-max-retries");
      const timeoutInput = document.getElementById("setting-timeout");
      const debugChk = document.getElementById("setting-debug-logging");
      const cookiesSel = document.getElementById("setting-browser-cookies");
      const autoProjPathChk = document.getElementById("setting-auto-project-path");
      const perProjQueueChk = document.getElementById("setting-per-project-queue");
      const updated = {
        general: {
          theme: themeSel?.value || "host",
          notifications: true,
          confirmOverwrite: confirmChk?.checked ?? true,
          autoCleanupTemp: cleanupChk?.checked ?? true,
          autoImportToProject: autoImportChk?.checked ?? true
        },
        downloads: {
          defaultPreset: "best-available",
          downloadLocationMode: modeSel?.value || "simple",
          customLocation: customLoc?.value || "",
          concurrency: parseInt(concSel?.value || "2", 10),
          maxRetries: parseInt(retriesSel?.value || "3", 10),
          retryDelayMs: 2e3,
          filenamePattern: "%(title)s.%(ext)s",
          playlistBehavior: playlistSel?.value || "ask",
          autoProjectPath: Boolean(autoProjPathChk?.checked),
          perProjectQueue: Boolean(perProjQueueChk?.checked)
        },
        engine: {
          autoUpdate: true,
          browserCookies: cookiesSel?.value || "none",
          cookiesBrowser: cookiesSel?.value || "none"
        },
        advanced: {
          networkTimeoutMs: parseInt(timeoutInput?.value || "30000", 10),
          debugLogging: debugChk?.checked ?? false
        }
      };
      serviceClient.updateSettings(updated);
      if (this.settings) {
        this.settings = { ...this.settings, ...updated };
      }
      try {
        localStorage.setItem("mf_saved_settings", JSON.stringify(this.settings || updated));
      } catch (_) {
      }
      if (updated.downloads.autoProjectPath) {
        const curKey = this.normalizeProjectPath(this.projectContext?.projectPath);
        this.savePerProjectPathOverride(curKey, updated.downloads.downloadLocationMode, updated.downloads.customLocation);
      }
      this.renderQueue();
      this.updateTargetDirDisplay();
      if (typeof window.Settings !== "undefined") {
        const pexelsInput = document.getElementById("setting-studio-pexels-key");
        const pixabayInput = document.getElementById("setting-studio-pixabay-key");
        const unsplashInput = document.getElementById("setting-studio-unsplash-key");
        const giphyInput = document.getElementById("setting-studio-giphy-key");
        window.Settings.save({
          downloadLocationMode: modeSel?.value || "simple",
          customLocation: customLoc?.value?.trim() || "",
          downloadFolder: modeSel?.value === "custom" || modeSel?.value === "custom_flat" ? customLoc?.value?.trim() || "" : "",
          pexelsApiKey: pexelsInput ? pexelsInput.value.trim() : "",
          pixabayApiKey: pixabayInput ? pixabayInput.value.trim() : "",
          unsplashApiKey: unsplashInput ? unsplashInput.value.trim() : "",
          giphyApiKey: giphyInput ? giphyInput.value.trim() : "",
          autoInsertTimeline: false
        });
      }
    }
    renderHistoryList(filterQuery = "") {
      const container = document.getElementById("history-list-container");
      if (!container) return;
      const isPro = window.__MF_EDITION__ === "pro" || window.location.pathname.includes(".pro") || document.title.includes("Pro");
      const myEdition = isPro ? "pro" : "standard";
      const filtered = this.history.filter((h) => {
        const matchEdition = !h.edition || h.edition === myEdition;
        const matchQuery = !filterQuery || h.title.toLowerCase().includes(filterQuery) || h.url.toLowerCase().includes(filterQuery);
        return matchEdition && matchQuery;
      });
      if (filtered.length === 0) {
        container.innerHTML = '<div style="font-size:11px; color:var(--text-muted); padding:12px; text-align:center;">No history records found.</div>';
        return;
      }
      container.innerHTML = "";
      for (const h of filtered) {
        const row = document.createElement("div");
        row.className = "queue-item";
        const dateStr = new Date(h.date).toLocaleDateString();
        const mb = (h.fileSize / (1024 * 1024)).toFixed(1);
        row.innerHTML = `
        <div class="queue-item-header">
          <span class="queue-item-title" title="${h.title}">${h.title}</span>
          <span class="queue-item-badge badge-completed">${h.profileName}</span>
        </div>
        <div class="queue-item-stats">
          <span>${dateStr} • ${mb} MB</span>
          <div class="queue-item-actions">
            <button class="btn btn-icon btn-sm btn-hist-reveal" title="Show in Folder">${ICONS.FOLDER}</button>
            <button class="btn btn-icon btn-sm btn-hist-redl" title="Download Again">${ICONS.RETRY}</button>
            <button class="btn btn-icon btn-sm btn-hist-del" title="Delete from history">${ICONS.CLOSE}</button>
          </div>
        </div>
      `;
        row.querySelector(".btn-hist-reveal")?.addEventListener("click", () => hostAdapter.revealInFinder(h.outputPath));
        row.querySelector(".btn-hist-redl")?.addEventListener("click", () => {
          const input = document.getElementById("url-input");
          if (input) {
            input.value = h.url;
            this.closeModal("modal-history");
            this.handleAnalyze();
          }
        });
        // Per-row button has data-id for container delegation
        row.querySelector(".btn-hist-del")?.setAttribute("data-id", h.id);
        row.querySelector(".btn-hist-del")?.addEventListener("click", (e) => {
          e.stopPropagation();
          serviceClient.removeHistoryItem(h.id);
          this.history = (this.history || []).filter(item => item.id !== h.id);
          this.renderHistoryList();
        });
        container.appendChild(row);
      }
    }
    showDuplicateModal(filePath) {
      const pathEl = document.getElementById("dup-file-path");
      if (pathEl) pathEl.textContent = filePath;
      this.openModal("modal-duplicate");
    }
    openModal(id) {
      const m = document.getElementById(id);
      if (m) m.classList.add("active");
    }
    closeModal(id) {
      if (id === "modal-media-preview") {
        const viewport = document.getElementById("media-preview-viewport");
        if (viewport) viewport.innerHTML = "";
      }
      const m = document.getElementById(id);
      if (m) m.classList.remove("active");
    }
    openMediaPreview(meta) {
      if (!meta) return;
      const url = meta.url || "";
      const activeItem = meta.items && meta.items.length > 0 ? meta.items[0] : meta;
      const isAppleMusic = Boolean(meta.isAppleMusic || /music\.apple\.com|itunes\.apple\.com/i.test(url));
      const isSpotify = Boolean(meta.isSpotify || /spotify\.com/i.test(url));
      const isExplicitAudio = meta.mediaType === "audio" || meta.type === "audio" || activeItem.type === "audio" || activeItem.mediaType === "audio" || isSpotify || isAppleMusic;
      const isExplicitImage = !isExplicitAudio && (meta.mediaType === "image" || meta.type === "image" || activeItem.type === "image" || activeItem.mediaType === "image" || meta.isImage || activeItem.isImage);
      const isExplicitVideo = !isExplicitAudio && !isExplicitImage;
      const embedUrl = isExplicitVideo ? meta.embedUrl || activeItem.embedUrl || "" : "";
      const streamUrl = meta.directStreamUrl || activeItem.directStreamUrl || meta.downloadTarget || activeItem.downloadTarget || "";
      const audioPreview = isExplicitAudio ? activeItem.audioPreviewUrl || meta.audioPreviewUrl || activeItem.previewUrl || meta.previewUrl || streamUrl : "";
      const theaterItem = {
        id: meta.id || "preview_" + Date.now(),
        videoId: isExplicitAudio ? "" : meta.id || activeItem.id,
        title: activeItem.title || meta.title,
        author: activeItem.uploader || meta.uploader || meta.channel || "Media Creator",
        uploader: activeItem.uploader || meta.uploader || meta.channel || "Media Creator",
        thumbnail: activeItem.thumbnail || meta.thumbnail,
        pageUrl: meta.url,
        sourceUrl: activeItem.url || meta.url,
        url: activeItem.url || meta.url,
        source: isAppleMusic ? "apple_music" : isSpotify ? "spotify" : meta.platform || meta.extractor || "media",
        platform: isAppleMusic ? "apple_music" : isSpotify ? "spotify" : meta.platform || "",
        isAppleMusic,
        isSpotify,
        type: isExplicitAudio ? "audio" : isExplicitImage ? "image" : "video",
        audioPreviewUrl: audioPreview,
        previewUrl: isExplicitAudio ? audioPreview : embedUrl || streamUrl,
        hoverPreviewUrl: isExplicitAudio ? audioPreview : streamUrl,
        embedUrl,
        directStreamUrl: streamUrl,
        downloadFormats: activeItem.formats || meta.formats || []
      };
      if (typeof window.openTheaterPreview === "function") {
        try {
          window.openTheaterPreview(theaterItem);
          return;
        } catch (err) {
          console.warn("Theater player delegate error:", err);
        }
      }
      const titleEl = document.getElementById("media-preview-title");
      const authorEl = document.getElementById("media-preview-author");
      const viewport = document.getElementById("media-preview-viewport");
      const openBrowserBtn = document.getElementById("btn-open-preview-browser");
      if (authorEl) {
        const isImg = meta.mediaType === "image" || meta.isImage || activeItem?.mediaType === "image";
        const durStr = isImg ? "PHOTO" : meta.duration && meta.duration > 0 ? this.formatDuration(meta.duration) : "";
        authorEl.textContent = `${activeItem.uploader || meta.uploader || meta.channel || "Media"}${durStr ? " \u2022 " + durStr : ""}`;
      }
      if (openBrowserBtn) {
        openBrowserBtn.onclick = () => {
          const u = meta.url;
          if (u) {
            if (window.__adobe_cep__ && typeof window.__adobe_cep__.openURLInDefaultBrowser === "function") {
              window.__adobe_cep__.openURLInDefaultBrowser(u);
            } else if (window.cep?.util?.openURLInDefaultBrowser) {
              window.cep.util.openURLInDefaultBrowser(u);
            } else {
              window.open(u, "_blank");
            }
          }
        };
      }
      if (viewport) {
        viewport.innerHTML = "";
        const isYouTube = !isAudio && (url.includes("youtube.com") || url.includes("youtu.be"));
        if (isAppleMusic) {
          const audioUrl = audioPreview;
          if (audioUrl) {
            viewport.innerHTML = `
            <div style="display:flex; flex-direction:column; align-items:center; justify-content:center; gap:14px; padding:20px; text-align:center; height:100%;">
              <img src="${activeItem.thumbnail || meta.thumbnail || ""}" style="width:120px; height:120px; border-radius:8px; object-fit:cover; box-shadow:0 8px 24px rgba(0,0,0,0.6);" alt="Cover">
              <div style="display:flex; flex-direction:column; gap:4px;">
                <span style="font-size:13px; font-weight:700; color:#fff;">${activeItem.title || meta.title || "Apple Music Track"}</span>
                <span style="font-size:11px; color:#ff4d55; font-weight:600;">${activeItem.uploader || meta.uploader || meta.channel || "Artist"} \u2022 Apple Music</span>
              </div>
              <audio src="${audioUrl}" controls autoplay style="width:90%; max-width:320px; margin-top:6px;"></audio>
            </div>
          `;
          } else {
            viewport.innerHTML = `<div style="display:flex; flex-direction:column; align-items:center; justify-content:center; gap:8px; padding:20px; color:#aaa;"><span>Apple Music track ready for download</span></div>`;
          }
        } else if (isYouTube) {
          let ytId = meta.id;
          if (!ytId || ytId.length !== 11) {
            const match = url.match(/(?:v=|youtu\.be\/|embed\/|live\/)([a-zA-Z0-9_-]{11})/);
            if (match) ytId = match[1];
          }
          if (ytId) {
            viewport.innerHTML = `<iframe src="http://127.0.0.1:48924/youtube-player.html?v=${encodeURIComponent(ytId)}&autoplay=1" style="width:100%; height:100%; border:none;" allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen></iframe>`;
          } else {
            viewport.innerHTML = `<div style="display:flex; flex-direction:column; align-items:center; justify-content:center; gap:8px; padding:20px; color:#aaa;"><span>Preview ready</span><button class="btn btn-primary btn-sm" id="btn-play-yt-browser" style="display:inline-flex; align-items:center; gap:5px;">${ICONS.PLAY} Play in Browser</button></div>`;
            document.getElementById("btn-play-yt-browser")?.addEventListener("click", () => {
              if (window.__adobe_cep__?.openURLInDefaultBrowser) window.__adobe_cep__.openURLInDefaultBrowser(url);
              else window.open(url, "_blank");
            });
          }
        } else if (isSpotify) {
          const trackMatch = url.match(/track\/([a-zA-Z0-9]+)/);
          const sId = trackMatch ? trackMatch[1] : meta.id;
          if (sId) {
            viewport.innerHTML = `<iframe src="https://open.spotify.com/embed/track/${sId}?utm_source=generator" width="100%" height="100%" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"></iframe>`;
          }
        } else if (embedUrl) {
          viewport.innerHTML = `<iframe src="${embedUrl}" style="width:100%; height:100%; border:none;" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen></iframe>`;
        } else {
          let resolvedStreamUrl = streamUrl;
          if (!resolvedStreamUrl && meta.formats && meta.formats.length > 0) {
            const streamFormat = meta.formats.find((f) => f.url && (f.hasAudioAndVideo || f.ext === "mp4" && f.vcodec !== "none"));
            if (streamFormat) resolvedStreamUrl = streamFormat.url;
          }
          if (resolvedStreamUrl && /\.(mp4|webm|m3u8|mov|ogg)($|\?)/i.test(resolvedStreamUrl)) {
            viewport.innerHTML = `<video src="${resolvedStreamUrl}" controls autoplay playsinline style="width:100%; height:100%; object-fit:contain;"></video>`;
            const vEl = viewport.querySelector("video");
            if (vEl) {
              vEl.onloadedmetadata = () => {
                if (vEl.duration && !isNaN(vEl.duration) && vEl.duration > 0 && (!meta.duration || meta.duration <= 0)) {
                  meta.duration = Math.round(vEl.duration);
                  if (authorEl) {
                    authorEl.textContent = `${activeItem.uploader || meta.uploader || meta.channel || "Media"} \u2022 ${this.formatDuration(meta.duration)}`;
                  }
                  const dt = document.getElementById("media-duration-tag");
                  if (dt) dt.textContent = this.formatDuration(meta.duration);
                }
              };
            }
          } else {
            viewport.innerHTML = `
            <div style="display:flex; flex-direction:column; align-items:center; justify-content:center; gap:10px; padding:20px; text-align:center; color:#ddd;">
              <div style="width:28px; height:28px; border:3px solid #00d1b2; border-top-color:transparent; border-radius:50%; animation:spin 0.8s linear infinite;"></div>
              <span style="font-size:12px; font-weight:600; color:#00d1b2;">Resolving stream preview...</span>
            </div>
          `;
            fetch(`http://127.0.0.1:48924/api/stream-url?v=${encodeURIComponent(url)}`).then((r) => r.json()).then((data) => {
              if (data && data.success && data.streamUrl) {
                viewport.innerHTML = `<video src="${data.streamUrl}" controls autoplay playsinline style="width:100%; height:100%; object-fit:contain;"></video>`;
                const vEl = viewport.querySelector("video");
                if (vEl) {
                  vEl.onloadedmetadata = () => {
                    if (vEl.duration && !isNaN(vEl.duration) && vEl.duration > 0 && (!meta.duration || meta.duration <= 0)) {
                      meta.duration = Math.round(vEl.duration);
                      if (authorEl) {
                        authorEl.textContent = `${activeItem.uploader || meta.uploader || meta.channel || "Media"} \u2022 ${this.formatDuration(meta.duration)}`;
                      }
                      const dt = document.getElementById("media-duration-tag");
                      if (dt) dt.textContent = this.formatDuration(meta.duration);
                    }
                  };
                }
              } else {
                throw new Error("Stream URL not found");
              }
            }).catch(() => {
              viewport.innerHTML = `
                <div style="display:flex; flex-direction:column; align-items:center; justify-content:center; gap:8px; padding:16px; text-align:center;">
                  <img src="${meta.thumbnail || ""}" style="max-height:140px; border-radius:4px; box-shadow:0 4px 12px rgba(0,0,0,0.5);" alt="Thumb">
                  <span style="font-size:11px; color:#bbb;">Click below to stream in default browser</span>
                  <button type="button" class="btn btn-primary btn-sm" id="btn-play-external" style="padding:4px 12px; font-weight:600; display:inline-flex; align-items:center; gap:5px;">${ICONS.PLAY} Watch Stream</button>
                </div>
              `;
              document.getElementById("btn-play-external")?.addEventListener("click", () => {
                if (window.__adobe_cep__ && typeof window.__adobe_cep__.openURLInDefaultBrowser === "function") {
                  window.__adobe_cep__.openURLInDefaultBrowser(url);
                } else if (window.cep?.util?.openURLInDefaultBrowser) {
                  window.cep.util.openURLInDefaultBrowser(url);
                } else {
                  window.open(url, "_blank");
                }
              });
            });
          }
        }
      }
      this.openModal("modal-media-preview");
    }
    closeMediaPreview() {
      const viewport = document.getElementById("media-preview-viewport");
      if (viewport) viewport.innerHTML = "";
      this.closeModal("modal-media-preview");
    }
    parseTimeToSec(txt) {
      if (!txt) return 0;
      const clean = txt.trim();
      if (!clean) return 0;
      const parts = clean.split(":").map((p) => parseFloat(p.trim()) || 0);
      if (parts.length >= 3) {
        let sec = parts[0] * 3600 + parts[1] * 60 + parts[2];
        if (parts.length >= 4) sec += parts[3] / 30;
        return sec;
      }
      if (parts.length === 2) return parts[0] * 60 + parts[1];
      if (parts.length === 1) return parts[0];
      return 0;
    }
    formatDuration(seconds) {
      if (!seconds || seconds <= 0) return "00:00";
      const h = Math.floor(seconds / 3600);
      const m = Math.floor(seconds % 3600 / 60);
      const s = Math.floor(seconds % 60);
      if (h > 0) {
        return `${h.toString().padStart(2, "0")}:${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
      }
      return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
    }
    loadUrlIntoDownloader(targetUrl, options = {}) {
      if (!targetUrl) return;
      const modeBtnDownload = document.getElementById("mode-btn-download");
      if (modeBtnDownload) modeBtnDownload.click();
      this.currentMetadata = null;
      this.currentPlaylist = null;
      this.pendingDownloadParams = null;
      if (typeof window.resetTrim === "function") window.resetTrim();
      const filenameInput = document.getElementById("custom-filename-input");
      if (filenameInput) filenameInput.value = "";
      const cardSection = document.getElementById("media-card-section");
      if (cardSection) cardSection.style.display = "none";
      if (options.isAudio) {
        const audioBtn = document.getElementById("mode-audio-only");
        if (audioBtn) audioBtn.click();
      } else if (options.isVideo) {
        const videoBtn = document.getElementById("mode-video-audio");
        if (videoBtn) videoBtn.click();
      }
      const urlInput = document.getElementById("url-input");
      if (urlInput) {
        urlInput.value = targetUrl;
        urlInput.dispatchEvent(new Event("input", { bubbles: true }));
        urlInput.dispatchEvent(new Event("change", { bubbles: true }));
        urlInput.focus();
      }
      if (options.openTrimmer) {
        const trimPanel = document.getElementById("trim-inputs-panel");
        const trimArrow = document.getElementById("trim-toggle-arrow");
        if (trimPanel) {
          trimPanel.style.display = "flex";
          if (trimArrow) trimArrow.textContent = "\u25BC";
        }
      }
      setTimeout(() => {
        this.handleAnalyze();
      }, 120);
    }
  };
  if (typeof document !== "undefined") {
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", () => new MediaFetchApp());
    } else {
      new MediaFetchApp();
    }
  }
})();
//# sourceMappingURL=main.js.map
