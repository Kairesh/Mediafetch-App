import fs from 'fs';
import path from 'path';
import os from 'os';
import { execFile } from 'child_process';
import { promisify } from 'util';
import https from 'https';
import http from 'http';
import { fileURLToPath } from 'url';
import { logger } from './logger.js';

const getFilename = () => {
  try {
    if (typeof __filename !== 'undefined') return __filename;
    if (typeof import.meta !== 'undefined' && import.meta?.url) return fileURLToPath(import.meta.url);
  } catch (_) {}
  return '';
};
const _selfFile = getFilename();
const __dirname = _selfFile ? path.dirname(_selfFile) : process.cwd();
const execFileAsync = promisify(execFile);

export class DependencyManager {
  constructor() {
    const isWin = process.platform === 'win32';
    const isMac = process.platform === 'darwin';
    let appData;
    if (isWin) {
      appData = process.env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local');
    } else if (isMac) {
      appData = path.join(os.homedir(), 'Library', 'Application Support');
    } else {
      appData = path.join(os.homedir(), '.mediafetch');
    }
    this.binDir = path.join(appData, 'MediaFetch', 'bin');
    this.isUpdating = false;
    this.ensureBinDirectory();
  }

  ensureBinDirectory() {
    try {
      if (!fs.existsSync(this.binDir)) {
        fs.mkdirSync(this.binDir, { recursive: true });
      }
    } catch (err) {
      logger.error('Failed to create bin directory:', err);
    }
  }

  getBinDir() {
    return this.binDir;
  }

  async checkYtDlp() {
    try {
      const execPath = await this.getYtDlpExecutablePath();
      if (!fs.existsSync(execPath)) {
        return { name: 'ytdlp', available: false, error: 'yt-dlp executable not found' };
      }
      const { stdout } = await execFileAsync(execPath, ['--version'], { windowsHide: true });
      return { name: 'ytdlp', available: true, version: stdout.trim(), path: execPath };
    } catch (err) {
      return { name: 'ytdlp', available: false, error: err.message };
    }
  }

  async checkFfmpeg() {
    try {
      const execPath = await this.getFfmpegExecutablePath();
      if (!execPath || !fs.existsSync(execPath)) {
        return { name: 'ffmpeg', available: false, error: 'FFmpeg executable not found' };
      }
      const { stdout } = await execFileAsync(execPath, ['-version'], { windowsHide: true });
      const firstLine = stdout.split('\n')[0] || '';
      const versionMatch = firstLine.match(/version\s+([^\s]+)/i);
      const version = versionMatch ? versionMatch[1] : 'installed';
      return { name: 'ffmpeg', available: true, version, path: execPath };
    } catch (err) {
      return { name: 'ffmpeg', available: false, error: err.message };
    }
  }

  async checkFfprobe() {
    try {
      const isWin = process.platform === 'win32';
      const execPath = path.join(this.binDir, isWin ? 'ffprobe.exe' : 'ffprobe');
      if (!fs.existsSync(execPath)) {
        return { name: 'ffprobe', available: false, error: 'ffprobe executable not found' };
      }
      const { stdout } = await execFileAsync(execPath, ['-version'], { windowsHide: true });
      const firstLine = stdout.split('\n')[0] || '';
      const versionMatch = firstLine.match(/version\s+([^\s]+)/i);
      const version = versionMatch ? versionMatch[1] : 'installed';
      return { name: 'ffprobe', available: true, version, path: execPath };
    } catch (err) {
      return { name: 'ffprobe', available: false, error: err.message };
    }
  }

  getNodeExecutablePath() {
    // Check if process.execPath is genuinely node.exe (not AfterFX.exe or Premiere.exe)
    if (typeof process !== 'undefined' && process.execPath) {
      const base = path.basename(process.execPath).toLowerCase();
      if (base === 'node.exe' || base === 'node') {
        return process.execPath;
      }
    }

    const isWin = process.platform === 'win32';
    const candidates = isWin ? [
      'C:\\Program Files\\nodejs\\node.exe',
      'C:\\Program Files (x86)\\nodejs\\node.exe',
      process.env.LOCALAPPDATA ? path.join(process.env.LOCALAPPDATA, 'Programs', 'node', 'node.exe') : '',
      process.env.APPDATA ? path.join(process.env.APPDATA, 'npm', 'node.exe') : ''
    ].filter(Boolean) : [
      '/usr/local/bin/node',
      '/usr/bin/node'
    ];

    for (const c of candidates) {
      try {
        if (fs.existsSync(c)) return c;
      } catch (_) {}
    }

    return 'node';
  }

  async downloadFile(url, destPath, onProgress, stepLabel = 'Downloading') {
    return new Promise((resolve, reject) => {
      const follow = (curUrl, redirectCount = 0) => {
        if (redirectCount > 10) return reject(new Error('Too many HTTP redirects'));
        const parsed = new URL(curUrl);
        const client = parsed.protocol === 'https:' ? https : http;
        const req = client.get(curUrl, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) MediaFetch/1.0',
            'Accept': '*/*'
          }
        }, (res) => {
          if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
            const nextUrl = new URL(res.headers.location, curUrl).toString();
            return follow(nextUrl, redirectCount + 1);
          }
          if (res.statusCode !== 200) {
            return reject(new Error(`Download failed with HTTP ${res.statusCode}`));
          }
          const totalBytes = parseInt(res.headers['content-length'] || '0', 10);
          let loadedBytes = 0;
          const tempFile = `${destPath}.tmp_${Date.now()}`;
          const outStream = fs.createWriteStream(tempFile);
          res.on('data', (chunk) => {
            loadedBytes += chunk.length;
            if (totalBytes > 0 && onProgress) {
              const pct = Math.min(99, Math.round((loadedBytes / totalBytes) * 100));
              const mb = (loadedBytes / (1024 * 1024)).toFixed(1);
              const totalMb = (totalBytes / (1024 * 1024)).toFixed(1);
              onProgress('downloading', pct, `${stepLabel}: ${mb} MB / ${totalMb} MB (${pct}%)`);
            }
          });
          res.pipe(outStream);
          outStream.on('finish', () => {
            outStream.close(() => {
              try {
                if (fs.existsSync(destPath)) fs.unlinkSync(destPath);
                fs.renameSync(tempFile, destPath);
                resolve(destPath);
              } catch (renameErr) {
                reject(renameErr);
              }
            });
          });
          outStream.on('error', (err) => {
            try { if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile); } catch (_) {}
            reject(err);
          });
        });
        req.on('error', reject);
        req.setTimeout(90000, () => {
          req.destroy();
          reject(new Error('Network timeout downloading dependency'));
        });
      };
      follow(url);
    });
  }

  async getYtDlpExecutablePath() {
    const isWin = process.platform === 'win32';
    const filename = isWin ? 'yt-dlp.exe' : 'yt-dlp';
    const macFilename = 'yt-dlp_macos';
    const candidates = [
      path.join(this.binDir, filename),
      path.join(this.binDir, macFilename),
      path.join(process.env.LOCALAPPDATA || '', 'MediaFetch', 'bin', filename),
      path.join(process.env.APPDATA || '', 'MediaFetch', 'bin', filename),
      path.join(process.env.APPDATA || '', 'Python', 'Python314', 'Scripts', filename),
      path.join(process.env.APPDATA || '', 'Python', 'Python313', 'Scripts', filename),
      path.join(process.env.APPDATA || '', 'Python', 'Python312', 'Scripts', filename),
      path.join(process.env.APPDATA || '', 'Python', 'Python311', 'Scripts', filename),
      path.join(process.env.LOCALAPPDATA || '', 'Programs', 'Python', 'Python314', 'Scripts', filename),
      path.join(process.env.LOCALAPPDATA || '', 'Programs', 'Python', 'Python313', 'Scripts', filename),
      path.join(process.env.LOCALAPPDATA || '', 'Programs', 'Python', 'Python312', 'Scripts', filename),
      path.join(process.env.LOCALAPPDATA || '', 'Microsoft', 'WinGet', 'Links', filename),
      path.join(process.env.APPDATA || '', 'blinkl.io', 'resources', 'io.any-paste.blinkl', 'yt-dlp', filename),
      '/opt/homebrew/bin/yt-dlp',
      '/usr/local/bin/yt-dlp',
      '/usr/bin/yt-dlp',
      path.join(__dirname, '..', 'bin', filename),
      path.join(__dirname, 'bin', filename),
      path.join(os.homedir(), '.stacher', filename)
    ];
    for (const c of candidates) {
      if (c && fs.existsSync(c)) return c;
    }
    try {
      await execFileAsync(filename, ['--version'], { windowsHide: true });
      return filename;
    } catch (_) {}
    return path.join(this.binDir, filename);
  }

  async getFfmpegExecutablePath() {
    const isWin = process.platform === 'win32';
    const filename = isWin ? 'ffmpeg.exe' : 'ffmpeg';
    const candidates = [
      path.join(this.binDir, filename),
      path.join(process.env.LOCALAPPDATA || '', 'MediaFetch', 'bin', filename),
      path.join(process.env.APPDATA || '', 'MediaFetch', 'bin', filename),
      path.join(process.env.LOCALAPPDATA || '', 'Microsoft', 'WinGet', 'Links', filename),
      path.join(process.env.APPDATA || '', 'blinkl.io', 'resources', 'ffmpeg', filename),
      '/opt/homebrew/bin/ffmpeg',
      '/usr/local/bin/ffmpeg',
      '/usr/bin/ffmpeg',
      path.join(__dirname, '..', 'bin', filename),
      path.join(__dirname, 'bin', filename),
      path.join(os.homedir(), '.stacher', filename)
    ];
    for (const c of candidates) {
      if (c && fs.existsSync(c)) return c;
    }
    try {
      await execFileAsync(filename, ['-version'], { windowsHide: true });
      return filename;
    } catch (_) {}
    return path.join(this.binDir, filename);
  }

  async getFfprobeExecutablePath() {
    const isWin = process.platform === 'win32';
    const filename = isWin ? 'ffprobe.exe' : 'ffprobe';
    const candidates = [
      path.join(this.binDir, filename),
      path.join(process.env.LOCALAPPDATA || '', 'MediaFetch', 'bin', filename),
      path.join(process.env.APPDATA || '', 'MediaFetch', 'bin', filename),
      path.join(process.env.LOCALAPPDATA || '', 'Microsoft', 'WinGet', 'Links', filename),
      path.join(process.env.APPDATA || '', 'blinkl.io', 'resources', 'ffmpeg', filename),
      '/opt/homebrew/bin/ffprobe',
      '/usr/local/bin/ffprobe',
      '/usr/bin/ffprobe',
      path.join(__dirname, '..', 'bin', filename),
      path.join(__dirname, 'bin', filename),
      path.join(os.homedir(), '.stacher', filename)
    ];
    for (const c of candidates) {
      if (c && fs.existsSync(c)) return c;
    }
    try {
      await execFileAsync(filename, ['-version'], { windowsHide: true });
      return filename;
    } catch (_) {}
    return path.join(this.binDir, filename);
  }

  async installYtDlp(onProgress) {
    this.ensureBinDirectory();
    const isWin = process.platform === 'win32';
    const isMac = process.platform === 'darwin';
    const filename = isWin ? 'yt-dlp.exe' : 'yt-dlp';
    const targetPath = path.join(this.binDir, filename);

    onProgress?.('installing', 10, 'Connecting to official yt-dlp repository...');
    const urls = isWin ? [
      'https://github.com/yt-dlp/yt-dlp-nightly-builds/releases/latest/download/yt-dlp.exe',
      'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe'
    ] : (isMac ? [
      'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_macos',
      'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp'
    ] : [
      'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp'
    ]);

    let downloaded = false;
    let lastErr = null;
    for (const u of urls) {
      try {
        await this.downloadFile(u, targetPath, onProgress, 'Downloading yt-dlp');
        downloaded = true;
        break;
      } catch (e) {
        lastErr = e;
        logger.warn('[DependencyManager] Primary yt-dlp download failed, trying fallback:', e.message);
      }
    }

    if (!downloaded || !fs.existsSync(targetPath)) {
      if (isWin) {
        try {
          onProgress?.('installing', 40, 'Downloading via PowerShell system client...');
          const psCmd = `[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; (New-Object System.Net.WebClient).DownloadFile('${urls[0]}', '${targetPath}')`;
          await execFileAsync('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', psCmd], { windowsHide: true, timeout: 60000 });
        } catch (psErr) {
          lastErr = psErr;
        }
      } else if (isMac) {
        try {
          onProgress?.('installing', 40, 'Downloading via curl system client...');
          await execFileAsync('curl', ['-L', urls[0], '-o', targetPath], { timeout: 60000 });
        } catch (curlErr) {
          lastErr = curlErr;
        }
      }
    }

    if (!fs.existsSync(targetPath)) {
      return { success: false, error: lastErr ? lastErr.message : 'Could not download yt-dlp' };
    }

    if (!isWin) {
      try { fs.chmodSync(targetPath, 0o755); } catch (_) {}
    }

    try {
      const { stdout } = await execFileAsync(targetPath, ['--version'], { windowsHide: true, timeout: 10000 });
      const ver = stdout.trim();
      onProgress?.('installing', 100, `yt-dlp ready (${ver})`);
      return { success: true, version: ver, path: targetPath };
    } catch (verErr) {
      return { success: true, version: 'installed', path: targetPath };
    }
  }

  async installFfmpeg(onProgress) {
    this.ensureBinDirectory();
    const isWin = process.platform === 'win32';
    const isMac = process.platform === 'darwin';

    if (isMac) {
      for (const p of ['/opt/homebrew/bin/ffmpeg', '/usr/local/bin/ffmpeg']) {
        if (fs.existsSync(p)) {
          onProgress?.('installing', 100, 'FFmpeg found on macOS system.');
          return { success: true, version: 'installed', path: p };
        }
      }

      const arch = process.arch === 'arm64' ? 'arm64' : 'x64';
      const ffmpegTarget = path.join(this.binDir, 'ffmpeg');
      const ffprobeTarget = path.join(this.binDir, 'ffprobe');
      const ffmpegUrl = `https://github.com/eugeneware/ffmpeg-static/releases/latest/download/ffmpeg-darwin-${arch}`;
      const ffprobeUrl = `https://github.com/eugeneware/ffmpeg-static/releases/latest/download/ffprobe-darwin-${arch}`;

      onProgress?.('installing', 10, 'Downloading macOS FFmpeg media engine...');
      try {
        await this.downloadFile(ffmpegUrl, ffmpegTarget, (stage, pct, msg) => {
          onProgress?.('installing', Math.min(50, Math.round(pct * 0.5)), msg);
        }, 'Downloading FFmpeg');
        try { fs.chmodSync(ffmpegTarget, 0o755); } catch (_) {}

        onProgress?.('installing', 50, 'Downloading macOS FFprobe analyzer...');
        await this.downloadFile(ffprobeUrl, ffprobeTarget, (stage, pct, msg) => {
          onProgress?.('installing', Math.min(95, 50 + Math.round(pct * 0.45)), msg);
        }, 'Downloading FFprobe');
        try { fs.chmodSync(ffprobeTarget, 0o755); } catch (_) {}

        if (fs.existsSync(ffmpegTarget)) {
          onProgress?.('installing', 100, 'FFmpeg & FFprobe installed successfully on macOS.');
          return { success: true, version: 'installed', path: ffmpegTarget };
        }
      } catch (macErr) {
        logger.error('[DependencyManager] Mac FFmpeg install error:', macErr);
        return { success: false, error: 'Could not auto-install FFmpeg. Run "brew install ffmpeg" in Terminal.' };
      }
    }

    if (!isWin) {
      return { success: false, error: 'Please install ffmpeg via your package manager (e.g. brew install ffmpeg).' };
    }

    const ffmpegTarget = path.join(this.binDir, 'ffmpeg.exe');
    const ffprobeTarget = path.join(this.binDir, 'ffprobe.exe');

    onProgress?.('installing', 5, 'Downloading FFmpeg and FFprobe media engines...');
    const zipUrl = 'https://github.com/yt-dlp/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip';
    const tempZip = path.join(os.tmpdir(), `ffmpeg_${Date.now()}.zip`);
    const tempUnpack = path.join(os.tmpdir(), `ffmpeg_unpack_${Date.now()}`);

    try {
      await this.downloadFile(zipUrl, tempZip, (stage, pct, msg) => {
        onProgress?.('installing', Math.min(88, 5 + Math.round(pct * 0.83)), msg || `Downloading media merger (${pct}%)...`);
      }, 'Downloading FFmpeg merger');

      onProgress?.('installing', 90, 'Extracting FFmpeg & FFprobe core binaries...');
      const psScript = `
        Expand-Archive -Path '${tempZip}' -DestinationPath '${tempUnpack}' -Force;
        Get-ChildItem -Path '${tempUnpack}' -Recurse -Filter 'ffmpeg.exe' | Copy-Item -Destination '${ffmpegTarget}' -Force;
        Get-ChildItem -Path '${tempUnpack}' -Recurse -Filter 'ffprobe.exe' | Copy-Item -Destination '${ffprobeTarget}' -Force;
        Remove-Item -Force '${tempZip}' -ErrorAction SilentlyContinue;
        Remove-Item -Recurse -Force '${tempUnpack}' -ErrorAction SilentlyContinue;
      `;
      await execFileAsync('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', psScript], { windowsHide: true, timeout: 60000 });

      if (fs.existsSync(ffmpegTarget) && fs.existsSync(ffprobeTarget)) {
        onProgress?.('installing', 100, 'FFmpeg & FFprobe installed successfully.');
        return { success: true, version: 'installed', path: ffmpegTarget };
      }
      return { success: false, error: 'FFmpeg extraction did not produce ffmpeg.exe' };
    } catch (err) {
      logger.error('[DependencyManager] FFmpeg install error:', err);
      return { success: false, error: err.message || 'FFmpeg installation failed' };
    }
  }

  async updateYtDlp(hasActiveDownloads, onProgress) {
    if (hasActiveDownloads) {
      return { success: false, error: 'Cannot update while downloads are active' };
    }
    try {
      const execPath = await this.getYtDlpExecutablePath();
      // If yt-dlp does not exist at all, perform first-time installation!
      if (!execPath || !fs.existsSync(execPath)) {
        onProgress?.('updating', 10, 'yt-dlp engine not found. Downloading fresh copy...');
        return await this.installYtDlp(onProgress);
      }

      onProgress?.('updating', 20, 'Querying official repository...');
      try {
        const { stdout, stderr } = await execFileAsync(execPath, ['-U'], { windowsHide: true, timeout: 60000 });
        const output = (stdout || stderr || '').trim();
        onProgress?.('updating', 100, output.includes('up to date') ? 'Already up to date' : 'Updated successfully');
        return { success: true, version: output };
      } catch (updateErr) {
        logger.warn('[DependencyManager] yt-dlp self-update failed, falling back to direct re-download:', updateErr.message);
        onProgress?.('updating', 40, 'Directly downloading latest release from GitHub...');
        return await this.installYtDlp(onProgress);
      }
    } catch (err) {
      logger.error('[DependencyManager] yt-dlp update error:', err);
      return { success: false, error: err.message || 'Update failed' };
    }
  }
}

export const dependencyManager = new DependencyManager();