var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/node_modules/ws/lib/constants.js
var require_constants = __commonJS({
  "MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/node_modules/ws/lib/constants.js"(exports2, module2) {
    "use strict";
    var BINARY_TYPES = ["nodebuffer", "arraybuffer", "fragments"];
    var hasBlob = typeof Blob !== "undefined";
    if (hasBlob) BINARY_TYPES.push("blob");
    module2.exports = {
      BINARY_TYPES,
      CLOSE_TIMEOUT: 3e4,
      EMPTY_BUFFER: Buffer.alloc(0),
      GUID: "258EAFA5-E914-47DA-95CA-C5AB0DC85B11",
      hasBlob,
      kForOnEventAttribute: /* @__PURE__ */ Symbol("kIsForOnEventAttribute"),
      kListener: /* @__PURE__ */ Symbol("kListener"),
      kStatusCode: /* @__PURE__ */ Symbol("status-code"),
      kWebSocket: /* @__PURE__ */ Symbol("websocket"),
      NOOP: () => {
      }
    };
  }
});

// MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/node_modules/ws/lib/buffer-util.js
var require_buffer_util = __commonJS({
  "MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/node_modules/ws/lib/buffer-util.js"(exports2, module2) {
    "use strict";
    var { EMPTY_BUFFER } = require_constants();
    var FastBuffer = Buffer[Symbol.species];
    function concat(list, totalLength) {
      if (list.length === 0) return EMPTY_BUFFER;
      if (list.length === 1) return list[0];
      const target = Buffer.allocUnsafe(totalLength);
      let offset = 0;
      for (let i = 0; i < list.length; i++) {
        const buf = list[i];
        target.set(buf, offset);
        offset += buf.length;
      }
      if (offset < totalLength) {
        return new FastBuffer(target.buffer, target.byteOffset, offset);
      }
      return target;
    }
    function _mask(source, mask, output, offset, length) {
      for (let i = 0; i < length; i++) {
        output[offset + i] = source[i] ^ mask[i & 3];
      }
    }
    function _unmask(buffer, mask) {
      for (let i = 0; i < buffer.length; i++) {
        buffer[i] ^= mask[i & 3];
      }
    }
    function toArrayBuffer(buf) {
      if (buf.length === buf.buffer.byteLength) {
        return buf.buffer;
      }
      return buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.length);
    }
    function toBuffer(data) {
      toBuffer.readOnly = true;
      if (Buffer.isBuffer(data)) return data;
      let buf;
      if (data instanceof ArrayBuffer) {
        buf = new FastBuffer(data);
      } else if (ArrayBuffer.isView(data)) {
        buf = new FastBuffer(data.buffer, data.byteOffset, data.byteLength);
      } else {
        buf = Buffer.from(data);
        toBuffer.readOnly = false;
      }
      return buf;
    }
    module2.exports = {
      concat,
      mask: _mask,
      toArrayBuffer,
      toBuffer,
      unmask: _unmask
    };
    if (!process.env.WS_NO_BUFFER_UTIL) {
      try {
        const bufferUtil = require("bufferutil");
        module2.exports.mask = function(source, mask, output, offset, length) {
          if (length < 48) _mask(source, mask, output, offset, length);
          else bufferUtil.mask(source, mask, output, offset, length);
        };
        module2.exports.unmask = function(buffer, mask) {
          if (buffer.length < 32) _unmask(buffer, mask);
          else bufferUtil.unmask(buffer, mask);
        };
      } catch (e) {
      }
    }
  }
});

// MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/node_modules/ws/lib/limiter.js
var require_limiter = __commonJS({
  "MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/node_modules/ws/lib/limiter.js"(exports2, module2) {
    "use strict";
    var kDone = /* @__PURE__ */ Symbol("kDone");
    var kRun = /* @__PURE__ */ Symbol("kRun");
    var Limiter = class {
      /**
       * Creates a new `Limiter`.
       *
       * @param {Number} [concurrency=Infinity] The maximum number of jobs allowed
       *     to run concurrently
       */
      constructor(concurrency) {
        this[kDone] = () => {
          this.pending--;
          this[kRun]();
        };
        this.concurrency = concurrency || Infinity;
        this.jobs = [];
        this.pending = 0;
      }
      /**
       * Adds a job to the queue.
       *
       * @param {Function} job The job to run
       * @public
       */
      add(job) {
        this.jobs.push(job);
        this[kRun]();
      }
      /**
       * Removes a job from the queue and runs it if possible.
       *
       * @private
       */
      [kRun]() {
        if (this.pending === this.concurrency) return;
        if (this.jobs.length) {
          const job = this.jobs.shift();
          this.pending++;
          job(this[kDone]);
        }
      }
    };
    module2.exports = Limiter;
  }
});

// MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/node_modules/ws/lib/permessage-deflate.js
var require_permessage_deflate = __commonJS({
  "MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/node_modules/ws/lib/permessage-deflate.js"(exports2, module2) {
    "use strict";
    var zlib = require("zlib");
    var bufferUtil = require_buffer_util();
    var Limiter = require_limiter();
    var { kStatusCode } = require_constants();
    var FastBuffer = Buffer[Symbol.species];
    var TRAILER = Buffer.from([0, 0, 255, 255]);
    var kPerMessageDeflate = /* @__PURE__ */ Symbol("permessage-deflate");
    var kTotalLength = /* @__PURE__ */ Symbol("total-length");
    var kCallback = /* @__PURE__ */ Symbol("callback");
    var kBuffers = /* @__PURE__ */ Symbol("buffers");
    var kError = /* @__PURE__ */ Symbol("error");
    var zlibLimiter;
    var PerMessageDeflate = class {
      /**
       * Creates a PerMessageDeflate instance.
       *
       * @param {Object} [options] Configuration options
       * @param {(Boolean|Number)} [options.clientMaxWindowBits] Advertise support
       *     for, or request, a custom client window size
       * @param {Boolean} [options.clientNoContextTakeover=false] Advertise/
       *     acknowledge disabling of client context takeover
       * @param {Number} [options.concurrencyLimit=10] The number of concurrent
       *     calls to zlib
       * @param {Boolean} [options.isServer=false] Create the instance in either
       *     server or client mode
       * @param {Number} [options.maxPayload=0] The maximum allowed message length
       * @param {(Boolean|Number)} [options.serverMaxWindowBits] Request/confirm the
       *     use of a custom server window size
       * @param {Boolean} [options.serverNoContextTakeover=false] Request/accept
       *     disabling of server context takeover
       * @param {Number} [options.threshold=1024] Size (in bytes) below which
       *     messages should not be compressed if context takeover is disabled
       * @param {Object} [options.zlibDeflateOptions] Options to pass to zlib on
       *     deflate
       * @param {Object} [options.zlibInflateOptions] Options to pass to zlib on
       *     inflate
       */
      constructor(options) {
        this._options = options || {};
        this._threshold = this._options.threshold !== void 0 ? this._options.threshold : 1024;
        this._maxPayload = this._options.maxPayload | 0;
        this._isServer = !!this._options.isServer;
        this._deflate = null;
        this._inflate = null;
        this.params = null;
        if (!zlibLimiter) {
          const concurrency = this._options.concurrencyLimit !== void 0 ? this._options.concurrencyLimit : 10;
          zlibLimiter = new Limiter(concurrency);
        }
      }
      /**
       * @type {String}
       */
      static get extensionName() {
        return "permessage-deflate";
      }
      /**
       * Create an extension negotiation offer.
       *
       * @return {Object} Extension parameters
       * @public
       */
      offer() {
        const params = {};
        if (this._options.serverNoContextTakeover) {
          params.server_no_context_takeover = true;
        }
        if (this._options.clientNoContextTakeover) {
          params.client_no_context_takeover = true;
        }
        if (this._options.serverMaxWindowBits) {
          params.server_max_window_bits = this._options.serverMaxWindowBits;
        }
        if (this._options.clientMaxWindowBits) {
          params.client_max_window_bits = this._options.clientMaxWindowBits;
        } else if (this._options.clientMaxWindowBits == null) {
          params.client_max_window_bits = true;
        }
        return params;
      }
      /**
       * Accept an extension negotiation offer/response.
       *
       * @param {Array} configurations The extension negotiation offers/reponse
       * @return {Object} Accepted configuration
       * @public
       */
      accept(configurations) {
        configurations = this.normalizeParams(configurations);
        this.params = this._isServer ? this.acceptAsServer(configurations) : this.acceptAsClient(configurations);
        return this.params;
      }
      /**
       * Releases all resources used by the extension.
       *
       * @public
       */
      cleanup() {
        if (this._inflate) {
          this._inflate.close();
          this._inflate = null;
        }
        if (this._deflate) {
          const callback = this._deflate[kCallback];
          this._deflate.close();
          this._deflate = null;
          if (callback) {
            callback(
              new Error(
                "The deflate stream was closed while data was being processed"
              )
            );
          }
        }
      }
      /**
       *  Accept an extension negotiation offer.
       *
       * @param {Array} offers The extension negotiation offers
       * @return {Object} Accepted configuration
       * @private
       */
      acceptAsServer(offers) {
        const opts = this._options;
        const accepted = offers.find((params) => {
          if (opts.serverNoContextTakeover === false && params.server_no_context_takeover || params.server_max_window_bits && (opts.serverMaxWindowBits === false || typeof opts.serverMaxWindowBits === "number" && opts.serverMaxWindowBits > params.server_max_window_bits) || typeof opts.clientMaxWindowBits === "number" && (typeof params.client_max_window_bits === "number" ? opts.clientMaxWindowBits > params.client_max_window_bits : !params.client_max_window_bits)) {
            return false;
          }
          return true;
        });
        if (!accepted) {
          throw new Error("None of the extension offers can be accepted");
        }
        if (opts.serverNoContextTakeover) {
          accepted.server_no_context_takeover = true;
        }
        if (opts.clientNoContextTakeover) {
          accepted.client_no_context_takeover = true;
        }
        if (typeof opts.serverMaxWindowBits === "number") {
          accepted.server_max_window_bits = opts.serverMaxWindowBits;
        }
        if (typeof opts.clientMaxWindowBits === "number") {
          accepted.client_max_window_bits = opts.clientMaxWindowBits;
        } else if (accepted.client_max_window_bits === true || opts.clientMaxWindowBits === false) {
          delete accepted.client_max_window_bits;
        }
        return accepted;
      }
      /**
       * Accept the extension negotiation response.
       *
       * @param {Array} response The extension negotiation response
       * @return {Object} Accepted configuration
       * @private
       */
      acceptAsClient(response) {
        const params = response[0];
        if (this._options.clientNoContextTakeover === false && params.client_no_context_takeover) {
          throw new Error('Unexpected parameter "client_no_context_takeover"');
        }
        if (!params.client_max_window_bits) {
          if (typeof this._options.clientMaxWindowBits === "number") {
            params.client_max_window_bits = this._options.clientMaxWindowBits;
          }
        } else if (this._options.clientMaxWindowBits === false || typeof this._options.clientMaxWindowBits === "number" && params.client_max_window_bits > this._options.clientMaxWindowBits) {
          throw new Error(
            'Unexpected or invalid parameter "client_max_window_bits"'
          );
        }
        return params;
      }
      /**
       * Normalize parameters.
       *
       * @param {Array} configurations The extension negotiation offers/reponse
       * @return {Array} The offers/response with normalized parameters
       * @private
       */
      normalizeParams(configurations) {
        configurations.forEach((params) => {
          Object.keys(params).forEach((key) => {
            let value = params[key];
            if (value.length > 1) {
              throw new Error(`Parameter "${key}" must have only a single value`);
            }
            value = value[0];
            if (key === "client_max_window_bits") {
              if (value !== true) {
                const num = +value;
                if (!Number.isInteger(num) || num < 8 || num > 15) {
                  throw new TypeError(
                    `Invalid value for parameter "${key}": ${value}`
                  );
                }
                value = num;
              } else if (!this._isServer) {
                throw new TypeError(
                  `Invalid value for parameter "${key}": ${value}`
                );
              }
            } else if (key === "server_max_window_bits") {
              const num = +value;
              if (!Number.isInteger(num) || num < 8 || num > 15) {
                throw new TypeError(
                  `Invalid value for parameter "${key}": ${value}`
                );
              }
              value = num;
            } else if (key === "client_no_context_takeover" || key === "server_no_context_takeover") {
              if (value !== true) {
                throw new TypeError(
                  `Invalid value for parameter "${key}": ${value}`
                );
              }
            } else {
              throw new Error(`Unknown parameter "${key}"`);
            }
            params[key] = value;
          });
        });
        return configurations;
      }
      /**
       * Decompress data. Concurrency limited.
       *
       * @param {Buffer} data Compressed data
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @public
       */
      decompress(data, fin, callback) {
        zlibLimiter.add((done) => {
          this._decompress(data, fin, (err, result) => {
            done();
            callback(err, result);
          });
        });
      }
      /**
       * Compress data. Concurrency limited.
       *
       * @param {(Buffer|String)} data Data to compress
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @public
       */
      compress(data, fin, callback) {
        zlibLimiter.add((done) => {
          this._compress(data, fin, (err, result) => {
            done();
            callback(err, result);
          });
        });
      }
      /**
       * Decompress data.
       *
       * @param {Buffer} data Compressed data
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @private
       */
      _decompress(data, fin, callback) {
        const endpoint = this._isServer ? "client" : "server";
        if (!this._inflate) {
          const key = `${endpoint}_max_window_bits`;
          const windowBits = typeof this.params[key] !== "number" ? zlib.Z_DEFAULT_WINDOWBITS : this.params[key];
          this._inflate = zlib.createInflateRaw({
            ...this._options.zlibInflateOptions,
            windowBits
          });
          this._inflate[kPerMessageDeflate] = this;
          this._inflate[kTotalLength] = 0;
          this._inflate[kBuffers] = [];
          this._inflate.on("error", inflateOnError);
          this._inflate.on("data", inflateOnData);
        }
        this._inflate[kCallback] = callback;
        this._inflate.write(data);
        if (fin) this._inflate.write(TRAILER);
        this._inflate.flush(() => {
          const err = this._inflate[kError];
          if (err) {
            this._inflate.close();
            this._inflate = null;
            callback(err);
            return;
          }
          const data2 = bufferUtil.concat(
            this._inflate[kBuffers],
            this._inflate[kTotalLength]
          );
          if (this._inflate._readableState.endEmitted) {
            this._inflate.close();
            this._inflate = null;
          } else {
            this._inflate[kTotalLength] = 0;
            this._inflate[kBuffers] = [];
            if (fin && this.params[`${endpoint}_no_context_takeover`]) {
              this._inflate.reset();
            }
          }
          callback(null, data2);
        });
      }
      /**
       * Compress data.
       *
       * @param {(Buffer|String)} data Data to compress
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @private
       */
      _compress(data, fin, callback) {
        const endpoint = this._isServer ? "server" : "client";
        if (!this._deflate) {
          const key = `${endpoint}_max_window_bits`;
          const windowBits = typeof this.params[key] !== "number" ? zlib.Z_DEFAULT_WINDOWBITS : this.params[key];
          this._deflate = zlib.createDeflateRaw({
            ...this._options.zlibDeflateOptions,
            windowBits
          });
          this._deflate[kTotalLength] = 0;
          this._deflate[kBuffers] = [];
          this._deflate.on("data", deflateOnData);
        }
        this._deflate[kCallback] = callback;
        this._deflate.write(data);
        this._deflate.flush(zlib.Z_SYNC_FLUSH, () => {
          if (!this._deflate) {
            return;
          }
          let data2 = bufferUtil.concat(
            this._deflate[kBuffers],
            this._deflate[kTotalLength]
          );
          if (fin) {
            data2 = new FastBuffer(data2.buffer, data2.byteOffset, data2.length - 4);
          }
          this._deflate[kCallback] = null;
          this._deflate[kTotalLength] = 0;
          this._deflate[kBuffers] = [];
          if (fin && this.params[`${endpoint}_no_context_takeover`]) {
            this._deflate.reset();
          }
          callback(null, data2);
        });
      }
    };
    module2.exports = PerMessageDeflate;
    function deflateOnData(chunk) {
      this[kBuffers].push(chunk);
      this[kTotalLength] += chunk.length;
    }
    function inflateOnData(chunk) {
      this[kTotalLength] += chunk.length;
      if (this[kPerMessageDeflate]._maxPayload < 1 || this[kTotalLength] <= this[kPerMessageDeflate]._maxPayload) {
        this[kBuffers].push(chunk);
        return;
      }
      this[kError] = new RangeError("Max payload size exceeded");
      this[kError].code = "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH";
      this[kError][kStatusCode] = 1009;
      this.removeListener("data", inflateOnData);
      this.reset();
    }
    function inflateOnError(err) {
      this[kPerMessageDeflate]._inflate = null;
      if (this[kError]) {
        this[kCallback](this[kError]);
        return;
      }
      err[kStatusCode] = 1007;
      this[kCallback](err);
    }
  }
});

// MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/node_modules/ws/lib/validation.js
var require_validation = __commonJS({
  "MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/node_modules/ws/lib/validation.js"(exports2, module2) {
    "use strict";
    var { isUtf8 } = require("buffer");
    var { hasBlob } = require_constants();
    var tokenChars = [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      // 0 - 15
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      // 16 - 31
      0,
      1,
      0,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      1,
      1,
      0,
      1,
      1,
      0,
      // 32 - 47
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      // 48 - 63
      0,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      // 64 - 79
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      0,
      1,
      1,
      // 80 - 95
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      // 96 - 111
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      1,
      0,
      1,
      0
      // 112 - 127
    ];
    function isValidStatusCode(code) {
      return code >= 1e3 && code <= 1014 && code !== 1004 && code !== 1005 && code !== 1006 || code >= 3e3 && code <= 4999;
    }
    function _isValidUTF8(buf) {
      const len = buf.length;
      let i = 0;
      while (i < len) {
        if ((buf[i] & 128) === 0) {
          i++;
        } else if ((buf[i] & 224) === 192) {
          if (i + 1 === len || (buf[i + 1] & 192) !== 128 || (buf[i] & 254) === 192) {
            return false;
          }
          i += 2;
        } else if ((buf[i] & 240) === 224) {
          if (i + 2 >= len || (buf[i + 1] & 192) !== 128 || (buf[i + 2] & 192) !== 128 || buf[i] === 224 && (buf[i + 1] & 224) === 128 || // Overlong
          buf[i] === 237 && (buf[i + 1] & 224) === 160) {
            return false;
          }
          i += 3;
        } else if ((buf[i] & 248) === 240) {
          if (i + 3 >= len || (buf[i + 1] & 192) !== 128 || (buf[i + 2] & 192) !== 128 || (buf[i + 3] & 192) !== 128 || buf[i] === 240 && (buf[i + 1] & 240) === 128 || // Overlong
          buf[i] === 244 && buf[i + 1] > 143 || buf[i] > 244) {
            return false;
          }
          i += 4;
        } else {
          return false;
        }
      }
      return true;
    }
    function isBlob(value) {
      return hasBlob && typeof value === "object" && typeof value.arrayBuffer === "function" && typeof value.type === "string" && typeof value.stream === "function" && (value[Symbol.toStringTag] === "Blob" || value[Symbol.toStringTag] === "File");
    }
    module2.exports = {
      isBlob,
      isValidStatusCode,
      isValidUTF8: _isValidUTF8,
      tokenChars
    };
    if (isUtf8) {
      module2.exports.isValidUTF8 = function(buf) {
        return buf.length < 24 ? _isValidUTF8(buf) : isUtf8(buf);
      };
    } else if (!process.env.WS_NO_UTF_8_VALIDATE) {
      try {
        const isValidUTF8 = require("utf-8-validate");
        module2.exports.isValidUTF8 = function(buf) {
          return buf.length < 32 ? _isValidUTF8(buf) : isValidUTF8(buf);
        };
      } catch (e) {
      }
    }
  }
});

// MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/node_modules/ws/lib/receiver.js
var require_receiver = __commonJS({
  "MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/node_modules/ws/lib/receiver.js"(exports2, module2) {
    "use strict";
    var { Writable } = require("stream");
    var PerMessageDeflate = require_permessage_deflate();
    var {
      BINARY_TYPES,
      EMPTY_BUFFER,
      kStatusCode,
      kWebSocket
    } = require_constants();
    var { concat, toArrayBuffer, unmask } = require_buffer_util();
    var { isValidStatusCode, isValidUTF8 } = require_validation();
    var FastBuffer = Buffer[Symbol.species];
    var GET_INFO = 0;
    var GET_PAYLOAD_LENGTH_16 = 1;
    var GET_PAYLOAD_LENGTH_64 = 2;
    var GET_MASK = 3;
    var GET_DATA = 4;
    var INFLATING = 5;
    var DEFER_EVENT = 6;
    var Receiver = class extends Writable {
      /**
       * Creates a Receiver instance.
       *
       * @param {Object} [options] Options object
       * @param {Boolean} [options.allowSynchronousEvents=true] Specifies whether
       *     any of the `'message'`, `'ping'`, and `'pong'` events can be emitted
       *     multiple times in the same tick
       * @param {String} [options.binaryType=nodebuffer] The type for binary data
       * @param {Object} [options.extensions] An object containing the negotiated
       *     extensions
       * @param {Boolean} [options.isServer=false] Specifies whether to operate in
       *     client or server mode
       * @param {Number} [options.maxBufferedChunks=0] The maximum number of
       *     buffered data chunks
       * @param {Number} [options.maxFragments=0] The maximum number of message
       *     fragments
       * @param {Number} [options.maxPayload=0] The maximum allowed message length
       * @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
       *     not to skip UTF-8 validation for text and close messages
       */
      constructor(options = {}) {
        super();
        this._allowSynchronousEvents = options.allowSynchronousEvents !== void 0 ? options.allowSynchronousEvents : true;
        this._binaryType = options.binaryType || BINARY_TYPES[0];
        this._extensions = options.extensions || {};
        this._isServer = !!options.isServer;
        this._maxBufferedChunks = options.maxBufferedChunks | 0;
        this._maxFragments = options.maxFragments | 0;
        this._maxPayload = options.maxPayload | 0;
        this._skipUTF8Validation = !!options.skipUTF8Validation;
        this[kWebSocket] = void 0;
        this._bufferedBytes = 0;
        this._buffers = [];
        this._compressed = false;
        this._payloadLength = 0;
        this._mask = void 0;
        this._fragmented = 0;
        this._masked = false;
        this._fin = false;
        this._opcode = 0;
        this._totalPayloadLength = 0;
        this._messageLength = 0;
        this._numFragments = 0;
        this._fragments = [];
        this._errored = false;
        this._loop = false;
        this._state = GET_INFO;
      }
      /**
       * Implements `Writable.prototype._write()`.
       *
       * @param {Buffer} chunk The chunk of data to write
       * @param {String} encoding The character encoding of `chunk`
       * @param {Function} cb Callback
       * @private
       */
      _write(chunk, encoding, cb) {
        if (this._opcode === 8 && this._state == GET_INFO) return cb();
        if (this._maxBufferedChunks > 0 && this._buffers.length >= this._maxBufferedChunks) {
          cb(
            this.createError(
              RangeError,
              "Too many buffered chunks",
              false,
              1008,
              "WS_ERR_TOO_MANY_BUFFERED_PARTS"
            )
          );
          return;
        }
        this._bufferedBytes += chunk.length;
        this._buffers.push(chunk);
        this.startLoop(cb);
      }
      /**
       * Consumes `n` bytes from the buffered data.
       *
       * @param {Number} n The number of bytes to consume
       * @return {Buffer} The consumed bytes
       * @private
       */
      consume(n) {
        this._bufferedBytes -= n;
        if (n === this._buffers[0].length) return this._buffers.shift();
        if (n < this._buffers[0].length) {
          const buf = this._buffers[0];
          this._buffers[0] = new FastBuffer(
            buf.buffer,
            buf.byteOffset + n,
            buf.length - n
          );
          return new FastBuffer(buf.buffer, buf.byteOffset, n);
        }
        const dst = Buffer.allocUnsafe(n);
        do {
          const buf = this._buffers[0];
          const offset = dst.length - n;
          if (n >= buf.length) {
            dst.set(this._buffers.shift(), offset);
          } else {
            dst.set(new Uint8Array(buf.buffer, buf.byteOffset, n), offset);
            this._buffers[0] = new FastBuffer(
              buf.buffer,
              buf.byteOffset + n,
              buf.length - n
            );
          }
          n -= buf.length;
        } while (n > 0);
        return dst;
      }
      /**
       * Starts the parsing loop.
       *
       * @param {Function} cb Callback
       * @private
       */
      startLoop(cb) {
        this._loop = true;
        do {
          switch (this._state) {
            case GET_INFO:
              this.getInfo(cb);
              break;
            case GET_PAYLOAD_LENGTH_16:
              this.getPayloadLength16(cb);
              break;
            case GET_PAYLOAD_LENGTH_64:
              this.getPayloadLength64(cb);
              break;
            case GET_MASK:
              this.getMask();
              break;
            case GET_DATA:
              this.getData(cb);
              break;
            case INFLATING:
            case DEFER_EVENT:
              this._loop = false;
              return;
          }
        } while (this._loop);
        if (!this._errored) cb();
      }
      /**
       * Reads the first two bytes of a frame.
       *
       * @param {Function} cb Callback
       * @private
       */
      getInfo(cb) {
        if (this._bufferedBytes < 2) {
          this._loop = false;
          return;
        }
        const buf = this.consume(2);
        if ((buf[0] & 48) !== 0) {
          const error = this.createError(
            RangeError,
            "RSV2 and RSV3 must be clear",
            true,
            1002,
            "WS_ERR_UNEXPECTED_RSV_2_3"
          );
          cb(error);
          return;
        }
        const compressed = (buf[0] & 64) === 64;
        if (compressed && !this._extensions[PerMessageDeflate.extensionName]) {
          const error = this.createError(
            RangeError,
            "RSV1 must be clear",
            true,
            1002,
            "WS_ERR_UNEXPECTED_RSV_1"
          );
          cb(error);
          return;
        }
        this._fin = (buf[0] & 128) === 128;
        this._opcode = buf[0] & 15;
        this._payloadLength = buf[1] & 127;
        if (this._opcode === 0) {
          if (compressed) {
            const error = this.createError(
              RangeError,
              "RSV1 must be clear",
              true,
              1002,
              "WS_ERR_UNEXPECTED_RSV_1"
            );
            cb(error);
            return;
          }
          if (!this._fragmented) {
            const error = this.createError(
              RangeError,
              "invalid opcode 0",
              true,
              1002,
              "WS_ERR_INVALID_OPCODE"
            );
            cb(error);
            return;
          }
          this._opcode = this._fragmented;
        } else if (this._opcode === 1 || this._opcode === 2) {
          if (this._fragmented) {
            const error = this.createError(
              RangeError,
              `invalid opcode ${this._opcode}`,
              true,
              1002,
              "WS_ERR_INVALID_OPCODE"
            );
            cb(error);
            return;
          }
          this._compressed = compressed;
        } else if (this._opcode > 7 && this._opcode < 11) {
          if (!this._fin) {
            const error = this.createError(
              RangeError,
              "FIN must be set",
              true,
              1002,
              "WS_ERR_EXPECTED_FIN"
            );
            cb(error);
            return;
          }
          if (compressed) {
            const error = this.createError(
              RangeError,
              "RSV1 must be clear",
              true,
              1002,
              "WS_ERR_UNEXPECTED_RSV_1"
            );
            cb(error);
            return;
          }
          if (this._payloadLength > 125 || this._opcode === 8 && this._payloadLength === 1) {
            const error = this.createError(
              RangeError,
              `invalid payload length ${this._payloadLength}`,
              true,
              1002,
              "WS_ERR_INVALID_CONTROL_PAYLOAD_LENGTH"
            );
            cb(error);
            return;
          }
        } else {
          const error = this.createError(
            RangeError,
            `invalid opcode ${this._opcode}`,
            true,
            1002,
            "WS_ERR_INVALID_OPCODE"
          );
          cb(error);
          return;
        }
        if (!this._fin && !this._fragmented) this._fragmented = this._opcode;
        this._masked = (buf[1] & 128) === 128;
        if (this._isServer) {
          if (!this._masked) {
            const error = this.createError(
              RangeError,
              "MASK must be set",
              true,
              1002,
              "WS_ERR_EXPECTED_MASK"
            );
            cb(error);
            return;
          }
        } else if (this._masked) {
          const error = this.createError(
            RangeError,
            "MASK must be clear",
            true,
            1002,
            "WS_ERR_UNEXPECTED_MASK"
          );
          cb(error);
          return;
        }
        if (this._payloadLength === 126) this._state = GET_PAYLOAD_LENGTH_16;
        else if (this._payloadLength === 127) this._state = GET_PAYLOAD_LENGTH_64;
        else this.haveLength(cb);
      }
      /**
       * Gets extended payload length (7+16).
       *
       * @param {Function} cb Callback
       * @private
       */
      getPayloadLength16(cb) {
        if (this._bufferedBytes < 2) {
          this._loop = false;
          return;
        }
        this._payloadLength = this.consume(2).readUInt16BE(0);
        this.haveLength(cb);
      }
      /**
       * Gets extended payload length (7+64).
       *
       * @param {Function} cb Callback
       * @private
       */
      getPayloadLength64(cb) {
        if (this._bufferedBytes < 8) {
          this._loop = false;
          return;
        }
        const buf = this.consume(8);
        const num = buf.readUInt32BE(0);
        if (num > Math.pow(2, 53 - 32) - 1) {
          const error = this.createError(
            RangeError,
            "Unsupported WebSocket frame: payload length > 2^53 - 1",
            false,
            1009,
            "WS_ERR_UNSUPPORTED_DATA_PAYLOAD_LENGTH"
          );
          cb(error);
          return;
        }
        this._payloadLength = num * Math.pow(2, 32) + buf.readUInt32BE(4);
        this.haveLength(cb);
      }
      /**
       * Payload length has been read.
       *
       * @param {Function} cb Callback
       * @private
       */
      haveLength(cb) {
        if (this._payloadLength && this._opcode < 8) {
          this._totalPayloadLength += this._payloadLength;
          if (this._totalPayloadLength > this._maxPayload && this._maxPayload > 0) {
            const error = this.createError(
              RangeError,
              "Max payload size exceeded",
              false,
              1009,
              "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH"
            );
            cb(error);
            return;
          }
        }
        if (this._masked) this._state = GET_MASK;
        else this._state = GET_DATA;
      }
      /**
       * Reads mask bytes.
       *
       * @private
       */
      getMask() {
        if (this._bufferedBytes < 4) {
          this._loop = false;
          return;
        }
        this._mask = this.consume(4);
        this._state = GET_DATA;
      }
      /**
       * Reads data bytes.
       *
       * @param {Function} cb Callback
       * @private
       */
      getData(cb) {
        let data = EMPTY_BUFFER;
        if (this._payloadLength) {
          if (this._bufferedBytes < this._payloadLength) {
            this._loop = false;
            return;
          }
          data = this.consume(this._payloadLength);
          if (this._masked && (this._mask[0] | this._mask[1] | this._mask[2] | this._mask[3]) !== 0) {
            unmask(data, this._mask);
          }
        }
        if (this._opcode > 7) {
          this.controlMessage(data, cb);
          return;
        }
        if (this._maxFragments > 0 && ++this._numFragments > this._maxFragments) {
          const error = this.createError(
            RangeError,
            "Too many message fragments",
            false,
            1008,
            "WS_ERR_TOO_MANY_BUFFERED_PARTS"
          );
          cb(error);
          return;
        }
        if (this._compressed) {
          this._state = INFLATING;
          this.decompress(data, cb);
          return;
        }
        if (data.length) {
          this._messageLength = this._totalPayloadLength;
          this._fragments.push(data);
        }
        this.dataMessage(cb);
      }
      /**
       * Decompresses data.
       *
       * @param {Buffer} data Compressed data
       * @param {Function} cb Callback
       * @private
       */
      decompress(data, cb) {
        const perMessageDeflate = this._extensions[PerMessageDeflate.extensionName];
        perMessageDeflate.decompress(data, this._fin, (err, buf) => {
          if (err) return cb(err);
          if (buf.length) {
            this._messageLength += buf.length;
            if (this._messageLength > this._maxPayload && this._maxPayload > 0) {
              const error = this.createError(
                RangeError,
                "Max payload size exceeded",
                false,
                1009,
                "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH"
              );
              cb(error);
              return;
            }
            this._fragments.push(buf);
          }
          this.dataMessage(cb);
          if (this._state === GET_INFO) this.startLoop(cb);
        });
      }
      /**
       * Handles a data message.
       *
       * @param {Function} cb Callback
       * @private
       */
      dataMessage(cb) {
        if (!this._fin) {
          this._state = GET_INFO;
          return;
        }
        const messageLength = this._messageLength;
        const fragments = this._fragments;
        this._totalPayloadLength = 0;
        this._messageLength = 0;
        this._fragmented = 0;
        this._numFragments = 0;
        this._fragments = [];
        if (this._opcode === 2) {
          let data;
          if (this._binaryType === "nodebuffer") {
            data = concat(fragments, messageLength);
          } else if (this._binaryType === "arraybuffer") {
            data = toArrayBuffer(concat(fragments, messageLength));
          } else if (this._binaryType === "blob") {
            data = new Blob(fragments);
          } else {
            data = fragments;
          }
          if (this._allowSynchronousEvents) {
            this.emit("message", data, true);
            this._state = GET_INFO;
          } else {
            this._state = DEFER_EVENT;
            setImmediate(() => {
              this.emit("message", data, true);
              this._state = GET_INFO;
              this.startLoop(cb);
            });
          }
        } else {
          const buf = concat(fragments, messageLength);
          if (!this._skipUTF8Validation && !isValidUTF8(buf)) {
            const error = this.createError(
              Error,
              "invalid UTF-8 sequence",
              true,
              1007,
              "WS_ERR_INVALID_UTF8"
            );
            cb(error);
            return;
          }
          if (this._state === INFLATING || this._allowSynchronousEvents) {
            this.emit("message", buf, false);
            this._state = GET_INFO;
          } else {
            this._state = DEFER_EVENT;
            setImmediate(() => {
              this.emit("message", buf, false);
              this._state = GET_INFO;
              this.startLoop(cb);
            });
          }
        }
      }
      /**
       * Handles a control message.
       *
       * @param {Buffer} data Data to handle
       * @return {(Error|RangeError|undefined)} A possible error
       * @private
       */
      controlMessage(data, cb) {
        if (this._opcode === 8) {
          if (data.length === 0) {
            this._loop = false;
            this.emit("conclude", 1005, EMPTY_BUFFER);
            this.end();
          } else {
            const code = data.readUInt16BE(0);
            if (!isValidStatusCode(code)) {
              const error = this.createError(
                RangeError,
                `invalid status code ${code}`,
                true,
                1002,
                "WS_ERR_INVALID_CLOSE_CODE"
              );
              cb(error);
              return;
            }
            const buf = new FastBuffer(
              data.buffer,
              data.byteOffset + 2,
              data.length - 2
            );
            if (!this._skipUTF8Validation && !isValidUTF8(buf)) {
              const error = this.createError(
                Error,
                "invalid UTF-8 sequence",
                true,
                1007,
                "WS_ERR_INVALID_UTF8"
              );
              cb(error);
              return;
            }
            this._loop = false;
            this.emit("conclude", code, buf);
            this.end();
          }
          this._state = GET_INFO;
          return;
        }
        if (this._allowSynchronousEvents) {
          this.emit(this._opcode === 9 ? "ping" : "pong", data);
          this._state = GET_INFO;
        } else {
          this._state = DEFER_EVENT;
          setImmediate(() => {
            this.emit(this._opcode === 9 ? "ping" : "pong", data);
            this._state = GET_INFO;
            this.startLoop(cb);
          });
        }
      }
      /**
       * Builds an error object.
       *
       * @param {function(new:Error|RangeError)} ErrorCtor The error constructor
       * @param {String} message The error message
       * @param {Boolean} prefix Specifies whether or not to add a default prefix to
       *     `message`
       * @param {Number} statusCode The status code
       * @param {String} errorCode The exposed error code
       * @return {(Error|RangeError)} The error
       * @private
       */
      createError(ErrorCtor, message, prefix, statusCode, errorCode) {
        this._loop = false;
        this._errored = true;
        const err = new ErrorCtor(
          prefix ? `Invalid WebSocket frame: ${message}` : message
        );
        Error.captureStackTrace(err, this.createError);
        err.code = errorCode;
        err[kStatusCode] = statusCode;
        return err;
      }
    };
    module2.exports = Receiver;
  }
});

// MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/node_modules/ws/lib/sender.js
var require_sender = __commonJS({
  "MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/node_modules/ws/lib/sender.js"(exports2, module2) {
    "use strict";
    var { Duplex } = require("stream");
    var { randomFillSync } = require("crypto");
    var {
      types: { isUint8Array }
    } = require("util");
    var PerMessageDeflate = require_permessage_deflate();
    var { EMPTY_BUFFER, kWebSocket, NOOP } = require_constants();
    var { isBlob, isValidStatusCode } = require_validation();
    var { mask: applyMask, toBuffer } = require_buffer_util();
    var kByteLength = /* @__PURE__ */ Symbol("kByteLength");
    var maskBuffer = Buffer.alloc(4);
    var RANDOM_POOL_SIZE = 8 * 1024;
    var randomPool;
    var randomPoolPointer = RANDOM_POOL_SIZE;
    var DEFAULT = 0;
    var DEFLATING = 1;
    var GET_BLOB_DATA = 2;
    var Sender = class _Sender {
      /**
       * Creates a Sender instance.
       *
       * @param {Duplex} socket The connection socket
       * @param {Object} [extensions] An object containing the negotiated extensions
       * @param {Function} [generateMask] The function used to generate the masking
       *     key
       */
      constructor(socket, extensions, generateMask) {
        this._extensions = extensions || {};
        if (generateMask) {
          this._generateMask = generateMask;
          this._maskBuffer = Buffer.alloc(4);
        }
        this._socket = socket;
        this._firstFragment = true;
        this._compress = false;
        this._bufferedBytes = 0;
        this._queue = [];
        this._state = DEFAULT;
        this.onerror = NOOP;
        this[kWebSocket] = void 0;
      }
      /**
       * Frames a piece of data according to the HyBi WebSocket protocol.
       *
       * @param {(Buffer|String)} data The data to frame
       * @param {Object} options Options object
       * @param {Boolean} [options.fin=false] Specifies whether or not to set the
       *     FIN bit
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Buffer} [options.maskBuffer] The buffer used to store the masking
       *     key
       * @param {Number} options.opcode The opcode
       * @param {Boolean} [options.readOnly=false] Specifies whether `data` can be
       *     modified
       * @param {Boolean} [options.rsv1=false] Specifies whether or not to set the
       *     RSV1 bit
       * @return {(Buffer|String)[]} The framed data
       * @public
       */
      static frame(data, options) {
        let mask;
        let merge = false;
        let offset = 2;
        let skipMasking = false;
        if (options.mask) {
          mask = options.maskBuffer || maskBuffer;
          if (options.generateMask) {
            options.generateMask(mask);
          } else {
            if (randomPoolPointer === RANDOM_POOL_SIZE) {
              if (randomPool === void 0) {
                randomPool = Buffer.alloc(RANDOM_POOL_SIZE);
              }
              randomFillSync(randomPool, 0, RANDOM_POOL_SIZE);
              randomPoolPointer = 0;
            }
            mask[0] = randomPool[randomPoolPointer++];
            mask[1] = randomPool[randomPoolPointer++];
            mask[2] = randomPool[randomPoolPointer++];
            mask[3] = randomPool[randomPoolPointer++];
          }
          skipMasking = (mask[0] | mask[1] | mask[2] | mask[3]) === 0;
          offset = 6;
        }
        let dataLength;
        if (typeof data === "string") {
          if ((!options.mask || skipMasking) && options[kByteLength] !== void 0) {
            dataLength = options[kByteLength];
          } else {
            data = Buffer.from(data);
            dataLength = data.length;
          }
        } else {
          dataLength = data.length;
          merge = options.mask && options.readOnly && !skipMasking;
        }
        let payloadLength = dataLength;
        if (dataLength >= 65536) {
          offset += 8;
          payloadLength = 127;
        } else if (dataLength > 125) {
          offset += 2;
          payloadLength = 126;
        }
        const target = Buffer.allocUnsafe(merge ? dataLength + offset : offset);
        target[0] = options.fin ? options.opcode | 128 : options.opcode;
        if (options.rsv1) target[0] |= 64;
        target[1] = payloadLength;
        if (payloadLength === 126) {
          target.writeUInt16BE(dataLength, 2);
        } else if (payloadLength === 127) {
          target[2] = target[3] = 0;
          target.writeUIntBE(dataLength, 4, 6);
        }
        if (!options.mask) return [target, data];
        target[1] |= 128;
        target[offset - 4] = mask[0];
        target[offset - 3] = mask[1];
        target[offset - 2] = mask[2];
        target[offset - 1] = mask[3];
        if (skipMasking) return [target, data];
        if (merge) {
          applyMask(data, mask, target, offset, dataLength);
          return [target];
        }
        applyMask(data, mask, data, 0, dataLength);
        return [target, data];
      }
      /**
       * Sends a close message to the other peer.
       *
       * @param {Number} [code] The status code component of the body
       * @param {(String|Buffer)} [data] The message component of the body
       * @param {Boolean} [mask=false] Specifies whether or not to mask the message
       * @param {Function} [cb] Callback
       * @public
       */
      close(code, data, mask, cb) {
        let buf;
        if (code === void 0) {
          buf = EMPTY_BUFFER;
        } else if (typeof code !== "number" || !isValidStatusCode(code)) {
          throw new TypeError("First argument must be a valid error code number");
        } else if (data === void 0 || !data.length) {
          buf = Buffer.allocUnsafe(2);
          buf.writeUInt16BE(code, 0);
        } else {
          const length = Buffer.byteLength(data);
          if (length > 123) {
            throw new RangeError("The message must not be greater than 123 bytes");
          }
          buf = Buffer.allocUnsafe(2 + length);
          buf.writeUInt16BE(code, 0);
          if (typeof data === "string") {
            buf.write(data, 2);
          } else if (isUint8Array(data)) {
            buf.set(data, 2);
          } else {
            throw new TypeError("Second argument must be a string or a Uint8Array");
          }
        }
        const options = {
          [kByteLength]: buf.length,
          fin: true,
          generateMask: this._generateMask,
          mask,
          maskBuffer: this._maskBuffer,
          opcode: 8,
          readOnly: false,
          rsv1: false
        };
        if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, buf, false, options, cb]);
        } else {
          this.sendFrame(_Sender.frame(buf, options), cb);
        }
      }
      /**
       * Sends a ping message to the other peer.
       *
       * @param {*} data The message to send
       * @param {Boolean} [mask=false] Specifies whether or not to mask `data`
       * @param {Function} [cb] Callback
       * @public
       */
      ping(data, mask, cb) {
        let byteLength;
        let readOnly;
        if (typeof data === "string") {
          byteLength = Buffer.byteLength(data);
          readOnly = false;
        } else if (isBlob(data)) {
          byteLength = data.size;
          readOnly = false;
        } else {
          data = toBuffer(data);
          byteLength = data.length;
          readOnly = toBuffer.readOnly;
        }
        if (byteLength > 125) {
          throw new RangeError("The data size must not be greater than 125 bytes");
        }
        const options = {
          [kByteLength]: byteLength,
          fin: true,
          generateMask: this._generateMask,
          mask,
          maskBuffer: this._maskBuffer,
          opcode: 9,
          readOnly,
          rsv1: false
        };
        if (isBlob(data)) {
          if (this._state !== DEFAULT) {
            this.enqueue([this.getBlobData, data, false, options, cb]);
          } else {
            this.getBlobData(data, false, options, cb);
          }
        } else if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, data, false, options, cb]);
        } else {
          this.sendFrame(_Sender.frame(data, options), cb);
        }
      }
      /**
       * Sends a pong message to the other peer.
       *
       * @param {*} data The message to send
       * @param {Boolean} [mask=false] Specifies whether or not to mask `data`
       * @param {Function} [cb] Callback
       * @public
       */
      pong(data, mask, cb) {
        let byteLength;
        let readOnly;
        if (typeof data === "string") {
          byteLength = Buffer.byteLength(data);
          readOnly = false;
        } else if (isBlob(data)) {
          byteLength = data.size;
          readOnly = false;
        } else {
          data = toBuffer(data);
          byteLength = data.length;
          readOnly = toBuffer.readOnly;
        }
        if (byteLength > 125) {
          throw new RangeError("The data size must not be greater than 125 bytes");
        }
        const options = {
          [kByteLength]: byteLength,
          fin: true,
          generateMask: this._generateMask,
          mask,
          maskBuffer: this._maskBuffer,
          opcode: 10,
          readOnly,
          rsv1: false
        };
        if (isBlob(data)) {
          if (this._state !== DEFAULT) {
            this.enqueue([this.getBlobData, data, false, options, cb]);
          } else {
            this.getBlobData(data, false, options, cb);
          }
        } else if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, data, false, options, cb]);
        } else {
          this.sendFrame(_Sender.frame(data, options), cb);
        }
      }
      /**
       * Sends a data message to the other peer.
       *
       * @param {*} data The message to send
       * @param {Object} options Options object
       * @param {Boolean} [options.binary=false] Specifies whether `data` is binary
       *     or text
       * @param {Boolean} [options.compress=false] Specifies whether or not to
       *     compress `data`
       * @param {Boolean} [options.fin=false] Specifies whether the fragment is the
       *     last one
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Function} [cb] Callback
       * @public
       */
      send(data, options, cb) {
        const perMessageDeflate = this._extensions[PerMessageDeflate.extensionName];
        let opcode = options.binary ? 2 : 1;
        let rsv1 = options.compress;
        let byteLength;
        let readOnly;
        if (typeof data === "string") {
          byteLength = Buffer.byteLength(data);
          readOnly = false;
        } else if (isBlob(data)) {
          byteLength = data.size;
          readOnly = false;
        } else {
          data = toBuffer(data);
          byteLength = data.length;
          readOnly = toBuffer.readOnly;
        }
        if (this._firstFragment) {
          this._firstFragment = false;
          if (rsv1 && perMessageDeflate && perMessageDeflate.params[perMessageDeflate._isServer ? "server_no_context_takeover" : "client_no_context_takeover"]) {
            rsv1 = byteLength >= perMessageDeflate._threshold;
          }
          this._compress = rsv1;
        } else {
          rsv1 = false;
          opcode = 0;
        }
        if (options.fin) this._firstFragment = true;
        const opts = {
          [kByteLength]: byteLength,
          fin: options.fin,
          generateMask: this._generateMask,
          mask: options.mask,
          maskBuffer: this._maskBuffer,
          opcode,
          readOnly,
          rsv1
        };
        if (isBlob(data)) {
          if (this._state !== DEFAULT) {
            this.enqueue([this.getBlobData, data, this._compress, opts, cb]);
          } else {
            this.getBlobData(data, this._compress, opts, cb);
          }
        } else if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, data, this._compress, opts, cb]);
        } else {
          this.dispatch(data, this._compress, opts, cb);
        }
      }
      /**
       * Gets the contents of a blob as binary data.
       *
       * @param {Blob} blob The blob
       * @param {Boolean} [compress=false] Specifies whether or not to compress
       *     the data
       * @param {Object} options Options object
       * @param {Boolean} [options.fin=false] Specifies whether or not to set the
       *     FIN bit
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Buffer} [options.maskBuffer] The buffer used to store the masking
       *     key
       * @param {Number} options.opcode The opcode
       * @param {Boolean} [options.readOnly=false] Specifies whether `data` can be
       *     modified
       * @param {Boolean} [options.rsv1=false] Specifies whether or not to set the
       *     RSV1 bit
       * @param {Function} [cb] Callback
       * @private
       */
      getBlobData(blob, compress, options, cb) {
        this._bufferedBytes += options[kByteLength];
        this._state = GET_BLOB_DATA;
        blob.arrayBuffer().then((arrayBuffer) => {
          if (this._socket.destroyed) {
            const err = new Error(
              "The socket was closed while the blob was being read"
            );
            process.nextTick(callCallbacks, this, err, cb);
            return;
          }
          this._bufferedBytes -= options[kByteLength];
          const data = toBuffer(arrayBuffer);
          if (!compress) {
            this._state = DEFAULT;
            this.sendFrame(_Sender.frame(data, options), cb);
            this.dequeue();
          } else {
            this.dispatch(data, compress, options, cb);
          }
        }).catch((err) => {
          process.nextTick(onError, this, err, cb);
        });
      }
      /**
       * Dispatches a message.
       *
       * @param {(Buffer|String)} data The message to send
       * @param {Boolean} [compress=false] Specifies whether or not to compress
       *     `data`
       * @param {Object} options Options object
       * @param {Boolean} [options.fin=false] Specifies whether or not to set the
       *     FIN bit
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Buffer} [options.maskBuffer] The buffer used to store the masking
       *     key
       * @param {Number} options.opcode The opcode
       * @param {Boolean} [options.readOnly=false] Specifies whether `data` can be
       *     modified
       * @param {Boolean} [options.rsv1=false] Specifies whether or not to set the
       *     RSV1 bit
       * @param {Function} [cb] Callback
       * @private
       */
      dispatch(data, compress, options, cb) {
        if (!compress) {
          this.sendFrame(_Sender.frame(data, options), cb);
          return;
        }
        const perMessageDeflate = this._extensions[PerMessageDeflate.extensionName];
        this._bufferedBytes += options[kByteLength];
        this._state = DEFLATING;
        perMessageDeflate.compress(data, options.fin, (_, buf) => {
          if (this._socket.destroyed) {
            const err = new Error(
              "The socket was closed while data was being compressed"
            );
            callCallbacks(this, err, cb);
            return;
          }
          this._bufferedBytes -= options[kByteLength];
          this._state = DEFAULT;
          options.readOnly = false;
          this.sendFrame(_Sender.frame(buf, options), cb);
          this.dequeue();
        });
      }
      /**
       * Executes queued send operations.
       *
       * @private
       */
      dequeue() {
        while (this._state === DEFAULT && this._queue.length) {
          const params = this._queue.shift();
          this._bufferedBytes -= params[3][kByteLength];
          Reflect.apply(params[0], this, params.slice(1));
        }
      }
      /**
       * Enqueues a send operation.
       *
       * @param {Array} params Send operation parameters.
       * @private
       */
      enqueue(params) {
        this._bufferedBytes += params[3][kByteLength];
        this._queue.push(params);
      }
      /**
       * Sends a frame.
       *
       * @param {(Buffer | String)[]} list The frame to send
       * @param {Function} [cb] Callback
       * @private
       */
      sendFrame(list, cb) {
        if (list.length === 2) {
          this._socket.cork();
          this._socket.write(list[0]);
          this._socket.write(list[1], cb);
          this._socket.uncork();
        } else {
          this._socket.write(list[0], cb);
        }
      }
    };
    module2.exports = Sender;
    function callCallbacks(sender, err, cb) {
      if (typeof cb === "function") cb(err);
      for (let i = 0; i < sender._queue.length; i++) {
        const params = sender._queue[i];
        const callback = params[params.length - 1];
        if (typeof callback === "function") callback(err);
      }
    }
    function onError(sender, err, cb) {
      callCallbacks(sender, err, cb);
      sender.onerror(err);
    }
  }
});

// MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/node_modules/ws/lib/event-target.js
var require_event_target = __commonJS({
  "MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/node_modules/ws/lib/event-target.js"(exports2, module2) {
    "use strict";
    var { kForOnEventAttribute, kListener } = require_constants();
    var kCode = /* @__PURE__ */ Symbol("kCode");
    var kData = /* @__PURE__ */ Symbol("kData");
    var kError = /* @__PURE__ */ Symbol("kError");
    var kMessage = /* @__PURE__ */ Symbol("kMessage");
    var kReason = /* @__PURE__ */ Symbol("kReason");
    var kTarget = /* @__PURE__ */ Symbol("kTarget");
    var kType = /* @__PURE__ */ Symbol("kType");
    var kWasClean = /* @__PURE__ */ Symbol("kWasClean");
    var Event = class {
      /**
       * Create a new `Event`.
       *
       * @param {String} type The name of the event
       * @throws {TypeError} If the `type` argument is not specified
       */
      constructor(type) {
        this[kTarget] = null;
        this[kType] = type;
      }
      /**
       * @type {*}
       */
      get target() {
        return this[kTarget];
      }
      /**
       * @type {String}
       */
      get type() {
        return this[kType];
      }
    };
    Object.defineProperty(Event.prototype, "target", { enumerable: true });
    Object.defineProperty(Event.prototype, "type", { enumerable: true });
    var CloseEvent = class extends Event {
      /**
       * Create a new `CloseEvent`.
       *
       * @param {String} type The name of the event
       * @param {Object} [options] A dictionary object that allows for setting
       *     attributes via object members of the same name
       * @param {Number} [options.code=0] The status code explaining why the
       *     connection was closed
       * @param {String} [options.reason=''] A human-readable string explaining why
       *     the connection was closed
       * @param {Boolean} [options.wasClean=false] Indicates whether or not the
       *     connection was cleanly closed
       */
      constructor(type, options = {}) {
        super(type);
        this[kCode] = options.code === void 0 ? 0 : options.code;
        this[kReason] = options.reason === void 0 ? "" : options.reason;
        this[kWasClean] = options.wasClean === void 0 ? false : options.wasClean;
      }
      /**
       * @type {Number}
       */
      get code() {
        return this[kCode];
      }
      /**
       * @type {String}
       */
      get reason() {
        return this[kReason];
      }
      /**
       * @type {Boolean}
       */
      get wasClean() {
        return this[kWasClean];
      }
    };
    Object.defineProperty(CloseEvent.prototype, "code", { enumerable: true });
    Object.defineProperty(CloseEvent.prototype, "reason", { enumerable: true });
    Object.defineProperty(CloseEvent.prototype, "wasClean", { enumerable: true });
    var ErrorEvent = class extends Event {
      /**
       * Create a new `ErrorEvent`.
       *
       * @param {String} type The name of the event
       * @param {Object} [options] A dictionary object that allows for setting
       *     attributes via object members of the same name
       * @param {*} [options.error=null] The error that generated this event
       * @param {String} [options.message=''] The error message
       */
      constructor(type, options = {}) {
        super(type);
        this[kError] = options.error === void 0 ? null : options.error;
        this[kMessage] = options.message === void 0 ? "" : options.message;
      }
      /**
       * @type {*}
       */
      get error() {
        return this[kError];
      }
      /**
       * @type {String}
       */
      get message() {
        return this[kMessage];
      }
    };
    Object.defineProperty(ErrorEvent.prototype, "error", { enumerable: true });
    Object.defineProperty(ErrorEvent.prototype, "message", { enumerable: true });
    var MessageEvent = class extends Event {
      /**
       * Create a new `MessageEvent`.
       *
       * @param {String} type The name of the event
       * @param {Object} [options] A dictionary object that allows for setting
       *     attributes via object members of the same name
       * @param {*} [options.data=null] The message content
       */
      constructor(type, options = {}) {
        super(type);
        this[kData] = options.data === void 0 ? null : options.data;
      }
      /**
       * @type {*}
       */
      get data() {
        return this[kData];
      }
    };
    Object.defineProperty(MessageEvent.prototype, "data", { enumerable: true });
    var EventTarget = {
      /**
       * Register an event listener.
       *
       * @param {String} type A string representing the event type to listen for
       * @param {(Function|Object)} handler The listener to add
       * @param {Object} [options] An options object specifies characteristics about
       *     the event listener
       * @param {Boolean} [options.once=false] A `Boolean` indicating that the
       *     listener should be invoked at most once after being added. If `true`,
       *     the listener would be automatically removed when invoked.
       * @public
       */
      addEventListener(type, handler, options = {}) {
        for (const listener of this.listeners(type)) {
          if (!options[kForOnEventAttribute] && listener[kListener] === handler && !listener[kForOnEventAttribute]) {
            return;
          }
        }
        let wrapper;
        if (type === "message") {
          wrapper = function onMessage(data, isBinary) {
            const event = new MessageEvent("message", {
              data: isBinary ? data : data.toString()
            });
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else if (type === "close") {
          wrapper = function onClose(code, message) {
            const event = new CloseEvent("close", {
              code,
              reason: message.toString(),
              wasClean: this._closeFrameReceived && this._closeFrameSent
            });
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else if (type === "error") {
          wrapper = function onError(error) {
            const event = new ErrorEvent("error", {
              error,
              message: error.message
            });
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else if (type === "open") {
          wrapper = function onOpen() {
            const event = new Event("open");
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else {
          return;
        }
        wrapper[kForOnEventAttribute] = !!options[kForOnEventAttribute];
        wrapper[kListener] = handler;
        if (options.once) {
          this.once(type, wrapper);
        } else {
          this.on(type, wrapper);
        }
      },
      /**
       * Remove an event listener.
       *
       * @param {String} type A string representing the event type to remove
       * @param {(Function|Object)} handler The listener to remove
       * @public
       */
      removeEventListener(type, handler) {
        for (const listener of this.listeners(type)) {
          if (listener[kListener] === handler && !listener[kForOnEventAttribute]) {
            this.removeListener(type, listener);
            break;
          }
        }
      }
    };
    module2.exports = {
      CloseEvent,
      ErrorEvent,
      Event,
      EventTarget,
      MessageEvent
    };
    function callListener(listener, thisArg, event) {
      if (typeof listener === "object" && listener.handleEvent) {
        listener.handleEvent.call(listener, event);
      } else {
        listener.call(thisArg, event);
      }
    }
  }
});

// MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/node_modules/ws/lib/extension.js
var require_extension = __commonJS({
  "MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/node_modules/ws/lib/extension.js"(exports2, module2) {
    "use strict";
    var { tokenChars } = require_validation();
    function push(dest, name, elem) {
      if (dest[name] === void 0) dest[name] = [elem];
      else dest[name].push(elem);
    }
    function parse(header) {
      const offers = /* @__PURE__ */ Object.create(null);
      let params = /* @__PURE__ */ Object.create(null);
      let mustUnescape = false;
      let isEscaping = false;
      let inQuotes = false;
      let extensionName;
      let paramName;
      let start = -1;
      let code = -1;
      let end = -1;
      let i = 0;
      for (; i < header.length; i++) {
        code = header.charCodeAt(i);
        if (extensionName === void 0) {
          if (end === -1 && tokenChars[code] === 1) {
            if (start === -1) start = i;
          } else if (i !== 0 && (code === 32 || code === 9)) {
            if (end === -1 && start !== -1) end = i;
          } else if (code === 59 || code === 44) {
            if (start === -1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (end === -1) end = i;
            const name = header.slice(start, end);
            if (code === 44) {
              push(offers, name, params);
              params = /* @__PURE__ */ Object.create(null);
            } else {
              extensionName = name;
            }
            start = end = -1;
          } else {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
        } else if (paramName === void 0) {
          if (end === -1 && tokenChars[code] === 1) {
            if (start === -1) start = i;
          } else if (code === 32 || code === 9) {
            if (end === -1 && start !== -1) end = i;
          } else if (code === 59 || code === 44) {
            if (start === -1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (end === -1) end = i;
            push(params, header.slice(start, end), true);
            if (code === 44) {
              push(offers, extensionName, params);
              params = /* @__PURE__ */ Object.create(null);
              extensionName = void 0;
            }
            start = end = -1;
          } else if (code === 61 && start !== -1 && end === -1) {
            paramName = header.slice(start, i);
            start = end = -1;
          } else {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
        } else {
          if (isEscaping) {
            if (tokenChars[code] !== 1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (start === -1) start = i;
            else if (!mustUnescape) mustUnescape = true;
            isEscaping = false;
          } else if (inQuotes) {
            if (tokenChars[code] === 1) {
              if (start === -1) start = i;
            } else if (code === 34 && start !== -1) {
              inQuotes = false;
              end = i;
            } else if (code === 92) {
              isEscaping = true;
            } else {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
          } else if (code === 34 && header.charCodeAt(i - 1) === 61) {
            inQuotes = true;
          } else if (end === -1 && tokenChars[code] === 1) {
            if (start === -1) start = i;
          } else if (start !== -1 && (code === 32 || code === 9)) {
            if (end === -1) end = i;
          } else if (code === 59 || code === 44) {
            if (start === -1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (end === -1) end = i;
            let value = header.slice(start, end);
            if (mustUnescape) {
              value = value.replace(/\\/g, "");
              mustUnescape = false;
            }
            push(params, paramName, value);
            if (code === 44) {
              push(offers, extensionName, params);
              params = /* @__PURE__ */ Object.create(null);
              extensionName = void 0;
            }
            paramName = void 0;
            start = end = -1;
          } else {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
        }
      }
      if (start === -1 || inQuotes || code === 32 || code === 9) {
        throw new SyntaxError("Unexpected end of input");
      }
      if (end === -1) end = i;
      const token = header.slice(start, end);
      if (extensionName === void 0) {
        push(offers, token, params);
      } else {
        if (paramName === void 0) {
          push(params, token, true);
        } else if (mustUnescape) {
          push(params, paramName, token.replace(/\\/g, ""));
        } else {
          push(params, paramName, token);
        }
        push(offers, extensionName, params);
      }
      return offers;
    }
    function format(extensions) {
      return Object.keys(extensions).map((extension) => {
        let configurations = extensions[extension];
        if (!Array.isArray(configurations)) configurations = [configurations];
        return configurations.map((params) => {
          return [extension].concat(
            Object.keys(params).map((k) => {
              let values = params[k];
              if (!Array.isArray(values)) values = [values];
              return values.map((v) => v === true ? k : `${k}=${v}`).join("; ");
            })
          ).join("; ");
        }).join(", ");
      }).join(", ");
    }
    module2.exports = { format, parse };
  }
});

// MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/node_modules/ws/lib/websocket.js
var require_websocket = __commonJS({
  "MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/node_modules/ws/lib/websocket.js"(exports2, module2) {
    "use strict";
    var EventEmitter = require("events");
    var https4 = require("https");
    var http5 = require("http");
    var net = require("net");
    var tls = require("tls");
    var { randomBytes, createHash } = require("crypto");
    var { Duplex, Readable } = require("stream");
    var { URL: URL2 } = require("url");
    var PerMessageDeflate = require_permessage_deflate();
    var Receiver = require_receiver();
    var Sender = require_sender();
    var { isBlob } = require_validation();
    var {
      BINARY_TYPES,
      CLOSE_TIMEOUT,
      EMPTY_BUFFER,
      GUID,
      kForOnEventAttribute,
      kListener,
      kStatusCode,
      kWebSocket,
      NOOP
    } = require_constants();
    var {
      EventTarget: { addEventListener, removeEventListener }
    } = require_event_target();
    var { format, parse } = require_extension();
    var { toBuffer } = require_buffer_util();
    var kAborted = /* @__PURE__ */ Symbol("kAborted");
    var protocolVersions = [8, 13];
    var readyStates = ["CONNECTING", "OPEN", "CLOSING", "CLOSED"];
    var subprotocolRegex = /^[!#$%&'*+\-.0-9A-Z^_`|a-z~]+$/;
    var WebSocket2 = class _WebSocket extends EventEmitter {
      /**
       * Create a new `WebSocket`.
       *
       * @param {(String|URL)} address The URL to which to connect
       * @param {(String|String[])} [protocols] The subprotocols
       * @param {Object} [options] Connection options
       */
      constructor(address, protocols, options) {
        super();
        this._binaryType = BINARY_TYPES[0];
        this._closeCode = 1006;
        this._closeFrameReceived = false;
        this._closeFrameSent = false;
        this._closeMessage = EMPTY_BUFFER;
        this._closeTimer = null;
        this._errorEmitted = false;
        this._extensions = {};
        this._paused = false;
        this._protocol = "";
        this._readyState = _WebSocket.CONNECTING;
        this._receiver = null;
        this._sender = null;
        this._socket = null;
        if (address !== null) {
          this._bufferedAmount = 0;
          this._isServer = false;
          this._redirects = 0;
          if (protocols === void 0) {
            protocols = [];
          } else if (!Array.isArray(protocols)) {
            if (typeof protocols === "object" && protocols !== null) {
              options = protocols;
              protocols = [];
            } else {
              protocols = [protocols];
            }
          }
          initAsClient(this, address, protocols, options);
        } else {
          this._autoPong = options.autoPong;
          this._closeTimeout = options.closeTimeout;
          this._isServer = true;
        }
      }
      /**
       * For historical reasons, the custom "nodebuffer" type is used by the default
       * instead of "blob".
       *
       * @type {String}
       */
      get binaryType() {
        return this._binaryType;
      }
      set binaryType(type) {
        if (!BINARY_TYPES.includes(type)) return;
        this._binaryType = type;
        if (this._receiver) this._receiver._binaryType = type;
      }
      /**
       * @type {Number}
       */
      get bufferedAmount() {
        if (!this._socket) return this._bufferedAmount;
        return this._socket._writableState.length + this._sender._bufferedBytes;
      }
      /**
       * @type {String}
       */
      get extensions() {
        return Object.keys(this._extensions).join();
      }
      /**
       * @type {Boolean}
       */
      get isPaused() {
        return this._paused;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onclose() {
        return null;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onerror() {
        return null;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onopen() {
        return null;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onmessage() {
        return null;
      }
      /**
       * @type {String}
       */
      get protocol() {
        return this._protocol;
      }
      /**
       * @type {Number}
       */
      get readyState() {
        return this._readyState;
      }
      /**
       * @type {String}
       */
      get url() {
        return this._url;
      }
      /**
       * Set up the socket and the internal resources.
       *
       * @param {Duplex} socket The network socket between the server and client
       * @param {Buffer} head The first packet of the upgraded stream
       * @param {Object} options Options object
       * @param {Boolean} [options.allowSynchronousEvents=false] Specifies whether
       *     any of the `'message'`, `'ping'`, and `'pong'` events can be emitted
       *     multiple times in the same tick
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Number} [options.maxBufferedChunks=0] The maximum number of
       *     buffered data chunks
       * @param {Number} [options.maxFragments=0] The maximum number of message
       *     fragments
       * @param {Number} [options.maxPayload=0] The maximum allowed message size
       * @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
       *     not to skip UTF-8 validation for text and close messages
       * @private
       */
      setSocket(socket, head, options) {
        const receiver = new Receiver({
          allowSynchronousEvents: options.allowSynchronousEvents,
          binaryType: this.binaryType,
          extensions: this._extensions,
          isServer: this._isServer,
          maxBufferedChunks: options.maxBufferedChunks,
          maxFragments: options.maxFragments,
          maxPayload: options.maxPayload,
          skipUTF8Validation: options.skipUTF8Validation
        });
        const sender = new Sender(socket, this._extensions, options.generateMask);
        this._receiver = receiver;
        this._sender = sender;
        this._socket = socket;
        receiver[kWebSocket] = this;
        sender[kWebSocket] = this;
        socket[kWebSocket] = this;
        receiver.on("conclude", receiverOnConclude);
        receiver.on("drain", receiverOnDrain);
        receiver.on("error", receiverOnError);
        receiver.on("message", receiverOnMessage);
        receiver.on("ping", receiverOnPing);
        receiver.on("pong", receiverOnPong);
        sender.onerror = senderOnError;
        if (socket.setTimeout) socket.setTimeout(0);
        if (socket.setNoDelay) socket.setNoDelay();
        if (head.length > 0) socket.unshift(head);
        socket.on("close", socketOnClose);
        socket.on("data", socketOnData);
        socket.on("end", socketOnEnd);
        socket.on("error", socketOnError);
        this._readyState = _WebSocket.OPEN;
        this.emit("open");
      }
      /**
       * Emit the `'close'` event.
       *
       * @private
       */
      emitClose() {
        if (!this._socket) {
          this._readyState = _WebSocket.CLOSED;
          this.emit("close", this._closeCode, this._closeMessage);
          return;
        }
        if (this._extensions[PerMessageDeflate.extensionName]) {
          this._extensions[PerMessageDeflate.extensionName].cleanup();
        }
        this._receiver.removeAllListeners();
        this._readyState = _WebSocket.CLOSED;
        this.emit("close", this._closeCode, this._closeMessage);
      }
      /**
       * Start a closing handshake.
       *
       *          +----------+   +-----------+   +----------+
       *     - - -|ws.close()|-->|close frame|-->|ws.close()|- - -
       *    |     +----------+   +-----------+   +----------+     |
       *          +----------+   +-----------+         |
       * CLOSING  |ws.close()|<--|close frame|<--+-----+       CLOSING
       *          +----------+   +-----------+   |
       *    |           |                        |   +---+        |
       *                +------------------------+-->|fin| - - - -
       *    |         +---+                      |   +---+
       *     - - - - -|fin|<---------------------+
       *              +---+
       *
       * @param {Number} [code] Status code explaining why the connection is closing
       * @param {(String|Buffer)} [data] The reason why the connection is
       *     closing
       * @public
       */
      close(code, data) {
        if (this.readyState === _WebSocket.CLOSED) return;
        if (this.readyState === _WebSocket.CONNECTING) {
          const msg = "WebSocket was closed before the connection was established";
          abortHandshake(this, this._req, msg);
          return;
        }
        if (this.readyState === _WebSocket.CLOSING) {
          if (this._closeFrameSent && (this._closeFrameReceived || this._receiver._writableState.errorEmitted)) {
            this._socket.end();
          }
          return;
        }
        this._readyState = _WebSocket.CLOSING;
        this._sender.close(code, data, !this._isServer, (err) => {
          if (err) return;
          this._closeFrameSent = true;
          if (this._closeFrameReceived || this._receiver._writableState.errorEmitted) {
            this._socket.end();
          }
        });
        setCloseTimer(this);
      }
      /**
       * Pause the socket.
       *
       * @public
       */
      pause() {
        if (this.readyState === _WebSocket.CONNECTING || this.readyState === _WebSocket.CLOSED) {
          return;
        }
        this._paused = true;
        this._socket.pause();
      }
      /**
       * Send a ping.
       *
       * @param {*} [data] The data to send
       * @param {Boolean} [mask] Indicates whether or not to mask `data`
       * @param {Function} [cb] Callback which is executed when the ping is sent
       * @public
       */
      ping(data, mask, cb) {
        if (this.readyState === _WebSocket.CONNECTING) {
          throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
        }
        if (typeof data === "function") {
          cb = data;
          data = mask = void 0;
        } else if (typeof mask === "function") {
          cb = mask;
          mask = void 0;
        }
        if (typeof data === "number") data = data.toString();
        if (this.readyState !== _WebSocket.OPEN) {
          sendAfterClose(this, data, cb);
          return;
        }
        if (mask === void 0) mask = !this._isServer;
        this._sender.ping(data || EMPTY_BUFFER, mask, cb);
      }
      /**
       * Send a pong.
       *
       * @param {*} [data] The data to send
       * @param {Boolean} [mask] Indicates whether or not to mask `data`
       * @param {Function} [cb] Callback which is executed when the pong is sent
       * @public
       */
      pong(data, mask, cb) {
        if (this.readyState === _WebSocket.CONNECTING) {
          throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
        }
        if (typeof data === "function") {
          cb = data;
          data = mask = void 0;
        } else if (typeof mask === "function") {
          cb = mask;
          mask = void 0;
        }
        if (typeof data === "number") data = data.toString();
        if (this.readyState !== _WebSocket.OPEN) {
          sendAfterClose(this, data, cb);
          return;
        }
        if (mask === void 0) mask = !this._isServer;
        this._sender.pong(data || EMPTY_BUFFER, mask, cb);
      }
      /**
       * Resume the socket.
       *
       * @public
       */
      resume() {
        if (this.readyState === _WebSocket.CONNECTING || this.readyState === _WebSocket.CLOSED) {
          return;
        }
        this._paused = false;
        if (!this._receiver._writableState.needDrain) this._socket.resume();
      }
      /**
       * Send a data message.
       *
       * @param {*} data The message to send
       * @param {Object} [options] Options object
       * @param {Boolean} [options.binary] Specifies whether `data` is binary or
       *     text
       * @param {Boolean} [options.compress] Specifies whether or not to compress
       *     `data`
       * @param {Boolean} [options.fin=true] Specifies whether the fragment is the
       *     last one
       * @param {Boolean} [options.mask] Specifies whether or not to mask `data`
       * @param {Function} [cb] Callback which is executed when data is written out
       * @public
       */
      send(data, options, cb) {
        if (this.readyState === _WebSocket.CONNECTING) {
          throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
        }
        if (typeof options === "function") {
          cb = options;
          options = {};
        }
        if (typeof data === "number") data = data.toString();
        if (this.readyState !== _WebSocket.OPEN) {
          sendAfterClose(this, data, cb);
          return;
        }
        const opts = {
          binary: typeof data !== "string",
          mask: !this._isServer,
          compress: true,
          fin: true,
          ...options
        };
        if (!this._extensions[PerMessageDeflate.extensionName]) {
          opts.compress = false;
        }
        this._sender.send(data || EMPTY_BUFFER, opts, cb);
      }
      /**
       * Forcibly close the connection.
       *
       * @public
       */
      terminate() {
        if (this.readyState === _WebSocket.CLOSED) return;
        if (this.readyState === _WebSocket.CONNECTING) {
          const msg = "WebSocket was closed before the connection was established";
          abortHandshake(this, this._req, msg);
          return;
        }
        if (this._socket) {
          this._readyState = _WebSocket.CLOSING;
          this._socket.destroy();
        }
      }
    };
    Object.defineProperty(WebSocket2, "CONNECTING", {
      enumerable: true,
      value: readyStates.indexOf("CONNECTING")
    });
    Object.defineProperty(WebSocket2.prototype, "CONNECTING", {
      enumerable: true,
      value: readyStates.indexOf("CONNECTING")
    });
    Object.defineProperty(WebSocket2, "OPEN", {
      enumerable: true,
      value: readyStates.indexOf("OPEN")
    });
    Object.defineProperty(WebSocket2.prototype, "OPEN", {
      enumerable: true,
      value: readyStates.indexOf("OPEN")
    });
    Object.defineProperty(WebSocket2, "CLOSING", {
      enumerable: true,
      value: readyStates.indexOf("CLOSING")
    });
    Object.defineProperty(WebSocket2.prototype, "CLOSING", {
      enumerable: true,
      value: readyStates.indexOf("CLOSING")
    });
    Object.defineProperty(WebSocket2, "CLOSED", {
      enumerable: true,
      value: readyStates.indexOf("CLOSED")
    });
    Object.defineProperty(WebSocket2.prototype, "CLOSED", {
      enumerable: true,
      value: readyStates.indexOf("CLOSED")
    });
    [
      "binaryType",
      "bufferedAmount",
      "extensions",
      "isPaused",
      "protocol",
      "readyState",
      "url"
    ].forEach((property) => {
      Object.defineProperty(WebSocket2.prototype, property, { enumerable: true });
    });
    ["open", "error", "close", "message"].forEach((method) => {
      Object.defineProperty(WebSocket2.prototype, `on${method}`, {
        enumerable: true,
        get() {
          for (const listener of this.listeners(method)) {
            if (listener[kForOnEventAttribute]) return listener[kListener];
          }
          return null;
        },
        set(handler) {
          for (const listener of this.listeners(method)) {
            if (listener[kForOnEventAttribute]) {
              this.removeListener(method, listener);
              break;
            }
          }
          if (typeof handler !== "function") return;
          this.addEventListener(method, handler, {
            [kForOnEventAttribute]: true
          });
        }
      });
    });
    WebSocket2.prototype.addEventListener = addEventListener;
    WebSocket2.prototype.removeEventListener = removeEventListener;
    module2.exports = WebSocket2;
    function initAsClient(websocket, address, protocols, options) {
      const opts = {
        allowSynchronousEvents: true,
        autoPong: true,
        closeTimeout: CLOSE_TIMEOUT,
        protocolVersion: protocolVersions[1],
        maxBufferedChunks: 256 * 1024,
        maxFragments: 16 * 1024,
        maxPayload: 100 * 1024 * 1024,
        skipUTF8Validation: false,
        perMessageDeflate: true,
        followRedirects: false,
        maxRedirects: 10,
        ...options,
        socketPath: void 0,
        hostname: void 0,
        protocol: void 0,
        timeout: void 0,
        method: "GET",
        host: void 0,
        path: void 0,
        port: void 0
      };
      websocket._autoPong = opts.autoPong;
      websocket._closeTimeout = opts.closeTimeout;
      if (!protocolVersions.includes(opts.protocolVersion)) {
        throw new RangeError(
          `Unsupported protocol version: ${opts.protocolVersion} (supported versions: ${protocolVersions.join(", ")})`
        );
      }
      let parsedUrl;
      if (address instanceof URL2) {
        parsedUrl = address;
      } else {
        try {
          parsedUrl = new URL2(address);
        } catch {
          throw new SyntaxError(`Invalid URL: ${address}`);
        }
      }
      if (parsedUrl.protocol === "http:") {
        parsedUrl.protocol = "ws:";
      } else if (parsedUrl.protocol === "https:") {
        parsedUrl.protocol = "wss:";
      }
      websocket._url = parsedUrl.href;
      const isSecure = parsedUrl.protocol === "wss:";
      const isIpcUrl = parsedUrl.protocol === "ws+unix:";
      let invalidUrlMessage;
      if (parsedUrl.protocol !== "ws:" && !isSecure && !isIpcUrl) {
        invalidUrlMessage = `The URL's protocol must be one of "ws:", "wss:", "http:", "https:", or "ws+unix:"`;
      } else if (isIpcUrl && !parsedUrl.pathname) {
        invalidUrlMessage = "The URL's pathname is empty";
      } else if (parsedUrl.hash) {
        invalidUrlMessage = "The URL contains a fragment identifier";
      }
      if (invalidUrlMessage) {
        const err = new SyntaxError(invalidUrlMessage);
        if (websocket._redirects === 0) {
          throw err;
        } else {
          emitErrorAndClose(websocket, err);
          return;
        }
      }
      const defaultPort = isSecure ? 443 : 80;
      const key = randomBytes(16).toString("base64");
      const request = isSecure ? https4.request : http5.request;
      const protocolSet = /* @__PURE__ */ new Set();
      let perMessageDeflate;
      opts.createConnection = opts.createConnection || (isSecure ? tlsConnect : netConnect);
      opts.defaultPort = opts.defaultPort || defaultPort;
      opts.port = parsedUrl.port || defaultPort;
      opts.host = parsedUrl.hostname.startsWith("[") ? parsedUrl.hostname.slice(1, -1) : parsedUrl.hostname;
      opts.headers = {
        ...opts.headers,
        "Sec-WebSocket-Version": opts.protocolVersion,
        "Sec-WebSocket-Key": key,
        Connection: "Upgrade",
        Upgrade: "websocket"
      };
      opts.path = parsedUrl.pathname + parsedUrl.search;
      opts.timeout = opts.handshakeTimeout;
      if (opts.perMessageDeflate) {
        perMessageDeflate = new PerMessageDeflate({
          ...opts.perMessageDeflate,
          isServer: false,
          maxPayload: opts.maxPayload
        });
        opts.headers["Sec-WebSocket-Extensions"] = format({
          [PerMessageDeflate.extensionName]: perMessageDeflate.offer()
        });
      }
      if (protocols.length) {
        for (const protocol of protocols) {
          if (typeof protocol !== "string" || !subprotocolRegex.test(protocol) || protocolSet.has(protocol)) {
            throw new SyntaxError(
              "An invalid or duplicated subprotocol was specified"
            );
          }
          protocolSet.add(protocol);
        }
        opts.headers["Sec-WebSocket-Protocol"] = protocols.join(",");
      }
      if (opts.origin) {
        if (opts.protocolVersion < 13) {
          opts.headers["Sec-WebSocket-Origin"] = opts.origin;
        } else {
          opts.headers.Origin = opts.origin;
        }
      }
      if (parsedUrl.username || parsedUrl.password) {
        opts.auth = `${parsedUrl.username}:${parsedUrl.password}`;
      }
      if (isIpcUrl) {
        const parts = opts.path.split(":");
        opts.socketPath = parts[0];
        opts.path = parts[1];
      }
      let req;
      if (opts.followRedirects) {
        if (websocket._redirects === 0) {
          websocket._originalIpc = isIpcUrl;
          websocket._originalSecure = isSecure;
          websocket._originalHostOrSocketPath = isIpcUrl ? opts.socketPath : parsedUrl.host;
          const headers = options && options.headers;
          options = { ...options, headers: {} };
          if (headers) {
            for (const [key2, value] of Object.entries(headers)) {
              options.headers[key2.toLowerCase()] = value;
            }
          }
        } else if (websocket.listenerCount("redirect") === 0) {
          const isSameHost = isIpcUrl ? websocket._originalIpc ? opts.socketPath === websocket._originalHostOrSocketPath : false : websocket._originalIpc ? false : parsedUrl.host === websocket._originalHostOrSocketPath;
          if (!isSameHost || websocket._originalSecure && !isSecure) {
            delete opts.headers.authorization;
            delete opts.headers.cookie;
            if (!isSameHost) delete opts.headers.host;
            opts.auth = void 0;
          }
        }
        if (opts.auth && !options.headers.authorization) {
          options.headers.authorization = "Basic " + Buffer.from(opts.auth).toString("base64");
        }
        req = websocket._req = request(opts);
        if (websocket._redirects) {
          websocket.emit("redirect", websocket.url, req);
        }
      } else {
        req = websocket._req = request(opts);
      }
      if (opts.timeout) {
        req.on("timeout", () => {
          abortHandshake(websocket, req, "Opening handshake has timed out");
        });
      }
      req.on("error", (err) => {
        if (req === null || req[kAborted]) return;
        req = websocket._req = null;
        emitErrorAndClose(websocket, err);
      });
      req.on("response", (res) => {
        const location = res.headers.location;
        const statusCode = res.statusCode;
        if (location && opts.followRedirects && statusCode >= 300 && statusCode < 400) {
          if (++websocket._redirects > opts.maxRedirects) {
            abortHandshake(websocket, req, "Maximum redirects exceeded");
            return;
          }
          req.abort();
          let addr;
          try {
            addr = new URL2(location, address);
          } catch (e) {
            const err = new SyntaxError(`Invalid URL: ${location}`);
            emitErrorAndClose(websocket, err);
            return;
          }
          initAsClient(websocket, addr, protocols, options);
        } else if (!websocket.emit("unexpected-response", req, res)) {
          abortHandshake(
            websocket,
            req,
            `Unexpected server response: ${res.statusCode}`
          );
        }
      });
      req.on("upgrade", (res, socket, head) => {
        websocket.emit("upgrade", res);
        if (websocket.readyState !== WebSocket2.CONNECTING) return;
        req = websocket._req = null;
        const upgrade = res.headers.upgrade;
        if (upgrade === void 0 || upgrade.toLowerCase() !== "websocket") {
          abortHandshake(websocket, socket, "Invalid Upgrade header");
          return;
        }
        const digest = createHash("sha1").update(key + GUID).digest("base64");
        if (res.headers["sec-websocket-accept"] !== digest) {
          abortHandshake(websocket, socket, "Invalid Sec-WebSocket-Accept header");
          return;
        }
        const serverProt = res.headers["sec-websocket-protocol"];
        let protError;
        if (serverProt !== void 0) {
          if (!protocolSet.size) {
            protError = "Server sent a subprotocol but none was requested";
          } else if (!protocolSet.has(serverProt)) {
            protError = "Server sent an invalid subprotocol";
          }
        } else if (protocolSet.size) {
          protError = "Server sent no subprotocol";
        }
        if (protError) {
          abortHandshake(websocket, socket, protError);
          return;
        }
        if (serverProt) websocket._protocol = serverProt;
        const secWebSocketExtensions = res.headers["sec-websocket-extensions"];
        if (secWebSocketExtensions !== void 0) {
          if (!perMessageDeflate) {
            const message = "Server sent a Sec-WebSocket-Extensions header but no extension was requested";
            abortHandshake(websocket, socket, message);
            return;
          }
          let extensions;
          try {
            extensions = parse(secWebSocketExtensions);
          } catch (err) {
            const message = "Invalid Sec-WebSocket-Extensions header";
            abortHandshake(websocket, socket, message);
            return;
          }
          const extensionNames = Object.keys(extensions);
          if (extensionNames.length !== 1 || extensionNames[0] !== PerMessageDeflate.extensionName) {
            const message = "Server indicated an extension that was not requested";
            abortHandshake(websocket, socket, message);
            return;
          }
          try {
            perMessageDeflate.accept(extensions[PerMessageDeflate.extensionName]);
          } catch (err) {
            const message = "Invalid Sec-WebSocket-Extensions header";
            abortHandshake(websocket, socket, message);
            return;
          }
          websocket._extensions[PerMessageDeflate.extensionName] = perMessageDeflate;
        }
        websocket.setSocket(socket, head, {
          allowSynchronousEvents: opts.allowSynchronousEvents,
          generateMask: opts.generateMask,
          maxBufferedChunks: opts.maxBufferedChunks,
          maxFragments: opts.maxFragments,
          maxPayload: opts.maxPayload,
          skipUTF8Validation: opts.skipUTF8Validation
        });
      });
      if (opts.finishRequest) {
        opts.finishRequest(req, websocket);
      } else {
        req.end();
      }
    }
    function emitErrorAndClose(websocket, err) {
      websocket._readyState = WebSocket2.CLOSING;
      websocket._errorEmitted = true;
      websocket.emit("error", err);
      websocket.emitClose();
    }
    function netConnect(options) {
      options.path = options.socketPath;
      return net.connect(options);
    }
    function tlsConnect(options) {
      options.path = void 0;
      if (!options.servername && options.servername !== "") {
        options.servername = net.isIP(options.host) ? "" : options.host;
      }
      return tls.connect(options);
    }
    function abortHandshake(websocket, stream, message) {
      websocket._readyState = WebSocket2.CLOSING;
      const err = new Error(message);
      Error.captureStackTrace(err, abortHandshake);
      if (stream.setHeader) {
        stream[kAborted] = true;
        stream.abort();
        if (stream.socket && !stream.socket.destroyed) {
          stream.socket.destroy();
        }
        process.nextTick(emitErrorAndClose, websocket, err);
      } else {
        stream.destroy(err);
        stream.once("error", websocket.emit.bind(websocket, "error"));
        stream.once("close", websocket.emitClose.bind(websocket));
      }
    }
    function sendAfterClose(websocket, data, cb) {
      if (data) {
        const length = isBlob(data) ? data.size : toBuffer(data).length;
        if (websocket._socket) websocket._sender._bufferedBytes += length;
        else websocket._bufferedAmount += length;
      }
      if (cb) {
        const err = new Error(
          `WebSocket is not open: readyState ${websocket.readyState} (${readyStates[websocket.readyState]})`
        );
        process.nextTick(cb, err);
      }
    }
    function receiverOnConclude(code, reason) {
      const websocket = this[kWebSocket];
      websocket._closeFrameReceived = true;
      websocket._closeMessage = reason;
      websocket._closeCode = code;
      if (websocket._socket[kWebSocket] === void 0) return;
      websocket._socket.removeListener("data", socketOnData);
      process.nextTick(resume, websocket._socket);
      if (code === 1005) websocket.close();
      else websocket.close(code, reason);
    }
    function receiverOnDrain() {
      const websocket = this[kWebSocket];
      if (!websocket.isPaused) websocket._socket.resume();
    }
    function receiverOnError(err) {
      const websocket = this[kWebSocket];
      if (websocket._socket[kWebSocket] !== void 0) {
        websocket._socket.removeListener("data", socketOnData);
        process.nextTick(resume, websocket._socket);
        websocket.close(err[kStatusCode]);
      }
      if (!websocket._errorEmitted) {
        websocket._errorEmitted = true;
        websocket.emit("error", err);
      }
    }
    function receiverOnFinish() {
      this[kWebSocket].emitClose();
    }
    function receiverOnMessage(data, isBinary) {
      this[kWebSocket].emit("message", data, isBinary);
    }
    function receiverOnPing(data) {
      const websocket = this[kWebSocket];
      if (websocket._autoPong) websocket.pong(data, !this._isServer, NOOP);
      websocket.emit("ping", data);
    }
    function receiverOnPong(data) {
      this[kWebSocket].emit("pong", data);
    }
    function resume(stream) {
      stream.resume();
    }
    function senderOnError(err) {
      const websocket = this[kWebSocket];
      if (websocket.readyState === WebSocket2.CLOSED) return;
      if (websocket.readyState === WebSocket2.OPEN) {
        websocket._readyState = WebSocket2.CLOSING;
        setCloseTimer(websocket);
      }
      this._socket.end();
      if (!websocket._errorEmitted) {
        websocket._errorEmitted = true;
        websocket.emit("error", err);
      }
    }
    function setCloseTimer(websocket) {
      websocket._closeTimer = setTimeout(
        websocket._socket.destroy.bind(websocket._socket),
        websocket._closeTimeout
      );
    }
    function socketOnClose() {
      const websocket = this[kWebSocket];
      this.removeListener("close", socketOnClose);
      this.removeListener("data", socketOnData);
      this.removeListener("end", socketOnEnd);
      websocket._readyState = WebSocket2.CLOSING;
      if (!this._readableState.endEmitted && !websocket._closeFrameReceived && !websocket._receiver._writableState.errorEmitted && this._readableState.length !== 0) {
        const chunk = this.read(this._readableState.length);
        websocket._receiver.write(chunk);
      }
      websocket._receiver.end();
      this[kWebSocket] = void 0;
      clearTimeout(websocket._closeTimer);
      if (websocket._receiver._writableState.finished || websocket._receiver._writableState.errorEmitted) {
        websocket.emitClose();
      } else {
        websocket._receiver.on("error", receiverOnFinish);
        websocket._receiver.on("finish", receiverOnFinish);
      }
    }
    function socketOnData(chunk) {
      if (!this[kWebSocket]._receiver.write(chunk)) {
        this.pause();
      }
    }
    function socketOnEnd() {
      const websocket = this[kWebSocket];
      websocket._readyState = WebSocket2.CLOSING;
      websocket._receiver.end();
      this.end();
    }
    function socketOnError() {
      const websocket = this[kWebSocket];
      this.removeListener("error", socketOnError);
      this.on("error", NOOP);
      if (websocket) {
        websocket._readyState = WebSocket2.CLOSING;
        this.destroy();
      }
    }
  }
});

// MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/node_modules/ws/lib/stream.js
var require_stream = __commonJS({
  "MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/node_modules/ws/lib/stream.js"(exports2, module2) {
    "use strict";
    var WebSocket2 = require_websocket();
    var { Duplex } = require("stream");
    function emitClose(stream) {
      stream.emit("close");
    }
    function duplexOnEnd() {
      if (!this.destroyed && this._writableState.finished) {
        this.destroy();
      }
    }
    function duplexOnError(err) {
      this.removeListener("error", duplexOnError);
      this.destroy();
      if (this.listenerCount("error") === 0) {
        this.emit("error", err);
      }
    }
    function createWebSocketStream(ws, options) {
      let terminateOnDestroy = true;
      const duplex = new Duplex({
        ...options,
        autoDestroy: false,
        emitClose: false,
        objectMode: false,
        writableObjectMode: false
      });
      ws.on("message", function message(msg, isBinary) {
        const data = !isBinary && duplex._readableState.objectMode ? msg.toString() : msg;
        if (!duplex.push(data)) ws.pause();
      });
      ws.once("error", function error(err) {
        if (duplex.destroyed) return;
        terminateOnDestroy = false;
        duplex.destroy(err);
      });
      ws.once("close", function close() {
        if (duplex.destroyed) return;
        duplex.push(null);
      });
      duplex._destroy = function(err, callback) {
        if (ws.readyState === ws.CLOSED) {
          callback(err);
          process.nextTick(emitClose, duplex);
          return;
        }
        let called = false;
        ws.once("error", function error(err2) {
          called = true;
          callback(err2);
        });
        ws.once("close", function close() {
          if (!called) callback(err);
          process.nextTick(emitClose, duplex);
        });
        if (terminateOnDestroy) ws.terminate();
      };
      duplex._final = function(callback) {
        if (ws.readyState === ws.CONNECTING) {
          ws.once("open", function open() {
            duplex._final(callback);
          });
          return;
        }
        if (ws._socket === null) return;
        if (ws._socket._writableState.finished) {
          callback();
          if (duplex._readableState.endEmitted) duplex.destroy();
        } else {
          ws._socket.once("finish", function finish() {
            callback();
          });
          ws.close();
        }
      };
      duplex._read = function() {
        if (ws.isPaused) ws.resume();
      };
      duplex._write = function(chunk, encoding, callback) {
        if (ws.readyState === ws.CONNECTING) {
          ws.once("open", function open() {
            duplex._write(chunk, encoding, callback);
          });
          return;
        }
        ws.send(chunk, callback);
      };
      duplex.on("end", duplexOnEnd);
      duplex.on("error", duplexOnError);
      return duplex;
    }
    module2.exports = createWebSocketStream;
  }
});

// MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/node_modules/ws/lib/subprotocol.js
var require_subprotocol = __commonJS({
  "MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/node_modules/ws/lib/subprotocol.js"(exports2, module2) {
    "use strict";
    var { tokenChars } = require_validation();
    function parse(header) {
      const protocols = /* @__PURE__ */ new Set();
      let start = -1;
      let end = -1;
      let i = 0;
      for (i; i < header.length; i++) {
        const code = header.charCodeAt(i);
        if (end === -1 && tokenChars[code] === 1) {
          if (start === -1) start = i;
        } else if (i !== 0 && (code === 32 || code === 9)) {
          if (end === -1 && start !== -1) end = i;
        } else if (code === 44) {
          if (start === -1) {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
          if (end === -1) end = i;
          const protocol2 = header.slice(start, end);
          if (protocols.has(protocol2)) {
            throw new SyntaxError(`The "${protocol2}" subprotocol is duplicated`);
          }
          protocols.add(protocol2);
          start = end = -1;
        } else {
          throw new SyntaxError(`Unexpected character at index ${i}`);
        }
      }
      if (start === -1 || end !== -1) {
        throw new SyntaxError("Unexpected end of input");
      }
      const protocol = header.slice(start, i);
      if (protocols.has(protocol)) {
        throw new SyntaxError(`The "${protocol}" subprotocol is duplicated`);
      }
      protocols.add(protocol);
      return protocols;
    }
    module2.exports = { parse };
  }
});

// MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/node_modules/ws/lib/websocket-server.js
var require_websocket_server = __commonJS({
  "MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/node_modules/ws/lib/websocket-server.js"(exports2, module2) {
    "use strict";
    var EventEmitter = require("events");
    var http5 = require("http");
    var { Duplex } = require("stream");
    var { createHash } = require("crypto");
    var extension = require_extension();
    var PerMessageDeflate = require_permessage_deflate();
    var subprotocol = require_subprotocol();
    var WebSocket2 = require_websocket();
    var { CLOSE_TIMEOUT, GUID, kWebSocket } = require_constants();
    var keyRegex = /^[+/0-9A-Za-z]{22}==$/;
    var RUNNING = 0;
    var CLOSING = 1;
    var CLOSED = 2;
    var WebSocketServer2 = class extends EventEmitter {
      /**
       * Create a `WebSocketServer` instance.
       *
       * @param {Object} options Configuration options
       * @param {Boolean} [options.allowSynchronousEvents=true] Specifies whether
       *     any of the `'message'`, `'ping'`, and `'pong'` events can be emitted
       *     multiple times in the same tick
       * @param {Boolean} [options.autoPong=true] Specifies whether or not to
       *     automatically send a pong in response to a ping
       * @param {Number} [options.backlog=511] The maximum length of the queue of
       *     pending connections
       * @param {Boolean} [options.clientTracking=true] Specifies whether or not to
       *     track clients
       * @param {Number} [options.closeTimeout=30000] Duration in milliseconds to
       *     wait for the closing handshake to finish after `websocket.close()` is
       *     called
       * @param {Function} [options.handleProtocols] A hook to handle protocols
       * @param {String} [options.host] The hostname where to bind the server
       * @param {Number} [options.maxBufferedChunks=262144] The maximum number of
       *     buffered data chunks
       * @param {Number} [options.maxFragments=16384] The maximum number of message
       *     fragments
       * @param {Number} [options.maxPayload=104857600] The maximum allowed message
       *     size
       * @param {Boolean} [options.noServer=false] Enable no server mode
       * @param {String} [options.path] Accept only connections matching this path
       * @param {(Boolean|Object)} [options.perMessageDeflate=false] Enable/disable
       *     permessage-deflate
       * @param {Number} [options.port] The port where to bind the server
       * @param {(http.Server|https.Server)} [options.server] A pre-created HTTP/S
       *     server to use
       * @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
       *     not to skip UTF-8 validation for text and close messages
       * @param {Function} [options.verifyClient] A hook to reject connections
       * @param {Function} [options.WebSocket=WebSocket] Specifies the `WebSocket`
       *     class to use. It must be the `WebSocket` class or class that extends it
       * @param {Function} [callback] A listener for the `listening` event
       */
      constructor(options, callback) {
        super();
        options = {
          allowSynchronousEvents: true,
          autoPong: true,
          maxBufferedChunks: 256 * 1024,
          maxFragments: 16 * 1024,
          maxPayload: 100 * 1024 * 1024,
          skipUTF8Validation: false,
          perMessageDeflate: false,
          handleProtocols: null,
          clientTracking: true,
          closeTimeout: CLOSE_TIMEOUT,
          verifyClient: null,
          noServer: false,
          backlog: null,
          // use default (511 as implemented in net.js)
          server: null,
          host: null,
          path: null,
          port: null,
          WebSocket: WebSocket2,
          ...options
        };
        if (options.port == null && !options.server && !options.noServer || options.port != null && (options.server || options.noServer) || options.server && options.noServer) {
          throw new TypeError(
            'One and only one of the "port", "server", or "noServer" options must be specified'
          );
        }
        if (options.port != null) {
          this._server = http5.createServer((req, res) => {
            const body = http5.STATUS_CODES[426];
            res.writeHead(426, {
              "Content-Length": body.length,
              "Content-Type": "text/plain"
            });
            res.end(body);
          });
          this._server.listen(
            options.port,
            options.host,
            options.backlog,
            callback
          );
        } else if (options.server) {
          this._server = options.server;
        }
        if (this._server) {
          const emitConnection = this.emit.bind(this, "connection");
          this._removeListeners = addListeners(this._server, {
            listening: this.emit.bind(this, "listening"),
            error: this.emit.bind(this, "error"),
            upgrade: (req, socket, head) => {
              this.handleUpgrade(req, socket, head, emitConnection);
            }
          });
        }
        if (options.perMessageDeflate === true) options.perMessageDeflate = {};
        if (options.clientTracking) {
          this.clients = /* @__PURE__ */ new Set();
          this._shouldEmitClose = false;
        }
        this.options = options;
        this._state = RUNNING;
      }
      /**
       * Returns the bound address, the address family name, and port of the server
       * as reported by the operating system if listening on an IP socket.
       * If the server is listening on a pipe or UNIX domain socket, the name is
       * returned as a string.
       *
       * @return {(Object|String|null)} The address of the server
       * @public
       */
      address() {
        if (this.options.noServer) {
          throw new Error('The server is operating in "noServer" mode');
        }
        if (!this._server) return null;
        return this._server.address();
      }
      /**
       * Stop the server from accepting new connections and emit the `'close'` event
       * when all existing connections are closed.
       *
       * @param {Function} [cb] A one-time listener for the `'close'` event
       * @public
       */
      close(cb) {
        if (this._state === CLOSED) {
          if (cb) {
            this.once("close", () => {
              cb(new Error("The server is not running"));
            });
          }
          process.nextTick(emitClose, this);
          return;
        }
        if (cb) this.once("close", cb);
        if (this._state === CLOSING) return;
        this._state = CLOSING;
        if (this.options.noServer || this.options.server) {
          if (this._server) {
            this._removeListeners();
            this._removeListeners = this._server = null;
          }
          if (this.clients) {
            if (!this.clients.size) {
              process.nextTick(emitClose, this);
            } else {
              this._shouldEmitClose = true;
            }
          } else {
            process.nextTick(emitClose, this);
          }
        } else {
          const server = this._server;
          this._removeListeners();
          this._removeListeners = this._server = null;
          server.close(() => {
            emitClose(this);
          });
        }
      }
      /**
       * See if a given request should be handled by this server instance.
       *
       * @param {http.IncomingMessage} req Request object to inspect
       * @return {Boolean} `true` if the request is valid, else `false`
       * @public
       */
      shouldHandle(req) {
        if (this.options.path) {
          const index = req.url.indexOf("?");
          const pathname = index !== -1 ? req.url.slice(0, index) : req.url;
          if (pathname !== this.options.path) return false;
        }
        return true;
      }
      /**
       * Handle a HTTP Upgrade request.
       *
       * @param {http.IncomingMessage} req The request object
       * @param {Duplex} socket The network socket between the server and client
       * @param {Buffer} head The first packet of the upgraded stream
       * @param {Function} cb Callback
       * @public
       */
      handleUpgrade(req, socket, head, cb) {
        socket.on("error", socketOnError);
        const key = req.headers["sec-websocket-key"];
        const upgrade = req.headers.upgrade;
        const version = +req.headers["sec-websocket-version"];
        if (req.method !== "GET") {
          const message = "Invalid HTTP method";
          abortHandshakeOrEmitwsClientError(this, req, socket, 405, message);
          return;
        }
        if (upgrade === void 0 || upgrade.toLowerCase() !== "websocket") {
          const message = "Invalid Upgrade header";
          abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
          return;
        }
        if (key === void 0 || !keyRegex.test(key)) {
          const message = "Missing or invalid Sec-WebSocket-Key header";
          abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
          return;
        }
        if (version !== 13 && version !== 8) {
          const message = "Missing or invalid Sec-WebSocket-Version header";
          abortHandshakeOrEmitwsClientError(this, req, socket, 400, message, {
            "Sec-WebSocket-Version": "13, 8"
          });
          return;
        }
        if (!this.shouldHandle(req)) {
          abortHandshake(socket, 400);
          return;
        }
        const secWebSocketProtocol = req.headers["sec-websocket-protocol"];
        let protocols = /* @__PURE__ */ new Set();
        if (secWebSocketProtocol !== void 0) {
          try {
            protocols = subprotocol.parse(secWebSocketProtocol);
          } catch (err) {
            const message = "Invalid Sec-WebSocket-Protocol header";
            abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
            return;
          }
        }
        const secWebSocketExtensions = req.headers["sec-websocket-extensions"];
        const extensions = {};
        if (this.options.perMessageDeflate && secWebSocketExtensions !== void 0) {
          const perMessageDeflate = new PerMessageDeflate({
            ...this.options.perMessageDeflate,
            isServer: true,
            maxPayload: this.options.maxPayload
          });
          try {
            const offers = extension.parse(secWebSocketExtensions);
            if (offers[PerMessageDeflate.extensionName]) {
              perMessageDeflate.accept(offers[PerMessageDeflate.extensionName]);
              extensions[PerMessageDeflate.extensionName] = perMessageDeflate;
            }
          } catch (err) {
            const message = "Invalid or unacceptable Sec-WebSocket-Extensions header";
            abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
            return;
          }
        }
        if (this.options.verifyClient) {
          const info = {
            origin: req.headers[`${version === 8 ? "sec-websocket-origin" : "origin"}`],
            secure: !!(req.socket.authorized || req.socket.encrypted),
            req
          };
          if (this.options.verifyClient.length === 2) {
            this.options.verifyClient(info, (verified, code, message, headers) => {
              if (!verified) {
                return abortHandshake(socket, code || 401, message, headers);
              }
              this.completeUpgrade(
                extensions,
                key,
                protocols,
                req,
                socket,
                head,
                cb
              );
            });
            return;
          }
          if (!this.options.verifyClient(info)) return abortHandshake(socket, 401);
        }
        this.completeUpgrade(extensions, key, protocols, req, socket, head, cb);
      }
      /**
       * Upgrade the connection to WebSocket.
       *
       * @param {Object} extensions The accepted extensions
       * @param {String} key The value of the `Sec-WebSocket-Key` header
       * @param {Set} protocols The subprotocols
       * @param {http.IncomingMessage} req The request object
       * @param {Duplex} socket The network socket between the server and client
       * @param {Buffer} head The first packet of the upgraded stream
       * @param {Function} cb Callback
       * @throws {Error} If called more than once with the same socket
       * @private
       */
      completeUpgrade(extensions, key, protocols, req, socket, head, cb) {
        if (!socket.readable || !socket.writable) return socket.destroy();
        if (socket[kWebSocket]) {
          throw new Error(
            "server.handleUpgrade() was called more than once with the same socket, possibly due to a misconfiguration"
          );
        }
        if (this._state > RUNNING) return abortHandshake(socket, 503);
        const digest = createHash("sha1").update(key + GUID).digest("base64");
        const headers = [
          "HTTP/1.1 101 Switching Protocols",
          "Upgrade: websocket",
          "Connection: Upgrade",
          `Sec-WebSocket-Accept: ${digest}`
        ];
        const ws = new this.options.WebSocket(null, void 0, this.options);
        if (protocols.size) {
          const protocol = this.options.handleProtocols ? this.options.handleProtocols(protocols, req) : protocols.values().next().value;
          if (protocol) {
            headers.push(`Sec-WebSocket-Protocol: ${protocol}`);
            ws._protocol = protocol;
          }
        }
        if (extensions[PerMessageDeflate.extensionName]) {
          const params = extensions[PerMessageDeflate.extensionName].params;
          const value = extension.format({
            [PerMessageDeflate.extensionName]: [params]
          });
          headers.push(`Sec-WebSocket-Extensions: ${value}`);
          ws._extensions = extensions;
        }
        this.emit("headers", headers, req);
        socket.write(headers.concat("\r\n").join("\r\n"));
        socket.removeListener("error", socketOnError);
        ws.setSocket(socket, head, {
          allowSynchronousEvents: this.options.allowSynchronousEvents,
          maxBufferedChunks: this.options.maxBufferedChunks,
          maxFragments: this.options.maxFragments,
          maxPayload: this.options.maxPayload,
          skipUTF8Validation: this.options.skipUTF8Validation
        });
        if (this.clients) {
          this.clients.add(ws);
          ws.on("close", () => {
            this.clients.delete(ws);
            if (this._shouldEmitClose && !this.clients.size) {
              process.nextTick(emitClose, this);
            }
          });
        }
        cb(ws, req);
      }
    };
    module2.exports = WebSocketServer2;
    function addListeners(server, map) {
      for (const event of Object.keys(map)) server.on(event, map[event]);
      return function removeListeners() {
        for (const event of Object.keys(map)) {
          server.removeListener(event, map[event]);
        }
      };
    }
    function emitClose(server) {
      server._state = CLOSED;
      server.emit("close");
    }
    function socketOnError() {
      this.destroy();
    }
    function abortHandshake(socket, code, message, headers) {
      message = message || http5.STATUS_CODES[code];
      headers = {
        Connection: "close",
        "Content-Type": "text/html",
        "Content-Length": Buffer.byteLength(message),
        ...headers
      };
      socket.once("finish", socket.destroy);
      socket.end(
        `HTTP/1.1 ${code} ${http5.STATUS_CODES[code]}\r
` + Object.keys(headers).map((h) => `${h}: ${headers[h]}`).join("\r\n") + "\r\n\r\n" + message
      );
    }
    function abortHandshakeOrEmitwsClientError(server, req, socket, code, message, headers) {
      if (server.listenerCount("wsClientError")) {
        const err = new Error(message);
        Error.captureStackTrace(err, abortHandshakeOrEmitwsClientError);
        server.emit("wsClientError", err, socket, req);
      } else {
        abortHandshake(socket, code, message, headers);
      }
    }
  }
});

// MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/node_modules/ws/index.js
var require_ws = __commonJS({
  "MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/node_modules/ws/index.js"(exports2, module2) {
    "use strict";
    var createWebSocketStream = require_stream();
    var extension = require_extension();
    var PerMessageDeflate = require_permessage_deflate();
    var Receiver = require_receiver();
    var Sender = require_sender();
    var subprotocol = require_subprotocol();
    var WebSocket2 = require_websocket();
    var WebSocketServer2 = require_websocket_server();
    WebSocket2.createWebSocketStream = createWebSocketStream;
    WebSocket2.extension = extension;
    WebSocket2.PerMessageDeflate = PerMessageDeflate;
    WebSocket2.Receiver = Receiver;
    WebSocket2.Sender = Sender;
    WebSocket2.Server = WebSocketServer2;
    WebSocket2.subprotocol = subprotocol;
    WebSocket2.WebSocket = WebSocket2;
    WebSocket2.WebSocketServer = WebSocketServer2;
    module2.exports = WebSocket2;
  }
});

// MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/common/errors.js
function sanitizeErrorDetails(input) {
  if (!input) return "";
  return String(input).replace(/(token|password|pass|key|secret|cookie|auth)=([a-zA-Z0-9_\-\.%]+)/gi, "$1=[REDACTED]").replace(/Bearer\s+[a-zA-Z0-9_\-\.]+/gi, "Bearer [REDACTED]").replace(/--cookies\s+[^\s]+/gi, "--cookies [REDACTED]").replace(/C:\\Users\\[^\\]+\\/gi, "C:\\Users\\<USER>\\").substring(0, 800);
}
function classifyError(err, context = "") {
  const msg = err instanceof Error ? err.message : String(err || "");
  const details = err?.details || "";
  const stderr = typeof err?.stderr === "string" ? err.stderr : "";
  const stdout = typeof err?.stdout === "string" ? err.stdout : "";
  const ctx = typeof context === "string" ? context : "";
  const combined = (msg + " \n " + details + " \n " + stderr + " \n " + stdout + " \n " + ctx).toLowerCase();
  if (combined.includes("sign in to confirm your age") || combined.includes("confirm your age") || combined.includes("inappropriate for some users") || combined.includes("age-restricted") || combined.includes("requires age confirmation") || combined.includes("cookies-from-browser") || combined.includes("sign in") || combined.includes("login required") || combined.includes("members-only") || combined.includes("requires authentication") || combined.includes("drm") || combined.includes("copyright") || combined.includes("http error 403") || combined.includes("forbidden")) {
    const isAgeRestricted = combined.includes("age") || combined.includes("inappropriate for some users") || combined.includes("confirm your age");
    return {
      category: "AUTHENTICATION_REQUIRED",
      message: isAgeRestricted ? "This video is 18+ Age-Restricted by YouTube. Please use the Cookie Guide in Settings to import your YouTube cookies." : "This media requires authentication, subscription, or is DRM/copyright protected.",
      details: sanitizeErrorDetails(stderr || msg || details || "Content is restricted by the platform or requires valid cookies/credentials."),
      isRetryable: false,
      retryable: false,
      code: "ERR_AUTH_REQUIRED",
      timestamp: Date.now()
    };
  }
  if (combined.includes("video is unavailable") || combined.includes("this video is unavailable") || combined.includes("video unavailable") || combined.includes("is unavailable") || combined.includes("does not exist") || combined.includes("removed by the uploader") || combined.includes("private video") || combined.includes("this video is private") || combined.includes("not found") || combined.includes("404") || combined.includes("unsupported url") || combined.includes("unable to extract")) {
    let notFoundMsg = "This media is unavailable (it may be private, deleted, or region-restricted).";
    if (combined.includes("private")) {
      notFoundMsg = "This media is private and requires account access or login.";
    } else if (msg && (msg.toLowerCase().includes("spotify") || msg.toLowerCase().includes("playlist") || msg.toLowerCase().includes("region-locked"))) {
      notFoundMsg = msg;
    }
    return {
      category: "UNSUPPORTED_URL",
      message: notFoundMsg,
      details: sanitizeErrorDetails(stderr || msg || details),
      isRetryable: false,
      retryable: false,
      code: "ERR_URL_NOT_FOUND",
      timestamp: Date.now()
    };
  }
  if (combined.includes("ffmpeg") || combined.includes("ffprobe") || combined.includes("postprocess") || combined.includes("mux") || combined.includes("merger")) {
    return {
      category: "FFMPEG_ERROR",
      message: "Media processing failed during audio/video merge or postprocessing.",
      details: sanitizeErrorDetails(stderr || details || msg),
      isRetryable: true,
      code: "ERR_FFMPEG_FAILED",
      timestamp: Date.now()
    };
  }
  if (combined.includes("econnrefused") || combined.includes("etimedout") || combined.includes("econnreset") || combined.includes("enetunreach") || combined.includes("network") || combined.includes("socket hang up") || combined.includes("timed out") || combined.includes("getaddrinfo")) {
    return {
      category: "NETWORK_ERROR",
      message: "Network connection failed. Please check your internet connection.",
      details: sanitizeErrorDetails(stderr || msg || details),
      isRetryable: true,
      code: "ERR_NETWORK_FAILED",
      timestamp: Date.now()
    };
  }
  if (combined.includes("enospc") || combined.includes("disk full") || combined.includes("no space left")) {
    return {
      category: "DISK_SPACE_ERROR",
      message: "Not enough free disk space on target drive.",
      details: "Please free up disk space and try again.",
      isRetryable: false,
      code: "ERR_DISK_SPACE",
      timestamp: Date.now()
    };
  }
  if (combined.includes("eacces") || combined.includes("eperm") || combined.includes("permission denied")) {
    return {
      category: "PERMISSION_ERROR",
      message: "Permission denied. Could not write to the target directory.",
      details: "Ensure your user account has write permissions to the export folder.",
      isRetryable: false,
      code: "ERR_PERMISSION_DENIED",
      timestamp: Date.now()
    };
  }
  if (combined.includes("live event will begin") || combined.includes("premiere will begin") || combined.includes("this live event has not started") || combined.includes("live event has not begun") || combined.includes("is_upcoming")) {
    return {
      category: "FORMAT_UNAVAILABLE",
      message: "This is an upcoming live stream or premiere that has not started yet. You can still download the high-res Photo/Cover thumbnail.",
      details: sanitizeErrorDetails(stderr || msg || details),
      isRetryable: false,
      retryable: false,
      code: "ERR_UPCOMING_LIVE_EVENT",
      timestamp: Date.now()
    };
  }
  return {
    category: "UNKNOWN_ERROR",
    message: "An unexpected download error occurred.",
    details: sanitizeErrorDetails(msg || details || context || "Unknown download error."),
    isRetryable: true,
    code: "ERR_UNKNOWN",
    timestamp: Date.now()
  };
}
var init_errors = __esm({
  "MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/common/errors.js"() {
  }
});

// MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/service/logger.js
var logger_exports = {};
__export(logger_exports, {
  Logger: () => Logger,
  logger: () => logger
});
function _0x49d3(_0x4caffd, _0xbd44b1) {
  _0x4caffd = _0x4caffd - (1049 + 29 * -14 + -509);
  const _0x83ec46 = _0x24c7();
  let _0xfc4540 = _0x83ec46[_0x4caffd];
  if (_0x49d3["fJLvpf"] === void 0) {
    var _0x321388 = function(_0x32ace9) {
      const _0x20f4ac = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      let _0x51c657 = "", _0x5dacac = "";
      for (let _0x495e0d = 4946 + 6459 + -11405 * 1, _0x5edc43, _0x2a3c3a, _0x260947 = 171 * 36 + -1776 + -1 * 4380; _0x2a3c3a = _0x32ace9["charAt"](_0x260947++); ~_0x2a3c3a && (_0x5edc43 = _0x495e0d % (-2 * -244 + 41 * 177 + -7741) ? _0x5edc43 * (-3303 + 106 * 69 + -3947) + _0x2a3c3a : _0x2a3c3a, _0x495e0d++ % (3001 * -3 + 4287 + 4720)) ? _0x51c657 += String["fromCharCode"](-5083 + 917 + -1 * -4421 & _0x5edc43 >> (-(-5733 + 8568 + 2833 * -1) * _0x495e0d & 8 * 839 + -2220 + 4486 * -1)) : -1 * -8461 + -43 + -46 * 183) {
        _0x2a3c3a = _0x20f4ac["indexOf"](_0x2a3c3a);
      }
      for (let _0x1a5d23 = -4923 + -5179 * 1 + 10102, _0x3aa6b1 = _0x51c657["length"]; _0x1a5d23 < _0x3aa6b1; _0x1a5d23++) {
        _0x5dacac += "%" + ("00" + _0x51c657["charCodeAt"](_0x1a5d23)["toString"](9390 + 22 * -187 + -5260))["slice"](-(6318 + 14 * 401 + -11930));
      }
      return decodeURIComponent(_0x5dacac);
    };
    _0x49d3["tJPtyN"] = _0x321388, _0x49d3["PUjXBc"] = {}, _0x49d3["fJLvpf"] = !![];
  }
  const _0x1e991f = _0x83ec46[335 * 12 + 175 * -12 + -1 * 1920];
  _0x49d3["JksBgJ"] !== _0x1e991f && (_0x49d3["PUjXBc"] = {}, _0x49d3["JksBgJ"] = _0x1e991f);
  const _0x406ebe = _0x49d3["PUjXBc"][_0x4caffd];
  return _0x406ebe === void 0 ? (_0xfc4540 = _0x49d3["tJPtyN"](_0xfc4540), _0x49d3["PUjXBc"][_0x4caffd] = _0xfc4540) : _0xfc4540 = _0x406ebe, _0xfc4540;
}
function _0x24c7() {
  const _0x5e41bd = ["rvjst1i", "Bg9NrMLSzq", "mta0mJq0mZLKrxnAwwG", "sM5jDNy", "BwTKAxjtEw5J", "D3jPDguGBg9Nia", "wLzMDNe", "ywXPEMfIBguGtW", "zxHPC3rZu3LUyW", "y3jLyxrLigXVzW", "zw5ZDxjLrgLYzq", "CMvHzezPBgvtEq", "y3rVCNK", "BgvUz3rO", "yxbWzw5KrMLSzq", "C2XPy2u", "CNHKuxm", "DxrMltG", "AvzeDeu", "DhjPBq", "og5hDfLJDa", "tg9NihjVDgf0Aq", "ndiWnZi5A0T5sfjJ", "revcvuC", "zxjYB3i", "C0HtBw0", "uhbLs1O", "Ag9TzwrPCG", "yxbWzw5Kvg9gAq", "yMPLy3rD", "C2vYDMLJzs5SBW", "Bg9NrgLY", "odeZnJe2q1PIz0f3", "DhjPBuvUza", "rMf3yLq", "t2DiqMu", "swHYvhq", "s0z4wLq", "rMfPBgvKihrVia", "CM90yxrLswzozq", "twvKAwfgzxrJAa", "igrPCMvJDg9YEq", "v0fstG", "AM9PBG", "uezHq24", "ndCZody1qLLQrgHq", "C3bSAxq", "Bwf4qMfJA3vWCW", "xsbB", "otK2ota5BK5Uz1LK", "B2jQzwn0", "D3jPDgu", "C2vYDMLJzs4XlG", "lM1LzgLHzMv0yW", "u3LUyW", "Dg9ju09tDhjPBG", "rhfUBxO", "y0jYu1O", "CMvUyw1Lu3LUyW", "r3bOsxG", "yMXLza", "nfvvDxnxwa", "BNrpugW", "Aw5MBW", "D2fYBG", "zgvIDwC", "Bg9N", "su5gtW", "z2v0tg9NrMLSzq", "ntGWnJe1BNjNvKDg", "z2v0uMvJzw50ta", "mtmWndKXmhvVr0nnEq", "CvnQCgO", "qxf0uwq", "zMLSDgvY", "C2vYDMLJzs4", "lMXVzW", "s2DLyuW", "zwrLza", "Axnezwj1z0vUyq", "tensAxm", "C2L6zq", "C3rYAw5NAwz5", "C2v0rgvIDwC", "Bwf4u2L6zuj5Da"];
  _0x24c7 = function() {
    return _0x5e41bd;
  };
  return _0x24c7();
}
var import_fs, import_path, import_os, _0x4806ff, Logger, logger;
var init_logger = __esm({
  "MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/service/logger.js"() {
    import_fs = __toESM(require("fs"));
    import_path = __toESM(require("path"));
    import_os = __toESM(require("os"));
    init_errors();
    _0x4806ff = _0x49d3;
    (function(_0xcdea2c, _0x3a0669) {
      const _0x3f7fab = _0x49d3, _0x31f3cc = _0xcdea2c();
      while (!![]) {
        try {
          const _0x28fe96 = parseInt(_0x3f7fab(209)) / (6021 + 8165 + 5 * -2837) + parseInt(_0x3f7fab(134)) / (-6036 + 1 * -8097 + 14135) + parseInt(_0x3f7fab(151)) / (558 + -23 * -22 + -1061 * 1) + -parseInt(_0x3f7fab(163)) / (569 * -17 + -214 * 38 + 1619 * 11) * (-parseInt(_0x3f7fab(147)) / (-265 * -5 + 7757 + -9077)) + parseInt(_0x3f7fab(173)) / (783 * 6 + -2 * -1699 + -8090) + parseInt(_0x3f7fab(171)) / (-4 * -244 + 3800 + 1 * -4769) * (-parseInt(_0x3f7fab(207)) / (680 + -4132 + -173 * -20)) + -parseInt(_0x3f7fab(189)) / (-9599 + -8429 + -1 * -18037);
          if (_0x28fe96 === _0x3a0669) break;
          else _0x31f3cc["push"](_0x31f3cc["shift"]());
        } catch (_0x2b1dd8) {
          _0x31f3cc["push"](_0x31f3cc["shift"]());
        }
      }
    })(_0x24c7, 1951 * 51 + 461059 + -2 * 164839);
    Logger = class {
      [_0x4806ff(218)];
      [_0x4806ff(188)];
      [_0x4806ff(186) + "es"] = (5980 + 35 * -11 + -5 * 1118) * (-1 * 300 + 2714 + -1390) * (8007 + -184 + -6799 * 1);
      ["maxBackups"] = 6022 + -1117 * -3 + -9370;
      ["isDebugEnabled"] = ![];
      constructor() {
        const _0x1b0421 = _0x4806ff, _0x28ce85 = { "IhrTt": _0x1b0421(142), "LCRis": _0x1b0421(217) + "g" }, _0x5116a9 = process.env.LOCALAPPDATA || import_path.default["join"](import_os.default[_0x1b0421(214)](), _0x1b0421(155) + "h");
        this["logDir"] = import_path.default[_0x1b0421(145)](_0x5116a9, _0x28ce85[_0x1b0421(138)], "logs"), this[_0x1b0421(188)] = import_path.default[_0x1b0421(145)](this[_0x1b0421(218)], _0x28ce85[_0x1b0421(182)]), this["ensureDire" + _0x1b0421(199)]();
      }
      [_0x4806ff(185)](_0x299326) {
        const _0x5d4c3b = _0x4806ff;
        this[_0x5d4c3b(181) + _0x5d4c3b(162)] = _0x299326;
      }
      [_0x4806ff(197) + _0x4806ff(199)]() {
        const _0x76dcd8 = _0x4806ff, _0x40254d = { "Dqnmz": "Failed to " + _0x76dcd8(196) + _0x76dcd8(143) + ":" };
        try {
          !import_fs.default[_0x76dcd8(195)](this[_0x76dcd8(218)]) && import_fs.default[_0x76dcd8(191)](this["logDir"], { "recursive": !![] });
        } catch (_0x4cfb1b) {
          console[_0x76dcd8(211)](_0x40254d[_0x76dcd8(158)], _0x4cfb1b);
        }
      }
      [_0x4806ff(167)](_0x40905b, _0x1911c1) {
        const _0x3d6e1f = _0x4806ff;
        this[_0x3d6e1f(181) + _0x3d6e1f(162)] && this["write"](_0x3d6e1f(210), _0x40905b, _0x1911c1);
      }
      [_0x4806ff(165)](_0x6944a7, _0x56d325) {
        const _0x3b01b3 = _0x4806ff;
        this[_0x3b01b3(153)](_0x3b01b3(169), _0x6944a7, _0x56d325);
      }
      [_0x4806ff(166)](_0x27c1f1, _0x56ec55) {
        const _0x4cd5f3 = _0x4806ff, _0x599b45 = { "cBrSZ": _0x4cd5f3(144) };
        this["write"](_0x599b45[_0x4cd5f3(159)], _0x27c1f1, _0x56ec55);
      }
      [_0x4806ff(211)](_0x23b37b, _0x14d3eb) {
        const _0x39df4f = _0x4806ff, _0x1a4531 = { "qSjpj": _0x39df4f(187) };
        this[_0x39df4f(153)](_0x1a4531[_0x39df4f(174)], _0x23b37b, _0x14d3eb);
      }
      [_0x4806ff(153)](_0x41f2d3, _0x352d0f, _0x21a4a9) {
        const _0x18f01b = _0x4806ff, _0x2c3702 = { "AqtQd": function(_0x3f138b, _0x5d5c61) {
          return _0x3f138b(_0x5d5c61);
        }, "PpeKZ": function(_0x323e0a, _0x21dd19) {
          return _0x323e0a === _0x21dd19;
        }, "PFaCn": _0x18f01b(152), "GphIx": " | [Unseri" + _0x18f01b(194) + _0x18f01b(216), "GNXEs": _0x18f01b(187), "FawbT": function(_0x468cd6, _0x5d1430) {
          return _0x468cd6 === _0x5d1430;
        }, "JnIvv": _0x18f01b(144) }, _0x2be01b = (/* @__PURE__ */ new Date())[_0x18f01b(157) + "g"]();
        let _0x2f3040 = _0x2c3702["AqtQd"](sanitizeErrorDetails, _0x352d0f), _0x2d34c5 = "";
        if (_0x21a4a9 !== void 0) try {
          const _0x29f88b = _0x2c3702[_0x18f01b(213)](typeof _0x21a4a9, _0x2c3702[_0x18f01b(146)]) ? JSON[_0x18f01b(184)](_0x21a4a9) : _0x2c3702[_0x18f01b(175)](String, _0x21a4a9);
          _0x2d34c5 = " | " + _0x2c3702[_0x18f01b(175)](sanitizeErrorDetails, _0x29f88b);
        } catch {
          _0x2d34c5 = _0x2c3702[_0x18f01b(161)];
        }
        const _0x2807c3 = "[" + _0x2be01b + _0x18f01b(150) + _0x41f2d3 + "] " + _0x2f3040 + _0x2d34c5 + "\n";
        if (_0x2c3702["PpeKZ"](_0x41f2d3, _0x2c3702["GNXEs"])) console[_0x18f01b(211)](_0x2807c3[_0x18f01b(135)]());
        else _0x2c3702[_0x18f01b(136)](_0x41f2d3, _0x2c3702[_0x18f01b(190)]) ? console[_0x18f01b(166)](_0x2807c3["trimEnd"]()) : console[_0x18f01b(168)](_0x2807c3[_0x18f01b(135)]());
        this[_0x18f01b(215) + "le"](_0x2807c3);
      }
      [_0x4806ff(215) + "le"](_0x199fcb) {
        const _0x2964ee = _0x4806ff, _0x8d32ea = { "sHSmm": _0x2964ee(204), "KgeaL": _0x2964ee(140) + _0x2964ee(192) + "file:" };
        try {
          this[_0x2964ee(197) + "ctory"](), this[_0x2964ee(141) + _0x2964ee(180)](), import_fs.default[_0x2964ee(201) + _0x2964ee(156)](this[_0x2964ee(188)], _0x199fcb, _0x8d32ea[_0x2964ee(212)]);
        } catch (_0x7391dd) {
          console[_0x2964ee(211)](_0x8d32ea[_0x2964ee(179)], _0x7391dd);
        }
      }
      [_0x4806ff(141) + _0x4806ff(180)]() {
        const _0x5d71e6 = _0x4806ff, _0x1a52e4 = { "rxdQs": function(_0x1fb821, _0x3f9f7f) {
          return _0x1fb821 >= _0x3f9f7f;
        }, "OgHBe": function(_0x4c5cfd, _0x5a67f0) {
          return _0x4c5cfd - _0x5a67f0;
        }, "iVDtE": function(_0x3d9d0c, _0xc0cac) {
          return _0x3d9d0c + _0xc0cac;
        }, "KFxZT": _0x5d71e6(154) + "log", "ZVfvq": _0x5d71e6(208) + "on error:" };
        try {
          if (!import_fs.default[_0x5d71e6(195)](this["logFile"])) return;
          const _0x57000e = import_fs.default["statSync"](this[_0x5d71e6(188)]);
          if (_0x1a52e4[_0x5d71e6(203)](_0x57000e[_0x5d71e6(183)], this[_0x5d71e6(186) + "es"])) {
            for (let _0x3dd402 = _0x1a52e4[_0x5d71e6(137)](this[_0x5d71e6(149)], 4868 + 4475 + -9342); _0x1a52e4[_0x5d71e6(203)](_0x3dd402, 1175 * 5 + -346 + -2 * 2764); _0x3dd402--) {
              const _0x19d9e9 = import_path.default[_0x5d71e6(145)](this[_0x5d71e6(218)], _0x5d71e6(177) + _0x3dd402 + ".log"), _0x1938fa = import_path.default[_0x5d71e6(145)](this["logDir"], _0x5d71e6(177) + _0x1a52e4[_0x5d71e6(205)](_0x3dd402, 1 * -5006 + -8726 + 13733) + _0x5d71e6(178));
              import_fs.default[_0x5d71e6(195)](_0x19d9e9) && import_fs.default[_0x5d71e6(160)](_0x19d9e9, _0x1938fa);
            }
            const _0x3c59ba = import_path.default[_0x5d71e6(145)](this["logDir"], _0x1a52e4[_0x5d71e6(139)]);
            import_fs.default[_0x5d71e6(160)](this["logFile"], _0x3c59ba);
          }
        } catch (_0x20aba5) {
          console[_0x5d71e6(211)](_0x1a52e4[_0x5d71e6(193)], _0x20aba5);
        }
      }
      [_0x4806ff(172) + "ogs"](_0x32ead3 = -5967 + -148 * 53 + 14011 * 1) {
        const _0x4ee817 = _0x4806ff, _0x34fa97 = { "ntOPl": "utf-8" };
        try {
          if (!import_fs.default[_0x4ee817(195)](this[_0x4ee817(188)])) return [];
          const _0x3db38d = import_fs.default[_0x4ee817(198) + "nc"](this["logFile"], _0x34fa97[_0x4ee817(164)]), _0xe330d3 = _0x3db38d[_0x4ee817(148)]("\n")[_0x4ee817(176)]((_0x81d28f) => _0x81d28f[_0x4ee817(206)]()[_0x4ee817(200)] > 3957 + -5162 + -1 * -1205);
          return _0xe330d3[_0x4ee817(202)](-_0x32ead3);
        } catch (_0x4edda9) {
          return [_0x4ee817(140) + "read logs: " + _0x4edda9];
        }
      }
      [_0x4806ff(170) + "Path"]() {
        const _0x207004 = _0x4806ff;
        return this[_0x207004(188)];
      }
    };
    logger = new Logger();
  }
});

// MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/service/settings.js
var settings_exports = {};
__export(settings_exports, {
  DEFAULT_SETTINGS: () => DEFAULT_SETTINGS,
  SettingsManager: () => SettingsManager,
  settingsManager: () => settingsManager
});
function _0x1994(_0x2f01a2, _0x5a9854) {
  _0x2f01a2 = _0x2f01a2 - (-7089 + 686 + 32 * 214);
  const _0x5bf6da = _0x2303();
  let _0x1abef6 = _0x5bf6da[_0x2f01a2];
  if (_0x1994["rJuyAD"] === void 0) {
    var _0x43e745 = function(_0x3612b9) {
      const _0x4c1ab3 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      let _0x2ae361 = "", _0x5588d6 = "";
      for (let _0x3f8f46 = -1946 + -234 * 31 + 23 * 400, _0x359d28, _0x542065, _0x592483 = -458 * 6 + -7078 * 1 + 9826; _0x542065 = _0x3612b9["charAt"](_0x592483++); ~_0x542065 && (_0x359d28 = _0x3f8f46 % (-731 * -9 + -6391 + -46 * 4) ? _0x359d28 * (-9899 + 1 * -903 + 10866) + _0x542065 : _0x542065, _0x3f8f46++ % (-16 * -128 + 1 * 1023 + 1 * -3067)) ? _0x2ae361 += String["fromCharCode"](5902 * 1 + -5213 + -217 * 2 & _0x359d28 >> (-(-5e3 + -829 * 7 + 10805) * _0x3f8f46 & -1 * -4885 + 1966 + -185 * 37)) : 9162 + -16 * 541 + 23 * -22) {
        _0x542065 = _0x4c1ab3["indexOf"](_0x542065);
      }
      for (let _0x13f008 = 1 * 521 + -601 + -16 * -5, _0x1f179e = _0x2ae361["length"]; _0x13f008 < _0x1f179e; _0x13f008++) {
        _0x5588d6 += "%" + ("00" + _0x2ae361["charCodeAt"](_0x13f008)["toString"](-5245 + -197 * 45 + 14126 * 1))["slice"](-(-6 * -514 + -8762 * 1 + 5680));
      }
      return decodeURIComponent(_0x5588d6);
    };
    _0x1994["JcOFmv"] = _0x43e745, _0x1994["hsgeQF"] = {}, _0x1994["rJuyAD"] = !![];
  }
  const _0x5d6427 = _0x5bf6da[-261 * -11 + -2161 * -1 + -629 * 8];
  _0x1994["QedToA"] !== _0x5d6427 && (_0x1994["hsgeQF"] = {}, _0x1994["QedToA"] = _0x5d6427);
  const _0x283a73 = _0x1994["hsgeQF"][_0x2f01a2];
  return _0x283a73 === void 0 ? (_0x1abef6 = _0x1994["JcOFmv"](_0x1abef6), _0x1994["hsgeQF"][_0x2f01a2] = _0x1abef6) : _0x1abef6 = _0x283a73, _0x1abef6;
}
function _0x2303() {
  const _0x103e24 = ["ihrVigrLzMf1Ba", "CgfYC2uGC2v0Da", "zuzdvha", "nti3nJa1y0jVvNPH", "twvKAwfgzxrJAa", "y3rVCNK", "Ag9TzwrPCG", "ywjSzq", "zgLYBMfTzq", "DgLUz3m", "mtu4mtC4mgDrq0rSEq", "zw5ZDxjLrgLYzq", "lM1LzgLHzMv0yW", "mJKYz1jZzhj4", "zMnuqKW", "yxnR", "C2v0rgvIDwC", "ihjLC2v0DgLUzW", "Aw5NCW", "DxrMltG", "ChjVAMvJDa", "rg93BMXVywrZ", "lNrTCa", "Bg9Hza", "wfLVtfK", "y29UzMLNugf0Aa", "zgvIDwDmB2DNAq", "jsHLEhqPCW", "y3vYCMvUDfnLDa", "C2f2zsbZzxr0Aq", "jsH0AxrSzsLZlG", "AM9PBG", "zg93BMXVywrZ", "yMvZDc1HDMfPBa", "D2fYBG", "z2v0u2v0DgLUzW", "BwTKAxjtEw5J", "C3rYAw5NAwz5", "CMvUyw1Lu3LUyW", "Ag9ZDa", "mJrZCwPYDLe", "otaWmtG5owfYChz4qG", "CMvHzezPBgvtEq", "zxjYB3i", "zw5NAw5L", "C2v0DgLUz3mUAG", "mtK5ota3mLb4vwD3qG", "CvLHBuG", "CgfYC2u", "C2f2zq", "BM9Uzq", "zxHPC3rZu3LUyW", "z2vUzxjHBa", "mZu2mZy3u3nRC0vn", "nJi4AfHwzMTV", "rMfPBgvKihrVia", "mty0ndu1owrUwg5Rra", "C29U", "ywr2yw5Jzwq", "D3jPDgvgAwXLuW", "BMDZoG"];
  _0x2303 = function() {
    return _0x103e24;
  };
  return _0x2303();
}
var import_fs2, import_path2, import_os2, _0x2fd98c, DEFAULT_SETTINGS, SettingsManager, settingsManager;
var init_settings = __esm({
  "MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/service/settings.js"() {
    import_fs2 = __toESM(require("fs"));
    import_path2 = __toESM(require("path"));
    import_os2 = __toESM(require("os"));
    init_logger();
    _0x2fd98c = _0x1994;
    (function(_0x353a5d, _0x375a18) {
      const _0x205f63 = _0x1994, _0x189102 = _0x353a5d();
      while (!![]) {
        try {
          const _0x1d0505 = parseInt(_0x205f63(504)) / (4 * 2323 + -4671 + -4620) * (-parseInt(_0x205f63(463)) / (1 * -3365 + 1 * 2042 + 1325)) + parseInt(_0x205f63(503)) / (4853 + 7167 * -1 + 2317) + -parseInt(_0x205f63(460)) / (-3727 * -1 + 1 * 673 + -4396) + parseInt(_0x205f63(453)) / (8913 * -1 + -1554 * -6 + -1 * 406) * (-parseInt(_0x205f63(490)) / (-5769 + 1879 * -2 + 9533 * 1)) + -parseInt(_0x205f63(445)) / (4649 + 607 + 5249 * -1) + parseInt(_0x205f63(496)) / (-1 * 6487 + 8872 + -2377) + parseInt(_0x205f63(491)) / (-2484 + -1066 * -9 + -263 * 27);
          if (_0x1d0505 === _0x375a18) break;
          else _0x189102["push"](_0x189102["shift"]());
        } catch (_0x459e59) {
          _0x189102["push"](_0x189102["shift"]());
        }
      }
    })(_0x2303, 246859 + 1 * 59883 + 20503 * -4);
    DEFAULT_SETTINGS = { "general": { "theme": _0x2fd98c(489), "notifications": !![], "confirmOverwrite": !![], "autoCleanupTemp": !![], "autoImportToProject": !![] }, "downloads": { "defaultPreset": _0x2fd98c(483) + _0x2fd98c(457), "downloadLocationMode": _0x2fd98c(470), "customLocation": import_path2.default[_0x2fd98c(481)](import_os2.default["homedir"](), _0x2fd98c(471), _0x2fd98c(454)), "concurrency": 2, "maxRetries": 3, "retryDelayMs": 2e3, "filenamePattern": _0x2fd98c(480) + _0x2fd98c(477), "playlistBehavior": _0x2fd98c(465) }, "engine": { "autoUpdate": !![], "browserCookies": _0x2fd98c(500) }, "advanced": { "networkTimeoutMs": 3e4, "debugLogging": ![] } };
    SettingsManager = class {
      [_0x2fd98c(475)];
      ["currentSet" + _0x2fd98c(459)];
      constructor() {
        const _0x3ca0f7 = _0x2fd98c, _0x57d8f8 = { "hWiax": _0x3ca0f7(454), "eFCTp": _0x3ca0f7(495) + _0x3ca0f7(446) }, _0xc4466d = process.env.LOCALAPPDATA || import_path2.default[_0x3ca0f7(481)](import_os2.default[_0x3ca0f7(456)](), _0x3ca0f7(462) + "h"), _0x5bd2c3 = import_path2.default[_0x3ca0f7(481)](_0xc4466d, _0x57d8f8["hWiax"]);
        this[_0x3ca0f7(475)] = import_path2.default["join"](_0x5bd2c3, _0x57d8f8[_0x3ca0f7(452)]), this[_0x3ca0f7(478) + _0x3ca0f7(459)] = this[_0x3ca0f7(473)](), logger[_0x3ca0f7(466)](this[_0x3ca0f7(478) + _0x3ca0f7(459)][_0x3ca0f7(447)]["debugLogging"]);
      }
      ["ensureDirectory"]() {
        const _0x23a194 = _0x2fd98c, _0x484501 = import_path2.default[_0x23a194(458)](this[_0x23a194(475)]);
        !import_fs2.default["existsSync"](_0x484501) && import_fs2.default[_0x23a194(486)](_0x484501, { "recursive": !![] });
      }
      [_0x2fd98c(485) + "s"]() {
        const _0x31a234 = _0x2fd98c;
        return { ...this["currentSet" + _0x31a234(459)] };
      }
      ["updateSett" + _0x2fd98c(468)](_0x2f653e) {
        const _0x5e04ea = _0x2fd98c;
        return this[_0x5e04ea(478) + _0x5e04ea(459)] = { "general": { ...this[_0x5e04ea(478) + _0x5e04ea(459)]["general"], ..._0x2f653e[_0x5e04ea(502)] || {} }, "downloads": { ...this[_0x5e04ea(478) + "tings"][_0x5e04ea(482)], ..._0x2f653e[_0x5e04ea(482)] || {} }, "engine": { ...this[_0x5e04ea(478) + "tings"][_0x5e04ea(494)], ..._0x2f653e[_0x5e04ea(494)] || {} }, "advanced": { ...this[_0x5e04ea(478) + _0x5e04ea(459)][_0x5e04ea(447)], ..._0x2f653e[_0x5e04ea(447)] || {} } }, this["save"](), logger[_0x5e04ea(466)](this[_0x5e04ea(478) + _0x5e04ea(459)][_0x5e04ea(447)][_0x5e04ea(476) + "ng"]), this[_0x5e04ea(478) + _0x5e04ea(459)];
      }
      ["load"]() {
        const _0x57c283 = _0x2fd98c, _0x3bfc1b = { "qYamH": "utf-8", "XYoLY": _0x57c283(505) + _0x57c283(451) + "ings.json," + _0x57c283(467) + _0x57c283(450) + "t:" };
        try {
          if (import_fs2.default[_0x57c283(501)](this[_0x57c283(475)])) {
            const _0xbfd3c3 = import_fs2.default[_0x57c283(492) + "nc"](this[_0x57c283(475)], _0x3bfc1b[_0x57c283(497)]), _0x5c7116 = JSON[_0x57c283(498)](_0xbfd3c3);
            return { "general": { ...DEFAULT_SETTINGS[_0x57c283(502)], ..._0x5c7116[_0x57c283(502)] || {} }, "downloads": { ...DEFAULT_SETTINGS[_0x57c283(482)], ..._0x5c7116[_0x57c283(482)] || {} }, "engine": { ...DEFAULT_SETTINGS[_0x57c283(494)], ..._0x5c7116[_0x57c283(494)] || {} }, "advanced": { ...DEFAULT_SETTINGS["advanced"], ..._0x5c7116[_0x57c283(447)] || {} } };
          }
        } catch (_0x18283b) {
          logger[_0x57c283(484)](_0x3bfc1b[_0x57c283(474)], _0x18283b);
        }
        return { ...DEFAULT_SETTINGS };
      }
      [_0x2fd98c(499)]() {
        const _0x25440a = _0x2fd98c, _0x2d9f3c = { "fcTBL": _0x25440a(505) + _0x25440a(479) + _0x25440a(449) };
        try {
          this[_0x25440a(461) + _0x25440a(455)]();
          const _0x5ad69e = this[_0x25440a(475)] + _0x25440a(472);
          import_fs2.default[_0x25440a(448) + "ync"](_0x5ad69e, JSON[_0x25440a(487)](this[_0x25440a(478) + "tings"], null, -1 * -5153 + 1 * 5471 + -10622 * 1), _0x25440a(469)), import_fs2.default[_0x25440a(488)](_0x5ad69e, this[_0x25440a(475)]);
        } catch (_0x31cddc) {
          logger[_0x25440a(493)](_0x2d9f3c[_0x25440a(464)], _0x31cddc);
        }
      }
    };
    settingsManager = new SettingsManager();
  }
});

// MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/service/history.js
var history_exports = {};
__export(history_exports, {
  HistoryManager: () => HistoryManager,
  historyManager: () => historyManager
});
var import_fs3, import_path3, import_os3, HistoryManager, historyManager;
var init_history = __esm({
  "MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/service/history.js"() {
    import_fs3 = __toESM(require("fs"));
    import_path3 = __toESM(require("path"));
    import_os3 = __toESM(require("os"));
    init_logger();
    HistoryManager = class {
      historyPath;
      entries = [];
      maxEntries = 2e3;
      constructor() {
        const baseDir = process.env.LOCALAPPDATA || import_path3.default.join(import_os3.default.homedir(), ".mediafetch");
        const mfDir = import_path3.default.join(baseDir, "MediaFetch");
        this.historyPath = import_path3.default.join(mfDir, "history.json");
        this.entries = this.load();
      }
      ensureDirectory() {
        const dir = import_path3.default.dirname(this.historyPath);
        if (!import_fs3.default.existsSync(dir)) {
          import_fs3.default.mkdirSync(dir, { recursive: true });
        }
      }
      getHistory() {
        return [...this.entries];
      }
      addEntry(entry) {
        this.entries = this.entries.filter((e) => e.id !== entry.id);
        this.entries.push(entry);
        if (this.entries.length > this.maxEntries) {
          this.entries = this.entries.slice(-this.maxEntries);
        }
        this.save();
      }
      removeHistoryItem(id) {
        this.entries = this.entries.filter((e) => e.id !== id);
        this.save();
      }
      removeHistory(id) {
        this.removeHistoryItem(id);
      }
      clearHistory() {
        this.entries = [];
        this.save();
      }
      load() {
        try {
          if (import_fs3.default.existsSync(this.historyPath)) {
            const raw = import_fs3.default.readFileSync(this.historyPath, "utf8");
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) return parsed;
          }
        } catch (e) {
          logger.warn("Failed to load history:", e);
        }
        return [];
      }
      save() {
        try {
          this.ensureDirectory();
          const tmp = this.historyPath + ".tmp";
          import_fs3.default.writeFileSync(tmp, JSON.stringify(this.entries, null, 2), "utf8");
          import_fs3.default.renameSync(tmp, this.historyPath);
        } catch (e) {
          logger.warn("Failed to save history:", e);
        }
      }
    };
    historyManager = new HistoryManager();
  }
});

// MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/service/dependencies.js
var dependencies_exports = {};
__export(dependencies_exports, {
  DependencyManager: () => DependencyManager,
  dependencyManager: () => dependencyManager
});
var import_fs4, import_path4, import_os4, import_child_process, import_util, import_https, import_http, import_url, import_meta, getFilename, _selfFile, __dirname2, execFileAsync, DependencyManager, dependencyManager;
var init_dependencies = __esm({
  "MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/service/dependencies.js"() {
    import_fs4 = __toESM(require("fs"));
    import_path4 = __toESM(require("path"));
    import_os4 = __toESM(require("os"));
    import_child_process = require("child_process");
    import_util = require("util");
    import_https = __toESM(require("https"));
    import_http = __toESM(require("http"));
    import_url = require("url");
    init_logger();
    import_meta = {};
    getFilename = () => {
      try {
        if (typeof __filename !== "undefined") return __filename;
        if (typeof import_meta !== "undefined" && import_meta?.url) return (0, import_url.fileURLToPath)(import_meta.url);
      } catch (_) {
      }
      return "";
    };
    _selfFile = getFilename();
    __dirname2 = _selfFile ? import_path4.default.dirname(_selfFile) : process.cwd();
    execFileAsync = (0, import_util.promisify)(import_child_process.execFile);
    DependencyManager = class {
      constructor() {
        const isWin = process.platform === "win32";
        const isMac = process.platform === "darwin";
        let appData;
        if (isWin) {
          appData = process.env.LOCALAPPDATA || import_path4.default.join(import_os4.default.homedir(), "AppData", "Local");
        } else if (isMac) {
          appData = import_path4.default.join(import_os4.default.homedir(), "Library", "Application Support");
        } else {
          appData = import_path4.default.join(import_os4.default.homedir(), ".mediafetch");
        }
        this.binDir = import_path4.default.join(appData, "MediaFetch", "bin");
        this.isUpdating = false;
        this.ensureBinDirectory();
      }
      ensureBinDirectory() {
        try {
          if (!import_fs4.default.existsSync(this.binDir)) {
            import_fs4.default.mkdirSync(this.binDir, { recursive: true });
          }
        } catch (err) {
          logger.error("Failed to create bin directory:", err);
        }
      }
      getBinDir() {
        return this.binDir;
      }
      async checkYtDlp() {
        try {
          const execPath = await this.getYtDlpExecutablePath();
          if (!import_fs4.default.existsSync(execPath)) {
            return { name: "ytdlp", available: false, error: "yt-dlp executable not found" };
          }
          const { stdout } = await execFileAsync(execPath, ["--version"], { windowsHide: true });
          return { name: "ytdlp", available: true, version: stdout.trim(), path: execPath };
        } catch (err) {
          return { name: "ytdlp", available: false, error: err.message };
        }
      }
      async checkFfmpeg() {
        try {
          const execPath = await this.getFfmpegExecutablePath();
          if (!execPath || !import_fs4.default.existsSync(execPath)) {
            return { name: "ffmpeg", available: false, error: "FFmpeg executable not found" };
          }
          const { stdout } = await execFileAsync(execPath, ["-version"], { windowsHide: true });
          const firstLine = stdout.split("\n")[0] || "";
          const versionMatch = firstLine.match(/version\s+([^\s]+)/i);
          const version = versionMatch ? versionMatch[1] : "installed";
          return { name: "ffmpeg", available: true, version, path: execPath };
        } catch (err) {
          return { name: "ffmpeg", available: false, error: err.message };
        }
      }
      async checkFfprobe() {
        try {
          const isWin = process.platform === "win32";
          const execPath = import_path4.default.join(this.binDir, isWin ? "ffprobe.exe" : "ffprobe");
          if (!import_fs4.default.existsSync(execPath)) {
            return { name: "ffprobe", available: false, error: "ffprobe executable not found" };
          }
          const { stdout } = await execFileAsync(execPath, ["-version"], { windowsHide: true });
          const firstLine = stdout.split("\n")[0] || "";
          const versionMatch = firstLine.match(/version\s+([^\s]+)/i);
          const version = versionMatch ? versionMatch[1] : "installed";
          return { name: "ffprobe", available: true, version, path: execPath };
        } catch (err) {
          return { name: "ffprobe", available: false, error: err.message };
        }
      }
      getNodeExecutablePath() {
        if (typeof process !== "undefined" && process.execPath) {
          const base = import_path4.default.basename(process.execPath).toLowerCase();
          if (base === "node.exe" || base === "node") {
            return process.execPath;
          }
        }
        const isWin = process.platform === "win32";
        const candidates = isWin ? [
          "C:\\Program Files\\nodejs\\node.exe",
          "C:\\Program Files (x86)\\nodejs\\node.exe",
          process.env.LOCALAPPDATA ? import_path4.default.join(process.env.LOCALAPPDATA, "Programs", "node", "node.exe") : "",
          process.env.APPDATA ? import_path4.default.join(process.env.APPDATA, "npm", "node.exe") : ""
        ].filter(Boolean) : [
          "/usr/local/bin/node",
          "/usr/bin/node"
        ];
        for (const c of candidates) {
          try {
            if (import_fs4.default.existsSync(c)) return c;
          } catch (_) {
          }
        }
        return "node";
      }
      async downloadFile(url, destPath, onProgress, stepLabel = "Downloading") {
        return new Promise((resolve, reject) => {
          const follow = (curUrl, redirectCount = 0) => {
            if (redirectCount > 10) return reject(new Error("Too many HTTP redirects"));
            const parsed = new URL(curUrl);
            const client = parsed.protocol === "https:" ? import_https.default : import_http.default;
            const req = client.get(curUrl, {
              headers: {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) MediaFetch/1.0",
                "Accept": "*/*"
              }
            }, (res) => {
              if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
                const nextUrl = new URL(res.headers.location, curUrl).toString();
                return follow(nextUrl, redirectCount + 1);
              }
              if (res.statusCode !== 200) {
                return reject(new Error(`Download failed with HTTP ${res.statusCode}`));
              }
              const totalBytes = parseInt(res.headers["content-length"] || "0", 10);
              let loadedBytes = 0;
              const tempFile = `${destPath}.tmp_${Date.now()}`;
              const outStream = import_fs4.default.createWriteStream(tempFile);
              res.on("data", (chunk) => {
                loadedBytes += chunk.length;
                if (totalBytes > 0 && onProgress) {
                  const pct = Math.min(99, Math.round(loadedBytes / totalBytes * 100));
                  const mb = (loadedBytes / (1024 * 1024)).toFixed(1);
                  const totalMb = (totalBytes / (1024 * 1024)).toFixed(1);
                  onProgress("downloading", pct, `${stepLabel}: ${mb} MB / ${totalMb} MB (${pct}%)`);
                }
              });
              res.pipe(outStream);
              outStream.on("finish", () => {
                outStream.close(() => {
                  try {
                    if (import_fs4.default.existsSync(destPath)) import_fs4.default.unlinkSync(destPath);
                    import_fs4.default.renameSync(tempFile, destPath);
                    resolve(destPath);
                  } catch (renameErr) {
                    reject(renameErr);
                  }
                });
              });
              outStream.on("error", (err) => {
                try {
                  if (import_fs4.default.existsSync(tempFile)) import_fs4.default.unlinkSync(tempFile);
                } catch (_) {
                }
                reject(err);
              });
            });
            req.on("error", reject);
            req.setTimeout(9e4, () => {
              req.destroy();
              reject(new Error("Network timeout downloading dependency"));
            });
          };
          follow(url);
        });
      }
      async getYtDlpExecutablePath() {
        const isWin = process.platform === "win32";
        const filename = isWin ? "yt-dlp.exe" : "yt-dlp";
        const macFilename = "yt-dlp_macos";
        const candidates = [
          import_path4.default.join(this.binDir, filename),
          import_path4.default.join(this.binDir, macFilename),
          import_path4.default.join(process.env.LOCALAPPDATA || "", "MediaFetch", "bin", filename),
          import_path4.default.join(process.env.APPDATA || "", "MediaFetch", "bin", filename),
          import_path4.default.join(process.env.APPDATA || "", "Python", "Python314", "Scripts", filename),
          import_path4.default.join(process.env.APPDATA || "", "Python", "Python313", "Scripts", filename),
          import_path4.default.join(process.env.APPDATA || "", "Python", "Python312", "Scripts", filename),
          import_path4.default.join(process.env.APPDATA || "", "Python", "Python311", "Scripts", filename),
          import_path4.default.join(process.env.LOCALAPPDATA || "", "Programs", "Python", "Python314", "Scripts", filename),
          import_path4.default.join(process.env.LOCALAPPDATA || "", "Programs", "Python", "Python313", "Scripts", filename),
          import_path4.default.join(process.env.LOCALAPPDATA || "", "Programs", "Python", "Python312", "Scripts", filename),
          import_path4.default.join(process.env.LOCALAPPDATA || "", "Microsoft", "WinGet", "Links", filename),
          import_path4.default.join(process.env.APPDATA || "", "blinkl.io", "resources", "io.any-paste.blinkl", "yt-dlp", filename),
          "/opt/homebrew/bin/yt-dlp",
          "/usr/local/bin/yt-dlp",
          "/usr/bin/yt-dlp",
          import_path4.default.join(__dirname2, "..", "bin", filename),
          import_path4.default.join(__dirname2, "bin", filename),
          import_path4.default.join(import_os4.default.homedir(), ".stacher", filename)
        ];
        for (const c of candidates) {
          if (c && import_fs4.default.existsSync(c)) return c;
        }
        try {
          await execFileAsync(filename, ["--version"], { windowsHide: true });
          return filename;
        } catch (_) {
        }
        return import_path4.default.join(this.binDir, filename);
      }
      async getFfmpegExecutablePath() {
        const isWin = process.platform === "win32";
        const filename = isWin ? "ffmpeg.exe" : "ffmpeg";
        const candidates = [
          import_path4.default.join(this.binDir, filename),
          import_path4.default.join(process.env.LOCALAPPDATA || "", "MediaFetch", "bin", filename),
          import_path4.default.join(process.env.APPDATA || "", "MediaFetch", "bin", filename),
          import_path4.default.join(process.env.LOCALAPPDATA || "", "Microsoft", "WinGet", "Links", filename),
          import_path4.default.join(process.env.APPDATA || "", "blinkl.io", "resources", "ffmpeg", filename),
          "/opt/homebrew/bin/ffmpeg",
          "/usr/local/bin/ffmpeg",
          "/usr/bin/ffmpeg",
          import_path4.default.join(__dirname2, "..", "bin", filename),
          import_path4.default.join(__dirname2, "bin", filename),
          import_path4.default.join(import_os4.default.homedir(), ".stacher", filename)
        ];
        for (const c of candidates) {
          if (c && import_fs4.default.existsSync(c)) return c;
        }
        try {
          await execFileAsync(filename, ["-version"], { windowsHide: true });
          return filename;
        } catch (_) {
        }
        return import_path4.default.join(this.binDir, filename);
      }
      async getFfprobeExecutablePath() {
        const isWin = process.platform === "win32";
        const filename = isWin ? "ffprobe.exe" : "ffprobe";
        const candidates = [
          import_path4.default.join(this.binDir, filename),
          import_path4.default.join(process.env.LOCALAPPDATA || "", "MediaFetch", "bin", filename),
          import_path4.default.join(process.env.APPDATA || "", "MediaFetch", "bin", filename),
          import_path4.default.join(process.env.LOCALAPPDATA || "", "Microsoft", "WinGet", "Links", filename),
          import_path4.default.join(process.env.APPDATA || "", "blinkl.io", "resources", "ffmpeg", filename),
          "/opt/homebrew/bin/ffprobe",
          "/usr/local/bin/ffprobe",
          "/usr/bin/ffprobe",
          import_path4.default.join(__dirname2, "..", "bin", filename),
          import_path4.default.join(__dirname2, "bin", filename),
          import_path4.default.join(import_os4.default.homedir(), ".stacher", filename)
        ];
        for (const c of candidates) {
          if (c && import_fs4.default.existsSync(c)) return c;
        }
        try {
          await execFileAsync(filename, ["-version"], { windowsHide: true });
          return filename;
        } catch (_) {
        }
        return import_path4.default.join(this.binDir, filename);
      }
      async installYtDlp(onProgress) {
        this.ensureBinDirectory();
        const isWin = process.platform === "win32";
        const isMac = process.platform === "darwin";
        const filename = isWin ? "yt-dlp.exe" : "yt-dlp";
        const targetPath = import_path4.default.join(this.binDir, filename);
        onProgress?.("installing", 10, "Connecting to official yt-dlp repository...");
        const urls = isWin ? [
          "https://github.com/yt-dlp/yt-dlp-nightly-builds/releases/latest/download/yt-dlp.exe",
          "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe"
        ] : isMac ? [
          "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_macos",
          "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp"
        ] : [
          "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp"
        ];
        let downloaded = false;
        let lastErr = null;
        for (const u of urls) {
          try {
            await this.downloadFile(u, targetPath, onProgress, "Downloading yt-dlp");
            downloaded = true;
            break;
          } catch (e) {
            lastErr = e;
            logger.warn("[DependencyManager] Primary yt-dlp download failed, trying fallback:", e.message);
          }
        }
        if (!downloaded || !import_fs4.default.existsSync(targetPath)) {
          if (isWin) {
            try {
              onProgress?.("installing", 40, "Downloading via PowerShell system client...");
              const psCmd = `[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; (New-Object System.Net.WebClient).DownloadFile('${urls[0]}', '${targetPath}')`;
              await execFileAsync("powershell", ["-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", psCmd], { windowsHide: true, timeout: 6e4 });
            } catch (psErr) {
              lastErr = psErr;
            }
          } else if (isMac) {
            try {
              onProgress?.("installing", 40, "Downloading via curl system client...");
              await execFileAsync("curl", ["-L", urls[0], "-o", targetPath], { timeout: 6e4 });
            } catch (curlErr) {
              lastErr = curlErr;
            }
          }
        }
        if (!import_fs4.default.existsSync(targetPath)) {
          return { success: false, error: lastErr ? lastErr.message : "Could not download yt-dlp" };
        }
        if (!isWin) {
          try {
            import_fs4.default.chmodSync(targetPath, 493);
          } catch (_) {
          }
        }
        try {
          const { stdout } = await execFileAsync(targetPath, ["--version"], { windowsHide: true, timeout: 1e4 });
          const ver = stdout.trim();
          onProgress?.("installing", 100, `yt-dlp ready (${ver})`);
          return { success: true, version: ver, path: targetPath };
        } catch (verErr) {
          return { success: true, version: "installed", path: targetPath };
        }
      }
      async installFfmpeg(onProgress) {
        this.ensureBinDirectory();
        const isWin = process.platform === "win32";
        const isMac = process.platform === "darwin";
        if (isMac) {
          for (const p of ["/opt/homebrew/bin/ffmpeg", "/usr/local/bin/ffmpeg"]) {
            if (import_fs4.default.existsSync(p)) {
              onProgress?.("installing", 100, "FFmpeg found on macOS system.");
              return { success: true, version: "installed", path: p };
            }
          }
          const arch = process.arch === "arm64" ? "arm64" : "x64";
          const ffmpegTarget2 = import_path4.default.join(this.binDir, "ffmpeg");
          const ffprobeTarget2 = import_path4.default.join(this.binDir, "ffprobe");
          const ffmpegUrl = `https://github.com/eugeneware/ffmpeg-static/releases/latest/download/ffmpeg-darwin-${arch}`;
          const ffprobeUrl = `https://github.com/eugeneware/ffmpeg-static/releases/latest/download/ffprobe-darwin-${arch}`;
          onProgress?.("installing", 10, "Downloading macOS FFmpeg media engine...");
          try {
            await this.downloadFile(ffmpegUrl, ffmpegTarget2, (stage, pct, msg) => {
              onProgress?.("installing", Math.min(50, Math.round(pct * 0.5)), msg);
            }, "Downloading FFmpeg");
            try {
              import_fs4.default.chmodSync(ffmpegTarget2, 493);
            } catch (_) {
            }
            onProgress?.("installing", 50, "Downloading macOS FFprobe analyzer...");
            await this.downloadFile(ffprobeUrl, ffprobeTarget2, (stage, pct, msg) => {
              onProgress?.("installing", Math.min(95, 50 + Math.round(pct * 0.45)), msg);
            }, "Downloading FFprobe");
            try {
              import_fs4.default.chmodSync(ffprobeTarget2, 493);
            } catch (_) {
            }
            if (import_fs4.default.existsSync(ffmpegTarget2)) {
              onProgress?.("installing", 100, "FFmpeg & FFprobe installed successfully on macOS.");
              return { success: true, version: "installed", path: ffmpegTarget2 };
            }
          } catch (macErr) {
            logger.error("[DependencyManager] Mac FFmpeg install error:", macErr);
            return { success: false, error: 'Could not auto-install FFmpeg. Run "brew install ffmpeg" in Terminal.' };
          }
        }
        if (!isWin) {
          return { success: false, error: "Please install ffmpeg via your package manager (e.g. brew install ffmpeg)." };
        }
        const ffmpegTarget = import_path4.default.join(this.binDir, "ffmpeg.exe");
        const ffprobeTarget = import_path4.default.join(this.binDir, "ffprobe.exe");
        onProgress?.("installing", 5, "Downloading FFmpeg and FFprobe media engines...");
        const zipUrl = "https://github.com/yt-dlp/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip";
        const tempZip = import_path4.default.join(import_os4.default.tmpdir(), `ffmpeg_${Date.now()}.zip`);
        const tempUnpack = import_path4.default.join(import_os4.default.tmpdir(), `ffmpeg_unpack_${Date.now()}`);
        try {
          await this.downloadFile(zipUrl, tempZip, (stage, pct, msg) => {
            onProgress?.("installing", Math.min(88, 5 + Math.round(pct * 0.83)), msg || `Downloading media merger (${pct}%)...`);
          }, "Downloading FFmpeg merger");
          onProgress?.("installing", 90, "Extracting FFmpeg & FFprobe core binaries...");
          const psScript = `
        Expand-Archive -Path '${tempZip}' -DestinationPath '${tempUnpack}' -Force;
        Get-ChildItem -Path '${tempUnpack}' -Recurse -Filter 'ffmpeg.exe' | Copy-Item -Destination '${ffmpegTarget}' -Force;
        Get-ChildItem -Path '${tempUnpack}' -Recurse -Filter 'ffprobe.exe' | Copy-Item -Destination '${ffprobeTarget}' -Force;
        Remove-Item -Force '${tempZip}' -ErrorAction SilentlyContinue;
        Remove-Item -Recurse -Force '${tempUnpack}' -ErrorAction SilentlyContinue;
      `;
          await execFileAsync("powershell", ["-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", psScript], { windowsHide: true, timeout: 6e4 });
          if (import_fs4.default.existsSync(ffmpegTarget) && import_fs4.default.existsSync(ffprobeTarget)) {
            onProgress?.("installing", 100, "FFmpeg & FFprobe installed successfully.");
            return { success: true, version: "installed", path: ffmpegTarget };
          }
          return { success: false, error: "FFmpeg extraction did not produce ffmpeg.exe" };
        } catch (err) {
          logger.error("[DependencyManager] FFmpeg install error:", err);
          return { success: false, error: err.message || "FFmpeg installation failed" };
        }
      }
      async updateYtDlp(hasActiveDownloads, onProgress) {
        if (hasActiveDownloads) {
          return { success: false, error: "Cannot update while downloads are active" };
        }
        try {
          const execPath = await this.getYtDlpExecutablePath();
          if (!execPath || !import_fs4.default.existsSync(execPath)) {
            onProgress?.("updating", 10, "yt-dlp engine not found. Downloading fresh copy...");
            return await this.installYtDlp(onProgress);
          }
          onProgress?.("updating", 20, "Querying official repository...");
          try {
            const { stdout, stderr } = await execFileAsync(execPath, ["-U"], { windowsHide: true, timeout: 6e4 });
            const output = (stdout || stderr || "").trim();
            onProgress?.("updating", 100, output.includes("up to date") ? "Already up to date" : "Updated successfully");
            return { success: true, version: output };
          } catch (updateErr) {
            logger.warn("[DependencyManager] yt-dlp self-update failed, falling back to direct re-download:", updateErr.message);
            onProgress?.("updating", 40, "Directly downloading latest release from GitHub...");
            return await this.installYtDlp(onProgress);
          }
        } catch (err) {
          logger.error("[DependencyManager] yt-dlp update error:", err);
          return { success: false, error: err.message || "Update failed" };
        }
      }
      async autoRecoverYtDlpIfStale() {
        const now = Date.now();
        if (this._lastAutoUpdateAt && now - this._lastAutoUpdateAt < 10 * 60 * 1e3) {
          return { success: false, skipped: true };
        }
        this._lastAutoUpdateAt = now;
        logger.info("[DependencyManager] Auto-updating yt-dlp to recover from YouTube extraction failure...");
        return await this.updateYtDlp(false);
      }
    };
    dependencyManager = new DependencyManager();
  }
});

// MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/service/filesystem.js
var filesystem_exports = {};
__export(filesystem_exports, {
  FilesystemManager: () => FilesystemManager,
  filesystemManager: () => filesystemManager
});
var import_fs5, import_path5, import_os5, WINDOWS_RESERVED_NAMES, FilesystemManager, filesystemManager;
var init_filesystem = __esm({
  "MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/service/filesystem.js"() {
    import_fs5 = __toESM(require("fs"));
    import_path5 = __toESM(require("path"));
    import_os5 = __toESM(require("os"));
    init_settings();
    init_logger();
    WINDOWS_RESERVED_NAMES = /* @__PURE__ */ new Set([
      "CON",
      "PRN",
      "AUX",
      "NUL",
      "COM1",
      "COM2",
      "COM3",
      "COM4",
      "COM5",
      "COM6",
      "COM7",
      "COM8",
      "COM9",
      "LPT1",
      "LPT2",
      "LPT3",
      "LPT4",
      "LPT5",
      "LPT6",
      "LPT7",
      "LPT8",
      "LPT9"
    ]);
    FilesystemManager = class {
      /**
       * Sanitizes a title string into a cross-platform safe filename.
       */
      sanitizeFilename(title, ext) {
        if (!title || typeof title !== "string" || title.trim().length === 0) {
          title = "media_download";
        }
        let sanitized = title.replace(/[\x00-\x1f\x7f]/g, "").replace(/[\\/:*?"<>|]/g, "_").replace(/\s+/g, " ").replace(/_+/g, "_").trim().replace(/^[.\s]+|[.\s]+$/g, "");
        if (!sanitized) {
          sanitized = "media_file";
        }
        const upper = sanitized.toUpperCase();
        if (WINDOWS_RESERVED_NAMES.has(upper)) {
          sanitized = `_${sanitized}_`;
        }
        if (sanitized.length > 200) {
          sanitized = sanitized.substring(0, 200).trim();
        }
        if (ext) {
          const cleanExt = ext.startsWith(".") ? ext.substring(1) : ext;
          return `${sanitized}.${cleanExt}`;
        }
        return sanitized;
      }
      /**
       * Resolves target download directory based on project state and settings.
       */
      resolveTargetDirectory(projectContext, customOverride, settings) {
        const currentSettings = settings || settingsManager.getSettings();
        const rawMode = currentSettings?.downloads?.downloadLocationMode || "simple";
        const locMode = rawMode === "project" ? "simple" : rawMode;
        if (customOverride && typeof customOverride === "string" && customOverride.trim().length > 0) {
          return {
            targetDir: import_path5.default.resolve(customOverride.trim()),
            mode: "custom",
            isProjectFolder: false
          };
        }
        if (locMode === "simple") {
          if (projectContext && projectContext.projectDirectory) {
            return {
              targetDir: import_path5.default.join(projectContext.projectDirectory, "MediaFetch"),
              mode: "simple",
              isProjectFolder: true
            };
          }
          return {
            targetDir: import_path5.default.join(import_os5.default.homedir(), "Downloads", "MediaFetch"),
            mode: "simple",
            isProjectFolder: false
          };
        }
        if ((locMode === "custom" || locMode === "custom_flat") && currentSettings?.downloads?.customLocation && currentSettings.downloads.customLocation.trim().length > 0) {
          return {
            targetDir: import_path5.default.resolve(currentSettings.downloads.customLocation.trim()),
            mode: locMode,
            isProjectFolder: false
          };
        }
        return {
          targetDir: import_path5.default.join(import_os5.default.homedir(), "Downloads", "MediaFetch"),
          mode: "simple",
          isProjectFolder: false
        };
      }
      /**
       * Checks if a file already exists in target directory.
       */
      checkDuplicate(targetDir, filename) {
        const filePath = import_path5.default.join(targetDir, filename);
        try {
          if (import_fs5.default.existsSync(filePath)) {
            const stat = import_fs5.default.statSync(filePath);
            return { exists: true, filePath, size: stat.size };
          }
        } catch (_) {
        }
        return { exists: false, filePath, size: 0 };
      }
      /**
       * Resolves unique filename by incrementing Title (1).ext, Title (2).ext if collision exists.
       */
      resolveUniqueFilename(targetDir, desiredFilename) {
        const parsed = import_path5.default.parse(desiredFilename);
        let counter = 1;
        let candidate = desiredFilename;
        while (import_fs5.default.existsSync(import_path5.default.join(targetDir, candidate))) {
          candidate = `${parsed.name} (${counter})${parsed.ext}`;
          counter++;
        }
        return candidate;
      }
      /**
       * Gets staging path inside .temp subfolder.
       */
      getTempStagingPath(targetDir, downloadId, ext = "tmp") {
        const stagingDir = import_path5.default.join(targetDir, ".temp_mediafetch");
        this.ensureDirExists(stagingDir);
        return import_path5.default.join(stagingDir, `${downloadId}.${ext}`);
      }
      /**
       * Verifies downloaded file and moves atomically to final path.
       */
      finalizeDownloadedFile(tempFilePath, targetDirectory, desiredFilename, overwrite = false) {
        if (!import_fs5.default.existsSync(tempFilePath)) {
          throw new Error(`Downloaded file does not exist: ${tempFilePath}`);
        }
        const stat = import_fs5.default.statSync(tempFilePath);
        if (stat.size === 0) {
          throw new Error("Downloaded file is empty (0 bytes).");
        }
        this.ensureDirExists(targetDirectory);
        const finalFilename = overwrite ? desiredFilename : this.resolveUniqueFilename(targetDirectory, desiredFilename);
        const finalPath = import_path5.default.join(targetDirectory, finalFilename);
        try {
          import_fs5.default.renameSync(tempFilePath, finalPath);
        } catch (_) {
          import_fs5.default.copyFileSync(tempFilePath, finalPath);
          import_fs5.default.unlinkSync(tempFilePath);
        }
        logger.info(`Finalized download to ${finalPath} (${(stat.size / (1024 * 1024)).toFixed(2)} MB)`);
        try {
          const stagingDir = import_path5.default.dirname(tempFilePath);
          if (import_fs5.default.existsSync(stagingDir) && !import_path5.default.basename(stagingDir).startsWith(".temp")) {
            const remaining = import_fs5.default.readdirSync(stagingDir);
            if (remaining.length === 0) {
              import_fs5.default.rmdirSync(stagingDir);
            }
          }
        } catch (_) {
        }
        return { finalPath, fileSize: stat.size };
      }
      ensureDirExists(dirPath) {
        if (!import_fs5.default.existsSync(dirPath)) {
          import_fs5.default.mkdirSync(dirPath, { recursive: true });
        }
      }
      verifyWritePermission(dirPath) {
        try {
          this.ensureDirExists(dirPath);
          const testPath = import_path5.default.join(dirPath, `.mf_write_test_${Date.now()}_${Math.random().toString(36).substring(2, 6)}.tmp`);
          import_fs5.default.writeFileSync(testPath, "ok", "utf8");
          import_fs5.default.unlinkSync(testPath);
          return true;
        } catch (err) {
          logger.error(`Write permission check failed for ${dirPath}:`, err);
          return false;
        }
      }
    };
    filesystemManager = new FilesystemManager();
  }
});

// MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/service/youtubeToken.js
var import_fs6, import_path6, import_os6, YouTubeTokenManager, youtubeTokenManager;
var init_youtubeToken = __esm({
  "MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/service/youtubeToken.js"() {
    import_fs6 = __toESM(require("fs"));
    import_path6 = __toESM(require("path"));
    import_os6 = __toESM(require("os"));
    init_logger();
    init_dependencies();
    YouTubeTokenManager = class {
      constructor() {
        this.fallbackVisitorData = null;
        this.tokenFilePath = import_path6.default.join(process.env.LOCALAPPDATA || (import_os6.default.homedir ? import_path6.default.join(import_os6.default.homedir(), "AppData", "Local") : "."), "MediaFetch", "visitor_data.txt");
        this.cachedVisitorData = this.readSavedVisitorData() || null;
        this.lastFetched = this.cachedVisitorData ? Date.now() : 0;
        this.isFetching = false;
      }
      readSavedVisitorData() {
        try {
          if (import_fs6.default.existsSync(this.tokenFilePath)) {
            const val = import_fs6.default.readFileSync(this.tokenFilePath, "utf8").trim();
            if (val && val.length > 20) return val;
          }
        } catch (_) {
        }
        return null;
      }
      saveVisitorData(vd) {
        try {
          const dir = import_path6.default.dirname(this.tokenFilePath);
          if (!import_fs6.default.existsSync(dir)) import_fs6.default.mkdirSync(dir, { recursive: true });
          import_fs6.default.writeFileSync(this.tokenFilePath, vd, "utf8");
        } catch (_) {
        }
      }
      isYouTubeUrl(url) {
        if (!url || typeof url !== "string") return false;
        const lower = url.toLowerCase().trim();
        return lower.includes("youtube.com") || lower.includes("youtu.be") || lower.startsWith("ytsearch");
      }
      async getVisitorData() {
        const age = Date.now() - this.lastFetched;
        if ((!this.cachedVisitorData || age > 6 * 60 * 60 * 1e3) && !this.isFetching) {
          await this.refreshVisitorData().catch(() => {
          });
        }
        return this.cachedVisitorData || null;
      }
      async refreshVisitorData() {
        if (this.isFetching) return this.cachedVisitorData;
        this.isFetching = true;
        try {
          logger?.debug?.("[YouTubeTokenManager] Refreshing YouTube visitor data token...");
          let controller = null;
          let timer = null;
          if (typeof AbortController !== "undefined") {
            controller = new AbortController();
            timer = setTimeout(() => {
              try {
                controller.abort();
              } catch (_) {
              }
            }, 6e3);
          }
          const fetchOpts = {
            headers: {
              "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
              "Accept-Language": "en-US,en;q=0.9"
            }
          };
          if (controller) fetchOpts.signal = controller.signal;
          const res = await fetch("https://www.youtube.com", fetchOpts);
          if (timer) clearTimeout(timer);
          if (res.ok) {
            const html = await res.text();
            const match = html.match(/"VISITOR_DATA":\s*"([^"]+)"/);
            if (match && match[1]) {
              try {
                this.cachedVisitorData = decodeURIComponent(match[1]);
              } catch (_) {
                this.cachedVisitorData = match[1];
              }
              this.lastFetched = Date.now();
              this.saveVisitorData(this.cachedVisitorData);
              logger?.info?.("[YouTubeTokenManager] Successfully refreshed YouTube visitor token");
              return this.cachedVisitorData;
            }
          }
        } catch (err) {
          logger?.warn?.("[YouTubeTokenManager] Background visitor token refresh notice:", err?.message || err);
        } finally {
          this.isFetching = false;
        }
        return this.cachedVisitorData || this.fallbackVisitorData || null;
      }
      async getYtDlpExtractorArgs(url, isAnalysis = false) {
        try {
          const nodeBin = dependencyManager.getNodeExecutablePath() || "node";
          const jsRuntime = nodeBin === "node" ? "node" : `node:${nodeBin}`;
          return ["--js-runtimes", jsRuntime, "--remote-components", "ejs:github"];
        } catch (_) {
          return ["--remote-components", "ejs:github"];
        }
      }
    };
    youtubeTokenManager = new YouTubeTokenManager();
  }
});

// MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/service/analyzer.js
var analyzer_exports = {};
__export(analyzer_exports, {
  MetadataAnalyzer: () => MetadataAnalyzer,
  metadataAnalyzer: () => metadataAnalyzer
});
function fetchHtml(targetUrl, headers = {}, maxRedirects = 5) {
  return new Promise((resolve, reject) => {
    if (maxRedirects <= 0) return reject(new Error("Too many redirects"));
    const client = targetUrl.startsWith("https:") ? import_https2.default : import_http2.default;
    const req = client.get(targetUrl, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
        ...headers
      }
    }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        let next = res.headers.location;
        if (!next.startsWith("http")) {
          try {
            const u = new URL(targetUrl);
            next = u.origin + next;
          } catch (e) {
            return reject(e);
          }
        }
        return fetchHtml(next, headers, maxRedirects - 1).then(resolve, reject);
      }
      let data = "";
      res.on("data", (chunk) => data += chunk);
      res.on("end", () => resolve({ statusCode: res.statusCode, body: data, finalUrl: targetUrl }));
    });
    req.on("error", reject);
    req.setTimeout(15e3, () => {
      req.destroy();
      reject(new Error("HTTP request timed out"));
    });
  });
}
function fetchSmartHtml(targetUrl, headers = {}, maxRedirects = 5) {
  const fallbackUas = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
    "DuckDuckBot/1.0; (+http://duckduckgo.com/duckduckbot.html)",
    "Mozilla/5.0 (compatible; Discordbot/2.0; +https://discordapp.com)",
    "facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)"
  ];
  function tryUa(idx) {
    if (idx >= fallbackUas.length) {
      return Promise.reject(new Error("Failed to retrieve webpage HTML across all headers"));
    }
    const reqHeaders = { "User-Agent": fallbackUas[idx], ...headers };
    return fetchHtml(targetUrl, reqHeaders, maxRedirects).then((res) => {
      if ((res.statusCode === 202 || res.statusCode === 403 || res.statusCode === 503) && idx + 1 < fallbackUas.length) {
        return tryUa(idx + 1);
      }
      return res;
    }).catch((err) => {
      if (idx + 1 < fallbackUas.length) return tryUa(idx + 1);
      throw err;
    });
  }
  return tryUa(0);
}
function findBrowserExecutable() {
  const candidates = [
    "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe",
    "C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe",
    "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
    "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
    "/usr/bin/google-chrome",
    "/usr/bin/chromium-browser",
    "/usr/bin/chromium"
  ];
  for (const c of candidates) {
    if (import_fs7.default.existsSync(c)) return c;
  }
  return null;
}
async function dumpHeadlessDom(targetUrl, timeoutMs = 25e3) {
  const browser = findBrowserExecutable();
  if (!browser) return null;
  try {
    const { stdout } = await execFileAsync2(browser, [
      "--headless",
      "--disable-gpu",
      "--no-sandbox",
      "--disable-dev-shm-usage",
      "--dump-dom",
      targetUrl
    ], { timeout: timeoutMs, windowsHide: true, maxBuffer: 10 * 1024 * 1024 });
    return stdout || "";
  } catch (err) {
    logger.warn("dumpHeadlessDom failed:", err.message);
    return null;
  }
}
async function probeMediaDuration(streamUrl, timeoutMs = 6e3) {
  if (!streamUrl || typeof streamUrl !== "string" || !streamUrl.startsWith("http")) return 0;
  try {
    const ffprobePath = await dependencyManager.getFfprobeExecutablePath();
    if (!ffprobePath) return 0;
    const { stdout } = await execFileAsync2(ffprobePath, [
      "-headers",
      "Referer: https://www.instagram.com/\r\n",
      "-user_agent",
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
      "-v",
      "error",
      "-show_entries",
      "format=duration",
      "-of",
      "default=noprint_wrappers=1:nokey=1",
      streamUrl
    ], { windowsHide: true, timeout: timeoutMs });
    const dur = parseFloat(stdout.trim());
    return dur && !isNaN(dur) && dur > 0 ? Math.round(dur) : 0;
  } catch (_) {
    return 0;
  }
}
var import_child_process2, import_util2, import_https2, import_http2, import_fs7, import_path7, import_os7, execFileAsync2, MetadataAnalyzer, metadataAnalyzer;
var init_analyzer = __esm({
  "MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/service/analyzer.js"() {
    import_child_process2 = require("child_process");
    import_util2 = require("util");
    import_https2 = __toESM(require("https"));
    import_http2 = __toESM(require("http"));
    import_fs7 = __toESM(require("fs"));
    import_path7 = __toESM(require("path"));
    import_os7 = __toESM(require("os"));
    init_errors();
    init_dependencies();
    init_settings();
    init_logger();
    init_youtubeToken();
    execFileAsync2 = (0, import_util2.promisify)(import_child_process2.execFile);
    MetadataAnalyzer = class {
      constructor() {
        this.metadataCache = /* @__PURE__ */ new Map();
      }
      getCachedMetadata(url) {
        if (!url) return null;
        const clean = url.trim();
        const hit = this.metadataCache.get(clean);
        if (hit && Date.now() - hit.time < 3e5) {
          return hit.data;
        }
        return null;
      }
      setCachedMetadata(url, data) {
        if (!url || !data) return;
        if (this.metadataCache.size > 200) {
          const first = this.metadataCache.keys().next().value;
          if (first) this.metadataCache.delete(first);
        }
        this.metadataCache.set(url.trim(), { data, time: Date.now() });
      }
      isValidUrl(urlStr) {
        try {
          const parsed = new URL(urlStr);
          return parsed.protocol === "http:" || parsed.protocol === "https:";
        } catch {
          return false;
        }
      }
      isPlaylistUrl(urlStr) {
        if (!this.isValidUrl(urlStr)) return false;
        const lower = urlStr.toLowerCase();
        const isAppleTrack = (lower.includes("music.apple.com") || lower.includes("itunes.apple.com")) && (lower.includes("?i=") || lower.includes("&i=") || lower.includes("?track=") || lower.includes("&track="));
        if (isAppleTrack) return false;
        return lower.includes("playlist?list=") || lower.includes("&list=") || lower.includes("?list=") || lower.includes("/sets/") || lower.includes("/album/") || lower.includes("spotify.") && (lower.includes("/playlist/") || lower.includes("/album/") || lower.includes("/artist/")) || lower.includes("drive.google.com/drive/folders/") || lower.includes("drive.google.com/drive/u/") || lower.includes("drive.google.com/folderview") || lower.includes("dropbox.com") && (lower.includes("/scl/fo/") || lower.includes("/sh/") || lower.includes("/folder/")) || lower.includes("1drv.ms") || lower.includes("onedrive.live.com") || lower.includes("sharepoint.com") || lower.includes("box.com/s/") || lower.includes("box.com/folder/") || lower.includes("mega.nz/folder/") || lower.includes("mega.nz/#f!") || lower.includes("pinterest.") && lower.includes("/boards/");
      }
      isSpotifyPlaylistUrl(urlStr) {
        if (!this.isValidUrl(urlStr)) return false;
        return /spotify\.(?:com|link).*(?:\/playlist\/|\/album\/|\/artist\/)/i.test(urlStr);
      }
      async parseGoogleDriveFolderRecursive(folderId, folderPath = "", depth = 0, maxDepth = 8, visited = /* @__PURE__ */ new Set()) {
        if (!folderId || depth > maxDepth || visited.has(folderId)) {
          return { title: folderPath, items: [], folders: [] };
        }
        visited.add(folderId);
        const folderUrl = `https://drive.google.com/drive/folders/${folderId}`;
        function cleanDriveTitle(raw) {
          if (!raw) return "";
          let str = String(raw);
          try {
            str = str.replace(/\\u([0-9a-fA-F]{4})/g, (_, h) => String.fromCharCode(parseInt(h, 16)));
          } catch (_) {
          }
          str = str.replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'");
          return str.trim();
        }
        let rawItems = [];
        const seenItemIds = /* @__PURE__ */ new Set();
        let folderTitle = folderPath;
        const GDRIVE_API_KEY = "AIzaSyAWGrfCCr7albM3lmCc937gx4uIphbpeKQ";
        let apiSuccess = false;
        try {
          let pageToken = null;
          let pages = 0;
          do {
            let apiUrl = `https://www.googleapis.com/drive/v3/files?q='${folderId}'+in+parents+and+trashed=false&pageSize=100&key=${GDRIVE_API_KEY}&fields=nextPageToken,files(id,name,mimeType)`;
            if (pageToken) apiUrl += `&pageToken=${encodeURIComponent(pageToken)}`;
            const res = await fetchHtml(apiUrl, {
              "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
            });
            const parsed = JSON.parse(res.body);
            if (parsed && Array.isArray(parsed.files)) {
              apiSuccess = true;
              for (const f of parsed.files) {
                if (f.id && !seenItemIds.has(f.id)) {
                  seenItemIds.add(f.id);
                  rawItems.push([f.id, null, f.name, f.mimeType]);
                }
              }
              pageToken = parsed.nextPageToken || null;
            } else {
              break;
            }
            pages++;
          } while (pageToken && pages < 50);
          if (apiSuccess && !folderTitle) {
            try {
              const metaRes = await fetchHtml(`https://www.googleapis.com/drive/v3/files/${folderId}?key=${GDRIVE_API_KEY}&fields=name`);
              const metaParsed = JSON.parse(metaRes.body);
              if (metaParsed && metaParsed.name) {
                folderTitle = cleanDriveTitle(metaParsed.name);
              }
            } catch (_) {
            }
          }
        } catch (_) {
          apiSuccess = false;
        }
        if (!apiSuccess || rawItems.length === 0) {
          let currentToken = null;
          let pageCount = 0;
          const maxPages = 50;
          do {
            let pageUrl = folderUrl;
            if (currentToken) {
              pageUrl += (pageUrl.includes("?") ? "&" : "?") + `pageToken=${encodeURIComponent(currentToken)}`;
            }
            let html = "";
            try {
              const res = await fetchHtml(pageUrl, {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "Accept-Language": "en-US,en;q=0.9"
              });
              html = res.body;
              if (res.statusCode === 404) {
                if (depth === 0) throw new Error('Google Drive folder not found (404). Please verify the link or ensure it is set to "Anyone with the link can view".');
                break;
              }
              if (res.statusCode === 403 || res.statusCode === 401) {
                if (depth === 0) throw new Error('Google Drive access denied (403). Set folder sharing to "Anyone with the link can view".');
                break;
              }
            } catch (e) {
              if (depth === 0 && pageCount === 0) throw e;
              logger.warn(`Failed to fetch Drive folder page ${pageCount + 1} (${folderId}):`, e.message || e);
              break;
            }
            if (!folderTitle) {
              const tMatch = html.match(/<title>([^<]+?)(?:\s*–\s*Google\s*Drive)?<\/title>/i);
              if (tMatch) folderTitle = cleanDriveTitle(tMatch[1]);
            }
            const ivdMatch = html.match(/window\['_DRIVE_ivd'\]\s*=\s*'([^']+)'/);
            if (!ivdMatch) {
              if (depth === 0 && pageCount === 0) {
                if (html.includes("404") || html.includes("Not Found") || html.includes("Error 404")) {
                  throw new Error("Google Drive folder not found (404). Please verify the link is valid and public.");
                }
                if (html.includes("accounts.google.com/ServiceLogin") || html.includes("Sign in - Google Accounts")) {
                  throw new Error('Google Drive folder requires sign-in. Change sharing to "Anyone with the link can view".');
                }
              }
              break;
            }
            try {
              const rawStr = ivdMatch[1];
              const unescaped = rawStr.replace(/\\x([0-9A-Fa-f]{2})/g, (_, hex) => String.fromCharCode(parseInt(hex, 16)));
              const parsed = JSON.parse(unescaped);
              const pageItems = parsed[0] || [];
              let newItemsFound = 0;
              for (const item of pageItems) {
                const itemId = item && item[0];
                if (itemId && !seenItemIds.has(itemId)) {
                  seenItemIds.add(itemId);
                  rawItems.push(item);
                  newItemsFound++;
                }
              }
              if (newItemsFound === 0) {
                break;
              }
              currentToken = null;
              if (parsed[4] && parsed[4][0] && Array.isArray(parsed[4][0])) {
                for (const entry of parsed[4][0]) {
                  if (typeof entry === "string" && entry.startsWith("~!!~")) {
                    currentToken = entry.replace(/\\u003d/g, "=").replace(/\\u([0-9a-fA-F]{4})/g, (_, h) => String.fromCharCode(parseInt(h, 16)));
                    break;
                  }
                }
              }
            } catch (e) {
              logger.warn(`Failed to parse _DRIVE_ivd page ${pageCount + 1} for folder ${folderId}:`, e.message || e);
              break;
            }
            pageCount++;
          } while (currentToken && pageCount < maxPages);
        }
        if (!folderTitle) folderTitle = "Google Drive Folder";
        const directFiles = [];
        const subFolderDefs = [];
        for (let idx = 0; idx < rawItems.length; idx++) {
          const item = rawItems[idx];
          const itemId = item[0];
          if (!itemId) continue;
          const rawItemName = item[2] || `File_${idx + 1}`;
          const itemName = cleanDriveTitle(rawItemName);
          const mime = item[3] || "video/mp4";
          if (mime === "application/vnd.google-apps.folder") {
            subFolderDefs.push({ id: itemId, name: itemName });
          } else {
            const isVideo = mime.startsWith("video") || /\.(mp4|mov|mkv|webm|avi|flv|m4v)$/i.test(itemName);
            const isAudio = mime.startsWith("audio") || /\.(mp3|wav|m4a|aac|flac|ogg)$/i.test(itemName);
            const isImage = mime.startsWith("image") || /\.(jpg|jpeg|png|webp|gif|bmp)$/i.test(itemName);
            const directUrl = `https://drive.google.com/uc?export=download&id=${itemId}`;
            const thumbUrl = `https://drive.google.com/thumbnail?id=${itemId}&sz=w800`;
            const hMatch = itemName.match(/(\d{3,4})p/i);
            let detectedH = 0;
            if (hMatch) {
              detectedH = parseInt(hMatch[1], 10);
            } else if (/\b4k\b/i.test(itemName) || /\b2160\b/.test(itemName)) {
              detectedH = 2160;
            } else if (/\b1440\b/.test(itemName) || /\b2k\b/i.test(itemName)) {
              detectedH = 1440;
            } else if (/\b1080\b/.test(itemName)) {
              detectedH = 1080;
            } else if (/\b720\b/.test(itemName)) {
              detectedH = 720;
            } else if (/\b480\b/.test(itemName)) {
              detectedH = 480;
            }
            directFiles.push({
              id: itemId,
              title: itemName,
              author: "Google Drive",
              duration: 0,
              thumbnail: thumbUrl,
              url: directUrl,
              directUrl,
              mediaType: isVideo ? "video" : isAudio ? "audio" : isImage ? "image" : "video",
              height: detectedH,
              resolution: detectedH ? `${detectedH}p` : void 0,
              subFolderId: folderId,
              subFolderName: folderPath || folderTitle
            });
          }
        }
        const childResults = await Promise.all(subFolderDefs.map(async (sub) => {
          const nextPath = folderPath ? `${folderPath} / ${sub.name}` : sub.name;
          const subRes = await this.parseGoogleDriveFolderRecursive(sub.id, nextPath, depth + 1, maxDepth, visited);
          if (subRes.items.length > 0 || subRes.folders.length > 0) {
            return {
              id: sub.id,
              name: nextPath,
              items: subRes.items,
              folders: subRes.folders
            };
          }
          return null;
        }));
        const childFolders = childResults.filter(Boolean);
        return {
          title: folderTitle,
          items: directFiles,
          folders: childFolders
        };
      }
      async analyzePlaylist(url, timeoutMs = 35e3) {
        if (this.isBehanceUrl(url)) {
          return await this.analyzeBehance(url, timeoutMs);
        }
        if (this.isThreadsUrl(url)) {
          return await this.analyzeThreads(url, timeoutMs);
        }
        if (url.includes("instagram.com/p/") || url.includes("instagram.com/reel/") || url.includes("instagram.com/reels/")) {
          const ig = await this.analyzeInstagram(url, timeoutMs);
          if (ig) return ig;
        }
        if (this.isPinterestUrl(url)) {
          return await this.analyzePinterest(url, timeoutMs);
        }
        if (this.isDribbbleUrl(url)) {
          return await this.analyzeDribbble(url, timeoutMs);
        }
        if (this.isArtStationUrl(url)) {
          return await this.analyzeArtStation(url, timeoutMs);
        }
        if (this.isFiverrUrl(url)) {
          return await this.analyzeFiverr(url, timeoutMs);
        }
        if (this.isAppleMusicUrl(url) && !this.isAppleMusicAlbumUrl(url)) {
          return await this.analyzeAppleMusic(url, timeoutMs);
        }
        if (url.includes("drive.google.com") && (url.includes("/folders/") || url.includes("folderview") || url.includes("/drive/u/"))) {
          logger.info(`Analyzing Google Drive shared folder: ${url}`);
          try {
            let collectSubfolders = function(subGroupList) {
              for (const grp of subGroupList) {
                if (grp.items && grp.items.length > 0) {
                  folderGroups.push({
                    id: grp.id,
                    name: grp.name,
                    items: grp.items
                  });
                  allFlatItems.push(...grp.items);
                }
                if (grp.folders && grp.folders.length > 0) {
                  collectSubfolders(grp.folders);
                }
              }
            };
            const fMatch = url.match(/folders\/([a-zA-Z0-9_-]+)/);
            const idMatch = url.match(/[?&]id=([a-zA-Z0-9_-]+)/);
            const folderId = fMatch ? fMatch[1] : idMatch ? idMatch[1] : "";
            const tree = await this.parseGoogleDriveFolderRecursive(folderId, "", 0, 8);
            const allFlatItems = [];
            const folderGroups = [];
            if (tree.items.length > 0) {
              folderGroups.push({
                id: folderId,
                name: tree.title || "Main Folder",
                items: tree.items
              });
              allFlatItems.push(...tree.items);
            }
            collectSubfolders(tree.folders);
            if (allFlatItems.length > 0) {
              allFlatItems.forEach((it, idx) => {
                it.index = idx + 1;
              });
              return {
                id: folderId || "drive_folder",
                title: tree.title || "Google Drive Folder",
                uploader: "Google Drive",
                thumbnail: allFlatItems[0]?.thumbnail || "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800",
                url,
                itemCount: allFlatItems.length,
                items: allFlatItems,
                folders: folderGroups.length > 0 ? folderGroups : [{
                  id: folderId || "root",
                  name: tree.title || "Files",
                  items: allFlatItems
                }]
              };
            }
            throw new Error("No media files found in this Google Drive folder.");
          } catch (err) {
            logger.error("Failed to parse Google Drive folder:", err);
            throw err;
          }
        }
        if (this.isSpotifyPlaylistUrl(url)) {
          logger.info(`Analyzing Spotify playlist/album/artist: ${url}`);
          try {
            const idMatch = url.match(/(playlist|album|artist)\/([a-zA-Z0-9]+)/);
            const type = idMatch ? idMatch[1] : "playlist";
            const id = idMatch ? idMatch[2] : "";
            if (id) {
              const embedUrl = `https://open.spotify.com/embed/${type}/${id}`;
              const { body: html } = await fetchHtml(embedUrl);
              const nextDataMatch = html.match(/<script id="__NEXT_DATA__" type="application\/json">([\s\S]+?)<\/script>/);
              if (nextDataMatch) {
                const nextData = JSON.parse(nextDataMatch[1]);
                const entity = nextData.props?.pageProps?.state?.data?.entity;
                if (entity) {
                  const isArtist = entity.type === "artist" || type === "artist";
                  const playlistTitle = isArtist ? `${entity.name || "Artist"} - Top Tracks` : entity.name || entity.title || "Spotify Playlist";
                  const coverImg = entity.coverArt?.sources?.[0]?.url || entity.visualIdentity?.image?.[1]?.url || entity.visualIdentity?.image?.[0]?.url || "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800";
                  const rawTracks = entity.trackList || [];
                  const defaultArtist = entity.name || entity.subtitle || "Artist";
                  const items = rawTracks.map((t, idx) => {
                    const trackTitle = t.title || `Track ${idx + 1}`;
                    const trackArtist = t.subtitle || defaultArtist;
                    const durSec = t.duration ? Math.round(t.duration / 1e3) : 180;
                    const trackUri = t.uri ? t.uri.replace("spotify:track:", "https://open.spotify.com/track/") : url;
                    const fullTitle = trackArtist ? `${trackTitle} - ${trackArtist}`.trim() : trackTitle;
                    const searchQuery = `ytsearch1:${trackTitle} ${trackArtist} audio`.trim();
                    const previewAudio = t.audioPreview?.url || "";
                    return {
                      id: t.id || t.uid || `spotify_${idx}`,
                      url: trackUri,
                      title: fullTitle,
                      duration: durSec,
                      thumbnail: coverImg,
                      channel: trackArtist,
                      uploader: trackArtist,
                      downloadQuery: searchQuery,
                      mediaType: "audio",
                      type: "audio",
                      isSpotify: true,
                      audioPreviewUrl: previewAudio,
                      directStreamUrl: previewAudio,
                      downloadTarget: previewAudio || trackUri,
                      formats: previewAudio ? [{
                        formatId: "spotify_preview",
                        ext: "mp3",
                        resolution: "Audio Preview (MP3)",
                        qualityLabel: "Audio Preview (MP3)",
                        url: previewAudio,
                        hasAudio: true,
                        hasVideo: false,
                        isAudio: true
                      }] : [],
                      index: idx + 1
                    };
                  });
                  return {
                    id,
                    url,
                    title: playlistTitle,
                    uploader: isArtist ? entity.name : entity.subtitle || "Spotify",
                    itemCount: items.length,
                    items,
                    thumbnail: coverImg
                  };
                }
              }
            }
          } catch (spErr) {
            logger.warn("Spotify playlist embed scraper notice:", spErr);
          }
        }
        if (this.isAppleMusicAlbumUrl(url)) {
          logger.info(`Analyzing Apple Music collection/artist: ${url}`);
          try {
            const idMatch = url.match(/(?:album|playlist|artist)\/[^/]+\/(\d+)/i) || url.match(/\/(\d+)(?:\?|$)/);
            const colId = idMatch ? idMatch[1] : "";
            if (colId) {
              const itunesApi = `https://itunes.apple.com/lookup?id=${colId}&entity=song&limit=50`;
              const { body: itunesBody } = await fetchHtml(itunesApi);
              const data = JSON.parse(itunesBody);
              if (data && data.results && data.results.length > 0) {
                const first = data.results[0];
                const isArtistEntity = first.wrapperType === "artist";
                const defaultArtist = first.artistName || "Apple Music Creator";
                const playlistTitle = isArtistEntity ? `${defaultArtist} - Top Tracks & Discography` : first.collectionName || "Apple Music Album";
                const rawTracks = (isArtistEntity ? data.results.slice(1) : data.results).filter((r) => r.wrapperType === "track");
                const coverImg = (first.artworkUrl100 || rawTracks[0]?.artworkUrl100 || "").replace("100x100bb", "600x600bb") || "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800";
                const items = rawTracks.map((t, idx) => {
                  const trackTitle = t.trackName || `Track ${idx + 1}`;
                  const trackArtist = t.artistName || defaultArtist;
                  const durSec = t.trackTimeMillis ? Math.round(t.trackTimeMillis / 1e3) : 180;
                  const trackUri = t.trackViewUrl || url;
                  const fullTitle = trackArtist ? `${trackTitle} - ${trackArtist}`.trim() : trackTitle;
                  const searchQuery = `ytsearch1:${trackTitle} ${trackArtist} audio`.trim();
                  return {
                    id: t.trackId ? String(t.trackId) : `apple_${idx}`,
                    url: trackUri,
                    title: fullTitle,
                    duration: durSec,
                    thumbnail: (t.artworkUrl100 || coverImg).replace("100x100bb", "600x600bb"),
                    channel: trackArtist,
                    uploader: trackArtist,
                    downloadQuery: searchQuery,
                    index: idx + 1,
                    directStreamUrl: t.previewUrl || "",
                    audioPreviewUrl: t.previewUrl || "",
                    platform: "apple_music",
                    isAppleMusic: true,
                    type: "audio"
                  };
                });
                return {
                  id: colId,
                  url,
                  title: playlistTitle,
                  uploader: defaultArtist,
                  itemCount: items.length,
                  items,
                  thumbnail: coverImg
                };
              }
            }
          } catch (appleErr) {
            logger.warn("Apple Music playlist scraper notice:", appleErr);
          }
        }
        logger.info(`Analyzing playlist with yt-dlp: ${url}`);
        let targetVideoId = null;
        try {
          const parsedUrl = new URL(url);
          targetVideoId = parsedUrl.searchParams.get("v");
        } catch (_) {
        }
        if (!targetVideoId) {
          const vMatch = url.match(/(?:v=|\/watch\/|\/embed\/|youtu\.be\/)([a-zA-Z0-9_-]{11})/);
          if (vMatch) targetVideoId = vMatch[1];
        }
        const ytdlpPath = await dependencyManager.getYtDlpExecutablePath();
        const ytArgs = await youtubeTokenManager.getYtDlpExtractorArgs(url);
        const args = [
          "--flat-playlist",
          "--playlist-items",
          "1:500",
          "--dump-single-json",
          "--ignore-no-formats-error",
          "--no-check-certificates",
          "--prefer-free-formats",
          ...ytArgs,
          "--add-header",
          "User-Agent:Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
          url
        ];
        try {
          const { stdout } = await execFileAsync2(ytdlpPath, args, {
            windowsHide: true,
            timeout: timeoutMs,
            maxBuffer: 50 * 1024 * 1024
          });
          const raw = JSON.parse(stdout);
          const items = (raw.entries || []).map((entry, index) => {
            let entryUrl = entry.url || entry.webpage_url || "";
            if (entry.id && (!entryUrl || !entryUrl.startsWith("http"))) {
              entryUrl = `https://www.youtube.com/watch?v=${entry.id}`;
            }
            if (!entryUrl) entryUrl = url;
            const entryTitle = entry.title || `Track ${index + 1}`;
            const hMatch = entryTitle.match(/(\d{3,4})p/i);
            let detectedH = entry.height || 0;
            if (!detectedH && hMatch) {
              detectedH = parseInt(hMatch[1], 10);
            } else if (!detectedH) {
              if (/\b4k\b/i.test(entryTitle) || /\b2160\b/.test(entryTitle)) detectedH = 2160;
              else if (/\b1440\b/.test(entryTitle) || /\b2k\b/i.test(entryTitle)) detectedH = 1440;
              else if (/\b1080\b/.test(entryTitle)) detectedH = 1080;
              else if (/\b720\b/.test(entryTitle)) detectedH = 720;
              else if (/\b480\b/.test(entryTitle)) detectedH = 480;
            }
            return {
              id: entry.id || `item_${index}`,
              url: entryUrl,
              downloadQuery: entryUrl,
              title: entryTitle,
              duration: entry.duration || 0,
              thumbnail: entry.thumbnail || entry.thumbnails?.[0]?.url,
              channel: entry.uploader || entry.channel || "",
              uploader: entry.uploader || entry.channel || "",
              index: index + 1,
              height: detectedH,
              resolution: detectedH ? `${detectedH}p` : void 0
            };
          });
          if (items.length > 0 && items[0].url && !items.some((it) => it.height > 0)) {
            try {
              const sampleArgs = [
                "--dump-single-json",
                "--skip-download",
                "--no-warnings",
                "--no-playlist",
                ...ytArgs,
                items[0].url
              ];
              const sampleProc = await execFileAsync2(ytdlpPath, sampleArgs, { windowsHide: true, timeout: 6e3 });
              const sampleRaw = JSON.parse(sampleProc.stdout);
              const sampleHeights = (sampleRaw.formats || []).map((f) => f.height).filter((h) => typeof h === "number" && h > 0);
              if (sampleHeights.length > 0) {
                const maxH = Math.max(...sampleHeights);
                items[0].height = maxH;
                items[0].resolution = `${maxH}p`;
              }
            } catch (_) {
            }
          }
          const rawTitle = (raw.title || raw.playlist_title || raw.playlist || raw.name || "").trim();
          const firstUploader = items[0]?.uploader || items[0]?.channel || raw.uploader || raw.channel || "";
          let finalTitle = rawTitle;
          if (!finalTitle || finalTitle === "NA" || finalTitle === "[NA]" || finalTitle.toLowerCase() === "playlist") {
            finalTitle = firstUploader ? `${firstUploader} - Playlist` : raw.id ? `Playlist_${raw.id}` : "Media Playlist";
          }
          if (targetVideoId) {
            const found = items.some((it) => it.id === targetVideoId || it.url && it.url.includes(targetVideoId));
            if (!found) {
              try {
                logger.info(`Target video ${targetVideoId} not found in first 500 playlist entries. Fetching single video info...`);
                const singleUrl = `https://www.youtube.com/watch?v=${targetVideoId}`;
                const sArgs = [
                  "--dump-single-json",
                  "--skip-download",
                  "--no-warnings",
                  "--no-playlist",
                  ...ytArgs,
                  singleUrl
                ];
                const { stdout: sOut } = await execFileAsync2(ytdlpPath, sArgs, { windowsHide: true, timeout: 8e3 });
                const sRaw = JSON.parse(sOut);
                const targetItem = {
                  id: targetVideoId,
                  url: singleUrl,
                  downloadQuery: singleUrl,
                  title: sRaw.title || `Video ${targetVideoId}`,
                  duration: sRaw.duration || 0,
                  thumbnail: sRaw.thumbnail || sRaw.thumbnails?.[0]?.url || "",
                  channel: sRaw.uploader || sRaw.channel || "",
                  uploader: sRaw.uploader || sRaw.channel || "",
                  index: 1,
                  height: sRaw.height || 1080,
                  resolution: sRaw.height ? `${sRaw.height}p` : "1080p"
                };
                items.unshift(targetItem);
                items.forEach((it, idx) => {
                  it.index = idx + 1;
                });
              } catch (e) {
                logger.warn(`Could not fetch target video ${targetVideoId} fallback:`, e.message);
              }
            }
          }
          return {
            id: raw.id || "playlist",
            url,
            title: finalTitle,
            uploader: raw.uploader || raw.channel || firstUploader || "YouTube",
            itemCount: items.length,
            items,
            thumbnail: raw.thumbnails?.[0]?.url || (items[0]?.thumbnail || ""),
            targetVideoId: targetVideoId || void 0
          };
        } catch (err) {
          logger.error("Playlist analysis failed:", err);
          const vMatch = url.match(/(?:v=|\/watch\/|\/embed\/|youtu\.be\/|shorts\/)([a-zA-Z0-9_-]{11})/);
          if (vMatch && vMatch[1]) {
            try {
              logger.info(`Playlist analysis failed, attempting fallback to single video for ID ${vMatch[1]}`);
              const singleUrl = `https://www.youtube.com/watch?v=${vMatch[1]}`;
              const singleMeta = await this.analyzeUrl(singleUrl, 15e3);
              if (singleMeta) {
                return {
                  id: vMatch[1],
                  url,
                  title: singleMeta.title || "YouTube Media",
                  uploader: singleMeta.uploader || "YouTube",
                  itemCount: 1,
                  items: [{
                    id: singleMeta.id || vMatch[1],
                    url: singleUrl,
                    title: singleMeta.title || "YouTube Media",
                    duration: singleMeta.duration || 0,
                    thumbnail: singleMeta.thumbnail || "",
                    channel: singleMeta.uploader || "",
                    uploader: singleMeta.uploader || "",
                    index: 1,
                    height: singleMeta.height || 0,
                    resolution: singleMeta.resolution || (singleMeta.height ? `${singleMeta.height}p` : void 0)
                  }],
                  thumbnail: singleMeta.thumbnail || ""
                };
              }
            } catch (singleErr) {
              logger.warn("Single video fallback after playlist failure failed:", singleErr);
            }
          }
          throw classifyError(err, "Failed to analyze playlist");
        }
      }
      isFacebookUrl(urlStr) {
        if (!this.isValidUrl(urlStr)) return false;
        return /(?:facebook\.com|fb\.watch|fb\.com|m\.facebook\.com)/i.test(urlStr);
      }
      async resolveFacebookRedirects(initialUrl, maxRedirects = 4) {
        let currentUrl = initialUrl.trim();
        let count = 0;
        while (count++ < maxRedirects) {
          try {
            const parsed = new URL(currentUrl);
            if (!currentUrl.includes("/share/") && !currentUrl.includes("fb.watch") && !currentUrl.includes("fb.com")) {
              break;
            }
            const res = await fetch(currentUrl, {
              method: "GET",
              redirect: "manual",
              headers: {
                "User-Agent": "facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
              },
              signal: AbortSignal.timeout(4500)
            });
            if (res.status >= 300 && res.status < 400 && res.headers.has("location")) {
              let loc = res.headers.get("location");
              if (loc.startsWith("/")) {
                loc = `${parsed.protocol}//${parsed.host}${loc}`;
              }
              currentUrl = loc;
            } else {
              break;
            }
          } catch (_) {
            break;
          }
        }
        return currentUrl;
      }
      cleanFacebookUrl(rawUrl) {
        try {
          const u = new URL(rawUrl.trim());
          const paramsToStrip = ["mibextid", "sfnsn", "rdid", "ref", "__tn__", "fbclid", "scm", "source", "checkpoint_src"];
          for (const p of paramsToStrip) {
            u.searchParams.delete(p);
          }
          return u.toString();
        } catch (_) {
          return rawUrl.trim();
        }
      }
      async analyzeFacebook(url, timeoutMs = 3e4) {
        const rawClean = this.cleanFacebookUrl(url);
        logger.info(`Analyzing Facebook URL: ${rawClean}`);
        let resolvedUrl = rawClean;
        try {
          resolvedUrl = await this.resolveFacebookRedirects(rawClean);
          resolvedUrl = this.cleanFacebookUrl(resolvedUrl);
        } catch (_) {
        }
        const isExplicitPhoto = /\/photo(?:\.php|\/|\?)/i.test(resolvedUrl) || /\/photos\//i.test(resolvedUrl) || /\/share\/p\//i.test(url);
        const fbidMatch = resolvedUrl.match(/[?&](?:fbid|photo_id|media_id)=(\d+)/i) || resolvedUrl.match(/\/photos\/(?:[a-zA-Z0-9_.-]+\/)?(\d+)/i) || resolvedUrl.match(/\/posts\/(\d+)/i) || url.match(/[?&](?:fbid|photo_id|media_id)=(\d+)/i);
        const fbid = fbidMatch ? fbidMatch[1] : "";
        if (!isExplicitPhoto) {
          try {
            const ytdlpPath = await dependencyManager.getYtDlpExecutablePath();
            const args = [
              "--dump-single-json",
              "--skip-download",
              "--no-warnings",
              "--ignore-no-formats-error",
              "--no-playlist",
              "--no-check-certificates",
              "--add-header",
              "User-Agent:Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
              resolvedUrl
            ];
            const localAppData = process.env.LOCALAPPDATA || (import_os7.default.homedir ? import_path7.default.join(import_os7.default.homedir(), "AppData", "Local") : "");
            const cookiesFilePath = localAppData ? import_path7.default.join(localAppData, "MediaFetch", "cookies.txt") : "";
            if (cookiesFilePath && import_fs7.default.existsSync(cookiesFilePath) && import_fs7.default.statSync(cookiesFilePath).size > 10) {
              args.push("--cookies", cookiesFilePath);
            } else {
              const rawCookiesBrowser = settingsManager.getSettings()?.engine?.browserCookies || settingsManager.getSettings()?.engine?.cookiesBrowser || "none";
              const isWin = process.platform === "win32";
              const cookiesBrowser = isWin && rawCookiesBrowser === "chrome" ? "none" : rawCookiesBrowser;
              if (cookiesBrowser && cookiesBrowser !== "none") {
                args.push("--cookies-from-browser", cookiesBrowser);
              }
            }
            const { stdout } = await execFileAsync2(ytdlpPath, args, {
              windowsHide: true,
              timeout: Math.min(timeoutMs, 16e3),
              maxBuffer: 20 * 1024 * 1024
            });
            const raw = JSON.parse(stdout);
            const parsed = await this.parseYtDlpOutput(resolvedUrl, raw);
            if (parsed && (parsed.formats?.length > 0 || parsed.directStreamUrl || parsed.duration > 0)) {
              return parsed;
            }
          } catch (ytdlpErr) {
            logger.info(`Facebook yt-dlp attempt notice for ${resolvedUrl}: ${ytdlpErr.message}`);
          }
        }
        try {
          const uas = [
            "facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
          ];
          let html = "";
          for (const ua of uas) {
            try {
              const res = await fetchHtml(resolvedUrl, { "User-Agent": ua });
              if (res.body && res.body.length > 500) {
                html = res.body;
                break;
              }
            } catch (_) {
            }
          }
          const ogTitleMatch = html ? html.match(/<meta property=["']og:title["'] content=["']([^"']+)["']/i) : null;
          const ogDescMatch = html ? html.match(/<meta property=["']og:description["'] content=["']([^"']+)["']/i) : null;
          const ogImageMatch = html ? html.match(/<meta property=["']og:image(?::secure_url|:url)?["'] content=["']([^"']+)["']/i) : null;
          const ogVideoMatch = html ? html.match(/<meta property=["']og:video(?::secure_url|:url)?["'] content=["']([^"']+)["']/i) : null;
          const titleTagMatch = html ? html.match(/<title>([^<]+)<\/title>/i) : null;
          let cleanTitle = ogTitleMatch ? ogTitleMatch[1] : ogDescMatch ? ogDescMatch[1] : titleTagMatch ? titleTagMatch[1] : "";
          cleanTitle = cleanTitle.replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/\s*\|\s*Facebook$/i, "").trim();
          if (cleanTitle.toLowerCase().includes("log in") || cleanTitle.toLowerCase() === "facebook") {
            cleanTitle = "";
          }
          const videoUrl = ogVideoMatch ? ogVideoMatch[1].replace(/&amp;/g, "&") : "";
          let imageUrl = ogImageMatch ? ogImageMatch[1].replace(/&amp;/g, "&") : "";
          if (!imageUrl && html) {
            const imgBlockMatch = html.match(/"image":\s*\{[^}]*"uri":"([^"]+)"/);
            if (imgBlockMatch) {
              imageUrl = imgBlockMatch[1].replace(/\\u0025/g, "%").replace(/\\\//g, "/").replace(/\\u([0-9a-fA-F]{4})/g, (_, h) => String.fromCharCode(parseInt(h, 16))).replace(/&amp;/g, "&");
            }
          }
          if (!imageUrl && fbid) {
            imageUrl = `https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=${fbid}`;
          }
          if (!cleanTitle && html) {
            const textMatch = html.match(/"text":"([^"]{8,300}?)"/);
            if (textMatch) {
              const rawTxt = textMatch[1].replace(/\\u0025/g, "%").replace(/\\\//g, "/").replace(/\\u([0-9a-fA-F]{4})/g, (_, h) => String.fromCharCode(parseInt(h, 16))).replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&#39;/g, "'").split("\\n")[0].trim();
              if (rawTxt && rawTxt.length >= 3 && !rawTxt.toLowerCase().includes("commenting has been turned off")) {
                cleanTitle = rawTxt;
              }
            }
          }
          if (!cleanTitle) {
            cleanTitle = fbid ? `Facebook Photo (${fbid})` : "Facebook Media";
          }
          if (cleanTitle.length > 90) cleanTitle = cleanTitle.substring(0, 90).trim() + "...";
          let scriptVideoHd = "";
          let scriptVideoSd = "";
          if (html) {
            const hdMatch = html.match(/"browser_native_hd_url":"([^"]+)"/) || html.match(/"playable_url_quality_hd":"([^"]+)"/);
            if (hdMatch) scriptVideoHd = hdMatch[1].replace(/\\u0025/g, "%").replace(/\\u([0-9a-fA-F]{4})/g, (_, h) => String.fromCharCode(parseInt(h, 16))).replace(/\\\//g, "/");
            const sdMatch = html.match(/"browser_native_sd_url":"([^"]+)"/) || html.match(/"playable_url":"([^"]+)"/);
            if (sdMatch) scriptVideoSd = sdMatch[1].replace(/\\u0025/g, "%").replace(/\\u([0-9a-fA-F]{4})/g, (_, h) => String.fromCharCode(parseInt(h, 16))).replace(/\\\//g, "/");
          }
          const bestVideo = scriptVideoHd || scriptVideoSd || videoUrl;
          if (bestVideo && !isExplicitPhoto) {
            const fmts = [];
            if (scriptVideoHd) {
              fmts.push({
                formatId: "fb_hd",
                url: scriptVideoHd,
                ext: "mp4",
                resolution: "1080p Full HD",
                quality: "1080p",
                width: 1920,
                height: 1080,
                hasAudioAndVideo: true,
                isVideo: true,
                isAudio: false
              });
            }
            if (scriptVideoSd) {
              fmts.push({
                formatId: "fb_sd",
                url: scriptVideoSd,
                ext: "mp4",
                resolution: "720p HD",
                quality: "720p",
                width: 1280,
                height: 720,
                hasAudioAndVideo: true,
                isVideo: true,
                isAudio: false
              });
            }
            if (fmts.length === 0) {
              fmts.push({
                formatId: "fb_video",
                url: bestVideo,
                ext: "mp4",
                resolution: "HD Video",
                hasAudioAndVideo: true,
                isVideo: true,
                isAudio: false
              });
            }
            return {
              id: "fb_" + Date.now(),
              url: resolvedUrl,
              title: cleanTitle || "Facebook Video",
              thumbnail: imageUrl || "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800",
              duration: 0,
              uploader: "Facebook",
              mediaType: "video",
              type: "video",
              directStreamUrl: bestVideo,
              downloadTarget: bestVideo,
              formats: fmts
            };
          }
          if (imageUrl) {
            return {
              id: `fb_photo_${fbid || Date.now()}`,
              url: resolvedUrl,
              title: cleanTitle,
              thumbnail: imageUrl,
              duration: 0,
              uploader: "Facebook",
              mediaType: "image",
              type: "image",
              isImage: true,
              directImageUrl: imageUrl,
              directStreamUrl: imageUrl,
              downloadTarget: imageUrl,
              formats: [
                {
                  formatId: "photo_original",
                  url: imageUrl,
                  ext: "jpg",
                  resolution: "Original High-Res Photo",
                  isAudioOnly: false,
                  isVideoOnly: false,
                  isImage: true
                }
              ]
            };
          }
        } catch (fbHtmlErr) {
          logger.warn("Facebook HTML parsing notice:", fbHtmlErr.message);
        }
        if (fbid) {
          const fallbackPhotoUrl = `https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=${fbid}`;
          return {
            id: `fb_photo_${fbid}`,
            url: resolvedUrl,
            title: `Facebook Photo (${fbid})`,
            thumbnail: fallbackPhotoUrl,
            duration: 0,
            uploader: "Facebook",
            mediaType: "image",
            type: "image",
            isImage: true,
            directImageUrl: fallbackPhotoUrl,
            directStreamUrl: fallbackPhotoUrl,
            downloadTarget: fallbackPhotoUrl,
            formats: [
              {
                formatId: "photo_original",
                url: fallbackPhotoUrl,
                ext: "jpg",
                resolution: "Original High-Res Photo",
                isAudioOnly: false,
                isVideoOnly: false,
                isImage: true
              }
            ]
          };
        }
        throw new Error("Could not extract media from Facebook link. The post may be private or deleted.");
      }
      isTikTokUrl(urlStr) {
        if (!this.isValidUrl(urlStr)) return false;
        const lower = urlStr.toLowerCase();
        return lower.includes("tiktok.com") || lower.includes("tiktokcdn") || lower.includes("vm.tiktok.com") || lower.includes("vt.tiktok.com");
      }
      isThreadsUrl(urlStr) {
        if (!this.isValidUrl(urlStr)) return false;
        return /threads\.(?:net|com)/i.test(urlStr);
      }
      isSpotifyUrl(urlStr) {
        if (!this.isValidUrl(urlStr)) return false;
        return /spotify\.(?:com|link)/i.test(urlStr);
      }
      isAppleMusicUrl(urlStr) {
        if (!this.isValidUrl(urlStr)) return false;
        return /music\.apple\.com|itunes\.apple\.com/i.test(urlStr);
      }
      isAppleMusicAlbumUrl(urlStr) {
        if (!this.isValidUrl(urlStr)) return false;
        const isApple = /music\.apple\.com|itunes\.apple\.com/i.test(urlStr);
        if (!isApple) return false;
        const isSingleTrack = /[?&](?:i|track)=(\d+)/i.test(urlStr);
        return !isSingleTrack && /(?:\/album\/|\/playlist\/|\/artist\/)/i.test(urlStr);
      }
      isBehanceUrl(urlStr) {
        if (!this.isValidUrl(urlStr)) return false;
        return /behance\.(?:net|com)/i.test(urlStr);
      }
      isDribbbleUrl(urlStr) {
        if (!this.isValidUrl(urlStr)) return false;
        return /dribbble\.com/i.test(urlStr);
      }
      isArtStationUrl(urlStr) {
        if (!this.isValidUrl(urlStr)) return false;
        return /artstation\.com/i.test(urlStr);
      }
      isFiverrUrl(urlStr) {
        if (!this.isValidUrl(urlStr)) return false;
        return /fiverr\.com/i.test(urlStr);
      }
      isPinterestUrl(urlStr) {
        if (!this.isValidUrl(urlStr)) return false;
        const lower = urlStr.toLowerCase();
        return lower.includes("pinterest.") || lower.includes("pin.it");
      }
      async expandPinterestUrl(urlStr) {
        if (!urlStr || !urlStr.includes("pin.it")) return urlStr;
        try {
          const res = await fetchHtml(urlStr);
          if (res.finalUrl && !res.finalUrl.includes("pin.it")) {
            return res.finalUrl;
          }
        } catch (e) {
          logger.warn("[Analyzer] Failed to expand pin.it with fetchHtml:", e.message);
        }
        return urlStr;
      }
      async analyzeThreads(url, timeoutMs = 25e3) {
        logger.info(`Analyzing Threads post: ${url}`);
        try {
          let html = "";
          let finalUrl = url;
          try {
            const res = await fetchHtml(url, {
              "User-Agent": "facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)"
            });
            html = res.body || "";
            finalUrl = res.finalUrl || url;
          } catch (fErr) {
            logger.warn("Threads initial fetch notice:", fErr.message);
          }
          if (!html || !html.includes("og:video") && !html.includes(".mp4") && !html.includes("og:image")) {
            try {
              const dom = await dumpHeadlessDom(url, 15e3);
              if (dom) html = dom;
            } catch (_) {
            }
          }
          let clean = (html || "").replace(/\\u0025/g, "%").replace(/\\u0026/g, "&").replace(/\\\//g, "/").replace(/&amp;/g, "&");
          if (!clean.includes('"carousel_media":[')) {
            try {
              const dom = await dumpHeadlessDom(url, 15e3);
              if (dom) {
                html = dom;
                clean = html.replace(/\\u0025/g, "%").replace(/\\u0026/g, "&").replace(/\\\//g, "/").replace(/&amp;/g, "&");
              }
            } catch (_) {
            }
          }
          let ogVideo = clean.match(/<meta[^>]+property=["']og:video(?::secure_url)?["'][^>]+content=["']([^"']+)["']/i)?.[1];
          const ogTitle = clean.match(/<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']/i)?.[1];
          const ogDesc = clean.match(/<meta[^>]+property=["']og:description["'][^>]+content=["']([^"']+)["']/i)?.[1];
          let ogImage = clean.match(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i)?.[1];
          if (ogImage && ogImage.includes("rsrc.php")) ogImage = "";
          let author = "Threads Creator";
          let title = "Threads Post";
          const urlAuthorMatch = (finalUrl || url).match(/@([a-zA-Z0-9._]+)/);
          if (urlAuthorMatch) {
            author = "@" + urlAuthorMatch[1];
          } else if (ogTitle) {
            const aMatch = ogTitle.match(/@([a-zA-Z0-9._]+)/);
            if (aMatch) author = "@" + aMatch[1];
          }
          if (ogDesc) {
            let cleanDesc = ogDesc.replace(/&amp;/g, "&").replace(/&#x[0-9a-fA-F]+;/g, " ").replace(/&#[0-9]+;/g, " ").replace(/&quot;/g, '"').replace(/https?:\/\/\S+/g, "").trim();
            const firstLine = cleanDesc.split(/[\r\n]+/)[0]?.trim();
            if (firstLine && firstLine.length >= 3) {
              title = firstLine.length > 120 ? firstLine.substring(0, 117) + "..." : firstLine;
            } else if (cleanDesc.length >= 3) {
              title = cleanDesc.length > 120 ? cleanDesc.substring(0, 117) + "..." : cleanDesc;
            }
          }
          const isGenericThreadsTitle = !title || title === "Threads Post" || title.toLowerCase().includes("log in") || title.toLowerCase().includes("login") || title.toLowerCase().includes("join threads") || title.toLowerCase().includes("sign up");
          if (isGenericThreadsTitle) {
            title = author && author !== "Threads Creator" ? `Threads Post (${author})` : "Threads Post";
          }
          const scMatch = (finalUrl || url).match(/(?:post|share|t)\/([a-zA-Z0-9_-]+)/i);
          const shortcode = scMatch ? scMatch[1] : "";
          const carouselItems = [];
          const carouselStart = clean.indexOf('"carousel_media":[');
          if (carouselStart !== -1) {
            let inString = false;
            let escape = false;
            let depth = 0;
            let carouselEnd = -1;
            for (let i = carouselStart + '"carousel_media":'.length; i < clean.length; i++) {
              const c = clean[i];
              if (escape) {
                escape = false;
                continue;
              }
              if (c === "\\") {
                escape = true;
                continue;
              }
              if (c === '"') {
                inString = !inString;
                continue;
              }
              if (!inString) {
                if (c === "[") depth++;
                else if (c === "]") {
                  depth--;
                  if (depth === 0) {
                    carouselEnd = i;
                    break;
                  }
                }
              }
            }
            if (carouselEnd !== -1) {
              try {
                const jsonArrStr = clean.substring(carouselStart + '"carousel_media":'.length, carouselEnd + 1);
                const arr = JSON.parse(jsonArrStr);
                if (Array.isArray(arr) && arr.length > 0) {
                  for (let idx = 0; idx < arr.length; idx++) {
                    const it = arr[idx];
                    const isVid = Array.isArray(it.video_versions) && it.video_versions.length > 0;
                    let targetUrl = "";
                    let thumbUrl = "";
                    let duration = 0;
                    if (isVid) {
                      const sortedVids = it.video_versions.slice().sort((a, b) => (b.width || 0) - (a.width || 0));
                      targetUrl = sortedVids[0]?.url || "";
                      duration = Math.round(it.video_duration || 30);
                    }
                    if (it.image_versions2 && Array.isArray(it.image_versions2.candidates)) {
                      const sortedImgs = it.image_versions2.candidates.slice().sort((a, b) => (b.width || 0) - (a.width || 0));
                      thumbUrl = sortedImgs[0]?.url || "";
                      if (!targetUrl) targetUrl = thumbUrl;
                    }
                    if (targetUrl) {
                      carouselItems.push({
                        id: `threads_item_${idx + 1}`,
                        index: idx + 1,
                        title: `${title} (${isVid ? "Video" : "Photo"} ${idx + 1})`,
                        url: targetUrl,
                        thumbnail: thumbUrl || targetUrl,
                        duration,
                        downloadQuery: targetUrl,
                        downloadTarget: targetUrl,
                        directStreamUrl: targetUrl,
                        uploader: author,
                        mediaType: isVid ? "video" : "image",
                        type: isVid ? "video" : "image",
                        isVideo: isVid,
                        isImage: !isVid,
                        referer: "https://www.threads.net/"
                      });
                    }
                  }
                }
              } catch (cErr) {
                logger.warn("carousel_media JSON parse notice:", cErr.message);
              }
            }
          }
          if (carouselItems.length > 1) {
            return {
              id: shortcode || "threads_multi_" + Date.now(),
              url,
              title,
              uploader: author,
              itemCount: carouselItems.length,
              isPlaylist: true,
              isCarousel: true,
              referer: "https://www.threads.net/",
              thumbnail: carouselItems[0].thumbnail,
              items: carouselItems
            };
          }
          const allVids = clean.match(/https:\/\/[a-zA-Z0-9.\-_]+(?:fbcdn\.net|cdninstagram\.com)[^"\'><\s\\]+?\.mp4[^"\'><\s\\]*/g) || [];
          const validVids = [...new Set(allVids.filter((v) => !v.includes("rsrc.php") && v.includes("oh=") && v.includes("oe=")))];
          const hasVideo = validVids.length > 0 || !!ogVideo;
          const targetVideoUrl = validVids[0] || ogVideo || "";
          let targetImageUrl = ogImage || "";
          if (!targetImageUrl) {
            const allImgs = clean.match(/https:\/\/[a-zA-Z0-9.\-_]+(?:fbcdn\.net|cdninstagram\.com)[^"\'><\s\\]+?\.(?:jpe?g|webp|png)[^"\'><\s\\]*/g) || [];
            const validImgs = allImgs.filter((im) => !im.includes("rsrc.php") && !im.includes("profile_pic") && !im.includes("-19/") && !im.includes("/emg") && !im.includes("150x150"));
            targetImageUrl = validImgs[0] || "";
          }
          let videoDuration = 0;
          if (hasVideo && targetVideoUrl) {
            videoDuration = await probeMediaDuration(targetVideoUrl);
            if (!videoDuration) videoDuration = 30;
          }
          const streamUrl = hasVideo ? targetVideoUrl : targetImageUrl;
          const thumbnail = targetImageUrl || "https://images.unsplash.com/photo-1611605698335-8b1569810432?w=800";
          const formats = [];
          if (hasVideo) {
            formats.push({
              formatId: "threads-best",
              ext: "mp4",
              resolution: "1080x1920",
              height: 1080,
              width: 1920,
              vcodec: "h264",
              acodec: "aac",
              isAudioOnly: false,
              isVideoOnly: false,
              hasAudioAndVideo: true,
              qualityLabel: "1080p Full HD",
              url: streamUrl
            });
            formats.push({
              formatId: "threads-720p",
              ext: "mp4",
              resolution: "720x1280",
              height: 720,
              width: 1280,
              vcodec: "h264",
              acodec: "aac",
              isAudioOnly: false,
              isVideoOnly: false,
              hasAudioAndVideo: true,
              qualityLabel: "720p HD",
              url: streamUrl
            });
            formats.push({
              formatId: "threads-audio",
              ext: "mp3",
              isAudioOnly: true,
              isVideoOnly: false,
              hasAudioAndVideo: false,
              qualityLabel: "Audio (MP3 320kbps)",
              url: streamUrl
            });
          } else if (streamUrl) {
            formats.push({
              formatId: "threads-image",
              ext: "jpg",
              resolution: "Original Photo",
              isAudioOnly: false,
              isVideoOnly: false,
              hasAudioAndVideo: false,
              isImage: true,
              qualityLabel: "Original Photo (JPG)",
              url: streamUrl
            });
          }
          return {
            id: shortcode || "threads_" + Date.now(),
            url,
            directStreamUrl: streamUrl,
            downloadTarget: streamUrl,
            title,
            thumbnail,
            duration: hasVideo ? videoDuration || 30 : 0,
            uploader: author,
            channel: author,
            description: ogDesc,
            extractor: "Threads",
            mediaType: hasVideo ? "video" : "image",
            type: hasVideo ? "video" : "image",
            formats,
            availableResolutions: hasVideo ? [1080, 720] : [],
            hasAudio: hasVideo,
            hasVideo,
            hasImage: !hasVideo && !!streamUrl,
            referer: "https://www.threads.net/",
            defaultProfile: {
              type: hasVideo ? "video" : "image",
              presetId: hasVideo ? "best-available" : "original-image",
              label: hasVideo ? "Best Available Quality (Universal H.264)" : "Original Photo (JPG)",
              container: hasVideo ? "mp4" : "jpg",
              remuxToMp4: hasVideo
            }
          };
        } catch (err) {
          logger.error("Threads analysis failed:", err);
          throw classifyError(err, "Failed to analyze Threads media");
        }
      }
      async analyzeSpotify(url, timeoutMs = 35e3) {
        if (this.isSpotifyPlaylistUrl(url)) {
          return await this.analyzePlaylist(url, timeoutMs);
        }
        logger.info(`Analyzing Spotify track: ${url}`);
        try {
          let trackTitle = "";
          let artist = "";
          let thumbnail = "";
          let durationSec = 0;
          let previewAudio = "";
          const trackIdMatch = url.match(/track\/([a-zA-Z0-9]+)/);
          const trackId = trackIdMatch ? trackIdMatch[1] : "";
          try {
            const { body: ssrHtml, statusCode: ssrStatus } = await fetchHtml(url, {
              "User-Agent": "facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)"
            });
            if (ssrStatus === 200) {
              const ogTitleMatch = ssrHtml.match(/<meta property=["']og:title["'] content=["']([^"']+)["']/i);
              const ogDescMatch = ssrHtml.match(/<meta property=["']og:description["'] content=["']([^"']+)["']/i);
              const ogImageMatch = ssrHtml.match(/<meta property=["']og:image["'] content=["']([^"']+)["']/i);
              const durationMatch = ssrHtml.match(/<meta property=["']music:duration["'] content=["']([^"']+)["']/i);
              if (ogTitleMatch && ogTitleMatch[1] && !ogTitleMatch[1].startsWith("Spotify")) {
                trackTitle = ogTitleMatch[1];
              }
              if (ogDescMatch && ogDescMatch[1]) {
                const parts = ogDescMatch[1].split("\xB7").map((s) => s.trim());
                if (parts.length > 0 && parts[0]) artist = parts[0];
              }
              if (ogImageMatch && ogImageMatch[1]) {
                thumbnail = ogImageMatch[1];
              }
              if (durationMatch && durationMatch[1]) {
                durationSec = parseInt(durationMatch[1], 10);
              }
            }
          } catch (ssrErr) {
            logger.warn("Spotify SSR scraper notice:", ssrErr);
          }
          if (trackId) {
            try {
              const embedUrl = `https://open.spotify.com/embed/track/${trackId}`;
              const { body: embedHtml } = await fetchHtml(embedUrl);
              const nextDataMatch = embedHtml.match(/<script id="__NEXT_DATA__" type="application\/json">([\s\S]+?)<\/script>/);
              if (nextDataMatch) {
                const nextData = JSON.parse(nextDataMatch[1]);
                const entity = nextData.props?.pageProps?.state?.data?.entity;
                if (entity) {
                  if (entity.name && (!trackTitle || trackTitle === "Spotify Track")) {
                    trackTitle = entity.name;
                  }
                  if (entity.artists && Array.isArray(entity.artists) && entity.artists.length > 0) {
                    artist = entity.artists.map((a) => a.name).filter(Boolean).join(", ");
                  }
                  if (entity.duration) {
                    durationSec = Math.round(entity.duration / 1e3);
                  }
                  if (entity.audioPreview?.url) {
                    previewAudio = entity.audioPreview.url;
                  }
                  const coverImg = entity.visualIdentity?.image?.[1]?.url || entity.visualIdentity?.image?.[0]?.url || entity.coverArt?.sources?.[0]?.url;
                  if (coverImg && (!thumbnail || thumbnail.includes("unsplash"))) {
                    thumbnail = coverImg;
                  }
                }
              }
            } catch (embErr) {
              logger.warn("Spotify embed parse notice:", embErr);
            }
          }
          if (!trackTitle) {
            try {
              const oembedUrl = `https://open.spotify.com/oembed?url=${encodeURIComponent(url)}`;
              const { body: oembedJson } = await fetchHtml(oembedUrl);
              const oembed = JSON.parse(oembedJson);
              if (oembed.title) trackTitle = oembed.title;
              if (oembed.thumbnail_url && !thumbnail) thumbnail = oembed.thumbnail_url;
            } catch (oeErr) {
              logger.warn("Spotify oembed notice:", oeErr);
            }
          }
          if (!trackTitle || trackTitle === "Spotify Track") {
            throw new Error("This Spotify track could not be found, is region-locked, or has been removed from Spotify.");
          }
          if (!artist) artist = "Spotify";
          if (!thumbnail) thumbnail = "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800";
          if (!durationSec) durationSec = 180;
          const query = `ytsearch1:${trackTitle} ${artist} audio`.trim();
          logger.info(`Pairing Spotify track with YouTube stream query: ${query}`);
          const ytdlpPath = await dependencyManager.getYtDlpExecutablePath();
          const ytArgs = await youtubeTokenManager.getYtDlpExtractorArgs(url);
          const args = [
            "--dump-single-json",
            "--no-playlist",
            "--no-check-certificates",
            "--prefer-free-formats",
            ...ytArgs,
            "--add-header",
            "User-Agent:Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
            query
          ];
          let meta;
          try {
            const { stdout } = await execFileAsync2(ytdlpPath, args, {
              windowsHide: true,
              timeout: Math.min(timeoutMs, 15e3),
              maxBuffer: 30 * 1024 * 1024
            });
            const raw = JSON.parse(stdout);
            const entry = raw.entries && raw.entries.length > 0 ? raw.entries[0] : raw;
            meta = await this.parseYtDlpOutput(url, entry);
          } catch (ytSearchErr) {
            logger.warn("YouTube pairing search notice during Spotify analysis:", ytSearchErr.message);
            meta = {
              id: trackId || "spotify_track",
              url,
              title: trackTitle,
              formats: [{
                format_id: "audio_mp3_320",
                ext: "mp3",
                resolution: "audio only",
                note: "MP3 320kbps High Quality Audio"
              }],
              duration: durationSec || 180,
              thumbnail
            };
          }
          meta.id = trackId || (meta.id || "spotify_track");
          meta.url = url;
          meta.title = trackTitle;
          meta.thumbnail = thumbnail;
          meta.uploader = artist;
          meta.channel = artist;
          meta.extractor = "Spotify";
          meta.platform = "spotify";
          meta.isSpotify = true;
          meta.mediaType = "audio";
          meta.type = "audio";
          meta.audioPreviewUrl = previewAudio;
          meta.directStreamUrl = previewAudio || meta.directStreamUrl || "";
          meta.downloadTarget = previewAudio || meta.downloadTarget || "";
          meta.hasVideo = false;
          meta.hasAudio = true;
          meta.availableResolutions = [];
          meta.formats = [
            ...previewAudio ? [{
              format_id: "spotify_preview",
              formatId: "spotify_preview",
              ext: "mp3",
              resolution: "Audio Preview (MP3)",
              qualityLabel: "Audio Preview (MP3)",
              url: previewAudio,
              hasAudio: true,
              hasVideo: false,
              isAudio: true
            }] : [],
            {
              format_id: "audio_mp3_320",
              ext: "mp3",
              resolution: "audio only",
              qualityLabel: "MP3 320kbps High Quality Audio",
              note: "MP3 320kbps High Quality Audio",
              isAudioOnly: true
            },
            {
              format_id: "audio_mp3_192",
              ext: "mp3",
              resolution: "audio only",
              qualityLabel: "MP3 192kbps Clean Audio",
              note: "MP3 192kbps Clean Audio",
              isAudioOnly: true
            },
            {
              format_id: "audio_wav",
              ext: "wav",
              resolution: "audio only",
              qualityLabel: "Lossless WAV (48kHz Studio Audio)",
              note: "Lossless WAV Audio",
              isAudioOnly: true
            }
          ];
          meta.duration = durationSec > 0 ? durationSec : meta.duration;
          meta.downloadQuery = query;
          meta.downloadTarget = meta.webpage_url || query;
          delete meta.directStreamUrl;
          meta.defaultProfile = {
            type: "audio",
            presetId: "best-audio",
            label: "Best Audio Quality (MP3 320kbps)",
            container: "mp3"
          };
          return meta;
        } catch (err) {
          logger.error("Spotify analysis failed:", err);
          throw classifyError(err, "Failed to analyze Spotify song");
        }
      }
      async analyzeAppleMusic(url, timeoutMs = 35e3) {
        if (this.isAppleMusicAlbumUrl(url)) {
          return await this.analyzePlaylist(url, timeoutMs);
        }
        logger.info(`Analyzing Apple Music song: ${url}`);
        try {
          let trackTitle = "";
          let artist = "";
          let thumbnail = "";
          let durationSec = 180;
          let trackId = "";
          let previewUrl = "";
          const iMatch = url.match(/[?&](?:i|track)=(\d+)/i);
          if (iMatch) {
            trackId = iMatch[1];
          } else {
            const idMatch = url.match(/\/(\d+)(?:\?|$)/);
            if (idMatch) trackId = idMatch[1];
          }
          if (trackId) {
            try {
              const itunesApi = `https://itunes.apple.com/lookup?id=${trackId}`;
              const { body: itunesBody } = await fetchHtml(itunesApi);
              const data = JSON.parse(itunesBody);
              if (data && data.results && data.results.length > 0) {
                const item = data.results[0];
                trackTitle = item.trackName || item.collectionName || "";
                artist = item.artistName || "";
                thumbnail = (item.artworkUrl100 || "").replace("100x100bb", "600x600bb");
                if (item.trackTimeMillis) {
                  durationSec = Math.round(item.trackTimeMillis / 1e3);
                }
                if (item.previewUrl) {
                  previewUrl = item.previewUrl;
                }
              }
            } catch (itErr) {
              logger.warn("iTunes lookup error for Apple Music:", itErr);
            }
          }
          if (!trackTitle) {
            try {
              const { body: html } = await fetchHtml(url, {
                "User-Agent": "facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)"
              });
              const ogTitle = html.match(/<meta property=["']og:title["'] content=["']([^"']+)["']/i)?.[1];
              const ogDesc = html.match(/<meta property=["']og:description["'] content=["']([^"']+)["']/i)?.[1];
              const ogImg = html.match(/<meta property=["']og:image["'] content=["']([^"']+)["']/i)?.[1];
              if (ogTitle) trackTitle = ogTitle;
              if (ogDesc && !artist) {
                const parts = ogDesc.split("\xB7").map((s) => s.trim());
                if (parts.length > 0) artist = parts[0];
              }
              if (ogImg && !thumbnail) thumbnail = ogImg;
            } catch (ogErr) {
              logger.warn("Apple Music OG tag fallback notice:", ogErr);
            }
          }
          if (!trackTitle) {
            throw new Error("This Apple Music song could not be found or previewed.");
          }
          if (!artist) artist = "Apple Music";
          if (!thumbnail) thumbnail = "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800";
          const query = `ytsearch1:${trackTitle} ${artist} audio`.trim();
          logger.info(`Pairing Apple Music track with YouTube audio query: ${query}`);
          const ytdlpPath = await dependencyManager.getYtDlpExecutablePath();
          const ytArgs = await youtubeTokenManager.getYtDlpExtractorArgs(url);
          const args = [
            "--dump-single-json",
            "--no-playlist",
            "--no-check-certificates",
            "--prefer-free-formats",
            ...ytArgs,
            "--add-header",
            "User-Agent:Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
            query
          ];
          let meta;
          try {
            const { stdout } = await execFileAsync2(ytdlpPath, args, {
              windowsHide: true,
              timeout: Math.min(timeoutMs, 15e3),
              maxBuffer: 30 * 1024 * 1024
            });
            const raw = JSON.parse(stdout);
            const entry = raw.entries && raw.entries.length > 0 ? raw.entries[0] : raw;
            meta = await this.parseYtDlpOutput(url, entry);
          } catch (ytSearchErr) {
            logger.warn("YouTube pairing notice during Apple Music analysis:", ytSearchErr.message);
            meta = {
              id: trackId || "apple_music_track",
              url,
              title: trackTitle,
              formats: [{
                format_id: "audio_mp3_320",
                ext: "mp3",
                resolution: "audio only",
                note: "MP3 320kbps High Quality Audio"
              }],
              duration: durationSec || 180,
              thumbnail
            };
          }
          meta.id = trackId || (meta.id || "apple_music_track");
          meta.url = url;
          meta.title = trackTitle;
          meta.thumbnail = thumbnail;
          meta.uploader = artist;
          meta.channel = artist;
          meta.extractor = "AppleMusic";
          meta.platform = "apple_music";
          meta.isAppleMusic = true;
          meta.mediaType = "audio";
          meta.hasVideo = false;
          meta.hasAudio = true;
          meta.availableResolutions = [];
          meta.formats = [
            {
              format_id: "apple_aac_256",
              ext: "m4a",
              resolution: "audio only",
              qualityLabel: "Apple Lossless / AAC (256 kbps Master)",
              note: "Apple Music Master Audio",
              isAudioOnly: true
            },
            {
              format_id: "audio_mp3_320",
              ext: "mp3",
              resolution: "audio only",
              qualityLabel: "MP3 320kbps High Quality Audio",
              note: "MP3 320kbps High Quality Audio",
              isAudioOnly: true
            },
            {
              format_id: "audio_wav",
              ext: "wav",
              resolution: "audio only",
              qualityLabel: "Lossless WAV (48kHz Studio Audio)",
              note: "Lossless WAV Audio",
              isAudioOnly: true
            }
          ];
          meta.duration = durationSec > 0 ? durationSec : meta.duration;
          meta.downloadQuery = query;
          meta.downloadTarget = meta.webpage_url || query;
          if (previewUrl) {
            meta.directStreamUrl = previewUrl;
            meta.audioPreviewUrl = previewUrl;
            meta.previewUrl = previewUrl;
          }
          meta.defaultProfile = {
            type: "audio",
            presetId: "best-audio",
            label: "Best Audio Quality (MP3 320kbps)",
            container: "mp3"
          };
          return meta;
        } catch (err) {
          logger.error("Apple Music analysis failed:", err);
          throw classifyError(err, "Failed to analyze Apple Music song");
        }
      }
      async fetchBehanceHtml(url) {
        const fetchWithHeader = (ua, cookie = "") => {
          return new Promise((resolve) => {
            const u = new URL(url);
            const req = import_https2.default.request({
              hostname: u.hostname,
              path: u.pathname + u.search,
              method: "GET",
              headers: {
                "User-Agent": ua,
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "Accept-Language": "en-US,en;q=0.9",
                ...cookie ? { "Cookie": cookie } : {}
              }
            }, (res2) => {
              let b = "";
              res2.on("data", (c) => b += c);
              res2.on("end", () => resolve({ status: res2.statusCode, headers: res2.headers, body: b }));
            });
            req.on("error", () => resolve({ status: 500, body: "" }));
            req.end();
          });
        };
        const botUa = "Mozilla/5.0 (compatible; Discordbot/2.0; +https://discordapp.com)";
        let res = await fetchWithHeader(botUa);
        if (res.body && res.body.includes("beconfig-store_state")) {
          return res.body;
        }
        const cookieMatch = (res.body || "").match(/js_challenge_value=([a-f0-9]+)/);
        if (cookieMatch) {
          const challengeCookie = `js_challenge_value=${cookieMatch[1]}`;
          const res2 = await fetchWithHeader(botUa, challengeCookie);
          if (res2.body && res2.body.includes("beconfig-store_state")) {
            return res2.body;
          }
        }
        const fbUa = "facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)";
        let fbRes = await fetchWithHeader(fbUa);
        const fbCookieMatch = (fbRes.body || "").match(/js_challenge_value=([a-f0-9]+)/);
        if (fbCookieMatch) {
          const challengeCookie = `js_challenge_value=${fbCookieMatch[1]}`;
          const fbRes2 = await fetchWithHeader(fbUa, challengeCookie);
          if (fbRes2.body && fbRes2.body.includes("beconfig-store_state")) {
            return fbRes2.body;
          }
        }
        const ddgUa = "DuckDuckBot/1.0; (+http://duckduckgo.com/duckduckbot.html)";
        let ddgRes = await fetchWithHeader(ddgUa);
        return ddgRes.body || res.body || "";
      }
      async analyzeBehance(url, timeoutMs = 35e3) {
        logger.info(`Analyzing Behance URL: ${url}`);
        try {
          const idMatch = url.match(/(?:gallery|projects)\/(\d+)/i);
          const projectId = idMatch ? idMatch[1] : "";
          let proj = null;
          if (projectId) {
            try {
              const apiUrl = `https://www.behance.net/v2/projects/${projectId}?client_id=behance1`;
              const apiRes = await fetch(apiUrl, {
                headers: {
                  "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
                  "Referer": "https://www.behance.net/"
                },
                signal: AbortSignal.timeout(Math.min(timeoutMs, 15e3))
              });
              if (apiRes.ok) {
                const apiData = await apiRes.json();
                if (apiData && apiData.project) {
                  proj = apiData.project;
                }
              }
            } catch (apiErr) {
              logger.warn(`Behance API fetch attempt failed: ${apiErr.message}`);
            }
          }
          if (!proj) {
            const html = await this.fetchBehanceHtml(url);
            if (html && html.includes("beconfig-store_state")) {
              const jsonStr = html.split('id="beconfig-store_state">')[1].split("</script>")[0];
              const raw = JSON.parse(jsonStr);
              proj = raw.project?.project;
            }
          }
          if (!proj) throw new Error("Behance project details not found.");
          const title = proj.name || proj.title || "Behance Media";
          const uploader = proj.owners && proj.owners.length > 0 ? proj.owners[0].displayName || proj.owners[0].display_name || proj.owners[0].first_name || "Behance Creator" : "Behance Creator";
          const thumbnail = proj.covers?.["808"] || proj.covers?.["404"] || proj.covers?.["original"] || "";
          const mediaItems = [];
          let itemIndex = 1;
          for (const m of proj.modules || []) {
            if ((m.type === "video" || m.__typename === "VideoModule") && m.videoData?.renditions?.length) {
              const bestRendition = m.videoData.renditions.slice().sort((a, b) => (b.height || 0) - (a.height || 0))[0];
              if (bestRendition && bestRendition.url) {
                mediaItems.push({
                  id: `behance_v_${m.id || itemIndex}`,
                  index: itemIndex++,
                  title: `${title} - Video ${itemIndex - 1}`,
                  url: bestRendition.url,
                  downloadTarget: bestRendition.url,
                  directStreamUrl: bestRendition.url,
                  thumbnail: m.thumbnail || thumbnail,
                  uploader,
                  type: "video",
                  mediaType: "video",
                  referer: "https://www.behance.net/",
                  resolution: `${bestRendition.height || 1080}p`
                });
              }
            }
            const embedHtml = m.originalEmbed || m.embed || m.fluidEmbed || "";
            if (embedHtml) {
              const srcMatch = embedHtml.match(/src=["']([^"']+)["']/i);
              if (srcMatch && srcMatch[1]) {
                let embedSrc = srcMatch[1].replace(/&amp;/g, "&");
                const vimeoId = embedSrc.match(/vimeo\.com\/(?:video\/)?(\d+)/i)?.[1];
                let targetUrl = embedSrc;
                if (vimeoId) {
                  targetUrl = `https://player.vimeo.com/video/${vimeoId}`;
                  embedSrc = `https://player.vimeo.com/video/${vimeoId}`;
                }
                const ytId = embedSrc.match(/(?:youtube\.com\/(?:embed\/|watch\?v=)|youtu\.be\/)([a-zA-Z0-9_-]{11})/i)?.[1];
                if (ytId) {
                  targetUrl = `https://www.youtube.com/watch?v=${ytId}`;
                }
                const hMatch = embedHtml.match(/height=["'](\d+)["']/i);
                const h = hMatch ? parseInt(hMatch[1], 10) : 1080;
                mediaItems.push({
                  id: `behance_embed_${m.id || itemIndex}`,
                  index: itemIndex++,
                  title: `${title} - Video ${itemIndex - 1}`,
                  url: targetUrl,
                  downloadTarget: targetUrl,
                  embedUrl: embedSrc,
                  thumbnail,
                  uploader,
                  type: "video",
                  mediaType: "video",
                  referer: "https://www.behance.net/",
                  resolution: `${h}p`
                });
              }
            }
            if (m.type === "image" || m.__typename === "ImageModule") {
              const imgUrl = m.sizes?.original || m.sizes?.source || m.sizes?.max_3840 || m.sizes?.max_1920 || m.sizes?.["1400"] || m.sizes?.max_1200 || m.src;
              if (imgUrl) {
                mediaItems.push({
                  id: `behance_img_${m.id || itemIndex}`,
                  index: itemIndex++,
                  title: `${title} - Image ${itemIndex - 1}`,
                  url: imgUrl,
                  downloadTarget: imgUrl,
                  thumbnail: imgUrl,
                  uploader,
                  type: "image",
                  mediaType: "image",
                  referer: "https://www.behance.net/",
                  resolution: "High Resolution Image"
                });
              }
            }
            if (m.type === "media_collection" && Array.isArray(m.components)) {
              for (const comp of m.components) {
                const compUrl = comp.sizes?.original || comp.sizes?.source || comp.sizes?.max_3840 || comp.sizes?.max_1920 || comp.sizes?.["1400"] || comp.sizes?.max_1200 || comp.src;
                if (compUrl) {
                  mediaItems.push({
                    id: `behance_col_${comp.id || itemIndex}`,
                    index: itemIndex++,
                    title: `${title} - Slide ${itemIndex - 1}`,
                    url: compUrl,
                    downloadTarget: compUrl,
                    thumbnail: compUrl,
                    uploader,
                    type: "image",
                    mediaType: "image",
                    referer: "https://www.behance.net/",
                    resolution: "High Resolution Image"
                  });
                }
              }
            }
          }
          if (mediaItems.length === 0) {
            if (thumbnail) {
              mediaItems.push({
                id: `behance_cover_${proj.id || Date.now()}`,
                index: 1,
                title,
                url: thumbnail,
                downloadTarget: thumbnail,
                thumbnail,
                uploader,
                type: "image",
                mediaType: "image",
                referer: "https://www.behance.net/",
                resolution: "Original Cover"
              });
            } else {
              throw new Error("No downloadable media found in this Behance project.");
            }
          }
          const effectiveItems = mediaItems;
          if (effectiveItems.length > 1) {
            return {
              id: `behance_${proj.id || Date.now()}`,
              isPlaylist: true,
              isCarousel: true,
              url,
              title,
              uploader,
              itemCount: effectiveItems.length,
              items: effectiveItems.map((item) => ({
                id: item.id,
                url: item.url,
                title: item.title,
                thumbnail: item.thumbnail,
                duration: 0,
                downloadQuery: item.downloadTarget,
                downloadTarget: item.downloadTarget,
                uploader,
                type: item.type,
                mediaType: item.type,
                referer: "https://www.behance.net/",
                embedUrl: item.embedUrl || "",
                directStreamUrl: item.directStreamUrl || ""
              })),
              thumbnail,
              referer: "https://www.behance.net/",
              downloadTarget: effectiveItems[0].downloadTarget,
              directStreamUrl: effectiveItems[0].directStreamUrl || "",
              formats: [
                {
                  formatId: effectiveItems[0].type === "image" ? "behance_img_orig" : "behance_vid_best",
                  ext: effectiveItems[0].type === "image" ? "jpg" : "mp4",
                  resolution: effectiveItems[0].resolution || "1080p",
                  url: effectiveItems[0].downloadTarget,
                  isImage: effectiveItems[0].type === "image"
                }
              ]
            };
          }
          const single = effectiveItems[0];
          const isImg = single.type === "image";
          return {
            id: single.id,
            url,
            title: single.title,
            uploader,
            thumbnail: single.thumbnail,
            duration: 0,
            formats: [
              {
                formatId: isImg ? "behance_image_orig" : "behance_video_best",
                ext: isImg ? "jpg" : "mp4",
                resolution: single.resolution,
                url: single.downloadTarget,
                isImage: isImg
              }
            ],
            downloadTarget: single.downloadTarget,
            directStreamUrl: single.directStreamUrl || (isImg ? single.downloadTarget : ""),
            embedUrl: single.embedUrl || "",
            platform: "behance",
            mediaType: isImg ? "image" : "video"
          };
        } catch (err) {
          logger.error("Behance analysis failed:", err);
          throw classifyError(err, "Failed to extract media from Behance");
        }
      }
      async analyzeDribbble(url, timeoutMs = 35e3) {
        logger.info(`Analyzing Dribbble URL: ${url}`);
        try {
          const res = await fetchHtml(url, {
            "User-Agent": "DuckDuckBot/1.0; (+http://duckduckgo.com/duckduckbot.html)",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
          });
          const html = res.body || "";
          let rawTitle = html.match(/<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']/i)?.[1] || html.match(/<meta[^>]+name=["']twitter:title["'][^>]+content=["']([^"']+)["']/i)?.[1] || html.match(/<title>([^<]+)<\/title>/i)?.[1] || "Dribbble Shot";
          let title = rawTitle.replace(/&amp;/g, "&").replace(/&#39;/g, "'").replace(/&quot;/g, '"').replace(/\s*\|\s*Dribbble/i, "").trim();
          let uploader = "Dribbble Designer";
          const authorMatch = html.match(/by\s+([^<]+?)\s+on Dribbble/i) || html.match(/<meta[^>]+property=["']og:site_name["'][^>]+content=["']([^"']+)["']/i);
          if (authorMatch && authorMatch[1] && !authorMatch[1].toLowerCase().includes("dribbble")) {
            uploader = authorMatch[1].trim();
          }
          let thumbnail = html.match(/<meta[^>]+property=["']og:image(?::secure_url)?["'][^>]+content=["']([^"']+)["']/i)?.[1] || html.match(/<meta[^>]+name=["']twitter:image["'][^>]+content=["']([^"']+)["']/i)?.[1] || "";
          thumbnail = thumbnail.replace(/&amp;/g, "&");
          if (thumbnail && thumbnail.includes("twimg.com")) {
            thumbnail = thumbnail.replace(/name=[a-z0-9]+/i, "name=orig").replace(/format=webp/i, "format=jpg");
          }
          let videoUrl = "";
          const vMatch = html.match(/https:\/\/cdn\.dribbble\.com\/userupload\/[^"'\s<>]+\.mp4[^"'\s<>]*/gi) || html.match(/https?:\/\/[^"'\s<>]+\.(?:mp4|webm)[^"'\s<>]*/gi) || [];
          const validVids = vMatch.filter((v) => !v.includes("blank") && !v.includes("pixel"));
          if (validVids.length > 0) {
            videoUrl = validVids.find((v) => v.includes("large-") || v.includes("original-")) || validVids[0];
          }
          const isVideo = !!videoUrl;
          const isImg = !isVideo && !!thumbnail;
          const downloadTarget = isVideo ? videoUrl : thumbnail || url;
          return {
            id: `dribbble_${Date.now()}`,
            url,
            title,
            uploader,
            thumbnail: thumbnail || videoUrl,
            duration: isVideo ? 30 : 0,
            formats: isVideo ? [
              {
                formatId: "dribbble_video_1080p",
                ext: "mp4",
                resolution: "1080p",
                height: 1080,
                qualityLabel: "1080p Full HD",
                url: downloadTarget,
                hasAudioAndVideo: true,
                isVideo: true
              },
              {
                formatId: "dribbble_video_720p",
                ext: "mp4",
                resolution: "720p",
                height: 720,
                qualityLabel: "720p HD",
                url: downloadTarget,
                hasAudioAndVideo: true,
                isVideo: true
              },
              {
                formatId: "dribbble_audio_master",
                ext: "mp3",
                resolution: "audio only",
                qualityLabel: "Audio (MP3 320kbps)",
                url: downloadTarget,
                isAudioOnly: true
              }
            ] : [
              {
                formatId: "dribbble_image_high",
                ext: "jpg",
                resolution: "Original Photo",
                qualityLabel: "Original Photo (JPG)",
                url: downloadTarget,
                isImage: true
              }
            ],
            availableResolutions: isVideo ? [1080, 720] : [],
            hasAudio: isVideo,
            hasVideo: isVideo,
            hasImage: isImg,
            downloadTarget,
            directStreamUrl: isVideo ? videoUrl : isImg ? thumbnail : "",
            platform: "dribbble",
            mediaType: isVideo ? "video" : isImg ? "image" : "video",
            defaultProfile: {
              type: isVideo ? "video" : isImg ? "image" : "video",
              presetId: isVideo ? "best-available" : "original-image",
              label: isVideo ? "Best Available Quality (Universal H.264)" : "Original Photo (JPG)",
              container: isVideo ? "mp4" : "jpg",
              remuxToMp4: isVideo
            }
          };
        } catch (err) {
          logger.warn("Dribbble extraction failed, trying universal web fallback:", err);
          return await this.analyzeUniversalWebMedia(url, timeoutMs);
        }
      }
      async analyzeUniversalWebMedia(url, timeoutMs = 35e3) {
        logger.info(`Analyzing Universal Web Media URL: ${url}`);
        try {
          const res = await fetchSmartHtml(url);
          const html = res.body || "";
          let rawTitle = html.match(/<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']/i)?.[1] || html.match(/<meta[^>]+name=["']twitter:title["'][^>]+content=["']([^"']+)["']/i)?.[1] || html.match(/<title>([^<]+)<\/title>/i)?.[1] || "";
          let title = rawTitle.replace(/&amp;/g, "&").replace(/&#39;/g, "'").replace(/&quot;/g, '"').replace(/[\r\n\t]+/g, " ").trim();
          if (!title || title.toLowerCase() === "not found" || title.toLowerCase() === "just a moment...") {
            try {
              const u = new URL(url);
              const slug = u.pathname.split("/").filter(Boolean).pop() || u.hostname;
              title = slug.replace(/[-_]/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
            } catch (_) {
              title = "Web Media";
            }
          }
          let uploader = html.match(/<meta[^>]+property=["']og:site_name["'][^>]+content=["']([^"']+)["']/i)?.[1] || html.match(/<meta[^>]+name=["']author["'][^>]+content=["']([^"']+)["']/i)?.[1] || "";
          if (!uploader) {
            try {
              uploader = new URL(url).hostname.replace(/^www\./, "");
            } catch (_) {
              uploader = "Web Creator";
            }
          }
          uploader = uploader.replace(/&amp;/g, "&").trim();
          let thumbnail = html.match(/<meta[^>]+property=["']og:image(?::secure_url)?["'][^>]+content=["']([^"']+)["']/i)?.[1] || html.match(/<meta[^>]+name=["']twitter:image["'][^>]+content=["']([^"']+)["']/i)?.[1] || html.match(/<link[^>]+rel=["']image_src["'][^>]+href=["']([^"']+)["']/i)?.[1] || "";
          thumbnail = thumbnail.replace(/&amp;/g, "&");
          if (thumbnail && !thumbnail.startsWith("http")) {
            try {
              thumbnail = new URL(thumbnail, url).href;
            } catch (_) {
            }
          }
          let videoUrl = html.match(/<meta[^>]+property=["']og:video(?::secure_url|:url)?["'][^>]+content=["']([^"']+)["']/i)?.[1] || html.match(/<meta[^>]+name=["']twitter:player:stream["'][^>]+content=["']([^"']+)["']/i)?.[1] || "";
          videoUrl = videoUrl.replace(/&amp;/g, "&");
          if (!videoUrl) {
            const srcMatch = html.match(/<video[^>]*src=["']([^"']+)["']/i) || html.match(/<source[^>]*src=["']([^"']+\.mp4[^"']*)["']/i) || html.match(/<source[^>]*src=["']([^"']+\.webm[^"']*)["']/i);
            if (srcMatch && srcMatch[1]) videoUrl = srcMatch[1];
          }
          let embedUrl = "";
          let downloadTarget = videoUrl;
          const vimeoMatch = html.match(/(?:player\.vimeo\.com\/video\/|vimeo\.com\/)(\d+)/i);
          if (vimeoMatch && vimeoMatch[1]) {
            embedUrl = `https://player.vimeo.com/video/${vimeoMatch[1]}`;
            if (!videoUrl) {
              videoUrl = `https://vimeo.com/${vimeoMatch[1]}`;
              downloadTarget = videoUrl;
            }
          }
          const ytMatch = html.match(/(?:youtube\.com\/(?:embed\/|watch\?v=)|youtu\.be\/)([a-zA-Z0-9_-]{11})/i);
          if (ytMatch && ytMatch[1] && !videoUrl) {
            embedUrl = `https://www.youtube.com/embed/${ytMatch[1]}`;
            videoUrl = `https://www.youtube.com/watch?v=${ytMatch[1]}`;
            downloadTarget = videoUrl;
          }
          if (!videoUrl) {
            const cdnVids = html.match(/https?:\/\/[a-zA-Z0-9.\-_/]+\.(?:mp4|webm|mov|m4v)(?:\?[^"'\s<>]*)?/gi) || [];
            const valid = cdnVids.filter((v) => !v.includes("blank") && !v.includes("pixel") && !v.includes("tracking") && !v.includes("ad_") && !v.includes("analytics"));
            const uniqueVids = [...new Set(valid)];
            if (uniqueVids.length > 1) {
              logger.info(`[UniversalWebMedia] Detected multi-video gallery (${uniqueVids.length} videos) on ${url}`);
              return {
                id: `portfolio_${Date.now()}`,
                url,
                title: title || "Portfolio Media Gallery",
                uploader: uploader || "Portfolio Creator",
                thumbnail: thumbnail || uniqueVids[0],
                itemCount: uniqueVids.length,
                isPlaylist: true,
                items: uniqueVids.map((vUrl, idx) => ({
                  id: `portfolio_vid_${idx + 1}`,
                  url: vUrl,
                  downloadTarget: vUrl,
                  directStreamUrl: vUrl,
                  title: `${title} - Video ${idx + 1}`,
                  duration: 60,
                  thumbnail: thumbnail || "",
                  channel: uploader,
                  uploader,
                  index: idx + 1,
                  height: 1080,
                  resolution: "1080p",
                  isVideo: true,
                  hasVideo: true,
                  hasAudio: true,
                  mediaType: "video",
                  ext: "mp4",
                  formatId: "universal_video_1080p",
                  defaultProfile: {
                    type: "video",
                    presetId: "best-available",
                    label: "Best Available Quality (1080p MP4)",
                    container: "mp4",
                    remuxToMp4: true
                  }
                }))
              };
            }
            if (uniqueVids.length === 1) {
              videoUrl = uniqueVids[0];
              downloadTarget = videoUrl;
            }
          }
          if (videoUrl) {
            videoUrl = videoUrl.replace(/&amp;/g, "&");
            if (videoUrl.includes("cloudinary.com") && !/\.(mp4|webm|m3u8|mov)($|\?)/i.test(videoUrl)) {
              videoUrl += ".mp4";
              downloadTarget = videoUrl;
            }
          }
          let audioUrl = "";
          if (!videoUrl) {
            const audMatch = html.match(/<meta[^>]+property=["']og:audio(?::secure_url)?["'][^>]+content=["']([^"']+)["']/i)?.[1] || html.match(/<audio[^>]*src=["']([^"']+)["']/i) || html.match(/<source[^>]*src=["']([^"']+\.(?:mp3|wav|m4a|aac|flac|ogg)[^"']*)["']/i);
            if (audMatch && audMatch[1]) audioUrl = audMatch[1].replace(/&amp;/g, "&");
            if (!audioUrl) {
              const cdnAuds = html.match(/https?:\/\/[a-zA-Z0-9.\-_/]+\.(?:mp3|wav|m4a|aac|flac|ogg)(?:\?[^"'\s<>]*)?/gi) || [];
              if (cdnAuds.length > 0) audioUrl = cdnAuds[0];
            }
          }
          const isVideo = !!videoUrl;
          const isAudio = !isVideo && !!audioUrl;
          const isImg = !isVideo && !isAudio && !!thumbnail;
          if (!isVideo && !isAudio && !isImg) {
            throw new Error("No media elements (video, audio, or high-res image) detected on this webpage.");
          }
          const mediaType = isVideo ? "video" : isAudio ? "audio" : "image";
          const finalTarget = isVideo ? downloadTarget : isAudio ? audioUrl : thumbnail;
          const ext = isVideo ? "mp4" : isAudio ? "mp3" : "jpg";
          let domain = "";
          try {
            domain = new URL(url).hostname.replace(/^www\./, "");
          } catch (_) {
          }
          return {
            id: `web_${Date.now()}`,
            url,
            title,
            uploader,
            thumbnail: thumbnail || (isVideo ? videoUrl : ""),
            duration: isVideo ? 60 : 0,
            formats: isVideo ? [
              {
                formatId: "universal_video_1080p",
                ext: "mp4",
                resolution: "1080p",
                height: 1080,
                qualityLabel: "1080p Full HD",
                url: finalTarget,
                hasAudioAndVideo: true,
                isVideo: true
              },
              {
                formatId: "universal_video_720p",
                ext: "mp4",
                resolution: "720p",
                height: 720,
                qualityLabel: "720p HD",
                url: finalTarget,
                hasAudioAndVideo: true,
                isVideo: true
              },
              {
                formatId: "universal_audio_master",
                ext: "mp3",
                resolution: "audio only",
                qualityLabel: "Audio (MP3 320kbps)",
                url: finalTarget,
                isAudioOnly: true
              }
            ] : isAudio ? [
              {
                formatId: "universal_audio_best",
                ext: "mp3",
                resolution: "audio only",
                qualityLabel: "Audio (MP3 320kbps)",
                url: finalTarget,
                isAudioOnly: true
              }
            ] : [
              {
                formatId: "universal_image_best",
                ext: "jpg",
                resolution: "Original Photo",
                qualityLabel: "Original Photo (JPG)",
                url: finalTarget,
                isImage: true
              }
            ],
            availableResolutions: isVideo ? [1080, 720] : [],
            hasAudio: isVideo || isAudio,
            hasVideo: isVideo,
            hasImage: isImg,
            isImage: isImg,
            type: mediaType,
            downloadTarget: finalTarget,
            directStreamUrl: isVideo && !embedUrl ? videoUrl : isAudio ? audioUrl : isImg ? thumbnail : "",
            embedUrl,
            platform: domain || "web",
            mediaType,
            defaultProfile: {
              type: isVideo ? "video" : isAudio ? "audio" : "image",
              presetId: isVideo ? "best-available" : isAudio ? "best-audio" : "original-image",
              label: isVideo ? "Best Available Quality (Universal H.264)" : isAudio ? "Best Audio Quality (MP3 320kbps)" : "Original Photo (JPG)",
              container: ext,
              remuxToMp4: isVideo
            }
          };
        } catch (err) {
          logger.error("Universal web media extraction failed:", err);
          throw classifyError(err, "Failed to extract media from this webpage");
        }
      }
      async analyzeFiverr(url, timeoutMs = 35e3) {
        logger.info(`Analyzing Fiverr URL: ${url}`);
        try {
          let html = "";
          try {
            const res = await fetchHtml(url, {
              "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
              "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
              "Accept-Language": "en-US,en;q=0.9"
            });
            html = res.body || "";
          } catch (fErr) {
            logger.warn("Direct Fiverr HTML fetch error, trying headless fallback:", fErr.message);
            html = await dumpHeadlessDom(url, timeoutMs) || "";
          }
          if (!html) {
            throw new Error("Could not retrieve Fiverr gig content");
          }
          let title = "";
          let uploader = "Fiverr Seller";
          let videoUrl = "";
          let thumbnail = "";
          const pMatch = html.match(/<script[^>]*perseus-initial-props[^>]*>([\s\S]*?)<\/script>/i);
          if (pMatch) {
            try {
              const data = JSON.parse(pMatch[1].trim());
              if (data.general?.gigTitle) {
                title = data.general.gigTitle.startsWith("I will") ? data.general.gigTitle : `I will ${data.general.gigTitle}`;
              } else if (data.openGraph?.title) {
                title = data.openGraph.title;
              }
              const s = data.seller?.user;
              if (s) {
                uploader = s.name || s.profile?.displayName || s.fullName || uploader;
              }
              if (data.openGraph?.video) {
                videoUrl = data.openGraph.video;
              } else if (data.seller?.introVideo?.videoSrc) {
                videoUrl = data.seller.introVideo.videoSrc;
              }
              if (data.openGraph?.image) {
                thumbnail = data.openGraph.image;
              }
              if (!videoUrl && Array.isArray(data.gallery?.portfolio)) {
                const vidSlide = data.gallery.portfolio.find((p) => p.slide?.typeVideo && (p.slide?.videoSrc || p.slide?.src));
                if (vidSlide) {
                  videoUrl = vidSlide.slide.videoSrc || vidSlide.slide.src;
                  if (!thumbnail && vidSlide.slide.thumbnail) thumbnail = vidSlide.slide.thumbnail;
                }
              }
            } catch (pErr) {
              logger.warn("Perseus parse notice:", pErr.message);
            }
          }
          const cleanHtml = html.replace(/&amp;/g, "&");
          if (!title) {
            const ogTitle = cleanHtml.match(/<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']/i)?.[1] || cleanHtml.match(/<title>([^<]+)<\/title>/i)?.[1] || "Fiverr Gig Portfolio";
            title = ogTitle.replace(/\s*\|\s*Fiverr/i, "").replace(/&#x27;/g, "'").trim();
          }
          if (!uploader || uploader === "Fiverr Seller") {
            const authorMatch = cleanHtml.match(/by\s+([a-zA-Z0-9_\-]+)\s+on Fiverr/i) || cleanHtml.match(/class=["'][^"']*seller-name[^"']*["'][^>]*>([^<]+)</i);
            if (authorMatch && authorMatch[1]) {
              uploader = authorMatch[1].trim();
            } else {
              const uMatch = url.match(/fiverr\.com\/([a-zA-Z0-9_\-]+)\//);
              if (uMatch && uMatch[1] && !["s", "categories", "gigs"].includes(uMatch[1])) {
                uploader = uMatch[1];
              }
            }
          }
          if (!thumbnail) {
            thumbnail = cleanHtml.match(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i)?.[1] || cleanHtml.match(/https:\/\/(?:res\.cloudinary\.com\/fiverr-prod|fiverr-res\.cloudinary\.com)\/images\/[^"'\s<>]+/i)?.[0] || "";
          }
          if (!videoUrl) {
            videoUrl = cleanHtml.match(/<meta[^>]+property=["']og:video(?::secure_url)?["'][^>]+content=["']([^"']+)["']/i)?.[1] || cleanHtml.match(/<video[^>]+src=["']([^"']+)["']/i)?.[1] || cleanHtml.match(/https:\/\/(?:res\.cloudinary\.com\/fiverr-prod|fiverr-res\.cloudinary\.com)\/video\/upload\/[^"'\s<>]+/i)?.[0] || "";
          }
          if (videoUrl) {
            videoUrl = videoUrl.replace(/&amp;/g, "&");
            if (videoUrl.includes("cloudinary.com") && !/\.(mp4|webm|m3u8|mov)($|\?)/i.test(videoUrl)) {
              videoUrl += ".mp4";
            }
          }
          const isVideo = Boolean(videoUrl);
          const directTarget = isVideo ? videoUrl : thumbnail || url;
          return {
            id: `fiverr_${Date.now()}`,
            url,
            title,
            uploader,
            thumbnail,
            duration: isVideo ? 60 : 0,
            formats: isVideo ? [
              {
                formatId: "fiverr_video_1080p",
                ext: "mp4",
                resolution: "1080p",
                height: 1080,
                qualityLabel: "1080p Full HD",
                url: directTarget,
                hasAudioAndVideo: true,
                isVideo: true
              },
              {
                formatId: "fiverr_video_720p",
                ext: "mp4",
                resolution: "720p",
                height: 720,
                qualityLabel: "720p HD",
                url: directTarget,
                hasAudioAndVideo: true,
                isVideo: true
              },
              {
                formatId: "fiverr_audio_master",
                ext: "mp3",
                resolution: "audio only",
                qualityLabel: "Audio (MP3 320kbps)",
                url: directTarget,
                isAudioOnly: true
              }
            ] : [
              {
                formatId: "fiverr_image_best",
                ext: "jpg",
                resolution: "Original Photo",
                qualityLabel: "Original Photo (JPG)",
                url: directTarget,
                isImage: true
              }
            ],
            availableResolutions: isVideo ? [1080, 720] : [],
            hasAudio: isVideo,
            hasVideo: isVideo,
            hasImage: !isVideo,
            downloadTarget: directTarget,
            directStreamUrl: isVideo ? directTarget : "",
            embedUrl: "",
            platform: "fiverr",
            mediaType: isVideo ? "video" : "image",
            defaultProfile: {
              type: isVideo ? "video" : "image",
              presetId: isVideo ? "best-available" : "original-image",
              label: isVideo ? "Best Available Quality (Universal H.264)" : "Original Photo (JPG)",
              container: isVideo ? "mp4" : "jpg",
              remuxToMp4: isVideo
            }
          };
        } catch (err) {
          logger.warn("Fiverr direct parse failed, trying universal web fallback:", err);
          return await this.analyzeUniversalWebMedia(url, timeoutMs);
        }
      }
      async analyzeArtStation(url, timeoutMs = 35e3) {
        logger.info(`Analyzing ArtStation URL: ${url}`);
        try {
          const pMatch = url.match(/(?:artwork|projects)\/([a-zA-Z0-9]+)/);
          const projId = pMatch ? pMatch[1] : null;
          let title = "ArtStation Artwork";
          let uploader = "ArtStation Artist";
          let thumbnail = "";
          let directTarget = "";
          let isVideo = false;
          if (projId) {
            try {
              const jsonRes = await fetchHtml(`https://www.artstation.com/projects/${projId}.json`, {
                "User-Agent": "Mozilla/5.0 (compatible; Discordbot/2.0; +https://discordapp.com)"
              });
              if (jsonRes.statusCode === 200 && jsonRes.body) {
                const data = JSON.parse(jsonRes.body);
                title = data.title || title;
                uploader = data.user?.username || data.user?.full_name || uploader;
                thumbnail = data.cover_url || "";
                if (data.assets && data.assets.length > 0) {
                  const videoAsset = data.assets.find((a) => a.has_embedded_player || a.video_clip || a.asset_type === "video");
                  if (videoAsset) {
                    isVideo = true;
                    if (videoAsset.player_embedded) {
                      const srcM = videoAsset.player_embedded.match(/src=["']([^"']+)["']/i);
                      if (srcM) directTarget = srcM[1];
                    }
                    if (!directTarget && videoAsset.video_clip) {
                      directTarget = videoAsset.video_clip;
                    }
                    if (!directTarget && videoAsset.image_url) {
                      directTarget = videoAsset.image_url;
                    }
                  } else {
                    directTarget = data.assets[0].image_url || thumbnail;
                  }
                }
              }
            } catch (_) {
            }
          }
          if (!directTarget) {
            const html = await dumpHeadlessDom(url, timeoutMs) || "";
            if (html) {
              const cleanHtml = html.replace(/&amp;/g, "&");
              title = cleanHtml.match(/<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']/i)?.[1] || cleanHtml.match(/<title>([^<]+)<\/title>/i)?.[1] || title;
              uploader = cleanHtml.match(/<meta[^>]+name=["']author["'][^>]+content=["']([^"']+)["']/i)?.[1] || uploader;
              thumbnail = cleanHtml.match(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i)?.[1] || thumbnail;
              const videoUrl = cleanHtml.match(/<video[^>]+src=["']([^"']+)["']/i)?.[1] || "";
              if (videoUrl) {
                isVideo = true;
                directTarget = videoUrl;
              } else {
                directTarget = thumbnail || url;
              }
            }
          }
          return {
            id: `artstation_${projId || Date.now()}`,
            url,
            title: title.replace(/\s*\|\s*ArtStation/i, "").trim(),
            uploader,
            thumbnail,
            duration: 0,
            formats: [
              {
                formatId: isVideo ? "artstation_video" : "artstation_image",
                ext: isVideo ? "mp4" : "jpg",
                resolution: isVideo ? "1080p" : "Original",
                url: directTarget,
                isImage: !isVideo
              }
            ],
            downloadTarget: directTarget,
            directStreamUrl: isVideo ? directTarget : "",
            embedUrl: directTarget && (directTarget.includes("vimeo.com") || directTarget.includes("youtube.com")) ? directTarget : "",
            platform: "artstation",
            mediaType: isVideo ? "video" : "image"
          };
        } catch (err) {
          logger.warn("ArtStation extraction failed, trying universal web fallback:", err);
          return await this.analyzeUniversalWebMedia(url, timeoutMs);
        }
      }
      async analyzePinterest(url, timeoutMs = 35e3) {
        logger.info(`Analyzing Pinterest URL: ${url}`);
        const targetUrl = await this.expandPinterestUrl(url);
        let title = "";
        let author = "Pinterest Creator";
        let thumbnail = "https://images.unsplash.com/photo-1579783902614-a3fb3927b675?w=800";
        let directImageUrl = "";
        let directVideoUrl = "";
        let durationSec = 0;
        let pinId = "";
        let carouselItems = [];
        let carouselSlides = [];
        let apiData = null;
        const pinMat = targetUrl.match(/pin\/(?:[\w-]+--)?(\d+)/i) || targetUrl.match(/pins\/(\d+)/i);
        if (pinMat) {
          pinId = pinMat[1];
        } else {
          const numMat = targetUrl.match(/(\d{10,22})/);
          if (numMat) pinId = numMat[1];
        }
        if (pinId) {
          try {
            const opts = { field_set_key: "unauth_react_main_pin", id: pinId };
            const q = encodeURIComponent(JSON.stringify({ options: opts }));
            const apiUrl = `https://www.pinterest.com/resource/PinResource/get/?data=${q}`;
            const { body: apiBody, statusCode } = await fetchHtml(apiUrl, {
              "X-Pinterest-PWS-Handler": "www/[username].js",
              "Accept": "application/json, text/javascript, */*, q=0.01",
              "X-Requested-With": "XMLHttpRequest",
              "Referer": "https://www.pinterest.com/"
            });
            if (statusCode === 200 && apiBody) {
              const json = JSON.parse(apiBody);
              const data = json.resource_response?.data;
              if (data) {
                apiData = data;
                const parsedTitle = data.title || data.grid_title || data.closeup_unified_description || "";
                if (parsedTitle && parsedTitle.trim()) {
                  title = parsedTitle.trim();
                }
                const pinner = data.pinner;
                if (pinner) {
                  const pinnerName = pinner.full_name || pinner.username || "";
                  if (pinnerName) author = pinnerName;
                }
                const images = data.images;
                const origImg = images?.orig?.url || images?.["736x"]?.url || "";
                if (origImg) {
                  directImageUrl = origImg.includes("/736x/") && images?.orig?.url ? images.orig.url : images?.orig?.url || origImg.replace(/\/(?:236x|474x|564x|736x)\//, "/originals/");
                  thumbnail = origImg;
                }
                if (data.carousel_data?.carousel_slots && Array.isArray(data.carousel_data.carousel_slots) && data.carousel_data.carousel_slots.length > 0) {
                  const slots = [];
                  data.carousel_data.carousel_slots.forEach((slot, idx) => {
                    let slotVideoUrl = "";
                    let slotDuration = 0;
                    let slotThumb = "";
                    let slotImageUrl = "";
                    if (slot.videos?.video_list) {
                      const vList = slot.videos.video_list;
                      const preferredKeys = ["V_720P", "V_EXP7", "V_480P"];
                      for (const pk of preferredKeys) {
                        const vObj = vList[pk];
                        if (vObj?.url && vObj.url.includes(".mp4")) {
                          slotVideoUrl = vObj.url;
                          if (vObj.duration) slotDuration = Math.round(vObj.duration / 1e3);
                          if (vObj.thumbnail) slotThumb = vObj.thumbnail;
                          break;
                        }
                      }
                      if (!slotVideoUrl) {
                        for (const vk of Object.keys(vList)) {
                          const vObj = vList[vk];
                          if (vObj?.url && vObj.url.includes(".mp4")) {
                            slotVideoUrl = vObj.url;
                            if (vObj.duration) slotDuration = Math.round(vObj.duration / 1e3);
                            if (vObj.thumbnail) slotThumb = vObj.thumbnail;
                            break;
                          }
                        }
                      }
                    }
                    if (slot.images) {
                      const sImg = slot.images.orig?.url || slot.images["736x"]?.url || slot.images["564x"]?.url || "";
                      if (sImg) {
                        slotImageUrl = slot.images.orig?.url || sImg.replace(/\/(?:236x|474x|564x|736x)\//, "/originals/");
                        if (!slotThumb) slotThumb = sImg;
                      }
                    }
                    const isSlotVid = Boolean(slotVideoUrl);
                    const slotMediaUrl = slotVideoUrl || slotImageUrl;
                    if (slotMediaUrl) {
                      slots.push({
                        slideIndex: idx + 1,
                        index: idx + 1,
                        id: slot.id || `${pinId}_slot_${idx + 1}`,
                        title: slot.title || `${title || "Pin Media"} (Part ${idx + 1})`,
                        mediaType: isSlotVid ? "video" : "image",
                        type: isSlotVid ? "video" : "image",
                        url: slotMediaUrl,
                        downloadTarget: slotMediaUrl,
                        directStreamUrl: slotMediaUrl,
                        thumbnail: slotThumb || thumbnail || slotMediaUrl,
                        duration: slotDuration,
                        isSlotVid,
                        slotVideoUrl,
                        slotImageUrl
                      });
                    }
                  });
                  if (slots.length > 0) {
                    const firstVideoSlot = slots.find((s) => s.isSlotVid);
                    if (firstVideoSlot) {
                      directVideoUrl = firstVideoSlot.slotVideoUrl;
                      durationSec = firstVideoSlot.duration;
                      if (firstVideoSlot.thumbnail) thumbnail = firstVideoSlot.thumbnail;
                    }
                    if (slots[0] && !directImageUrl) {
                      directImageUrl = slots[0].slotImageUrl || slots[0].url;
                    }
                    if (slots.length > 1) {
                      carouselItems = slots.map((s) => ({
                        id: s.id,
                        title: s.title,
                        thumbnail: s.thumbnail,
                        duration: s.duration,
                        url: s.url,
                        downloadTarget: s.url,
                        downloadQuery: s.url,
                        directStreamUrl: s.url,
                        uploader: author,
                        mediaType: s.mediaType,
                        type: s.type,
                        formats: s.isSlotVid ? [
                          { formatId: "pinterest_video_720p", label: "720p HD Video (MP4)", ext: "mp4", resolution: "720p", quality: "720", url: s.slotVideoUrl, isVideo: true, hasAudioAndVideo: true, type: "video" }
                        ] : [
                          { formatId: "pinterest_original", label: "Original Master Photo", ext: "jpg", url: s.slotImageUrl, isImage: true, type: "image" }
                        ],
                        subFolderName: ""
                      }));
                      carouselSlides = slots.map((s) => ({
                        slideIndex: s.slideIndex,
                        index: s.slideIndex,
                        id: s.id,
                        mediaType: s.mediaType,
                        label: `Slide ${s.slideIndex} \u2022 ${s.mediaType === "video" ? "Video" : "Photo"}`,
                        url: s.url,
                        thumbnail: s.thumbnail,
                        duration: s.duration
                      }));
                    }
                  }
                }
                if (!directVideoUrl) {
                  let vidList = data.videos?.video_list;
                  if (!vidList && data.story_pin_data?.pages) {
                    for (const page of data.story_pin_data.pages) {
                      if (page.blocks) {
                        for (const blk of page.blocks) {
                          if (blk.video?.video_list) {
                            vidList = blk.video.video_list;
                            break;
                          }
                        }
                      }
                      if (vidList) break;
                    }
                  }
                  if (vidList) {
                    const preferredKeys = ["V_EXP7", "V_720P", "V_480P"];
                    for (const pk of preferredKeys) {
                      const vObj = vidList[pk];
                      if (vObj?.url && vObj.url.includes(".mp4")) {
                        directVideoUrl = vObj.url;
                        if (vObj.duration) durationSec = Math.round(vObj.duration / 1e3);
                        if (vObj.thumbnail) thumbnail = vObj.thumbnail;
                        break;
                      }
                    }
                    if (!directVideoUrl) {
                      for (const vk of Object.keys(vidList)) {
                        const vObj = vidList[vk];
                        if (vObj?.url && vObj.url.includes(".mp4")) {
                          directVideoUrl = vObj.url;
                          if (vObj.duration) durationSec = Math.round(vObj.duration / 1e3);
                          if (vObj.thumbnail) thumbnail = vObj.thumbnail;
                          break;
                        }
                      }
                    }
                  }
                }
              }
            }
          } catch (apiErr) {
            logger.warn("[Analyzer] Pinterest PinResource query notice:", apiErr.message);
          }
        }
        if (!directVideoUrl && !directImageUrl) {
          try {
            const { body: html } = await fetchHtml(targetUrl, {
              "Referer": "https://www.google.com/"
            });
            const cleanHtml = html.replace(/\\\//g, "/").replace(/\\u002F/gi, "/").replace(/&amp;/g, "&");
            if (!title) {
              const ogTitleM = cleanHtml.match(/<meta\s+property=["']og:title["']\s+content=["'](.*?)["']/i) || cleanHtml.match(/<meta\s+content=["'](.*?)["']\s+property=["']og:title["']/i);
              if (ogTitleM && ogTitleM[1]) {
                title = ogTitleM[1].replace(/ \| Pinterest$/i, "").trim();
              } else {
                const pageTitleM = cleanHtml.match(/<title[^>]*>(.*?)<\/title>/i);
                if (pageTitleM && pageTitleM[1]) {
                  title = pageTitleM[1].replace(/ \| Pinterest$/i, "").trim();
                }
              }
            }
            const vidPattern = /https?:\/\/[a-zA-Z0-9.-]*pinimg\.com\/videos\/[a-zA-Z0-9/_.-]+\.mp4/i;
            const vidM = cleanHtml.match(vidPattern);
            if (vidM) {
              directVideoUrl = vidM[0];
            } else {
              const ogvM = cleanHtml.match(/<meta\s+property=["']og:video(?::secure_url)?["']\s+content=["'](.*?)["']/i);
              if (ogvM && ogvM[1]) directVideoUrl = ogvM[1];
            }
            const imgPattern = /https:\/\/i\.pinimg\.com\/(?:originals|736x)\/[a-zA-Z0-9/_.-]+\.(?:jpg|png|webp|gif)/i;
            const imgM = cleanHtml.match(imgPattern);
            if (imgM) {
              directImageUrl = imgM[0].replace(/\/736x\//, "/originals/");
              if (!thumbnail || thumbnail.includes("unsplash")) thumbnail = directImageUrl;
            } else {
              const ogImgM = cleanHtml.match(/<meta\s+property=["']og:image["']\s+content=["'](.*?)["']/i);
              if (ogImgM && ogImgM[1]) {
                directImageUrl = ogImgM[1].replace(/\/736x\//, "/originals/");
                if (!thumbnail || thumbnail.includes("unsplash")) thumbnail = directImageUrl;
              }
            }
          } catch (htmlErr) {
            logger.warn("[Analyzer] Pinterest HTML fallback notice:", htmlErr.message);
          }
        }
        if (!title) {
          title = pinId ? `Pinterest Pin ${pinId}` : "Pinterest Visual Media";
        }
        const isVideo = Boolean(directVideoUrl);
        const isGif = !isVideo && Boolean(apiData?.is_animated || apiData?.gif || /\.gif($|\?)/i.test(directImageUrl));
        const mediaStream = directVideoUrl || directImageUrl;
        const isCarousel = Array.isArray(carouselSlides) && carouselSlides.length > 1;
        const meta = {
          id: pinId || "pinterest_pin",
          url: targetUrl,
          title,
          uploader: author,
          channel: author,
          thumbnail: thumbnail || directImageUrl,
          duration: durationSec,
          extractor: "pinterest",
          platform: "pinterest",
          directStreamUrl: mediaStream,
          downloadTarget: mediaStream,
          mediaType: isVideo ? "video" : "image",
          type: isVideo ? "video" : "image",
          hasVideo: isVideo,
          hasAudio: isVideo,
          hasImage: !isVideo,
          isImage: !isVideo,
          isGif,
          formats: isVideo ? [
            { formatId: "best-video", label: "720p HD Video (MP4)", ext: "mp4", resolution: "720p", quality: "720", url: directVideoUrl, isVideo: true, hasAudioAndVideo: true, type: "video" },
            { formatId: "best-audio", label: "Audio Only (MP3)", ext: "mp3", url: directVideoUrl, isAudioOnly: true, type: "audio" }
          ] : [
            { formatId: "original-image", label: isGif ? "Original Animated GIF" : "Original Master Resolution Photo", ext: isGif ? "gif" : /\.png($|\?)/i.test(directImageUrl) ? "png" : "jpg", url: directImageUrl, isImage: true, type: "image" }
          ],
          defaultProfile: isVideo ? {
            type: "video",
            presetId: "best-video",
            label: "720p HD Video (MP4)",
            container: "mp4",
            remuxToMp4: true
          } : {
            type: "image",
            presetId: "original-image",
            label: isGif ? "Original Animated GIF" : "Original Master Photo",
            container: isGif ? "gif" : "jpg"
          }
        };
        if (isCarousel) {
          meta.isPlaylist = true;
          meta.isCarousel = true;
          meta.itemCount = carouselItems.length;
          meta.items = carouselItems;
          meta.carouselSlides = carouselSlides;
        }
        return meta;
      }
      isCloudStorageUrl(urlStr) {
        if (!this.isValidUrl(urlStr)) return false;
        const lower = urlStr.toLowerCase();
        if (lower.includes("/folders/") || lower.includes("folderview") || lower.includes("/scl/fo/")) return false;
        return lower.includes("drive.google.com") || lower.includes("dropbox.com") || lower.includes("1drv.ms") || lower.includes("onedrive.live.com") || lower.includes("sharepoint.com") || /\.(mp4|mov|mkv|webm|avi|flv|m4v|mp3|wav|m4a|aac|flac|ogg|zip|rar|7z|tar|gz|jpe?g|png|webp|gif|bmp|svg|avif|tiff)(\?.*)?$/i.test(urlStr);
      }
      probeCloudMedia(targetUrl, maxRedirects = 5) {
        return new Promise((resolve) => {
          if (!targetUrl || maxRedirects <= 0) return resolve({});
          const client = targetUrl.startsWith("https:") ? import_https2.default : import_http2.default;
          const req = client.request(targetUrl, {
            method: "GET",
            headers: {
              "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
              "Range": "bytes=0-1024"
            }
          }, (res) => {
            if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
              let loc = res.headers.location;
              if (!loc.startsWith("http")) {
                try {
                  loc = new URL(loc, targetUrl).href;
                } catch (_) {
                }
              }
              res.destroy();
              return resolve(this.probeCloudMedia(loc, maxRedirects - 1));
            }
            const cd = res.headers["content-disposition"] || "";
            const ct = res.headers["content-type"] || "";
            let filename = "";
            const fnMatch = cd.match(/filename\*?=(?:UTF-8'')?["']?([^"';\r\n]+)["']?/i);
            if (fnMatch) {
              try {
                filename = decodeURIComponent(fnMatch[1]);
              } catch (_) {
                filename = fnMatch[1];
              }
            }
            res.destroy();
            resolve({ filename, contentType: ct, finalUrl: targetUrl });
          });
          req.on("error", () => resolve({}));
          req.setTimeout(5e3, () => {
            req.abort();
            resolve({});
          });
          req.end();
        });
      }
      async analyzeCloudStorage(url, timeoutMs = 35e3) {
        if (this.isPlaylistUrl(url)) {
          return await this.analyzePlaylist(url, timeoutMs);
        }
        logger.info(`Analyzing cloud storage / direct media URL: ${url}`);
        let directUrl = url;
        let title = "Cloud Media";
        let isArchive = false;
        let isAudio = false;
        let isImage = false;
        let isVideo = true;
        const lower = url.toLowerCase();
        if (lower.includes("drive.google.com")) {
          const driveMatch = url.match(/\/d\/([a-zA-Z0-9_-]+)/) || url.match(/id=([a-zA-Z0-9_-]+)/);
          if (driveMatch) {
            directUrl = `https://drive.usercontent.google.com/download?id=${driveMatch[1]}&export=download`;
            title = `Google Drive File (${driveMatch[1].substring(0, 8)})`;
            try {
              const html = await fetchHtml(url, {}, 3).catch(() => "");
              const tMatch = html.match(/<title>([^<]+)\s*-\s*Google Drive<\/title>/i);
              if (tMatch && tMatch[1]) {
                title = tMatch[1].trim();
              }
            } catch (_) {
            }
          }
        } else if (lower.includes("dropbox.com")) {
          directUrl = url.replace("dl=0", "dl=1");
          if (!directUrl.includes("dl=1")) {
            directUrl += (directUrl.includes("?") ? "&" : "?") + "dl=1";
          }
          const nameMatch = url.match(/\/([^/?#]+)\?/);
          if (nameMatch) {
            try {
              title = decodeURIComponent(nameMatch[1]);
            } catch (_) {
            }
          }
        } else if (lower.includes("1drv.ms") || lower.includes("onedrive.live.com") || lower.includes("sharepoint.com")) {
          directUrl = url.includes("download=1") ? url : url + (url.includes("?") ? "&" : "?") + "download=1";
          title = "OneDrive File";
        } else {
          try {
            const u = new URL(url);
            const bname = import_path7.default.basename(u.pathname);
            if (bname) title = decodeURIComponent(bname);
          } catch (_) {
          }
        }
        try {
          const probe = await this.probeCloudMedia(directUrl);
          if (probe.filename) title = probe.filename;
          if (probe.finalUrl) directUrl = probe.finalUrl;
          const ct = (probe.contentType || "").toLowerCase();
          if (ct.startsWith("image/")) {
            isImage = true;
            isVideo = false;
            isAudio = false;
          } else if (ct.startsWith("audio/")) {
            isAudio = true;
            isVideo = false;
            isImage = false;
          } else if (ct.startsWith("video/")) {
            isVideo = true;
            isImage = false;
            isAudio = false;
          } else if (ct.includes("zip") || ct.includes("rar") || ct.includes("tar") || ct.includes("7z") || ct.includes("octet-stream")) {
            if (/\.(zip|rar|7z|tar|gz)($|\?)/i.test(title)) {
              isArchive = true;
              isVideo = false;
              isAudio = false;
            }
          }
        } catch (_) {
        }
        const checkTarget = `${title} ${url} ${directUrl}`;
        if (/\.(jpe?g|png|webp|gif|bmp|svg|avif|tiff)($|\?)/i.test(checkTarget)) {
          isImage = true;
          isVideo = false;
          isAudio = false;
        } else if (/\.(mp3|wav|m4a|aac|flac|ogg|opus)($|\?)/i.test(checkTarget)) {
          isAudio = true;
          isVideo = false;
          isImage = false;
        } else if (/\.(mp4|mov|webm|mkv|avi|m4v|wmv|flv)($|\?)/i.test(checkTarget)) {
          isVideo = true;
          isImage = false;
          isAudio = false;
        } else if (/\.(zip|rar|7z|tar|gz)($|\?)/i.test(checkTarget)) {
          isArchive = true;
          isVideo = false;
          isAudio = false;
        }
        return {
          id: "cloud_" + Date.now(),
          url,
          originalUrl: url,
          webpage_url: url,
          directUrl,
          directStreamUrl: directUrl,
          downloadTarget: directUrl,
          title,
          thumbnail: isImage ? directUrl : "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800",
          duration: 0,
          uploader: "Cloud Storage",
          channel: "Cloud Storage",
          extractor: "cloud",
          isCloud: true,
          isArchive,
          isImage,
          mediaType: isImage ? "image" : isAudio ? "audio" : "video",
          hasAudio: isAudio || isVideo,
          hasVideo: isVideo,
          resolution: isImage ? "Original High-Res Image" : "Original Master File",
          availableResolutions: [],
          formats: isArchive ? [
            { format_id: "archive_original", ext: "zip", height: null, vcodec: "none", acodec: "none", url: directUrl }
          ] : isImage ? [
            { format_id: "image_original", ext: title.match(/\.(jpe?g|png|webp|gif|bmp|svg)/i)?.[1]?.toLowerCase() || "png", height: null, vcodec: "none", acodec: "none", url: directUrl }
          ] : isVideo ? [
            { format_id: "cloud_original", ext: "mp4", height: null, vcodec: "h264", acodec: "aac", url: directUrl },
            { format_id: "cloud_audio", ext: "mp3", height: null, vcodec: "none", acodec: "mp3", url: directUrl }
          ] : [
            { format_id: "cloud_audio", ext: "mp3", height: null, vcodec: "none", acodec: "mp3", url: directUrl }
          ],
          defaultProfile: isArchive ? {
            type: "archive",
            presetId: "original-archive",
            label: "Original Archive (.zip)",
            container: "zip"
          } : isImage ? {
            type: "image",
            presetId: "image-orig",
            label: "Original Photo (Master Quality)",
            container: title.match(/\.(jpe?g|png|webp|gif|bmp|svg)/i)?.[1]?.toLowerCase() || "png"
          } : isVideo ? {
            type: "video",
            presetId: "best-available",
            label: "Direct Cloud Video (MP4)",
            container: "mp4",
            remuxToMp4: true
          } : {
            type: "audio",
            presetId: "best-audio",
            label: "Direct Audio Stream (MP3)",
            container: "mp3"
          }
        };
      }
      async analyzeInstagram(url, timeoutMs = 25e3) {
        logger.info(`Analyzing Instagram media with multi-slide/carousel extractor: ${url}`);
        try {
          const pyCode = `
import sys, json, re, yt_dlp
url = sys.argv[1]
ydl = yt_dlp.YoutubeDL({'quiet': True, 'no_warnings': True})
ie = yt_dlp.extractor.instagram.InstagramIE(ydl)
try:
    ie.raise_no_formats = lambda *a, **k: None
except Exception:
    pass
res = ie._real_extract(url)
t = res.get('_type')
raw_desc = res.get('description') or res.get('caption') or ''
clean_title = ''
if raw_desc:
    for line in str(raw_desc).split('\\n'):
        l = line.strip()
        l = re.sub(r'https?://\\S+', '', l).strip()
        l = re.sub(r'#\\w+', '', l).strip()
        if len(l) >= 3:
            clean_title = l[:120]
            break
res_title = res.get('title') or ''
if clean_title:
    title = clean_title
elif res_title and not res_title.lower().startswith(('video by', 'photo by', 'post by', 'clip by')):
    title = res_title
else:
    uploader_clean = (res.get('uploader') or res.get('channel') or '').strip()
    title = f"Instagram Post by {uploader_clean}" if uploader_clean else "Instagram Post"
uploader = res.get('uploader') or res.get('channel') or '@Instagram'
def get_best_playable_video(fmts):
    # 1. First priority: Progressive combined video+audio (contains both streams in single MP4)
    prog = [f for f in fmts if f.get('url') and (
        'progressive' in f.get('url', '') or
        'progressive_recipe' in f.get('url', '') or
        (f.get('vcodec') is None and f.get('acodec') is None and not str(f.get('format_id') or '').startswith('dash')) or
        (f.get('vcodec') and f.get('vcodec') != 'none' and f.get('acodec') and f.get('acodec') != 'none')
    )]
    if prog:
        prog.sort(key=lambda x: (x.get('height') or 0, x.get('tbr') or 0))
        return prog[-1].get('url')
    # 2. Fallback: Any video stream
    vid = [f for f in fmts if f.get('url') and f.get('vcodec') != 'none']
    if vid:
        vid.sort(key=lambda x: (x.get('height') or 0, x.get('tbr') or 0))
        return vid[-1].get('url')
    return None

if t == 'playlist':
    entries = res.get('entries', [])
    slides = []
    for idx, e in enumerate(entries):
        formats = e.get('formats') or []
        vid_url = get_best_playable_video(formats)
        thumbs = e.get('thumbnails') or []
        if thumbs:
            thumbs_sorted = sorted(thumbs, key=lambda t: (t.get('width') or 0) * (t.get('height') or 0))
            img_url = thumbs_sorted[-1].get('url')
        else:
            img_url = e.get('thumbnail') or None
        slide_url = vid_url or img_url
        if slide_url:
            slides.append({
                'index': idx + 1,
                'title': f"{title} (Slide {idx + 1})",
                'url': slide_url,
                'thumbnail': img_url or vid_url,
                'isVideo': bool(vid_url),
                'duration': e.get('duration') or res.get('duration') or 0
            })
    print(json.dumps({'type': 'playlist', 'title': title, 'uploader': uploader, 'itemCount': len(slides), 'items': slides}))
else:
    formats = res.get('formats') or []
    vid_url = get_best_playable_video(formats)
    thumbs = res.get('thumbnails') or []
    if thumbs:
        thumbs_sorted = sorted(thumbs, key=lambda t: (t.get('width') or 0) * (t.get('height') or 0))
        img_url = thumbs_sorted[-1].get('url')
    else:
        img_url = res.get('thumbnail')
    dur = res.get('duration') or 0
    print(json.dumps({'type': 'single', 'title': title, 'uploader': uploader, 'videoUrl': vid_url, 'photoUrl': img_url, 'thumbnail': img_url or vid_url, 'duration': dur}))
`.trim();
          const { stdout } = await execFileAsync2("python", ["-c", pyCode, url], {
            windowsHide: true,
            timeout: timeoutMs,
            maxBuffer: 15 * 1024 * 1024
          });
          const parsed = JSON.parse(stdout.trim());
          if (parsed.type === "playlist" && parsed.items && parsed.items.length > 0) {
            return {
              isPlaylist: true,
              isCarousel: true,
              url,
              title: parsed.title,
              uploader: parsed.uploader,
              itemCount: parsed.items.length,
              referer: "https://www.instagram.com/",
              items: parsed.items.map((s, idx) => ({
                id: `ig_slide_${idx + 1}`,
                url: s.url,
                title: s.title,
                thumbnail: s.thumbnail,
                duration: s.duration || 0,
                downloadQuery: s.url,
                downloadTarget: s.url,
                directStreamUrl: s.url,
                uploader: parsed.uploader,
                mediaType: s.isVideo ? "video" : "image",
                type: s.isVideo ? "video" : "image",
                referer: "https://www.instagram.com/"
              }))
            };
          } else if (parsed.photoUrl || parsed.videoUrl) {
            const isPhoto = !parsed.videoUrl;
            const targetUrl = parsed.videoUrl || parsed.photoUrl;
            let videoDuration = Number(parsed.duration) || 0;
            if (!videoDuration && !isPhoto && targetUrl) {
              videoDuration = await probeMediaDuration(targetUrl);
            }
            return {
              id: "instagram_" + Date.now(),
              url,
              title: parsed.title,
              uploader: parsed.uploader,
              thumbnail: parsed.thumbnail,
              duration: videoDuration || 0,
              formats: [
                {
                  formatId: isPhoto ? "photo_original" : "video_original",
                  ext: isPhoto ? "jpg" : "mp4",
                  resolution: isPhoto ? "Original High-Res Photo" : "1080p Full HD",
                  url: targetUrl,
                  hasAudioAndVideo: !isPhoto,
                  isVideo: !isPhoto,
                  isImage: isPhoto
                }
              ],
              downloadTarget: targetUrl,
              directStreamUrl: targetUrl,
              mediaType: isPhoto ? "image" : "video",
              type: isPhoto ? "image" : "video",
              hasVideo: !isPhoto,
              hasAudio: !isPhoto,
              hasImage: isPhoto,
              isImage: isPhoto,
              referer: "https://www.instagram.com/"
            };
          }
        } catch (e) {
          logger.warn("[Instagram Carousel] Python extractor fallback failed:", e.message);
        }
        try {
          const shortcodeMatch = url.match(/(?:p|reel|tv)\/([a-zA-Z0-9_-]+)/);
          const shortcode = shortcodeMatch ? shortcodeMatch[1] : "";
          if (shortcode) {
            const embedUrl = `https://www.instagram.com/p/${shortcode}/embed/captioned/`;
            const { body } = await fetchHtml(embedUrl);
            const imgMat = body.match(/<img[^>]+class="[^"]*EmbeddedMediaImage[^"]*"[^>]+src="([^"]+)"/);
            const titleMat = body.match(/class="[^"]*Caption[^"]*"[^>]*>(.*?)<\/div>/s);
            const userMat = body.match(/class="[^"]*Username[^"]*"[^>]*>(.*?)<\/div>/s);
            let rawPhoto = imgMat ? imgMat[1].replace(/&amp;/g, "&") : "";
            const displayMatch = body.match(/"display_url"\s*:\s*"([^"]+)"/);
            if (displayMatch && displayMatch[1]) {
              const u = displayMatch[1].replace(/\\u0026/g, "&").replace(/\\/g, "");
              if (u.startsWith("http")) rawPhoto = u;
            }
            if (rawPhoto) {
              rawPhoto = rawPhoto.replace(/\/c\d+\.\d+\.\d+\.\d+a?\//, "/").replace(/\/[sp]\d+x\d+\//, "/");
            }
            const cap = titleMat ? titleMat[1].replace(/<[^>]+>/g, "").trim() : "Instagram Post";
            const user = userMat ? userMat[1].replace(/<[^>]+>/g, "").trim() : "Instagram";
            const vidMat = body.match(/<video[^>]+src="([^"]+)"/i) || body.match(/video_url["']?\s*:\s*["']([^"']+)["']/i);
            const rawVideo = vidMat ? vidMat[1].replace(/&amp;/g, "&") : "";
            if (rawVideo) {
              return {
                id: "instagram_" + shortcode,
                url,
                title: cap,
                uploader: user,
                thumbnail: rawPhoto || "",
                duration: 0,
                formats: [{
                  formatId: "video_embed",
                  ext: "mp4",
                  resolution: "1080p HD Video",
                  url: rawVideo,
                  isVideo: true,
                  hasAudioAndVideo: true
                }],
                isVideo: true,
                hasVideo: true,
                mediaType: "video",
                type: "video",
                downloadTarget: rawVideo,
                directStreamUrl: rawVideo,
                referer: "https://www.instagram.com/"
              };
            }
            if (rawPhoto) {
              return {
                id: "instagram_" + shortcode,
                url,
                title: cap,
                uploader: user,
                thumbnail: rawPhoto,
                duration: 0,
                formats: [{
                  formatId: "photo_embed",
                  ext: "jpg",
                  resolution: "Original Photo",
                  url: rawPhoto,
                  isImage: true
                }],
                isImage: true,
                mediaType: "image",
                type: "image",
                downloadTarget: rawPhoto,
                directStreamUrl: rawPhoto,
                referer: "https://www.instagram.com/"
              };
            }
          }
        } catch (embErr) {
          logger.warn("[Instagram Carousel] Embed fallback failed:", embErr.message);
        }
        throw new Error("Could not analyze Instagram carousel or photo post.");
      }
      async analyzeTikTok(url, timeoutMs = 35e3) {
        logger.info(`Analyzing TikTok URL: ${url}`);
        const cleanUrl = url.trim();
        try {
          const apiUrl = `https://www.tikwm.com/api/?url=${encodeURIComponent(cleanUrl)}&hd=1`;
          const res = await fetch(apiUrl, {
            headers: {
              "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
              "Accept": "application/json"
            },
            signal: AbortSignal.timeout(Math.min(timeoutMs, 18e3))
          });
          if (res.ok) {
            const json = await res.json();
            if (json && json.code === 0 && json.data) {
              const data = json.data;
              const title = (data.title || data.content_desc || "TikTok Video").replace(/[\r\n\t]+/g, " ").trim();
              const uploader = data.author && (data.author.nickname || data.author.unique_id) || "TikTok Creator";
              const thumbnail = data.origin_cover || data.cover || "";
              const duration = data.duration || 0;
              if (Array.isArray(data.images) && data.images.length > 0) {
                const items = data.images.map((imgUrl, idx) => ({
                  id: `tiktok_slide_${data.id || Date.now()}_${idx + 1}`,
                  index: idx + 1,
                  title: `${title} (Slide ${idx + 1})`,
                  url: imgUrl,
                  downloadTarget: imgUrl,
                  downloadQuery: imgUrl,
                  thumbnail: imgUrl,
                  uploader,
                  type: "image",
                  resolution: "Original Photo",
                  directStreamUrl: imgUrl,
                  formats: [
                    {
                      formatId: `tiktok_photo_${idx + 1}`,
                      ext: "jpg",
                      resolution: "Original Photo",
                      qualityLabel: "Original Photo (High-Res)",
                      url: imgUrl,
                      isImage: true
                    }
                  ]
                }));
                return {
                  id: `tiktok_${data.id || Date.now()}`,
                  isPlaylist: true,
                  isCarousel: true,
                  url: cleanUrl,
                  title,
                  uploader,
                  thumbnail: thumbnail || data.images[0],
                  itemCount: items.length,
                  items,
                  platform: "tiktok",
                  mediaType: "image",
                  carouselSlides: items.map((it) => ({
                    slideIndex: it.index,
                    mediaType: "image",
                    thumbnail: it.thumbnail,
                    url: it.downloadTarget
                  })),
                  downloadTarget: items[0].downloadTarget,
                  directStreamUrl: items[0].directStreamUrl,
                  previewUrl: items[0].directStreamUrl,
                  formats: items[0].formats
                };
              }
              const hdStream = data.hdplay || data.play || "";
              const sdStream = data.play || "";
              const wmStream = data.wmplay || "";
              const audioStream = data.music || "";
              const formats = [];
              if (hdStream) {
                formats.push({
                  formatId: "tiktok_hd_nowm",
                  ext: "mp4",
                  resolution: "1080p",
                  quality: "1080",
                  height: 1080,
                  label: "1080p Full HD (No Watermark)",
                  qualityLabel: "1080p Full HD (No Watermark)",
                  url: hdStream,
                  previewUrl: sdStream || hdStream,
                  hasAudioAndVideo: true,
                  isVideo: true
                });
              }
              if (sdStream && sdStream !== hdStream) {
                formats.push({
                  formatId: "tiktok_sd_nowm",
                  ext: "mp4",
                  resolution: "720p",
                  quality: "720",
                  height: 720,
                  label: "720p HD (No Watermark)",
                  qualityLabel: "720p HD (No Watermark)",
                  url: sdStream,
                  previewUrl: sdStream,
                  hasAudioAndVideo: true,
                  isVideo: true
                });
              }
              if (wmStream) {
                formats.push({
                  formatId: "tiktok_wm",
                  ext: "mp4",
                  resolution: "Original",
                  label: "Original with Watermark",
                  qualityLabel: "Original with Watermark",
                  url: wmStream,
                  hasAudioAndVideo: true,
                  isVideo: true
                });
              }
              if (audioStream) {
                formats.push({
                  formatId: "tiktok_audio_master",
                  ext: "mp3",
                  resolution: "audio only",
                  label: "Original Audio Track (MP3)",
                  qualityLabel: "Original Audio Track (MP3)",
                  url: audioStream,
                  isAudioOnly: true
                });
              }
              if (thumbnail) {
                formats.push({
                  formatId: "tiktok_cover_photo",
                  ext: "jpg",
                  resolution: "Cover Photo",
                  qualityLabel: "Original Cover Photo (JPG)",
                  url: thumbnail,
                  isImage: true
                });
              }
              const primaryStream = hdStream || sdStream;
              return {
                id: `tiktok_${data.id || Date.now()}`,
                url: cleanUrl,
                title,
                uploader,
                thumbnail,
                duration,
                formats,
                availableResolutions: hdStream ? [1080, 720] : [720],
                hasAudio: true,
                hasVideo: true,
                hasImage: !!thumbnail,
                downloadTarget: primaryStream,
                directStreamUrl: primaryStream,
                previewUrl: sdStream || hdStream,
                directAudioUrl: audioStream,
                platform: "tiktok",
                mediaType: "video",
                defaultProfile: {
                  type: "video",
                  presetId: "best-available",
                  label: "1080p / Best Quality (No Watermark)",
                  container: "mp4",
                  remuxToMp4: true
                }
              };
            }
          }
        } catch (tikwmErr) {
          logger.warn("[TikTok] TikWM analysis notice, attempting TikMate fallback:", tikwmErr.message);
        }
        try {
          const mateRes = await fetch("https://api.tikmate.app/api/lookup", {
            method: "POST",
            headers: {
              "Content-Type": "application/x-www-form-urlencoded",
              "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            },
            body: `url=${encodeURIComponent(cleanUrl)}`,
            signal: AbortSignal.timeout(Math.min(timeoutMs, 15e3))
          });
          if (mateRes.ok) {
            const mate = await mateRes.json();
            if (mate && mate.token && mate.id) {
              const title = (mate.desc || "TikTok Video").replace(/[\r\n\t]+/g, " ").trim();
              const uploader = mate.author_name || "TikTok Creator";
              const thumbnail = mate.cover || "";
              const streamUrl = `https://tikmate.app/download/${mate.token}/${mate.id}.mp4?hd=1`;
              return {
                id: `tiktok_${mate.id}`,
                url: cleanUrl,
                title,
                uploader,
                thumbnail,
                duration: 30,
                formats: [
                  {
                    formatId: "tiktok_mate_hd",
                    ext: "mp4",
                    resolution: "1080p",
                    quality: "1080",
                    height: 1080,
                    label: "1080p HD (No Watermark)",
                    qualityLabel: "1080p HD (No Watermark)",
                    url: streamUrl,
                    hasAudioAndVideo: true,
                    isVideo: true
                  }
                ],
                availableResolutions: [1080],
                hasAudio: true,
                hasVideo: true,
                downloadTarget: streamUrl,
                directStreamUrl: streamUrl,
                platform: "tiktok",
                mediaType: "video",
                defaultProfile: {
                  type: "video",
                  presetId: "best-available",
                  label: "1080p / Best Quality",
                  container: "mp4",
                  remuxToMp4: true
                }
              };
            }
          }
        } catch (mateErr) {
          logger.warn("[TikTok] TikMate fallback notice:", mateErr.message);
        }
        try {
          logger.info(`[TikTok] Falling through to standard engine for ${cleanUrl}`);
          const ytdlpPath = await dependencyManager.getYtDlpExecutablePath();
          const ytArgs = await youtubeTokenManager.getYtDlpExtractorArgs(cleanUrl);
          const args = [
            "--dump-single-json",
            "--skip-download",
            "--no-warnings",
            "--no-check-certificates",
            ...ytArgs,
            "--add-header",
            "User-Agent:Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
            cleanUrl
          ];
          const { stdout } = await execFileAsync2(ytdlpPath, args, { windowsHide: true, timeout: timeoutMs, maxBuffer: 20 * 1024 * 1024 });
          const raw = JSON.parse(stdout);
          return await this.parseYtDlpOutput(cleanUrl, raw);
        } catch (finalErr) {
          logger.error("[TikTok] All extractors failed for:", cleanUrl, finalErr.message);
          throw classifyError(finalErr, "TikTok media extraction failed. Please check your internet connection or the URL.");
        }
      }
      async analyzeUrl(url, timeoutMs = 45e3) {
        if (!url) throw new Error("No URL provided");
        const cached = this.getCachedMetadata(url);
        if (cached) {
          logger.info(`[Analyzer] Returning in-memory cached metadata for: ${url}`);
          return cached;
        }
        if (this.isFacebookUrl(url)) {
          const res = await this.analyzeFacebook(url, timeoutMs);
          if (res) this.setCachedMetadata(url, res);
          return res;
        }
        if (this.isTikTokUrl(url)) {
          const res = await this.analyzeTikTok(url, timeoutMs);
          if (res) this.setCachedMetadata(url, res);
          return res;
        }
        if (this.isPlaylistUrl(url)) {
          return await this.analyzePlaylist(url, timeoutMs);
        }
        if (this.isThreadsUrl(url)) {
          const res = await this.analyzeThreads(url, timeoutMs);
          if (res) this.setCachedMetadata(url, res);
          return res;
        }
        if (this.isSpotifyPlaylistUrl(url)) {
          return await this.analyzePlaylist(url, timeoutMs);
        }
        if (this.isSpotifyUrl(url)) {
          const res = await this.analyzeSpotify(url, timeoutMs);
          if (res) this.setCachedMetadata(url, res);
          return res;
        }
        if (this.isAppleMusicAlbumUrl(url)) {
          return await this.analyzePlaylist(url, timeoutMs);
        }
        if (this.isAppleMusicUrl(url)) {
          const res = await this.analyzeAppleMusic(url, timeoutMs);
          if (res) this.setCachedMetadata(url, res);
          return res;
        }
        if (this.isBehanceUrl(url)) {
          const res = await this.analyzeBehance(url, timeoutMs);
          if (res) this.setCachedMetadata(url, res);
          return res;
        }
        if (this.isDribbbleUrl(url)) {
          const res = await this.analyzeDribbble(url, timeoutMs);
          if (res) this.setCachedMetadata(url, res);
          return res;
        }
        if (this.isArtStationUrl(url)) {
          const res = await this.analyzeArtStation(url, timeoutMs);
          if (res) this.setCachedMetadata(url, res);
          return res;
        }
        if (this.isFiverrUrl(url)) {
          const res = await this.analyzeFiverr(url, timeoutMs);
          if (res) this.setCachedMetadata(url, res);
          return res;
        }
        if (this.isPinterestUrl(url)) {
          const res = await this.analyzePinterest(url, timeoutMs);
          if (res) this.setCachedMetadata(url, res);
          return res;
        }
        if (this.isCloudStorageUrl(url)) {
          const res = await this.analyzeCloudStorage(url, timeoutMs);
          if (res) this.setCachedMetadata(url, res);
          return res;
        }
        if (url.includes("instagram.com/p/") || url.includes("instagram.com/reel/")) {
          try {
            const igResult = await this.analyzeInstagram(url, timeoutMs);
            if (igResult) {
              this.setCachedMetadata(url, igResult);
              return igResult;
            }
          } catch (igErr) {
            logger.info(`Instagram custom handler deferred to yt-dlp: ${igErr.message}`);
          }
        }
        logger.info(`Analyzing URL with yt-dlp: ${url}`);
        const ytdlpPath = await dependencyManager.getYtDlpExecutablePath();
        const isMultiPost = url.includes("instagram.com") || url.includes("pinterest.com");
        let ytArgs = [];
        try {
          ytArgs = await Promise.race([
            youtubeTokenManager.getYtDlpExtractorArgs(url, true),
            new Promise((r) => setTimeout(() => r(["--remote-components", "ejs:github"]), 1e3))
          ]);
        } catch (_) {
          ytArgs = ["--remote-components", "ejs:github"];
        }
        const args = [
          "--dump-single-json",
          "--skip-download",
          "--no-warnings",
          "--ignore-no-formats-error",
          ...isMultiPost ? [] : ["--no-playlist"],
          "--no-check-certificates",
          "--match-filter",
          "!is_storyboard",
          ...ytArgs,
          ...url.includes("youtube.com") || url.includes("youtu.be") ? [] : ["--add-header", "User-Agent:Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"],
          url
        ];
        let hasCookies = false;
        const localAppData = process.env.LOCALAPPDATA || (import_os7.default.homedir ? import_path7.default.join(import_os7.default.homedir(), "AppData", "Local") : "");
        const cookiesFilePath = localAppData ? import_path7.default.join(localAppData, "MediaFetch", "cookies.txt") : "";
        if (cookiesFilePath && import_fs7.default.existsSync(cookiesFilePath) && import_fs7.default.statSync(cookiesFilePath).size > 10) {
          args.push("--cookies", cookiesFilePath);
          hasCookies = true;
        } else {
          const rawCookiesBrowser = settingsManager.getSettings()?.engine?.browserCookies || settingsManager.getSettings()?.engine?.cookiesBrowser || "none";
          const isWin = process.platform === "win32";
          const cookiesBrowser = isWin && rawCookiesBrowser === "chrome" ? "none" : rawCookiesBrowser;
          if (cookiesBrowser && cookiesBrowser !== "none") {
            args.push("--cookies-from-browser", cookiesBrowser);
            hasCookies = true;
          }
        }
        logger.info(`[Analyzer] Spawning yt-dlp binary: "${ytdlpPath}" with args: ${args.join(" ")}`);
        const execStart = Date.now();
        try {
          const { stdout } = await execFileAsync2(ytdlpPath, args, {
            windowsHide: true,
            timeout: timeoutMs,
            maxBuffer: 30 * 1024 * 1024
          });
          logger.info(`[Analyzer] yt-dlp extraction completed in ${Date.now() - execStart}ms for: ${url}`);
          let raw = JSON.parse(stdout);
          let parsed = await this.parseYtDlpOutput(url, raw);
          const isYouTubeVideoUrl = (url.includes("youtube.com") || url.includes("youtu.be")) && !url.includes("/post/") && !url.includes("/community");
          if (isYouTubeVideoUrl && parsed && !parsed.isUpcoming && !parsed.hasVideo && !parsed.hasAudio) {
            logger.warn(`[Analyzer] yt-dlp returned 0 video/audio streams for YouTube URL ${url}; attempting auto-update of yt-dlp and retry...`);
            const upd = await dependencyManager.autoRecoverYtDlpIfStale();
            if (upd && upd.success) {
              const freshPath = await dependencyManager.getYtDlpExecutablePath();
              const { stdout: retryStdout } = await execFileAsync2(freshPath, args, {
                windowsHide: true,
                timeout: timeoutMs,
                maxBuffer: 30 * 1024 * 1024
              });
              raw = JSON.parse(retryStdout);
              parsed = await this.parseYtDlpOutput(url, raw);
            }
            if (!parsed.hasVideo && !parsed.hasAudio && !parsed.isUpcoming) {
              throw new Error("Failed to extract YouTube video streams. Please update yt-dlp in Settings > Engine or refresh your cookies.");
            }
          }
          if (parsed && (parsed.formats?.length > 0 || parsed.directStreamUrl || parsed.duration > 0 || parsed.isImage)) {
            this.setCachedMetadata(url, parsed);
            return parsed;
          }
          logger.info(`yt-dlp returned 0 playable formats for ${url}, switching to Universal Web Media Extractor...`);
          try {
            const universalMeta = await this.analyzeUniversalWebMedia(url, timeoutMs);
            if (universalMeta) {
              this.setCachedMetadata(url, universalMeta);
              return universalMeta;
            }
          } catch (_) {
          }
          if (parsed) {
            this.setCachedMetadata(url, parsed);
            return parsed;
          }
        } catch (err) {
          logger.error(`[Analyzer] yt-dlp execution error after ${Date.now() - execStart}ms: ${err?.message}`, err?.stderr ? `| stderr: ${err.stderr.substring(0, 300)}` : "");
          const errStrCheck = (err ? err.stderr || err.message || String(err) : "").toLowerCase();
          const isCookieOrDpapiError = hasCookies || errStrCheck.includes("dpapi") || errStrCheck.includes("failed to decrypt") || errStrCheck.includes("cookie") || errStrCheck.includes("database is locked") || errStrCheck.includes("the page needs to be reloaded") || errStrCheck.includes("confirm you\u2019re not a robot");
          if (isCookieOrDpapiError) {
            logger.info(`[Analyzer] yt-dlp failed with cookies/session/DPAPI (${err?.message || "Error"}), retrying cleanly WITHOUT cookies...`);
            try {
              const cleanArgs = args.filter((a, idx) => a !== "--cookies" && args[idx - 1] !== "--cookies" && a !== "--cookies-from-browser" && args[idx - 1] !== "--cookies-from-browser");
              const { stdout: cleanStdout } = await execFileAsync2(ytdlpPath, cleanArgs, {
                windowsHide: true,
                timeout: Math.min(timeoutMs, 25e3),
                maxBuffer: 30 * 1024 * 1024
              });
              const cleanRaw = JSON.parse(cleanStdout);
              const cleanParsed = await this.parseYtDlpOutput(url, cleanRaw);
              if (cleanParsed) this.setCachedMetadata(url, cleanParsed);
              return cleanParsed;
            } catch (retryErr) {
              logger.warn(`[Analyzer] Clean retry without cookies notice: ${retryErr?.message || retryErr}`);
            }
          }
          const errStr = (err ? err.stderr || err.message || String(err) : "").toLowerCase();
          if (errStr.includes("live event will begin") || errStr.includes("premiere will begin") || errStr.includes("live event has not started") || errStr.includes("live event has not begun")) {
            const ytIdMatch = url.match(/(?:v=|\/shorts\/|\/embed\/|youtu\.be\/|\/v\/|\/e\/)([\w-]{11})/);
            const vidId = ytIdMatch ? ytIdMatch[1] : "media";
            const bestThumb = `https://i.ytimg.com/vi/${vidId}/maxresdefault.jpg`;
            return {
              id: vidId,
              url,
              title: "Upcoming YouTube Premiere / Live Event",
              thumbnail: bestThumb,
              duration: 0,
              uploader: "YouTube Creator",
              mediaType: "image",
              type: "image",
              isImage: true,
              isUpcoming: true,
              liveStatus: "is_upcoming",
              directImageUrl: bestThumb,
              directStreamUrl: bestThumb,
              downloadTarget: bestThumb,
              formats: [
                {
                  formatId: "photo_thumbnail",
                  url: bestThumb,
                  ext: "jpg",
                  resolution: "1920x1080",
                  width: 1920,
                  height: 1080,
                  isAudioOnly: false,
                  isVideoOnly: false,
                  hasAudioAndVideo: false,
                  label: "Photo / Cover Thumbnail (HD)",
                  qualityLabel: "HD Photo / Cover",
                  protocol: "https"
                }
              ],
              availableResolutions: [],
              hasAudio: false,
              hasVideo: false,
              defaultProfile: {
                type: "image",
                presetId: "image-jpg",
                label: "Photo / Cover (JPG)",
                container: "jpg",
                remuxToMp4: false
              }
            };
          }
          if (url.includes("instagram.com") || err && String(err).includes("No video formats found")) {
            try {
              return await this.analyzeInstagram(url, timeoutMs);
            } catch (_) {
            }
          }
          const isYouTubeCommunity = url.includes("/post/") || url.includes("/community");
          if (isYouTubeCommunity) {
            logger.info(`YouTube Community post detected for ${url}, extracting community post image...`);
            try {
              return await this.analyzeUniversalWebMedia(url, timeoutMs);
            } catch (_) {
            }
          }
          const isYouTubeUrl = url.includes("youtube.com") || url.includes("youtu.be");
          if (isYouTubeUrl) {
            logger.error(`YouTube video extraction failed for ${url}:`, err.message || err);
            throw classifyError(err, "Failed to extract YouTube video");
          }
          logger.info(`yt-dlp could not extract media for ${url}, automatically switching to Universal Web Media Extractor...`);
          try {
            return await this.analyzeUniversalWebMedia(url, timeoutMs);
          } catch (fallbackErr) {
            logger.error("Both yt-dlp and Universal Web Media Extractor failed:", fallbackErr);
          }
          logger.error("Metadata analysis failed:", err);
          throw classifyError(err, "Failed to analyze media URL");
        }
      }
      resolveAuthenticTitle(raw, url) {
        let candidate = "";
        const isYouTube = raw.extractor_key && raw.extractor_key.toLowerCase().includes("youtube") || raw.extractor && raw.extractor.toLowerCase().includes("youtube") || url && (url.includes("youtube.com") || url.includes("youtu.be"));
        const rawTitle = (raw.title || "").trim();
        const isGenericTitle = !rawTitle || /^video by /i.test(rawTitle) || /^post by /i.test(rawTitle) || /^tweet by /i.test(rawTitle) || /^tiktok video by /i.test(rawTitle) || /^threads post by /i.test(rawTitle) || /^photo by /i.test(rawTitle) || /^media by /i.test(rawTitle) || rawTitle.toLowerCase() === "media" || rawTitle.toLowerCase() === "instagram" || rawTitle.toLowerCase() === "threads" || rawTitle.toLowerCase() === "twitter" || rawTitle.toLowerCase() === "tiktok" || rawTitle.toLowerCase() === "facebook" || rawTitle.toLowerCase().includes("log in") || rawTitle.toLowerCase().includes("login") || rawTitle.startsWith("#") || rawTitle.startsWith("@");
        if ((!isYouTube || isGenericTitle) && raw.description) {
          const lines = raw.description.split(/[\r\n]+/);
          for (let line of lines) {
            line = line.replace(/https?:\/\/\S+/g, "").replace(/[#@]\S+/g, "").trim();
            line = line.replace(/^["'“”‘]+|["'“”‘]+$/g, "").trim();
            if (line.length >= 3) {
              candidate = line;
              break;
            }
          }
          if (!candidate) {
            for (const line of lines) {
              const trimmed = line.trim();
              if (trimmed.length >= 3 && !trimmed.startsWith("http")) {
                candidate = trimmed;
                break;
              }
            }
          }
        }
        if (candidate) {
          if (candidate.length > 120) candidate = candidate.substring(0, 117).trim() + "...";
          return candidate;
        }
        if (raw.fulltitle && !isGenericTitle) return raw.fulltitle.trim();
        if (rawTitle && !isGenericTitle) return rawTitle;
        if (rawTitle && /^video by /i.test(rawTitle)) {
          const stripped = rawTitle.replace(/^video by /i, "").trim();
          if (stripped) return `Instagram Clip (${stripped})`;
        }
        if (raw.uploader) return `Media by ${raw.uploader}`;
        return "Media";
      }
      async parseYtDlpOutput(url, raw) {
        const getStandardResolution = (f) => {
          if (!f) return null;
          const note = String(f.format_note || "").toLowerCase();
          const h = typeof f.height === "number" ? f.height : 0;
          const w = typeof f.width === "number" ? f.width : 0;
          if (note.includes("2160") || note.includes("4k")) return 2160;
          if (note.includes("1440") || note.includes("2k")) return 1440;
          if (note.includes("1080")) return 1080;
          if (note.includes("720")) return 720;
          if (note.includes("480")) return 480;
          if (note.includes("360")) return 360;
          if (note.includes("240")) return 240;
          if (note.includes("144")) return 144;
          const shorter = h > 0 && w > 0 ? Math.min(w, h) : h || w;
          const longer = h > 0 && w > 0 ? Math.max(w, h) : h || w;
          if (shorter >= 2160 || longer >= 3840) return 2160;
          if (shorter >= 1440 || longer >= 2560 && shorter >= 1e3) return 1440;
          if (shorter >= 1080 || longer >= 1920 && shorter >= 700) return 1080;
          if (shorter >= 720 || longer >= 1280 && shorter >= 500) return 720;
          if (shorter >= 480 || longer >= 854 && shorter >= 320) return 480;
          if (shorter >= 360 || longer >= 640 && shorter >= 240) return 360;
          if (shorter >= 240 || longer >= 426 && shorter >= 160) return 240;
          if (shorter >= 144 || longer >= 256 && shorter >= 100) return 144;
          return shorter > 0 && shorter <= 2160 ? shorter : null;
        };
        const formats = (raw.formats || []).map((f) => {
          const isAudioOnly = f.vcodec === "none" && f.acodec !== "none";
          const isVideoOnly = f.vcodec !== "none" && f.acodec === "none";
          const hasAudioAndVideo = f.vcodec !== "none" && f.acodec !== "none";
          const stdRes = getStandardResolution(f);
          let qualityLabel = "";
          if (stdRes) {
            qualityLabel = `${stdRes}p`;
            if (f.fps && f.fps > 30) qualityLabel += `${f.fps}`;
          } else if (f.height) {
            qualityLabel = `${f.height}p`;
            if (f.fps && f.fps > 30) qualityLabel += `${f.fps}`;
          } else if (f.abr) {
            qualityLabel = `${Math.round(f.abr)}kbps audio`;
          } else {
            qualityLabel = f.format_note || f.ext;
          }
          return {
            formatId: f.format_id,
            url: f.url,
            ext: f.ext,
            resolution: f.resolution || (f.height ? `${f.width || "?"}x${f.height}` : void 0),
            height: stdRes || f.height,
            width: f.width,
            vcodec: f.vcodec,
            acodec: f.acodec,
            filesize: f.filesize,
            filesizeApprox: f.filesize_approx,
            fps: f.fps,
            tbr: f.tbr,
            vbr: f.vbr,
            abr: f.abr,
            isAudioOnly,
            isVideoOnly,
            hasAudioAndVideo,
            quality: stdRes ? String(stdRes) : void 0,
            label: qualityLabel,
            qualityLabel,
            protocol: f.protocol
          };
        });
        const heights = (raw.formats || []).filter((f) => f && f.protocol !== "mhtml" && !String(f.format_id || "").startsWith("sb") && !String(f.ext || "").includes("mhtml") && f.vcodec !== "none").map(getStandardResolution).filter((h) => typeof h === "number" && h > 0 && h <= 2160);
        const rootRes = getStandardResolution(raw);
        if (rootRes && typeof rootRes === "number" && rootRes > 0 && rootRes <= 2160 && !heights.includes(rootRes)) {
          heights.push(rootRes);
        }
        const availableResolutions = [...new Set(heights)].sort((a, b) => b - a);
        const hasAudio = formats.some((f) => f.acodec && f.acodec !== "none");
        const hasVideo = formats.some((f) => f.vcodec && f.vcodec !== "none");
        let directStreamUrl = "";
        const progressiveMp4 = formats.slice().reverse().find((f) => f.hasAudioAndVideo && f.ext === "mp4" && f.url);
        const anyProgressive = formats.slice().reverse().find((f) => f.hasAudioAndVideo && f.url);
        const videoWithUrl = formats.slice().reverse().find((f) => f.vcodec && f.vcodec !== "none" && f.url);
        if (progressiveMp4) {
          directStreamUrl = progressiveMp4.url;
        } else if (anyProgressive) {
          directStreamUrl = anyProgressive.url;
        } else if (videoWithUrl) {
          directStreamUrl = videoWithUrl.url;
        } else if (raw.url) {
          directStreamUrl = raw.url;
        }
        let dur = Math.round(raw.duration || 0);
        if (!dur && hasVideo && directStreamUrl) {
          dur = await probeMediaDuration(directStreamUrl);
        }
        let uploader = raw.uploader || raw.channel || raw.creator || "";
        if (!uploader && (url.includes("linkedin.com") || url.includes("lnkd.in") || raw.extractor_key && raw.extractor_key.toLowerCase().includes("linkedin"))) {
          const authorMatch = (raw.title || "").match(/\|\s*([^|]+?)\s*\|/);
          if (authorMatch && authorMatch[1]) {
            uploader = authorMatch[1].trim();
          } else {
            const uMatch = (raw.webpage_url || url).match(/posts\/([a-zA-Z0-9-]+)_/);
            if (uMatch) uploader = uMatch[1].replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
          }
        }
        if (!uploader) uploader = "Unknown Creator";
        const hasPlayableStreams = formats.some((f) => f.hasAudioAndVideo || f.vcodec && f.vcodec !== "none" || f.acodec && f.acodec !== "none");
        const isUpcoming = Boolean((raw.live_status === "is_upcoming" || raw.live_status === "upcoming") && !hasPlayableStreams);
        const isYouTubeVideo = (url.includes("youtube.com") || url.includes("youtu.be") || raw.extractor_key && raw.extractor_key.toLowerCase().includes("youtube") || raw.extractor && raw.extractor.toLowerCase().includes("youtube")) && !url.includes("/post/") && !url.includes("/community");
        const canFallbackToImage = !isYouTubeVideo || isUpcoming;
        let bestThumbnail = (() => {
          let best = raw.thumbnail;
          if (Array.isArray(raw.thumbnails) && raw.thumbnails.length > 0) {
            const sorted = [...raw.thumbnails].sort((a, b) => (b.width || 0) * (b.height || 0) - (a.width || 0) * (a.height || 0));
            if (sorted[0]?.url) best = sorted[0].url;
          }
          if (raw.id && (raw.extractor_key === "Youtube" || url.includes("youtu"))) {
            if (!best) best = `https://i.ytimg.com/vi/${raw.id}/maxresdefault.jpg`;
          }
          return best || raw.thumbnails?.[0]?.url;
        })();
        if (isUpcoming || formats.length === 0 && canFallbackToImage) {
          if (bestThumbnail) {
            formats.push({
              formatId: "photo_thumbnail",
              url: bestThumbnail,
              ext: "jpg",
              resolution: "1920x1080",
              height: 1080,
              width: 1920,
              vcodec: "none",
              acodec: "none",
              isAudioOnly: false,
              isVideoOnly: false,
              hasAudioAndVideo: false,
              quality: "1080",
              label: "Photo / Cover Thumbnail (HD)",
              qualityLabel: "HD Photo / Cover",
              protocol: "https"
            });
            if (!directStreamUrl) directStreamUrl = bestThumbnail;
          }
        }
        const meta = {
          id: raw.id || "media",
          url,
          title: this.resolveAuthenticTitle(raw, url),
          thumbnail: bestThumbnail,
          duration: dur,
          uploader,
          channel: raw.channel,
          description: raw.description ? raw.description.substring(0, 300) : void 0,
          extractor: raw.extractor_key || raw.extractor,
          mediaType: isUpcoming ? "image" : hasVideo ? "video" : hasAudio ? "audio" : canFallbackToImage && (bestThumbnail || raw.thumbnail) ? "image" : "video",
          type: isUpcoming ? "image" : hasVideo ? "video" : hasAudio ? "audio" : canFallbackToImage && (bestThumbnail || raw.thumbnail) ? "image" : "video",
          isImage: Boolean(isUpcoming || canFallbackToImage && !hasVideo && !hasAudio && (bestThumbnail || raw.thumbnail)),
          isUpcoming,
          liveStatus: raw.live_status || (isUpcoming ? "is_upcoming" : void 0),
          releaseTimestamp: raw.release_timestamp,
          directImageUrl: isUpcoming ? bestThumbnail : void 0,
          directStreamUrl,
          downloadTarget: isUpcoming ? bestThumbnail : url.includes("youtube.com") || url.includes("youtu.be") || raw.extractor_key && raw.extractor_key.toLowerCase().includes("youtube") || raw.extractor && raw.extractor.toLowerCase().includes("youtube") ? raw.webpage_url || url : directStreamUrl || url,
          formats,
          availableResolutions,
          hasAudio,
          hasVideo,
          defaultProfile: isUpcoming || canFallbackToImage && !hasVideo && !hasAudio && (bestThumbnail || raw.thumbnail) ? {
            type: "image",
            presetId: "image-orig",
            label: "Photo / Cover (JPG)",
            container: "jpg",
            remuxToMp4: false
          } : {
            type: "video",
            presetId: "best-available",
            label: "Best Available Quality (Universal H.264)",
            container: "mp4",
            remuxToMp4: true
          }
        };
        if (raw._type === "playlist" || raw.entries && Array.isArray(raw.entries) && raw.entries.length > 1) {
          const entries = Array.isArray(raw.entries) ? raw.entries : [];
          meta.isPlaylist = true;
          meta.isCarousel = true;
          meta.itemCount = entries.length;
          meta.items = entries.map((entry, idx) => {
            const isEntryVideo = entry.vcodec && entry.vcodec !== "none" || entry.formats && entry.formats.some((f) => f.vcodec && f.vcodec !== "none");
            const entryThumb = entry.thumbnail || entry.thumbnails?.[0]?.url || meta.thumbnail;
            const entryUrl = entry.url || entry.webpage_url || url;
            const entryTitle = entry.title || `${meta.title} (Slide ${idx + 1})`;
            return {
              id: entry.id || `slide_${idx + 1}`,
              title: entryTitle,
              thumbnail: entryThumb,
              duration: entry.duration || 0,
              url: entryUrl,
              downloadQuery: entryUrl,
              downloadTarget: entryUrl,
              directStreamUrl: entryUrl,
              uploader: entry.uploader || meta.uploader || "@Instagram",
              mediaType: isEntryVideo ? "video" : "image",
              type: isEntryVideo ? "video" : "image",
              subFolderName: ""
            };
          });
          meta.carouselSlides = meta.items.map((item, idx) => ({
            index: idx + 1,
            id: item.id,
            mediaType: item.mediaType,
            label: `Slide ${idx + 1} \u2022 ${item.mediaType === "video" ? "Video" : "Photo"}`,
            url: item.url,
            thumbnail: item.thumbnail,
            duration: item.duration
          }));
        }
        return meta;
      }
      getAvailableProfiles(metadata) {
        const profiles = [];
        if (metadata.hasVideo) {
          profiles.push({
            type: "video",
            presetId: "best-available",
            label: "Best Available Quality (Universal H.264)",
            container: "mp4",
            remuxToMp4: true
          });
          if (metadata.availableResolutions.includes(2160)) {
            profiles.push({ type: "video", presetId: "video-4k", label: "4K Ultra HD (2160p) \u2022 Studio Quality (Slower \u2022 Large File)", resolution: 2160, container: "mp4", remuxToMp4: true });
          }
          if (metadata.availableResolutions.includes(1440)) {
            profiles.push({ type: "video", presetId: "video-1440p", label: "1440p Quad HD (2K) \u2022 High Quality (Moderate Speed)", resolution: 1440, container: "mp4", remuxToMp4: true });
          }
          if (metadata.availableResolutions.includes(1080) || metadata.availableResolutions.some((r) => r >= 1080)) {
            profiles.push({ type: "video", presetId: "video-1080p", label: "1080p Full HD \u2022 Recommended (Fast & Balanced)", resolution: 1080, container: "mp4", remuxToMp4: true });
          }
          if (metadata.availableResolutions.includes(720) || metadata.availableResolutions.some((r) => r >= 720)) {
            profiles.push({ type: "video", presetId: "video-720p", label: "720p HD \u2022 High Speed (Light File)", resolution: 720, container: "mp4", remuxToMp4: true });
          }
          if (metadata.availableResolutions.includes(480) || metadata.availableResolutions.some((r) => r >= 480)) {
            profiles.push({ type: "video", presetId: "video-480p", label: "480p SD \u2022 Standard Quality (Lightweight)", resolution: 480, container: "mp4", remuxToMp4: true });
          }
          if (metadata.availableResolutions.includes(360) || metadata.availableResolutions.some((r) => r >= 360)) {
            profiles.push({ type: "video", presetId: "video-360p", label: "360p \u2022 Small File (Fast Download)", resolution: 360, container: "mp4", remuxToMp4: true });
          }
          profiles.push({
            type: "video",
            presetId: "video-prores",
            label: "Apple ProRes 422 HQ (Broadcast Master)",
            container: "mov"
          });
        }
        if (metadata.hasAudio) {
          profiles.push({
            type: "audio",
            presetId: "best-audio",
            label: "Best Audio Quality (MP3 320kbps)",
            container: "mp3"
          });
          profiles.push({
            type: "audio",
            presetId: "audio-wav",
            label: "Lossless Studio Audio (WAV 48kHz)",
            container: "wav"
          });
        }
        return profiles;
      }
    };
    metadataAnalyzer = new MetadataAnalyzer();
  }
});

// MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/service/downloader.js
function getOptimalEncoderArgs(ffmpegPath) {
  if (cachedServiceEncoder) return cachedServiceEncoder;
  const candidates = [
    { name: "h264_nvenc", args: ["-c:v", "h264_nvenc", "-preset", "p4", "-cq", "18", "-b:v", "0", "-maxrate", "120M", "-bufsize", "120M", "-pix_fmt", "yuv420p"] },
    { name: "h264_qsv", args: ["-c:v", "h264_qsv", "-preset", "veryfast", "-global_quality", "18", "-pix_fmt", "yuv420p"] },
    { name: "h264_amf", args: ["-c:v", "h264_amf", "-quality", "quality", "-rc", "cqp", "-qp_p", "18", "-qp_i", "18", "-pix_fmt", "yuv420p"] }
  ];
  for (const c of candidates) {
    try {
      (0, import_child_process3.execFileSync)(ffmpegPath, ["-f", "lavfi", "-i", "nullsrc=s=256x256:d=0.04", "-c:v", c.name, "-f", "null", "-"], { windowsHide: true, timeout: 1500, stdio: "pipe" });
      cachedServiceEncoder = c.args;
      return cachedServiceEncoder;
    } catch (_) {
    }
  }
  cachedServiceEncoder = [
    "-threads",
    "0",
    "-c:v",
    "libx264",
    "-preset",
    "ultrafast",
    "-crf",
    "18",
    "-pix_fmt",
    "yuv420p"
  ];
  return cachedServiceEncoder;
}
function getAria2cExecutablePath() {
  const localAppData = process.env.LOCALAPPDATA || (import_os8.default.homedir ? import_path8.default.join(import_os8.default.homedir(), "AppData", "Local") : "");
  const mfAria2c = localAppData ? import_path8.default.join(localAppData, "MediaFetch", "bin", process.platform === "win32" ? "aria2c.exe" : "aria2c") : "";
  if (mfAria2c && import_fs8.default.existsSync(mfAria2c)) {
    return mfAria2c;
  }
  return null;
}
async function probeDurationSeconds(filePath, ffprobePath) {
  if (!ffprobePath || !import_fs8.default.existsSync(ffprobePath) || !import_fs8.default.existsSync(filePath)) {
    return null;
  }
  try {
    const { stdout } = await execFileAsync3(ffprobePath, [
      "-v",
      "error",
      "-show_entries",
      "format=duration",
      "-of",
      "default=noprint_wrappers=1:nokey=1",
      filePath
    ], { windowsHide: true, timeout: 1e4 });
    const dur = parseFloat((stdout || "").trim());
    return !isNaN(dur) && dur > 0 ? dur : null;
  } catch (err) {
    logger.warn("[DownloadJob] probeDuration notice:", err?.message || err);
    return null;
  }
}
var import_child_process3, import_util3, import_path8, import_fs8, import_os8, import_https3, import_http3, execFileAsync3, cachedServiceEncoder, DownloadJob;
var init_downloader = __esm({
  "MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/service/downloader.js"() {
    import_child_process3 = require("child_process");
    import_util3 = require("util");
    import_path8 = __toESM(require("path"));
    import_fs8 = __toESM(require("fs"));
    import_os8 = __toESM(require("os"));
    import_https3 = __toESM(require("https"));
    import_http3 = __toESM(require("http"));
    init_errors();
    init_dependencies();
    init_filesystem();
    init_settings();
    init_analyzer();
    init_logger();
    init_youtubeToken();
    execFileAsync3 = (0, import_util3.promisify)(import_child_process3.execFile);
    cachedServiceEncoder = null;
    DownloadJob = class {
      constructor(item, onProgress) {
        this.item = item;
        this.childProcess = void 0;
        this.activeHttpRequest = void 0;
        this.isPaused = false;
        this.isCancelled = false;
        this.lastProgressEmit = 0;
        this.throttleMs = 250;
        this.onProgressCb = onProgress;
        this.streamIndex = 0;
        this.completedStreamsBytes = 0;
        this.completedStreamsTotal = 0;
        this.currentStreamDownloaded = 0;
        this.currentStreamTotal = 0;
        this.lastStreamTotal = 0;
      }
      getItem() {
        return this.item;
      }
      async start() {
        let ytdlpPath = await dependencyManager.getYtDlpExecutablePath();
        let ffmpegPath = await dependencyManager.getFfmpegExecutablePath();
        let ffprobePath = await dependencyManager.getFfprobeExecutablePath();
        const binDir = dependencyManager.getBinDir();
        if (!import_fs8.default.existsSync(ytdlpPath)) {
          this.emitThrottledProgress({
            progress: 2,
            downloadedBytes: 0,
            totalBytes: 0,
            speed: "",
            eta: "",
            stageDescription: "Auto-installing media engine (first run)..."
          });
          await dependencyManager.installYtDlp((stage, pct, msg) => {
            this.emitThrottledProgress({
              progress: Math.min(10, Math.round(pct * 0.1)),
              downloadedBytes: 0,
              totalBytes: 0,
              speed: "",
              eta: "",
              stageDescription: msg || "Configuring media engine..."
            });
          });
          ytdlpPath = await dependencyManager.getYtDlpExecutablePath();
        }
        if (!import_fs8.default.existsSync(ffmpegPath)) {
          this.emitThrottledProgress({
            progress: 10,
            downloadedBytes: 0,
            totalBytes: 0,
            speed: "",
            eta: "",
            stageDescription: "Auto-installing FFmpeg merger (first run)..."
          });
          await dependencyManager.installFfmpeg((stage, pct, msg) => {
            this.emitThrottledProgress({
              progress: Math.min(20, 10 + Math.round(pct * 0.1)),
              downloadedBytes: 0,
              totalBytes: 0,
              speed: "",
              eta: "",
              stageDescription: msg || "Configuring FFmpeg..."
            });
          });
          ffmpegPath = await dependencyManager.getFfmpegExecutablePath();
          ffprobePath = await dependencyManager.getFfprobeExecutablePath();
        }
        const currentSettings = settingsManager.getSettings();
        let targetDir = this.item.targetFolder;
        if (!targetDir) {
          const isCustomModeActive = currentSettings?.downloads?.downloadLocationMode === "custom" || currentSettings?.downloads?.downloadLocationMode === "custom_flat";
          if (isCustomModeActive && currentSettings?.downloads?.customLocation?.trim()) {
            targetDir = import_path8.default.resolve(currentSettings.downloads.customLocation.trim());
          } else {
            targetDir = this.item.projectFolder || filesystemManager.resolveTargetDirectory(this.item.projectContext).targetDir;
          }
        }
        const stagingDir = import_path8.default.join(targetDir, ".temp_mediafetch");
        filesystemManager.ensureDirExists(stagingDir);
        const isSpotify = this.item.url.includes("spotify.com") || this.item.url.includes("spotify.link");
        const isAppleMusic = this.item.url.includes("music.apple.com") || this.item.url.includes("itunes.apple.com");
        const isThreads = this.item.url.includes("threads.net") || this.item.url.includes("threads.com");
        const isPinterest = this.item.url.includes("pinterest.") || this.item.url.includes("pin.it") || this.item.url.includes("pinimg.com") || this.item.metadata?.platform === "pinterest" || this.item.metadata?.extractor === "pinterest";
        const isInstagram = this.item.url.includes("instagram.com");
        const isBehance = /behance\.(?:net|com)/i.test(this.item.url);
        const isDribbble = /dribbble\.com/i.test(this.item.url);
        const isFiverr = /fiverr\.com/i.test(this.item.url);
        const isArtStation = /artstation\.com/i.test(this.item.url);
        const isTikTok = this.item.metadata?.platform === "tiktok" || /tiktok\.com|tiktokcdn|vm\.tiktok\.com|vt\.tiktok\.com/i.test(this.item.url);
        const isTwitter = /twitter\.com|x\.com/i.test(this.item.url);
        const isFacebook = /facebook\.com|fb\.watch/i.test(this.item.url);
        const isPlaylistOrBatch = Boolean(this.item.metadata?.isPlaylist || this.item.metadata?.batchId || this.item.metadata?.zipPackage);
        if (!isSpotify && !isAppleMusic && !isPlaylistOrBatch && this.item.metadata && this.item.metadata.url && this.item.metadata.url !== this.item.url && this.item.metadata.webpage_url !== this.item.url) {
          logger.info(`[DownloadJob] Discarding stale metadata for item ${this.item.id} (URL mismatch: ${this.item.metadata.url} vs ${this.item.url})`);
          this.item.metadata = {};
          this.item.title = "";
        }
        if (isPinterest && this.item.url.includes("pin.it")) {
          try {
            const expanded = await metadataAnalyzer.expandPinterestUrl(this.item.url);
            if (expanded && !expanded.includes("pin.it")) {
              this.item.url = expanded;
            }
          } catch (e) {
          }
        }
        const isGenericTitle = !this.item.title || this.item.title === "Fetching media info..." || this.item.title === "Fetching media info" || this.item.title.toLowerCase().startsWith("fetching media info") || /^google drive file/i.test(this.item.title) || /^video by /i.test(this.item.title) || /^post by /i.test(this.item.title) || /^tweet by /i.test(this.item.title) || this.item.title.toLowerCase() === "media" || /^media[\._]/i.test(this.item.title);
        const isCloudStorage = /drive\.google\.com|dropbox\.com|1drv\.ms|onedrive\.live\.com|sharepoint\.com/i.test(this.item.url);
        const needsMandatoryPreAnalysis = (isSpotify || isAppleMusic) && (!this.item.metadata?.downloadQuery || isGenericTitle) || isInstagram && !this.item.metadata?.directStreamUrl && !this.item.metadata?.downloadTarget || isThreads && !this.item.metadata?.directStreamUrl || isPinterest && (!this.item.metadata?.directStreamUrl || isGenericTitle) && !this.item.url.includes("pinimg.com") || isBehance && !this.item.metadata?.downloadTarget && !this.item.metadata?.directStreamUrl || isDribbble && !this.item.metadata?.directStreamUrl && !this.item.metadata?.downloadTarget || isFiverr && !this.item.metadata?.directStreamUrl && !this.item.metadata?.downloadTarget || isArtStation && !this.item.metadata?.directStreamUrl && !this.item.metadata?.downloadTarget || (isTwitter || isFacebook) && (!this.item.metadata?.directStreamUrl && !this.item.metadata?.downloadTarget || isGenericTitle) || isTikTok && !this.item.metadata?.directStreamUrl && !this.item.metadata?.downloadTarget || isCloudStorage && (isGenericTitle || !this.item.metadata?.directStreamUrl);
        if (needsMandatoryPreAnalysis) {
          try {
            logger.info(`[DownloadJob] Running pre-download metadata analysis for item ${this.item.id}: ${this.item.url}`);
            this.emitThrottledProgress({
              progress: 5,
              downloadedBytes: 0,
              totalBytes: 0,
              speed: "",
              eta: "",
              stageDescription: "Analyzing media information..."
            });
            const freshMeta = await Promise.race([
              isCloudStorage ? metadataAnalyzer.analyzeCloudStorage(this.item.url, 15e3) : metadataAnalyzer.analyzeUrl(this.item.url, 12e3),
              new Promise((_, reject) => setTimeout(() => reject(new Error("Pre-analysis timeout")), 15e3))
            ]);
            if (freshMeta) {
              this.item.metadata = { ...this.item.metadata || {}, ...freshMeta };
              if (freshMeta.title && !/^video by /i.test(freshMeta.title) && freshMeta.title.toLowerCase() !== "media") {
                this.item.title = freshMeta.title;
              }
              if (freshMeta.thumbnail && !this.item.thumbnail) {
                this.item.thumbnail = freshMeta.thumbnail;
              }
              if (freshMeta.duration && !this.item.duration) {
                this.item.duration = freshMeta.duration;
              }
              this.emitThrottledProgress({
                progress: 8,
                stageDescription: `Found: ${this.item.title || "media"}`
              });
            }
          } catch (metaErr) {
            logger.warn(`[DownloadJob] Pre-download metadata analysis notice for ${this.item.url}:`, metaErr.message);
            if ((isSpotify || isAppleMusic) && !this.item.metadata?.downloadQuery && isGenericTitle) {
              throw metaErr;
            }
          }
        }
        let downloadTarget = this.item.metadata?.downloadQuery || this.item.metadata?.downloadTarget || this.item.metadata?.directStreamUrl || this.item.url;
        const isGoogleDrive = Boolean(
          typeof this.item.url === "string" && this.item.url.includes("drive.google.com") || typeof downloadTarget === "string" && downloadTarget.includes("drive.google.com")
        );
        if (isGoogleDrive) {
          const dUrl = typeof downloadTarget === "string" && downloadTarget.includes("drive.google.com") ? downloadTarget : this.item.url;
          const dMatch = dUrl.match(/\/d\/([a-zA-Z0-9_-]+)/) || dUrl.match(/id=([a-zA-Z0-9_-]+)/);
          if (dMatch && dMatch[1]) {
            downloadTarget = `https://drive.usercontent.google.com/download?id=${dMatch[1]}&export=download`;
          }
        } else if (typeof downloadTarget === "string" && downloadTarget.includes("dropbox.com")) {
          downloadTarget = downloadTarget.replace("dl=0", "dl=1");
          if (!downloadTarget.includes("dl=1")) {
            downloadTarget += (downloadTarget.includes("?") ? "&" : "?") + "dl=1";
          }
        }
        const isYouTube = Boolean(
          typeof this.item.url === "string" && (this.item.url.includes("youtube.com") || this.item.url.includes("youtu.be")) || typeof downloadTarget === "string" && (downloadTarget.includes("youtube.com") || downloadTarget.includes("youtu.be") || downloadTarget.includes("googlevideo.com")) || this.item.metadata?.extractor && String(this.item.metadata.extractor).toLowerCase().includes("youtube")
        );
        if (isYouTube) {
          downloadTarget = this.item.url || this.item.metadata?.webpage_url || (downloadTarget.includes("googlevideo.com") ? this.item.url : downloadTarget);
        }
        if (isSpotify || isAppleMusic) {
          if (this.item.metadata?.downloadQuery) {
            downloadTarget = this.item.metadata.downloadQuery;
          } else {
            const qTitle = !isGenericTitle && this.item.title ? this.item.title : this.item.metadata?.title || "song";
            const qArtist = this.item.metadata?.uploader || this.item.metadata?.channel || "";
            downloadTarget = `ytsearch1:${qTitle} ${qArtist} audio`.trim();
          }
        } else if (isThreads && this.item.metadata?.directStreamUrl) {
          downloadTarget = this.item.metadata.directStreamUrl;
        } else if (isPinterest) {
          if (this.item.profile?.type === "image" && (this.item.metadata?.directImageUrl || this.item.metadata?.thumbnail || this.item.metadata?.directStreamUrl)) {
            downloadTarget = this.item.metadata.directImageUrl || this.item.metadata.thumbnail || this.item.metadata.directStreamUrl;
          } else if (this.item.metadata?.directVideoUrl) {
            downloadTarget = this.item.metadata.directVideoUrl;
          } else if (this.item.metadata?.directStreamUrl) {
            downloadTarget = this.item.metadata.directStreamUrl;
          }
        } else if (isBehance && (this.item.metadata?.downloadTarget || this.item.metadata?.directStreamUrl || this.item.metadata?.items?.[0]?.downloadTarget)) {
          downloadTarget = this.item.metadata.downloadTarget || this.item.metadata.directStreamUrl || this.item.metadata.items && this.item.metadata.items[0]?.downloadTarget || this.item.metadata.items && this.item.metadata.items[0]?.url || this.item.url;
        } else if (isDribbble && (this.item.metadata?.directStreamUrl || this.item.metadata?.downloadTarget)) {
          downloadTarget = this.item.metadata.directStreamUrl || this.item.metadata.downloadTarget;
        } else if (isFiverr && (this.item.metadata?.directStreamUrl || this.item.metadata?.downloadTarget)) {
          downloadTarget = this.item.metadata.directStreamUrl || this.item.metadata.downloadTarget;
        } else if (isArtStation && (this.item.metadata?.directStreamUrl || this.item.metadata?.downloadTarget)) {
          downloadTarget = this.item.metadata.directStreamUrl || this.item.metadata.downloadTarget;
        } else if (isTikTok) {
          if (this.item.profile?.type === "audio" && (this.item.metadata?.directAudioUrl || this.item.metadata?.formats?.find((f) => f.isAudioOnly)?.url)) {
            downloadTarget = this.item.metadata.directAudioUrl || this.item.metadata.formats.find((f) => f.isAudioOnly).url;
          } else if (this.item.profile?.type === "image" && (this.item.metadata?.thumbnail || this.item.metadata?.directStreamUrl)) {
            downloadTarget = this.item.metadata.thumbnail || this.item.metadata.directStreamUrl;
          } else {
            const reqQuality = String(this.item.profile?.quality || this.item.profile?.resolution || "");
            const matchingFmt = Array.isArray(this.item.metadata?.formats) && this.item.metadata.formats.find(
              (f) => reqQuality && (f.quality === reqQuality || f.resolution?.includes(reqQuality)) || reqQuality === "720" && f.formatId === "tiktok_sd_nowm" || reqQuality === "1080" && f.formatId === "tiktok_hd_nowm"
            );
            downloadTarget = matchingFmt?.url || this.item.metadata?.directStreamUrl || this.item.metadata?.downloadTarget || downloadTarget;
          }
          if (typeof downloadTarget === "string" && (downloadTarget.includes("tiktok.com/") || downloadTarget.includes("vm.tiktok.com") || downloadTarget.includes("vt.tiktok.com")) && !downloadTarget.includes("tiktokcdn")) {
            try {
              logger.info(`[DownloadJob] Resolving raw TikTok web URL into direct CDN stream: ${downloadTarget}`);
              const resolvedMeta = await metadataAnalyzer.analyzeTikTok(downloadTarget);
              if (resolvedMeta) {
                this.item.metadata = { ...this.item.metadata || {}, ...resolvedMeta };
                if (this.item.profile?.type === "audio" && resolvedMeta.directAudioUrl) {
                  downloadTarget = resolvedMeta.directAudioUrl;
                } else if (this.item.profile?.type === "image" && (resolvedMeta.thumbnail || resolvedMeta.directStreamUrl)) {
                  downloadTarget = resolvedMeta.thumbnail || resolvedMeta.directStreamUrl;
                } else {
                  const reqQ = String(this.item.profile?.quality || this.item.profile?.resolution || "");
                  const fmt = resolvedMeta.formats?.find((f) => reqQ && (f.quality === reqQ || f.resolution?.includes(reqQ)));
                  downloadTarget = fmt?.url || resolvedMeta.directStreamUrl || resolvedMeta.downloadTarget || downloadTarget;
                }
              }
            } catch (resErr) {
              logger.warn("[DownloadJob] Failed to resolve raw TikTok web URL:", resErr.message);
            }
          }
        }
        const isUpcoming = Boolean(this.item.metadata?.isUpcoming || this.item.metadata?.liveStatus === "is_upcoming");
        if (isUpcoming) {
          if (!this.item.profile) this.item.profile = {};
          this.item.profile.type = "image";
          downloadTarget = this.item.metadata?.thumbnail || this.item.metadata?.directStreamUrl || downloadTarget;
        }
        const isExplicitVideoOrAudio = this.item.profile?.type === "video" || this.item.profile?.type === "audio" || this.item.profile?.type === "video-only" || ["mp4", "mov", "mkv", "webm", "mp3", "wav", "m4a", "flac"].includes((this.item.profile?.container || "").toLowerCase());
        const isImageFile = !isExplicitVideoOrAudio && Boolean(
          isUpcoming || this.item.profile?.type === "image" || this.item.metadata?.mediaType === "image" || this.item.metadata?.isImage || typeof this.item.title === "string" && /\.(jpg|jpeg|png|webp|gif|bmp|svg|tiff)($|\?)/i.test(this.item.title) || typeof downloadTarget === "string" && downloadTarget.startsWith("http") && (/\.(jpg|jpeg|png|webp|gif|bmp|svg|tiff)($|\?)/i.test(downloadTarget) && !downloadTarget.includes(".mp4") || downloadTarget.includes("pbs.twimg.com") && !downloadTarget.includes(".mp4") && !downloadTarget.includes("video.twimg.com") || /[?&]format=(jpg|jpeg|png|webp)/i.test(downloadTarget) && !downloadTarget.includes("video.twimg.com") && !downloadTarget.includes(".mp4"))
        );
        if (isImageFile) {
          let imgTarget = downloadTarget;
          const allUrls = `${this.item.url || ""} ${downloadTarget || ""}`;
          const ytM = allUrls.match(/(?:v=|shorts\/|youtu\.be\/|embed\/|\/vi\/|\/live\/)([a-zA-Z0-9_-]{11})/);
          const ytId = ytM && ytM[1] || (this.item.metadata?.extractor?.includes("youtube") && this.item.metadata?.id && this.item.metadata.id.length === 11 ? this.item.metadata.id : null);
          if (typeof downloadTarget === "string" && downloadTarget.includes("pbs.twimg.com")) {
            imgTarget = downloadTarget.replace(/name=[a-z0-9]+/i, "name=orig").replace(/format=webp/i, "format=jpg");
          } else if (isUpcoming) {
            imgTarget = (ytId ? `https://i.ytimg.com/vi/${ytId}/maxresdefault.jpg` : null) || this.item.metadata?.thumbnail || this.item.metadata?.directStreamUrl || downloadTarget;
          } else if (this.item.profile?.type === "image" && ytId) {
            imgTarget = `https://i.ytimg.com/vi/${ytId}/maxresdefault.jpg`;
          }
          logger.info(`[DownloadJob] Direct image download for item ${this.item.id}: ${imgTarget}`);
          let ext = "jpg";
          const titleExtMatch = (this.item.title || "").match(/\.(jpg|jpeg|png|webp|gif|bmp|svg|tiff)($|\?)/i);
          const urlExtMatch = typeof downloadTarget === "string" ? downloadTarget.match(/\.(jpg|jpeg|png|webp|gif|bmp|svg|tiff)($|\?)/i) : null;
          const formatParamMatch = typeof downloadTarget === "string" ? downloadTarget.match(/[?&]format=(jpg|jpeg|png|webp|gif)/i) : null;
          if (titleExtMatch) {
            ext = titleExtMatch[1].toLowerCase();
          } else if (urlExtMatch) {
            ext = urlExtMatch[1].toLowerCase();
          } else if (formatParamMatch) {
            ext = formatParamMatch[1].toLowerCase() === "webp" ? "jpg" : formatParamMatch[1].toLowerCase();
          } else if (this.item.profile?.container && ["jpg", "jpeg", "png", "webp", "gif", "bmp", "svg"].includes(this.item.profile.container.toLowerCase())) {
            ext = this.item.profile.container.toLowerCase();
          }
          let cleanCandidate = !isGenericTitle && this.item.title ? this.item.title : this.item.metadata?.title || "image";
          if (cleanCandidate.toLowerCase().startsWith("fetching media info") || /^google drive file/i.test(cleanCandidate)) {
            if (this.item.metadata?.title && !this.item.metadata.title.toLowerCase().startsWith("fetching media info") && !/^google drive file/i.test(this.item.metadata.title)) {
              cleanCandidate = this.item.metadata.title;
            }
          }
          if (titleExtMatch) {
            cleanCandidate = cleanCandidate.replace(/\.(jpg|jpeg|png|webp|gif|bmp|svg|tiff)($|\?)/i, "");
          }
          const cleanTitle = filesystemManager.sanitizeFilename(cleanCandidate).substring(0, 100);
          const finalName = `${cleanTitle}.${ext}`;
          const tempImgPath = import_path8.default.join(stagingDir, `${this.item.id}__MF__${cleanTitle}.${ext}`);
          const fallbacks = [];
          if (ytId) {
            fallbacks.push(`https://i.ytimg.com/vi/${ytId}/hq720.jpg`);
            if (this.item.metadata?.thumbnail && !this.item.metadata.thumbnail.includes("maxresdefault.jpg")) {
              fallbacks.push(this.item.metadata.thumbnail);
            }
            fallbacks.push(`https://i.ytimg.com/vi/${ytId}/hqdefault.jpg`);
          }
          this.emitThrottledProgress({
            progress: 10,
            downloadedBytes: 0,
            totalBytes: 0,
            speed: "",
            eta: "",
            stageDescription: "Downloading image file..."
          });
          let dlResult = null;
          try {
            dlResult = await this.downloadDirectStream(imgTarget, tempImgPath);
          } catch (streamErr) {
            try {
              if (import_fs8.default.existsSync(tempImgPath)) import_fs8.default.unlinkSync(tempImgPath);
            } catch (_) {
            }
            let downloadedOk = false;
            for (const fb of fallbacks) {
              try {
                dlResult = await this.downloadDirectStream(fb, tempImgPath);
                downloadedOk = true;
                break;
              } catch (_) {
                try {
                  if (import_fs8.default.existsSync(tempImgPath)) import_fs8.default.unlinkSync(tempImgPath);
                } catch (_2) {
                }
              }
            }
            if (!downloadedOk) {
              throw streamErr;
            }
          }
          let finalCandidate = cleanCandidate;
          if (dlResult && dlResult.serverFilename) {
            const sExt = import_path8.default.extname(dlResult.serverFilename).replace(".", "").toLowerCase();
            if (sExt && ["jpg", "jpeg", "png", "webp", "gif", "bmp", "svg", "tiff"].includes(sExt)) {
              ext = sExt;
            }
            const sBase = import_path8.default.basename(dlResult.serverFilename, import_path8.default.extname(dlResult.serverFilename));
            if (sBase) {
              finalCandidate = sBase;
              this.item.title = dlResult.serverFilename;
            }
          }
          const finalCleanTitle = filesystemManager.sanitizeFilename(finalCandidate).substring(0, 100);
          const actualFinalName = `${finalCleanTitle}.${ext}`;
          let actualTempImgPath = tempImgPath;
          const expectedTempPath = import_path8.default.join(stagingDir, `${this.item.id}__MF__${finalCleanTitle}.${ext}`);
          if (actualTempImgPath !== expectedTempPath && import_fs8.default.existsSync(actualTempImgPath)) {
            try {
              import_fs8.default.renameSync(actualTempImgPath, expectedTempPath);
              actualTempImgPath = expectedTempPath;
            } catch (_) {
            }
          }
          const effectiveTargetDir = this.resolveFinalTargetDir(targetDir, ext, "image");
          const finalized = filesystemManager.finalizeDownloadedFile(actualTempImgPath, effectiveTargetDir, actualFinalName);
          this.item.downloadedPath = finalized.finalPath;
          return finalized;
        }
        const isDirectArchive = this.item.profile?.type === "archive" || typeof downloadTarget === "string" && downloadTarget.startsWith("http") && downloadTarget.match(/\.(zip|rar|7z|tar|gz)($|\?)/i);
        if (isDirectArchive) {
          logger.info(`[DownloadJob] Direct archive download for item ${this.item.id}: ${downloadTarget}`);
          let cleanCandidate = !isGenericTitle && this.item.title ? this.item.title : this.item.metadata?.title || "cloud_archive";
          let extMatch = downloadTarget.match(/\.(zip|rar|7z|tar|gz)($|\?)/i);
          let ext = extMatch ? extMatch[1].toLowerCase() : "zip";
          const cleanTitle = filesystemManager.sanitizeFilename(cleanCandidate).substring(0, 80);
          const tempArchiveFile = import_path8.default.join(stagingDir, `${this.item.id}__MF__${cleanTitle}.${ext}`);
          const dlResult = await this.downloadDirectStream(downloadTarget, tempArchiveFile);
          let archFinalTitle = cleanTitle;
          if (dlResult && dlResult.serverFilename) {
            const sExt = import_path8.default.extname(dlResult.serverFilename).replace(".", "").toLowerCase();
            if (sExt && ["zip", "rar", "7z", "tar", "gz"].includes(sExt)) {
              ext = sExt;
            }
            const sBase = import_path8.default.basename(dlResult.serverFilename, import_path8.default.extname(dlResult.serverFilename));
            if (sBase) {
              archFinalTitle = filesystemManager.sanitizeFilename(sBase).substring(0, 80);
              this.item.title = dlResult.serverFilename;
            }
          }
          let actualTempArchive = tempArchiveFile;
          const expectedArchive = import_path8.default.join(stagingDir, `${this.item.id}__MF__${archFinalTitle}.${ext}`);
          if (actualTempArchive !== expectedArchive && import_fs8.default.existsSync(actualTempArchive)) {
            try {
              import_fs8.default.renameSync(actualTempArchive, expectedArchive);
              actualTempArchive = expectedArchive;
            } catch (_) {
            }
          }
          const effectiveTargetDir = targetDir;
          const finalized = filesystemManager.finalizeDownloadedFile(actualTempArchive, effectiveTargetDir, `${archFinalTitle}.${ext}`);
          this.item.downloadedPath = finalized.finalPath;
          return finalized;
        }
        const isDirectVideoStream = !isSpotify && !isYouTube && this.item.profile?.type !== "audio" && this.item.profile?.type !== "image" && (this.item.profile?.type === "video" || this.item.profile?.type === "video-only" || this.item.metadata?.mediaType === "video" || this.item.metadata?.hasVideo) && !String(downloadTarget).includes(".m3u8") && Boolean(
          this.item.metadata?.directStreamUrl && !this.item.metadata.directStreamUrl.includes("youtube.com") && !this.item.metadata.directStreamUrl.includes("youtu.be") && !this.item.metadata.directStreamUrl.includes("googlevideo.com") && !this.item.metadata.directStreamUrl.includes("tiktok.com/") || typeof downloadTarget === "string" && downloadTarget.startsWith("http") && !downloadTarget.includes("tiktok.com/") && (downloadTarget.includes("fbcdn.net") || downloadTarget.includes("cdninstagram.com") || downloadTarget.includes("twimg.com") || downloadTarget.includes("licdn.com") || downloadTarget.includes("tiktokcdn") || downloadTarget.includes("tikwm") || downloadTarget.includes("tikmate") || downloadTarget.includes("drive.google.com") || downloadTarget.includes("drive.usercontent.google.com") || downloadTarget.match(/\.(mp4|mov|mkv|webm|avi|m4v)($|\?)/i) && !downloadTarget.includes("googlevideo.com") && !downloadTarget.includes("youtube.com") && !downloadTarget.includes("youtu.be"))
        );
        if (isDirectVideoStream) {
          logger.info(`[DownloadJob] Direct video stream download for item ${this.item.id}: ${downloadTarget}`);
          let cleanCandidate = !isGenericTitle && this.item.title ? this.item.title : this.item.metadata?.title || "video_stream";
          const cleanTitle = filesystemManager.sanitizeFilename(cleanCandidate).substring(0, 80);
          const rawExtMatch = typeof downloadTarget === "string" ? (this.item.title || downloadTarget).match(/\.(mp4|mov|mkv|webm|avi|m4v)($|\?)/i) : null;
          let streamExt = rawExtMatch ? rawExtMatch[1].toLowerCase() : "mp4";
          const tempStreamFile = import_path8.default.join(stagingDir, `${this.item.id}__MF__${cleanTitle}.${streamExt}`);
          const dlResult = await this.downloadDirectStream(downloadTarget, tempStreamFile);
          let streamFinalTitle = cleanTitle;
          if (dlResult && dlResult.serverFilename) {
            const sExt = import_path8.default.extname(dlResult.serverFilename).replace(".", "").toLowerCase();
            if (sExt && ["mp4", "mov", "mkv", "webm", "avi", "m4v", "flv"].includes(sExt)) {
              streamExt = sExt;
            }
            const sBase = import_path8.default.basename(dlResult.serverFilename, import_path8.default.extname(dlResult.serverFilename));
            if (sBase) {
              streamFinalTitle = filesystemManager.sanitizeFilename(sBase).substring(0, 80);
              this.item.title = dlResult.serverFilename;
            }
          }
          let actualTempFile = tempStreamFile;
          const expectedTempFile = import_path8.default.join(stagingDir, `${this.item.id}__MF__${streamFinalTitle}.${streamExt}`);
          if (actualTempFile !== expectedTempFile && import_fs8.default.existsSync(actualTempFile)) {
            try {
              import_fs8.default.renameSync(actualTempFile, expectedTempFile);
              actualTempFile = expectedTempFile;
            } catch (_) {
            }
          }
          return await this.processAndFinalizeDownloadedFile(actualTempFile, stagingDir, targetDir, ffmpegPath, ffprobePath, binDir, streamFinalTitle);
        }
        const isDirectAudioStream = !isSpotify && !isYouTube && this.item.profile?.type === "audio" && Boolean(
          typeof downloadTarget === "string" && downloadTarget.startsWith("http") && (downloadTarget.includes("tiktokcdn") || downloadTarget.includes("tikwm") || isTikTok && this.item.profile?.type === "audio" || downloadTarget.includes("drive.google.com") || downloadTarget.includes("drive.usercontent.google.com") || downloadTarget.match(/\.(mp3|wav|m4a|aac|flac|ogg|mp4|mov|mkv|webm|avi|m4v)($|\?)/i) && !downloadTarget.includes("googlevideo.com") && !downloadTarget.includes("youtube.com") && !downloadTarget.includes("youtu.be"))
        );
        if (isDirectAudioStream) {
          logger.info(`[DownloadJob] Direct audio stream download for item ${this.item.id}: ${downloadTarget}`);
          const cleanCandidate = !isGenericTitle && this.item.title ? this.item.title : this.item.metadata?.title || "audio_stream";
          const cleanTitle = filesystemManager.sanitizeFilename(cleanCandidate).substring(0, 80);
          const rawExtMatch = typeof downloadTarget === "string" ? (this.item.title || downloadTarget).match(/\.(mp3|wav|m4a|aac|flac|ogg|mp4|mov)($|\?)/i) : null;
          const streamExt = rawExtMatch ? rawExtMatch[1].toLowerCase() : this.item.metadata?.mediaType === "video" ? "mp4" : "mp3";
          const tempStreamFile = import_path8.default.join(stagingDir, `${this.item.id}__MF__${cleanTitle}.${streamExt}`);
          await this.downloadDirectStream(downloadTarget, tempStreamFile);
          return await this.processAndFinalizeDownloadedFile(tempStreamFile, stagingDir, targetDir, ffmpegPath, ffprobePath, binDir, cleanTitle);
        }
        const hasValidTitle = !isGenericTitle && this.item.title && this.item.title !== "Fetching media info...";
        const cleanTitleCandidate = hasValidTitle ? this.item.title : this.item.metadata?.title && !/^video by /i.test(this.item.metadata.title) && this.item.metadata.title.toLowerCase() !== "media" && !/^media[\._]/i.test(this.item.metadata.title) ? this.item.metadata.title : "";
        const safeTitlePart = cleanTitleCandidate ? filesystemManager.sanitizeFilename(cleanTitleCandidate).substring(0, 80) : "";
        const stagingTemplate = safeTitlePart ? import_path8.default.join(stagingDir, `${this.item.id}__MF__${safeTitlePart}.%(ext)s`) : import_path8.default.join(stagingDir, `${this.item.id}__MF__%(title).80s.%(ext)s`);
        const ffmpegLocation = ffmpegPath ? import_path8.default.dirname(ffmpegPath) : void 0;
        const searchTargets = [downloadTarget];
        const ytMatch = downloadTarget.match(/(?:v=|\/shorts\/|\/embed\/|youtu\.be\/|\/v\/|\/e\/)([\w-]{11})/);
        if (ytMatch && ytMatch[1] && !downloadTarget.includes("youtube.com") && !downloadTarget.includes("youtu.be")) {
          const vidSearch = `ytsearch1:${ytMatch[1]}`;
          if (!searchTargets.includes(vidSearch)) {
            searchTargets.push(vidSearch);
          }
        }
        const rawCandidateTitle = !isGenericTitle && this.item.title ? this.item.title : this.item.metadata?.title || "";
        const cleanT = rawCandidateTitle.replace(/\s*[-â€“]\s*.*$/, "").replace(/[\\/:*?"<>|]/g, "").replace(/\s+/g, " ").trim();
        const candidateArtist = this.item.metadata?.uploader || this.item.metadata?.channel || "";
        if (cleanT && cleanT.length > 2 && (isSpotify || this.item.isPlaylist || this.item.metadata?.isPlaylist || this.item.batchId || this.item.metadata?.batchId)) {
          const primaryArtist = candidateArtist.split(/[,;&/]|feat\.?|ft\.?/i)[0].trim();
          const strippedTitle = cleanT.replace(/\s*[\(\[][^\)\]]*[\)\]]/g, "").trim();
          const asciiTitle = cleanT.normalize("NFKD").replace(/[\u0300-\u036f]/g, "").replace(/[^\x20-\x7E]/g, " ").replace(/\s+/g, " ").trim();
          const asciiPrimary = primaryArtist.normalize("NFKD").replace(/[\u0300-\u036f]/g, "").replace(/[^\x20-\x7E]/g, " ").replace(/\s+/g, " ").trim();
          if (asciiPrimary) {
            const alt1 = `ytsearch1:${asciiTitle} ${asciiPrimary}`.trim();
            if (!searchTargets.includes(alt1)) searchTargets.push(alt1);
          }
          if (strippedTitle && strippedTitle.length > 2 && asciiPrimary) {
            const altStr = `ytsearch1:${strippedTitle} ${asciiPrimary}`.trim();
            if (!searchTargets.includes(altStr)) searchTargets.push(altStr);
          }
          if (candidateArtist && candidateArtist !== primaryArtist) {
            const alt2 = `ytsearch1:${asciiTitle} ${candidateArtist}`.trim();
            if (!searchTargets.includes(alt2)) searchTargets.push(alt2);
          }
          const alt3 = `ytsearch1:${asciiTitle} audio`.trim();
          if (!searchTargets.includes(alt3)) searchTargets.push(alt3);
          const alt4 = `ytsearch1:${asciiTitle}`.trim();
          if (!searchTargets.includes(alt4)) searchTargets.push(alt4);
          if (strippedTitle && strippedTitle.length > 2) {
            const alt5 = `ytsearch1:${strippedTitle}`.trim();
            if (!searchTargets.includes(alt5)) searchTargets.push(alt5);
          }
        }
        if (youtubeTokenManager.isYouTubeUrl(downloadTarget) || this.item.url && youtubeTokenManager.isYouTubeUrl(this.item.url)) {
          await youtubeTokenManager.getVisitorData().catch(() => {
          });
        }
        return new Promise((resolve, reject) => {
          const executeDownload = (targetIndex = 0, skipCookies = false) => {
            filesystemManager.ensureDirExists(stagingDir);
            if (this.isCancelled) {
              this.cleanupStagingFiles(stagingDir, this.item.id);
              return reject({ isCancelled: true });
            }
            if (this.isPaused) {
              return reject({ isPaused: true });
            }
            const currentTarget = searchTargets[targetIndex];
            const args = this.buildYtDlpArgs(currentTarget, this.item.profile, stagingTemplate, ffmpegLocation, skipCookies);
            logger.info(`[DownloadJob] Starting download for item ${this.item.id}: ${currentTarget}`);
            logger.debug("[DownloadJob] yt-dlp args:", args);
            let stdoutBuf = "";
            let stderrBuf = "";
            let watchdogTimer;
            try {
              this.childProcess = (0, import_child_process3.spawn)(ytdlpPath, args, {
                windowsHide: true,
                stdio: ["ignore", "pipe", "pipe"]
              });
              try {
                if (this.childProcess.pid && typeof import_os8.default.setPriority === "function") {
                  import_os8.default.setPriority(this.childProcess.pid, import_os8.default.constants.priority.PRIORITY_BELOW_NORMAL);
                }
              } catch (_) {
              }
              const resetWatchdog2 = () => {
                if (watchdogTimer) clearTimeout(watchdogTimer);
                watchdogTimer = setTimeout(() => {
                  logger.warn(`[DownloadJob] Inactivity watchdog timeout (300s) for item ${this.item.id} on query "${currentTarget}". Terminating stalled process...`);
                  if (this.childProcess) {
                    const pid = this.childProcess.pid;
                    if (process.platform === "win32" && pid) {
                      try {
                        const { exec } = require("child_process");
                        exec(`taskkill /pid ${pid} /T /F`, { windowsHide: true }, () => {
                        });
                      } catch (_) {
                        try {
                          this.childProcess.kill("SIGKILL");
                        } catch (_2) {
                        }
                      }
                    } else {
                      try {
                        this.childProcess.kill("SIGKILL");
                      } catch (_) {
                      }
                    }
                  }
                }, 3e5);
              };
              resetWatchdog2();
              const initialStage = this.item.profile?.timeRange && (this.item.profile.timeRange.start || this.item.profile.timeRange.end) ? `Preparing clip (${this.item.profile.timeRange.start || "00:00:00"} - ${this.item.profile.timeRange.end || "end"}) - Seeking stream...` : "Connecting to media server...";
              this.emitThrottledProgress({
                progress: 1,
                downloadedBytes: 0,
                totalBytes: 0,
                speed: "",
                eta: "",
                stageDescription: initialStage
              });
            } catch (err) {
              if (watchdogTimer) clearTimeout(watchdogTimer);
              return reject(classifyError(err, "Failed to launch yt-dlp"));
            }
            this.childProcess.stdout?.on("data", (chunk) => {
              if (typeof resetWatchdog === "function") resetWatchdog();
              const text = chunk.toString("utf-8");
              stdoutBuf += text;
              this.parseStdout(text);
            });
            this.childProcess.stderr?.on("data", (chunk) => {
              if (typeof resetWatchdog === "function") resetWatchdog();
              const text = chunk.toString("utf-8");
              stderrBuf += text;
              this.parseStderr(text);
            });
            this.childProcess.on("error", (err) => {
              if (watchdogTimer) clearTimeout(watchdogTimer);
              logger.error(`[DownloadJob] Process error for item [${this.item.id}]:`, err);
              reject(classifyError(err));
            });
            this.childProcess.on("close", async (code) => {
              if (watchdogTimer) {
                clearTimeout(watchdogTimer);
                watchdogTimer = void 0;
              }
              this.childProcess = void 0;
              if (this.isPaused) {
                logger.info(`[DownloadJob] Item ${this.item.id} paused.`);
                return reject({ isPaused: true });
              }
              if (this.isCancelled) {
                logger.info(`[DownloadJob] Item ${this.item.id} cancelled.`);
                this.cleanupStagingFiles(stagingDir, this.item.id);
                return reject({ isCancelled: true });
              }
              const stagingResult = this.findStagingFile(stagingDir, this.item.id);
              if (stagingResult && stagingResult.filePath) {
                try {
                  const finalized = await this.processAndFinalizeDownloadedFile(
                    stagingResult.filePath,
                    stagingDir,
                    targetDir,
                    ffmpegPath,
                    ffprobePath,
                    binDir,
                    stagingResult.extractedTitle
                  );
                  resolve(finalized);
                  return;
                } catch (finErr) {
                  this.cleanupStagingFiles(stagingDir, this.item.id);
                  reject(classifyError(finErr, "Failed to process downloaded file"));
                  return;
                }
              } else {
                const combinedOut = ((stderrBuf || "") + " " + (stdoutBuf || "")).toLowerCase();
                const isCookieError = combinedOut.includes("the page needs to be reloaded") || combinedOut.includes("confirm you\xE2\u20AC\u2122re not a robot") || combinedOut.includes("failed to parse json") || combinedOut.includes("failed to decrypt") || combinedOut.includes("dpapi") || combinedOut.includes("database is locked") || combinedOut.includes("cookie");
                if (!skipCookies && isCookieError) {
                  logger.warn(`[DownloadJob] Cookie error / reload challenge detected for item ${this.item.id}. Retrying cleanly without cookies...`);
                  this.cleanupStagingFiles(stagingDir, this.item.id);
                  return executeDownload(targetIndex, true);
                }
                const isPermanentFail = combinedOut.includes("video unavailable") || combinedOut.includes("this video is unavailable") || combinedOut.includes("private video") || combinedOut.includes("sign in to confirm");
                if (!isPermanentFail && this.downloadedWithSections && !this.retriedWithoutSections) {
                  this.retriedWithoutSections = true;
                  this.downloadedWithSections = false;
                  this.cleanupStagingFiles(stagingDir, this.item.id);
                  logger.info(`[DownloadJob] Tier 1 trim failed for "${currentTarget}". Attempting Tier 2: direct stream URLs via yt-dlp -g + ffmpeg -ss -to...`);
                  this.emitThrottledProgress({
                    progress: 5,
                    downloadedBytes: 0,
                    totalBytes: 0,
                    speed: "",
                    eta: "",
                    stageDescription: "Connecting to direct stream range..."
                  });
                  try {
                    const ytdlpPath2 = await dependencyManager.getYtDlpExecutablePath();
                    const nodeBin = dependencyManager.getNodeExecutablePath();
                    const jsRuntime = nodeBin === "node" || !nodeBin ? "node" : `node:${nodeBin}`;
                    const gArgs = [
                      "--no-playlist",
                      "--no-check-certificates",
                      "--no-warnings",
                      "--skip-download",
                      "--js-runtimes",
                      jsRuntime,
                      "-g"
                    ];
                    if (this.item.profile?.customFormatId) {
                      gArgs.push("-f", this.item.profile.customFormatId);
                    } else if (this.item.profile?.type === "audio") {
                      gArgs.push("-f", "bestaudio/best");
                    } else {
                      gArgs.push("-f", "bestvideo+bestaudio/best");
                    }
                    const localAppData = process.env.LOCALAPPDATA || (import_os8.default.homedir ? import_path8.default.join(import_os8.default.homedir(), "AppData", "Local") : "");
                    const cookiesFilePath = localAppData ? import_path8.default.join(localAppData, "MediaFetch", "cookies.txt") : "";
                    if (cookiesFilePath && import_fs8.default.existsSync(cookiesFilePath) && import_fs8.default.statSync(cookiesFilePath).size > 10) {
                      gArgs.push("--cookies", cookiesFilePath);
                    }
                    gArgs.push(currentTarget);
                    let gOut;
                    try {
                      const res = await execFileAsync3(ytdlpPath2, gArgs, { windowsHide: true, timeout: 25e3 });
                      gOut = res.stdout;
                    } catch (gErr) {
                      if (gArgs.includes("--cookies")) {
                        logger.warn(`[DownloadJob] Tier 2 stream extraction failed with cookies. Retrying without cookies...`);
                        const cleanGArgs = gArgs.filter((a, idx) => a !== "--cookies" && gArgs[idx - 1] !== "--cookies");
                        const res = await execFileAsync3(ytdlpPath2, cleanGArgs, { windowsHide: true, timeout: 25e3 });
                        gOut = res.stdout;
                      } else {
                        throw gErr;
                      }
                    }
                    const streamUrls = (gOut || "").trim().split(/\r?\n/).filter((u) => u.startsWith("http"));
                    if (streamUrls.length > 0 && ffmpegPath && import_fs8.default.existsSync(ffmpegPath)) {
                      filesystemManager.ensureDirExists(stagingDir);
                      const isVideoOnly = this.item.profile?.type === "video-only" || this.item.profile?.presetId === "video-only";
                      const isAudioOnly = this.item.profile?.type === "audio" || ["mp3", "wav", "m4a", "flac", "aac", "ogg"].includes((this.item.profile?.container || "").toLowerCase());
                      let start = this.normalizeTime(this.item.profile?.timeRange?.start, "00:00:00");
                      let end = this.normalizeTime(this.item.profile?.timeRange?.end, "99:59:59");
                      const startSec = this.parseTimeToSeconds(start);
                      const endSec = this.parseTimeToSeconds(end);
                      const clipDurSec = endSec > startSec ? endSec - startSec : 300;
                      const rangeTimeoutMs = Math.max(6e4, Math.ceil(clipDurSec * 3e3));
                      const tier2Staging = import_path8.default.join(stagingDir, `${this.item.id}__MF__tier2_${Date.now()}.${(this.item.profile?.container || "mp4").toLowerCase()}`);
                      let ffRangeArgs = ["-y"];
                      const ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
                      const itemUrl = this.item.url || "";
                      for (const sUrl of streamUrls) {
                        let streamReferer = "https://www.youtube.com/";
                        if (itemUrl.includes("x.com") || itemUrl.includes("twitter.com") || sUrl.includes("twimg.com")) {
                          streamReferer = "https://x.com/";
                        } else if (itemUrl.includes("instagram.com") || sUrl.includes("cdninstagram.com")) {
                          streamReferer = "https://www.instagram.com/";
                        } else if (itemUrl.includes("facebook.com") || sUrl.includes("fbcdn.net")) {
                          streamReferer = "https://www.facebook.com/";
                        } else if (itemUrl.includes("tiktok.com") || sUrl.includes("tiktokcdn")) {
                          streamReferer = "https://www.tiktok.com/";
                        } else if (sUrl.includes("googlevideo.com")) {
                          streamReferer = "https://www.youtube.com/";
                        } else if (itemUrl.startsWith("http")) {
                          try {
                            const uObj = new URL(itemUrl);
                            streamReferer = `${uObj.protocol}//${uObj.host}/`;
                          } catch (_) {
                          }
                        }
                        const refHeader = `Referer: ${streamReferer}\r
Origin: ${streamReferer}\r
`;
                        ffRangeArgs.push("-user_agent", ua, "-headers", refHeader, "-ss", start, "-to", end, "-i", sUrl);
                      }
                      if (streamUrls.length === 1) {
                        if (isAudioOnly) {
                          ffRangeArgs.push("-vn", "-c:a", "aac", "-b:a", "192k", "-ar", "48000", tier2Staging);
                        } else {
                          ffRangeArgs.push(
                            ...getOptimalEncoderArgs(ffmpegPath),
                            ...isVideoOnly ? ["-an"] : ["-c:a", "aac", "-b:a", "192k", "-ar", "48000"],
                            "-movflags",
                            "+faststart",
                            tier2Staging
                          );
                        }
                      } else {
                        if (isAudioOnly) {
                          ffRangeArgs.push("-map", "1:a:0?", "-vn", "-c:a", "aac", "-b:a", "192k", "-ar", "48000", tier2Staging);
                        } else {
                          ffRangeArgs.push(
                            "-map",
                            "0:v:0",
                            "-map",
                            "1:a:0?",
                            ...getOptimalEncoderArgs(ffmpegPath),
                            ...isVideoOnly ? ["-an"] : ["-c:a", "aac", "-b:a", "192k", "-ar", "48000"],
                            "-movflags",
                            "+faststart",
                            tier2Staging
                          );
                        }
                      }
                      logger.info(`[DownloadJob] Executing Tier 2 stream trim: ffmpeg ${ffRangeArgs.join(" ")}`);
                      await new Promise((resolveT2, rejectT2) => {
                        const t2Proc = (0, import_child_process3.spawn)(ffmpegPath, ffRangeArgs, { windowsHide: true });
                        const timer = setTimeout(() => {
                          try {
                            t2Proc.kill("SIGKILL");
                          } catch (_) {
                          }
                          rejectT2(new Error("Tier 2 stream trim timed out"));
                        }, rangeTimeoutMs);
                        t2Proc.on("error", (err) => {
                          clearTimeout(timer);
                          rejectT2(err);
                        });
                        t2Proc.on("close", (c) => {
                          clearTimeout(timer);
                          if (c === 0 && import_fs8.default.existsSync(tier2Staging) && import_fs8.default.statSync(tier2Staging).size > 1e3) {
                            resolveT2();
                          } else {
                            rejectT2(new Error(`Tier 2 stream trim exited with code ${c}`));
                          }
                        });
                      });
                      if (import_fs8.default.existsSync(tier2Staging) && import_fs8.default.statSync(tier2Staging).size > 1e3) {
                        logger.info(`[DownloadJob] Tier 2 direct stream range trim succeeded.`);
                        this.downloadedWithTier2 = true;
                        const finalized = await this.processAndFinalizeDownloadedFile(
                          tier2Staging,
                          stagingDir,
                          targetDir,
                          ffmpegPath,
                          ffprobePath,
                          binDir,
                          safeTitlePart
                        );
                        resolve(finalized);
                        return;
                      }
                    }
                  } catch (tier2Err) {
                    logger.warn(`[DownloadJob] Tier 2 trim notice: ${tier2Err.message}. Proceeding to Tier 3 (full download + async local cut)...`);
                  }
                  logger.info(`[DownloadJob] Executing Tier 3: Full file download followed by local async cut...`);
                  filesystemManager.ensureDirExists(stagingDir);
                  return executeDownload(targetIndex);
                }
                if (!isPermanentFail && targetIndex + 1 < searchTargets.length) {
                  this.cleanupStagingFiles(stagingDir, this.item.id);
                  logger.info(`[DownloadJob] Query "${currentTarget}" did not produce a file (exit: ${code}), trying fallback query "${searchTargets[targetIndex + 1]}" (${targetIndex + 2}/${searchTargets.length})...`);
                  return executeDownload(targetIndex + 1);
                }
                this.cleanupStagingFiles(stagingDir, this.item.id);
                const errorMsg = stderrBuf || (code === 0 ? "Downloaded file not found in staging folder." : `yt-dlp exited with code ${code}`);
                logger.warn(`yt-dlp failed after all queries: ${errorMsg}`);
                if (/n challenge|addOnDisposeCallback|\[jsc\]|requested format is not available/i.test(errorMsg)) {
                  dependencyManager.autoRecoverYtDlpIfStale().catch(() => {
                  });
                }
                reject(classifyError(new Error(errorMsg), stderrBuf));
              }
            });
          };
          executeDownload(0);
        });
      }
      downloadDirectStream(streamUrl, stagingFile) {
        return new Promise((resolve, reject) => {
          const download = (targetUrl, redirectCount = 0) => {
            if (redirectCount > 8) return reject(new Error("Too many redirects"));
            let referer = "https://www.google.com/";
            const pageUrl = this.item.url || "";
            try {
              if (pageUrl.includes("x.com") || pageUrl.includes("twitter.com") || targetUrl.includes("twimg.com")) {
                referer = "https://x.com/";
              } else if (pageUrl.includes("instagram.com") || targetUrl.includes("cdninstagram.com")) {
                referer = "https://www.instagram.com/";
              } else if (pageUrl.includes("threads.net") || pageUrl.includes("threads.com")) {
                referer = "https://www.threads.net/";
              } else if (pageUrl.includes("linkedin.com") || targetUrl.includes("licdn.com")) {
                referer = "https://www.linkedin.com/";
              } else if (pageUrl.includes("behance.net") || targetUrl.includes("behance.net") || targetUrl.includes("vimeocdn.com")) {
                referer = "https://www.behance.net/";
              } else if (targetUrl.includes("tiktokcdn") || targetUrl.includes("tikwm") || targetUrl.includes("tikmate") || pageUrl.includes("tiktok.com")) {
                referer = "https://www.tiktok.com/";
              } else if (pageUrl.startsWith("http")) {
                referer = new URL(pageUrl).origin + "/";
              } else {
                const u = new URL(targetUrl);
                referer = u.origin + "/";
              }
            } catch (_) {
            }
            this.emitThrottledProgress({
              progress: 5,
              downloadedBytes: 0,
              totalBytes: 0,
              speed: "",
              eta: "",
              stageDescription: "Connecting to direct media stream..."
            });
            let existingSize = 0;
            if (import_fs8.default.existsSync(stagingFile)) {
              try {
                existingSize = import_fs8.default.statSync(stagingFile).size;
              } catch (_) {
              }
            }
            const client = targetUrl.startsWith("https:") ? import_https3.default : import_http3.default;
            const reqHeaders = {
              "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
              "Referer": referer
            };
            if (existingSize > 0) {
              reqHeaders["Range"] = `bytes=${existingSize}-`;
            }
            const req = client.get(targetUrl, {
              headers: reqHeaders
            }, (res) => {
              if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
                let nextUrl = res.headers.location;
                if (!nextUrl.startsWith("http")) {
                  try {
                    nextUrl = new URL(nextUrl, targetUrl).href;
                  } catch (_) {
                  }
                }
                return download(nextUrl, redirectCount + 1);
              }
              if (res.statusCode !== 200 && res.statusCode !== 206) {
                return reject(new Error(`Direct stream download failed with HTTP status ${res.statusCode}`));
              }
              const ct = (res.headers["content-type"] || "").toLowerCase();
              const cd = res.headers["content-disposition"] || "";
              let serverFilename = "";
              const fnMatch = cd.match(/filename\*?=(?:UTF-8'')?["']?([^"';\r\n]+)["']?/i);
              if (fnMatch) {
                try {
                  serverFilename = decodeURIComponent(fnMatch[1]);
                } catch (_) {
                  serverFilename = fnMatch[1];
                }
              }
              if (ct.includes("text/html")) {
                let htmlChunk = "";
                res.on("data", (c) => {
                  if (htmlChunk.length < 32768) htmlChunk += c.toString("utf8");
                });
                res.on("end", () => {
                  const confirmMatch = htmlChunk.match(/href="([^"]*(?:\/uc\?export=download|drive\.usercontent\.google\.com\/download)[^"]*)"/i) || htmlChunk.match(/action="([^"]*(?:\/uc\?export=download|drive\.usercontent\.google\.com\/download)[^"]*)"/i);
                  if (confirmMatch && redirectCount < 8) {
                    let cUrl = confirmMatch[1].replace(/&amp;/g, "&");
                    if (!cUrl.startsWith("http")) {
                      try {
                        cUrl = new URL(cUrl, targetUrl).href;
                      } catch (_) {
                      }
                    }
                    return download(cUrl, redirectCount + 1);
                  }
                  return reject(new Error("Direct download returned an HTML web page instead of media content. Ensure link permissions allow public downloading."));
                });
                return;
              }
              const isRangeResume = res.statusCode === 206;
              const streamContentLen = parseInt(res.headers["content-length"] || "0", 10);
              const totalBytes = isRangeResume ? existingSize + streamContentLen : streamContentLen;
              this.emitThrottledProgress({
                progress: 8,
                downloadedBytes: isRangeResume ? existingSize : 0,
                totalBytes,
                speed: "",
                eta: "",
                stageDescription: totalBytes > 0 ? `Connected to stream (${(totalBytes / (1024 * 1024)).toFixed(1)} MB)...` : "Connected, receiving media data..."
              });
              let downloaded = isRangeResume ? existingSize : 0;
              const out = import_fs8.default.createWriteStream(stagingFile, {
                flags: isRangeResume ? "a" : "w",
                highWaterMark: 1024 * 1024 * 4
              });
              let lastProgress = Date.now();
              let lastDownloaded = downloaded;
              res.on("data", (chunk) => {
                if (this.isCancelled) {
                  res.destroy();
                  out.close();
                  try {
                    import_fs8.default.unlinkSync(stagingFile);
                  } catch (_) {
                  }
                  return reject({ isCancelled: true });
                }
                if (this.isPaused) {
                  res.destroy();
                  out.close();
                  return reject({ isPaused: true });
                }
                downloaded += chunk.length;
                const now = Date.now();
                if (now - lastProgress > 250) {
                  const deltaBytes = downloaded - lastDownloaded;
                  const deltaTime = (now - lastProgress) / 1e3;
                  const speedBytesPerSec = deltaTime > 0 ? deltaBytes / deltaTime : 0;
                  const speedStr = (speedBytesPerSec / (1024 * 1024)).toFixed(1) + " MB/s";
                  const pct = totalBytes > 0 ? Math.min(90, Math.round(downloaded / totalBytes * 100)) : 50;
                  const isImg = this.item.profile?.type === "image" || this.item.metadata?.mediaType === "image" || this.item.metadata?.isImage;
                  const isAud = this.item.profile?.type === "audio" || this.item.metadata?.mediaType === "audio";
                  const stageDesc = isImg ? "Downloading image file..." : isAud ? "Downloading audio stream..." : "Downloading video stream...";
                  this.emitThrottledProgress({
                    progress: pct,
                    downloadedBytes: downloaded,
                    totalBytes,
                    speed: speedStr,
                    eta: "",
                    stageDescription: stageDesc
                  });
                  lastProgress = now;
                  lastDownloaded = downloaded;
                }
              });
              res.pipe(out);
              out.on("finish", () => {
                out.close();
                this.activeHttpRequest = void 0;
                resolve({ filePath: stagingFile, totalBytes: downloaded, serverFilename, contentType: ct });
              });
              out.on("error", (err) => {
                out.close();
                this.activeHttpRequest = void 0;
                try {
                  import_fs8.default.unlinkSync(stagingFile);
                } catch (_) {
                }
                reject(err);
              });
            });
            this.activeHttpRequest = req;
            req.on("error", (err) => {
              this.activeHttpRequest = void 0;
              try {
                import_fs8.default.unlinkSync(stagingFile);
              } catch (_) {
              }
              reject(err);
            });
          };
          download(streamUrl);
        });
      }
      async processAndFinalizeDownloadedFile(currentStagingFile, stagingDir, targetDir, ffmpegPath, ffprobePath, binDir, extractedTitle) {
        const stagingExt = import_path8.default.extname(currentStagingFile).replace(".", "").toLowerCase();
        let container = (this.item.profile?.container || "mp4").toLowerCase();
        const isAudioOnly = this.item.profile?.type === "audio" || ["mp3", "wav", "m4a", "flac", "aac", "ogg"].includes(container);
        const isVideoOnly = this.item.profile?.type === "video-only" || this.item.profile?.presetId === "video-only";
        let res = 1080;
        if (this.item.profile?.resolution && typeof this.item.profile.resolution === "number" && this.item.profile.resolution > 0) {
          res = this.item.profile.resolution;
        } else if (typeof this.item.profile?.presetId === "string" && this.item.profile.presetId.startsWith("res-")) {
          const parsed = parseInt(this.item.profile.presetId.replace("res-", ""), 10);
          if (!isNaN(parsed) && parsed > 0) res = parsed;
        }
        const isProRes = container === "mov" && (this.item.profile?.label?.includes("ProRes") || this.item.profile?.presetId?.includes("prores"));
        let probedVideoCodec = null;
        if (ffprobePath && !isAudioOnly) {
          probedVideoCodec = await this.probeVideoCodec(currentStagingFile, ffprobePath);
          logger.info(`[DownloadJob] Probed video stream codec: ${probedVideoCodec || "none/unknown"}`);
        }
        let probedAudioCodec = null;
        if (ffprobePath && !isVideoOnly) {
          probedAudioCodec = await this.probeAudioCodec(currentStagingFile, ffprobePath);
          logger.info(`[DownloadJob] Probed audio stream codec: ${probedAudioCodec || "none/unknown"}`);
        }
        const isH264 = probedVideoCodec === "h264" || probedVideoCodec === "avc1";
        const appName = (this.item.projectContext?.application || "").toLowerCase();
        const isAfterEffects = appName.includes("aftereffects") || appName.includes("aeft") || appName.includes("ae");
        const isPremiere = (appName.includes("premiere") || appName.includes("ppro")) && !isAfterEffects;
        if (ffmpegPath && import_fs8.default.existsSync(ffmpegPath)) {
          const processedFile = import_path8.default.join(stagingDir, `proc_${Date.now()}_${this.item.id}.${container}`);
          let ffmpegArgs = [];
          const hasTimeRange = Boolean(!this.downloadedWithSections && !this.downloadedWithTier2 && this.item.profile?.timeRange && (this.item.profile.timeRange.start || this.item.profile.timeRange.end));
          let timeSeekArgs = [];
          if (hasTimeRange) {
            let start = this.normalizeTime(this.item.profile.timeRange.start, "00:00:00");
            let end = this.normalizeTime(this.item.profile.timeRange.end, "99:59:59");
            const startSec = this.parseTimeToSeconds(start);
            const endSec = this.parseTimeToSeconds(end);
            if (endSec > 0 && startSec > endSec) {
              const tmp = start;
              start = end;
              end = tmp;
            }
            timeSeekArgs = ["-ss", start, "-to", end];
          }
          if (isAudioOnly) {
            let targetBitrate = "320k";
            const pId = this.item.profile?.presetId || "";
            const pLbl = this.item.profile?.label || "";
            if (pId === "audio-mp3-128" || pLbl.includes("128")) targetBitrate = "128k";
            else if (pId === "audio-mp3-192" || pLbl.includes("192")) targetBitrate = "192k";
            else if (pId === "audio-mp3-96" || pLbl.includes("96")) targetBitrate = "96k";
            else if (pId === "audio-m4a" || pLbl.includes("256")) targetBitrate = "256k";
            else if (pId === "audio-mp3-320" || pLbl.includes("320")) targetBitrate = "320k";
            if (container === "wav") {
              ffmpegArgs = ["-y", "-i", currentStagingFile, "-vn", "-c:a", "pcm_s16le", "-ar", "48000", processedFile];
            } else if (container === "m4a" || container === "aac") {
              ffmpegArgs = ["-y", "-i", currentStagingFile, "-vn", "-c:a", "aac", "-b:a", targetBitrate, "-ar", "48000", processedFile];
            } else if (container === "flac") {
              ffmpegArgs = ["-y", "-i", currentStagingFile, "-vn", "-c:a", "flac", processedFile];
            } else if (container === "webm") {
              ffmpegArgs = ["-y", "-i", currentStagingFile, "-vn", "-c:a", "libopus", "-b:a", "160k", processedFile];
            } else {
              ffmpegArgs = ["-y", "-i", currentStagingFile, "-vn", "-c:a", "libmp3lame", "-b:a", targetBitrate, "-ar", "44100", processedFile];
            }
          } else if (isVideoOnly) {
            if (container === "webm") {
              if (stagingExt === "webm") {
                ffmpegArgs = ["-y", "-i", currentStagingFile, "-c:v", "copy", "-an", processedFile];
              } else {
                ffmpegArgs = ["-y", "-i", currentStagingFile, "-c:v", "libvpx-vp9", "-b:v", "0", "-crf", "24", "-an", processedFile];
              }
            } else if (container === "mkv") {
              if (stagingExt === "mkv") {
                ffmpegArgs = ["-y", "-i", currentStagingFile, "-c:v", "copy", "-an", processedFile];
              } else {
                ffmpegArgs = ["-y", "-threads", "0", "-i", currentStagingFile, ...getOptimalEncoderArgs(ffmpegPath), "-an", processedFile];
              }
            } else if (container === "mov") {
              if (isH264) {
                ffmpegArgs = ["-y", "-i", currentStagingFile, "-c:v", "copy", "-tag:v", "avc1", "-an", "-movflags", "+faststart", processedFile];
              } else {
                ffmpegArgs = ["-y", "-threads", "0", "-i", currentStagingFile, ...getOptimalEncoderArgs(ffmpegPath), "-tag:v", "avc1", "-an", "-movflags", "+faststart", processedFile];
              }
            } else {
              if (isH264 && stagingExt === "mp4" && !hasTimeRange) {
                ffmpegArgs = ["-y", "-i", currentStagingFile, "-c:v", "copy", "-an", "-movflags", "+faststart", processedFile];
              } else {
                ffmpegArgs = ["-y", "-threads", "0", "-i", currentStagingFile, ...getOptimalEncoderArgs(ffmpegPath), "-an", "-movflags", "+faststart", processedFile];
              }
            }
          } else if (isProRes) {
            ffmpegArgs = [
              "-y",
              "-i",
              currentStagingFile,
              "-c:v",
              "prores_ks",
              "-profile:v",
              "3",
              "-pix_fmt",
              "yuv422p10le",
              "-c:a",
              "pcm_s16le",
              "-ar",
              "48000",
              processedFile
            ];
          } else if (container === "webm") {
            if (stagingExt === "webm") {
              ffmpegArgs = ["-y", "-i", currentStagingFile, "-c", "copy", processedFile];
            } else if (probedVideoCodec === "vp9" || probedVideoCodec === "vp8" || probedVideoCodec === "av01" || probedVideoCodec === "av1") {
              ffmpegArgs = ["-y", "-i", currentStagingFile, "-c:v", "copy", "-c:a", "libopus", "-b:a", "160k", processedFile];
            } else {
              ffmpegArgs = [
                "-y",
                "-i",
                currentStagingFile,
                "-c:v",
                "libvpx-vp9",
                "-b:v",
                "0",
                "-crf",
                "28",
                "-cpu-used",
                "4",
                "-row-mt",
                "1",
                "-c:a",
                "libopus",
                "-b:a",
                "160k",
                processedFile
              ];
            }
          } else if (container === "mkv") {
            if (stagingExt === "mkv") {
              ffmpegArgs = ["-y", "-i", currentStagingFile, "-c", "copy", processedFile];
            } else {
              ffmpegArgs = [
                "-y",
                "-i",
                currentStagingFile,
                ...getOptimalEncoderArgs(ffmpegPath),
                "-pix_fmt",
                "yuv420p",
                "-c:a",
                "aac",
                "-b:a",
                "320k",
                "-ar",
                "48000",
                processedFile
              ];
            }
          } else if (container === "mov") {
            if (isH264 && (stagingExt === "mov" || stagingExt === "mp4")) {
              ffmpegArgs = [
                "-y",
                "-i",
                currentStagingFile,
                "-c:v",
                "copy",
                "-tag:v",
                "avc1",
                "-c:a",
                "aac",
                "-b:a",
                "320k",
                "-ar",
                "48000",
                "-movflags",
                "+faststart",
                processedFile
              ];
            } else if (isH264) {
              ffmpegArgs = [
                "-y",
                "-i",
                currentStagingFile,
                "-c:v",
                "copy",
                "-tag:v",
                "avc1",
                "-c:a",
                "aac",
                "-b:a",
                "320k",
                "-ar",
                "48000",
                "-af",
                "aresample=async=1000:first_pts=0",
                "-movflags",
                "+faststart",
                processedFile
              ];
            } else {
              ffmpegArgs = [
                "-y",
                "-threads",
                "0",
                "-i",
                currentStagingFile,
                ...getOptimalEncoderArgs(ffmpegPath),
                "-pix_fmt",
                "yuv420p",
                "-tag:v",
                "avc1",
                "-map",
                "0:v:0",
                "-map",
                "0:a?",
                "-c:a",
                "aac",
                "-b:a",
                "320k",
                "-ar",
                "48000",
                "-movflags",
                "+faststart",
                processedFile
              ];
            }
          } else {
            if (isH264 && container === "mp4" && !hasTimeRange) {
              const isAacAudio = probedAudioCodec === "aac" || probedAudioCodec === "mp4a";
              const hasAudio = Boolean(probedAudioCodec);
              if ((stagingExt === "mp4" || stagingExt === "mov") && (!hasAudio || isAacAudio)) {
                ffmpegArgs = [
                  "-y",
                  "-i",
                  currentStagingFile,
                  "-c",
                  "copy",
                  "-movflags",
                  "+faststart",
                  processedFile
                ];
              } else {
                ffmpegArgs = [
                  "-y",
                  "-i",
                  currentStagingFile,
                  "-map",
                  "0:v:0",
                  "-map",
                  "0:a?",
                  "-c:v",
                  "copy",
                  "-c:a",
                  "aac",
                  "-b:a",
                  "320k",
                  "-ar",
                  "48000",
                  "-movflags",
                  "+faststart",
                  processedFile
                ];
              }
            } else {
              ffmpegArgs = [
                "-y",
                "-i",
                currentStagingFile,
                ...getOptimalEncoderArgs(ffmpegPath),
                "-map",
                "0:v:0",
                "-map",
                "0:a?",
                ...isVideoOnly ? ["-an"] : ["-c:a", "aac", "-b:a", "320k", "-ar", "48000"],
                "-movflags",
                "+faststart",
                processedFile
              ];
            }
          }
          if (timeSeekArgs.length > 0) {
            const iIdx = ffmpegArgs.indexOf("-i");
            if (iIdx !== -1) {
              ffmpegArgs.splice(iIdx, 0, ...timeSeekArgs);
            }
          }
          try {
            this.emitThrottledProgress({
              progress: 92,
              downloadedBytes: this.item.downloadedBytes || 0,
              totalBytes: this.item.totalBytes || 0,
              speed: "",
              eta: "Finalizing...",
              stageDescription: isH264 ? `Finalizing lossless ${container.toUpperCase()} for Adobe timeline...` : hasTimeRange ? `Precision trimming for Adobe timeline...` : `Hardware accelerating ${container.toUpperCase()} for Adobe...`
            });
            logger.info(`[DownloadJob] Transcoding with FFmpeg: ${ffmpegArgs.join(" ")}`);
            await new Promise((resFf) => {
              const ffProc = (0, import_child_process3.spawn)(ffmpegPath, ffmpegArgs, { windowsHide: true });
              try {
                if (ffProc.pid && typeof import_os8.default.setPriority === "function") {
                  import_os8.default.setPriority(ffProc.pid, import_os8.default.constants.priority.PRIORITY_BELOW_NORMAL);
                }
              } catch (_) {
              }
              let ffErr = "";
              ffProc.stderr?.on("data", (chunk) => {
                const text = chunk.toString();
                ffErr = (ffErr + text).slice(-1500);
                const timeMatch = text.match(/time=(\d+):(\d+):(\d+\.\d+)/);
                const speedMatch = text.match(/speed=\s*([\d\.]+x)/);
                const fpsMatch = text.match(/fps=\s*([\d\.]+)/);
                if (timeMatch) {
                  const curSec = parseFloat(timeMatch[1]) * 3600 + parseFloat(timeMatch[2]) * 60 + parseFloat(timeMatch[3]);
                  const durSec = this.item.duration || 0;
                  let pct = 92;
                  if (durSec > 0) {
                    pct = Math.min(99, Math.max(91, 91 + Math.round(curSec / durSec * 8)));
                  }
                  const spd = speedMatch ? speedMatch[1] : fpsMatch ? `${fpsMatch[1]} fps` : "";
                  const resTag = res >= 2160 ? "4K" : res >= 1440 ? "2K" : res >= 1080 ? "Full HD" : res >= 720 ? "720p HD" : "video";
                  this.emitThrottledProgress({
                    progress: pct,
                    downloadedBytes: this.item.downloadedBytes || 0,
                    totalBytes: this.item.totalBytes || 0,
                    speed: spd ? `Optimizing at ${spd}` : "",
                    eta: "Almost ready...",
                    stageDescription: `Optimizing ${resTag} stream for Adobe timeline (${pct}%)...`
                  });
                }
              });
              ffProc.on("close", async (code) => {
                if (code === 0 && import_fs8.default.existsSync(processedFile) && import_fs8.default.statSync(processedFile).size > 1e3) {
                  if (timeSeekArgs.length > 0) this.trimmedInTranscode = true;
                  resFf();
                } else {
                  logger.warn(`[DownloadJob] Primary FFmpeg transcode finished with code ${code}. Retrying with universal fallback...`);
                  let cpuArgs = [];
                  if (isAudioOnly) {
                    let targetBitrate = "320k";
                    const pId = this.item.profile?.presetId || "";
                    const pLbl = this.item.profile?.label || "";
                    if (pId === "audio-mp3-128" || pLbl.includes("128")) targetBitrate = "128k";
                    else if (pId === "audio-mp3-192" || pLbl.includes("192")) targetBitrate = "192k";
                    else if (pId === "audio-mp3-96" || pLbl.includes("96")) targetBitrate = "96k";
                    else if (pId === "audio-m4a" || pLbl.includes("256")) targetBitrate = "256k";
                    else if (pId === "audio-mp3-320" || pLbl.includes("320")) targetBitrate = "320k";
                    if (container === "wav") {
                      cpuArgs = ["-y", ...timeSeekArgs, "-i", currentStagingFile, "-vn", "-c:a", "pcm_s16le", "-ar", "48000", processedFile];
                    } else if (container === "m4a" || container === "aac") {
                      cpuArgs = ["-y", ...timeSeekArgs, "-i", currentStagingFile, "-vn", "-c:a", "aac", "-b:a", targetBitrate, "-ar", "48000", processedFile];
                    } else if (container === "flac") {
                      cpuArgs = ["-y", ...timeSeekArgs, "-i", currentStagingFile, "-vn", "-c:a", "flac", processedFile];
                    } else if (container === "webm") {
                      cpuArgs = ["-y", ...timeSeekArgs, "-i", currentStagingFile, "-vn", "-c:a", "libopus", "-b:a", "160k", processedFile];
                    } else {
                      cpuArgs = ["-y", ...timeSeekArgs, "-i", currentStagingFile, "-vn", "-c:a", "libmp3lame", "-b:a", targetBitrate, "-ar", "44100", processedFile];
                    }
                  } else if (container === "webm") {
                    cpuArgs = [
                      "-y",
                      ...timeSeekArgs,
                      "-i",
                      currentStagingFile,
                      "-c:v",
                      "libvpx-vp9",
                      "-b:v",
                      "0",
                      "-crf",
                      "24",
                      ...isVideoOnly ? ["-an"] : ["-c:a", "libopus", "-b:a", "160k"],
                      processedFile
                    ];
                  } else if (container === "mkv") {
                    cpuArgs = [
                      "-y",
                      ...timeSeekArgs,
                      "-threads",
                      "0",
                      "-i",
                      currentStagingFile,
                      ...getOptimalEncoderArgs(ffmpegPath),
                      "-map",
                      "0:v:0",
                      "-map",
                      "0:a?",
                      ...isVideoOnly ? ["-an"] : ["-c:a", "aac", "-b:a", "320k", "-ar", "48000"],
                      processedFile
                    ];
                  } else {
                    cpuArgs = [
                      "-y",
                      ...timeSeekArgs,
                      "-threads",
                      "0",
                      "-i",
                      currentStagingFile,
                      ...getOptimalEncoderArgs(ffmpegPath),
                      ...container === "mov" ? ["-tag:v", "avc1"] : [],
                      "-map",
                      "0:v:0",
                      "-map",
                      "0:a?",
                      ...isVideoOnly ? ["-an"] : ["-c:a", "aac", "-b:a", "320k", "-ar", "48000"],
                      "-movflags",
                      "+faststart",
                      processedFile
                    ];
                  }
                  try {
                    const cpuProc = (0, import_child_process3.spawn)(ffmpegPath, cpuArgs, { windowsHide: true });
                    cpuProc.on("close", () => resFf());
                    cpuProc.on("error", () => resFf());
                  } catch (_) {
                    resFf();
                  }
                }
              });
              ffProc.on("error", (err) => {
                logger.warn("FFmpeg spawn notice:", err);
                resFf();
              });
            });
            if (import_fs8.default.existsSync(processedFile) && import_fs8.default.statSync(processedFile).size > 1e3) {
              try {
                import_fs8.default.unlinkSync(currentStagingFile);
              } catch (_) {
              }
              currentStagingFile = processedFile;
            }
          } catch (ffmpegErr) {
            logger.warn("[DownloadJob] FFmpeg processing notice:", ffmpegErr);
          }
        }
        const fallbackHasTimeRange = Boolean(!this.downloadedWithSections && !this.trimmedInTranscode && !this.downloadedWithTier2 && this.item.profile?.timeRange && (this.item.profile.timeRange.start || this.item.profile.timeRange.end));
        if (fallbackHasTimeRange && currentStagingFile && import_fs8.default.existsSync(currentStagingFile)) {
          const activeFfmpeg = ffmpegPath && import_fs8.default.existsSync(ffmpegPath) ? ffmpegPath : import_path8.default.join(binDir || "", process.platform === "win32" ? "ffmpeg.exe" : "ffmpeg");
          if (activeFfmpeg && import_fs8.default.existsSync(activeFfmpeg)) {
            const trimmedCut = import_path8.default.join(stagingDir, `cut_${Date.now()}_${this.item.id}.${stagingExt}`);
            try {
              let start = this.normalizeTime(this.item.profile.timeRange.start, "00:00:00");
              let end = this.normalizeTime(this.item.profile.timeRange.end, "99:59:59");
              const startSec = this.parseTimeToSeconds(start);
              const endSec = this.parseTimeToSeconds(end);
              const expectedDurSec = endSec > startSec ? endSec - startSec : null;
              const mediaDuration = this.item.duration || expectedDurSec || 300;
              const cutTimeoutMs = Math.max(6e4, Math.ceil(mediaDuration * 2e3));
              this.emitThrottledProgress({
                progress: 94,
                downloadedBytes: this.item.downloadedBytes || 0,
                totalBytes: this.item.totalBytes || 0,
                speed: "",
                eta: "Trimming...",
                stageDescription: `Precision trimming clip (${start} - ${end})...`
              });
              await new Promise((resolveCut, rejectCut) => {
                const cutProc = (0, import_child_process3.spawn)(activeFfmpeg, [
                  "-y",
                  "-ss",
                  start,
                  "-to",
                  end,
                  "-i",
                  currentStagingFile,
                  "-c",
                  "copy",
                  "-movflags",
                  "+faststart",
                  trimmedCut
                ], { windowsHide: true, stdio: ["ignore", "ignore", "pipe"] });
                let cutStderr = "";
                cutProc.stderr?.on("data", (d) => {
                  const text = d.toString();
                  cutStderr += text;
                  const timeMatch = text.match(/time=(\d+):(\d+):(\d+\.\d+)/);
                  if (timeMatch && expectedDurSec) {
                    const curSec = parseFloat(timeMatch[1]) * 3600 + parseFloat(timeMatch[2]) * 60 + parseFloat(timeMatch[3]);
                    const pct = Math.min(99, Math.max(93, 93 + Math.round(curSec / expectedDurSec * 6)));
                    this.emitThrottledProgress({
                      progress: pct,
                      downloadedBytes: this.item.downloadedBytes || 0,
                      totalBytes: this.item.totalBytes || 0,
                      speed: "",
                      eta: "Trimming...",
                      stageDescription: `Trimming clip (${pct}%)...`
                    });
                  }
                });
                const timer = setTimeout(() => {
                  try {
                    cutProc.kill("SIGKILL");
                  } catch (_) {
                  }
                  rejectCut(new Error(`Stream copy cut timed out after ${cutTimeoutMs}ms`));
                }, cutTimeoutMs);
                cutProc.on("error", (err) => {
                  clearTimeout(timer);
                  rejectCut(err);
                });
                cutProc.on("close", (code) => {
                  clearTimeout(timer);
                  if (code === 0 && import_fs8.default.existsSync(trimmedCut) && import_fs8.default.statSync(trimmedCut).size > 1e3) {
                    resolveCut();
                  } else {
                    rejectCut(new Error(`Stream copy cut failed with exit code ${code}: ${cutStderr.slice(-300)}`));
                  }
                });
              });
              if (import_fs8.default.existsSync(trimmedCut) && import_fs8.default.statSync(trimmedCut).size > 1e3) {
                if (expectedDurSec && ffprobePath && import_fs8.default.existsSync(ffprobePath)) {
                  const actualDur = await probeDurationSeconds(trimmedCut, ffprobePath);
                  if (actualDur && Math.abs(actualDur - expectedDurSec) > 2.5) {
                    logger.warn(`[DownloadJob] Trim duration mismatch: expected ${expectedDurSec}s, got ${actualDur}s`);
                  }
                }
                try {
                  import_fs8.default.unlinkSync(currentStagingFile);
                } catch (_) {
                }
                currentStagingFile = trimmedCut;
              }
            } catch (cutErr) {
              logger.warn(`Post-download stream copy cut notice: ${cutErr.message}`);
              throw cutErr;
            }
          }
        }
        const ext = this.getContainerExtension(this.item.profile || {});
        let finalName = "";
        if (this.item.profile?.customFilename && this.item.profile.customFilename.trim().length > 0) {
          const customClean = filesystemManager.sanitizeFilename(this.item.profile.customFilename.trim());
          finalName = customClean + "." + ext;
          this.item.title = customClean;
        } else {
          const isGeneric = (str) => {
            if (!str) return true;
            const s = str.trim();
            return !s || s === "Fetching media info..." || /^video by /i.test(s) || /^post by /i.test(s) || /^tweet by /i.test(s) || s.toLowerCase() === "media" || /^media[\._]/i.test(s);
          };
          const curTitle = (this.item.title || "").trim();
          const curIsGeneric = isGeneric(curTitle);
          const extTitle = (extractedTitle || "").trim();
          const extIsGeneric = isGeneric(extTitle);
          const metaTitle = (this.item.metadata?.title || "").trim();
          const metaIsGeneric = isGeneric(metaTitle);
          let chosenTitle = "MediaFetch_Media";
          if (!metaIsGeneric) {
            chosenTitle = metaTitle;
          } else if (!curIsGeneric) {
            chosenTitle = curTitle;
          } else if (!extIsGeneric) {
            chosenTitle = extTitle;
          } else if (metaTitle && !isGeneric(metaTitle)) {
            chosenTitle = metaTitle.replace(/^video by /i, "Clip - ").trim();
          } else if (curTitle && !isGeneric(curTitle)) {
            chosenTitle = curTitle.replace(/^video by /i, "Clip - ").trim();
          } else if (extTitle && !isGeneric(extTitle)) {
            chosenTitle = extTitle.replace(/^video by /i, "Clip - ").trim();
          }
          const cleanChosen = filesystemManager.sanitizeFilename(chosenTitle);
          finalName = cleanChosen + "." + ext;
          this.item.title = cleanChosen;
        }
        const effectiveTargetDir = this.resolveFinalTargetDir(targetDir, ext, this.item.profile?.type);
        const finalized = filesystemManager.finalizeDownloadedFile(currentStagingFile, effectiveTargetDir, finalName);
        this.item.downloadedPath = finalized.finalPath;
        this.cleanupStagingFiles(stagingDir, this.item.id);
        await new Promise((r) => setTimeout(r, 400));
        return finalized;
      }
      resolveFinalTargetDir(baseTargetDir, ext, profileType) {
        if (this.item.zipPackage || this.item.metadata?.zipPackage) {
          if (baseTargetDir) {
            filesystemManager.ensureDirExists(baseTargetDir);
            return baseTargetDir;
          }
        }
        const rawLocMode = settingsManager.getSettings()?.downloads?.downloadLocationMode || "simple";
        const locMode = rawLocMode === "project" ? "simple" : rawLocMode;
        const isCustomFlat = locMode === "custom_flat" || Boolean(this.item.isCustomFlat);
        const isCustomMode = locMode === "custom" || isCustomFlat || Boolean(this.item.isCustomPath);
        const isPlaylist = Boolean(this.item.metadata?.isPlaylist || this.item.isPlaylist || this.item.metadata?.playlistTitle);
        let root = baseTargetDir || filesystemManager.resolveTargetDirectory().targetDir;
        root = root.replace(/[\/\\]+$/, "");
        if (isCustomFlat) {
          filesystemManager.ensureDirExists(root);
          return root;
        }
        if (isPlaylist) {
          const rawPTitle = this.item.metadata?.playlistTitle || this.item.metadata?.customFolderName || "Playlist";
          const pTitle = rawPTitle.replace(/[\\/:*?"<>|]/g, "_").trim() || "Playlist";
          let pDir = import_path8.default.join(root, "Playlists", pTitle);
          if (this.item.metadata?.subFolderName) {
            pDir = import_path8.default.join(pDir, this.item.metadata.subFolderName);
          }
          filesystemManager.ensureDirExists(pDir);
          return pDir;
        }
        const cleanExt = (ext || "").toLowerCase().replace(/^\./, "").split("?")[0];
        const isAudio = profileType === "audio" || ["mp3", "wav", "m4a", "flac", "aac", "ogg", "opus", "aiff", "m4p"].includes(cleanExt);
        const isImage = profileType === "image" || ["jpg", "jpeg", "png", "webp", "gif", "bmp", "svg", "tiff", "tif", "ico"].includes(cleanExt);
        const subType = isAudio ? "Audio" : isImage ? "Images" : "Video";
        if (isCustomMode) {
          const finalDir2 = import_path8.default.join(root, subType);
          filesystemManager.ensureDirExists(finalDir2);
          return finalDir2;
        }
        root = root.replace(/[\/\\](?:Link|Search|LinkMediaFetch|SerachMediafetch|Video|Audio|Images?)$/i, "");
        if (!/[\/\\]MediaFetch$/i.test(root) && import_path8.default.basename(root).toLowerCase() !== "mediafetch") {
          root = import_path8.default.join(root, "MediaFetch");
        }
        const finalDir = import_path8.default.join(root, subType);
        filesystemManager.ensureDirExists(finalDir);
        return finalDir;
      }
      pause() {
        this.isPaused = true;
        this.killProcess();
      }
      cancel() {
        this.isCancelled = true;
        this.killProcess();
      }
      killProcess() {
        if (this.activeHttpRequest) {
          try {
            this.activeHttpRequest.destroy();
            this.activeHttpRequest = void 0;
          } catch (_) {
          }
        }
        if (this.childProcess) {
          try {
            if (process.platform === "win32") {
              try {
                (0, import_child_process3.spawn)("taskkill", ["/pid", String(this.childProcess.pid), "/f", "/t"], { windowsHide: true });
              } catch (_) {
              }
              try {
                this.childProcess.kill("SIGKILL");
              } catch (_) {
              }
            } else {
              this.childProcess.kill("SIGKILL");
            }
          } catch (err) {
            logger.warn(`[DownloadJob] Kill error for [${this.item.id}]:`, err);
          }
        }
      }
      async probeVideoCodec(filePath, ffprobePath) {
        if (!ffprobePath || !import_fs8.default.existsSync(ffprobePath) || !import_fs8.default.existsSync(filePath)) {
          return null;
        }
        try {
          const { stdout } = await execFileAsync3(ffprobePath, [
            "-v",
            "error",
            "-select_streams",
            "v:0",
            "-show_entries",
            "stream=codec_name",
            "-of",
            "default=noprint_wrappers=1:nokey=1",
            filePath
          ], { windowsHide: true });
          return (stdout || "").trim().toLowerCase();
        } catch (err) {
          logger.warn("[DownloadJob] ffprobe probe notice:", err);
          return null;
        }
      }
      async probeAudioCodec(filePath, ffprobePath) {
        if (!ffprobePath || !import_fs8.default.existsSync(ffprobePath) || !import_fs8.default.existsSync(filePath)) {
          return null;
        }
        try {
          const { stdout } = await execFileAsync3(ffprobePath, [
            "-v",
            "error",
            "-select_streams",
            "a:0",
            "-show_entries",
            "stream=codec_name",
            "-of",
            "default=noprint_wrappers=1:nokey=1",
            filePath
          ], { windowsHide: true });
          return (stdout || "").trim().toLowerCase();
        } catch (err) {
          logger.warn("[DownloadJob] ffprobe audio probe notice:", err);
          return null;
        }
      }
      parseStdout(data) {
        if (this.isPaused || this.isCancelled) return;
        const lines = data.split(/\r?\n/);
        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed) continue;
          if (trimmed.startsWith("MF_TITLE:")) {
            const t = trimmed.substring("MF_TITLE:".length).trim();
            const isGeneric = !t || /^video by /i.test(t) || /^post by /i.test(t) || /^tweet by /i.test(t) || t.toLowerCase() === "media" || /^media[\._]/i.test(t);
            if (t && t.length > 0 && !isGeneric && (this.item.title === "Fetching media info..." || !this.item.title || /^video by /i.test(this.item.title) || this.item.title.toLowerCase() === "media" || /^media[\._]/i.test(this.item.title))) {
              this.item.title = t;
              if (!this.item.metadata) this.item.metadata = {};
              this.item.metadata.title = t;
              this.onProgressCb?.({
                progress: this.item.progress || 0,
                downloadedBytes: this.item.downloadedBytes || 0,
                totalBytes: this.item.totalBytes || 0,
                speed: this.item.speed || "",
                eta: this.item.eta || "",
                stageDescription: "Starting download..."
              });
            }
          } else if (trimmed.startsWith("[download] Destination:") || trimmed.startsWith("[download] Got destination:")) {
            const destMatch = trimmed.match(/__MF__(.*?)(?:__MF__|\.[a-zA-Z0-9]+$)/);
            if (destMatch && destMatch[1] && (this.item.title === "Fetching media info..." || !this.item.title || this.item.title.toLowerCase() === "media" || /^media[\._]/i.test(this.item.title))) {
              let dt = destMatch[1].trim();
              dt = dt.replace(/\.f\d+$/i, "").replace(/\.temp$/i, "").trim();
              const isGeneric = !dt || /^video by /i.test(dt) || /^post by /i.test(dt) || /^tweet by /i.test(dt) || dt.toLowerCase() === "media" || /^media[\._]/i.test(dt);
              if (!isGeneric) {
                this.item.title = dt;
                if (!this.item.metadata) this.item.metadata = {};
                this.item.metadata.title = dt;
              }
            }
            this.streamIndex++;
            if (this.streamIndex > 1) {
              if (this.currentStreamTotal > 0) {
                this.completedStreamsBytes += this.currentStreamDownloaded || this.currentStreamTotal;
                this.completedStreamsTotal += this.currentStreamTotal;
                this.currentStreamDownloaded = 0;
                this.currentStreamTotal = 0;
              }
              this.emitThrottledProgress({
                progress: Math.min(90, Math.max(88, this.item.progress || 0)),
                downloadedBytes: this.completedStreamsBytes,
                totalBytes: this.completedStreamsTotal,
                speed: "",
                eta: "",
                stageDescription: "Video stream ready, fetching audio track..."
              });
            } else {
              this.emitThrottledProgress({
                progress: Math.max(10, this.item.progress || 0),
                downloadedBytes: this.item.downloadedBytes || 0,
                totalBytes: this.item.totalBytes || 0,
                speed: "",
                eta: "",
                stageDescription: "Connected to server, starting media transfer..."
              });
            }
          } else if (trimmed.includes("Downloading webpage") || trimmed.includes("Extracting URL")) {
            this.emitThrottledProgress({
              progress: Math.max(3, this.item.progress || 0),
              downloadedBytes: 0,
              totalBytes: 0,
              speed: "",
              eta: "",
              stageDescription: "Resolving media host..."
            });
          } else if (trimmed.includes("player API") || trimmed.includes("initial data")) {
            this.emitThrottledProgress({
              progress: Math.max(6, this.item.progress || 0),
              downloadedBytes: 0,
              totalBytes: 0,
              speed: "",
              eta: "",
              stageDescription: "Negotiating high-speed stream..."
            });
          } else if (trimmed.includes("Downloading 1 format") || trimmed.includes("Downloading format") || trimmed.includes("[info]")) {
            this.emitThrottledProgress({
              progress: Math.max(8, this.item.progress || 0),
              downloadedBytes: 0,
              totalBytes: 0,
              speed: "",
              eta: "",
              stageDescription: "Stream selected, establishing CDN connection..."
            });
          } else if (trimmed.startsWith("MF_PROGRESS:")) {
            const parts = trimmed.substring("MF_PROGRESS:".length).split("|");
            if (parts.length >= 5) {
              const rawPercent = parts[0].replace("%", "").trim();
              const percent = parseFloat(rawPercent) || 0;
              const downloadedStr = parts[1].trim();
              const totalStr = parts[2].trim();
              const speedStr = parts[3].trim();
              const etaStr = parts[4].trim();
              const downloadedBytes = this.parseBytes(downloadedStr);
              const totalBytes = this.parseBytes(totalStr);
              if (this.streamIndex <= 1 && this.lastStreamTotal > 15 * 1024 * 1024 && totalBytes > 0 && totalBytes < this.lastStreamTotal * 0.4 && percent < 20) {
                this.streamIndex = 2;
                this.completedStreamsBytes += this.currentStreamDownloaded || this.lastStreamTotal;
                this.completedStreamsTotal += this.lastStreamTotal;
                this.currentStreamDownloaded = 0;
                this.currentStreamTotal = 0;
              }
              this.lastStreamTotal = totalBytes;
              this.currentStreamDownloaded = downloadedBytes;
              this.currentStreamTotal = totalBytes;
              let aggregateDownloaded = downloadedBytes;
              let aggregateTotal = totalBytes;
              if (this.streamIndex > 1 || this.completedStreamsTotal > 0) {
                aggregateDownloaded = this.completedStreamsBytes + downloadedBytes;
                aggregateTotal = this.completedStreamsTotal + totalBytes;
              }
              this.item.downloadedBytes = aggregateDownloaded;
              this.item.totalBytes = aggregateTotal;
              this.item.speed = speedStr;
              this.item.eta = etaStr;
              let overallPercent = percent;
              if (aggregateTotal > 0) {
                overallPercent = aggregateDownloaded / aggregateTotal * 100;
              }
              const prevProg = this.item.progress || 0;
              let targetProgress = Math.min(90, Math.round(overallPercent));
              if (this.streamIndex > 1) {
                targetProgress = Math.min(90, Math.max(88, targetProgress));
              }
              const displayProgress = Math.max(prevProg, targetProgress);
              this.item.progress = displayProgress;
              let stageDesc = "";
              if (this.streamIndex > 1) {
                stageDesc = `Downloading audio track (${percent.toFixed(0)}%)...`;
              } else {
                stageDesc = `Downloading (${percent.toFixed(0)}%)`;
              }
              this.emitThrottledProgress({
                progress: displayProgress,
                downloadedBytes: aggregateDownloaded,
                totalBytes: aggregateTotal,
                speed: speedStr || "",
                eta: etaStr || "",
                stageDescription: stageDesc
              });
            }
          } else if (trimmed.includes("CN:") && /\[#\w+\s+[\d\.]+[A-Za-z]+\/[\d\.]+[A-Za-z]+\s*\(\d+%\)/.test(trimmed)) {
            const ariaMatch = trimmed.match(/\[#\w+\s+([\d\.]+[A-Za-z]+)\/([\d\.]+[A-Za-z]+)\s*\((\d+)%\).*?DL:([\d\.]+[A-Za-z]+(?:\/s)?)?(?:\s+ETA:([\w:]+))?/);
            if (ariaMatch) {
              const dlStr = ariaMatch[1];
              const totStr = ariaMatch[2];
              const pct = parseInt(ariaMatch[3], 10) || 0;
              const spd = ariaMatch[4] ? `${ariaMatch[4]}/s`.replace("/s/s", "/s") : "";
              const eta = ariaMatch[5] || "";
              const dlBytes = this.parseBytes(dlStr);
              const totBytes = this.parseBytes(totStr);
              const displayProg = Math.min(90, Math.max(5, pct));
              this.emitThrottledProgress({
                progress: displayProg,
                downloadedBytes: dlBytes,
                totalBytes: totBytes,
                speed: spd,
                eta,
                stageDescription: `Downloading (${displayProg}%)`
              });
            }
          } else if (/^\[download\]\s+\d+(\.\d+)?%/i.test(trimmed)) {
            const stdMatch = trimmed.match(/\[download\]\s+(\d+(?:\.\d+)?)%\s+of\s+~?\s*([\d\.]+\s*[a-zA-Z]+)(?:\s+at\s+~?\s*([\d\.]+\s*[a-zA-Z]+\/s))?(?:\s+ETA\s+([0-9:]+))?/i);
            if (stdMatch) {
              const percent = parseFloat(stdMatch[1]) || 0;
              const totalStr = stdMatch[2] || "";
              const speedStr = stdMatch[3] || "";
              const etaStr = stdMatch[4] || "";
              const totalBytes = this.parseBytes(totalStr);
              const downloadedBytes = totalBytes > 0 ? Math.round(percent / 100 * totalBytes) : 0;
              if (this.streamIndex <= 1 && this.lastStreamTotal > 15 * 1024 * 1024 && totalBytes > 0 && totalBytes < this.lastStreamTotal * 0.4 && percent < 20) {
                this.streamIndex = 2;
                this.completedStreamsBytes += this.currentStreamDownloaded || this.lastStreamTotal;
                this.completedStreamsTotal += this.lastStreamTotal;
                this.currentStreamDownloaded = 0;
                this.currentStreamTotal = 0;
              }
              this.lastStreamTotal = totalBytes;
              this.currentStreamDownloaded = downloadedBytes;
              this.currentStreamTotal = totalBytes;
              let aggregateDownloaded = downloadedBytes;
              let aggregateTotal = totalBytes;
              if (this.streamIndex > 1 || this.completedStreamsTotal > 0) {
                aggregateDownloaded = this.completedStreamsBytes + downloadedBytes;
                aggregateTotal = this.completedStreamsTotal + totalBytes;
              }
              this.item.downloadedBytes = aggregateDownloaded;
              this.item.totalBytes = aggregateTotal;
              this.item.speed = speedStr;
              this.item.eta = etaStr;
              let overallPercent = percent;
              if (aggregateTotal > 0) {
                overallPercent = aggregateDownloaded / aggregateTotal * 100;
              }
              const prevProg = this.item.progress || 0;
              let targetProgress = Math.min(90, Math.round(overallPercent));
              if (this.streamIndex > 1) {
                targetProgress = Math.min(90, Math.max(88, targetProgress));
              }
              const displayProgress = Math.max(prevProg, targetProgress);
              this.item.progress = displayProgress;
              let stageDesc = "";
              if (this.streamIndex > 1) {
                stageDesc = `Downloading audio track (${percent.toFixed(0)}%)...`;
              } else {
                stageDesc = `Downloading (${percent.toFixed(0)}%)`;
              }
              this.emitThrottledProgress({
                progress: displayProgress,
                downloadedBytes: aggregateDownloaded,
                totalBytes: aggregateTotal,
                speed: speedStr || "",
                eta: etaStr || "",
                stageDescription: stageDesc
              });
            }
          } else if (trimmed.includes("[Merger]") || trimmed.includes("[ExtractAudio]") || trimmed.includes("[FixupM3u8]") || trimmed.includes("MF_MERGE:")) {
            this.emitThrottledProgress({
              progress: 91,
              downloadedBytes: this.item.downloadedBytes || 0,
              totalBytes: this.item.totalBytes || 0,
              speed: "",
              eta: "Finalizing...",
              stageDescription: "Merging audio and video streams (almost ready)..."
            });
          }
        }
      }
      parseStderr(data) {
        if (this.isPaused || this.isCancelled) return;
        if (data.includes("[Merger]") || data.includes("[ExtractAudio]") || data.includes("Post-process")) {
          this.emitThrottledProgress({
            progress: 91,
            downloadedBytes: this.item.downloadedBytes || 0,
            totalBytes: this.item.totalBytes || 0,
            speed: "",
            eta: "Finalizing...",
            stageDescription: "Processing & remuxing with FFmpeg (almost ready)..."
          });
          return;
        }
        if (data.includes("Opening") || data.includes("Press [q]") || data.includes("Metadata:") || data.includes("Stream #") || data.includes("Starting connection attempt") || data.includes("Successfully connected")) {
          const isTrim = Boolean(this.item.profile?.timeRange);
          const startPoint = this.item.profile?.timeRange?.start || "00:00:00";
          this.emitThrottledProgress({
            progress: Math.max(isTrim ? 12 : 5, this.item.progress || 0),
            downloadedBytes: this.item.downloadedBytes || 0,
            totalBytes: this.item.totalBytes || 0,
            speed: "",
            eta: "",
            stageDescription: isTrim ? `Seeking stream to cut point (${startPoint})...` : "Establishing media stream..."
          });
        }
        const timeMatch = data.match(/time=\s*(-?[\d\.:]+)/);
        const sizeMatch = data.match(/size=\s*(\d+)\s*[kK]i?B/i);
        const speedMatch = data.match(/speed=\s*([\d\.]+)x/i);
        const frameMatch = data.match(/frame=\s*(\d+)/i);
        if (timeMatch || frameMatch) {
          const sizeKb = sizeMatch ? parseInt(sizeMatch[1], 10) : 0;
          const downloadedBytes = sizeKb * 1024;
          const speedStr = speedMatch ? `${speedMatch[1]}x` : "";
          let pct = Math.max(5, this.item.progress || 5);
          if (this.item.profile?.timeRange && timeMatch) {
            const tr = this.item.profile.timeRange;
            const s = this.parseTimeToSeconds(tr.start);
            const e = this.parseTimeToSeconds(tr.end);
            const dur = e > s ? e - s : 0;
            const rawCur = this.parseTimeToSeconds(timeMatch[1]);
            const cur = Math.max(0, rawCur);
            if (dur > 0) {
              pct = Math.min(95, Math.max(5, Math.round(cur / dur * 100)));
            }
          }
          this.emitThrottledProgress({
            progress: pct,
            downloadedBytes: downloadedBytes > 0 ? downloadedBytes : this.item.downloadedBytes || 0,
            totalBytes: this.item.totalBytes || 0,
            speed: speedStr,
            eta: "",
            stageDescription: `Downloading trimmed stream (${pct}%)...`
          });
        }
      }
      emitThrottledProgress(update) {
        if (this.isPaused || this.isCancelled) return;
        const now = Date.now();
        if (now - this.lastProgressEmit >= this.throttleMs) {
          this.lastProgressEmit = now;
          this.onProgressCb?.(update);
        }
      }
      parseBytes(str) {
        if (!str || str === "N/A" || str === "Unknown") return 0;
        const match = str.match(/([\d\.]+)\s*([KMGTP]?i?B)/i);
        if (!match) return 0;
        const num = parseFloat(match[1]);
        const unit = match[2].toUpperCase();
        const multipliers = {
          "B": 1,
          "KB": 1024,
          "KIB": 1024,
          "MB": 1024 * 1024,
          "MIB": 1024 * 1024,
          "GB": 1024 * 1024 * 1024,
          "GIB": 1024 * 1024 * 1024,
          "TB": 1024 * 1024 * 1024 * 1024
        };
        return Math.round(num * (multipliers[unit] || 1));
      }
      parseTimeToSeconds(val) {
        if (!val) return 0;
        const clean = String(val).trim();
        if (!clean) return 0;
        const parts = clean.split(":").map((p) => parseFloat(p.trim()) || 0);
        if (parts.length >= 3) {
          let sec = parts[0] * 3600 + parts[1] * 60 + parts[2];
          if (parts.length >= 4) sec += parts[3] / 30;
          return sec;
        } else if (parts.length === 2) {
          return parts[0] * 60 + parts[1];
        } else if (parts.length === 1) {
          return parts[0];
        }
        return 0;
      }
      normalizeTime(val, fallback = "00:00:00") {
        if (!val) return fallback;
        const clean = String(val).trim();
        if (!clean) return fallback;
        let totalSec = this.parseTimeToSeconds(clean);
        if (isNaN(totalSec) || totalSec < 0) totalSec = 0;
        const h = Math.floor(totalSec / 3600);
        const m = Math.floor(totalSec % 3600 / 60);
        const s = Math.floor(totalSec % 60);
        const frac = totalSec - Math.floor(totalSec);
        const fracStr = frac > 0 ? "." + Math.round(frac * 1e3).toString().padStart(3, "0") : "";
        return `${h.toString().padStart(2, "0")}:${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}${fracStr}`;
      }
      getContainerExtension(profile) {
        const c = (profile.container || "").toLowerCase();
        if (c) {
          return c;
        }
        if (profile.type === "audio") {
          if (profile.presetId === "audio-wav") return "wav";
          if (profile.presetId === "audio-m4a") return "m4a";
          if (profile.presetId === "audio-flac") return "flac";
          return "mp3";
        }
        return "mp4";
      }
      findStagingFile(stagingDir, downloadId) {
        if (!import_fs8.default.existsSync(stagingDir)) return null;
        const files = import_fs8.default.readdirSync(stagingDir);
        const found = files.find((f) => f.startsWith(downloadId) && !f.endsWith(".part") && !f.endsWith(".ytdl") && !f.endsWith(".temp") && !/\.f\d+\.[a-zA-Z0-9]+$/i.test(f));
        if (!found) return null;
        let extractedTitle;
        if (found.includes("__MF__")) {
          const parts = found.split("__MF__");
          if (parts.length > 1) {
            extractedTitle = import_path8.default.parse(parts[1]).name;
            if (extractedTitle) {
              extractedTitle = extractedTitle.replace(/\.f\d+$/i, "").replace(/\.temp$/i, "").trim();
            }
          }
        }
        return {
          filePath: import_path8.default.join(stagingDir, found),
          extractedTitle
        };
      }
      cleanupStagingFiles(stagingDir, downloadId) {
        try {
          if (!import_fs8.default.existsSync(stagingDir)) return;
          const files = import_fs8.default.readdirSync(stagingDir);
          const now = Date.now();
          for (const f of files) {
            const fullPath = import_path8.default.join(stagingDir, f);
            if (downloadId && (f.startsWith(downloadId) || f.includes(downloadId))) {
              try {
                import_fs8.default.unlinkSync(fullPath);
              } catch (e) {
              }
            } else {
              try {
                const stat = import_fs8.default.statSync(fullPath);
                if (now - stat.mtimeMs > 10 * 60 * 1e3) {
                  import_fs8.default.unlinkSync(fullPath);
                }
              } catch (_) {
              }
            }
          }
        } catch (e) {
        }
      }
      buildYtDlpArgs(url, profile, outputTemplate, ffmpegBinDir, skipCookies = false) {
        const cleanUrl = url.trim();
        const isYouTube = youtubeTokenManager.isYouTubeUrl(cleanUrl);
        const isSearchQuery = cleanUrl.startsWith("ytsearch");
        const cacheDir = import_path8.default.join(process.env.LOCALAPPDATA || process.env.APPDATA || import_os8.default.tmpdir(), "MediaFetch", ".cache");
        const nodeBin = dependencyManager.getNodeExecutablePath();
        const jsRuntime = nodeBin === "node" || !nodeBin ? "node" : `node:${nodeBin}`;
        let ytExtArgs = [];
        if (isYouTube) {
          ytExtArgs.push("--remote-components", "ejs:github");
        }
        const args = [
          "--newline",
          "--continue",
          "--no-playlist",
          "--no-check-certificates",
          "--no-mtime",
          "--cache-dir",
          cacheDir,
          "--js-runtimes",
          jsRuntime,
          "--buffer-size",
          "16M",
          ...ytExtArgs,
          ...isSearchQuery ? ["--max-downloads", "1", "-i"] : [],
          "--progress-template",
          "download:MF_PROGRESS:%(progress._percent_str)s|%(progress._downloaded_bytes_str)s|%(progress._total_bytes_str|progress._total_bytes_estimate_str)s|%(progress._speed_str)s|%(progress._eta_str)s",
          "--print",
          "before_dl:MF_TITLE:%(title)s",
          "--retries",
          "10",
          "--fragment-retries",
          "10",
          "--file-access-retries",
          "3",
          "--concurrent-fragments",
          "16",
          "--socket-timeout",
          "30",
          "-o",
          outputTemplate
        ];
        if (ffmpegBinDir) {
          args.push("--ffmpeg-location", ffmpegBinDir);
        }
        const pageUrl = this.item.url || "";
        if (cleanUrl.includes("behance.net") || cleanUrl.includes("vimeo.com") || pageUrl.includes("behance.net")) {
          args.push("--referer", "https://www.behance.net/");
          args.push("--add-header", "Referer:https://www.behance.net/");
        } else if (cleanUrl.includes("instagram.com") || pageUrl.includes("instagram.com")) {
          args.push("--referer", "https://www.instagram.com/");
        } else if (cleanUrl.includes("threads.net") || cleanUrl.includes("threads.com") || pageUrl.includes("threads.net")) {
          args.push("--referer", "https://www.threads.net/");
        } else if (cleanUrl.includes("x.com") || cleanUrl.includes("twitter.com") || pageUrl.includes("x.com") || pageUrl.includes("twitter.com")) {
          args.push("--referer", "https://x.com/");
        } else if (cleanUrl.includes("linkedin.com") || pageUrl.includes("linkedin.com")) {
          args.push("--referer", "https://www.linkedin.com/");
        }
        const hasTimeRange = Boolean(profile.timeRange && (profile.timeRange.start?.trim() || profile.timeRange.end?.trim()));
        if (hasTimeRange && !this.retriedWithoutSections) {
          let start = this.normalizeTime(profile.timeRange.start, "00:00:00");
          let end = profile.timeRange.end ? this.normalizeTime(profile.timeRange.end, "99:59:59") : "99:59:59";
          const startSec = this.parseTimeToSeconds(start);
          const endSec = this.parseTimeToSeconds(end);
          if (endSec > 0 && startSec > endSec) {
            const tmp = start;
            start = end;
            end = tmp;
          }
          args.push("--download-sections", `*${start}-${end}`);
          args.push("--force-keyframes-at-cuts");
          args.push("--downloader-args", "ffmpeg:-threads 0 -reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5");
          this.downloadedWithSections = true;
        } else {
          this.downloadedWithSections = false;
          const aria2cPath = getAria2cExecutablePath();
          if (aria2cPath) {
            args.push("--downloader", aria2cPath, "--downloader-args", "aria2c:-x16 -s16 -k1M -j16");
          }
        }
        if (!skipCookies) {
          const localAppData = process.env.LOCALAPPDATA || (import_os8.default.homedir ? import_path8.default.join(import_os8.default.homedir(), "AppData", "Local") : "");
          const cookiesFilePath = localAppData ? import_path8.default.join(localAppData, "MediaFetch", "cookies.txt") : "";
          if (cookiesFilePath && import_fs8.default.existsSync(cookiesFilePath) && import_fs8.default.statSync(cookiesFilePath).size > 10) {
            args.push("--cookies", cookiesFilePath);
          } else {
            const rawCookiesBrowser = settingsManager.getSettings()?.engine?.browserCookies || settingsManager.getSettings()?.engine?.cookiesBrowser || "none";
            const isWin = process.platform === "win32";
            const cookiesBrowser = isWin && rawCookiesBrowser === "chrome" ? "none" : rawCookiesBrowser;
            if (cookiesBrowser && cookiesBrowser !== "none") {
              args.push("--cookies-from-browser", cookiesBrowser);
            }
          }
        }
        const container = (profile.container || "mp4").toLowerCase();
        const isExplicitVideo = ["mp4", "mov", "mkv", "webm", "avi"].includes(container);
        const isAudio = !isExplicitVideo && (profile.type === "audio" || ["mp3", "wav", "m4a", "flac", "aac", "ogg"].includes(container));
        const isVideoOnly = profile.type === "video-only" || profile.presetId === "video-only";
        let res = 1080;
        if (profile.resolution && typeof profile.resolution === "number" && profile.resolution > 0) {
          res = profile.resolution;
        } else if (profile.presetId === "video-4k" || profile.presetId === "res-2160") {
          res = 2160;
        } else if (profile.presetId === "video-1440p" || profile.presetId === "res-1440") {
          res = 1440;
        } else if (profile.presetId === "video-1080p" || profile.presetId === "res-1080") {
          res = 1080;
        } else if (profile.presetId === "video-720p" || profile.presetId === "res-720") {
          res = 720;
        } else if (profile.presetId === "video-480p" || profile.presetId === "res-480") {
          res = 480;
        } else if (profile.presetId === "video-360p" || profile.presetId === "res-360") {
          res = 360;
        } else if (profile.presetId === "best-available" || profile.presetId === "video-only") {
          res = 9999;
        } else if (typeof profile.presetId === "string" && profile.presetId.startsWith("res-")) {
          const parsed = parseInt(profile.presetId.replace("res-", ""), 10);
          if (!isNaN(parsed) && parsed > 0) res = parsed;
        }
        if (profile.customFormatId) {
          args.push("-f", profile.customFormatId);
        } else if (isAudio) {
          let targetFormat = container === "wav" || container === "m4a" || container === "flac" ? container : "mp3";
          let targetQuality = "0";
          const pId = profile.presetId || "";
          const pLbl = profile.label || "";
          if (pId === "audio-mp3-128" || pLbl.includes("128")) targetQuality = "128K";
          else if (pId === "audio-mp3-192" || pLbl.includes("192")) targetQuality = "192K";
          else if (pId === "audio-mp3-96" || pLbl.includes("96")) targetQuality = "96K";
          else if (pId === "audio-mp3-320" || pLbl.includes("320")) targetQuality = "320K";
          if (container === "webm") {
            args.push("-f", "bestaudio[ext=webm]/bestaudio[acodec=opus]/bestaudio[ext=webm]/bestaudio/best", "-x");
          } else {
            args.push(
              "-f",
              "bestaudio/best",
              "-x",
              "--audio-format",
              targetFormat,
              "--audio-quality",
              targetQuality
            );
          }
        } else if (isVideoOnly) {
          if (container === "webm") {
            const fStr = res >= 9999 ? "bestvideo[ext=webm]/bestvideo[vcodec^=vp]/bestvideo/best" : `bestvideo[height=${res}][ext=webm]/bestvideo[height<=?${res}][ext=webm]/bestvideo[height=${res}]/bestvideo[height<=?${res}]/bestvideo/best`;
            args.push("-f", fStr);
          } else {
            if (res >= 9999) {
              args.push("-S", "res,vcodec:h264");
              args.push("-f", "bestvideo/best");
            } else {
              args.push("-S", `res:${res},vcodec:h264`);
              args.push("-f", `bestvideo[height=${res}][vcodec^=avc1]/bestvideo[height=${res}][vcodec^=h264]/bestvideo[height<=?${res}][vcodec^=avc1]/bestvideo[height<=?${res}][vcodec^=h264]/bestvideo[height=${res}]/bestvideo[height<=?${res}]/bestvideo/best`);
            }
          }
        } else {
          if (container === "webm") {
            const fStr = res >= 9999 ? "bestvideo[ext=webm]+bestaudio[ext=webm]/bestvideo[vcodec^=vp]+bestaudio[acodec^=opus]/bestvideo+bestaudio/best" : `bestvideo[height=${res}][ext=webm]+bestaudio[ext=webm]/bestvideo[height<=?${res}][ext=webm]+bestaudio[ext=webm]/bestvideo[height=${res}]+bestaudio/bestvideo[height<=?${res}]+bestaudio/bestvideo+bestaudio/best`;
            args.push("-f", fStr);
          } else {
            if (res >= 9999) {
              args.push("-S", "res,vcodec:h264,acodec:m4a");
              args.push("-f", "bestvideo[vcodec^=avc1]+bestaudio[acodec^=mp4a]/bestvideo[vcodec^=avc1]+bestaudio/bestvideo[vcodec^=h264]+bestaudio[acodec^=mp4a]/bestvideo[vcodec^=h264]+bestaudio/bestvideo+bestaudio[acodec^=mp4a]/bestvideo+bestaudio[ext=m4a]/bestvideo+bestaudio/best");
            } else {
              args.push("-S", `res:${res},vcodec:h264,acodec:m4a`);
              args.push("-f", `bestvideo[height=${res}][vcodec^=avc1]+bestaudio[acodec^=mp4a]/bestvideo[height=${res}][vcodec^=avc1]+bestaudio[ext=m4a]/bestvideo[height=${res}][vcodec^=avc1]+bestaudio/bestvideo[height=${res}][vcodec^=h264]+bestaudio[acodec^=mp4a]/bestvideo[height=${res}][vcodec^=h264]+bestaudio/bestvideo[height<=?${res}][vcodec^=avc1]+bestaudio[acodec^=mp4a]/bestvideo[height<=?${res}][vcodec^=avc1]+bestaudio/bestvideo[height<=?${res}][vcodec^=h264]+bestaudio[acodec^=mp4a]/bestvideo[height<=?${res}][vcodec^=h264]+bestaudio/bestvideo[height=${res}]+bestaudio[acodec^=mp4a]/bestvideo[height=${res}]+bestaudio/bestvideo[height<=?${res}]+bestaudio/bestvideo+bestaudio/best`);
            }
          }
        }
        if (!isAudio && ["mp4", "mkv", "webm", "mov"].includes(container)) {
          if (container === "mov") {
            args.push("--merge-output-format", "mkv");
          } else {
            args.push("--merge-output-format", container);
          }
        }
        args.push(cleanUrl);
        return args;
      }
    };
  }
});

// MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/service/retry.js
function _0x38d8(_0x27a9fa, _0x549935) {
  _0x27a9fa = _0x27a9fa - (7 * 824 + -2 * 3595 + 1594);
  const _0x2c0448 = _0x43ad();
  let _0x27d528 = _0x2c0448[_0x27a9fa];
  if (_0x38d8["GVsutY"] === void 0) {
    var _0x1a4817 = function(_0x54fe9d) {
      const _0x566690 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      let _0x3647a9 = "", _0x1ef9d4 = "";
      for (let _0x195ad7 = 9977 * -1 + -4311 + 188 * 76, _0x1e6501, _0x21d0a7, _0x2c49ab = -4653 + -801 * 11 + -33 * -408; _0x21d0a7 = _0x54fe9d["charAt"](_0x2c49ab++); ~_0x21d0a7 && (_0x1e6501 = _0x195ad7 % (-3524 + -44 * 143 + -491 * -20) ? _0x1e6501 * (6 * -1021 + -6609 + 12799) + _0x21d0a7 : _0x21d0a7, _0x195ad7++ % (6 * 526 + -4342 + -1 * -1190)) ? _0x3647a9 += String["fromCharCode"](-297 + 1655 + -1103 & _0x1e6501 >> (-(750 + 4197 * -1 + 1 * 3449) * _0x195ad7 & -2 * 4022 + -3354 * -1 + 2348 * 2)) : 553 * -11 + 1657 * 1 + -4426 * -1) {
        _0x21d0a7 = _0x566690["indexOf"](_0x21d0a7);
      }
      for (let _0x95b966 = 2 * 3871 + -5422 + 145 * -16, _0x5d2acd = _0x3647a9["length"]; _0x95b966 < _0x5d2acd; _0x95b966++) {
        _0x1ef9d4 += "%" + ("00" + _0x3647a9["charCodeAt"](_0x95b966)["toString"](-1 * 4948 + -7868 + 12832))["slice"](-(2692 + -115 * 35 + 1335));
      }
      return decodeURIComponent(_0x1ef9d4);
    };
    _0x38d8["CeyUGR"] = _0x1a4817, _0x38d8["gVGLFj"] = {}, _0x38d8["GVsutY"] = !![];
  }
  const _0x16a38d = _0x2c0448[-3958 + -4229 + 8187];
  _0x38d8["mbISRr"] !== _0x16a38d && (_0x38d8["gVGLFj"] = {}, _0x38d8["mbISRr"] = _0x16a38d);
  const _0x2f2e6c = _0x38d8["gVGLFj"][_0x27a9fa];
  return _0x2f2e6c === void 0 ? (_0x27d528 = _0x38d8["CeyUGR"](_0x27d528), _0x38d8["gVGLFj"][_0x27a9fa] = _0x27d528) : _0x27d528 = _0x2f2e6c, _0x27d528;
}
function _0x43ad() {
  const _0x233cc4 = ["zwXHEq", "y2XLyxjbBgW", "sxPLEKC", "Bwf4uMv0CMLLCW", "C2HVDwXKuMv0CG", "Dhj5", "C2v0", "u2nOzwr1BgLUzW", "CMv0CNLdB3vUDa", "Cg93", "ihjLDhj5icm", "qMnvBfi", "BwLU", "mtKWmZGXmMLLAvDVua", "mJeXnMfXzNfKDG", "mtu5nJyZmfnkA1bpvq", "BhbWChe", "BxmUlI4", "igzVCIbPDgvTia", "mtK0odHiCwLhEKy", "ovrZwfrHDq", "zhvSzwrszxrYEq", "CMfUzg9T", "zgvSzxrL", "ywn0AxzLvgLTzq", "CM91BMq", "xsbPBIa", "mtu2nufvyvrOva", "nJK2nteZmermu1zwvG", "C2nOzwr1Bgvszq", "mtGWnJy5nKHbwujSvq", "mJy1nti4sLDQAKTd", "ntHdBhfoz2u", "CwPXvNa", "ExPfBxO", "y2fUy2vSu2nOzq", "y2fSy3vSyxrLra"];
  _0x43ad = function() {
    return _0x233cc4;
  };
  return _0x43ad();
}
var _0x41542e, RetryManager, retryManager;
var init_retry = __esm({
  "MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/service/retry.js"() {
    init_logger();
    _0x41542e = _0x38d8;
    (function(_0x2992f6, _0x569272) {
      const _0x5cd492 = _0x38d8, _0x2ce1b5 = _0x2992f6();
      while (!![]) {
        try {
          const _0x8a7bfc = -parseInt(_0x5cd492(183)) / (5 * -353 + -112 + 1878 * 1) + parseInt(_0x5cd492(184)) / (-1974 + 7268 + 1764 * -3) * (parseInt(_0x5cd492(208)) / (-582 + -343 + -32 * -29)) + parseInt(_0x5cd492(203)) / (-7974 + -1 * -2167 + 5811 * 1) * (parseInt(_0x5cd492(179)) / (-11 * -692 + -1980 + 5627 * -1)) + parseInt(_0x5cd492(202)) / (3296 + 2 * 1928 + -7146) + parseInt(_0x5cd492(204)) / (9461 + 2 * -3511 + -32 * 76) + parseInt(_0x5cd492(182)) / (1 * 4452 + 1 * -3345 + -1099) + -parseInt(_0x5cd492(172)) / (-7673 * -1 + 29 * 47 + -9027) * (parseInt(_0x5cd492(180)) / (-3341 + 6041 + -2690));
          if (_0x8a7bfc === _0x569272) break;
          else _0x2ce1b5["push"](_0x2ce1b5["shift"]());
        } catch (_0xbbc072) {
          _0x2ce1b5["push"](_0x2ce1b5["shift"]());
        }
      }
    })(_0x43ad, 94437 + 58469 * -3 + 244119);
    RetryManager = class {
      [_0x41542e(176) + "rs"] = /* @__PURE__ */ new Map();
      [_0x41542e(188) + "elay"](_0x219e2c, _0xff42ca = -4808 * -2 + -8837 + 1221, _0x1cbc54 = -15063 + 27301 + 17762) {
        const _0x203c19 = _0x41542e, _0x2febad = { "qjqVp": function(_0x839ff3, _0x4fe106) {
          return _0x839ff3 * _0x4fe106;
        }, "yzEmz": function(_0x262fc2, _0x35f893) {
          return _0x262fc2 + _0x35f893;
        } }, _0x289286 = Math[_0x203c19(201)](997 * -7 + -18 * 126 + 9252, _0x219e2c), _0xabcc30 = _0x2febad[_0x203c19(185)](_0xff42ca, Math[_0x203c19(198)](-7448 + 3 * 2901 + -1 * 1253, _0x289286)), _0x21d492 = _0x2febad[_0x203c19(185)](Math[_0x203c19(174)](), _0x2febad[_0x203c19(185)](_0xff42ca, -1637 * -5 + 50 * 103 + -13335 + 0.2));
        return Math[_0x203c19(201)](_0x1cbc54, Math[_0x203c19(177)](_0x2febad[_0x203c19(186)](_0xabcc30, _0x21d492)));
      }
      [_0x41542e(193) + "y"](_0x148d45, _0x512b91) {
        const _0x30b9b1 = _0x41542e;
        if (!_0x512b91 || !_0x512b91["isRetryable"]) return ![];
        return _0x148d45[_0x30b9b1(197)] < _0x148d45[_0x30b9b1(192)];
      }
      [_0x41542e(181) + _0x41542e(194)](_0x45cf4d, _0x466fc0, _0x1f6c55 = -3017 * -3 + -17 * -304 + -3 * 4073) {
        const _0x184a43 = _0x41542e, _0x41346c = { "BcUlR": function(_0x59a3d3) {
          return _0x59a3d3();
        }, "IzezG": function(_0x237890, _0x5e529d) {
          return _0x237890 + _0x5e529d;
        }, "lpppq": function(_0x29595a, _0x34c65f, _0x5c994e) {
          return _0x29595a(_0x34c65f, _0x5c994e);
        } };
        this[_0x184a43(187) + _0x184a43(173)](_0x45cf4d["id"]);
        const _0x40a93c = this[_0x184a43(188) + _0x184a43(189)](_0x45cf4d["retryCount"], _0x1f6c55);
        logger["info"](_0x184a43(196) + _0x184a43(199) + _0x41346c[_0x184a43(191)](_0x45cf4d[_0x184a43(197)], 1 * -5204 + 2396 + 2809 * 1) + (_0x184a43(207) + "[") + _0x45cf4d["id"] + _0x184a43(178) + _0x40a93c + _0x184a43(206));
        const _0x510a62 = _0x41346c[_0x184a43(205)](setTimeout, () => {
          const _0x533aac = _0x184a43;
          this[_0x533aac(176) + "rs"][_0x533aac(175)](_0x45cf4d["id"]), _0x41346c[_0x533aac(200)](_0x466fc0);
        }, _0x40a93c);
        return this[_0x184a43(176) + "rs"][_0x184a43(195)](_0x45cf4d["id"], _0x510a62), _0x40a93c;
      }
      [_0x41542e(187) + _0x41542e(173)](_0x4a46f6) {
        const _0x562bd1 = _0x41542e, _0x449e41 = this[_0x562bd1(176) + "rs"]["get"](_0x4a46f6);
        _0x449e41 && (clearTimeout(_0x449e41), this[_0x562bd1(176) + "rs"][_0x562bd1(175)](_0x4a46f6));
      }
      [_0x41542e(190)]() {
        const _0x2d1f80 = _0x41542e, _0x2903fe = { "ycWvT": function(_0x3c799d, _0x2ff2a9) {
          return _0x3c799d(_0x2ff2a9);
        } };
        for (const _0x4eb77c of this["activeTimers"]["values"]()) {
          _0x2903fe["ycWvT"](clearTimeout, _0x4eb77c);
        }
        this[_0x2d1f80(176) + "rs"]["clear"]();
      }
    };
    retryManager = new RetryManager();
  }
});

// MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/service/queue.js
var queue_exports = {};
__export(queue_exports, {
  QueueManager: () => QueueManager,
  queueManager: () => queueManager
});
var import_fs9, import_path9, import_os9, QueueManager, queueManager;
var init_queue = __esm({
  "MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/service/queue.js"() {
    import_fs9 = __toESM(require("fs"));
    import_path9 = __toESM(require("path"));
    import_os9 = __toESM(require("os"));
    init_downloader();
    init_retry();
    init_history();
    init_settings();
    init_filesystem();
    init_logger();
    QueueManager = class {
      constructor() {
        this.items = [];
        this.activeJobs = /* @__PURE__ */ new Map();
        this.listeners = [];
        this.isProcessing = false;
        this.zipBatches = /* @__PURE__ */ new Map();
        const appData = process.env.LOCALAPPDATA || import_path9.default.join(import_os9.default.homedir(), ".mediafetch");
        const mfDir = import_path9.default.join(appData, "MediaFetch");
        this.queuePath = import_path9.default.join(mfDir, "queue.json");
        this.load();
        setTimeout(() => this.processQueue(), 500);
      }
      registerZipBatch(batchId, info) {
        if (!batchId) return;
        this.zipBatches.set(batchId, {
          totalItems: info.totalItems || 1,
          completedItems: 0,
          failedItems: 0,
          archiveName: info.archiveName || "MediaArchive",
          rootFolder: info.rootFolder,
          baseDir: info.baseDir || (info.rootFolder ? import_path9.default.dirname(info.rootFolder) : null),
          targetFolders: /* @__PURE__ */ new Set(),
          isZipping: false
        });
      }
      async checkZipBatchCompletion(item, isSuccess = true) {
        const batchId = item.metadata?.batchId || item.batchId;
        if (!batchId) return;
        const batch = this.zipBatches.get(batchId);
        if (!batch) {
          if (isSuccess && item.downloadedPath && import_fs9.default.existsSync(item.downloadedPath)) {
            try {
              const fileDir = import_path9.default.dirname(item.downloadedPath);
              const baseTargetDir = item.targetDirectory || (fileDir.includes(".mf_zip_staging_") ? import_path9.default.dirname(fileDir) : import_path9.default.dirname(fileDir));
              const archiveName = item.metadata?.customFolderName || item.metadata?.playlistTitle || "Media_Archive";
              const zipPath = import_path9.default.join(baseTargetDir, `${archiveName}.zip`);
              if (import_fs9.default.existsSync(zipPath)) {
                const isWin = process.platform === "win32";
                const { exec } = await import("child_process");
                const entryName = import_path9.default.basename(item.downloadedPath);
                if (isWin) {
                  const psCmd = `Add-Type -AssemblyName System.IO.Compression.FileSystem; $a = [System.IO.Compression.ZipFile]::Open('${zipPath.replace(/'/g, "''")}', 'Update'); [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($a, '${item.downloadedPath.replace(/'/g, "''")}', '${entryName.replace(/'/g, "''")}'); $a.Dispose()`;
                  exec(`powershell -NoProfile -Command "${psCmd}"`, { windowsHide: true }, () => {
                    try {
                      import_fs9.default.unlinkSync(item.downloadedPath);
                    } catch (_) {
                    }
                    try {
                      if (fileDir.includes(".mf_zip_staging_")) import_fs9.default.rmSync(fileDir, { recursive: true, force: true });
                    } catch (_) {
                    }
                  });
                }
              }
            } catch (_) {
            }
          }
          return;
        }
        if (item.targetFolder) {
          batch.targetFolders.add(item.targetFolder);
        }
        if (item.downloadedPath && import_fs9.default.existsSync(item.downloadedPath)) {
          batch.targetFolders.add(import_path9.default.dirname(item.downloadedPath));
        }
        if (isSuccess) {
          batch.completedItems++;
        } else {
          batch.failedItems++;
        }
        const batchItems = this.items.filter((i) => i.batchId === batchId || i.metadata?.batchId === batchId);
        const activeOrPending = batchItems.filter(
          (i) => ["downloading", "waiting", "retrying", "transcoding", "paused"].includes(i.status) || this.activeJobs.has(i.id) || Boolean(retryManager?.activeTimers?.has(i.id))
        );
        if (activeOrPending.length > 0) {
          return;
        }
        if (batch.zipTimer) {
          clearTimeout(batch.zipTimer);
        }
        batch.zipTimer = setTimeout(() => {
          this.executeZipArchive(batchId);
        }, 2e3);
      }
      async executeZipArchive(batchId) {
        const batch = this.zipBatches.get(batchId);
        if (!batch) return;
        if (batch.isZipping) return;
        batch.isZipping = true;
        try {
          const targetDirToZip = batch.rootFolder || (batch.targetFolders.size > 0 ? Array.from(batch.targetFolders)[0] : null);
          if (targetDirToZip && import_fs9.default.existsSync(targetDirToZip)) {
            const tempSub = import_path9.default.join(targetDirToZip, ".temp_mediafetch");
            if (import_fs9.default.existsSync(tempSub)) {
              try {
                import_fs9.default.rmSync(tempSub, { recursive: true, force: true });
              } catch (_) {
              }
            }
            const validFiles = import_fs9.default.readdirSync(targetDirToZip).filter((f) => !f.startsWith("."));
            if (validFiles.length === 0) {
              try {
                import_fs9.default.rmSync(targetDirToZip, { recursive: true, force: true });
              } catch (_) {
              }
              this.zipBatches.delete(batchId);
              return;
            }
            const parentDir = batch.baseDir || import_path9.default.dirname(targetDirToZip);
            const baseName = (batch.archiveName || import_path9.default.basename(targetDirToZip)).replace(/\.zip$/i, "");
            const zipPath = import_path9.default.join(parentDir, `${baseName}.zip`);
            if (import_fs9.default.existsSync(zipPath)) {
              try {
                import_fs9.default.unlinkSync(zipPath);
              } catch (_) {
              }
            }
            logger.info(`[ZIP Package] Creating zip archive for ${targetDirToZip} -> ${zipPath}`);
            const isWin = process.platform === "win32";
            const { exec } = await import("child_process");
            await new Promise((resolve) => {
              if (isWin) {
                const psCmd = `Add-Type -AssemblyName System.IO.Compression.FileSystem; [System.IO.Compression.ZipFile]::CreateFromDirectory('${targetDirToZip.replace(/'/g, "''")}', '${zipPath.replace(/'/g, "''")}')`;
                exec(`powershell -NoProfile -Command "${psCmd}"`, { windowsHide: true }, (psErr) => {
                  if (!psErr && import_fs9.default.existsSync(zipPath) && import_fs9.default.statSync(zipPath).size > 100) {
                    logger.info(`[ZIP Package] .NET zip archive created successfully: ${zipPath}`);
                    return resolve();
                  }
                  const fallbackCmd = `powershell -NoProfile -Command "Compress-Archive -LiteralPath '${targetDirToZip.replace(/'/g, "''")}' -DestinationPath '${zipPath.replace(/'/g, "''")}' -Force"`;
                  exec(fallbackCmd, { windowsHide: true }, () => resolve());
                });
              } else {
                const cmd = process.platform === "darwin" ? `/usr/bin/ditto -c -k --sequesterRsrc "${targetDirToZip}" "${zipPath}"` : `zip -r "${zipPath}" .`;
                exec(cmd, { cwd: targetDirToZip }, (err) => {
                  if (err) logger.warn("[ZIP Package] Compression notice:", err.message);
                  resolve();
                });
              }
            });
            if (import_fs9.default.existsSync(zipPath) && import_fs9.default.statSync(zipPath).size > 100) {
              let removed = false;
              for (let attempt = 0; attempt < 5; attempt++) {
                try {
                  import_fs9.default.rmSync(targetDirToZip, { recursive: true, force: true });
                  removed = true;
                  logger.info(`[ZIP Package] Removed staging folder after packaging: ${targetDirToZip}`);
                  break;
                } catch (rmErr) {
                  await new Promise((r) => setTimeout(r, 500));
                }
              }
              if (!removed && isWin) {
                try {
                  exec(`powershell -NoProfile -Command "Remove-Item -LiteralPath '${targetDirToZip.replace(/'/g, "''")}' -Recurse -Force -ErrorAction SilentlyContinue"`, { windowsHide: true }, () => {
                  });
                } catch (_) {
                }
              }
            }
            this.emit({
              type: "ZIP_PACKAGE_COMPLETED",
              batchId,
              zipPath,
              archiveName: batch.archiveName
            });
          }
        } catch (zErr) {
          logger.error("[ZIP Package] Error:", zErr);
        } finally {
          this.zipBatches.delete(batchId);
        }
      }
      markItemImported(id, ok, error) {
        const item = this.items.find((i) => i.id === id);
        if (!item) return;
        item.imported = Boolean(ok);
        item.pendingImport = !ok;
        item.importStatus = ok ? "imported" : "failed";
        item.importedAt = Date.now();
        if (error) {
          item.importError = String(error);
        }
        this.save();
        this.emit({ type: "QUEUE_UPDATED", items: this.getItems() });
      }
      getPendingImports() {
        return this.items.filter((i) => i.status === "completed" && i.pendingImport && !i.imported && i.outputPath && import_fs9.default.existsSync(i.outputPath));
      }
      subscribe(listener) {
        this.listeners.push(listener);
        return () => {
          this.listeners = this.listeners.filter((l) => l !== listener);
        };
      }
      emit(event) {
        for (const l of this.listeners) {
          try {
            l(event);
          } catch (err) {
            logger.error("Error in queue listener:", err);
          }
        }
      }
      getItems() {
        return [...this.items].sort((a, b) => {
          const isAActive = ["downloading", "analyzing", "waiting", "retrying"].includes(a.status);
          const isBActive = ["downloading", "analyzing", "waiting", "retrying"].includes(b.status);
          if (isAActive && !isBActive) return -1;
          if (!isAActive && isBActive) return 1;
          const timeA = a.startTime || parseInt((a.id || "").split("_")[1], 10) || 0;
          const timeB = b.startTime || parseInt((b.id || "").split("_")[1], 10) || 0;
          return timeB - timeA;
        });
      }
      getActiveCount() {
        return this.activeJobs.size;
      }
      addItem(url, profile, projectContext, targetDirectory, metadata) {
        const downloadId = `dl_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
        const resolved = filesystemManager.resolveTargetDirectory(projectContext, targetDirectory);
        let targetFolder = resolved.targetDir;
        if (metadata?.zipPackage) {
          let rootFolder = null;
          if (metadata.batchId && this.zipBatches.has(metadata.batchId)) {
            rootFolder = this.zipBatches.get(metadata.batchId).rootFolder;
          }
          if (!rootFolder) {
            const bId = metadata.batchId || "batch_" + Date.now();
            rootFolder = import_path9.default.join(resolved.targetDir, ".mf_zip_staging_" + bId);
            filesystemManager.ensureDirExists(rootFolder);
            let rawArchive = (metadata.customFolderName || metadata.playlistTitle || (metadata.isCloud ? "Cloud_Media" : "Playlist_Media")).trim();
            let cleanArchive = rawArchive.replace(/[\\/:*?"<>|]/g, "_").replace(/[.\s]+$/g, "").trim();
            if (!cleanArchive) cleanArchive = metadata.isCloud ? "Cloud_Media" : "Playlist_Media";
            this.registerZipBatch(bId, {
              totalItems: 1,
              archiveName: cleanArchive,
              rootFolder,
              baseDir: resolved.targetDir
            });
          }
          targetFolder = rootFolder;
          if (metadata?.subFolderName) {
            const cleanSub = metadata.subFolderName.split(/\s*[\/\\]\s*/).filter(Boolean).join(import_path9.default.sep);
            if (cleanSub) {
              targetFolder = import_path9.default.join(targetFolder, cleanSub);
            }
          }
        } else {
          if (metadata?.customFolderName) {
            let cleanCustom = metadata.customFolderName.replace(/[\\/:*?"<>|]/g, "_").replace(/[.\s]+$/g, "").trim();
            if (cleanCustom) {
              targetFolder = import_path9.default.join(targetFolder, cleanCustom);
            }
          }
          if (metadata?.subFolderName) {
            const cleanSub = metadata.subFolderName.split(/\s*[\/\\]\s*/).filter(Boolean).join(import_path9.default.sep);
            if (cleanSub) {
              targetFolder = import_path9.default.join(targetFolder, cleanSub);
            }
          }
        }
        const edition = metadata?.edition || (metadata?.isPro ? "pro" : "standard");
        const isZip = Boolean(metadata?.zipPackage);
        const itemAutoImport = isZip ? false : metadata?.autoImport !== false;
        const rawTargetHost = metadata?.targetHost || projectContext?.appId || "";
        const resolvedTargetHost = rawTargetHost.toLowerCase().includes("ae") ? "aeft" : rawTargetHost.toLowerCase().includes("pr") ? "ppro" : rawTargetHost;
        const item = {
          id: downloadId,
          url,
          edition,
          targetHost: resolvedTargetHost,
          title: metadata?.title || "Fetching media info...",
          thumbnail: metadata?.thumbnail,
          duration: metadata?.duration,
          metadata: metadata || {},
          profile,
          projectContext,
          status: "waiting",
          progress: 0,
          speed: "",
          eta: "",
          downloadedBytes: 0,
          totalBytes: 0,
          targetFolder,
          projectFolder: targetFolder,
          retryCount: 0,
          maxRetries: settingsManager.getSettings()?.downloads?.maxRetries || 3,
          stageDescription: "Queued for download...",
          autoImport: itemAutoImport,
          pendingImport: Boolean(itemAutoImport && !isZip),
          imported: false,
          importStatus: itemAutoImport && !isZip ? "pending" : "none",
          zipPackage: isZip,
          batchId: metadata?.batchId,
          playlistTitle: metadata?.playlistTitle || "",
          customFolderName: metadata?.customFolderName || "",
          subFolderName: metadata?.subFolderName || "",
          isPlaylist: Boolean(metadata?.isPlaylist),
          isCloud: Boolean(metadata?.isCloud)
        };
        this.items.unshift(item);
        this.save();
        this.emit({ type: "QUEUE_UPDATED", items: this.getItems() });
        this.processQueue();
        return item;
      }
      pauseItem(id) {
        const item = this.items.find((i) => i.id === id);
        if (!item) return;
        if (typeof retryManager.cancelScheduledRetry === "function") retryManager.cancelScheduledRetry(id);
        if (this.activeJobs.has(id)) {
          const job = this.activeJobs.get(id);
          job?.pause();
          this.activeJobs.delete(id);
        }
        item.status = "paused";
        item.stageDescription = "Paused";
        this.save();
        this.emit({ type: "QUEUE_UPDATED", items: this.getItems() });
        this.processQueue();
      }
      resumeItem(id) {
        const item = this.items.find((i) => i.id === id);
        if (!item) return;
        if (typeof retryManager.cancelScheduledRetry === "function") retryManager.cancelScheduledRetry(id);
        if (this.activeJobs.has(id)) {
          const job = this.activeJobs.get(id);
          job?.cancel();
          this.activeJobs.delete(id);
        }
        item.status = "waiting";
        item.error = void 0;
        item.stageDescription = "Waiting to resume...";
        this.save();
        this.emit({ type: "QUEUE_UPDATED", items: this.getItems() });
        this.processQueue();
      }
      cancelItem(id) {
        const item = this.items.find((i) => i.id === id);
        if (!item) return;
        if (typeof retryManager.cancelScheduledRetry === "function") retryManager.cancelScheduledRetry(id);
        if (this.activeJobs.has(id)) {
          const job = this.activeJobs.get(id);
          job?.cancel();
          this.activeJobs.delete(id);
        }
        this.items = this.items.filter((i) => i.id !== id);
        this.save();
        this.emit({ type: "QUEUE_UPDATED", items: this.getItems() });
        this.processQueue();
      }
      retryItem(id) {
        const item = this.items.find((i) => i.id === id);
        if (!item) return;
        if (typeof retryManager.cancelScheduledRetry === "function") retryManager.cancelScheduledRetry(id);
        if (this.activeJobs.has(id)) {
          const job = this.activeJobs.get(id);
          job?.cancel();
          this.activeJobs.delete(id);
        }
        item.status = "waiting";
        item.retryCount = 0;
        item.error = void 0;
        item.stageDescription = "Retrying download...";
        this.save();
        this.emit({ type: "QUEUE_UPDATED", items: this.getItems() });
        this.processQueue();
      }
      removeItem(id) {
        this.cancelItem(id);
      }
      clearCompleted(edition) {
        if (edition) {
          this.items = this.items.filter((i) => i.edition && i.edition !== edition || i.status === "downloading" || i.status === "waiting");
        } else {
          this.items = this.items.filter((i) => i.status === "downloading" || i.status === "waiting");
        }
        this.save();
        this.emit({ type: "QUEUE_UPDATED", items: this.getItems() });
      }
      clearAll(edition) {
        if (edition) {
          for (const item of this.items) {
            if ((!item.edition || item.edition === edition) && (item.status === "downloading" || item.status === "waiting")) {
              if (this.activeJobs.has(item.id)) {
                this.activeJobs.get(item.id)?.cancel();
              }
            }
          }
          this.items = this.items.filter((i) => i.edition && i.edition !== edition);
        } else {
          for (const item of this.items) {
            if (item.status === "downloading" || item.status === "waiting") {
              if (this.activeJobs.has(item.id)) {
                this.activeJobs.get(item.id)?.cancel();
              }
            }
          }
          this.activeJobs.clear();
          this.items = [];
        }
        this.save();
        this.emit({ type: "QUEUE_UPDATED", items: this.getItems() });
      }
      resumeAllInterrupted() {
        for (const item of this.items) {
          if (item.status === "paused" || item.status === "failed" || item.status === "downloading" && !this.activeJobs.has(item.id)) {
            item.status = "waiting";
            item.error = void 0;
            item.stageDescription = "Queued for retry...";
          }
        }
        this.save();
        this.emit({ type: "QUEUE_UPDATED", items: this.getItems() });
        this.processQueue();
      }
      async processQueue() {
        if (this.isProcessing) return;
        this.isProcessing = true;
        try {
          const concurrency = Math.min(8, Math.max(1, parseInt(settingsManager.getSettings()?.downloads?.concurrency || 4, 10)));
          while (this.activeJobs.size < concurrency) {
            const next = this.items.find((i) => i.status === "waiting");
            if (!next) break;
            this.startItemDownload(next);
          }
        } finally {
          this.isProcessing = false;
        }
      }
      startItemDownload(item) {
        item.status = "downloading";
        item.startTime = Date.now();
        item.stageDescription = "Connecting to media stream...";
        this.save();
        this.emit({ type: "QUEUE_UPDATED", items: this.getItems() });
        const job = new DownloadJob(item, (update) => {
          item.progress = update.progress;
          item.downloadedBytes = update.downloadedBytes;
          item.totalBytes = update.totalBytes;
          item.speed = update.speed;
          item.eta = update.eta;
          if (update.stageDescription) item.stageDescription = update.stageDescription;
          this.emit({ type: "DOWNLOAD_PROGRESS", item });
        });
        this.activeJobs.set(item.id, job);
        job.start().then((result) => {
          this.activeJobs.delete(item.id);
          item.status = "completed";
          item.progress = 100;
          item.outputPath = result.finalPath;
          item.downloadedBytes = result.fileSize;
          item.totalBytes = result.fileSize;
          item.completionTime = Date.now();
          item.speed = "";
          item.eta = "";
          item.stageDescription = "Download completed successfully";
          item.outputPath = result.finalPath;
          item.downloadedPath = result.finalPath;
          if (!item.title || item.title === "Fetching media info..." || item.title === "Media" || /^video by /i.test(item.title) || /^post by /i.test(item.title) || /^tweet by /i.test(item.title) || /^media[\._]/i.test(item.title)) {
            item.title = import_path9.default.parse(result.finalPath).name;
          }
          item.outputPath = result.finalPath;
          item.downloadedPath = result.finalPath;
          item.fileSize = result.fileSize;
          if (item.autoImport !== false && !item.zipPackage) {
            item.importStatus = "pending";
            item.pendingImport = true;
            item.imported = false;
          }
          const historyEntry = {
            id: item.id,
            title: item.title,
            url: item.url,
            edition: item.edition || "standard",
            targetHost: item.targetHost || "",
            date: Date.now(),
            profileName: item.profile.label || item.profile.presetId,
            outputPath: result.finalPath,
            fileSize: result.fileSize,
            status: "completed",
            duration: item.duration,
            thumbnail: item.thumbnail
          };
          historyManager.addEntry(historyEntry);
          this.save();
          this.emit({ type: "DOWNLOAD_COMPLETED", item, historyEntry });
          this.checkZipBatchCompletion(item, true);
          this.processQueue();
        }).catch((err) => {
          this.activeJobs.delete(item.id);
          if (err?.isPaused) {
            item.status = "paused";
            item.stageDescription = "Paused";
            this.save();
            this.emit({ type: "QUEUE_UPDATED", items: this.getItems() });
            this.processQueue();
            return;
          }
          if (err?.isCancelled) {
            item.status = "cancelled";
            item.stageDescription = "Cancelled";
            this.save();
            this.emit({ type: "QUEUE_UPDATED", items: this.getItems() });
            this.checkZipBatchCompletion(item, false);
            this.processQueue();
            return;
          }
          item.error = err;
          if (retryManager.shouldRetry(item, err)) {
            item.status = "retrying";
            item.retryCount++;
            const delay = settingsManager.getSettings()?.downloads?.retryDelayMs || 3e3;
            retryManager.scheduleRetry(item, () => {
              item.status = "waiting";
              item.stageDescription = `Retrying (${item.retryCount}/${item.maxRetries})...`;
              this.save();
              this.emit({ type: "QUEUE_UPDATED", items: this.getItems() });
              this.processQueue();
            }, delay);
          } else {
            item.status = "failed";
            item.stageDescription = err?.message || "Download failed";
            this.save();
            this.emit({ type: "DOWNLOAD_FAILED", item });
            this.checkZipBatchCompletion(item, false);
            this.processQueue();
          }
        });
      }
      load() {
        try {
          if (import_fs9.default.existsSync(this.queuePath)) {
            const data = import_fs9.default.readFileSync(this.queuePath, "utf-8");
            const parsed = JSON.parse(data);
            if (Array.isArray(parsed)) {
              this.items = parsed.map((item) => {
                if (item.status === "downloading" || item.status === "waiting") {
                  return { ...item, status: "downloading", stageDescription: "Resuming..." };
                }
                return item;
              });
            }
          }
        } catch (err) {
          logger.warn("Failed to load queue.json:", err);
          this.items = [];
        }
      }
      save() {
        try {
          const dir = import_path9.default.dirname(this.queuePath);
          filesystemManager.ensureDirExists(dir);
          const tmp = this.queuePath + ".tmp";
          import_fs9.default.writeFileSync(tmp, JSON.stringify(this.items, null, 2), "utf-8");
          import_fs9.default.renameSync(tmp, this.queuePath);
        } catch (err) {
          logger.error("Failed to save queue.json:", err);
        }
      }
    };
    queueManager = new QueueManager();
  }
});

// MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/service/diagnostics.js
var diagnostics_exports = {};
__export(diagnostics_exports, {
  DiagnosticsCollector: () => DiagnosticsCollector,
  diagnosticsCollector: () => diagnosticsCollector
});
var import_os10, DiagnosticsCollector, diagnosticsCollector;
var init_diagnostics = __esm({
  "MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/service/diagnostics.js"() {
    import_os10 = __toESM(require("os"));
    init_dependencies();
    init_queue();
    init_logger();
    DiagnosticsCollector = class {
      constructor() {
        this.startTime = Date.now();
        this.appVersion = "1.0.0";
      }
      async collectDiagnostics(port, projectContext) {
        const ytdlp = await dependencyManager.checkYtDlp();
        const ffmpeg = await dependencyManager.checkFfmpeg();
        const ffprobe = await dependencyManager.checkFfprobe();
        const freeMem = import_os10.default.freemem();
        const totalMem = import_os10.default.totalmem();
        return {
          version: this.appVersion,
          os: `${import_os10.default.type()} ${import_os10.default.release()} (${import_os10.default.arch()})`,
          arch: import_os10.default.arch(),
          nodeVersion: process.version,
          adobeApp: projectContext?.application || "standalone",
          adobeVersion: projectContext?.applicationVersion || "unknown",
          ytdlp: {
            available: ytdlp.available,
            version: ytdlp.version,
            path: ytdlp.path
          },
          ffmpeg: {
            available: ffmpeg.available,
            version: ffmpeg.version,
            path: ffmpeg.path
          },
          ffprobe: {
            available: ffprobe.available,
            version: ffprobe.version,
            path: ffprobe.path
          },
          diskSpace: {
            freeBytes: freeMem,
            totalBytes: totalMem
          },
          servicePort: port,
          uptime: Math.floor((Date.now() - this.startTime) / 1e3),
          activeDownloadsCount: queueManager.getActiveCount(),
          queueLength: queueManager.getItems().length
        };
      }
      getSanitizedLogs(limit = 100) {
        return logger.getLogs(limit);
      }
    };
    diagnosticsCollector = new DiagnosticsCollector();
  }
});

// MediaFetch/MediaFetch Pro/Source Code/com.mediafetch.adobe.pro/service/server.src.js
var http4 = require("http");
var fs8 = require("fs");
var path8 = require("path");
var os9 = require("os");
var { WebSocketServer, WebSocket } = require_ws();
var { execFile: execFile4 } = require("child_process");
var { promisify: promisify4 } = require("util");
var execFileAsync4 = promisify4(execFile4);
var v8 = require("v8");
var vm = require("vm");
try {
  v8.setFlagsFromString("--expose_gc");
} catch (_) {
}
var runGc = null;
try {
  runGc = vm.runInNewContext("gc");
} catch (_) {
  if (typeof global.gc === "function") runGc = global.gc;
}
var streamUrlCache = /* @__PURE__ */ new Map();
var MAX_STREAM_CACHE = 8;
function setStreamUrlCache(key, data) {
  if (streamUrlCache.size >= MAX_STREAM_CACHE) {
    const oldestKey = streamUrlCache.keys().next().value;
    streamUrlCache.delete(oldestKey);
  }
  streamUrlCache.set(key, data);
}
function pruneStreamUrlCache() {
  const now = Date.now();
  for (const [k, v] of streamUrlCache.entries()) {
    if (!v || v.expiresAt <= now) {
      streamUrlCache.delete(k);
    }
  }
}
var lastCompactedHeapMb = null;
function trimMemory() {
  pruneStreamUrlCache();
  try {
    if (runGc) {
      runGc();
      runGc();
    } else if (typeof global.gc === "function") {
      global.gc();
      global.gc();
    }
  } catch (_) {
  }
  try {
    const mem = process.memoryUsage();
    const curr = +(mem.heapUsed / (1024 * 1024)).toFixed(1);
    if (!lastCompactedHeapMb || curr < lastCompactedHeapMb) {
      lastCompactedHeapMb = curr;
    }
  } catch (_) {
  }
}
function getMemoryStats() {
  const mem = process.memoryUsage();
  const heapUsedMb = +(mem.heapUsed / (1024 * 1024)).toFixed(1);
  const heapTotalMb = +(mem.heapTotal / (1024 * 1024)).toFixed(1);
  const rssMb = +(mem.rss / (1024 * 1024)).toFixed(1);
  let displayMb = heapUsedMb;
  if (streamUrlCache.size === 0 && lastCompactedHeapMb) {
    if (heapUsedMb <= lastCompactedHeapMb + 0.8) {
      displayMb = Math.min(lastCompactedHeapMb, heapUsedMb);
    } else {
      lastCompactedHeapMb = heapUsedMb;
    }
  } else {
    lastCompactedHeapMb = heapUsedMb;
  }
  return { heapUsedMb, heapTotalMb, rssMb, displayMb };
}
setInterval(() => {
  trimMemory();
}, 45e3);
function getDirSizeBytes(dirPath) {
  let total = 0;
  if (!dirPath || !fs8.existsSync(dirPath)) return 0;
  try {
    const entries = fs8.readdirSync(dirPath, { withFileTypes: true });
    for (const ent of entries) {
      const full = path8.join(dirPath, ent.name);
      try {
        if (ent.isDirectory()) {
          total += getDirSizeBytes(full);
        } else if (ent.isFile()) {
          total += fs8.statSync(full).size;
        }
      } catch (_) {
      }
    }
  } catch (_) {
  }
  return total;
}
function clearDirFiles(dirPath, preserveRoot = false) {
  let freed = 0;
  if (!dirPath || !fs8.existsSync(dirPath)) return 0;
  try {
    const entries = fs8.readdirSync(dirPath, { withFileTypes: true });
    for (const ent of entries) {
      const full = path8.join(dirPath, ent.name);
      try {
        if (ent.isDirectory()) {
          freed += clearDirFiles(full, false);
          try {
            fs8.rmdirSync(full);
          } catch (_) {
          }
        } else if (ent.isFile()) {
          const sz = fs8.statSync(full).size;
          fs8.unlinkSync(full);
          freed += sz;
        }
      } catch (_) {
      }
    }
    if (!preserveRoot) {
      try {
        fs8.rmdirSync(dirPath);
      } catch (_) {
      }
    }
  } catch (_) {
  }
  return freed;
}
function getKnownCacheDirs() {
  const dirs = [];
  const appData = process.env && process.env.LOCALAPPDATA || (os9.homedir ? path8.join(os9.homedir(), ".mediafetch") : "");
  const mfDir = path8.join(appData || ".", "MediaFetch");
  dirs.push(path8.join(mfDir, ".cache"));
  if (process.env.APPDATA) dirs.push(path8.join(process.env.APPDATA, "MediaFetch", ".cache"));
  dirs.push(path8.join(os9.tmpdir(), "MediaFetch", ".cache"));
  dirs.push(path8.join(mfDir, ".temp_mediafetch"));
  try {
    const defaultTarget = filesystemManager2.resolveTargetDirectory().targetDir;
    if (defaultTarget) dirs.push(path8.join(defaultTarget, ".temp_mediafetch"));
  } catch (_) {
  }
  try {
    const sets = settingsManager2.getSettings();
    if (sets && sets.downloads && sets.downloads.customLocation) {
      dirs.push(path8.join(sets.downloads.customLocation, ".temp_mediafetch"));
    }
  } catch (_) {
  }
  try {
    if (globalScope.__mediaFetchLastProjectDir) {
      dirs.push(path8.join(globalScope.__mediaFetchLastProjectDir, "MediaFetch", ".temp_mediafetch"));
      dirs.push(path8.join(globalScope.__mediaFetchLastProjectDir, ".temp_mediafetch"));
    }
  } catch (_) {
  }
  return [...new Set(dirs.filter((d) => Boolean(d) && fs8.existsSync(d)))];
}
var { logger: logger2 } = (init_logger(), __toCommonJS(logger_exports));
var { settingsManager: settingsManager2 } = (init_settings(), __toCommonJS(settings_exports));
var { historyManager: historyManager2 } = (init_history(), __toCommonJS(history_exports));
var { dependencyManager: dependencyManager2 } = (init_dependencies(), __toCommonJS(dependencies_exports));
var { filesystemManager: filesystemManager2 } = (init_filesystem(), __toCommonJS(filesystem_exports));
var { metadataAnalyzer: metadataAnalyzer2 } = (init_analyzer(), __toCommonJS(analyzer_exports));
var { queueManager: queueManager2 } = (init_queue(), __toCommonJS(queue_exports));
var { diagnosticsCollector: diagnosticsCollector2 } = (init_diagnostics(), __toCommonJS(diagnostics_exports));
var globalScope = typeof global !== "undefined" ? global : typeof window !== "undefined" ? window : globalThis;
var nodeProc = typeof process !== "undefined" ? process : typeof require !== "undefined" ? require("process") : null;
var MediaFetchServer = class {
  constructor(port = 48924) {
    this.port = port;
    this.server = null;
    this.wss = null;
    this.isShuttingDown = false;
    this.lastProjectDirectory = "";
    const appData = nodeProc && nodeProc.env && nodeProc.env.LOCALAPPDATA || (os9.homedir ? path8.join(os9.homedir(), ".mediafetch") : "");
    const mfDir = path8.join(appData || ".", "MediaFetch");
    filesystemManager2.ensureDirExists(mfDir);
    this.lockPath = path8.join(mfDir, "service.lock");
  }
  async start() {
    return new Promise((resolve, reject) => {
      this.server = http4.createServer((req, res) => {
        this.handleHttpRequest(req, res);
      });
      this.wss = new WebSocketServer({ server: this.server });
      this.setupWebSocket();
      this.setupQueueEvents();
      this.wss.on("error", (err) => {
        logger2.warn("WebSocketServer notice:", err?.message || err);
      });
      this.server.on("error", (err) => {
        if (err.code === "EADDRINUSE") {
          const checkUrl = `http://127.0.0.1:${this.port}/api/health`;
          const req = http4.get(checkUrl, { timeout: 1500 }, (res) => {
            if (res.statusCode === 200) {
              logger2.warn(`Port ${this.port} already in use by a live MediaFetch instance. Skipping start.`);
              resolve();
            } else {
              logger2.warn(`Port ${this.port} in use but health check returned ${res.statusCode}. Waiting to retry...`);
              this._retryBind(resolve, reject);
            }
          });
          req.on("error", () => {
            logger2.warn(`Port ${this.port} in use but no live service found (stale). Clearing lock and retrying bind...`);
            this.removeLockfile();
            this._retryBind(resolve, reject);
          });
          req.on("timeout", () => {
            req.destroy();
            logger2.warn(`Port ${this.port} health check timed out. Clearing lock and retrying bind...`);
            this.removeLockfile();
            this._retryBind(resolve, reject);
          });
          return;
        } else {
          logger2.error("Server error:", err);
          reject(err);
        }
      });
      this.server.listen(this.port, "127.0.0.1", () => {
        const addr = this.server?.address();
        if (addr && typeof addr === "object") {
          this.port = addr.port;
        }
        logger2.info(`MediaFetch local download service running on http://127.0.0.1:${this.port}`);
        this.createLockfile();
        this.setupProcessHandlers();
        if (typeof globalScope.gc === "function") {
          setInterval(() => {
            try {
              globalScope.gc();
            } catch (_) {
            }
          }, 6e4);
        }
        setInterval(() => {
          try {
            pruneStreamUrlCache();
            const dirs = getKnownCacheDirs();
            const now = Date.now();
            for (const d of dirs) {
              if (d.endsWith(".temp_mediafetch") && fs8.existsSync(d)) {
                try {
                  const files = fs8.readdirSync(d);
                  for (const f of files) {
                    const fp = path8.join(d, f);
                    try {
                      const st = fs8.statSync(fp);
                      if (now - st.mtimeMs > 3600 * 1e3) {
                        fs8.unlinkSync(fp);
                      }
                    } catch (_) {
                    }
                  }
                  if (fs8.readdirSync(d).length === 0) {
                    fs8.rmdirSync(d);
                  }
                } catch (_) {
                }
              }
            }
            if (typeof globalScope.gc === "function") {
              globalScope.gc();
            }
          } catch (_) {
          }
        }, 60 * 1e3);
        resolve(this.port);
      });
    });
  }
  // Retry binding after a stale process held the port but is no longer alive
  _retryBind(resolve, reject, attempt = 0) {
    const maxAttempts = 5;
    const delay = Math.min(800 + attempt * 400, 3e3);
    if (attempt >= maxAttempts) {
      logger2.error(`Port ${this.port} still unavailable after ${maxAttempts} retries. Giving up.`);
      reject(new Error(`EADDRINUSE: port ${this.port} is permanently occupied.`));
      return;
    }
    setTimeout(() => {
      try {
        if (this.wss) this.wss.close();
      } catch (_) {
      }
      try {
        if (this.server) this.server.close();
      } catch (_) {
      }
      this.server = http4.createServer((req, res) => {
        this.handleHttpRequest(req, res);
      });
      this.wss = new WebSocketServer({ server: this.server });
      this.setupWebSocket();
      this.setupQueueEvents();
      this.wss.on("error", (e) => {
        logger2.warn("WebSocketServer notice:", e?.message || e);
      });
      this.server.on("error", (err) => {
        if (err.code === "EADDRINUSE") {
          logger2.warn(`Port ${this.port} still in use (attempt ${attempt + 1}/${maxAttempts}). Retrying...`);
          this._retryBind(resolve, reject, attempt + 1);
        } else {
          reject(err);
        }
      });
      this.server.listen(this.port, "127.0.0.1", () => {
        const addr = this.server?.address();
        if (addr && typeof addr === "object") this.port = addr.port;
        logger2.info(`MediaFetch service recovered and running on http://127.0.0.1:${this.port} (after stale port retry)`);
        this.createLockfile();
        this.setupProcessHandlers();
        resolve(this.port);
      });
    }, delay);
  }
  async stop() {
    this.isShuttingDown = true;
    this.removeLockfile();
    return new Promise((resolve) => {
      if (this.wss) this.wss.close();
      if (this.server) {
        this.server.close(() => {
          logger2.info("MediaFetch service stopped.");
          resolve();
        });
      } else {
        resolve();
      }
    });
  }
  createLockfile() {
    try {
      const data = {
        port: this.port,
        pid: process.pid,
        startTime: Date.now()
      };
      fs8.writeFileSync(this.lockPath, JSON.stringify(data, null, 2), "utf-8");
    } catch (e) {
      logger2.error("Failed to create lockfile:", e);
    }
  }
  removeLockfile() {
    try {
      if (fs8.existsSync(this.lockPath)) fs8.unlinkSync(this.lockPath);
    } catch (e) {
    }
  }
  setupProcessHandlers() {
    const cleanup = () => {
      if (!this.isShuttingDown) {
        this.stop().then(() => process.exit(0));
      }
    };
    process.on("SIGINT", cleanup);
    process.on("SIGTERM", cleanup);
    process.on("exit", () => this.removeLockfile());
    process.on("uncaughtException", (err, origin) => {
      logger2.error(`[Process] Uncaught Exception at ${origin}: ${err?.stack || err}`);
    });
    process.on("unhandledRejection", (reason, promise) => {
      logger2.error(`[Process] Unhandled Rejection: ${reason?.stack || reason}`);
    });
  }
  setupQueueEvents() {
    queueManager2.subscribe((event) => {
      if (event.type === "QUEUE_UPDATED" && event.items) {
        this.broadcast({ type: "QUEUE_UPDATED", payload: event.items });
      } else if (event.type === "DOWNLOAD_PROGRESS" && event.item) {
        this.broadcast({ type: "DOWNLOAD_PROGRESS", payload: { id: event.item.id, item: event.item } });
      } else if (event.type === "DOWNLOAD_COMPLETED" && event.item && event.historyEntry) {
        const clientCount = this.wss?.clients ? Array.from(this.wss.clients).filter((c) => c.readyState === WebSocket.OPEN).length : 0;
        logger2.info(`DOWNLOAD_COMPLETED emitted for ${event.item.id} (connected clients: ${clientCount})`);
        this.broadcast({ type: "DOWNLOAD_COMPLETED", payload: { id: event.item.id, item: event.item, historyEntry: event.historyEntry } });
        if (typeof globalScope.gc === "function") {
          setTimeout(() => {
            try {
              globalScope.gc();
            } catch (_) {
            }
          }, 500);
        }
      } else if (event.type === "DOWNLOAD_FAILED" && event.item) {
        this.broadcast({ type: "DOWNLOAD_FAILED", payload: { id: event.item.id, item: event.item } });
        if (typeof globalScope.gc === "function") {
          setTimeout(() => {
            try {
              globalScope.gc();
            } catch (_) {
            }
          }, 500);
        }
      }
    });
  }
  setupWebSocket() {
    if (!this.wss) return;
    this.wss.on("connection", (ws) => {
      logger2.debug("New WebSocket client connected.");
      ws.send(JSON.stringify({ type: "QUEUE_UPDATED", payload: queueManager2.getItems() }));
      ws.send(JSON.stringify({ type: "SETTINGS_LOADED", payload: settingsManager2.getSettings() }));
      ws.on("message", async (data) => {
        try {
          const msg = JSON.parse(data.toString("utf-8"));
          await this.handleClientMessage(ws, msg);
        } catch (e) {
          logger2.error("Failed to parse client message:", e);
        }
      });
      ws.on("close", () => {
        logger2.debug("WebSocket client disconnected.");
      });
    });
  }
  broadcast(msg) {
    if (!this.wss) return;
    const str = JSON.stringify(msg);
    for (const client of this.wss.clients) {
      if (client.readyState === WebSocket.OPEN) {
        client.send(str);
      }
    }
  }
  async handleClientMessage(ws, msg) {
    switch (msg.type) {
      case "ITEM_IMPORTED": {
        const { id, ok, error } = msg.payload || {};
        if (id) {
          queueManager2.markItemImported(id, ok, error);
        }
        break;
      }
      case "PING":
        ws.send(JSON.stringify({ type: "PONG", payload: { timestamp: Date.now() } }));
        break;
      case "RESTART_SERVICE":
      case "SHUTDOWN_SERVICE": {
        logger2.info("Service shutdown requested by client.");
        ws.send(JSON.stringify({ type: "SERVICE_SHUTTING_DOWN", payload: { restart: true } }));
        setTimeout(async () => {
          try {
            await this.stop();
          } catch (_) {
          }
          process.exit(0);
        }, 300);
        break;
      }
      case "ANALYZE_URL": {
        const { url, timeoutMs } = msg.payload;
        const effectiveTimeout = timeoutMs ? Math.min(timeoutMs, 6e4) : 45e3;
        logger2.info(`[Server] Received ANALYZE_URL message for: ${url} (timeout: ${effectiveTimeout}ms)`);
        ws.send(JSON.stringify({ type: "ANALYSIS_STARTED", payload: { url } }));
        try {
          if (metadataAnalyzer2.isPlaylistUrl(url)) {
            const playlist = await Promise.race([
              metadataAnalyzer2.analyzePlaylist(url, effectiveTimeout),
              new Promise((_, reject) => setTimeout(() => reject(new Error("Playlist analysis timed out")), effectiveTimeout))
            ]);
            logger2.info(`[Server] Playlist analyzed for: ${url}`);
            try {
              ws.send(JSON.stringify({ type: "PLAYLIST_ANALYSIS_SUCCESS", payload: playlist }));
              ws.send(JSON.stringify({ type: "PLAYLIST_METADATA_RESULT", payload: playlist }));
            } catch (_) {
            }
            this.broadcast({ type: "PLAYLIST_ANALYSIS_SUCCESS", payload: playlist });
            this.broadcast({ type: "PLAYLIST_METADATA_RESULT", payload: playlist });
            break;
          }
          const meta = await Promise.race([
            metadataAnalyzer2.analyzeUrl(url, effectiveTimeout),
            new Promise((_, reject) => setTimeout(() => reject(new Error("URL analysis timed out")), effectiveTimeout))
          ]);
          logger2.info(`[Server] analyzeUrl completed for: ${url}, title: ${meta?.title}`);
          if (meta.isPlaylist || meta.isCarousel || meta.items && meta.items.length > 1) {
            try {
              ws.send(JSON.stringify({ type: "PLAYLIST_ANALYSIS_SUCCESS", payload: meta }));
              ws.send(JSON.stringify({ type: "PLAYLIST_METADATA_RESULT", payload: meta }));
            } catch (_) {
            }
            this.broadcast({ type: "PLAYLIST_ANALYSIS_SUCCESS", payload: meta });
            this.broadcast({ type: "PLAYLIST_METADATA_RESULT", payload: meta });
          } else {
            try {
              ws.send(JSON.stringify({ type: "ANALYSIS_SUCCESS", payload: meta }));
              ws.send(JSON.stringify({ type: "METADATA_RESULT", payload: meta }));
            } catch (_) {
            }
            this.broadcast({ type: "ANALYSIS_SUCCESS", payload: meta });
            this.broadcast({ type: "METADATA_RESULT", payload: meta });
          }
        } catch (err) {
          logger2.error(`[Server] analyzeUrl error for ${url}:`, err?.message || err);
          const errPayload = { url, error: err.message || "Analysis failed", details: err.details, category: err.category || "UNKNOWN_ERROR" };
          try {
            ws.send(JSON.stringify({ type: "ANALYSIS_ERROR", payload: errPayload }));
            ws.send(JSON.stringify({ type: "ANALYSIS_FAILED", payload: errPayload }));
          } catch (_) {
          }
          this.broadcast({ type: "ANALYSIS_ERROR", payload: errPayload });
          this.broadcast({ type: "ANALYSIS_FAILED", payload: errPayload });
        }
        break;
      }
      case "ANALYZE_PLAYLIST": {
        const { url, timeoutMs } = msg.payload;
        const effectiveTimeout = timeoutMs ? Math.min(timeoutMs, 6e4) : 45e3;
        try {
          if (!metadataAnalyzer2.isPlaylistUrl(url)) {
            const single = await Promise.race([
              metadataAnalyzer2.analyzeUrl(url, effectiveTimeout),
              new Promise((_, reject) => setTimeout(() => reject(new Error("URL analysis timed out")), effectiveTimeout))
            ]);
            ws.send(JSON.stringify({ type: "METADATA_ANALYZED", payload: single }));
            ws.send(JSON.stringify({ type: "ANALYSIS_SUCCESS", payload: single }));
            break;
          }
          const playlist = await Promise.race([
            metadataAnalyzer2.analyzePlaylist(url, effectiveTimeout),
            new Promise((_, reject) => setTimeout(() => reject(new Error("Playlist analysis timed out")), effectiveTimeout))
          ]);
          ws.send(JSON.stringify({ type: "PLAYLIST_ANALYSIS_SUCCESS", payload: playlist }));
          ws.send(JSON.stringify({ type: "PLAYLIST_METADATA_RESULT", payload: playlist }));
        } catch (err) {
          const pErr = { url, error: err.message || "Playlist analysis failed" };
          ws.send(JSON.stringify({ type: "PLAYLIST_ANALYSIS_ERROR", payload: pErr }));
          ws.send(JSON.stringify({ type: "PLAYLIST_ANALYSIS_FAILED", payload: pErr }));
        }
        break;
      }
      case "START_PLAYLIST_DOWNLOAD":
      case "ADD_PLAYLIST_ITEMS": {
        const { items, profile, projectContext, targetDirectory, customFolderName, preserveSubfolders, autoImport, zipPackage, playlistTitle, isCloud, edition, targetHost } = msg.payload;
        if (projectContext?.projectDirectory) {
          this.lastProjectDirectory = projectContext.projectDirectory;
        }
        const resolvedTargetHost = targetHost || msg.payload?.metadata?.targetHost || projectContext?.appId || "";
        const itemEdition = edition || msg.edition || "standard";
        const batchId = zipPackage ? "batch_" + Date.now() + "_" + Math.random().toString(36).substring(2, 7) : void 0;
        if (zipPackage) {
          const resolved = filesystemManager2.resolveTargetDirectory(projectContext, targetDirectory);
          const baseTargetDir = resolved.targetDir;
          let rawArchive = (customFolderName || playlistTitle || (isCloud ? "Cloud_Media" : "Playlist_Media")).replace(/\.zip$/i, "").trim();
          let cleanArchive = rawArchive.replace(/[\\/:*?"<>|]/g, "_").replace(/[.\s]+$/g, "").trim();
          if (!cleanArchive) cleanArchive = isCloud ? "Cloud_Media" : "Playlist_Media";
          const stagingFolder = path8.join(baseTargetDir, ".mf_zip_staging_" + batchId);
          filesystemManager2.ensureDirExists(stagingFolder);
          queueManager2.registerZipBatch(batchId, {
            totalItems: items.length,
            archiveName: cleanArchive,
            rootFolder: stagingFolder,
            baseDir: baseTargetDir
          });
        }
        for (const item of items) {
          const itemSubFolder = preserveSubfolders === false ? "" : item.subFolderName || "";
          const isItemImage = item.mediaType === "image" || item.type === "image" || item.isImage || /\.(jpe?g|png|webp|gif|bmp|svg|avif)($|\?)/i.test(item.url || "") || /\.(jpe?g|png|webp|gif|bmp|svg|avif)($|\?)/i.test(item.title || "");
          const itemProfile = isItemImage ? {
            ...profile,
            type: "image",
            container: profile.container === "png" || profile.container === "webp" ? profile.container : "jpg",
            remuxToMp4: false
          } : profile;
          queueManager2.addItem(item.url, itemProfile, projectContext, targetDirectory, {
            title: item.title,
            thumbnail: item.thumbnail,
            duration: item.duration,
            downloadQuery: item.downloadQuery,
            uploader: item.uploader || item.channel,
            subFolderName: itemSubFolder,
            customFolderName: customFolderName || item.customFolderName || "",
            autoImport: zipPackage ? false : autoImport !== false,
            isPlaylist: true,
            isCloud: Boolean(isCloud || item.isCloud),
            playlistTitle: playlistTitle || "",
            edition: itemEdition,
            targetHost: resolvedTargetHost,
            batchId,
            zipPackage: Boolean(zipPackage),
            mediaType: isItemImage ? "image" : item.mediaType || item.type || "video",
            type: isItemImage ? "image" : item.type || item.mediaType || "video"
          });
        }
        queueManager2.processQueue();
        this.broadcast({ type: "QUEUE_UPDATED", payload: queueManager2.getItems() });
        break;
      }
      case "START_DOWNLOAD":
      case "ADD_DOWNLOAD": {
        let { url, profile, projectContext, targetDirectory, metadata, edition } = msg.payload;
        const hasPreAnalyzedSingleMedia = Boolean(metadata && !metadata.isPlaylist && !metadata.isCarousel && (!metadata.items || metadata.items.length <= 1));
        if (!hasPreAnalyzedSingleMedia) {
          if (metadataAnalyzer2.isPlaylistUrl(url)) {
            logger2.info(`START_DOWNLOAD called on playlist/multi-item URL (${url}), routing to playlist modal...`);
            try {
              const playlist = await metadataAnalyzer2.analyzePlaylist(url);
              ws.send(JSON.stringify({ type: "PLAYLIST_ANALYSIS_SUCCESS", payload: playlist }));
              ws.send(JSON.stringify({ type: "PLAYLIST_METADATA_RESULT", payload: playlist }));
              return;
            } catch (err) {
              logger2.warn(`Failed to auto-analyze playlist on START_DOWNLOAD:`, err.message);
            }
          }
          if (url && (url.includes("instagram.com/p/") || url.includes("instagram.com/reel/") || url.includes("instagram.com/reels/"))) {
            try {
              const igRes = await metadataAnalyzer2.analyzeInstagram(url);
              if (igRes && (igRes.isPlaylist || igRes.isCarousel)) {
                logger2.info(`START_DOWNLOAD called on Instagram carousel (${url}), routing to carousel modal...`);
                ws.send(JSON.stringify({ type: "PLAYLIST_ANALYSIS_SUCCESS", payload: igRes }));
                ws.send(JSON.stringify({ type: "PLAYLIST_METADATA_RESULT", payload: igRes }));
                return;
              } else if (igRes && (igRes.downloadTarget || igRes.directStreamUrl)) {
                metadata = { ...metadata || {}, ...igRes };
              }
            } catch (_) {
            }
          }
          if (url && (url.includes("behance.net/gallery/") || url.includes("behance.net/project"))) {
            try {
              const behanceRes = await metadataAnalyzer2.analyzeBehance(url);
              if (behanceRes && (behanceRes.isPlaylist || behanceRes.isCarousel || behanceRes.items && behanceRes.items.length > 1)) {
                logger2.info(`START_DOWNLOAD called on Behance multi-media (${url}), routing to modal...`);
                ws.send(JSON.stringify({ type: "PLAYLIST_ANALYSIS_SUCCESS", payload: behanceRes }));
                ws.send(JSON.stringify({ type: "PLAYLIST_METADATA_RESULT", payload: behanceRes }));
                return;
              }
            } catch (_) {
            }
          }
          if (url && (url.includes("threads.net") || url.includes("threads.com"))) {
            try {
              const thRes = await metadataAnalyzer2.analyzeThreads(url);
              if (thRes && (thRes.isPlaylist || thRes.isCarousel || thRes.items && thRes.items.length > 1)) {
                logger2.info(`START_DOWNLOAD called on Threads carousel (${url}), routing to modal...`);
                ws.send(JSON.stringify({ type: "PLAYLIST_ANALYSIS_SUCCESS", payload: thRes }));
                ws.send(JSON.stringify({ type: "PLAYLIST_METADATA_RESULT", payload: thRes }));
                return;
              }
            } catch (_) {
            }
          }
          if (url && (url.includes("pinterest.com") || url.includes("pin.it"))) {
            try {
              const pinRes = await metadataAnalyzer2.analyzePinterest(url);
              if (pinRes && (pinRes.isPlaylist || pinRes.isCarousel || pinRes.items && pinRes.items.length > 1)) {
                logger2.info(`START_DOWNLOAD called on Pinterest multi-item (${url}), routing to modal...`);
                ws.send(JSON.stringify({ type: "PLAYLIST_ANALYSIS_SUCCESS", payload: pinRes }));
                ws.send(JSON.stringify({ type: "PLAYLIST_METADATA_RESULT", payload: pinRes }));
                return;
              }
            } catch (_) {
            }
          }
        }
        const itemEdition = edition || metadata?.edition || msg.edition || "standard";
        if (projectContext?.projectDirectory) {
          this.lastProjectDirectory = projectContext.projectDirectory;
        }
        const targetHost = msg.payload?.targetHost || metadata?.targetHost || projectContext?.appId || "";
        queueManager2.addItem(url, profile, projectContext, targetDirectory, {
          ...metadata || {},
          edition: itemEdition,
          targetHost
        });
        this.broadcast({ type: "QUEUE_UPDATED", payload: queueManager2.getItems() });
        break;
      }
      case "UPDATE_PROJECT_CONTEXT": {
        if (msg.payload?.projectDirectory) {
          this.lastProjectDirectory = msg.payload.projectDirectory;
          globalScope.__mediaFetchLastProjectDir = this.lastProjectDirectory;
          logger2.info(`Updated cached active project directory: ${this.lastProjectDirectory}`);
        }
        break;
      }
      case "PAUSE_DOWNLOAD": {
        const id = typeof msg.payload === "object" && msg.payload ? msg.payload.id : msg.payload;
        if (id) {
          queueManager2.pauseItem(id);
        } else {
          for (const it of queueManager2.getItems()) {
            if (it.status === "downloading" || it.status === "waiting") {
              queueManager2.pauseItem(it.id);
            }
          }
        }
        this.broadcast({ type: "QUEUE_UPDATED", payload: queueManager2.getItems() });
        break;
      }
      case "RESUME_DOWNLOAD": {
        const id = typeof msg.payload === "object" && msg.payload ? msg.payload.id : msg.payload;
        if (id) {
          queueManager2.resumeItem(id);
        } else {
          queueManager2.resumeAllInterrupted();
        }
        this.broadcast({ type: "QUEUE_UPDATED", payload: queueManager2.getItems() });
        break;
      }
      case "CANCEL_DOWNLOAD": {
        const id = typeof msg.payload === "object" && msg.payload ? msg.payload.id : msg.payload;
        if (id) queueManager2.cancelItem(id);
        this.broadcast({ type: "QUEUE_UPDATED", payload: queueManager2.getItems() });
        break;
      }
      case "RETRY_DOWNLOAD": {
        const id = typeof msg.payload === "object" && msg.payload ? msg.payload.id : msg.payload;
        if (id) queueManager2.retryItem(id);
        this.broadcast({ type: "QUEUE_UPDATED", payload: queueManager2.getItems() });
        break;
      }
      case "CLEAR_COMPLETED": {
        const edition = msg.payload?.edition || msg.edition;
        queueManager2.clearCompleted(edition);
        this.broadcast({ type: "QUEUE_UPDATED", payload: queueManager2.getItems() });
        break;
      }
      case "CLEAR_ALL": {
        const edition = msg.payload?.edition || msg.edition;
        queueManager2.clearAll(edition);
        this.broadcast({ type: "QUEUE_UPDATED", payload: queueManager2.getItems() });
        break;
      }
      case "GET_QUEUE":
        ws.send(JSON.stringify({ type: "QUEUE_UPDATED", payload: queueManager2.getItems() }));
        break;
      case "GET_SETTINGS":
        ws.send(JSON.stringify({ type: "SETTINGS_LOADED", payload: settingsManager2.getSettings() }));
        break;
      case "UPDATE_SETTINGS": {
        const updated = settingsManager2.updateSettings(msg.payload);
        this.broadcast({ type: "SETTINGS_LOADED", payload: updated });
        break;
      }
      case "GET_DIAGNOSTICS": {
        const diag = await diagnosticsCollector2.collectDiagnostics(this.port);
        ws.send(JSON.stringify({ type: "DIAGNOSTICS_RESULT", payload: diag }));
        break;
      }
      case "RUN_SYSTEM_CHECK":
      case "RUN_SYSTEM_DIAGNOSTICS": {
        const diag = await diagnosticsCollector2.collectDiagnostics(this.port);
        ws.send(JSON.stringify({ type: "SYSTEM_DIAGNOSTICS_RESULT", payload: diag }));
        break;
      }
      case "INSTALL_DEPENDENCY": {
        const { name } = msg.payload;
        if (name === "all" || name === "ytdlp" || name === "yt-dlp") {
          const res = await dependencyManager2.installYtDlp((stage, progress, message) => {
            ws.send(JSON.stringify({ type: "DEPENDENCY_INSTALL_PROGRESS", payload: { name: "yt-dlp", stage, progress, message } }));
          });
          ws.send(JSON.stringify({ type: "DEPENDENCY_INSTALL_RESULT", payload: { name: "yt-dlp", success: res.success, error: res.error, message: res.version } }));
        }
        if (name === "all" || name === "ffmpeg" || name === "FFmpeg") {
          const res = await dependencyManager2.installFfmpeg((stage, progress, message) => {
            ws.send(JSON.stringify({ type: "DEPENDENCY_INSTALL_PROGRESS", payload: { name: "ffmpeg", stage, progress, message } }));
          });
          ws.send(JSON.stringify({ type: "DEPENDENCY_INSTALL_RESULT", payload: { name: "ffmpeg", success: res.success, error: res.error, message: res.version } }));
        }
        break;
      }
      case "UPDATE_YTDLP": {
        const active = queueManager2.getActiveCount() > 0;
        const res = await dependencyManager2.updateYtDlp(active, (stage, progress, message) => {
          ws.send(JSON.stringify({ type: "DEPENDENCY_INSTALL_PROGRESS", payload: { name: "yt-dlp", stage, progress, message } }));
        });
        ws.send(JSON.stringify({ type: "DEPENDENCY_INSTALL_RESULT", payload: { name: "yt-dlp", success: res.success, error: res.error, message: res.version } }));
        break;
      }
      case "GET_HISTORY":
        ws.send(JSON.stringify({ type: "HISTORY_LOADED", payload: historyManager2.getHistory() }));
        break;
      case "CLEAR_HISTORY":
        historyManager2.clearHistory();
        ws.send(JSON.stringify({ type: "HISTORY_LOADED", payload: [] }));
        break;
      case "REMOVE_HISTORY_ITEM":
        historyManager2.removeHistoryItem(msg.payload.id);
        ws.send(JSON.stringify({ type: "HISTORY_LOADED", payload: historyManager2.getHistory() }));
        break;
      case "CHECK_DUPLICATE": {
        const { title, container, targetDirectory } = msg.payload;
        const filename = filesystemManager2.sanitizeFilename(title, container);
        const dup = filesystemManager2.checkDuplicate(targetDirectory, filename);
        ws.send(JSON.stringify({
          type: "DUPLICATE_CHECK_RESULT",
          payload: { exists: dup.exists, existingFilePath: dup.filePath, existingFileSize: dup.size }
        }));
        break;
      }
      case "OPEN_FOLDER_DIALOG": {
        try {
          const { exec } = await import("child_process");
          if (process.platform === "win32") {
            const candidates = [
              path8.join(__dirname, "modern_folder_picker.ps1"),
              path8.join(__dirname, "service", "modern_folder_picker.ps1"),
              path8.join(__dirname, "..", "service", "modern_folder_picker.ps1")
            ];
            let pickerScript = candidates.find((c) => fs8.existsSync(c));
            if (!pickerScript) {
              const os10 = await import("os");
              pickerScript = path8.join(os10.tmpdir(), "mediafetch_folder_picker.ps1");
              fs8.writeFileSync(pickerScript, `Add-Type -AssemblyName System.Windows.Forms
function Show-ModernFolderPicker($Title) {
    try {
        $AssemblyFullName = 'System.Windows.Forms, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089'
        $Assembly = [System.Reflection.Assembly]::Load($AssemblyFullName)
        $OpenFileDialog = New-Object System.Windows.Forms.OpenFileDialog
        $OpenFileDialog.AddExtension = $false
        $OpenFileDialog.CheckFileExists = $false
        $OpenFileDialog.DereferenceLinks = $true
        $OpenFileDialog.Filter = "Folders|\`n"
        $OpenFileDialog.Multiselect = $false
        $OpenFileDialog.Title = if ($Title) { $Title } else { "Select MediaFetch Destination Folder" }
        $OpenFileDialogType = $OpenFileDialog.GetType()
        $FileDialogInterfaceType = $Assembly.GetType('System.Windows.Forms.FileDialogNative+IFileDialog')
        $IFileDialog = $OpenFileDialogType.GetMethod('CreateVistaDialog',@('NonPublic','Public','Static','Instance')).Invoke($OpenFileDialog,$null)
        $null = $OpenFileDialogType.GetMethod('OnBeforeVistaDialog',@('NonPublic','Public','Static','Instance')).Invoke($OpenFileDialog,$IFileDialog)
        [uint32]$PickFoldersOption = $Assembly.GetType('System.Windows.Forms.FileDialogNative+FOS').GetField('FOS_PICKFOLDERS').GetValue($null)
        $FolderOptions = $OpenFileDialogType.GetMethod('get_Options',@('NonPublic','Public','Static','Instance')).Invoke($OpenFileDialog,$null) -bor $PickFoldersOption
        $null = $FileDialogInterfaceType.GetMethod('SetOptions',@('NonPublic','Public','Static','Instance')).Invoke($IFileDialog,$FolderOptions)
        $VistaDialogEvent = [System.Activator]::CreateInstance($AssemblyFullName,'System.Windows.Forms.FileDialog+VistaDialogEvents',$false,0,$null,$OpenFileDialog,$null,$null).Unwrap()
        [uint32]$AdviceCookie = 0
        $AdvisoryParameters = @($VistaDialogEvent,$AdviceCookie)
        $AdviseResult = $FileDialogInterfaceType.GetMethod('Advise',@('NonPublic','Public','Static','Instance')).Invoke($IFileDialog,$AdvisoryParameters)
        $AdviceCookie = $AdvisoryParameters[1]
        $Result = $FileDialogInterfaceType.GetMethod('Show',@('NonPublic','Public','Static','Instance')).Invoke($IFileDialog,[System.IntPtr]::Zero)
        $null = $FileDialogInterfaceType.GetMethod('Unadvise',@('NonPublic','Public','Static','Instance')).Invoke($IFileDialog,$AdviceCookie)
        if ($Result -eq 0) {
            try {
                $files = $OpenFileDialogType.GetMethod('ProcessVistaFiles', [System.Reflection.BindingFlags]'NonPublic,Instance').Invoke($OpenFileDialog, @($IFileDialog))
                if ($files -and $files.Length -gt 0 -and !([string]::IsNullOrEmpty($files[0]))) {
                    return $files[0]
                }
            } catch {}
            if (![string]::IsNullOrEmpty($OpenFileDialog.FileName)) {
                return $OpenFileDialog.FileName
            }
        }
        return $null
    } catch {
        return $null
    }
}
$title = if ($args.Count -gt 0 -and $args[0]) { $args[0] } else { "Select MediaFetch Destination Folder" }
$p = Show-ModernFolderPicker -Title $title
if ($p) { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8; [Console]::WriteLine($p) }
`, "utf8");
            }
            execFile4("powershell.exe", [
              "-WindowStyle",
              "Hidden",
              "-NoLogo",
              "-STA",
              "-NoProfile",
              "-ExecutionPolicy",
              "Bypass",
              "-File",
              pickerScript,
              "Select MediaFetch Destination Folder"
            ], { windowsHide: true, encoding: "utf8" }, (err, stdout) => {
              const selected = (stdout || "").trim();
              if (selected) {
                ws.send(JSON.stringify({ type: "FOLDER_SELECTED", payload: { folderPath: selected } }));
              }
            });
          } else if (process.platform === "darwin") {
            exec(`osascript -e 'POSIX path of (choose folder with prompt "Select MediaFetch Destination Folder")'`, (err, stdout) => {
              const selected = (stdout || "").trim();
              if (selected) {
                ws.send(JSON.stringify({ type: "FOLDER_SELECTED", payload: { folderPath: selected } }));
              }
            });
          }
        } catch (dialogErr) {
          logger2.error("Failed to open native folder dialog:", dialogErr);
        }
        break;
      }
      case "GET_CACHE_STATS": {
        let tempStorageBytes = 0;
        const dirs = getKnownCacheDirs();
        for (const d of dirs) {
          tempStorageBytes += getDirSizeBytes(d);
        }
        const appData = nodeProc && nodeProc.env && nodeProc.env.LOCALAPPDATA || (os9.homedir ? path8.join(os9.homedir(), ".mediafetch") : "");
        const logsDir = path8.join(appData || ".", "MediaFetch", "logs");
        const logBytes = getDirSizeBytes(logsDir);
        const ram = getMemoryStats();
        ws.send(JSON.stringify({
          type: "CACHE_STATS",
          payload: {
            ram,
            streamCacheCount: streamUrlCache.size,
            tempStorageBytes,
            logBytes,
            totalCacheBytes: tempStorageBytes + logBytes,
            totalCacheMb: +((tempStorageBytes + logBytes) / (1024 * 1024)).toFixed(2)
          }
        }));
        break;
      }
      case "CLEAR_CACHE": {
        let freedBytes = 0;
        const dirs = getKnownCacheDirs();
        for (const d of dirs) {
          freedBytes += clearDirFiles(d, false);
        }
        streamUrlCache.clear();
        try {
          const appData = nodeProc && nodeProc.env && nodeProc.env.LOCALAPPDATA || (os9.homedir ? path8.join(os9.homedir(), ".mediafetch") : "");
          const logFile = path8.join(appData || ".", "MediaFetch", "logs", "service.log");
          if (fs8.existsSync(logFile)) {
            const sz = fs8.statSync(logFile).size;
            if (sz > 0) {
              fs8.truncateSync(logFile, 0);
              freedBytes += sz;
            }
          }
        } catch (_) {
        }
        trimMemory();
        const ram = getMemoryStats();
        ws.send(JSON.stringify({
          type: "CACHE_CLEARED",
          payload: {
            freedBytes,
            freedMb: +(freedBytes / (1024 * 1024)).toFixed(2),
            totalCacheBytes: 0,
            totalCacheMb: 0,
            ram
          }
        }));
        break;
      }
    }
  }
  handleHttpRequest(req, res) {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
    if (req.method === "OPTIONS") {
      res.writeHead(200);
      res.end();
      return;
    }
    const url = new URL(req.url || "/", `http://127.0.0.1:${this.port}`);
    const pathname = url.pathname;
    const jsonRes = (status, data) => {
      res.writeHead(status, { "Content-Type": "application/json" });
      res.end(JSON.stringify(data));
    };
    const convertImageToPreferredFormat = async (srcFile, targetFormat) => {
      if (!srcFile || !fs8.existsSync(srcFile)) return srcFile;
      const targetExt = (targetFormat === "jpeg" ? "jpg" : targetFormat || "png").toLowerCase();
      const currentExt = path8.extname(srcFile).toLowerCase().replace(".", "");
      if (currentExt === targetExt || currentExt === "jpeg" && targetExt === "jpg" || currentExt === "jpg" && targetExt === "jpeg") {
        return srcFile;
      }
      const destFile = srcFile.replace(/\.[^.]+$/, `.${targetExt}`);
      try {
        const ffmpegPath = await dependencyManager2.getFfmpegExecutablePath();
        if (fs8.existsSync(ffmpegPath)) {
          const args = ["-i", srcFile, "-y"];
          if (targetExt === "jpg") {
            args.push("-q:v", "1");
          } else if (targetExt === "webp") {
            args.push("-lossless", "1");
          }
          args.push(destFile);
          await execFileAsync4(ffmpegPath, args, { windowsHide: true, timeout: 15e3 });
          if (fs8.existsSync(destFile) && fs8.statSync(destFile).size > 100) {
            try {
              fs8.unlinkSync(srcFile);
            } catch (_) {
            }
            return destFile;
          }
        }
      } catch (convErr) {
        logger2.warn("Image format conversion notice:", convErr.message);
      }
      return srcFile;
    };
    if (pathname === "/health" || pathname === "/api/health" || pathname === "/") {
      jsonRes(200, { status: "ok", port: this.port, uptime: process.uptime() });
      return;
    }
    if (pathname === "/api/pending-imports" && req.method === "GET") {
      try {
        const pending = typeof queueManager2.getPendingImports === "function" ? queueManager2.getPendingImports() : [];
        jsonRes(200, { success: true, items: pending });
      } catch (err) {
        jsonRes(500, { success: false, error: err?.message || "Failed to get pending imports" });
      }
      return;
    }
    if (pathname.startsWith("/api/imports/") && pathname.endsWith("/ack") && req.method === "POST") {
      try {
        const parts = pathname.split("/");
        const id = parts[3];
        if (id) {
          queueManager2.markItemImported(id, true);
          jsonRes(200, { success: true, id, status: "imported" });
        } else {
          jsonRes(400, { success: false, error: "Missing import id" });
        }
      } catch (err) {
        jsonRes(500, { success: false, error: err?.message || "Failed to ack import" });
      }
      return;
    }
    if (pathname === "/api/clipboard" && (req.method === "GET" || req.method === "POST")) {
      (async () => {
        try {
          const isWin = process.platform === "win32";
          let clipText = "";
          if (isWin) {
            const { stdout } = await execFileAsync4("powershell.exe", ["-NoProfile", "-Command", "Get-Clipboard"], {
              windowsHide: true,
              timeout: 2500
            });
            clipText = (stdout || "").trim();
          } else {
            const { stdout } = await execFileAsync4("pbpaste", [], { timeout: 2500 });
            clipText = (stdout || "").trim();
          }
          jsonRes(200, { success: true, text: clipText });
        } catch (clipErr) {
          logger2.warn("Clipboard read notice:", clipErr.message);
          jsonRes(200, { success: false, text: "" });
        }
      })();
      return;
    }
    if (pathname === "/api/clipboard/paste-media" && (req.method === "GET" || req.method === "POST")) {
      (async () => {
        try {
          const isWin = process.platform === "win32";
          const isMac = process.platform === "darwin";
          const nowStr = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
          const rawFormat = (url.searchParams.get("format") || "").toLowerCase().trim();
          const currentSettings = typeof settingsManager2.getSettings === "function" ? settingsManager2.getSettings() : {};
          let preferredFormat = rawFormat || currentSettings?.downloads?.clipboardFormat || "png";
          if (preferredFormat === "jpeg") preferredFormat = "jpg";
          if (!["png", "jpg", "webp"].includes(preferredFormat)) preferredFormat = "png";
          const locMode = url.searchParams.get("downloadLocationMode") || currentSettings?.downloads?.downloadLocationMode || "simple";
          const customLoc = (url.searchParams.get("customLocation") || currentSettings?.downloads?.customLocation || "").trim();
          let targetDir = "";
          if (locMode === "custom_flat" && customLoc) {
            targetDir = customLoc;
          } else if (locMode === "custom" && customLoc) {
            targetDir = path8.join(customLoc, "Images");
          }
          if (!targetDir) {
            const projDirParam = (url.searchParams.get("projectDir") || url.searchParams.get("projectDirectory") || this.lastProjectDirectory || "").trim();
            if (projDirParam && projDirParam.length > 0) {
              try {
                if (fs8.existsSync(projDirParam)) {
                  targetDir = path8.join(projDirParam, "MediaFetch", "Images");
                }
              } catch (_) {
              }
            }
          }
          if (!targetDir) {
            const downloadsDir = currentSettings?.general?.downloadPath || path8.join(os9.homedir(), "Downloads");
            targetDir = path8.join(downloadsDir, "MediaFetch", "Images");
          }
          if (!fs8.existsSync(targetDir)) {
            try {
              fs8.mkdirSync(targetDir, { recursive: true });
            } catch (_) {
            }
          }
          if (isWin) {
            const outExt = preferredFormat === "jpg" ? "jpg" : preferredFormat === "webp" ? "webp" : "png";
            const outImg = path8.join(targetDir, `Clipboard_${nowStr}.${outExt}`);
            const escapedPath = outImg.replace(/'/g, "''");
            const psScript = `
Add-Type -AssemblyName System.Windows.Forms;
Add-Type -AssemblyName System.Drawing;

function Save-ImageFromClipboard {
    param([string]$DestPath, [string]$Fmt)

    # 1. Native PowerShell 5.1+ Get-Clipboard -Format Image
    try {
        $img = Get-Clipboard -Format Image;
        if ($img -ne $null) {
            $saveFmt = if ($Fmt -eq 'jpg') { [System.Drawing.Imaging.ImageFormat]::Jpeg } else { [System.Drawing.Imaging.ImageFormat]::Png };
            $img.Save($DestPath, $saveFmt);
            $img.Dispose();
            if (Test-Path $DestPath) {
                Write-Output ('SAVED_IMAGE:' + $DestPath);
                return $true;
            }
        }
    } catch {}

    $data = [System.Windows.Forms.Clipboard]::GetDataObject();
    if ($null -eq $data) { return $false; }

    # 2. PNG Stream (Lossless alpha channel)
    if ($data.GetDataPresent('PNG')) {
        try {
            $stream = $data.GetData('PNG');
            if ($stream -is [System.IO.MemoryStream]) {
                if ($Fmt -eq 'jpg') {
                    $bmp = [System.Drawing.Image]::FromStream($stream);
                    $bmp.Save($DestPath, [System.Drawing.Imaging.ImageFormat]::Jpeg);
                    $bmp.Dispose();
                } else {
                    [System.IO.File]::WriteAllBytes($DestPath, $stream.ToArray());
                }
                $stream.Dispose();
                if (Test-Path $DestPath) {
                    Write-Output ('SAVED_IMAGE:' + $DestPath);
                    return $true;
                }
            }
        } catch {}
    }

    # 3. DeviceIndependentBitmap (DIB / CF_DIB from Chromium, Firefox, etc.)
    if ($data.GetDataPresent('DeviceIndependentBitmap')) {
        try {
            $dibStream = $data.GetData('DeviceIndependentBitmap');
            if ($dibStream -is [System.IO.MemoryStream]) {
                $dibBytes = $dibStream.ToArray();
                $dibStream.Dispose();
                if ($dibBytes.Length -gt 40) {
                    $headerSize = [BitConverter]::ToInt32($dibBytes, 0);
                    $bitCount = [BitConverter]::ToInt16($dibBytes, 14);
                    $compression = [BitConverter]::ToInt32($dibBytes, 16);
                    $clrUsed = [BitConverter]::ToInt32($dibBytes, 32);

                    $paletteSize = 0;
                    if ($clrUsed -gt 0) {
                        $paletteSize = $clrUsed * 4;
                    } elseif ($bitCount -le 8) {
                        $paletteSize = [Math]::Pow(2, $bitCount) * 4;
                    } elseif ($compression -eq 3) {
                        $paletteSize = 12;
                    }

                    $offBits = 14 + $headerSize + $paletteSize;
                    $fileSize = 14 + $dibBytes.Length;

                    $bmpBytes = New-Object byte[] $fileSize;
                    $bmpBytes[0] = 0x42;
                    $bmpBytes[1] = 0x4D;
                    [Array]::Copy([BitConverter]::GetBytes([int]$fileSize), 0, $bmpBytes, 2, 4);
                    [Array]::Copy([BitConverter]::GetBytes([int]$offBits), 0, $bmpBytes, 10, 4);
                    [Array]::Copy($dibBytes, 0, $bmpBytes, 14, $dibBytes.Length);

                    $ms = New-Object System.IO.MemoryStream(,$bmpBytes);
                    $bmp = [System.Drawing.Image]::FromStream($ms);
                    $saveFmt = if ($Fmt -eq 'jpg') { [System.Drawing.Imaging.ImageFormat]::Jpeg } else { [System.Drawing.Imaging.ImageFormat]::Png };
                    $bmp.Save($DestPath, $saveFmt);
                    $bmp.Dispose();
                    $ms.Dispose();

                    if (Test-Path $DestPath) {
                        Write-Output ('SAVED_IMAGE:' + $DestPath);
                        return $true;
                    }
                }
            }
        } catch {}
    }

    # 4. Standard WinForms Clipboard GetImage
    if ([System.Windows.Forms.Clipboard]::ContainsImage()) {
        try {
            $img = [System.Windows.Forms.Clipboard]::GetImage();
            if ($img -ne $null) {
                $saveFmt = if ($Fmt -eq 'jpg') { [System.Drawing.Imaging.ImageFormat]::Jpeg } else { [System.Drawing.Imaging.ImageFormat]::Png };
                $img.Save($DestPath, $saveFmt);
                $img.Dispose();
                if (Test-Path $DestPath) {
                    Write-Output ('SAVED_IMAGE:' + $DestPath);
                    return $true;
                }
            }
        } catch {}
    }

    return $false;
}

$dest = '${escapedPath}';
$saved = Save-ImageFromClipboard -DestPath $dest -Fmt '${preferredFormat}';

$data = [System.Windows.Forms.Clipboard]::GetDataObject();
if ($data -ne $null) {
    if ($data.GetDataPresent('HTML Format')) {
        try {
            $hObj = $data.GetData('HTML Format');
            $hStr = '';
            if ($hObj -is [System.IO.MemoryStream]) {
                $hStr = [System.Text.Encoding]::UTF8.GetString($hObj.ToArray());
                $hObj.Dispose();
            } elseif ($hObj -is [string]) {
                $hStr = $hObj;
            }
            if ($hStr) { Write-Output ('HTML:' + $hStr); }
        } catch {}
    }
    if ([System.Windows.Forms.Clipboard]::ContainsFileDropList()) {
        try {
            $f = [System.Windows.Forms.Clipboard]::GetFileDropList();
            if ($f -ne $null -and $f.Count -gt 0) { Write-Output ('FILES:' + ($f -join '|')); }
        } catch {}
    }
    if ([System.Windows.Forms.Clipboard]::ContainsText()) {
        try {
            $t = [System.Windows.Forms.Clipboard]::GetText();
            if ($t) { Write-Output ('TEXT:' + $t); }
        } catch {}
    }
}
`;
            let stdout = "";
            try {
              const res2 = await execFileAsync4("powershell.exe", ["-STA", "-NoProfile", "-Command", psScript], {
                windowsHide: true,
                timeout: 5e3
              });
              stdout = res2.stdout || "";
            } catch (psErr) {
              logger2.warn("PowerShell clipboard extraction notice:", psErr.message);
              stdout = psErr.stdout || "";
            }
            const out = stdout.trim();
            let savedImagePath = null;
            if (out.includes("SAVED_IMAGE:")) {
              const line = out.split("\n").find((l) => l.includes("SAVED_IMAGE:")) || "";
              const filePath = line.substring(line.indexOf("SAVED_IMAGE:") + "SAVED_IMAGE:".length).trim();
              if (fs8.existsSync(filePath) && fs8.statSync(filePath).size > 100) {
                savedImagePath = filePath;
              }
            } else if (fs8.existsSync(outImg) && fs8.statSync(outImg).size > 100) {
              savedImagePath = outImg;
            }
            if (savedImagePath && fs8.existsSync(savedImagePath)) {
              const finalDestPath = await convertImageToPreferredFormat(savedImagePath, preferredFormat);
              return jsonRes(200, { success: true, type: "image", filePath: finalDestPath, fileName: path8.basename(finalDestPath) });
            }
            if (!savedImagePath && out.includes("HTML:")) {
              try {
                const htmlChunk = out.substring(out.indexOf("HTML:") + "HTML:".length);
                const b64Match = htmlChunk.match(/src=["']data:image\/([a-zA-Z0-9+]+);base64,([^"']+)["']/i);
                if (b64Match) {
                  const mime = b64Match[1].toLowerCase();
                  const b64Data = b64Match[2];
                  const buf = Buffer.from(b64Data, "base64");
                  if (buf.length > 100) {
                    const ext = mime.includes("jpeg") || mime.includes("jpg") ? ".jpg" : mime.includes("webp") ? ".webp" : ".png";
                    const b64Dest = path8.join(targetDir, `Clipboard_${nowStr}${ext}`);
                    fs8.writeFileSync(b64Dest, buf);
                    const finalDestPath = await convertImageToPreferredFormat(b64Dest, preferredFormat);
                    return jsonRes(200, { success: true, type: "image", filePath: finalDestPath, fileName: path8.basename(finalDestPath), source: "clipboard_base64_data" });
                  }
                }
                let candidateUrl = "";
                const srcMatch = htmlChunk.match(/<img[^>]+(?:src|data-src|data-original)=["']([^"']+)["']/i);
                if (srcMatch && srcMatch[1]) {
                  candidateUrl = srcMatch[1];
                } else {
                  const srcsetMatch = htmlChunk.match(/srcset=["']([^"']+)["']/i);
                  if (srcsetMatch && srcsetMatch[1]) {
                    const parts = srcsetMatch[1].split(",").map((s) => s.trim().split(" ")[0]).filter(Boolean);
                    candidateUrl = parts[parts.length - 1] || "";
                  }
                }
                if (candidateUrl) {
                  if (candidateUrl.startsWith("//")) candidateUrl = "https:" + candidateUrl;
                  if (candidateUrl.startsWith("http://") || candidateUrl.startsWith("https://")) {
                    const res2 = await fetch(candidateUrl, {
                      headers: {
                        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36",
                        "Accept": "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8"
                      },
                      signal: AbortSignal.timeout(6e3)
                    });
                    if (res2.ok) {
                      const ct = (res2.headers.get("content-type") || "").toLowerCase();
                      let ext = ".png";
                      if (ct.includes("jpeg") || ct.includes("jpg")) ext = ".jpg";
                      else if (ct.includes("webp")) ext = ".webp";
                      else if (ct.includes("gif")) ext = ".gif";
                      else if (ct.includes("svg")) ext = ".svg";
                      const highResDest = path8.join(targetDir, `Clipboard_${nowStr}${ext}`);
                      const buf = Buffer.from(await res2.arrayBuffer());
                      if (buf.length > 200) {
                        fs8.writeFileSync(highResDest, buf);
                        const finalDestPath = await convertImageToPreferredFormat(highResDest, preferredFormat);
                        return jsonRes(200, { success: true, type: "image", filePath: finalDestPath, fileName: path8.basename(finalDestPath), source: "web_master_original" });
                      }
                    }
                  }
                }
              } catch (webErr) {
                logger2.warn("Direct web master image fetch notice:", webErr.message);
              }
            }
            if (out.includes("FILES:")) {
              const line = out.split("\n").find((l) => l.includes("FILES:")) || "";
              const fileList = line.substring(line.indexOf("FILES:") + "FILES:".length).trim().split("|").filter(Boolean);
              if (fileList.length > 0 && fs8.existsSync(fileList[0])) {
                return jsonRes(200, { success: true, type: "file", filePath: fileList[0], files: fileList, fileName: path8.basename(fileList[0]) });
              }
            }
            if (out.includes("TEXT:")) {
              const line = out.split("\n").find((l) => l.includes("TEXT:")) || "";
              const txt = line.substring(line.indexOf("TEXT:") + "TEXT:".length).trim();
              if (txt.startsWith("http://") || txt.startsWith("https://")) {
                try {
                  const res2 = await fetch(txt, {
                    headers: {
                      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36",
                      "Accept": "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8"
                    },
                    signal: AbortSignal.timeout(5e3)
                  });
                  if (res2.ok) {
                    const ct = (res2.headers.get("content-type") || "").toLowerCase();
                    if (ct.startsWith("image/")) {
                      let ext = ".png";
                      if (ct.includes("jpeg") || ct.includes("jpg")) ext = ".jpg";
                      else if (ct.includes("webp")) ext = ".webp";
                      else if (ct.includes("gif")) ext = ".gif";
                      else if (ct.includes("svg")) ext = ".svg";
                      const finalDest = path8.join(targetDir, `Clipboard_${nowStr}${ext}`);
                      const buf = Buffer.from(await res2.arrayBuffer());
                      if (buf.length > 100) {
                        fs8.writeFileSync(finalDest, buf);
                        const finalDestPath = await convertImageToPreferredFormat(finalDest, preferredFormat);
                        return jsonRes(200, { success: true, type: "image", filePath: finalDestPath, fileName: path8.basename(finalDestPath), source: "url_master_original" });
                      }
                    }
                  }
                } catch (_) {
                }
                return jsonRes(200, { success: true, type: "text", text: txt });
              }
            }
          } else if (isMac) {
            const outImg = path8.join(targetDir, `Clipboard_${nowStr}.png`);
            try {
              await execFileAsync4("osascript", ["-e", `
                set theFile to (POSIX file "${outImg}")
                try
                  set theData to the clipboard as \xABclass PNGf\xBB
                  set theOpenedFile to open for access theFile with write permission
                  write theData to theOpenedFile
                  close access theOpenedFile
                on error
                  try
                    close access theFile
                  end try
                end try
              `], { timeout: 3500 });
              if (fs8.existsSync(outImg) && fs8.statSync(outImg).size > 100) {
                const finalDestPath = await convertImageToPreferredFormat(outImg, preferredFormat);
                return jsonRes(200, { success: true, type: "image", filePath: finalDestPath, fileName: path8.basename(finalDestPath) });
              }
            } catch (_) {
            }
          }
          jsonRes(200, { success: false, message: "Clipboard does not contain image or media" });
        } catch (err) {
          logger2.warn("Paste media error:", err.message);
          jsonRes(500, { success: false, error: err.message });
        }
      })();
      return;
    }
    if ((pathname === "/api/service/shutdown" || pathname === "/api/service/restart") && req.method === "POST") {
      logger2.info("Service shutdown endpoint called via HTTP POST.");
      jsonRes(200, { success: true, message: "Shutting down service..." });
      setTimeout(async () => {
        try {
          await this.stop();
        } catch (_) {
        }
        process.exit(0);
      }, 300);
      return;
    }
    if (pathname === "/api/panel/reload" && (req.method === "POST" || req.method === "GET")) {
      logger2.info("Broadcasting PANEL_RELOAD signal to connected Adobe panels...");
      this.broadcast({ type: "PANEL_RELOAD" });
      jsonRes(200, { success: true, message: "Reload signal broadcasted to panels" });
      return;
    }
    if (pathname === "/api/diagnostics" && req.method === "GET") {
      diagnosticsCollector2.collectDiagnostics(this.port).then((d) => jsonRes(200, d));
      return;
    }
    if (pathname === "/api/queue" && req.method === "GET") {
      jsonRes(200, queueManager2.getItems());
      return;
    }
    if (pathname === "/api/settings" && req.method === "GET") {
      jsonRes(200, settingsManager2.getSettings());
      return;
    }
    if (pathname === "/api/history" && req.method === "GET") {
      jsonRes(200, historyManager2.getHistory());
      return;
    }
    if (pathname === "/api/cache/stats" && req.method === "GET") {
      let tempStorageBytes = 0;
      const dirs = getKnownCacheDirs();
      for (const d of dirs) {
        tempStorageBytes += getDirSizeBytes(d);
      }
      const appData = nodeProc && nodeProc.env && nodeProc.env.LOCALAPPDATA || (os9.homedir ? path8.join(os9.homedir(), ".mediafetch") : "");
      const logsDir = path8.join(appData || ".", "MediaFetch", "logs");
      const logBytes = getDirSizeBytes(logsDir);
      const ram = getMemoryStats();
      jsonRes(200, {
        success: true,
        ram,
        streamCacheCount: streamUrlCache.size,
        tempStorageBytes,
        logBytes,
        totalCacheBytes: tempStorageBytes + logBytes,
        totalCacheMb: +((tempStorageBytes + logBytes) / (1024 * 1024)).toFixed(2)
      });
      return;
    }
    if (pathname === "/api/cache/clear" && req.method === "POST") {
      let freedBytes = 0;
      const dirs = getKnownCacheDirs();
      for (const d of dirs) {
        freedBytes += clearDirFiles(d, false);
      }
      streamUrlCache.clear();
      try {
        const appData = nodeProc && nodeProc.env && nodeProc.env.LOCALAPPDATA || (os9.homedir ? path8.join(os9.homedir(), ".mediafetch") : "");
        const logFile = path8.join(appData || ".", "MediaFetch", "logs", "service.log");
        if (fs8.existsSync(logFile)) {
          const sz = fs8.statSync(logFile).size;
          if (sz > 0) {
            fs8.truncateSync(logFile, 0);
            freedBytes += sz;
          }
        }
      } catch (_) {
      }
      trimMemory();
      const ram = getMemoryStats();
      jsonRes(200, {
        success: true,
        freedBytes,
        freedMb: +(freedBytes / (1024 * 1024)).toFixed(2),
        totalCacheBytes: 0,
        totalCacheMb: 0,
        ram
      });
      return;
    }
    if (pathname === "/api/cache/gc" && req.method === "POST") {
      trimMemory();
      const ram = getMemoryStats();
      jsonRes(200, {
        success: true,
        ram
      });
      return;
    }
    if (!this.pendingResolveImports) this.pendingResolveImports = [];
    if (!this.activeResolveProject) this.activeResolveProject = "DaVinci Resolve";
    if (pathname === "/api/davinci/import" && req.method === "POST") {
      let body = "";
      req.on("data", (chunk) => {
        body += chunk;
      });
      req.on("end", () => {
        try {
          const data = JSON.parse(body);
          if (data && data.filePath) {
            this.pendingResolveImports.push(data.filePath);
            jsonRes(200, { success: true, queued: true });
            return;
          }
        } catch (_) {
        }
        jsonRes(400, { error: "Invalid payload" });
      });
      return;
    }
    if (pathname === "/api/davinci/pending" && req.method === "GET") {
      const items = [...this.pendingResolveImports];
      this.pendingResolveImports = [];
      jsonRes(200, { files: items, project: this.activeResolveProject });
      return;
    }
    if (pathname === "/api/davinci/project" && req.method === "POST") {
      let body = "";
      req.on("data", (chunk) => {
        body += chunk;
      });
      req.on("end", () => {
        try {
          const data = JSON.parse(body);
          if (data && data.name) this.activeResolveProject = data.name;
        } catch (_) {
        }
        jsonRes(200, { success: true, project: this.activeResolveProject });
      });
      return;
    }
    if (pathname === "/api/davinci/project" && req.method === "GET") {
      jsonRes(200, { project: this.activeResolveProject });
      return;
    }
    if (pathname === "/api/clipboard" && req.method === "GET") {
      try {
        let clipText = "";
        const { execSync } = require("child_process");
        if (process.platform === "win32") {
          clipText = execSync("powershell.exe -NoProfile -Command Get-Clipboard", { encoding: "utf8", timeout: 2500, windowsHide: true }) || "";
        } else if (process.platform === "darwin") {
          clipText = execSync("pbpaste", { encoding: "utf8", timeout: 2e3 }) || "";
        } else {
          clipText = execSync("xclip -selection clipboard -o || wl-paste", { encoding: "utf8", timeout: 2e3 }) || "";
        }
        jsonRes(200, { success: true, text: clipText.trim() });
      } catch (err) {
        jsonRes(200, { success: false, error: err.message, text: "" });
      }
      return;
    }
    if (pathname === "/api/stream-url" && req.method === "GET") {
      const vid = url.searchParams.get("v") || url.searchParams.get("id");
      const quality = url.searchParams.get("quality") || "720";
      const targetUrl = vid ? vid.startsWith("http") ? vid : `https://www.youtube.com/watch?v=${vid}` : null;
      if (!targetUrl) {
        jsonRes(400, { success: false, error: "Missing video id" });
        return;
      }
      const cacheKey = `${vid}_${quality}`;
      const cached = streamUrlCache.get(cacheKey);
      if (cached && cached.expiresAt > Date.now()) {
        jsonRes(200, { success: true, streamUrl: cached.streamUrl, cached: true });
        return;
      }
      const isTikTok = /tiktok\.com|vm\.tiktok\.com|vt\.tiktok\.com/i.test(targetUrl);
      if (isTikTok) {
        (async () => {
          try {
            const resp = await fetch(`https://www.tikwm.com/api/?url=${encodeURIComponent(targetUrl)}&hd=1`, {
              headers: { "User-Agent": "Mozilla/5.0" },
              signal: AbortSignal.timeout(12e3)
            });
            if (resp.ok) {
              const data = await resp.json();
              if (data && data.code === 0 && data.data) {
                const sUrl = data.data.play || data.data.hdplay;
                if (sUrl) {
                  setStreamUrlCache(cacheKey, { streamUrl: sUrl, expiresAt: Date.now() + 3600 * 1e3 });
                  jsonRes(200, { success: true, streamUrl: sUrl });
                  return;
                }
              }
            }
          } catch (tErr) {
            logger2.warn("TikTok stream-url TikWM notice:", tErr.message);
          }
          try {
            const mateResp = await fetch("https://api.tikmate.app/api/lookup", {
              method: "POST",
              headers: { "Content-Type": "application/x-www-form-urlencoded" },
              body: `url=${encodeURIComponent(targetUrl)}`,
              signal: AbortSignal.timeout(1e4)
            });
            if (mateResp.ok) {
              const mateData = await mateResp.json();
              if (mateData && mateData.token && mateData.id) {
                const sUrl = `https://tikmate.app/download/${mateData.token}/${mateData.id}.mp4${quality === "1080" ? "?hd=1" : ""}`;
                setStreamUrlCache(cacheKey, { streamUrl: sUrl, expiresAt: Date.now() + 3600 * 1e3 });
                jsonRes(200, { success: true, streamUrl: sUrl });
                return;
              }
            }
          } catch (mErr) {
            logger2.warn("TikTok stream-url TikMate notice:", mErr.message);
          }
          jsonRes(500, { success: false, error: "Could not extract TikTok stream" });
        })();
        return;
      }
      let formatSpec = "b[height<=720][protocol^=https][ext=mp4]/22/18/b/best[protocol^=https]/best";
      if (quality === "1080") {
        formatSpec = "b[height<=1080][protocol^=https][ext=mp4]/22/18/b[height<=1080]/b/best[protocol^=https]/best";
      } else if (quality === "720") {
        formatSpec = "b[height<=720][protocol^=https][ext=mp4]/22/18/b[height<=720]/b/best[protocol^=https]/best";
      } else if (quality === "480") {
        formatSpec = "b[height<=480][protocol^=https][ext=mp4]/18/b[height<=480]/b/best[protocol^=https]/best";
      } else if (quality === "360") {
        formatSpec = "18/b[height<=360][protocol^=https][ext=mp4]/b/best[protocol^=https]/best";
      }
      const appendCookieArgs = (cmdArgs) => {
        try {
          const localAppData = process.env.LOCALAPPDATA || (os9.homedir ? path8.join(os9.homedir(), "AppData", "Local") : "");
          const cookiesFilePath = localAppData ? path8.join(localAppData, "MediaFetch", "cookies.txt") : "";
          if (cookiesFilePath && fs8.existsSync(cookiesFilePath) && fs8.statSync(cookiesFilePath).size > 10) {
            cmdArgs.push("--cookies", cookiesFilePath);
            return;
          }
          const rawCookiesBrowser = settingsManager2.getSettings()?.engine?.browserCookies || settingsManager2.getSettings()?.engine?.cookiesBrowser || "none";
          const isWin = process.platform === "win32";
          const cookiesBrowser = isWin && rawCookiesBrowser === "chrome" ? "none" : rawCookiesBrowser;
          if (cookiesBrowser && cookiesBrowser !== "none") {
            cmdArgs.push("--cookies-from-browser", cookiesBrowser);
          }
        } catch (_) {
        }
      };
      (async () => {
        try {
          const ytdlpPath = await dependencyManager2.getYtDlpExecutablePath();
          const nodeBin = dependencyManager2.getNodeExecutablePath();
          const jsRuntime = nodeBin === "node" ? "node" : `node:${nodeBin}`;
          const isYt = /youtu\.?be/i.test(targetUrl);
          const args = [
            "--no-playlist",
            "--no-check-certificates",
            "--no-warnings",
            "--skip-download",
            "--js-runtimes",
            jsRuntime,
            "--remote-components",
            "ejs:github"
          ];
          appendCookieArgs(args);
          if (targetUrl.includes("behance.net") || targetUrl.includes("vimeo.com")) {
            args.push("--referer", "https://www.behance.net/");
          } else if (targetUrl.includes("instagram.com")) {
            args.push("--referer", "https://www.instagram.com/");
          } else if (targetUrl.includes("threads.net") || targetUrl.includes("threads.com")) {
            args.push("--referer", "https://www.threads.net/");
          } else if (targetUrl.includes("x.com") || targetUrl.includes("twitter.com")) {
            args.push("--referer", "https://x.com/");
          } else if (targetUrl.includes("linkedin.com")) {
            args.push("--referer", "https://www.linkedin.com/");
          }
          args.push("-g", "-f", formatSpec, targetUrl);
          const { stdout } = await execFileAsync4(ytdlpPath, args, { windowsHide: true, timeout: 25e3 });
          const streamUrl = stdout.trim().split(/\r?\n/).find((u) => u.startsWith("http"));
          if (streamUrl) {
            setStreamUrlCache(cacheKey, { streamUrl, expiresAt: Date.now() + 2 * 3600 * 1e3 });
            jsonRes(200, { success: true, streamUrl });
            return;
          }
          throw new Error("No stream URL extracted");
        } catch (err) {
          try {
            const ytdlpPath = await dependencyManager2.getYtDlpExecutablePath();
            const nodeBin = dependencyManager2.getNodeExecutablePath();
            const jsRuntime = nodeBin === "node" ? "node" : `node:${nodeBin}`;
            const isYt = /youtu\.?be/i.test(targetUrl);
            const fallbackArgs = [
              "--no-playlist",
              "--no-check-certificates",
              "--no-warnings",
              "--skip-download",
              "--js-runtimes",
              jsRuntime,
              "--remote-components",
              "ejs:github"
            ];
            appendCookieArgs(fallbackArgs);
            if (targetUrl.includes("behance.net") || targetUrl.includes("vimeo.com")) {
              fallbackArgs.push("--referer", "https://www.behance.net/");
            } else if (targetUrl.includes("instagram.com")) {
              fallbackArgs.push("--referer", "https://www.instagram.com/");
            } else if (targetUrl.includes("threads.net") || targetUrl.includes("threads.com")) {
              fallbackArgs.push("--referer", "https://www.threads.net/");
            } else if (targetUrl.includes("x.com") || targetUrl.includes("twitter.com")) {
              fallbackArgs.push("--referer", "https://x.com/");
            } else if (targetUrl.includes("linkedin.com")) {
              fallbackArgs.push("--referer", "https://www.linkedin.com/");
            }
            if (isYt) {
              fallbackArgs.push("-g", "-f", "18/22/b/best", targetUrl);
            } else {
              fallbackArgs.push("-g", "-f", "best[protocol^=https]/best", targetUrl);
            }
            const { stdout } = await execFileAsync4(ytdlpPath, fallbackArgs, { windowsHide: true, timeout: 25e3 });
            const streamUrl = stdout.trim().split(/\r?\n/).find((u) => u.startsWith("http"));
            if (streamUrl) {
              setStreamUrlCache(cacheKey, { streamUrl, expiresAt: Date.now() + 2 * 3600 * 1e3 });
              jsonRes(200, { success: true, streamUrl });
              return;
            }
          } catch (_) {
          }
          try {
            const ytdlpPath = await dependencyManager2.getYtDlpExecutablePath();
            const nodeBin = dependencyManager2.getNodeExecutablePath();
            const jsRuntime = nodeBin === "node" ? "node" : `node:${nodeBin}`;
            const isYt = /youtu\.?be/i.test(targetUrl);
            const emergencyArgs = [
              "--no-playlist",
              "--no-check-certificates",
              "--no-warnings",
              "--skip-download",
              "--js-runtimes",
              jsRuntime,
              "--remote-components",
              "ejs:github"
            ];
            appendCookieArgs(emergencyArgs);
            if (isYt) {
              emergencyArgs.push("-g", "-f", "18/b/best", targetUrl);
            } else {
              emergencyArgs.push("-g", "-f", "best", targetUrl);
            }
            const { stdout } = await execFileAsync4(ytdlpPath, emergencyArgs, { windowsHide: true, timeout: 25e3 });
            const streamUrl = stdout.trim().split(/\r?\n/).find((u) => u.startsWith("http"));
            if (streamUrl) {
              setStreamUrlCache(cacheKey, { streamUrl, expiresAt: Date.now() + 2 * 3600 * 1e3 });
              jsonRes(200, { success: true, streamUrl });
              return;
            }
          } catch (_) {
          }
          jsonRes(500, { success: false, error: err.message || "Failed to resolve stream URL" });
        }
      })();
      return;
    }
    if (pathname === "/youtube-player.html" || pathname === "/player") {
      const ytPath = path8.join(__dirname, "..", "youtube-player.html");
      if (fs8.existsSync(ytPath)) {
        res.writeHead(200, {
          "Content-Type": "text/html; charset=utf-8",
          "Referrer-Policy": "strict-origin-when-cross-origin",
          "Access-Control-Allow-Origin": "*"
        });
        res.end(fs8.readFileSync(ytPath));
        return;
      }
    }
    if (pathname === "/theater-player.html" || pathname === "/theater") {
      const theaterPath = path8.join(__dirname, "..", "theater-player.html");
      if (fs8.existsSync(theaterPath)) {
        res.writeHead(200, {
          "Content-Type": "text/html; charset=utf-8",
          "Access-Control-Allow-Origin": "*"
        });
        res.end(fs8.readFileSync(theaterPath));
        return;
      }
    }
    const resolveRoots = [
      path8.join(__dirname, ".."),
      path8.join(process.env.PROGRAMDATA || "C:\\ProgramData", "Blackmagic Design", "DaVinci Resolve", "Support", "Workflow Integration Plugins", "com.mediafetch.resolve"),
      path8.join(__dirname, "..", "..", "com.mediafetch.resolve"),
      path8.join(__dirname, "..", "..", "..", "com.mediafetch.resolve")
    ];
    if (pathname === "/resolve" || pathname === "/resolve/" || pathname === "/resolve/index.html") {
      for (const root of resolveRoots) {
        const indexPath = path8.join(root, "index.html");
        if (fs8.existsSync(indexPath)) {
          res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
          res.end(fs8.readFileSync(indexPath));
          return;
        }
      }
    }
    if (pathname.startsWith("/resolve/")) {
      const rel = pathname.replace("/resolve/", "");
      for (const root of resolveRoots) {
        const fullPath = path8.join(root, rel);
        if (fs8.existsSync(fullPath) && fs8.statSync(fullPath).isFile()) {
          const ext = path8.extname(fullPath).toLowerCase();
          const mimeTypes = {
            ".html": "text/html; charset=utf-8",
            ".css": "text/css; charset=utf-8",
            ".js": "application/javascript; charset=utf-8",
            ".png": "image/png",
            ".svg": "image/svg+xml",
            ".json": "application/json"
          };
          res.writeHead(200, { "Content-Type": mimeTypes[ext] || "application/octet-stream" });
          res.end(fs8.readFileSync(fullPath));
          return;
        }
      }
    }
    jsonRes(404, { error: "Not Found" });
  }
};
function startInProcessServer(port = 48924) {
  if (globalScope.__mediaFetchServerStarted) return globalScope.__mediaFetchServerInstance;
  globalScope.__mediaFetchServerStarted = true;
  const preferredPort = parseInt(port || nodeProc && nodeProc.env && nodeProc.env.PORT || "48924", 10);
  const server = new MediaFetchServer(preferredPort);
  globalScope.__mediaFetchServerInstance = server;
  server.start().catch((err) => {
    if (err.code !== "EADDRINUSE") {
      console.error("Failed to start MediaFetch server:", err);
    }
  });
  return server;
}
var isNodeStandalone = typeof window === "undefined" && typeof document === "undefined";
if (isNodeStandalone && !globalScope.__mediaFetchServerStarted) {
  startInProcessServer();
}
module.exports = { MediaFetchServer, startInProcessServer, metadataAnalyzer: metadataAnalyzer2, queueManager: queueManager2, dependencyManager: dependencyManager2, settingsManager: settingsManager2 };
