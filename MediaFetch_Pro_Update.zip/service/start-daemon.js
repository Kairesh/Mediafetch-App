const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');

const serverPath = path.join(__dirname, 'server.js');
let nodeExe = 'node';
const candidates = [
  'C:\\Program Files\\nodejs\\node.exe',
  'C:\\Program Files (x86)\\nodejs\\node.exe',
  '/opt/homebrew/bin/node',
  '/usr/local/bin/node',
  '/usr/bin/node',
  process.execPath
];
for (const cand of candidates) {
  if (cand && fs.existsSync(cand)) {
    nodeExe = cand;
    break;
  }
}

const child = spawn(nodeExe, ['--expose-gc', '--max-old-space-size=48', '--optimize-for-size', serverPath], {
  detached: true,
  stdio: 'ignore',
  windowsHide: true
});
child.unref();
