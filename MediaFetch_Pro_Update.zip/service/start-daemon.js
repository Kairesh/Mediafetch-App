const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');

const serverPath = path.join(__dirname, 'server.js');
let nodeExe = 'node';
const candidates = [
  'C:\\Program Files\\nodejs\\node.exe',
  'C:\\Program Files (x86)\\nodejs\\node.exe',
  '/opt/homebrew/bin/node',
  '/usr/local/bin/node',
  '/usr/bin/node',
  process.execPath
];
for (const cand of candidates) {
  if (cand && fs.existsSync(cand)) {
    nodeExe = cand;
    break;
  }
}

const localAppData = process.env.LOCALAPPDATA || path.join(process.env.USERPROFILE || '', 'AppData', 'Local');
const logDir = path.join(localAppData, 'MediaFetch', 'logs');
try { fs.mkdirSync(logDir, { recursive: true }); } catch (_) {}
const logFile = path.join(logDir, 'service.log');
let outFd = 'ignore';
let errFd = 'ignore';
try {
  outFd = fs.openSync(logFile, 'a');
  errFd = outFd;
} catch (_) {}

const child = spawn(nodeExe, ['--expose-gc', '--max-old-space-size=512', serverPath], {
  detached: true,
  stdio: ['ignore', outFd, errFd],
  windowsHide: true
});
child.on('error', (err) => {
  console.error('[MediaFetch] Failed to spawn daemon:', err);
});
child.unref();
