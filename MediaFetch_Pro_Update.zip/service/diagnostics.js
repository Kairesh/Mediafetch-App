import os from 'os';
import { dependencyManager } from './dependencies.js';
import { queueManager } from './queue.js';
import { logger } from './logger.js';

export class DiagnosticsCollector {
  constructor() {
    this.startTime = Date.now();
    this.appVersion = '1.0.0';
  }

  async collectDiagnostics(port, projectContext) {
    const ytdlp = await dependencyManager.checkYtDlp();
    const ffmpeg = await dependencyManager.checkFfmpeg();
    const ffprobe = await dependencyManager.checkFfprobe();

    const freeMem = os.freemem();
    const totalMem = os.totalmem();

    return {
      version: this.appVersion,
      os: `${os.type()} ${os.release()} (${os.arch()})`,
      arch: os.arch(),
      nodeVersion: process.version,
      adobeApp: projectContext?.application || 'standalone',
      adobeVersion: projectContext?.applicationVersion || 'unknown',
      ytdlp: {
        available: ytdlp.available,
        version: ytdlp.version,
        path: ytdlp.path
      },
      ffmpeg: {
        available: ffmpeg.available,
        version: ffmpeg.version,
        path: ffmpeg.path
      },
      ffprobe: {
        available: ffprobe.available,
        version: ffprobe.version,
        path: ffprobe.path
      },
      diskSpace: {
        freeBytes: freeMem,
        totalBytes: totalMem
      },
      servicePort: port,
      uptime: Math.floor((Date.now() - this.startTime) / 1000),
      activeDownloadsCount: queueManager.getActiveCount(),
      queueLength: queueManager.getItems().length
    };
  }

  getSanitizedLogs(limit = 100) {
    return logger.getLogs(limit);
  }
}

export const diagnosticsCollector = new DiagnosticsCollector();