import fs from 'fs';
import path from 'path';
import os from 'os';
import { settingsManager } from './settings.js';
import { logger } from './logger.js';

const WINDOWS_RESERVED_NAMES = new Set([
  'CON', 'PRN', 'AUX', 'NUL',
  'COM1', 'COM2', 'COM3', 'COM4', 'COM5', 'COM6', 'COM7', 'COM8', 'COM9',
  'LPT1', 'LPT2', 'LPT3', 'LPT4', 'LPT5', 'LPT6', 'LPT7', 'LPT8', 'LPT9'
]);

export class FilesystemManager {
  /**
   * Sanitizes a title string into a cross-platform safe filename.
   */
  sanitizeFilename(title, ext) {
    if (!title || typeof title !== 'string' || title.trim().length === 0) {
      title = 'media_download';
    }

    let sanitized = title
      .replace(/[\x00-\x1f\x7f]/g, '')
      .replace(/[\\/:*?"<>|]/g, '_')
      .replace(/\s+/g, ' ')
      .replace(/_+/g, '_')
      .trim()
      .replace(/^[.\s]+|[.\s]+$/g, '');

    if (!sanitized) {
      sanitized = 'media_file';
    }

    const upper = sanitized.toUpperCase();
    if (WINDOWS_RESERVED_NAMES.has(upper)) {
      sanitized = `_${sanitized}_`;
    }

    if (sanitized.length > 200) {
      sanitized = sanitized.substring(0, 200).trim();
    }

    if (ext) {
      const cleanExt = ext.startsWith('.') ? ext.substring(1) : ext;
      return `${sanitized}.${cleanExt}`;
    }
    return sanitized;
  }

  /**
   * Resolves target download directory based on project state and settings.
   */
  resolveTargetDirectory(projectContext, customOverride, settings) {
    const currentSettings = settings || settingsManager.getSettings();
    const locMode = currentSettings?.downloads?.downloadLocationMode || 'project';

    // 1. Explicit override passed from UI
    if (customOverride && typeof customOverride === 'string' && customOverride.trim().length > 0) {
      return {
        targetDir: path.resolve(customOverride.trim()),
        mode: 'custom',
        isProjectFolder: false
      };
    }

    // 2. Project Folder Mode (Default & Recommended)
    if (locMode === 'project') {
      if (projectContext && projectContext.projectDirectory) {
        return {
          targetDir: path.join(projectContext.projectDirectory, 'MediaFetch'),
          mode: 'project',
          isProjectFolder: true
        };
      }
      // If project mode is selected but project is not saved, default to user Downloads folder
      return {
        targetDir: path.join(os.homedir(), 'Downloads', 'MediaFetch'),
        mode: 'default',
        isProjectFolder: false
      };
    }

    // 3. Custom Folder Mode
    if (locMode === 'custom' && currentSettings?.downloads?.customLocation && currentSettings.downloads.customLocation.trim().length > 0) {
      return {
        targetDir: path.resolve(currentSettings.downloads.customLocation.trim()),
        mode: 'custom',
        isProjectFolder: false
      };
    }

    // 4. Default Fallback
    return {
      targetDir: path.join(os.homedir(), 'Downloads', 'MediaFetch'),
      mode: 'default',
      isProjectFolder: false
    };
  }

  /**
   * Checks if a file already exists in target directory.
   */
  checkDuplicate(targetDir, filename) {
    const filePath = path.join(targetDir, filename);
    try {
      if (fs.existsSync(filePath)) {
        const stat = fs.statSync(filePath);
        return { exists: true, filePath, size: stat.size };
      }
    } catch (_) {}
    return { exists: false, filePath, size: 0 };
  }

  /**
   * Resolves unique filename by incrementing Title (1).ext, Title (2).ext if collision exists.
   */
  resolveUniqueFilename(targetDir, desiredFilename) {
    const parsed = path.parse(desiredFilename);
    let counter = 1;
    let candidate = desiredFilename;

    while (fs.existsSync(path.join(targetDir, candidate))) {
      candidate = `${parsed.name} (${counter})${parsed.ext}`;
      counter++;
    }
    return candidate;
  }

  /**
   * Gets staging path inside .temp subfolder.
   */
  getTempStagingPath(targetDir, downloadId, ext = 'tmp') {
    const stagingDir = path.join(targetDir, '.temp_mediafetch');
    this.ensureDirExists(stagingDir);
    return path.join(stagingDir, `${downloadId}.${ext}`);
  }

  /**
   * Verifies downloaded file and moves atomically to final path.
   */
  finalizeDownloadedFile(tempFilePath, targetDirectory, desiredFilename, overwrite = false) {
    if (!fs.existsSync(tempFilePath)) {
      throw new Error(`Downloaded file does not exist: ${tempFilePath}`);
    }
    const stat = fs.statSync(tempFilePath);
    if (stat.size === 0) {
      throw new Error('Downloaded file is empty (0 bytes).');
    }

    this.ensureDirExists(targetDirectory);
    const finalFilename = overwrite ? desiredFilename : this.resolveUniqueFilename(targetDirectory, desiredFilename);
    const finalPath = path.join(targetDirectory, finalFilename);

    try {
      fs.renameSync(tempFilePath, finalPath);
    } catch (_) {
      fs.copyFileSync(tempFilePath, finalPath);
      fs.unlinkSync(tempFilePath);
    }

    logger.info(`Finalized download to ${finalPath} (${(stat.size / (1024 * 1024)).toFixed(2)} MB)`);

    // Clean up empty staging folder
    try {
      const stagingDir = path.dirname(tempFilePath);
      const remaining = fs.readdirSync(stagingDir);
      if (remaining.length === 0) {
        fs.rmdirSync(stagingDir);
      }
    } catch (_) {}

    return { finalPath, fileSize: stat.size };
  }

  ensureDirExists(dirPath) {
    if (!fs.existsSync(dirPath)) {
      fs.mkdirSync(dirPath, { recursive: true });
    }
  }

  verifyWritePermission(dirPath) {
    try {
      this.ensureDirExists(dirPath);
      const testPath = path.join(dirPath, `.mf_write_test_${Date.now()}_${Math.random().toString(36).substring(2, 6)}.tmp`);
      fs.writeFileSync(testPath, 'ok', 'utf8');
      fs.unlinkSync(testPath);
      return true;
    } catch (err) {
      logger.error(`Write permission check failed for ${dirPath}:`, err);
      return false;
    }
  }
}

export const filesystemManager = new FilesystemManager();