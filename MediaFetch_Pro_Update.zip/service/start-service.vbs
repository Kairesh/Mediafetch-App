Set WshShell = CreateObject("WScript.Shell")
Dim fso, scriptDir, nodePath
Set fso = CreateObject("Scripting.FileSystemObject")
scriptDir = fso.GetParentFolderName(WScript.ScriptFullName)

nodePath = ""
Dim candidates, c
candidates = Array( _
    "C:\Program Files\nodejs\node.exe", _
    "C:\Program Files (x86)\nodejs\node.exe", _
    WshShell.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\Programs\node\node.exe", _
    WshShell.ExpandEnvironmentStrings("%APPDATA%") & "\npm\node.exe" _
)

For Each c In candidates
    If fso.FileExists(c) Then
        nodePath = c
        Exit For
    End If
Next

On Error Resume Next
If nodePath <> "" Then
    WshShell.Run """" & nodePath & """ --max-old-space-size=48 --optimize-for-size """ & scriptDir & "\server.bundle.js""", 0, False
Else
    WshShell.Run "node --max-old-space-size=48 --optimize-for-size """ & scriptDir & "\server.bundle.js""", 0, False
End If
