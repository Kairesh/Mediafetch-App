import { spawn, execFile, execFileSync } from 'child_process';
import { promisify } from 'util';
import path from 'path';
import fs from 'fs';
import os from 'os';
import https from 'https';
import http from 'http';
import { classifyError } from '../common/errors.js';
import { dependencyManager } from './dependencies.js';
import { filesystemManager } from './filesystem.js';
import { settingsManager } from './settings.js';
import { metadataAnalyzer } from './analyzer.js';
import { logger } from './logger.js';
import { youtubeTokenManager } from './youtubeToken.js';

const execFileAsync = promisify(execFile);

let cachedServiceEncoder = null;
function getOptimalEncoderArgs(ffmpegPath) {
  if (cachedServiceEncoder) return cachedServiceEncoder;
  try {
    const encOut = execFileSync(ffmpegPath, ['-hide_banner', '-encoders'], { encoding: 'utf8', windowsHide: true, timeout: 2000 });
    if (encOut.includes('h264_nvenc')) {
      cachedServiceEncoder = [
        '-c:v', 'h264_nvenc',
        '-preset', 'p2',
        '-cq', '16',
        '-b:v', '0',
        '-maxrate', '120M',
        '-bufsize', '120M',
        '-pix_fmt', 'yuv420p'
      ];
    } else if (encOut.includes('h264_qsv')) {
      cachedServiceEncoder = [
        '-c:v', 'h264_qsv',
        '-preset', 'veryfast',
        '-global_quality', '17',
        '-pix_fmt', 'yuv420p'
      ];
    } else if (encOut.includes('h264_amf')) {
      cachedServiceEncoder = [
        '-c:v', 'h264_amf',
        '-quality', 'quality',
        '-pix_fmt', 'yuv420p'
      ];
    } else {
      cachedServiceEncoder = [
        '-c:v', 'libx264',
        '-preset', 'veryfast',
        '-crf', '17',
        '-pix_fmt', 'yuv420p',
        '-threads', '0'
      ];
    }
  } catch (e) {
    cachedServiceEncoder = [
      '-c:v', 'libx264',
      '-preset', 'veryfast',
      '-crf', '18',
      '-pix_fmt', 'yuv420p',
      '-threads', '0'
    ];
  }
  return cachedServiceEncoder;
}

export class DownloadJob {
  constructor(item, onProgress) {
    this.item = item;
    this.childProcess = undefined;
    this.activeHttpRequest = undefined;
    this.isPaused = false;
    this.isCancelled = false;
    this.lastProgressEmit = 0;
    this.throttleMs = 250;
    this.onProgressCb = onProgress;
  }

  getItem() {
    return this.item;
  }

  async start() {
    let ytdlpPath = await dependencyManager.getYtDlpExecutablePath();
    let ffmpegPath = await dependencyManager.getFfmpegExecutablePath();
    let ffprobePath = await dependencyManager.getFfprobeExecutablePath();
    const binDir = dependencyManager.getBinDir();

    // Auto-heal missing engine binaries before download begins
    if (!fs.existsSync(ytdlpPath)) {
      this.emitThrottledProgress({
        progress: 2,
        downloadedBytes: 0,
        totalBytes: 0,
        speed: '',
        eta: '',
        stageDescription: 'Auto-installing media engine (first run)...'
      });
      await dependencyManager.installYtDlp((stage, pct, msg) => {
        this.emitThrottledProgress({
          progress: Math.min(10, Math.round(pct * 0.1)),
          downloadedBytes: 0,
          totalBytes: 0,
          speed: '',
          eta: '',
          stageDescription: msg || 'Configuring media engine...'
        });
      });
      ytdlpPath = await dependencyManager.getYtDlpExecutablePath();
    }

    if (!fs.existsSync(ffmpegPath)) {
      this.emitThrottledProgress({
        progress: 10,
        downloadedBytes: 0,
        totalBytes: 0,
        speed: '',
        eta: '',
        stageDescription: 'Auto-installing FFmpeg merger (first run)...'
      });
      await dependencyManager.installFfmpeg((stage, pct, msg) => {
        this.emitThrottledProgress({
          progress: Math.min(20, 10 + Math.round(pct * 0.1)),
          downloadedBytes: 0,
          totalBytes: 0,
          speed: '',
          eta: '',
          stageDescription: msg || 'Configuring FFmpeg...'
        });
      });
      ffmpegPath = await dependencyManager.getFfmpegExecutablePath();
      ffprobePath = await dependencyManager.getFfprobeExecutablePath();
    }

    // Check if custom location setting is active
    const currentSettings = settingsManager.getSettings();
    let targetDir = this.item.targetFolder;
    if (!targetDir) {
      if (currentSettings?.downloads?.downloadLocationMode === 'custom' && currentSettings?.downloads?.customLocation?.trim()) {
        targetDir = path.resolve(currentSettings.downloads.customLocation.trim());
      } else {
        targetDir = this.item.projectFolder || filesystemManager.resolveTargetDirectory(this.item.projectContext).targetDir;
      }
    }
    const stagingDir = path.join(targetDir, '.temp_mediafetch');
    filesystemManager.ensureDirExists(stagingDir);

    // 1. Pre-Analysis to resolve genuine title, Spotify pair query, Threads or Pinterest direct media stream
    const isSpotify = (this.item.url.includes('spotify.com') || this.item.url.includes('spotify.link'));
    const isThreads = (this.item.url.includes('threads.net') || this.item.url.includes('threads.com'));
    const isPinterest = (this.item.url.includes('pinterest.com') || this.item.url.includes('pin.it'));
    const isInstagram = this.item.url.includes('instagram.com');

    // CRITICAL: Guard against stale metadata from previous downloads!
    // NEVER wipe metadata if item is part of a playlist or zip batch!
    const isPlaylistOrBatch = Boolean(this.item.metadata?.isPlaylist || this.item.metadata?.batchId || this.item.metadata?.zipPackage);
    if (!isSpotify && !isPlaylistOrBatch && this.item.metadata && this.item.metadata.url && this.item.metadata.url !== this.item.url && this.item.metadata.webpage_url !== this.item.url) {
      logger.info(`[DownloadJob] Discarding stale metadata for item ${this.item.id} (URL mismatch: ${this.item.metadata.url} vs ${this.item.url})`);
      this.item.metadata = {};
      this.item.title = '';
    }

    if (isPinterest && this.item.url.includes('pin.it')) {
      try {
        const expanded = await metadataAnalyzer.expandPinterestUrl(this.item.url);
        if (expanded && !expanded.includes('pin.it')) {
          this.item.url = expanded;
        }
      } catch (e) {}
    }

    const isGenericTitle = !this.item.title || 
      this.item.title === 'Fetching media info...' || 
      /^video by /i.test(this.item.title) || 
      /^post by /i.test(this.item.title) || 
      this.item.title.toLowerCase() === 'media';

    // Only Spotify, Threads, and Pinterest require mandatory pre-analysis.
    // - Spotify: requires query resolution or authentic title
    // - Threads: requires directStreamUrl
    // - Pinterest: requires directStreamUrl or authentic title
    const needsMandatoryPreAnalysis = (isSpotify && (!this.item.metadata?.downloadQuery || isGenericTitle)) || 
                                     (isThreads && !this.item.metadata?.directStreamUrl) ||
                                     (isPinterest && (!this.item.metadata?.directStreamUrl || isGenericTitle));

    if (needsMandatoryPreAnalysis) {
      try {
        logger.info(`[DownloadJob] Running mandatory pre-download metadata analysis for item ${this.item.id}: ${this.item.url}`);
        this.emitThrottledProgress({
          progress: 5,
          downloadedBytes: 0,
          totalBytes: 0,
          speed: '',
          eta: '',
          stageDescription: 'Analyzing media information...'
        });
        const freshMeta = await metadataAnalyzer.analyzeUrl(this.item.url);
        if (freshMeta) {
          this.item.metadata = { ...(this.item.metadata || {}), ...freshMeta };
          if (freshMeta.title && !/^video by /i.test(freshMeta.title) && freshMeta.title.toLowerCase() !== 'media') {
            this.item.title = freshMeta.title;
          }
          if (freshMeta.thumbnail && !this.item.thumbnail) {
            this.item.thumbnail = freshMeta.thumbnail;
          }
          if (freshMeta.duration && !this.item.duration) {
            this.item.duration = freshMeta.duration;
          }
        }
      } catch (metaErr) {
        logger.warn(`[DownloadJob] Pre-download metadata analysis notice for ${this.item.url}:`, metaErr.message);
        if (isSpotify && !this.item.metadata?.downloadQuery && isGenericTitle) {
          throw metaErr;
        }
      }
    }

    // 2. Resolve effective download target
    let downloadTarget = this.item.metadata?.downloadQuery || this.item.metadata?.downloadTarget || this.item.metadata?.directStreamUrl || this.item.url;
    if (isSpotify) {
      if (this.item.metadata?.downloadQuery) {
        downloadTarget = this.item.metadata.downloadQuery;
      } else {
        const qTitle = (!isGenericTitle && this.item.title) ? this.item.title : (this.item.metadata?.title || 'song');
        const qArtist = this.item.metadata?.uploader || this.item.metadata?.channel || '';
        downloadTarget = `ytsearch1:${qTitle} ${qArtist} audio`.trim();
      }
    } else if (isThreads && this.item.metadata?.directStreamUrl) {
      downloadTarget = this.item.metadata.directStreamUrl;
    } else if (isPinterest && this.item.metadata?.directStreamUrl) {
      downloadTarget = this.item.metadata.directStreamUrl;
    }

    // Direct image download support (e.g. Google Drive image files, Threads, Instagram, Pinterest photos, or Video Cover / Thumbnail)
    const isImageFile = Boolean(
      this.item.profile?.type === 'image' ||
      this.item.metadata?.mediaType === 'image' ||
      (typeof this.item.title === 'string' && /\.(jpg|jpeg|png|webp|gif|bmp|svg|tiff)($|\?)/i.test(this.item.title)) ||
      (typeof downloadTarget === 'string' && downloadTarget.startsWith('http') && /\.(jpg|jpeg|png|webp|gif|bmp|svg|tiff)($|\?)/i.test(downloadTarget))
    );

    if (isImageFile) {
      let imgTarget = downloadTarget;
      const allUrls = `${this.item.url} ${downloadTarget}`;
      const ytM = allUrls.match(/(?:v=|shorts\/|youtu\.be\/|embed\/)([a-zA-Z0-9_-]{11})/);

      if (this.item.profile?.type === 'image' && ytM && ytM[1] && !this.item.metadata?.mediaType) {
        let candidateImg = this.item.thumbnail || this.item.metadata?.thumbnail;
        if (candidateImg) {
          imgTarget = candidateImg;
        } else {
          imgTarget = `https://i.ytimg.com/vi/${ytM[1]}/maxresdefault.jpg`;
        }
      }

      logger.info(`[DownloadJob] Direct image download for item ${this.item.id}: ${imgTarget}`);
      let ext = 'jpg';
      const titleExtMatch = (this.item.title || '').match(/\.(jpg|jpeg|png|webp|gif|bmp|svg|tiff)($|\?)/i);
      const urlExtMatch = (typeof downloadTarget === 'string') ? downloadTarget.match(/\.(jpg|jpeg|png|webp|gif|bmp|svg|tiff)($|\?)/i) : null;
      if (titleExtMatch) {
        ext = titleExtMatch[1].toLowerCase();
      } else if (urlExtMatch) {
        ext = urlExtMatch[1].toLowerCase();
      } else if (this.item.profile?.container && ['jpg', 'jpeg', 'png', 'webp', 'gif', 'bmp', 'svg'].includes(this.item.profile.container.toLowerCase())) {
        ext = this.item.profile.container.toLowerCase();
      }

      let cleanCandidate = this.item.title || 'image';
      if (titleExtMatch) {
        cleanCandidate = cleanCandidate.replace(/\.(jpg|jpeg|png|webp|gif|bmp|svg|tiff)($|\?)/i, '');
      }
      const cleanTitle = filesystemManager.sanitizeFilename(cleanCandidate).substring(0, 100);
      const finalName = `${cleanTitle}.${ext}`;
      const tempImgPath = path.join(stagingDir, `${this.item.id}__MF__${cleanTitle}.${ext}`);

      const fallbacks = [];
      if (ytM && ytM[1]) {
        fallbacks.push(`https://i.ytimg.com/vi/${ytM[1]}/hq720.jpg`);
        fallbacks.push(`https://i.ytimg.com/vi/${ytM[1]}/hqdefault.jpg`);
      }

      this.emitThrottledProgress({
        progress: 10,
        downloadedBytes: 0,
        totalBytes: 0,
        speed: '',
        eta: '',
        stageDescription: 'Downloading image file...'
      });

      try {
        await this.downloadDirectStream(imgTarget, tempImgPath);
      } catch (streamErr) {
        let downloadedOk = false;
        for (const fb of fallbacks) {
          try {
            await this.downloadDirectStream(fb, tempImgPath);
            downloadedOk = true;
            break;
          } catch (_) {}
        }
        if (!downloadedOk) {
          throw streamErr;
        }
      }

      const effectiveTargetDir = this.resolveFinalTargetDir(targetDir, ext, 'image');
      const finalized = filesystemManager.finalizeDownloadedFile(tempImgPath, effectiveTargetDir, finalName);
      this.item.downloadedPath = finalized.finalPath;
      return finalized;
    }

    // Direct archive download support (e.g. zip, rar, 7z from cloud storage or direct link)
    const isDirectArchive = this.item.profile?.type === 'archive' ||
      (typeof downloadTarget === 'string' && downloadTarget.startsWith('http') && downloadTarget.match(/\.(zip|rar|7z|tar|gz)($|\?)/i));
    if (isDirectArchive) {
      logger.info(`[DownloadJob] Direct archive download for item ${this.item.id}: ${downloadTarget}`);
      const cleanCandidate = (!isGenericTitle && this.item.title) ? this.item.title : (this.item.metadata?.title || 'cloud_archive');
      const cleanTitle = filesystemManager.sanitizeFilename(cleanCandidate).substring(0, 80);
      const extMatch = downloadTarget.match(/\.(zip|rar|7z|tar|gz)($|\?)/i);
      const ext = extMatch ? extMatch[1].toLowerCase() : 'zip';
      const tempArchiveFile = path.join(stagingDir, `${this.item.id}__MF__${cleanTitle}.${ext}`);

      await this.downloadDirectStream(downloadTarget, tempArchiveFile);
      const effectiveTargetDir = targetDir;
      const finalized = filesystemManager.finalizeDownloadedFile(tempArchiveFile, effectiveTargetDir, `${cleanTitle}.${ext}`);
      this.item.downloadedPath = finalized.finalPath;
      return finalized;
    }

    // Direct video stream download (e.g. Threads video extracted directly with authentication tokens or raw MP4 CDN URLs)
    // CRITICAL: NEVER treat Spotify, YouTube as direct video streams!
    const isDirectVideoStream = !isSpotify &&
      (this.item.profile?.type === 'video' || this.item.profile?.type === 'video-only') &&
      Boolean(
        (this.item.metadata?.directStreamUrl && !this.item.metadata.directStreamUrl.includes('youtube.com') && !this.item.metadata.directStreamUrl.includes('youtu.be')) || 
        (typeof downloadTarget === 'string' && downloadTarget.startsWith('http') && 
         (downloadTarget.includes('fbcdn.net') || downloadTarget.includes('cdninstagram.com') || downloadTarget.includes('drive.google.com') || downloadTarget.includes('drive.usercontent.google.com') || (downloadTarget.match(/\.(mp4|mov|mkv|webm|avi|m4v)($|\?)/i) && !downloadTarget.includes('googlevideo.com') && !downloadTarget.includes('youtube.com') && !downloadTarget.includes('youtu.be'))))
      );

    if (isDirectVideoStream) {
      logger.info(`[DownloadJob] Direct video stream download for item ${this.item.id}: ${downloadTarget}`);
      const cleanCandidate = (!isGenericTitle && this.item.title) ? this.item.title : (this.item.metadata?.title || 'video_stream');
      const cleanTitle = filesystemManager.sanitizeFilename(cleanCandidate).substring(0, 80);
      const rawExtMatch = (typeof downloadTarget === 'string') ? (this.item.title || downloadTarget).match(/\.(mp4|mov|mkv|webm|avi|m4v)($|\?)/i) : null;
      const streamExt = rawExtMatch ? rawExtMatch[1].toLowerCase() : 'mp4';
      const tempStreamFile = path.join(stagingDir, `${this.item.id}__MF__${cleanTitle}.${streamExt}`);

      await this.downloadDirectStream(downloadTarget, tempStreamFile);
      return await this.processAndFinalizeDownloadedFile(tempStreamFile, stagingDir, targetDir, ffmpegPath, ffprobePath, binDir, cleanTitle);
    }

    const isDirectAudioStream = !isSpotify &&
      this.item.profile?.type === 'audio' &&
      Boolean(
        typeof downloadTarget === 'string' && downloadTarget.startsWith('http') &&
        (downloadTarget.includes('drive.google.com') || downloadTarget.includes('drive.usercontent.google.com') || downloadTarget.match(/\.(mp3|wav|m4a|aac|flac|ogg)($|\?)/i))
      );

    if (isDirectAudioStream) {
      logger.info(`[DownloadJob] Direct audio stream download for item ${this.item.id}: ${downloadTarget}`);
      const cleanCandidate = (!isGenericTitle && this.item.title) ? this.item.title : (this.item.metadata?.title || 'audio_stream');
      const cleanTitle = filesystemManager.sanitizeFilename(cleanCandidate).substring(0, 80);
      const rawExtMatch = (typeof downloadTarget === 'string') ? (this.item.title || downloadTarget).match(/\.(mp3|wav|m4a|aac|flac|ogg|mp4|mov)($|\?)/i) : null;
      const streamExt = rawExtMatch ? rawExtMatch[1].toLowerCase() : 'mp3';
      const tempStreamFile = path.join(stagingDir, `${this.item.id}__MF__${cleanTitle}.${streamExt}`);

      await this.downloadDirectStream(downloadTarget, tempStreamFile);
      return await this.processAndFinalizeDownloadedFile(tempStreamFile, stagingDir, targetDir, ffmpegPath, ffprobePath, binDir, cleanTitle);
    }

    // Safe staging template that never lets yt-dlp overwrite authentic title with 'Video by <username>'
    const cleanTitleCandidate = (!isGenericTitle && this.item.title)
      ? this.item.title
      : (this.item.metadata?.title && !/^video by /i.test(this.item.metadata.title) ? this.item.metadata.title : 'Media');
    const safeTitlePart = filesystemManager.sanitizeFilename(cleanTitleCandidate).substring(0, 80);
    const stagingTemplate = path.join(stagingDir, `${this.item.id}__MF__${safeTitlePart}.%(ext)s`);
    const ffmpegLocation = ffmpegPath ? path.dirname(ffmpegPath) : undefined;

    // Search targets (with automatic fallback queries for Spotify and playlist items)
    const searchTargets = [downloadTarget];

    // If downloadTarget is a YouTube URL with a video ID, add direct search by video ID as fallback
    const ytMatch = downloadTarget.match(/(?:v=|\/shorts\/|\/embed\/|youtu\.be\/|\/v\/|\/e\/)([\w-]{11})/);
    if (ytMatch && ytMatch[1]) {
      const vidSearch = `ytsearch1:${ytMatch[1]}`;
      if (!searchTargets.includes(vidSearch)) {
        searchTargets.push(vidSearch);
      }
    }

    const rawCandidateTitle = (!isGenericTitle && this.item.title) ? this.item.title : (this.item.metadata?.title || '');
    const cleanT = rawCandidateTitle
      .replace(/\s*[-–]\s*.*$/, '')
      .replace(/[\\/:*?"<>|]/g, '')
      .replace(/\s+/g, ' ')
      .trim();
    const candidateArtist = this.item.metadata?.uploader || this.item.metadata?.channel || '';

    if (cleanT && cleanT.length > 2 && (isSpotify || this.item.isPlaylist || this.item.metadata?.isPlaylist || this.item.batchId || this.item.metadata?.batchId)) {
      // Primary artist (strip featuring, commas, collab artists)
      const primaryArtist = candidateArtist.split(/[,;&/]|feat\.?|ft\.?/i)[0].trim();
      
      // Stripped title (remove parentheses, brackets like "(Pokemon Legends: Z-A but it's Lo-fi)")
      const strippedTitle = cleanT.replace(/\s*[\(\[][^\)\]]*[\)\]]/g, '').trim();

      // Cleaned characters (remove non-ASCII or corrupt accents)
      const asciiTitle = cleanT.normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/[^\x20-\x7E]/g, ' ').replace(/\s+/g, ' ').trim();
      const asciiPrimary = primaryArtist.normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/[^\x20-\x7E]/g, ' ').replace(/\s+/g, ' ').trim();

      if (asciiPrimary) {
        const alt1 = `ytsearch1:${asciiTitle} ${asciiPrimary}`.trim();
        if (!searchTargets.includes(alt1)) searchTargets.push(alt1);
      }
      if (strippedTitle && strippedTitle.length > 2 && asciiPrimary) {
        const altStr = `ytsearch1:${strippedTitle} ${asciiPrimary}`.trim();
        if (!searchTargets.includes(altStr)) searchTargets.push(altStr);
      }
      if (candidateArtist && candidateArtist !== primaryArtist) {
        const alt2 = `ytsearch1:${asciiTitle} ${candidateArtist}`.trim();
        if (!searchTargets.includes(alt2)) searchTargets.push(alt2);
      }
      const alt3 = `ytsearch1:${asciiTitle} audio`.trim();
      if (!searchTargets.includes(alt3)) searchTargets.push(alt3);
      const alt4 = `ytsearch1:${asciiTitle}`.trim();
      if (!searchTargets.includes(alt4)) searchTargets.push(alt4);
      if (strippedTitle && strippedTitle.length > 2) {
        const alt5 = `ytsearch1:${strippedTitle}`.trim();
        if (!searchTargets.includes(alt5)) searchTargets.push(alt5);
      }
    }

    return new Promise((resolve, reject) => {
      const executeDownload = (targetIndex = 0) => {
        if (this.isCancelled) {
          this.cleanupStagingFiles(stagingDir, this.item.id);
          return reject({ isCancelled: true });
        }
        if (this.isPaused) {
          return reject({ isPaused: true });
        }

        const currentTarget = searchTargets[targetIndex];
        const args = this.buildYtDlpArgs(currentTarget, this.item.profile, stagingTemplate, ffmpegLocation);

        logger.info(`[DownloadJob] Starting download for item ${this.item.id}: ${currentTarget}`);
        logger.debug('[DownloadJob] yt-dlp args:', args);

        let stdoutBuf = '';
        let stderrBuf = '';
        let watchdogTimer;

        try {
          this.childProcess = spawn(ytdlpPath, args, {
            windowsHide: true,
            stdio: ['ignore', 'pipe', 'pipe']
          });
          try {
            if (this.childProcess.pid && typeof os.setPriority === 'function') {
              os.setPriority(this.childProcess.pid, os.constants.priority.PRIORITY_BELOW_NORMAL);
            }
          } catch (_) {}

          // Watchdog timer: prevent any download from hanging perpetually in 'Connecting...'
          watchdogTimer = setTimeout(() => {
            logger.warn(`[DownloadJob] Watchdog timeout (45s) for item ${this.item.id} on query "${currentTarget}". Terminating stalled process...`);
            if (this.childProcess) {
              const pid = this.childProcess.pid;
              if (process.platform === 'win32' && pid) {
                try {
                  const { exec } = require('child_process');
                  exec(`taskkill /pid ${pid} /T /F`, () => {});
                } catch (_) {
                  try { this.childProcess.kill('SIGKILL'); } catch (_) {}
                }
              } else {
                try { this.childProcess.kill('SIGKILL'); } catch (_) {}
              }
            }
          }, 45000);

          this.emitThrottledProgress({
            progress: 1,
            downloadedBytes: 0,
            totalBytes: 0,
            speed: '',
            eta: '',
            stageDescription: 'Connecting to media server...'
          });
        } catch (err) {
          if (watchdogTimer) clearTimeout(watchdogTimer);
          return reject(classifyError(err, 'Failed to launch yt-dlp'));
        }

        this.childProcess.stdout?.on('data', (chunk) => {
          const text = chunk.toString('utf-8');
          stdoutBuf += text;
          this.parseStdout(text);
        });

        this.childProcess.stderr?.on('data', (chunk) => {
          const text = chunk.toString('utf-8');
          stderrBuf += text;
          this.parseStderr(text);
        });

        this.childProcess.on('error', (err) => {
          if (watchdogTimer) clearTimeout(watchdogTimer);
          logger.error(`[DownloadJob] Process error for item [${this.item.id}]:`, err);
          reject(classifyError(err));
        });

        this.childProcess.on('close', async (code) => {
          if (watchdogTimer) {
            clearTimeout(watchdogTimer);
            watchdogTimer = undefined;
          }
          this.childProcess = undefined;

          if (this.isPaused) {
            logger.info(`[DownloadJob] Item ${this.item.id} paused.`);
            return reject({ isPaused: true });
          }
          if (this.isCancelled) {
            logger.info(`[DownloadJob] Item ${this.item.id} cancelled.`);
            this.cleanupStagingFiles(stagingDir, this.item.id);
            return reject({ isCancelled: true });
          }

          // Check if file was produced in staging folder regardless of exit code (handles code 0 and code 101)
          const stagingResult = this.findStagingFile(stagingDir, this.item.id);

          if (stagingResult && stagingResult.filePath) {
            try {
              const finalized = await this.processAndFinalizeDownloadedFile(
                stagingResult.filePath,
                stagingDir,
                targetDir,
                ffmpegPath,
                ffprobePath,
                binDir,
                stagingResult.extractedTitle
              );
              resolve(finalized);
              return;
            } catch (finErr) {
              this.cleanupStagingFiles(stagingDir, this.item.id);
              reject(classifyError(finErr, 'Failed to process downloaded file'));
              return;
            }
          } else {
            // Check if fallback search query is available
            if (targetIndex + 1 < searchTargets.length) {
              this.cleanupStagingFiles(stagingDir, this.item.id);
              logger.info(`[DownloadJob] Query "${currentTarget}" did not produce a file (exit: ${code}), trying fallback query "${searchTargets[targetIndex + 1]}" (${targetIndex + 2}/${searchTargets.length})...`);
              return executeDownload(targetIndex + 1);
            }

            this.cleanupStagingFiles(stagingDir, this.item.id);
            const errorMsg = stderrBuf || (code === 0 ? 'Downloaded file not found in staging folder.' : `yt-dlp exited with code ${code}`);
            logger.warn(`yt-dlp failed after all queries: ${errorMsg}`);
            reject(classifyError(new Error(errorMsg), stderrBuf));
          }
        });
      };

      executeDownload(0);
    });
  }

  downloadDirectStream(streamUrl, stagingFile) {
    return new Promise((resolve, reject) => {
      const download = (targetUrl, redirectCount = 0) => {
        if (redirectCount > 5) return reject(new Error('Too many redirects'));
        const client = targetUrl.startsWith('https:') ? https : http;
        const req = client.get(targetUrl, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
            'Referer': 'https://www.threads.net/'
          }
        }, (res) => {
          if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
            let nextUrl = res.headers.location;
            if (!nextUrl.startsWith('http')) {
              try {
                nextUrl = new URL(nextUrl, targetUrl).href;
              } catch (_) {}
            }
            return download(nextUrl, redirectCount + 1);
          }
          if (res.statusCode !== 200 && res.statusCode !== 206) {
            return reject(new Error(`Direct stream download failed with HTTP status ${res.statusCode}`));
          }

          const totalBytes = parseInt(res.headers['content-length'] || '0', 10);
          let downloaded = 0;
          const out = fs.createWriteStream(stagingFile, { highWaterMark: 1024 * 1024 * 4 });
          let lastProgress = Date.now();
          let lastDownloaded = 0;

          res.on('data', (chunk) => {
            if (this.isCancelled) {
              res.destroy();
              out.close();
              try { fs.unlinkSync(stagingFile); } catch (_) {}
              return reject({ isCancelled: true });
            }
            if (this.isPaused) {
              res.destroy();
              out.close();
              return reject({ isPaused: true });
            }

            downloaded += chunk.length;
            const now = Date.now();
            if (now - lastProgress > 250) {
              const deltaBytes = downloaded - lastDownloaded;
              const deltaTime = (now - lastProgress) / 1000;
              const speedBytesPerSec = deltaTime > 0 ? deltaBytes / deltaTime : 0;
              const speedStr = (speedBytesPerSec / (1024 * 1024)).toFixed(1) + ' MB/s';
              const pct = totalBytes > 0 ? Math.min(90, Math.round((downloaded / totalBytes) * 100)) : 50;

              this.emitThrottledProgress({
                progress: pct,
                downloadedBytes: downloaded,
                totalBytes: totalBytes,
                speed: speedStr,
                eta: '',
                stageDescription: 'Downloading video stream...'
              });
              lastProgress = now;
              lastDownloaded = downloaded;
            }
          });

          res.pipe(out);
          out.on('finish', () => {
            out.close();
            this.activeHttpRequest = undefined;
            resolve({ filePath: stagingFile, totalBytes: downloaded });
          });
          out.on('error', (err) => {
            out.close();
            this.activeHttpRequest = undefined;
            try { fs.unlinkSync(stagingFile); } catch (_) {}
            reject(err);
          });
        });

        this.activeHttpRequest = req;
        req.on('error', (err) => {
          this.activeHttpRequest = undefined;
          try { fs.unlinkSync(stagingFile); } catch (_) {}
          reject(err);
        });
      };

      download(streamUrl);
    });
  }

  async processAndFinalizeDownloadedFile(currentStagingFile, stagingDir, targetDir, ffmpegPath, ffprobePath, binDir, extractedTitle) {
    const stagingExt = path.extname(currentStagingFile).replace('.', '').toLowerCase();
    let container = (this.item.profile?.container || 'mp4').toLowerCase();
    const isAudioOnly = this.item.profile?.type === 'audio' || ['mp3', 'wav', 'm4a', 'flac', 'aac', 'ogg'].includes(container);
    const isVideoOnly = this.item.profile?.type === 'video-only' || this.item.profile?.presetId === 'video-only';

    let res = 1080;
    if (this.item.profile?.resolution && typeof this.item.profile.resolution === 'number' && this.item.profile.resolution > 0) {
      res = this.item.profile.resolution;
    } else if (typeof this.item.profile?.presetId === 'string' && this.item.profile.presetId.startsWith('res-')) {
      const parsed = parseInt(this.item.profile.presetId.replace('res-', ''), 10);
      if (!isNaN(parsed) && parsed > 0) res = parsed;
    }

    const isProRes = container === 'mov' && (this.item.profile?.label?.includes('ProRes') || this.item.profile?.presetId?.includes('prores'));

    // Probe video codec using ffprobe to detect AV1/VP9 vs H.264
    let probedVideoCodec = null;
    if (ffprobePath && !isAudioOnly) {
      probedVideoCodec = await this.probeVideoCodec(currentStagingFile, ffprobePath);
      logger.info(`[DownloadJob] Probed video stream codec: ${probedVideoCodec || 'none/unknown'}`);
    }
    const isH264 = probedVideoCodec === 'h264' || probedVideoCodec === 'avc1';
    const appName = (this.item.projectContext?.application || '').toLowerCase();
    const isAfterEffects = appName.includes('aftereffects') || appName.includes('aeft') || appName.includes('ae');
    const isPremiere = (appName.includes('premiere') || appName.includes('ppro')) && !isAfterEffects;

    // Pro-Grade FFmpeg Transcoding & Adobe Normalization
    if (ffmpegPath && fs.existsSync(ffmpegPath)) {
      const processedFile = path.join(stagingDir, `proc_${Date.now()}_${this.item.id}.${container}`);
      let ffmpegArgs = [];

      if (isAudioOnly) {
        // Resolve Target Bitrate based on user profile selection
        let targetBitrate = '320k';
        const pId = this.item.profile?.presetId || '';
        const pLbl = this.item.profile?.label || '';
        if (pId === 'audio-mp3-128' || pLbl.includes('128')) targetBitrate = '128k';
        else if (pId === 'audio-mp3-192' || pLbl.includes('192')) targetBitrate = '192k';
        else if (pId === 'audio-mp3-96' || pLbl.includes('96')) targetBitrate = '96k';
        else if (pId === 'audio-m4a' || pLbl.includes('256')) targetBitrate = '256k';
        else if (pId === 'audio-mp3-320' || pLbl.includes('320')) targetBitrate = '320k';

        if (container === 'wav') {
          ffmpegArgs = ['-y', '-i', currentStagingFile, '-vn', '-c:a', 'pcm_s16le', '-ar', '48000', processedFile];
        } else if (container === 'm4a' || container === 'aac') {
          ffmpegArgs = ['-y', '-i', currentStagingFile, '-vn', '-c:a', 'aac', '-b:a', targetBitrate, '-ar', '48000', processedFile];
        } else if (container === 'flac') {
          ffmpegArgs = ['-y', '-i', currentStagingFile, '-vn', '-c:a', 'flac', processedFile];
        } else if (container === 'webm') {
          ffmpegArgs = ['-y', '-i', currentStagingFile, '-vn', '-c:a', 'libopus', '-b:a', '160k', processedFile];
        } else {
          // Guaranteed MP3 bitrate encoding (e.g. 128k, 192k, 320k)
          ffmpegArgs = ['-y', '-i', currentStagingFile, '-vn', '-c:a', 'libmp3lame', '-b:a', targetBitrate, '-ar', '44100', processedFile];
        }
      } else if (isVideoOnly) {
        if (container === 'webm') {
          if (stagingExt === 'webm') {
            ffmpegArgs = ['-y', '-i', currentStagingFile, '-c:v', 'copy', '-an', processedFile];
          } else {
            ffmpegArgs = ['-y', '-i', currentStagingFile, '-c:v', 'libvpx-vp9', '-b:v', '0', '-crf', '24', '-an', processedFile];
          }
        } else if (container === 'mkv') {
          if (stagingExt === 'mkv') {
            ffmpegArgs = ['-y', '-i', currentStagingFile, '-c:v', 'copy', '-an', processedFile];
          } else {
            ffmpegArgs = ['-y', '-i', currentStagingFile, '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-preset', 'veryfast', '-crf', '20', '-an', processedFile];
          }
        } else if (container === 'mov') {
          if (isH264) {
            ffmpegArgs = ['-y', '-i', currentStagingFile, '-c:v', 'copy', '-an', '-movflags', '+faststart', processedFile];
          } else {
            ffmpegArgs = ['-y', '-i', currentStagingFile, '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-preset', 'veryfast', '-crf', '20', '-an', '-movflags', '+faststart', processedFile];
          }
        } else {
          if (isH264 && stagingExt === 'mp4') {
            ffmpegArgs = ['-y', '-i', currentStagingFile, '-c:v', 'copy', '-an', '-movflags', '+faststart', processedFile];
          } else {
            ffmpegArgs = ['-y', '-i', currentStagingFile, '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-preset', 'veryfast', '-crf', '20', '-an', '-movflags', '+faststart', processedFile];
          }
        }
      } else if (isProRes) {
        ffmpegArgs = [
          '-y', '-i', currentStagingFile,
          '-c:v', 'prores_ks', '-profile:v', '3', '-pix_fmt', 'yuv422p10le',
          '-c:a', 'pcm_s16le', '-ar', '48000',
          processedFile
        ];
      } else if (container === 'webm') {
        if (stagingExt === 'webm') {
          ffmpegArgs = ['-y', '-i', currentStagingFile, '-c', 'copy', processedFile];
        } else if (probedVideoCodec === 'vp9' || probedVideoCodec === 'vp8' || probedVideoCodec === 'av01' || probedVideoCodec === 'av1') {
          ffmpegArgs = ['-y', '-i', currentStagingFile, '-c:v', 'copy', '-c:a', 'libopus', '-b:a', '160k', processedFile];
        } else {
          ffmpegArgs = [
            '-y', '-i', currentStagingFile,
            '-c:v', 'libvpx-vp9', '-b:v', '0', '-crf', '28', '-cpu-used', '4', '-row-mt', '1',
            '-c:a', 'libopus', '-b:a', '160k',
            processedFile
          ];
        }
      } else if (container === 'mkv') {
        if (stagingExt === 'mkv') {
          ffmpegArgs = ['-y', '-i', currentStagingFile, '-c', 'copy', processedFile];
        } else {
          ffmpegArgs = [
            '-y', '-i', currentStagingFile,
            ...getOptimalEncoderArgs(ffmpegPath),
            '-pix_fmt', 'yuv420p',
            '-c:a', 'aac', '-b:a', '320k', '-ar', '48000',
            processedFile
          ];
        }
      } else if (container === 'mov') {
        if (isH264 && (stagingExt === 'mov' || stagingExt === 'mp4')) {
          ffmpegArgs = [
            '-y', '-i', currentStagingFile,
            '-c:v', 'copy',
            '-c:a', 'aac', '-b:a', '320k', '-ar', '48000',
            '-movflags', '+faststart',
            processedFile
          ];
        } else if (isH264) {
          ffmpegArgs = [
            '-y', '-i', currentStagingFile,
            '-c:v', 'copy',
            '-c:a', 'aac', '-b:a', '320k', '-ar', '48000',
            '-af', 'aresample=async=1000:first_pts=0',
            '-movflags', '+faststart',
            processedFile
          ];
        } else {
          ffmpegArgs = [
            '-y',
            '-hwaccel', 'auto',
            '-threads', '0',
            '-i', currentStagingFile,
            ...getOptimalEncoderArgs(ffmpegPath),
            '-pix_fmt', 'yuv420p',
            '-map', '0:v:0',
            '-map', '0:a?',
            '-c:a', 'aac',
            '-b:a', '320k',
            '-ar', '48000',
            '-movflags', '+faststart',
            processedFile
          ];
        }
      } else {
        // MP4 container: Only bit-for-bit stream copy if source is already confirmed H.264
        // If it's VP9/AV1 (e.g. YouTube 4K), we MUST transcode to master H.264 with hardware acceleration
        if (isH264 && (stagingExt === 'mp4' || stagingExt === 'mov') && container === 'mp4') {
          ffmpegArgs = [
            '-y', '-i', currentStagingFile,
            '-c', 'copy',
            '-movflags', '+faststart',
            processedFile
          ];
        } else {
          // AV1/VP9 4K/8K: Must explicitly map both streams so Adobe gets video+audio.
          // -map 0:v:0 -map 0:a? forces FFmpeg to include both streams without failing on silent video.
          // -pix_fmt yuv420p is required by h264_nvenc (NVENC cannot accept NV12 directly from AV1 decoder).
          // -movflags +faststart enables streaming seek in Adobe timeline.
          ffmpegArgs = [
            '-y',
            '-hwaccel', 'auto',
            '-threads', '0',
            '-i', currentStagingFile,
            ...getOptimalEncoderArgs(ffmpegPath),
            '-pix_fmt', 'yuv420p',
            '-map', '0:v:0',
            '-map', '0:a?',
            '-c:a', 'aac',
            '-b:a', '320k',
            '-ar', '48000',
            '-movflags', '+faststart',
            processedFile
          ];
        }
      }

      try {
        this.emitThrottledProgress({
          progress: 92,
          downloadedBytes: this.item.downloadedBytes || 0,
          totalBytes: this.item.totalBytes || 0,
          speed: '',
          eta: 'Finalizing...',
          stageDescription: `Processing & optimizing ${container.toUpperCase()} for Adobe...`
        });
        logger.info(`[DownloadJob] Transcoding with FFmpeg: ${ffmpegArgs.join(' ')}`);

        await new Promise((resFf) => {
          const ffProc = spawn(ffmpegPath, ffmpegArgs, { windowsHide: true });
          try {
            if (ffProc.pid && typeof os.setPriority === 'function') {
              os.setPriority(ffProc.pid, os.constants.priority.PRIORITY_BELOW_NORMAL);
            }
          } catch (_) {}
          let ffErr = '';
          ffProc.stderr?.on('data', (chunk) => {
            const text = chunk.toString();
            ffErr = (ffErr + text).slice(-1500);
            const timeMatch = text.match(/time=(\d+):(\d+):(\d+\.\d+)/);
            const speedMatch = text.match(/speed=\s*([\d\.]+x)/);
            const fpsMatch = text.match(/fps=\s*([\d\.]+)/);
            if (timeMatch) {
              const curSec = (parseFloat(timeMatch[1]) * 3600) + (parseFloat(timeMatch[2]) * 60) + parseFloat(timeMatch[3]);
              const durSec = this.item.duration || 0;
              let pct = 92;
              if (durSec > 0) {
                pct = Math.min(99, Math.max(91, 91 + Math.round((curSec / durSec) * 8)));
              }
              const spd = speedMatch ? speedMatch[1] : (fpsMatch ? `${fpsMatch[1]} fps` : '');
              const resTag = res >= 2160 ? '4K' : (res >= 1440 ? '2K' : (res >= 1080 ? 'Full HD' : (res >= 720 ? '720p HD' : 'video')));
              this.emitThrottledProgress({
                progress: pct,
                downloadedBytes: this.item.downloadedBytes || 0,
                totalBytes: this.item.totalBytes || 0,
                speed: spd ? `Optimizing at ${spd}` : '',
                eta: 'Almost ready...',
                stageDescription: `Optimizing ${resTag} stream for Adobe timeline (${pct}%)...`
              });
            }
          });
          ffProc.on('close', (code) => {
            if (code === 0) resFf();
            else {
              logger.warn(`FFmpeg exit code ${code}: ${ffErr.slice(-300)}`);
              resFf();
            }
          });
          ffProc.on('error', (err) => {
            logger.warn('FFmpeg spawn notice:', err);
            resFf();
          });
        });

        if (fs.existsSync(processedFile) && fs.statSync(processedFile).size > 1000) {
          try { fs.unlinkSync(currentStagingFile); } catch (_) {}
          currentStagingFile = processedFile;
        }
      } catch (ffmpegErr) {
        logger.warn('[DownloadJob] FFmpeg processing notice:', ffmpegErr);
      }
    }

    const ext = this.getContainerExtension(this.item.profile || {});
    let finalName = '';

    if (this.item.profile?.customFilename && this.item.profile.customFilename.trim().length > 0) {
      const customClean = filesystemManager.sanitizeFilename(this.item.profile.customFilename.trim());
      finalName = customClean + '.' + ext;
      this.item.title = customClean;
    } else {
      const curTitle = (this.item.title || '').trim();
      const curIsGeneric = !curTitle || curTitle === 'Fetching media info...' || /^video by /i.test(curTitle) || /^post by /i.test(curTitle) || curTitle.toLowerCase() === 'media';
      
      const extTitle = (extractedTitle || '').trim();
      const extIsGeneric = !extTitle || /^video by /i.test(extTitle) || /^post by /i.test(extTitle) || extTitle.toLowerCase() === 'media';

      const metaTitle = (this.item.metadata?.title || '').trim();
      const metaIsGeneric = !metaTitle || metaTitle === 'Fetching media info...' || /^video by /i.test(metaTitle) || /^post by /i.test(metaTitle) || metaTitle.toLowerCase() === 'media';

      let chosenTitle = 'MediaFetch_Media';
      if (!metaIsGeneric) {
        chosenTitle = metaTitle;
      } else if (!curIsGeneric) {
        chosenTitle = curTitle;
      } else if (!extIsGeneric) {
        chosenTitle = extTitle;
      } else if (metaTitle && metaTitle !== 'Fetching media info...') {
        chosenTitle = metaTitle.replace(/^video by /i, 'Clip - ').trim();
      } else if (curTitle && curTitle !== 'Fetching media info...') {
        chosenTitle = curTitle.replace(/^video by /i, 'Clip - ').trim();
      } else if (extTitle) {
        chosenTitle = extTitle.replace(/^video by /i, 'Clip - ').trim();
      }

      const cleanChosen = filesystemManager.sanitizeFilename(chosenTitle);
      finalName = cleanChosen + '.' + ext;
      this.item.title = cleanChosen;
    }

    const effectiveTargetDir = this.resolveFinalTargetDir(targetDir, ext, this.item.profile?.type);
    const finalized = filesystemManager.finalizeDownloadedFile(currentStagingFile, effectiveTargetDir, finalName);
    this.item.downloadedPath = finalized.finalPath;
    this.cleanupStagingFiles(stagingDir, this.item.id);
    return finalized;
  }

  resolveFinalTargetDir(baseTargetDir, ext, profileType) {
    // For ZIP packages, ALWAYS directly return baseTargetDir (staging folder) - ZERO loose wrapper folders!
    if (this.item.zipPackage || this.item.metadata?.zipPackage) {
      if (baseTargetDir) {
        filesystemManager.ensureDirExists(baseTargetDir);
        return baseTargetDir;
      }
    }

    // If this item is part of a playlist/cloud folder or has subfolders/custom folder specified,
    // preserve the exact folder hierarchy requested by the user without wrapper pollution!
    const isPlaylistOrCustom = Boolean(
      this.item.metadata?.isPlaylist ||
      this.item.metadata?.subFolderName ||
      this.item.metadata?.customFolderName ||
      this.item.metadata?.playlistTitle ||
      (this.item.targetFolder && this.item.targetFolder !== filesystemManager.resolveTargetDirectory().targetDir)
    );

    if (isPlaylistOrCustom && baseTargetDir) {
      filesystemManager.ensureDirExists(baseTargetDir);
      return baseTargetDir;
    }

    let root = baseTargetDir || filesystemManager.resolveTargetDirectory().targetDir;
    root = root.replace(/[\/\\]+$/, '');
    if (/[\/\\](?:LinkMediaFetch|SerachMediafetch)$/i.test(root)) {
      root = path.dirname(root);
    }
    if (!/[\/\\]MediaFetch$/i.test(root) && path.basename(root).toLowerCase() !== 'mediafetch') {
      root = path.join(root, 'MediaFetch');
    }

    const cleanExt = (ext || '').toLowerCase().replace(/^\./, '').split('?')[0];
    const isAudio = profileType === 'audio' || ['mp3', 'wav', 'm4a', 'flac', 'aac', 'ogg', 'opus', 'aiff', 'm4p'].includes(cleanExt);
    const isImage = profileType === 'image' || ['jpg', 'jpeg', 'png', 'webp', 'gif', 'bmp', 'svg', 'tiff', 'tif', 'ico'].includes(cleanExt);
    const subType = isAudio ? 'Audio' : (isImage ? 'Image' : 'Video');

    const finalDir = path.join(root, 'LinkMediaFetch', subType);
    filesystemManager.ensureDirExists(finalDir);
    return finalDir;
  }

  pause() {
    this.isPaused = true;
    this.killProcess();
  }

  cancel() {
    this.isCancelled = true;
    this.killProcess();
  }

  killProcess() {
    if (this.activeHttpRequest) {
      try {
        this.activeHttpRequest.destroy();
        this.activeHttpRequest = undefined;
      } catch (_) {}
    }
    if (this.childProcess) {
      try {
        if (process.platform === 'win32') {
          try {
            spawn('taskkill', ['/pid', String(this.childProcess.pid), '/f', '/t'], { windowsHide: true });
          } catch (_) {}
          try {
            this.childProcess.kill('SIGKILL');
          } catch (_) {}
        } else {
          this.childProcess.kill('SIGKILL');
        }
      } catch (err) {
        logger.warn(`[DownloadJob] Kill error for [${this.item.id}]:`, err);
      }
    }
  }

  async probeVideoCodec(filePath, ffprobePath) {
    if (!ffprobePath || !fs.existsSync(ffprobePath) || !fs.existsSync(filePath)) {
      return null;
    }
    try {
      const { stdout } = await execFileAsync(ffprobePath, [
        '-v', 'error',
        '-select_streams', 'v:0',
        '-show_entries', 'stream=codec_name',
        '-of', 'default=noprint_wrappers=1:nokey=1',
        filePath
      ], { windowsHide: true });
      return (stdout || '').trim().toLowerCase();
    } catch (err) {
      logger.warn('[DownloadJob] ffprobe probe notice:', err);
      return null;
    }
  }

  parseStdout(data) {
    if (this.isPaused || this.isCancelled) return;
    const lines = data.split(/\r?\n/);
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed) continue;
      if (trimmed.startsWith('MF_TITLE:')) {
        const t = trimmed.substring('MF_TITLE:'.length).trim();
        const isGeneric = !t || /^video by /i.test(t) || /^post by /i.test(t) || /^tweet by /i.test(t) || t.toLowerCase() === 'media';
        if (t && t.length > 0 && !isGeneric && (this.item.title === 'Fetching media info...' || !this.item.title || /^video by /i.test(this.item.title))) {
          this.item.title = t;
          this.onProgressCb?.({
            progress: this.item.progress || 0,
            downloadedBytes: this.item.downloadedBytes || 0,
            totalBytes: this.item.totalBytes || 0,
            speed: this.item.speed || '',
            eta: this.item.eta || '',
            stageDescription: 'Starting download...'
          });
        }
      } else if (trimmed.startsWith('[download] Destination:') || trimmed.startsWith('[download] Got destination:')) {
        const destMatch = trimmed.match(/__MF__(.*?)\.[a-zA-Z0-9]+$/);
        if (destMatch && destMatch[1] && (this.item.title === 'Fetching media info...' || !this.item.title)) {
          const dt = destMatch[1].trim();
          if (!/^video by /i.test(dt) && !/^post by /i.test(dt)) {
            this.item.title = dt;
          }
        }
      } else if (trimmed.startsWith('MF_PROGRESS:')) {
        const parts = trimmed.substring('MF_PROGRESS:'.length).split('|');
        if (parts.length >= 5) {
          const rawPercent = parts[0].replace('%', '').trim();
          const percent = parseFloat(rawPercent) || 0;
          const downloadedStr = parts[1].trim();
          const totalStr = parts[2].trim();
          const speedStr = parts[3].trim();
          const etaStr = parts[4].trim();
          const downloadedBytes = this.parseBytes(downloadedStr);
          const totalBytes = this.parseBytes(totalStr);
          this.emitThrottledProgress({
            progress: Math.min(90, Math.max(0, percent)),
            downloadedBytes,
            totalBytes,
            speed: speedStr || '',
            eta: etaStr || '',
            stageDescription: 'Downloading high-quality media stream...'
          });
        }
      } else if (trimmed.includes('[Merger]') || trimmed.includes('[ExtractAudio]') || trimmed.includes('[FixupM3u8]')) {
        this.emitThrottledProgress({
          progress: 91,
          downloadedBytes: this.item.downloadedBytes || 0,
          totalBytes: this.item.totalBytes || 0,
          speed: '',
          eta: 'Finalizing...',
          stageDescription: 'Merging audio and video streams (almost ready)...'
        });
      }
    }
  }

  parseStderr(data) {
    if (this.isPaused || this.isCancelled) return;
    if (data.includes('[Merger]') || data.includes('[ExtractAudio]') || data.includes('Post-process')) {
      this.emitThrottledProgress({
        progress: 91,
        downloadedBytes: this.item.downloadedBytes || 0,
        totalBytes: this.item.totalBytes || 0,
        speed: '',
        eta: 'Finalizing...',
        stageDescription: 'Processing & remuxing with FFmpeg (almost ready)...'
      });
      return;
    }

    if (data.includes('Opening') || data.includes('Press [q]') || data.includes('Metadata:') || data.includes('Stream #')) {
      this.emitThrottledProgress({
        progress: Math.max(3, this.item.progress || 0),
        downloadedBytes: this.item.downloadedBytes || 0,
        totalBytes: this.item.totalBytes || 0,
        speed: '',
        eta: '',
        stageDescription: 'Seeking media server stream...'
      });
    }

    const timeMatch = data.match(/time=\s*([\d\.:]+)/);
    const sizeMatch = data.match(/size=\s*(\d+)\s*[kK]i?B/);
    const speedMatch = data.match(/speed=\s*([\d\.]+)x/);
    if (timeMatch) {
      const sizeKb = sizeMatch ? parseInt(sizeMatch[1], 10) : 0;
      const downloadedBytes = sizeKb * 1024;
      const speedStr = speedMatch ? `${speedMatch[1]}x` : '';

      let pct = 50;
      if (this.item.profile?.timeRange) {
        const tr = this.item.profile.timeRange;
        const s = this.parseTimeToSeconds(tr.start);
        const e = this.parseTimeToSeconds(tr.end);
        const dur = (e > s) ? (e - s) : 0;
        const cur = this.parseTimeToSeconds(timeMatch[1]);
        if (dur > 0) {
          pct = Math.min(95, Math.max(5, Math.round((cur / dur) * 100)));
        }
      }

      this.emitThrottledProgress({
        progress: pct,
        downloadedBytes: downloadedBytes > 0 ? downloadedBytes : (this.item.downloadedBytes || 0),
        totalBytes: this.item.totalBytes || 0,
        speed: speedStr,
        eta: '',
        stageDescription: `Downloading trimmed stream (${pct}%)...`
      });
    }
  }

  emitThrottledProgress(update) {
    if (this.isPaused || this.isCancelled) return;
    const now = Date.now();
    if (now - this.lastProgressEmit >= this.throttleMs) {
      this.lastProgressEmit = now;
      this.onProgressCb?.(update);
    }
  }

  parseBytes(str) {
    if (!str || str === 'N/A' || str === 'Unknown') return 0;
    const match = str.match(/([\d\.]+)\s*([KMGTP]?i?B)/i);
    if (!match) return 0;
    const num = parseFloat(match[1]);
    const unit = match[2].toUpperCase();
    const multipliers = {
      'B': 1,
      'KB': 1024,
      'KIB': 1024,
      'MB': 1024 * 1024,
      'MIB': 1024 * 1024,
      'GB': 1024 * 1024 * 1024,
      'GIB': 1024 * 1024 * 1024,
      'TB': 1024 * 1024 * 1024 * 1024
    };
    return Math.round(num * (multipliers[unit] || 1));
  }

  parseTimeToSeconds(val) {
    if (!val) return 0;
    const clean = String(val).trim();
    if (!clean) return 0;
    const parts = clean.split(':').map(p => parseFloat(p.trim()) || 0);
    if (parts.length >= 3) {
      let sec = parts[0] * 3600 + parts[1] * 60 + parts[2];
      if (parts.length >= 4) sec += parts[3] / 30; // frames fallback
      return sec;
    } else if (parts.length === 2) {
      return parts[0] * 60 + parts[1];
    } else if (parts.length === 1) {
      return parts[0];
    }
    return 0;
  }

  normalizeTime(val, fallback = '00:00:00') {
    if (!val) return fallback;
    const clean = String(val).trim();
    if (!clean) return fallback;

    let totalSec = this.parseTimeToSeconds(clean);
    if (isNaN(totalSec) || totalSec < 0) totalSec = 0;

    const h = Math.floor(totalSec / 3600);
    const m = Math.floor((totalSec % 3600) / 60);
    const s = Math.floor(totalSec % 60);
    const frac = totalSec - Math.floor(totalSec);
    const fracStr = frac > 0 ? ('.' + Math.round(frac * 1000).toString().padStart(3, '0')) : '';

    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}${fracStr}`;
  }

  getContainerExtension(profile) {
    const c = (profile.container || '').toLowerCase();
    if (c) {
      return c;
    }
    if (profile.type === 'audio') {
      if (profile.presetId === 'audio-wav') return 'wav';
      if (profile.presetId === 'audio-m4a') return 'm4a';
      if (profile.presetId === 'audio-flac') return 'flac';
      return 'mp3';
    }
    return 'mp4';
  }

  findStagingFile(stagingDir, downloadId) {
    if (!fs.existsSync(stagingDir)) return null;
    const files = fs.readdirSync(stagingDir);
    const found = files.find(f => f.startsWith(downloadId) && !f.endsWith('.part') && !f.endsWith('.ytdl') && !f.endsWith('.temp'));
    if (!found) return null;

    let extractedTitle;
    if (found.includes('__MF__')) {
      const parts = found.split('__MF__');
      if (parts.length > 1) {
        extractedTitle = path.parse(parts[1]).name;
      }
    }
    return {
      filePath: path.join(stagingDir, found),
      extractedTitle
    };
  }

  cleanupStagingFiles(stagingDir, downloadId) {
    try {
      if (!fs.existsSync(stagingDir)) return;
      const files = fs.readdirSync(stagingDir);
      const now = Date.now();
      for (const f of files) {
        const fullPath = path.join(stagingDir, f);
        if (downloadId && f.startsWith(downloadId)) {
          try { fs.unlinkSync(fullPath); } catch (e) {}
        } else {
          try {
            const stat = fs.statSync(fullPath);
            if (now - stat.mtimeMs > 3600 * 1000) {
              fs.unlinkSync(fullPath);
            }
          } catch (_) {}
        }
      }
      try {
        const remaining = fs.readdirSync(stagingDir);
        if (remaining.length === 0) {
          fs.rmdirSync(stagingDir);
        }
      } catch (_) {}
    } catch (e) {}
  }

  buildYtDlpArgs(url, profile, outputTemplate, ffmpegBinDir) {
    const cleanUrl = url.trim();
    const isYouTube = youtubeTokenManager.isYouTubeUrl(cleanUrl);
    const isSearchQuery = cleanUrl.startsWith('ytsearch');

    const cacheDir = path.join(process.env.LOCALAPPDATA || process.env.APPDATA || os.tmpdir(), 'MediaFetch', '.cache');

    const nodeBin = dependencyManager.getNodeExecutablePath();
    const jsRuntime = nodeBin === 'node' ? 'node' : `node:${nodeBin}`;

    const args = [
      '--newline',
      '--continue',
      '--no-playlist',
      '--no-check-certificates',
      '--no-mtime',
      '--cache-dir', cacheDir,
      '--js-runtimes', jsRuntime,
      ...(isYouTube ? ['--remote-components', 'ejs:github', '--extractor-args', 'youtube:player_client=web_embedded,android'] : []),
      ...(isSearchQuery ? ['--max-downloads', '1', '-i'] : []),
      '--progress-template', 'MF_PROGRESS:%(progress._percent_str)s|%(progress._downloaded_bytes_str)s|%(progress._total_bytes_str|progress._total_bytes_estimate_str)s|%(progress._speed_str)s|%(progress._eta_str)s',
      '--print', 'pre_process:MF_TITLE:%(title)s',
      '--no-simulate',
      '--retries', '10',
      '--fragment-retries', '20',
      '--file-access-retries', '5',
      '--buffer-size', '16M',
      '--http-chunk-size', '10M',
      '--concurrent-fragments', '8',
      '--socket-timeout', '30',
      '-o', outputTemplate
    ];

    if (ffmpegBinDir) {
      args.push('--ffmpeg-location', ffmpegBinDir);
    }

    if (profile.timeRange && (profile.timeRange.start || profile.timeRange.end)) {
      let start = this.normalizeTime(profile.timeRange.start, '00:00:00');
      let end = this.normalizeTime(profile.timeRange.end, '99:59:59');
      const startSec = this.parseTimeToSeconds(start);
      const endSec = this.parseTimeToSeconds(end);
      if (endSec > 0 && startSec > endSec) {
        const tmp = start;
        start = end;
        end = tmp;
      }
      // Fast keyframe seek on remote server / manifest without downloading entire stream from beginning
      args.push('--download-sections', `*${start}-${end}`);
      // Accelerate FFmpeg network seeking and copy streams without re-encoding
      args.push('--downloader-args', 'ffmpeg_i:-seekable 1 -reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5');
      args.push('--downloader-args', 'ffmpeg:-c copy');
    } else {
      // Accelerate stream reading with network auto-reconnect
      args.push('--downloader-args', 'ffmpeg_i:-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5');
    }

    const localAppData = process.env.LOCALAPPDATA || (os.homedir ? path.join(os.homedir(), 'AppData', 'Local') : '');
    const cookiesFilePath = localAppData ? path.join(localAppData, 'MediaFetch', 'cookies.txt') : '';
    if (cookiesFilePath && fs.existsSync(cookiesFilePath) && fs.statSync(cookiesFilePath).size > 10) {
      args.push('--cookies', cookiesFilePath);
    } else {
      const cookiesBrowser = settingsManager.getSettings()?.engine?.cookiesBrowser || 'none';
      if (cookiesBrowser && cookiesBrowser !== 'none') {
        args.push('--cookies-from-browser', cookiesBrowser);
      }
    }

    const container = (profile.container || 'mp4').toLowerCase();
    const isExplicitVideo = ['mp4', 'mov', 'mkv', 'webm', 'avi'].includes(container);
    const isAudio = !isExplicitVideo && (profile.type === 'audio' || ['mp3', 'wav', 'm4a', 'flac', 'aac', 'ogg'].includes(container));
    const isVideoOnly = profile.type === 'video-only' || profile.presetId === 'video-only';

    let res = 1080;
    if (profile.resolution && typeof profile.resolution === 'number' && profile.resolution > 0) {
      res = profile.resolution;
    } else if (profile.presetId === 'video-4k' || profile.presetId === 'res-2160') {
      res = 2160;
    } else if (profile.presetId === 'video-1440p' || profile.presetId === 'res-1440') {
      res = 1440;
    } else if (profile.presetId === 'video-1080p' || profile.presetId === 'res-1080') {
      res = 1080;
    } else if (profile.presetId === 'video-720p' || profile.presetId === 'res-720') {
      res = 720;
    } else if (profile.presetId === 'video-480p' || profile.presetId === 'res-480') {
      res = 480;
    } else if (profile.presetId === 'video-360p' || profile.presetId === 'res-360') {
      res = 360;
    } else if (profile.presetId === 'best-available' || profile.presetId === 'video-only') {
      res = 9999;
    } else if (typeof profile.presetId === 'string' && profile.presetId.startsWith('res-')) {
      const parsed = parseInt(profile.presetId.replace('res-', ''), 10);
      if (!isNaN(parsed) && parsed > 0) res = parsed;
    }

    if (profile.customFormatId) {
      args.push('-f', profile.customFormatId);
    } else if (isAudio) {
      let targetFormat = (container === 'wav' || container === 'm4a' || container === 'flac') ? container : 'mp3';
      let targetQuality = '0';
      const pId = profile.presetId || '';
      const pLbl = profile.label || '';
      if (pId === 'audio-mp3-128' || pLbl.includes('128')) targetQuality = '128K';
      else if (pId === 'audio-mp3-192' || pLbl.includes('192')) targetQuality = '192K';
      else if (pId === 'audio-mp3-96' || pLbl.includes('96')) targetQuality = '96K';
      else if (pId === 'audio-mp3-320' || pLbl.includes('320')) targetQuality = '320K';

      if (container === 'webm') {
        args.push('-f', 'bestaudio[ext=webm]/bestaudio[acodec=opus]/bestaudio/best', '-x');
      } else {
        args.push(
          '-f', 'bestaudio/best',
          '-x',
          '--audio-format', targetFormat,
          '--audio-quality', targetQuality
        );
      }
    } else if (isVideoOnly) {
      const hasTimeRange = Boolean(profile.timeRange && (profile.timeRange.start || profile.timeRange.end));
      if (container === 'webm') {
        const fStr = (res >= 9999)
          ? 'bestvideo[ext=webm]/bestvideo[vcodec^=vp]/bestvideo/best'
          : `bestvideo[height<=?${res}][ext=webm]/bestvideo[height<=?${res}][vcodec^=vp]/bestvideo[height<=?${res}]/bestvideo/best`;
        args.push('-f', fStr);
      } else if (hasTimeRange) {
        // Fast-seeking trimmed video: prioritize HLS (m3u8) slice streaming for instant download
        const maxH = (res < 9999) ? res : 1080;
        const fStr = `bestvideo[height<=?${maxH}][protocol^=m3u8]/bestvideo[height<=?${maxH}][vcodec^=avc1]/bestvideo[height<=?${maxH}][vcodec^=h264]/bestvideo[height<=?${maxH}][ext=mp4][vcodec!*=av01]/bestvideo[height<=?${maxH}]/best`;
        args.push('-f', fStr);
      } else if (res >= 1440) {
        // 8K (4320p), 4K (2160p), 1440p (2K), or Best Available: YouTube only encodes in VP9 or AV1
        // Prioritize modern AV1: cuts file size in half with higher fidelity
        const fStr = (res >= 9999)
          ? 'bestvideo[vcodec^=av01]/bestvideo[vcodec^=vp9]/bestvideo/best'
          : (res >= 4320)
            ? 'bestvideo[height<=4320][vcodec^=av01]/bestvideo[height<=4320][vcodec^=vp9]/bestvideo[height<=4320]/best'
            : (res >= 2160)
              ? 'bestvideo[height<=2160][vcodec^=av01]/bestvideo[height<=2160][vcodec^=vp9]/bestvideo[height<=2160]/best'
              : 'bestvideo[height<=1440][vcodec^=av01]/bestvideo[height<=1440][vcodec^=vp9]/bestvideo[height<=1440]/best';
        args.push('-f', fStr);
      } else {
        // For 1080p and below, prioritize native H.264 (avc1) for Adobe compatibility
        const fStr = `bestvideo[height<=?${res}][vcodec^=avc1]/bestvideo[height<=?${res}][vcodec^=h264]/bestvideo[height<=?${res}][ext=mp4][vcodec!*=av01]/bestvideo[height<=?${res}]/best`;
        args.push('-f', fStr);
      }
    } else {
      // Video + Audio
      const hasTimeRange = Boolean(profile.timeRange && (profile.timeRange.start || profile.timeRange.end));
      if (container === 'webm') {
        const fStr = (res >= 9999)
          ? 'bestvideo[ext=webm]+bestaudio[ext=webm]/bestvideo[vcodec^=vp]+bestaudio[acodec^=opus]/bestvideo+bestaudio/best'
          : `bestvideo[height<=?${res}][ext=webm]+bestaudio[ext=webm]/bestvideo[height<=?${res}][vcodec^=vp]+bestaudio[acodec^=opus]/bestvideo[height<=?${res}]+bestaudio/bestvideo+bestaudio/best`;
        args.push('-f', fStr);
      } else if (hasTimeRange) {
        // Fast-seeking trimmed video: prioritize HLS (m3u8) slice streaming for instant download in seconds
        const maxH = (res < 9999) ? res : 1080;
        const fStr = `bestvideo[height<=?${maxH}][protocol^=m3u8]+bestaudio[protocol^=m3u8]/bestvideo[height<=?${maxH}][vcodec^=avc1]+bestaudio[ext=m4a]/bestvideo[height<=?${maxH}][vcodec^=h264]+bestaudio[ext=m4a]/bestvideo[height<=?${maxH}][ext=mp4][vcodec!*=av01]+bestaudio[ext=m4a]/bestvideo[height<=?${maxH}]+bestaudio/best`;
        args.push('-f', fStr);
      } else if (res >= 1440) {
        // 8K (4320p), 4K (2160p), 1440p (2K), or Best Available:
        // Prioritize AV1 (vcodec^=av01) first, but allow any best audio and never drop to 360p
        const fStr = (res >= 9999)
          ? 'bestvideo[vcodec^=av01]+bestaudio[ext=m4a]/bestvideo[vcodec^=vp9]+bestaudio[ext=m4a]/bestvideo+bestaudio[ext=m4a]/bestvideo[vcodec^=av01]+bestaudio/bestvideo[vcodec^=vp9]+bestaudio/bestvideo+bestaudio/best'
          : `bestvideo[height<=?${res}][vcodec^=av01]+bestaudio[ext=m4a]/bestvideo[height<=?${res}][vcodec^=vp9]+bestaudio[ext=m4a]/bestvideo[height<=?${res}]+bestaudio[ext=m4a]/bestvideo[height<=?${res}][vcodec^=av01]+bestaudio/bestvideo[height<=?${res}][vcodec^=vp9]+bestaudio/bestvideo[height<=?${res}]+bestaudio/best`;
        args.push('-f', fStr);
      } else {
        // Guaranteed TRUE resolution (1080p, 720p, 480p):
        // 1. Prioritizes native H.264 (avc1) + AAC (m4a) for bit-for-bit master quality and instant copy
        // 2. Automatically picks highest available resolution up to the target (1080p videos get 1080p; 720p videos get 720p; 480p videos get 480p)
        const fStr = `bestvideo[height<=?${res}][vcodec^=avc1]+bestaudio[ext=m4a]/bestvideo[height<=?${res}][vcodec^=h264]+bestaudio[ext=m4a]/bestvideo[height<=?${res}][ext=mp4][vcodec!*=av01]+bestaudio[ext=m4a]/bestvideo[height<=?${res}]+bestaudio[ext=m4a]/bestvideo[height<=?${res}]+bestaudio/best[height<=?${res}]/best`;
        args.push('-f', fStr);
      }
    }

    if (!isAudio && ['mp4', 'mkv', 'webm', 'mov'].includes(container)) {
      if (container === 'mov') {
        // Matroska (MKV) accepts AV1, VP9, H.264, AAC, and Opus losslessly without muxer errors.
        // yt-dlp fails with 'av1 only supported in MP4 and AVIF. Conversion failed!' if --merge-output-format mov is used.
        // We stage as MKV, and our pro FFmpeg normalizer then transcodes/remuxes cleanly to QuickTime MOV.
        args.push('--merge-output-format', 'mkv');
      } else {
        args.push('--merge-output-format', container);
      }
    }

    args.push(cleanUrl);
    return args;
  }
}