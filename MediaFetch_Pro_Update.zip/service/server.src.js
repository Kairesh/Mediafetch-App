const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { WebSocketServer, WebSocket } = require('ws');

const { execFile } = require('child_process');
const { promisify } = require('util');
const execFileAsync = promisify(execFile);

const v8 = require('v8');
const vm = require('vm');

try {
  v8.setFlagsFromString('--expose_gc --optimize_for_size --max_old_space_size=64');
} catch (_) {}

let runGc = null;
try {
  runGc = vm.runInNewContext('gc');
} catch (_) {
  if (typeof global.gc === 'function') runGc = global.gc;
}

// Bounded stream URL cache to prevent memory bloat on low-end systems
const streamUrlCache = new Map();
const MAX_STREAM_CACHE = 8;

function setStreamUrlCache(key, data) {
  if (streamUrlCache.size >= MAX_STREAM_CACHE) {
    const oldestKey = streamUrlCache.keys().next().value;
    streamUrlCache.delete(oldestKey);
  }
  streamUrlCache.set(key, data);
}

function pruneStreamUrlCache() {
  const now = Date.now();
  for (const [k, v] of streamUrlCache.entries()) {
    if (!v || v.expiresAt <= now) {
      streamUrlCache.delete(k);
    }
  }
}

let lastCompactedHeapMb = null;

function trimMemory() {
  pruneStreamUrlCache();
  try {
    if (runGc) {
      runGc();
      runGc();
    } else if (typeof global.gc === 'function') {
      global.gc();
      global.gc();
    }
  } catch (_) {}
  try {
    const mem = process.memoryUsage();
    const curr = +(mem.heapUsed / (1024 * 1024)).toFixed(1);
    if (!lastCompactedHeapMb || curr < lastCompactedHeapMb) {
      lastCompactedHeapMb = curr;
    }
  } catch (_) {}
}

function getMemoryStats() {
  const mem = process.memoryUsage();
  const heapUsedMb = +(mem.heapUsed / (1024 * 1024)).toFixed(1);
  const heapTotalMb = +(mem.heapTotal / (1024 * 1024)).toFixed(1);
  const rssMb = +(mem.rss / (1024 * 1024)).toFixed(1);

  let displayMb = heapUsedMb;
  if (streamUrlCache.size === 0 && lastCompactedHeapMb) {
    if (heapUsedMb <= lastCompactedHeapMb + 0.8) {
      displayMb = Math.min(lastCompactedHeapMb, heapUsedMb);
    } else {
      lastCompactedHeapMb = heapUsedMb;
    }
  } else {
    lastCompactedHeapMb = heapUsedMb;
  }

  return { heapUsedMb, heapTotalMb, rssMb, displayMb };
}

setInterval(() => {
  trimMemory();
}, 45000);

function getDirSizeBytes(dirPath) {
  let total = 0;
  if (!dirPath || !fs.existsSync(dirPath)) return 0;
  try {
    const entries = fs.readdirSync(dirPath, { withFileTypes: true });
    for (const ent of entries) {
      const full = path.join(dirPath, ent.name);
      try {
        if (ent.isDirectory()) {
          total += getDirSizeBytes(full);
        } else if (ent.isFile()) {
          total += fs.statSync(full).size;
        }
      } catch (_) {}
    }
  } catch (_) {}
  return total;
}

function clearDirFiles(dirPath, preserveRoot = false) {
  let freed = 0;
  if (!dirPath || !fs.existsSync(dirPath)) return 0;
  try {
    const entries = fs.readdirSync(dirPath, { withFileTypes: true });
    for (const ent of entries) {
      const full = path.join(dirPath, ent.name);
      try {
        if (ent.isDirectory()) {
          freed += clearDirFiles(full, false);
          try { fs.rmdirSync(full); } catch (_) {}
        } else if (ent.isFile()) {
          const sz = fs.statSync(full).size;
          fs.unlinkSync(full);
          freed += sz;
        }
      } catch (_) {}
    }
    if (!preserveRoot) {
      try { fs.rmdirSync(dirPath); } catch (_) {}
    }
  } catch (_) {}
  return freed;
}

function getKnownCacheDirs() {
  const dirs = [];
  const appData = (process.env && process.env.LOCALAPPDATA) || (os.homedir ? path.join(os.homedir(), '.mediafetch') : '');
  const mfDir = path.join(appData || '.', 'MediaFetch');

  // yt-dlp cache
  dirs.push(path.join(mfDir, '.cache'));
  if (process.env.APPDATA) dirs.push(path.join(process.env.APPDATA, 'MediaFetch', '.cache'));
  dirs.push(path.join(os.tmpdir(), 'MediaFetch', '.cache'));

  // Staging in AppData
  dirs.push(path.join(mfDir, '.temp_mediafetch'));

  // Target download folders staging
  try {
    const defaultTarget = filesystemManager.resolveTargetDirectory().targetDir;
    if (defaultTarget) dirs.push(path.join(defaultTarget, '.temp_mediafetch'));
  } catch (_) {}

  try {
    const sets = settingsManager.getSettings();
    if (sets && sets.downloads && sets.downloads.customLocation) {
      dirs.push(path.join(sets.downloads.customLocation, '.temp_mediafetch'));
    }
  } catch (_) {}

  return [...new Set(dirs.filter(d => Boolean(d) && fs.existsSync(d)))];
}

const { logger } = require('./logger.js');
const { settingsManager } = require('./settings.js');
const { historyManager } = require('./history.js');
const { dependencyManager } = require('./dependencies.js');
const { filesystemManager } = require('./filesystem.js');
const { metadataAnalyzer } = require('./analyzer.js');
const { queueManager } = require('./queue.js');
const { diagnosticsCollector } = require('./diagnostics.js');

const globalScope = typeof global !== 'undefined' ? global : (typeof window !== 'undefined' ? window : globalThis);
const nodeProc = typeof process !== 'undefined' ? process : (typeof require !== 'undefined' ? require('process') : null);

class MediaFetchServer {
  constructor(port = 48924) {
    this.port = port;
    this.server = null;
    this.wss = null;
    this.isShuttingDown = false;
    const appData = (nodeProc && nodeProc.env && nodeProc.env.LOCALAPPDATA) || (os.homedir ? path.join(os.homedir(), '.mediafetch') : '');
    const mfDir = path.join(appData || '.', 'MediaFetch');
    filesystemManager.ensureDirExists(mfDir);
    this.lockPath = path.join(mfDir, 'service.lock');
  }

  async start() {
    return new Promise((resolve, reject) => {
      this.server = http.createServer((req, res) => {
        this.handleHttpRequest(req, res);
      });

      this.wss = new WebSocketServer({ server: this.server });
      this.setupWebSocket();
      this.setupQueueEvents();

      this.wss.on('error', (err) => {
        logger.warn('WebSocketServer notice:', err?.message || err);
      });

      this.server.on('error', (err) => {
        if (err.code === 'EADDRINUSE') {
          logger.warn(`Port ${this.port} already in use. A MediaFetch service instance is already running.`);
          resolve();
          return;
        } else {
          logger.error('Server error:', err);
          reject(err);
        }
      });

      this.server.listen(this.port, '127.0.0.1', () => {
        const addr = this.server?.address();
        if (addr && typeof addr === 'object') {
          this.port = addr.port;
        }
        logger.info(`MediaFetch local download service running on http://127.0.0.1:${this.port}`);
        this.createLockfile();
        this.setupProcessHandlers();
        if (typeof globalScope.gc === 'function') {
          setInterval(() => {
            try { globalScope.gc(); } catch (_) {}
          }, 60000);
        }

        // Low-end device memory & cache optimizer (runs every 3 minutes)
        setInterval(() => {
          try {
            pruneStreamUrlCache();
            const dirs = getKnownCacheDirs();
            const now = Date.now();
            for (const d of dirs) {
              if (d.endsWith('.temp_mediafetch') && fs.existsSync(d)) {
                try {
                  const files = fs.readdirSync(d);
                  for (const f of files) {
                    const fp = path.join(d, f);
                    try {
                      const st = fs.statSync(fp);
                      if (now - st.mtimeMs > 3600 * 1000) {
                        fs.unlinkSync(fp);
                      }
                    } catch (_) {}
                  }
                  if (fs.readdirSync(d).length === 0) {
                    fs.rmdirSync(d);
                  }
                } catch (_) {}
              }
            }
            if (typeof globalScope.gc === 'function') {
              globalScope.gc();
            }
          } catch (_) {}
        }, 60 * 1000);

        resolve(this.port);
      });
    });
  }

  async stop() {
    this.isShuttingDown = true;
    this.removeLockfile();
    return new Promise((resolve) => {
      if (this.wss) this.wss.close();
      if (this.server) {
        this.server.close(() => {
          logger.info('MediaFetch service stopped.');
          resolve();
        });
      } else {
        resolve();
      }
    });
  }

  createLockfile() {
    try {
      const data = {
        port: this.port,
        pid: process.pid,
        startTime: Date.now()
      };
      fs.writeFileSync(this.lockPath, JSON.stringify(data, null, 2), 'utf-8');
    } catch (e) {
      logger.error('Failed to create lockfile:', e);
    }
  }

  removeLockfile() {
    try {
      if (fs.existsSync(this.lockPath)) fs.unlinkSync(this.lockPath);
    } catch (e) {}
  }

  setupProcessHandlers() {
    const cleanup = () => {
      if (!this.isShuttingDown) {
        this.stop().then(() => process.exit(0));
      }
    };
    process.on('SIGINT', cleanup);
    process.on('SIGTERM', cleanup);
    process.on('exit', () => this.removeLockfile());
  }

  setupQueueEvents() {
    queueManager.subscribe((event) => {
      if (event.type === 'QUEUE_UPDATED' && event.items) {
        this.broadcast({ type: 'QUEUE_UPDATED', payload: event.items });
      } else if (event.type === 'DOWNLOAD_PROGRESS' && event.item) {
        this.broadcast({ type: 'DOWNLOAD_PROGRESS', payload: { id: event.item.id, item: event.item } });
      } else if (event.type === 'DOWNLOAD_COMPLETED' && event.item && event.historyEntry) {
        this.broadcast({ type: 'DOWNLOAD_COMPLETED', payload: { id: event.item.id, item: event.item, historyEntry: event.historyEntry } });
        if (typeof globalScope.gc === 'function') {
          setTimeout(() => { try { globalScope.gc(); } catch (_) {} }, 500);
        }
      } else if (event.type === 'DOWNLOAD_FAILED' && event.item) {
        this.broadcast({ type: 'DOWNLOAD_FAILED', payload: { id: event.item.id, item: event.item } });
        if (typeof globalScope.gc === 'function') {
          setTimeout(() => { try { globalScope.gc(); } catch (_) {} }, 500);
        }
      }
    });
  }

  setupWebSocket() {
    if (!this.wss) return;
    this.wss.on('connection', (ws) => {
      logger.debug('New WebSocket client connected.');
      ws.send(JSON.stringify({ type: 'QUEUE_UPDATED', payload: queueManager.getItems() }));
      ws.send(JSON.stringify({ type: 'SETTINGS_LOADED', payload: settingsManager.getSettings() }));

      ws.on('message', async (data) => {
        try {
          const msg = JSON.parse(data.toString('utf-8'));
          await this.handleClientMessage(ws, msg);
        } catch (e) {
          logger.error('Failed to parse client message:', e);
        }
      });

      ws.on('close', () => {
        logger.debug('WebSocket client disconnected.');
      });
    });
  }

  broadcast(msg) {
    if (!this.wss) return;
    const str = JSON.stringify(msg);
    for (const client of this.wss.clients) {
      if (client.readyState === WebSocket.OPEN) {
        client.send(str);
      }
    }
  }

  async handleClientMessage(ws, msg) {
    switch (msg.type) {
      case 'PING':
        ws.send(JSON.stringify({ type: 'PONG', payload: { timestamp: Date.now() } }));
        break;

      case 'RESTART_SERVICE':
      case 'SHUTDOWN_SERVICE': {
        logger.info('Service shutdown requested by client.');
        ws.send(JSON.stringify({ type: 'SERVICE_SHUTTING_DOWN', payload: { restart: true } }));
        setTimeout(async () => {
          try { await this.stop(); } catch (_) {}
          process.exit(0);
        }, 300);
        break;
      }

      case 'ANALYZE_URL': {
        const { url, timeoutMs } = msg.payload;
        ws.send(JSON.stringify({ type: 'ANALYSIS_STARTED', payload: { url } }));
        try {
          if (metadataAnalyzer.isPlaylistUrl(url)) {
            const playlist = await metadataAnalyzer.analyzePlaylist(url, timeoutMs);
            ws.send(JSON.stringify({ type: 'PLAYLIST_ANALYSIS_SUCCESS', payload: playlist }));
            ws.send(JSON.stringify({ type: 'PLAYLIST_METADATA_RESULT', payload: playlist }));
            break;
          }
          const meta = await metadataAnalyzer.analyzeUrl(url, timeoutMs);
          if (meta.isPlaylist || meta.isCarousel) {
            ws.send(JSON.stringify({ type: 'PLAYLIST_ANALYSIS_SUCCESS', payload: meta }));
            ws.send(JSON.stringify({ type: 'PLAYLIST_METADATA_RESULT', payload: meta }));
          } else {
            ws.send(JSON.stringify({ type: 'ANALYSIS_SUCCESS', payload: meta }));
            ws.send(JSON.stringify({ type: 'METADATA_RESULT', payload: meta }));
          }
        } catch (err) {
          const errPayload = { url, error: err.message || 'Analysis failed', details: err.details, category: err.category || 'UNKNOWN_ERROR' };
          ws.send(JSON.stringify({ type: 'ANALYSIS_ERROR', payload: errPayload }));
          ws.send(JSON.stringify({ type: 'ANALYSIS_FAILED', payload: errPayload }));
        }
        break;
      }

      case 'ANALYZE_PLAYLIST': {
        const { url } = msg.payload;
        try {
          const playlist = await metadataAnalyzer.analyzePlaylist(url);
          ws.send(JSON.stringify({ type: 'PLAYLIST_ANALYSIS_SUCCESS', payload: playlist }));
          ws.send(JSON.stringify({ type: 'PLAYLIST_METADATA_RESULT', payload: playlist }));
        } catch (err) {
          const pErr = { url, error: err.message || 'Playlist analysis failed' };
          ws.send(JSON.stringify({ type: 'PLAYLIST_ANALYSIS_ERROR', payload: pErr }));
          ws.send(JSON.stringify({ type: 'PLAYLIST_ANALYSIS_FAILED', payload: pErr }));
        }
        break;
      }

      case 'START_PLAYLIST_DOWNLOAD':
      case 'ADD_PLAYLIST_ITEMS': {
        const { items, profile, projectContext, targetDirectory, customFolderName, preserveSubfolders, autoImport, zipPackage, playlistTitle, isCloud, edition } = msg.payload;
        const itemEdition = edition || msg.edition || 'standard';
        const batchId = zipPackage ? ('batch_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7)) : undefined;

        if (zipPackage) {
          const resolved = filesystemManager.resolveTargetDirectory(projectContext, targetDirectory);
          const baseTargetDir = resolved.targetDir;
          let rawArchive = (customFolderName || playlistTitle || (isCloud ? 'Cloud_Media' : 'Playlist_Media')).replace(/\.zip$/i, '').trim();
          let cleanArchive = rawArchive.replace(/[\\/:*?"<>|]/g, '_').replace(/[.\s]+$/g, '').trim();
          if (!cleanArchive) cleanArchive = isCloud ? 'Cloud_Media' : 'Playlist_Media';
          // Dedicated hidden staging folder strictly for zipping - NEVER leaves a loose unzipped folder on disk
          const stagingFolder = path.join(baseTargetDir, '.mf_zip_staging_' + batchId);
          filesystemManager.ensureDirExists(stagingFolder);
          queueManager.registerZipBatch(batchId, {
            totalItems: items.length,
            archiveName: cleanArchive,
            rootFolder: stagingFolder,
            baseDir: baseTargetDir
          });
        }

        for (const item of items) {
          const itemSubFolder = (preserveSubfolders === false) ? '' : (item.subFolderName || '');
          queueManager.addItem(item.url, profile, projectContext, targetDirectory, {
            title: item.title,
            thumbnail: item.thumbnail,
            duration: item.duration,
            downloadQuery: item.downloadQuery,
            uploader: item.uploader || item.channel,
            subFolderName: itemSubFolder,
            customFolderName: customFolderName || item.customFolderName || '',
            autoImport: zipPackage ? false : (autoImport !== false),
            isPlaylist: true,
            isCloud: Boolean(isCloud || item.isCloud),
            playlistTitle: playlistTitle || '',
            edition: itemEdition,
            batchId,
            zipPackage: Boolean(zipPackage)
          });
        }
        queueManager.processQueue();
        this.broadcast({ type: 'QUEUE_UPDATED', payload: queueManager.getItems() });
        break;
      }

      case 'START_DOWNLOAD':
      case 'ADD_DOWNLOAD': {
        const { url, profile, projectContext, targetDirectory, metadata, edition } = msg.payload;

        // Automatically intercept playlists, cloud links, and carousels when user clicks download directly
        if (metadataAnalyzer.isPlaylistUrl(url)) {
          logger.info(`START_DOWNLOAD called on playlist/multi-item URL (${url}), routing to playlist modal...`);
          try {
            const playlist = await metadataAnalyzer.analyzePlaylist(url);
            ws.send(JSON.stringify({ type: 'PLAYLIST_ANALYSIS_SUCCESS', payload: playlist }));
            ws.send(JSON.stringify({ type: 'PLAYLIST_METADATA_RESULT', payload: playlist }));
            return;
          } catch (err) {
            logger.warn(`Failed to auto-analyze playlist on START_DOWNLOAD:`, err.message);
          }
        }
        if (url && (url.includes('instagram.com/p/') || url.includes('instagram.com/reel/'))) {
          try {
            const igRes = await metadataAnalyzer.analyzeInstagram(url);
            if (igRes && (igRes.isPlaylist || igRes.isCarousel)) {
              logger.info(`START_DOWNLOAD called on Instagram carousel (${url}), routing to carousel modal...`);
              ws.send(JSON.stringify({ type: 'PLAYLIST_ANALYSIS_SUCCESS', payload: igRes }));
              ws.send(JSON.stringify({ type: 'PLAYLIST_METADATA_RESULT', payload: igRes }));
              return;
            }
          } catch (_) {}
        }

        const itemEdition = edition || metadata?.edition || msg.edition || 'standard';
        queueManager.addItem(url, profile, projectContext, targetDirectory, {
          ...(metadata || {}),
          edition: itemEdition
        });
        this.broadcast({ type: 'QUEUE_UPDATED', payload: queueManager.getItems() });
        break;
      }

      case 'PAUSE_DOWNLOAD': {
        const id = typeof msg.payload === 'object' && msg.payload ? msg.payload.id : msg.payload;
        if (id) {
          queueManager.pauseItem(id);
        } else {
          for (const it of queueManager.getItems()) {
            if (it.status === 'downloading' || it.status === 'waiting') {
              queueManager.pauseItem(it.id);
            }
          }
        }
        this.broadcast({ type: 'QUEUE_UPDATED', payload: queueManager.getItems() });
        break;
      }

      case 'RESUME_DOWNLOAD': {
        const id = typeof msg.payload === 'object' && msg.payload ? msg.payload.id : msg.payload;
        if (id) {
          queueManager.resumeItem(id);
        } else {
          queueManager.resumeAllInterrupted();
        }
        this.broadcast({ type: 'QUEUE_UPDATED', payload: queueManager.getItems() });
        break;
      }

      case 'CANCEL_DOWNLOAD': {
        const id = typeof msg.payload === 'object' && msg.payload ? msg.payload.id : msg.payload;
        if (id) queueManager.cancelItem(id);
        this.broadcast({ type: 'QUEUE_UPDATED', payload: queueManager.getItems() });
        break;
      }

      case 'RETRY_DOWNLOAD': {
        const id = typeof msg.payload === 'object' && msg.payload ? msg.payload.id : msg.payload;
        if (id) queueManager.retryItem(id);
        this.broadcast({ type: 'QUEUE_UPDATED', payload: queueManager.getItems() });
        break;
      }

      case 'CLEAR_COMPLETED': {
        const edition = msg.payload?.edition || msg.edition;
        queueManager.clearCompleted(edition);
        this.broadcast({ type: 'QUEUE_UPDATED', payload: queueManager.getItems() });
        break;
      }

      case 'CLEAR_ALL': {
        const edition = msg.payload?.edition || msg.edition;
        queueManager.clearAll(edition);
        this.broadcast({ type: 'QUEUE_UPDATED', payload: queueManager.getItems() });
        break;
      }

      case 'GET_QUEUE':
        ws.send(JSON.stringify({ type: 'QUEUE_UPDATED', payload: queueManager.getItems() }));
        break;

      case 'GET_SETTINGS':
        ws.send(JSON.stringify({ type: 'SETTINGS_LOADED', payload: settingsManager.getSettings() }));
        break;

      case 'UPDATE_SETTINGS': {
        const updated = settingsManager.updateSettings(msg.payload);
        this.broadcast({ type: 'SETTINGS_LOADED', payload: updated });
        break;
      }

      case 'GET_DIAGNOSTICS': {
        const diag = await diagnosticsCollector.collectDiagnostics(this.port);
        ws.send(JSON.stringify({ type: 'DIAGNOSTICS_RESULT', payload: diag }));
        break;
      }

      case 'RUN_SYSTEM_CHECK':
      case 'RUN_SYSTEM_DIAGNOSTICS': {
        const diag = await diagnosticsCollector.collectDiagnostics(this.port);
        ws.send(JSON.stringify({ type: 'SYSTEM_DIAGNOSTICS_RESULT', payload: diag }));
        break;
      }

      case 'INSTALL_DEPENDENCY': {
        const { name } = msg.payload;
        if (name === 'all' || name === 'ytdlp' || name === 'yt-dlp') {
          const res = await dependencyManager.installYtDlp((stage, progress, message) => {
            ws.send(JSON.stringify({ type: 'DEPENDENCY_INSTALL_PROGRESS', payload: { name: 'yt-dlp', stage, progress, message } }));
          });
          ws.send(JSON.stringify({ type: 'DEPENDENCY_INSTALL_RESULT', payload: { name: 'yt-dlp', success: res.success, error: res.error, message: res.version } }));
        }
        if (name === 'all' || name === 'ffmpeg' || name === 'FFmpeg') {
          const res = await dependencyManager.installFfmpeg((stage, progress, message) => {
            ws.send(JSON.stringify({ type: 'DEPENDENCY_INSTALL_PROGRESS', payload: { name: 'ffmpeg', stage, progress, message } }));
          });
          ws.send(JSON.stringify({ type: 'DEPENDENCY_INSTALL_RESULT', payload: { name: 'ffmpeg', success: res.success, error: res.error, message: res.version } }));
        }
        break;
      }

      case 'UPDATE_YTDLP': {
        const active = queueManager.getActiveCount() > 0;
        const res = await dependencyManager.updateYtDlp(active, (stage, progress, message) => {
          ws.send(JSON.stringify({ type: 'DEPENDENCY_INSTALL_PROGRESS', payload: { name: 'yt-dlp', stage, progress, message } }));
        });
        ws.send(JSON.stringify({ type: 'DEPENDENCY_INSTALL_RESULT', payload: { name: 'yt-dlp', success: res.success, error: res.error, message: res.version } }));
        break;
      }

      case 'GET_HISTORY':
        ws.send(JSON.stringify({ type: 'HISTORY_LOADED', payload: historyManager.getHistory() }));
        break;

      case 'CLEAR_HISTORY':
        historyManager.clearHistory();
        ws.send(JSON.stringify({ type: 'HISTORY_LOADED', payload: [] }));
        break;

      case 'REMOVE_HISTORY_ITEM':
        historyManager.removeHistoryItem(msg.payload.id);
        ws.send(JSON.stringify({ type: 'HISTORY_LOADED', payload: historyManager.getHistory() }));
        break;

      case 'CHECK_DUPLICATE': {
        const { title, container, targetDirectory } = msg.payload;
        const filename = filesystemManager.sanitizeFilename(title, container);
        const dup = filesystemManager.checkDuplicate(targetDirectory, filename);
        ws.send(JSON.stringify({
          type: 'DUPLICATE_CHECK_RESULT',
          payload: { exists: dup.exists, existingFilePath: dup.filePath, existingFileSize: dup.size }
        }));
        break;
      }

      case 'OPEN_FOLDER_DIALOG': {
        try {
          const { exec } = await import('child_process');
          if (process.platform === 'win32') {
            const candidates = [
              path.join(__dirname, 'modern_folder_picker.ps1'),
              path.join(__dirname, 'service', 'modern_folder_picker.ps1'),
              path.join(__dirname, '..', 'service', 'modern_folder_picker.ps1')
            ];
            let pickerScript = candidates.find((c) => fs.existsSync(c));
            if (!pickerScript) {
              const os = await import('os');
              pickerScript = path.join(os.tmpdir(), 'mediafetch_folder_picker.ps1');
              fs.writeFileSync(pickerScript, `Add-Type -AssemblyName System.Windows.Forms
function Show-ModernFolderPicker($Title) {
    try {
        $AssemblyFullName = 'System.Windows.Forms, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089'
        $Assembly = [System.Reflection.Assembly]::Load($AssemblyFullName)
        $OpenFileDialog = New-Object System.Windows.Forms.OpenFileDialog
        $OpenFileDialog.AddExtension = $false
        $OpenFileDialog.CheckFileExists = $false
        $OpenFileDialog.DereferenceLinks = $true
        $OpenFileDialog.Filter = "Folders|\`n"
        $OpenFileDialog.Multiselect = $false
        $OpenFileDialog.Title = if ($Title) { $Title } else { "Select MediaFetch Destination Folder" }
        $OpenFileDialogType = $OpenFileDialog.GetType()
        $FileDialogInterfaceType = $Assembly.GetType('System.Windows.Forms.FileDialogNative+IFileDialog')
        $IFileDialog = $OpenFileDialogType.GetMethod('CreateVistaDialog',@('NonPublic','Public','Static','Instance')).Invoke($OpenFileDialog,$null)
        $null = $OpenFileDialogType.GetMethod('OnBeforeVistaDialog',@('NonPublic','Public','Static','Instance')).Invoke($OpenFileDialog,$IFileDialog)
        [uint32]$PickFoldersOption = $Assembly.GetType('System.Windows.Forms.FileDialogNative+FOS').GetField('FOS_PICKFOLDERS').GetValue($null)
        $FolderOptions = $OpenFileDialogType.GetMethod('get_Options',@('NonPublic','Public','Static','Instance')).Invoke($OpenFileDialog,$null) -bor $PickFoldersOption
        $null = $FileDialogInterfaceType.GetMethod('SetOptions',@('NonPublic','Public','Static','Instance')).Invoke($IFileDialog,$FolderOptions)
        $VistaDialogEvent = [System.Activator]::CreateInstance($AssemblyFullName,'System.Windows.Forms.FileDialog+VistaDialogEvents',$false,0,$null,$OpenFileDialog,$null,$null).Unwrap()
        [uint32]$AdviceCookie = 0
        $AdvisoryParameters = @($VistaDialogEvent,$AdviceCookie)
        $AdviseResult = $FileDialogInterfaceType.GetMethod('Advise',@('NonPublic','Public','Static','Instance')).Invoke($IFileDialog,$AdvisoryParameters)
        $AdviceCookie = $AdvisoryParameters[1]
        $Result = $FileDialogInterfaceType.GetMethod('Show',@('NonPublic','Public','Static','Instance')).Invoke($IFileDialog,[System.IntPtr]::Zero)
        $null = $FileDialogInterfaceType.GetMethod('Unadvise',@('NonPublic','Public','Static','Instance')).Invoke($IFileDialog,$AdviceCookie)
        if ($Result -eq 0) {
            try {
                $files = $OpenFileDialogType.GetMethod('ProcessVistaFiles', [System.Reflection.BindingFlags]'NonPublic,Instance').Invoke($OpenFileDialog, @($IFileDialog))
                if ($files -and $files.Length -gt 0 -and !([string]::IsNullOrEmpty($files[0]))) {
                    return $files[0]
                }
            } catch {}
            if (![string]::IsNullOrEmpty($OpenFileDialog.FileName)) {
                return $OpenFileDialog.FileName
            }
        }
        return $null
    } catch {
        return $null
    }
}
$title = if ($args.Count -gt 0 -and $args[0]) { $args[0] } else { "Select MediaFetch Destination Folder" }
$p = Show-ModernFolderPicker -Title $title
if ($p) { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8; [Console]::WriteLine($p) }
`, 'utf8');
            }
            execFile('powershell.exe', [
              '-WindowStyle', 'Hidden',
              '-NoLogo',
              '-STA',
              '-NoProfile',
              '-ExecutionPolicy', 'Bypass',
              '-File', pickerScript,
              'Select MediaFetch Destination Folder'
            ], { windowsHide: true, encoding: 'utf8' }, (err, stdout) => {
              const selected = (stdout || '').trim();
              if (selected) {
                ws.send(JSON.stringify({ type: 'FOLDER_SELECTED', payload: { folderPath: selected } }));
              }
            });
          } else if (process.platform === 'darwin') {
            exec(`osascript -e 'POSIX path of (choose folder with prompt "Select MediaFetch Destination Folder")'`, (err, stdout) => {
              const selected = (stdout || '').trim();
              if (selected) {
                ws.send(JSON.stringify({ type: 'FOLDER_SELECTED', payload: { folderPath: selected } }));
              }
            });
          }
        } catch (dialogErr) {
          logger.error('Failed to open native folder dialog:', dialogErr);
        }
        break;
      }

      case 'GET_CACHE_STATS': {
        let tempStorageBytes = 0;
        const dirs = getKnownCacheDirs();
        for (const d of dirs) {
          tempStorageBytes += getDirSizeBytes(d);
        }
        const appData = (nodeProc && nodeProc.env && nodeProc.env.LOCALAPPDATA) || (os.homedir ? path.join(os.homedir(), '.mediafetch') : '');
        const logsDir = path.join(appData || '.', 'MediaFetch', 'logs');
        const logBytes = getDirSizeBytes(logsDir);
        const ram = getMemoryStats();
        ws.send(JSON.stringify({
          type: 'CACHE_STATS',
          payload: {
            ram,
            streamCacheCount: streamUrlCache.size,
            tempStorageBytes,
            logBytes,
            totalCacheBytes: tempStorageBytes + logBytes,
            totalCacheMb: +((tempStorageBytes + logBytes) / (1024 * 1024)).toFixed(2)
          }
        }));
        break;
      }

      case 'CLEAR_CACHE': {
        let freedBytes = 0;
        const dirs = getKnownCacheDirs();
        for (const d of dirs) {
          freedBytes += clearDirFiles(d, false);
        }
        streamUrlCache.clear();
        try {
          const appData = (nodeProc && nodeProc.env && nodeProc.env.LOCALAPPDATA) || (os.homedir ? path.join(os.homedir(), '.mediafetch') : '');
          const logFile = path.join(appData || '.', 'MediaFetch', 'logs', 'service.log');
          if (fs.existsSync(logFile)) {
            const sz = fs.statSync(logFile).size;
            if (sz > 0) {
              fs.truncateSync(logFile, 0);
              freedBytes += sz;
            }
          }
        } catch (_) {}

        trimMemory();
        const ram = getMemoryStats();
        ws.send(JSON.stringify({
          type: 'CACHE_CLEARED',
          payload: {
            freedBytes,
            freedMb: +(freedBytes / (1024 * 1024)).toFixed(2),
            totalCacheBytes: 0,
            totalCacheMb: 0.00,
            ram
          }
        }));
        break;
      }
    }
  }

  handleHttpRequest(req, res) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    if (req.method === 'OPTIONS') {
      res.writeHead(200);
      res.end();
      return;
    }

    const url = new URL(req.url || '/', `http://127.0.0.1:${this.port}`);
    const pathname = url.pathname;

    const jsonRes = (status, data) => {
      res.writeHead(status, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(data));
    };

    if (pathname === '/health' || pathname === '/') {
      jsonRes(200, { status: 'ok', port: this.port, uptime: process.uptime() });
      return;
    }

    if (pathname === '/api/clipboard' && (req.method === 'GET' || req.method === 'POST')) {
      (async () => {
        try {
          const isWin = process.platform === 'win32';
          let clipText = '';
          if (isWin) {
            const { stdout } = await execFileAsync('powershell.exe', ['-NoProfile', '-Command', 'Get-Clipboard'], {
              windowsHide: true,
              timeout: 2500
            });
            clipText = (stdout || '').trim();
          } else {
            const { stdout } = await execFileAsync('pbpaste', [], { timeout: 2500 });
            clipText = (stdout || '').trim();
          }
          jsonRes(200, { success: true, text: clipText });
        } catch (clipErr) {
          logger.warn('Clipboard read notice:', clipErr.message);
          jsonRes(200, { success: false, text: '' });
        }
      })();
      return;
    }

    if ((pathname === '/api/service/shutdown' || pathname === '/api/service/restart') && req.method === 'POST') {
      logger.info('Service shutdown endpoint called via HTTP POST.');
      jsonRes(200, { success: true, message: 'Shutting down service...' });
      setTimeout(async () => {
        try { await this.stop(); } catch (_) {}
        process.exit(0);
      }, 300);
      return;
    }

    if (pathname === '/api/diagnostics' && req.method === 'GET') {
      diagnosticsCollector.collectDiagnostics(this.port).then((d) => jsonRes(200, d));
      return;
    }

    if (pathname === '/api/queue' && req.method === 'GET') {
      jsonRes(200, queueManager.getItems());
      return;
    }

    if (pathname === '/api/settings' && req.method === 'GET') {
      jsonRes(200, settingsManager.getSettings());
      return;
    }

    if (pathname === '/api/history' && req.method === 'GET') {
      jsonRes(200, historyManager.getHistory());
      return;
    }

    if (pathname === '/api/cache/stats' && req.method === 'GET') {
      let tempStorageBytes = 0;
      const dirs = getKnownCacheDirs();
      for (const d of dirs) {
        tempStorageBytes += getDirSizeBytes(d);
      }
      const appData = (nodeProc && nodeProc.env && nodeProc.env.LOCALAPPDATA) || (os.homedir ? path.join(os.homedir(), '.mediafetch') : '');
      const logsDir = path.join(appData || '.', 'MediaFetch', 'logs');
      const logBytes = getDirSizeBytes(logsDir);
      const ram = getMemoryStats();
      jsonRes(200, {
        success: true,
        ram,
        streamCacheCount: streamUrlCache.size,
        tempStorageBytes,
        logBytes,
        totalCacheBytes: tempStorageBytes + logBytes,
        totalCacheMb: +((tempStorageBytes + logBytes) / (1024 * 1024)).toFixed(2)
      });
      return;
    }

    if (pathname === '/api/cache/clear' && req.method === 'POST') {
      let freedBytes = 0;
      const dirs = getKnownCacheDirs();
      for (const d of dirs) {
        freedBytes += clearDirFiles(d, false);
      }
      streamUrlCache.clear();
      try {
        const appData = (nodeProc && nodeProc.env && nodeProc.env.LOCALAPPDATA) || (os.homedir ? path.join(os.homedir(), '.mediafetch') : '');
        const logFile = path.join(appData || '.', 'MediaFetch', 'logs', 'service.log');
        if (fs.existsSync(logFile)) {
          const sz = fs.statSync(logFile).size;
          if (sz > 0) {
            fs.truncateSync(logFile, 0);
            freedBytes += sz;
          }
        }
      } catch (_) {}

      trimMemory();
      const ram = getMemoryStats();
      jsonRes(200, {
        success: true,
        freedBytes,
        freedMb: +(freedBytes / (1024 * 1024)).toFixed(2),
        totalCacheBytes: 0,
        totalCacheMb: 0.00,
        ram
      });
      return;
    }

    if (pathname === '/api/cache/gc' && req.method === 'POST') {
      trimMemory();
      const ram = getMemoryStats();
      jsonRes(200, {
        success: true,
        ram
      });
      return;
    }

    // DaVinci Resolve Import Bridge
    if (!this.pendingResolveImports) this.pendingResolveImports = [];
    if (!this.activeResolveProject) this.activeResolveProject = 'DaVinci Resolve';

    if (pathname === '/api/davinci/import' && req.method === 'POST') {
      let body = '';
      req.on('data', (chunk) => { body += chunk; });
      req.on('end', () => {
        try {
          const data = JSON.parse(body);
          if (data && data.filePath) {
            this.pendingResolveImports.push(data.filePath);
            jsonRes(200, { success: true, queued: true });
            return;
          }
        } catch (_) {}
        jsonRes(400, { error: 'Invalid payload' });
      });
      return;
    }

    if (pathname === '/api/davinci/pending' && req.method === 'GET') {
      const items = [...this.pendingResolveImports];
      this.pendingResolveImports = [];
      jsonRes(200, { files: items, project: this.activeResolveProject });
      return;
    }

    if (pathname === '/api/davinci/project' && req.method === 'POST') {
      let body = '';
      req.on('data', (chunk) => { body += chunk; });
      req.on('end', () => {
        try {
          const data = JSON.parse(body);
          if (data && data.name) this.activeResolveProject = data.name;
        } catch (_) {}
        jsonRes(200, { success: true, project: this.activeResolveProject });
      });
      return;
    }

    if (pathname === '/api/davinci/project' && req.method === 'GET') {
      jsonRes(200, { project: this.activeResolveProject });
      return;
    }

    if (pathname === '/api/clipboard' && req.method === 'GET') {
      try {
        let clipText = '';
        const { execSync } = require('child_process');
        if (process.platform === 'win32') {
          clipText = execSync('powershell.exe -NoProfile -Command Get-Clipboard', { encoding: 'utf8', timeout: 2500, windowsHide: true }) || '';
        } else if (process.platform === 'darwin') {
          clipText = execSync('pbpaste', { encoding: 'utf8', timeout: 2000 }) || '';
        } else {
          clipText = execSync('xclip -selection clipboard -o || wl-paste', { encoding: 'utf8', timeout: 2000 }) || '';
        }
        jsonRes(200, { success: true, text: clipText.trim() });
      } catch (err) {
        jsonRes(200, { success: false, error: err.message, text: '' });
      }
      return;
    }

    if (pathname === '/api/stream-url' && req.method === 'GET') {
      const vid = url.searchParams.get('v') || url.searchParams.get('id');
      const quality = url.searchParams.get('quality') || '720';
      const targetUrl = vid ? (vid.startsWith('http') ? vid : `https://www.youtube.com/watch?v=${vid}`) : null;
      if (!targetUrl) {
        jsonRes(400, { success: false, error: 'Missing video id' });
        return;
      }

      const cacheKey = `${vid}_${quality}`;
      const cached = streamUrlCache.get(cacheKey);
      if (cached && cached.expiresAt > Date.now()) {
        jsonRes(200, { success: true, streamUrl: cached.streamUrl, cached: true });
        return;
      }

      let formatSpec = 'b[protocol^=https][ext=mp4]/22/18/best[protocol^=https]/best';
      if (quality === '1080') {
        formatSpec = 'b[height<=1080][protocol^=https][ext=mp4]/22/18/b[height<=1080]/best[protocol^=https]/best';
      } else if (quality === '720') {
        formatSpec = 'b[height<=720][protocol^=https][ext=mp4]/22/18/best[protocol^=https]/best';
      } else if (quality === '480') {
        formatSpec = 'b[height<=480][protocol^=https][ext=mp4]/18/best[protocol^=https]/best';
      } else if (quality === '360') {
        formatSpec = '18/b[height<=360][protocol^=https][ext=mp4]/best[protocol^=https]/best';
      }

      (async () => {
        try {
          const ytdlpPath = await dependencyManager.getYtDlpExecutablePath();
          const nodeBin = dependencyManager.getNodeExecutablePath();
          const jsRuntime = nodeBin === 'node' ? 'node' : `node:${nodeBin}`;
          const args = [
            '--no-playlist',
            '--no-check-certificates',
            '--no-warnings',
            '--skip-download',
            '--js-runtimes', jsRuntime,
            '--remote-components', 'ejs:github',
            '--extractor-args', 'youtube:player_client=android,web',
            '-g',
            '-f', formatSpec,
            targetUrl
          ];
          const { stdout } = await execFileAsync(ytdlpPath, args, { windowsHide: true, timeout: 25000 });
          const streamUrl = stdout.trim().split(/\r?\n/).find((u) => u.startsWith('http'));
          if (streamUrl) {
            setStreamUrlCache(cacheKey, { streamUrl, expiresAt: Date.now() + 2 * 3600 * 1000 });
            jsonRes(200, { success: true, streamUrl });
            return;
          }
          throw new Error('No stream URL extracted');
        } catch (err) {
          try {
            const ytdlpPath = await dependencyManager.getYtDlpExecutablePath();
            const nodeBin = dependencyManager.getNodeExecutablePath();
            const jsRuntime = nodeBin === 'node' ? 'node' : `node:${nodeBin}`;
            const { stdout } = await execFileAsync(ytdlpPath, [
              '--no-playlist',
              '--no-check-certificates',
              '--js-runtimes', jsRuntime,
              '--extractor-args', 'youtube:player_client=android,web',
              '-g',
              '-f', formatSpec,
              targetUrl
            ], { windowsHide: true, timeout: 25000 });
            const streamUrl = stdout.trim().split(/\r?\n/).find((u) => u.startsWith('http'));
            if (streamUrl) {
              setStreamUrlCache(cacheKey, { streamUrl, expiresAt: Date.now() + 2 * 3600 * 1000 });
              jsonRes(200, { success: true, streamUrl });
              return;
            }
          } catch (_) {}
          try {
            const ytdlpPath = await dependencyManager.getYtDlpExecutablePath();
            const nodeBin = dependencyManager.getNodeExecutablePath();
            const jsRuntime = nodeBin === 'node' ? 'node' : `node:${nodeBin}`;
            const { stdout } = await execFileAsync(ytdlpPath, [
              '--no-playlist',
              '--no-check-certificates',
              '--js-runtimes', jsRuntime,
              '-g',
              '-f', '18/b/best',
              targetUrl
            ], { windowsHide: true, timeout: 25000 });
            const streamUrl = stdout.trim().split(/\r?\n/).find((u) => u.startsWith('http'));
            if (streamUrl) {
              setStreamUrlCache(cacheKey, { streamUrl, expiresAt: Date.now() + 2 * 3600 * 1000 });
              jsonRes(200, { success: true, streamUrl });
              return;
            }
          } catch (_) {}
          jsonRes(500, { success: false, error: err.message || 'Failed to resolve stream URL' });
        }
      })();
      return;
    }

    if (pathname === '/youtube-player.html' || pathname === '/player') {
      const ytPath = path.join(__dirname, '..', 'youtube-player.html');
      if (fs.existsSync(ytPath)) {
        res.writeHead(200, {
          'Content-Type': 'text/html; charset=utf-8',
          'Referrer-Policy': 'strict-origin-when-cross-origin',
          'Access-Control-Allow-Origin': '*'
        });
        res.end(fs.readFileSync(ytPath));
        return;
      }
    }

    if (pathname === '/theater-player.html' || pathname === '/theater') {
      const theaterPath = path.join(__dirname, '..', 'theater-player.html');
      if (fs.existsSync(theaterPath)) {
        res.writeHead(200, {
          'Content-Type': 'text/html; charset=utf-8',
          'Access-Control-Allow-Origin': '*'
        });
        res.end(fs.readFileSync(theaterPath));
        return;
      }
    }

    // Static Web File Server for DaVinci Resolve Native Panel
    const resolveRoots = [
      path.join(__dirname, '..'),
      path.join(process.env.PROGRAMDATA || 'C:\\ProgramData', 'Blackmagic Design', 'DaVinci Resolve', 'Support', 'Workflow Integration Plugins', 'com.mediafetch.resolve'),
      path.join(__dirname, '..', '..', 'com.mediafetch.resolve'),
      path.join(__dirname, '..', '..', '..', 'com.mediafetch.resolve')
    ];

    if (pathname === '/resolve' || pathname === '/resolve/' || pathname === '/resolve/index.html') {
      for (const root of resolveRoots) {
        const indexPath = path.join(root, 'index.html');
        if (fs.existsSync(indexPath)) {
          res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
          res.end(fs.readFileSync(indexPath));
          return;
        }
      }
    }

    if (pathname.startsWith('/resolve/')) {
      const rel = pathname.replace('/resolve/', '');
      for (const root of resolveRoots) {
        const fullPath = path.join(root, rel);
        if (fs.existsSync(fullPath) && fs.statSync(fullPath).isFile()) {
          const ext = path.extname(fullPath).toLowerCase();
          const mimeTypes = {
            '.html': 'text/html; charset=utf-8',
            '.css': 'text/css; charset=utf-8',
            '.js': 'application/javascript; charset=utf-8',
            '.png': 'image/png',
            '.svg': 'image/svg+xml',
            '.json': 'application/json'
          };
          res.writeHead(200, { 'Content-Type': mimeTypes[ext] || 'application/octet-stream' });
          res.end(fs.readFileSync(fullPath));
          return;
        }
      }
    }

    jsonRes(404, { error: 'Not Found' });
  }
}

// Auto-start singleton
if (!globalScope.__mediaFetchServerStarted) {
  globalScope.__mediaFetchServerStarted = true;
  const preferredPort = parseInt((nodeProc && nodeProc.env && nodeProc.env.PORT) || '48924', 10);
  const server = new MediaFetchServer(preferredPort);
  server.start().catch((err) => {
    if (err.code !== 'EADDRINUSE') {
      console.error('Failed to start MediaFetch server:', err);
    }
  });
}

module.exports = { MediaFetchServer };
