import fs from 'fs';
import path from 'path';
import os from 'os';
import { DownloadJob } from './downloader.js';
import { retryManager } from './retry.js';
import { historyManager } from './history.js';
import { settingsManager } from './settings.js';
import { filesystemManager } from './filesystem.js';
import { logger } from './logger.js';

export class QueueManager {
  constructor() {
    this.items = [];
    this.activeJobs = new Map();
    this.listeners = [];
    this.isProcessing = false;
    this.zipBatches = new Map();
    const appData = process.env.LOCALAPPDATA || path.join(os.homedir(), '.mediafetch');
    const mfDir = path.join(appData, 'MediaFetch');
    this.queuePath = path.join(mfDir, 'queue.json');
    this.load();
  }

  registerZipBatch(batchId, info) {
    if (!batchId) return;
    this.zipBatches.set(batchId, {
      totalItems: info.totalItems || 1,
      completedItems: 0,
      failedItems: 0,
      archiveName: info.archiveName || 'MediaArchive',
      rootFolder: info.rootFolder,
      baseDir: info.baseDir || (info.rootFolder ? path.dirname(info.rootFolder) : null),
      targetFolders: new Set(),
      isZipping: false
    });
  }

  async checkZipBatchCompletion(item, isSuccess = true) {
    const batchId = item.metadata?.batchId || item.batchId;
    if (!batchId) return;

    const batch = this.zipBatches.get(batchId);
    if (!batch) {
      // If batch was already zipped earlier, and a late retried item just completed successfully:
      // Append this new file directly into the existing .zip file so NO loose folder is EVER created!
      if (isSuccess && item.downloadedPath && fs.existsSync(item.downloadedPath)) {
        try {
          const fileDir = path.dirname(item.downloadedPath);
          const baseTargetDir = item.targetDirectory || (fileDir.includes('.mf_zip_staging_') ? path.dirname(fileDir) : path.dirname(fileDir));
          const archiveName = item.metadata?.customFolderName || item.metadata?.playlistTitle || 'Media_Archive';
          const zipPath = path.join(baseTargetDir, `${archiveName}.zip`);
          if (fs.existsSync(zipPath)) {
            const isWin = process.platform === 'win32';
            const { exec } = await import('child_process');
            const entryName = path.basename(item.downloadedPath);
            if (isWin) {
              const psCmd = `Add-Type -AssemblyName System.IO.Compression.FileSystem; $a = [System.IO.Compression.ZipFile]::Open('${zipPath.replace(/'/g, "''")}', 'Update'); [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($a, '${item.downloadedPath.replace(/'/g, "''")}', '${entryName.replace(/'/g, "''")}'); $a.Dispose()`;
              exec(`powershell -NoProfile -Command "${psCmd}"`, { windowsHide: true }, () => {
                try { fs.unlinkSync(item.downloadedPath); } catch (_) {}
                try { if (fileDir.includes('.mf_zip_staging_')) fs.rmSync(fileDir, { recursive: true, force: true }); } catch (_) {}
              });
            }
          }
        } catch (_) {}
      }
      return;
    }

    if (item.targetFolder) {
      batch.targetFolders.add(item.targetFolder);
    }
    if (item.downloadedPath && fs.existsSync(item.downloadedPath)) {
      batch.targetFolders.add(path.dirname(item.downloadedPath));
    }
    if (isSuccess) {
      batch.completedItems++;
    } else {
      batch.failedItems++;
    }

    // Check ALL items in queue that belong to this batchId:
    // If ANY item is still downloading, waiting, retrying, transcoding, or paused, WAIT!
    const batchItems = this.items.filter((i) => (i.batchId === batchId || i.metadata?.batchId === batchId));
    const activeOrPending = batchItems.filter((i) =>
      ['downloading', 'waiting', 'retrying', 'transcoding', 'paused'].includes(i.status) ||
      this.activeJobs.has(i.id) ||
      Boolean(retryManager?.activeTimers?.has(i.id))
    );

    if (activeOrPending.length > 0) {
      // Still actively working on items in this batch. Do not zip yet!
      return;
    }

    // Debounce zip creation to ensure all child processes and file writes are closed
    if (batch.zipTimer) {
      clearTimeout(batch.zipTimer);
    }
    batch.zipTimer = setTimeout(() => {
      this.executeZipArchive(batchId);
    }, 2000);
  }

  async executeZipArchive(batchId) {
    const batch = this.zipBatches.get(batchId);
    if (!batch) return;
    if (batch.isZipping) return;
    batch.isZipping = true;

    try {
      const targetDirToZip = batch.rootFolder || (batch.targetFolders.size > 0 ? Array.from(batch.targetFolders)[0] : null);
      if (targetDirToZip && fs.existsSync(targetDirToZip)) {
        // 1. Clean up any .temp_mediafetch subdirectories first
        const tempSub = path.join(targetDirToZip, '.temp_mediafetch');
        if (fs.existsSync(tempSub)) {
          try { fs.rmSync(tempSub, { recursive: true, force: true }); } catch (_) {}
        }

        // 2. Check if there are valid files to zip
        const validFiles = fs.readdirSync(targetDirToZip).filter(f => !f.startsWith('.'));
        if (validFiles.length === 0) {
          try { fs.rmSync(targetDirToZip, { recursive: true, force: true }); } catch (_) {}
          this.zipBatches.delete(batchId);
          return;
        }

        const parentDir = batch.baseDir || path.dirname(targetDirToZip);
        const baseName = (batch.archiveName || path.basename(targetDirToZip)).replace(/\.zip$/i, '');
        const zipPath = path.join(parentDir, `${baseName}.zip`);
        if (fs.existsSync(zipPath)) {
          try { fs.unlinkSync(zipPath); } catch (_) {}
        }
        logger.info(`[ZIP Package] Creating zip archive for ${targetDirToZip} -> ${zipPath}`);

        const isWin = process.platform === 'win32';
        const { exec } = await import('child_process');

        await new Promise((resolve) => {
          if (isWin) {
            const psCmd = `Add-Type -AssemblyName System.IO.Compression.FileSystem; [System.IO.Compression.ZipFile]::CreateFromDirectory('${targetDirToZip.replace(/'/g, "''")}', '${zipPath.replace(/'/g, "''")}')`;
            exec(`powershell -NoProfile -Command "${psCmd}"`, { windowsHide: true }, (psErr) => {
              if (!psErr && fs.existsSync(zipPath) && fs.statSync(zipPath).size > 100) {
                logger.info(`[ZIP Package] .NET zip archive created successfully: ${zipPath}`);
                return resolve();
              }
              const fallbackCmd = `powershell -NoProfile -Command "Compress-Archive -LiteralPath '${targetDirToZip.replace(/'/g, "''")}' -DestinationPath '${zipPath.replace(/'/g, "''")}' -Force"`;
              exec(fallbackCmd, { windowsHide: true }, () => resolve());
            });
          } else {
            const cmd = process.platform === 'darwin'
              ? `/usr/bin/ditto -c -k --sequesterRsrc "${targetDirToZip}" "${zipPath}"`
              : `zip -r "${zipPath}" .`;
            exec(cmd, { cwd: targetDirToZip }, (err) => {
              if (err) logger.warn('[ZIP Package] Compression notice:', err.message);
              resolve();
            });
          }
        });

        // 3. Once .zip exists and is verified, completely remove the staging folder!
        if (fs.existsSync(zipPath) && fs.statSync(zipPath).size > 100) {
          let removed = false;
          for (let attempt = 0; attempt < 5; attempt++) {
            try {
              fs.rmSync(targetDirToZip, { recursive: true, force: true });
              removed = true;
              logger.info(`[ZIP Package] Removed staging folder after packaging: ${targetDirToZip}`);
              break;
            } catch (rmErr) {
              await new Promise((r) => setTimeout(r, 500));
            }
          }
          if (!removed && isWin) {
            try {
              exec(`powershell -NoProfile -Command "Remove-Item -LiteralPath '${targetDirToZip.replace(/'/g, "''")}' -Recurse -Force -ErrorAction SilentlyContinue"`, { windowsHide: true }, () => {});
            } catch (_) {}
          }
        }

        this.emit({
          type: 'ZIP_PACKAGE_COMPLETED',
          batchId,
          zipPath,
          archiveName: batch.archiveName
        });
      }
    } catch (zErr) {
      logger.error('[ZIP Package] Error:', zErr);
    } finally {
      this.zipBatches.delete(batchId);
    }
  }

  subscribe(listener) {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  emit(event) {
    for (const l of this.listeners) {
      try {
        l(event);
      } catch (err) {
        logger.error('Error in queue listener:', err);
      }
    }
  }

  getItems() {
    return [...this.items].sort((a, b) => {
      const isAActive = ['downloading', 'analyzing', 'waiting', 'retrying'].includes(a.status);
      const isBActive = ['downloading', 'analyzing', 'waiting', 'retrying'].includes(b.status);
      if (isAActive && !isBActive) return -1;
      if (!isAActive && isBActive) return 1;

      const timeA = a.startTime || parseInt((a.id || '').split('_')[1], 10) || 0;
      const timeB = b.startTime || parseInt((b.id || '').split('_')[1], 10) || 0;
      return timeB - timeA;
    });
  }

  getActiveCount() {
    return this.activeJobs.size;
  }

  addItem(url, profile, projectContext, targetDirectory, metadata) {
    const downloadId = `dl_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const resolved = filesystemManager.resolveTargetDirectory(projectContext, targetDirectory);
    let targetFolder = resolved.targetDir;
    if (metadata?.zipPackage) {
      // FOR ZIP PACKAGES: ALWAYS route to the zip staging folder!
      // NEVER EVER route to a loose custom folder or normal folder!
      let rootFolder = null;
      if (metadata.batchId && this.zipBatches.has(metadata.batchId)) {
        rootFolder = this.zipBatches.get(metadata.batchId).rootFolder;
      }
      if (!rootFolder) {
        const bId = metadata.batchId || ('batch_' + Date.now());
        rootFolder = path.join(resolved.targetDir, '.mf_zip_staging_' + bId);
        filesystemManager.ensureDirExists(rootFolder);
        let rawArchive = (metadata.customFolderName || metadata.playlistTitle || (metadata.isCloud ? 'Cloud_Media' : 'Playlist_Media')).trim();
        let cleanArchive = rawArchive.replace(/[\\/:*?"<>|]/g, '_').replace(/[.\s]+$/g, '').trim();
        if (!cleanArchive) cleanArchive = metadata.isCloud ? 'Cloud_Media' : 'Playlist_Media';
        this.registerZipBatch(bId, {
          totalItems: 1,
          archiveName: cleanArchive,
          rootFolder,
          baseDir: resolved.targetDir
        });
      }
      targetFolder = rootFolder;
      if (metadata?.subFolderName) {
        const cleanSub = metadata.subFolderName.split(/\s*[\/\\]\s*/).filter(Boolean).join(path.sep);
        if (cleanSub) {
          targetFolder = path.join(targetFolder, cleanSub);
        }
      }
    } else {
      if (metadata?.customFolderName) {
        let cleanCustom = metadata.customFolderName.replace(/[\\/:*?"<>|]/g, '_').replace(/[.\s]+$/g, '').trim();
        if (cleanCustom) {
          targetFolder = path.join(targetFolder, cleanCustom);
        }
      }
      if (metadata?.subFolderName) {
        const cleanSub = metadata.subFolderName.split(/\s*[\/\\]\s*/).filter(Boolean).join(path.sep);
        if (cleanSub) {
          targetFolder = path.join(targetFolder, cleanSub);
        }
      }
    }

    const edition = metadata?.edition || (metadata?.isPro ? 'pro' : 'standard');
    const isZip = Boolean(metadata?.zipPackage);
    const itemAutoImport = isZip ? false : (metadata?.autoImport !== false);

    const item = {
      id: downloadId,
      url,
      edition,
      title: metadata?.title || 'Fetching media info...',
      thumbnail: metadata?.thumbnail,
      duration: metadata?.duration,
      metadata: metadata || {},
      profile,
      projectContext,
      status: 'waiting',
      progress: 0,
      speed: '',
      eta: '',
      downloadedBytes: 0,
      totalBytes: 0,
      targetFolder,
      projectFolder: targetFolder,
      retryCount: 0,
      maxRetries: settingsManager.getSettings()?.downloads?.maxRetries || 3,
      stageDescription: 'Queued for download...',
      autoImport: itemAutoImport,
      zipPackage: isZip,
      batchId: metadata?.batchId,
      playlistTitle: metadata?.playlistTitle || '',
      customFolderName: metadata?.customFolderName || '',
      subFolderName: metadata?.subFolderName || '',
      isPlaylist: Boolean(metadata?.isPlaylist),
      isCloud: Boolean(metadata?.isCloud)
    };

    // Prepend to top of queue so newest download is always at the top of the list
    this.items.unshift(item);
    this.save();
    this.emit({ type: 'QUEUE_UPDATED', items: this.getItems() });
    this.processQueue();
    return item;
  }

  pauseItem(id) {
    const item = this.items.find((i) => i.id === id);
    if (!item) return;
    if (typeof retryManager.cancelScheduledRetry === 'function') retryManager.cancelScheduledRetry(id);
    if (this.activeJobs.has(id)) {
      const job = this.activeJobs.get(id);
      job?.pause();
      this.activeJobs.delete(id);
    }
    item.status = 'paused';
    item.stageDescription = 'Paused';
    this.save();
    this.emit({ type: 'QUEUE_UPDATED', items: this.getItems() });
    this.processQueue();
  }

  resumeItem(id) {
    const item = this.items.find((i) => i.id === id);
    if (!item) return;
    if (typeof retryManager.cancelScheduledRetry === 'function') retryManager.cancelScheduledRetry(id);
    if (this.activeJobs.has(id)) {
      const job = this.activeJobs.get(id);
      job?.cancel();
      this.activeJobs.delete(id);
    }
    item.status = 'waiting';
    item.error = undefined;
    item.stageDescription = 'Waiting to resume...';
    this.save();
    this.emit({ type: 'QUEUE_UPDATED', items: this.getItems() });
    this.processQueue();
  }

  cancelItem(id) {
    const item = this.items.find((i) => i.id === id);
    if (!item) return;
    if (typeof retryManager.cancelScheduledRetry === 'function') retryManager.cancelScheduledRetry(id);
    if (this.activeJobs.has(id)) {
      const job = this.activeJobs.get(id);
      job?.cancel();
      this.activeJobs.delete(id);
    }
    // Remove item completely from the queue on cancel/X
    this.items = this.items.filter((i) => i.id !== id);
    this.save();
    this.emit({ type: 'QUEUE_UPDATED', items: this.getItems() });
    this.processQueue();
  }

  retryItem(id) {
    const item = this.items.find((i) => i.id === id);
    if (!item) return;
    if (typeof retryManager.cancelScheduledRetry === 'function') retryManager.cancelScheduledRetry(id);
    if (this.activeJobs.has(id)) {
      const job = this.activeJobs.get(id);
      job?.cancel();
      this.activeJobs.delete(id);
    }
    item.status = 'waiting';
    item.retryCount = 0;
    item.error = undefined;
    item.stageDescription = 'Retrying download...';
    this.save();
    this.emit({ type: 'QUEUE_UPDATED', items: this.getItems() });
    this.processQueue();
  }

  removeItem(id) {
    this.cancelItem(id);
  }

  clearCompleted(edition) {
    if (edition) {
      this.items = this.items.filter((i) => (i.edition && i.edition !== edition) || i.status === 'downloading' || i.status === 'waiting');
    } else {
      this.items = this.items.filter((i) => i.status === 'downloading' || i.status === 'waiting');
    }
    this.save();
    this.emit({ type: 'QUEUE_UPDATED', items: this.getItems() });
  }

  clearAll(edition) {
    if (edition) {
      for (const item of this.items) {
        if ((!item.edition || item.edition === edition) && (item.status === 'downloading' || item.status === 'waiting')) {
          if (this.activeJobs.has(item.id)) {
            this.activeJobs.get(item.id)?.cancel();
          }
        }
      }
      this.items = this.items.filter((i) => i.edition && i.edition !== edition);
    } else {
      for (const item of this.items) {
        if (item.status === 'downloading' || item.status === 'waiting') {
          if (this.activeJobs.has(item.id)) {
            this.activeJobs.get(item.id)?.cancel();
          }
        }
      }
      this.activeJobs.clear();
      this.items = [];
    }
    this.save();
    this.emit({ type: 'QUEUE_UPDATED', items: this.getItems() });
  }

  resumeAllInterrupted() {
    for (const item of this.items) {
      if (item.status === 'paused' || item.status === 'failed' || (item.status === 'downloading' && !this.activeJobs.has(item.id))) {
        item.status = 'waiting';
        item.error = undefined;
        item.stageDescription = 'Queued for retry...';
      }
    }
    this.save();
    this.emit({ type: 'QUEUE_UPDATED', items: this.getItems() });
    this.processQueue();
  }

  async processQueue() {
    if (this.isProcessing) return;
    this.isProcessing = true;
    try {
      const concurrency = Math.min(8, Math.max(1, settingsManager.getSettings()?.downloads?.concurrency || 4));
      while (this.activeJobs.size < concurrency) {
        const next = this.items.find((i) => i.status === 'waiting');
        if (!next) break;
        this.startItemDownload(next);
      }
    } finally {
      this.isProcessing = false;
    }
  }

  startItemDownload(item) {
    item.status = 'downloading';
    item.startTime = Date.now();
    item.stageDescription = 'Connecting to media stream...';
    this.save();
    this.emit({ type: 'QUEUE_UPDATED', items: this.getItems() });

    const job = new DownloadJob(item, (update) => {
      item.progress = update.progress;
      item.downloadedBytes = update.downloadedBytes;
      item.totalBytes = update.totalBytes;
      item.speed = update.speed;
      item.eta = update.eta;
      if (update.stageDescription) item.stageDescription = update.stageDescription;
      this.emit({ type: 'DOWNLOAD_PROGRESS', item });
    });

    this.activeJobs.set(item.id, job);

    job.start()
      .then((result) => {
        this.activeJobs.delete(item.id);
        item.status = 'completed';
        item.progress = 100;
        item.outputPath = result.finalPath;
        item.downloadedBytes = result.fileSize;
        item.totalBytes = result.fileSize;
        item.completionTime = Date.now();
        item.speed = '';
        item.eta = '';
        item.stageDescription = 'Download completed successfully';
        item.outputPath = result.finalPath;
        item.downloadedPath = result.finalPath;

        if (!item.title || item.title === 'Fetching media info...' || item.title === 'Media' || /^video by /i.test(item.title) || /^post by /i.test(item.title)) {
          item.title = path.parse(result.finalPath).name;
        }

        const historyEntry = {
          id: item.id,
          title: item.title,
          url: item.url,
          edition: item.edition || 'standard',
          date: Date.now(),
          profileName: item.profile.label || item.profile.presetId,
          outputPath: result.finalPath,
          fileSize: result.fileSize,
          status: 'completed',
          duration: item.duration,
          thumbnail: item.thumbnail
        };

        historyManager.addEntry(historyEntry);
        this.save();
        this.emit({ type: 'DOWNLOAD_COMPLETED', item, historyEntry });
        this.checkZipBatchCompletion(item, true);
        this.processQueue();
      })
      .catch((err) => {
        this.activeJobs.delete(item.id);
        if (err?.isPaused) {
          item.status = 'paused';
          item.stageDescription = 'Paused';
          this.save();
          this.emit({ type: 'QUEUE_UPDATED', items: this.getItems() });
          this.processQueue();
          return;
        }
        if (err?.isCancelled) {
          item.status = 'cancelled';
          item.stageDescription = 'Cancelled';
          this.save();
          this.emit({ type: 'QUEUE_UPDATED', items: this.getItems() });
          this.checkZipBatchCompletion(item, false);
          this.processQueue();
          return;
        }

        item.error = err;
        if (retryManager.shouldRetry(item, err)) {
          item.status = 'retrying';
          item.retryCount++;
          const delay = settingsManager.getSettings()?.downloads?.retryDelayMs || 3000;
          retryManager.scheduleRetry(item, () => {
            item.status = 'waiting';
            item.stageDescription = `Retrying (${item.retryCount}/${item.maxRetries})...`;
            this.save();
            this.emit({ type: 'QUEUE_UPDATED', items: this.getItems() });
            this.processQueue();
          }, delay);
        } else {
          item.status = 'failed';
          item.stageDescription = err?.message || 'Download failed';
          this.save();
          this.emit({ type: 'DOWNLOAD_FAILED', item });
          this.checkZipBatchCompletion(item, false);
          this.processQueue();
        }
      });
  }

  load() {
    try {
      if (fs.existsSync(this.queuePath)) {
        const data = fs.readFileSync(this.queuePath, 'utf-8');
        const parsed = JSON.parse(data);
        if (Array.isArray(parsed)) {
          this.items = parsed.map((item) => {
            if (item.status === 'downloading' || item.status === 'waiting') {
              return { ...item, status: 'paused', stageDescription: 'Interrupted (Paused)' };
            }
            return item;
          });
        }
      }
    } catch (err) {
      logger.warn('Failed to load queue.json:', err);
      this.items = [];
    }
  }

  save() {
    try {
      const dir = path.dirname(this.queuePath);
      filesystemManager.ensureDirExists(dir);
      const tmp = this.queuePath + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify(this.items, null, 2), 'utf-8');
      fs.renameSync(tmp, this.queuePath);
    } catch (err) {
      logger.error('Failed to save queue.json:', err);
    }
  }
}

export const queueManager = new QueueManager();