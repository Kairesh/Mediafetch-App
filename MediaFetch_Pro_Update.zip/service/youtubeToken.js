/**
 * YouTube Visitor Data & Token Manager
 * Automatically provides valid visitor tokens to bypass YouTube anti-bot & SABR restrictions.
 */

import fs from 'fs';
import { logger } from './logger.js';
import { dependencyManager } from './dependencies.js';

class YouTubeTokenManager {
  constructor() {
    this.fallbackVisitorData = '';
    this.cachedVisitorData = null;
    this.lastFetched = 0;
    this.isFetching = false;
  }

  isYouTubeUrl(url) {
    if (!url || typeof url !== 'string') return false;
    const lower = url.toLowerCase().trim();
    return lower.includes('youtube.com') || lower.includes('youtu.be') || lower.startsWith('ytsearch');
  }

  async getVisitorData() {
    const age = Date.now() - this.lastFetched;
    if ((!this.cachedVisitorData || age > 12 * 60 * 60 * 1000) && !this.isFetching) {
      await this.refreshVisitorData().catch(() => {});
    }
    return this.cachedVisitorData || '';
  }

  async refreshVisitorData() {
    if (this.isFetching) return this.cachedVisitorData;
    this.isFetching = true;
    try {
      logger?.debug?.('[YouTubeTokenManager] Refreshing YouTube visitor data token...');
      const res = await fetch('https://www.youtube.com', {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
          'Accept-Language': 'en-US,en;q=0.9'
        },
        signal: AbortSignal.timeout(6000)
      });
      if (res.ok) {
        const html = await res.text();
        const match = html.match(/"VISITOR_DATA":\s*"([^"]+)"/);
        if (match && match[1]) {
          try {
            this.cachedVisitorData = decodeURIComponent(match[1]);
          } catch (_) {
            this.cachedVisitorData = match[1];
          }
          this.lastFetched = Date.now();
          logger?.info?.('[YouTubeTokenManager] Successfully refreshed YouTube visitor token');
          return this.cachedVisitorData;
        }
      }
    } catch (err) {
      logger?.warn?.('[YouTubeTokenManager] Background visitor token refresh notice:', err?.message || err);
    } finally {
      this.isFetching = false;
    }
    return this.cachedVisitorData || this.fallbackVisitorData;
  }

  async getYtDlpExtractorArgs(url) {
    const nodeBin = dependencyManager.getNodeExecutablePath();
    const jsRuntime = nodeBin === 'node' ? 'node' : `node:${nodeBin}`;

    const args = ['--js-runtimes', jsRuntime];
    if (this.isYouTubeUrl(url)) {
      args.push('--remote-components', 'ejs:github');
      args.push('--extractor-args', 'youtube:player_client=web_embedded,android');
    }
    return args;
  }
}

export const youtubeTokenManager = new YouTubeTokenManager();
