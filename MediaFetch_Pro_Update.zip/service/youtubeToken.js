/**
 * YouTube Visitor Data & Token Manager
 * Automatically provides valid visitor tokens to bypass YouTube anti-bot & SABR restrictions.
 */

import fs from 'fs';
import path from 'path';
import os from 'os';
import { logger } from './logger.js';
import { dependencyManager } from './dependencies.js';

class YouTubeTokenManager {
  constructor() {
    this.fallbackVisitorData = 'CgtOR2NfOVFoTm9HYyiv0LPWBjIKCgJJThIEGgAgYGKzAgqwAkN1RUJDQVVTa3dFQjhRWnVac2NMUGktQlRuSVVoS3FVLV80NFdfOW95bkFwVDlDVzlxbUl1M3h6QkE3aWxMTHZhbFVEMHNzdnJVanZkLXlHSjNpLWgzUEczRHVzaV9OTmVRd21DdXZSd3BlRHVtV0loZkZQNVBHN1ZUM1VaT1pPdzJ2U1l0QVdTeHE4YnpjNVBNdmEzeWpPci02VHEwc0RRVzVDSEhYMU5ZREx5QklvU1F2cmh2V3RseHlJcW1FWkpHR2dnODY0ckhUNTFTc29CVEpGQWQ2cG5VOU5TRVNPM0lMWkZYeFNUZUEtbnFJdEM3eGdsWEU4eldqS2FCZDctamJ4ZERuUUxHYVFacXdRdGJ5djlUVWp4UjhGTkNuYmU2bi1idWZDMWE1OGFxTUw=';
    this.tokenFilePath = path.join(process.env.LOCALAPPDATA || (os.homedir ? path.join(os.homedir(), 'AppData', 'Local') : '.'), 'MediaFetch', 'visitor_data.txt');
    this.cachedVisitorData = this.readSavedVisitorData() || this.fallbackVisitorData;
    this.lastFetched = 0;
    this.isFetching = false;
  }

  readSavedVisitorData() {
    try {
      if (fs.existsSync(this.tokenFilePath)) {
        const val = fs.readFileSync(this.tokenFilePath, 'utf8').trim();
        if (val && val.length > 20) return val;
      }
    } catch (_) {}
    return null;
  }

  saveVisitorData(vd) {
    try {
      const dir = path.dirname(this.tokenFilePath);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(this.tokenFilePath, vd, 'utf8');
    } catch (_) {}
  }

  isYouTubeUrl(url) {
    if (!url || typeof url !== 'string') return false;
    const lower = url.toLowerCase().trim();
    return lower.includes('youtube.com') || lower.includes('youtu.be') || lower.startsWith('ytsearch');
  }

  async getVisitorData() {
    const age = Date.now() - this.lastFetched;
    if ((!this.cachedVisitorData || this.cachedVisitorData === this.fallbackVisitorData || age > 6 * 60 * 60 * 1000) && !this.isFetching) {
      await this.refreshVisitorData().catch(() => {});
    }
    return this.cachedVisitorData || this.fallbackVisitorData;
  }

  async refreshVisitorData() {
    if (this.isFetching) return this.cachedVisitorData;
    this.isFetching = true;
    try {
      logger?.debug?.('[YouTubeTokenManager] Refreshing YouTube visitor data token...');
      const res = await fetch('https://www.youtube.com', {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
          'Accept-Language': 'en-US,en;q=0.9'
        },
        signal: AbortSignal.timeout(6000)
      });
      if (res.ok) {
        const html = await res.text();
        const match = html.match(/"VISITOR_DATA":\s*"([^"]+)"/);
        if (match && match[1]) {
          try {
            this.cachedVisitorData = decodeURIComponent(match[1]);
          } catch (_) {
            this.cachedVisitorData = match[1];
          }
          this.lastFetched = Date.now();
          this.saveVisitorData(this.cachedVisitorData);
          logger?.info?.('[YouTubeTokenManager] Successfully refreshed YouTube visitor token');
          return this.cachedVisitorData;
        }
      }
    } catch (err) {
      logger?.warn?.('[YouTubeTokenManager] Background visitor token refresh notice:', err?.message || err);
    } finally {
      this.isFetching = false;
    }
    return this.cachedVisitorData || this.fallbackVisitorData;
  }

  async getYtDlpExtractorArgs(url) {
    const nodeBin = dependencyManager.getNodeExecutablePath();
    const jsRuntime = nodeBin === 'node' ? 'node' : `node:${nodeBin}`;

    const args = ['--js-runtimes', jsRuntime];
    if (this.isYouTubeUrl(url)) {
      const localAppData = process.env.LOCALAPPDATA || (os.homedir ? path.join(os.homedir(), 'AppData', 'Local') : '');
      const cookiesFilePath = localAppData ? path.join(localAppData, 'MediaFetch', 'cookies.txt') : '';
      const hasCookies = cookiesFilePath && fs.existsSync(cookiesFilePath) && fs.statSync(cookiesFilePath).size > 10;

      let extArg = hasCookies ? 'youtube:player_client=web,android' : 'youtube:player_client=android,web';
      if (!hasCookies) {
        try {
          const vd = await this.getVisitorData();
          if (vd) {
            extArg += `;visitor_data=${vd}`;
          }
        } catch (_) {}
      }
      args.push('--extractor-args', extArg);
    }
    return args;
  }
}

export const youtubeTokenManager = new YouTubeTokenManager();
