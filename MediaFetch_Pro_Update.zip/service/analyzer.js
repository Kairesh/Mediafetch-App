import { execFile } from 'child_process';
import { promisify } from 'util';
import https from 'https';
import http from 'http';
import fs from 'fs';
import path from 'path';
import os from 'os';
import { classifyError } from '../common/errors.js';
import { dependencyManager } from './dependencies.js';
import { settingsManager } from './settings.js';
import { logger } from './logger.js';
import { youtubeTokenManager } from './youtubeToken.js';

const execFileAsync = promisify(execFile);

function fetchHtml(targetUrl, headers = {}, maxRedirects = 5) {
  return new Promise((resolve, reject) => {
    if (maxRedirects <= 0) return reject(new Error('Too many redirects'));
    const client = targetUrl.startsWith('https:') ? https : http;
    const req = client.get(targetUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        ...headers
      }
    }, res => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        let next = res.headers.location;
        if (!next.startsWith('http')) {
          try {
            const u = new URL(targetUrl);
            next = u.origin + next;
          } catch (e) {
            return reject(e);
          }
        }
        return fetchHtml(next, headers, maxRedirects - 1).then(resolve, reject);
      }
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve({ statusCode: res.statusCode, body: data, finalUrl: targetUrl }));
    });
    req.on('error', reject);
    req.setTimeout(15000, () => {
      req.destroy();
      reject(new Error('HTTP request timed out'));
    });
  });
}

async function probeMp4Duration(fileId, timeoutMs = 2500) {
  if (!fileId) return 0;
  return new Promise((resolve) => {
    let resolved = false;
    const finish = (val) => {
      if (!resolved) {
        resolved = true;
        resolve(val);
      }
    };
    const timer = setTimeout(() => finish(0), timeoutMs);

    function doRequest(targetUrl, redirectsLeft = 3) {
      if (redirectsLeft < 0) return finish(0);
      try {
        const parsed = new URL(targetUrl);
        const client = parsed.protocol === 'http:' ? http : https;
        const req = client.get(targetUrl, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
            'Range': 'bytes=0-262144'
          }
        }, (res) => {
          if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
            let next = res.headers.location;
            if (!next.startsWith('http')) {
              try { next = new URL(next, targetUrl).href; } catch { return finish(0); }
            }
            return doRequest(next, redirectsLeft - 1);
          }
          const chunks = [];
          res.on('data', (c) => chunks.push(c));
          res.on('end', () => {
            clearTimeout(timer);
            const buf = Buffer.concat(chunks);
            if (buf.length >= 32) {
              const mvhdIdx = buf.indexOf(Buffer.from('mvhd'));
              if (mvhdIdx !== -1 && mvhdIdx + 24 <= buf.length) {
                const version = buf[mvhdIdx + 4];
                if (version === 0) {
                  const timescale = buf.readUInt32BE(mvhdIdx + 16);
                  const duration = buf.readUInt32BE(mvhdIdx + 20);
                  if (timescale > 0 && duration > 0) {
                    return finish(Math.round(duration / timescale));
                  }
                } else if (version === 1 && mvhdIdx + 36 <= buf.length) {
                  const timescale = buf.readUInt32BE(mvhdIdx + 24);
                  const durHi = buf.readUInt32BE(mvhdIdx + 28);
                  const durLo = buf.readUInt32BE(mvhdIdx + 32);
                  const duration = durHi * 4294967296 + durLo;
                  if (timescale > 0 && duration > 0) {
                    return finish(Math.round(duration / timescale));
                  }
                }
              }
            }
            finish(0);
          });
          res.on('error', () => finish(0));
        });
        req.on('error', () => finish(0));
        req.setTimeout(timeoutMs, () => {
          try { req.destroy(); } catch (_) {}
          finish(0);
        });
      } catch (_) {
        finish(0);
      }
    }

    doRequest(`https://drive.usercontent.google.com/download?id=${fileId}&export=download`);
  });
}

export class MetadataAnalyzer {
  isValidUrl(urlStr) {
    try {
      const parsed = new URL(urlStr);
      return parsed.protocol === 'http:' || parsed.protocol === 'https:';
    } catch {
      return false;
    }
  }

  isPlaylistUrl(urlStr) {
    if (!this.isValidUrl(urlStr)) return false;
    const lower = urlStr.toLowerCase();
    return lower.includes('playlist?list=') || 
           lower.includes('&list=') || 
           lower.includes('?list=') || 
           lower.includes('/sets/') || 
           lower.includes('/album/') || 
           (lower.includes('spotify.') && (lower.includes('/playlist/') || lower.includes('/album/') || lower.includes('/artist/'))) ||
           lower.includes('drive.google.com/drive/folders/') ||
           lower.includes('drive.google.com/drive/u/') ||
           lower.includes('drive.google.com/folderview') ||
           (lower.includes('dropbox.com') && (lower.includes('/scl/fo/') || lower.includes('/sh/') || lower.includes('/folder/'))) ||
           lower.includes('1drv.ms') ||
           lower.includes('onedrive.live.com') ||
           lower.includes('sharepoint.com') ||
           lower.includes('box.com/s/') ||
           lower.includes('box.com/folder/') ||
           lower.includes('mega.nz/folder/') ||
           lower.includes('mega.nz/#f!') ||
           (lower.includes('pinterest.') && lower.includes('/boards/'));
  }

  isSpotifyPlaylistUrl(urlStr) {
    if (!this.isValidUrl(urlStr)) return false;
    return /spotify\.(?:com|link).*(?:\/playlist\/|\/album\/|\/artist\/)/i.test(urlStr);
  }

  async parseGoogleDriveFolderRecursive(folderId, folderPath = '', depth = 0, maxDepth = 8, visited = new Set()) {
    if (!folderId || depth > maxDepth || visited.has(folderId)) {
      return { title: folderPath, items: [], folders: [] };
    }
    visited.add(folderId);
    const folderUrl = `https://drive.google.com/drive/folders/${folderId}`;

    let html = '';
    try {
      const res = await fetchHtml(folderUrl, {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9'
      });
      html = res.body;
      if (res.statusCode === 404) {
        throw new Error('Google Drive folder not found (404). Please verify the link or ensure it is set to "Anyone with the link can view".');
      }
      if (res.statusCode === 403 || res.statusCode === 401) {
        throw new Error('Google Drive access denied (403). Set folder sharing to "Anyone with the link can view".');
      }
    } catch (e) {
      if (depth === 0) {
        throw e;
      }
      logger.warn(`Failed to fetch Drive folder ${folderId}:`, e);
      return { title: folderPath, items: [], folders: [] };
    }

    let folderTitle = folderPath;
    if (!folderTitle) {
      const tMatch = html.match(/<title>([^<]+?)(?:\s*–\s*Google\s*Drive)?<\/title>/i);
      if (tMatch) folderTitle = tMatch[1].trim();
    }
    if (!folderTitle) folderTitle = 'Google Drive Folder';

    const ivdMatch = html.match(/window\['_DRIVE_ivd'\]\s*=\s*'([^']+)'/);
    if (!ivdMatch) {
      if (depth === 0) {
        if (html.includes('404') || html.includes('Not Found') || html.includes('Error 404')) {
          throw new Error('Google Drive folder not found (404). Please verify the link is valid and public.');
        }
        if (html.includes('accounts.google.com/ServiceLogin') || html.includes('Sign in - Google Accounts')) {
          throw new Error('Google Drive folder requires sign-in. Change sharing to "Anyone with the link can view".');
        }
      }
      return { title: folderTitle, items: [], folders: [] };
    }

    let rawItems = [];
    try {
      const rawStr = ivdMatch[1];
      const unescaped = rawStr.replace(/\\x([0-9A-Fa-f]{2})/g, (_, hex) => String.fromCharCode(parseInt(hex, 16)));
      const parsed = JSON.parse(unescaped);
      rawItems = parsed[0] || [];
    } catch (e) {
      logger.warn(`Failed to parse _DRIVE_ivd for folder ${folderId}:`, e);
      return { title: folderTitle, items: [], folders: [] };
    }

    const directFiles = [];
    const subFolderDefs = [];

    for (let idx = 0; idx < rawItems.length; idx++) {
      const item = rawItems[idx];
      const itemId = item[0];
      if (!itemId) continue;
      const itemName = item[2] || `File_${idx + 1}`;
      const mime = item[3] || 'video/mp4';

      if (mime === 'application/vnd.google-apps.folder') {
        subFolderDefs.push({ id: itemId, name: itemName });
      } else {
        const isVideo = mime.startsWith('video') || /\.(mp4|mov|mkv|webm|avi|flv|m4v)$/i.test(itemName);
        const isAudio = mime.startsWith('audio') || /\.(mp3|wav|m4a|aac|flac|ogg)$/i.test(itemName);
        const isImage = mime.startsWith('image') || /\.(jpg|jpeg|png|webp|gif|bmp)$/i.test(itemName);
        const directUrl = `https://drive.google.com/uc?export=download&id=${itemId}`;
        const thumbUrl = `https://drive.google.com/thumbnail?id=${itemId}&sz=w800`;

        const hMatch = itemName.match(/(\d{3,4})p/i);
        let detectedH = 0;
        if (hMatch) {
          detectedH = parseInt(hMatch[1], 10);
        } else if (/\b4k\b/i.test(itemName) || /\b2160\b/.test(itemName)) {
          detectedH = 2160;
        } else if (/\b1440\b/.test(itemName) || /\b2k\b/i.test(itemName)) {
          detectedH = 1440;
        } else if (/\b1080\b/.test(itemName)) {
          detectedH = 1080;
        } else if (/\b720\b/.test(itemName)) {
          detectedH = 720;
        } else if (/\b480\b/.test(itemName)) {
          detectedH = 480;
        }

        directFiles.push({
          id: itemId,
          title: itemName,
          author: 'Google Drive',
          duration: 0,
          thumbnail: thumbUrl,
          url: directUrl,
          directUrl: directUrl,
          mediaType: isVideo ? 'video' : (isAudio ? 'audio' : (isImage ? 'image' : 'video')),
          height: detectedH,
          resolution: detectedH ? `${detectedH}p` : undefined,
          subFolderId: folderId,
          subFolderName: folderPath || folderTitle
        });
      }
    }

    // Duration is left at 0 for instant, lightweight cloud parsing without CPU spikes or network lag

    // Recurse into subfolders up to maxDepth 8 in parallel
    const childResults = await Promise.all(subFolderDefs.map(async (sub) => {
      const nextPath = folderPath ? `${folderPath} / ${sub.name}` : sub.name;
      const subRes = await this.parseGoogleDriveFolderRecursive(sub.id, nextPath, depth + 1, maxDepth, visited);
      if (subRes.items.length > 0 || subRes.folders.length > 0) {
        return {
          id: sub.id,
          name: nextPath,
          items: subRes.items,
          folders: subRes.folders
        };
      }
      return null;
    }));
    const childFolders = childResults.filter(Boolean);

    return {
      title: folderTitle,
      items: directFiles,
      folders: childFolders
    };
  }

  async analyzePlaylist(url, timeoutMs = 35000) {
    // 0. Google Drive Shared Folder Scraper (Footages & Multi-Files & Subfolders)
    if (url.includes('drive.google.com') && (url.includes('/folders/') || url.includes('folderview') || url.includes('/drive/u/'))) {
      logger.info(`Analyzing Google Drive shared folder: ${url}`);
      try {
        const fMatch = url.match(/folders\/([a-zA-Z0-9_-]+)/);
        const idMatch = url.match(/[?&]id=([a-zA-Z0-9_-]+)/);
        const folderId = fMatch ? fMatch[1] : (idMatch ? idMatch[1] : '');

        const tree = await this.parseGoogleDriveFolderRecursive(folderId, '', 0, 8);

        const allFlatItems = [];
        const folderGroups = [];

        // Direct files in root folder (if any)
        if (tree.items.length > 0) {
          folderGroups.push({
            id: folderId,
            name: tree.title || 'Main Folder',
            items: tree.items
          });
          allFlatItems.push(...tree.items);
        }

        // Subfolders recursive collection
        function collectSubfolders(subGroupList) {
          for (const grp of subGroupList) {
            if (grp.items && grp.items.length > 0) {
              folderGroups.push({
                id: grp.id,
                name: grp.name,
                items: grp.items
              });
              allFlatItems.push(...grp.items);
            }
            if (grp.folders && grp.folders.length > 0) {
              collectSubfolders(grp.folders);
            }
          }
        }
        collectSubfolders(tree.folders);

        if (allFlatItems.length > 0) {
          // Assign 1-based sequential indices
          allFlatItems.forEach((it, idx) => {
            it.index = idx + 1;
          });

          return {
            id: folderId || 'drive_folder',
            title: tree.title || 'Google Drive Folder',
            uploader: 'Google Drive',
            thumbnail: allFlatItems[0]?.thumbnail || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800',
            url,
            itemCount: allFlatItems.length,
            items: allFlatItems,
            folders: folderGroups.length > 0 ? folderGroups : [{
              id: folderId || 'root',
              name: tree.title || 'Files',
              items: allFlatItems
            }]
          };
        }
        throw new Error('No media files found in this Google Drive folder.');
      } catch (err) {
        logger.error('Failed to parse Google Drive folder:', err);
        throw err;
      }
    }

    // 1. Spotify Playlist / Album / Artist Scraper
    if (this.isSpotifyPlaylistUrl(url)) {
      logger.info(`Analyzing Spotify playlist/album/artist: ${url}`);
      try {
        const idMatch = url.match(/(playlist|album|artist)\/([a-zA-Z0-9]+)/);
        const type = idMatch ? idMatch[1] : 'playlist';
        const id = idMatch ? idMatch[2] : '';
        if (id) {
          const embedUrl = `https://open.spotify.com/embed/${type}/${id}`;
          const { body: html } = await fetchHtml(embedUrl);
          const nextDataMatch = html.match(/<script id="__NEXT_DATA__" type="application\/json">([\s\S]+?)<\/script>/);
          if (nextDataMatch) {
            const nextData = JSON.parse(nextDataMatch[1]);
            const entity = nextData.props?.pageProps?.state?.data?.entity;
            if (entity) {
              const isArtist = entity.type === 'artist' || type === 'artist';
              const playlistTitle = isArtist 
                ? `${entity.name || 'Artist'} - Top Tracks` 
                : (entity.name || entity.title || 'Spotify Playlist');
              const coverImg = entity.coverArt?.sources?.[0]?.url || 
                entity.visualIdentity?.image?.[1]?.url || 
                entity.visualIdentity?.image?.[0]?.url || 
                'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800';
              const rawTracks = entity.trackList || [];
              const defaultArtist = entity.name || entity.subtitle || 'Artist';
              const items = rawTracks.map((t, idx) => {
                const trackTitle = t.title || `Track ${idx + 1}`;
                const trackArtist = t.subtitle || defaultArtist;
                const durSec = t.duration ? Math.round(t.duration / 1000) : 180;
                const trackUri = t.uri ? t.uri.replace('spotify:track:', 'https://open.spotify.com/track/') : url;
                const fullTitle = trackArtist ? `${trackTitle} - ${trackArtist}`.trim() : trackTitle;
                const searchQuery = `ytsearch1:${trackTitle} ${trackArtist} audio`.trim();
                return {
                  id: t.id || t.uid || `spotify_${idx}`,
                  url: trackUri,
                  title: fullTitle,
                  duration: durSec,
                  thumbnail: coverImg,
                  channel: trackArtist,
                  uploader: trackArtist,
                  downloadQuery: searchQuery,
                  index: idx + 1
                };
              });
              return {
                id: id,
                url,
                title: playlistTitle,
                uploader: isArtist ? entity.name : (entity.subtitle || 'Spotify'),
                itemCount: items.length,
                items,
                thumbnail: coverImg
              };
            }
          }
        }
      } catch (spErr) {
        logger.warn('Spotify playlist embed scraper notice:', spErr);
      }
    }

    // 2. Standard YouTube / Generic Playlist via yt-dlp
    logger.info(`Analyzing playlist with yt-dlp: ${url}`);
    const ytdlpPath = await dependencyManager.getYtDlpExecutablePath();
    const ytArgs = await youtubeTokenManager.getYtDlpExtractorArgs(url);
    const args = [
      '--flat-playlist',
      '--playlist-items', '1:50',
      '--dump-single-json',
      '--no-check-certificates',
      '--prefer-free-formats',
      ...ytArgs,
      '--add-header', 'User-Agent:Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
      url
    ];

    try {
      const { stdout } = await execFileAsync(ytdlpPath, args, {
        windowsHide: true,
        timeout: timeoutMs,
        maxBuffer: 50 * 1024 * 1024
      });
      const raw = JSON.parse(stdout);
      const items = (raw.entries || []).map((entry, index) => {
        let entryUrl = entry.url || entry.webpage_url || '';
        if (entry.id && (!entryUrl || !entryUrl.startsWith('http'))) {
          entryUrl = `https://www.youtube.com/watch?v=${entry.id}`;
        }
        if (!entryUrl) entryUrl = url;
        const entryTitle = entry.title || `Track ${index + 1}`;

        const hMatch = entryTitle.match(/(\d{3,4})p/i);
        let detectedH = entry.height || 0;
        if (!detectedH && hMatch) {
          detectedH = parseInt(hMatch[1], 10);
        } else if (!detectedH) {
          if (/\b4k\b/i.test(entryTitle) || /\b2160\b/.test(entryTitle)) detectedH = 2160;
          else if (/\b1440\b/.test(entryTitle) || /\b2k\b/i.test(entryTitle)) detectedH = 1440;
          else if (/\b1080\b/.test(entryTitle)) detectedH = 1080;
          else if (/\b720\b/.test(entryTitle)) detectedH = 720;
          else if (/\b480\b/.test(entryTitle)) detectedH = 480;
        }

        return {
          id: entry.id || `item_${index}`,
          url: entryUrl,
          downloadQuery: entryUrl,
          title: entryTitle,
          duration: entry.duration || 0,
          thumbnail: entry.thumbnail || entry.thumbnails?.[0]?.url,
          channel: entry.uploader || entry.channel || '',
          uploader: entry.uploader || entry.channel || '',
          index: index + 1,
          height: detectedH,
          resolution: detectedH ? `${detectedH}p` : undefined
        };
      });

      // Sample first item to detect true resolution if no items had detectable heights
      if (items.length > 0 && items[0].url && !items.some((it) => it.height > 0)) {
        try {
          const sampleArgs = [
            '--dump-single-json',
            '--skip-download',
            '--no-warnings',
            '--no-playlist',
            ...ytArgs,
            items[0].url
          ];
          const sampleProc = await execFileAsync(ytdlpPath, sampleArgs, { windowsHide: true, timeout: 6000 });
          const sampleRaw = JSON.parse(sampleProc.stdout);
          const sampleHeights = (sampleRaw.formats || []).map((f) => f.height).filter((h) => typeof h === 'number' && h > 0);
          if (sampleHeights.length > 0) {
            const maxH = Math.max(...sampleHeights);
            items[0].height = maxH;
            items[0].resolution = `${maxH}p`;
          }
        } catch (_) {}
      }

      const rawTitle = (raw.title || raw.playlist_title || raw.playlist || raw.name || '').trim();
      const firstUploader = items[0]?.uploader || items[0]?.channel || raw.uploader || raw.channel || '';
      let finalTitle = rawTitle;
      if (!finalTitle || finalTitle === 'NA' || finalTitle === '[NA]' || finalTitle.toLowerCase() === 'playlist') {
        finalTitle = firstUploader ? `${firstUploader} - Playlist` : (raw.id ? `Playlist_${raw.id}` : 'Media Playlist');
      }

      return {
        id: raw.id || 'playlist',
        url,
        title: finalTitle,
        uploader: raw.uploader || raw.channel || firstUploader || 'YouTube',
        itemCount: items.length,
        items,
        thumbnail: raw.thumbnails?.[0]?.url || (items[0]?.thumbnail || '')
      };
    } catch (err) {
      logger.error('Playlist analysis failed:', err);
      // Fallback: If playlist extraction fails/times out, but the URL has an individual video ID (e.g. ?v=... or /watch?v=... or shorts/...),
      // try single video analysis and wrap it as a 1-item playlist so the user is never blocked!
      const vMatch = url.match(/(?:v=|\/watch\/|\/embed\/|youtu\.be\/|shorts\/)([a-zA-Z0-9_-]{11})/);
      if (vMatch && vMatch[1]) {
        try {
          logger.info(`Playlist analysis failed, attempting fallback to single video for ID ${vMatch[1]}`);
          const singleUrl = `https://www.youtube.com/watch?v=${vMatch[1]}`;
          const singleMeta = await this.analyzeUrl(singleUrl, 15000);
          if (singleMeta) {
            return {
              id: vMatch[1],
              url,
              title: singleMeta.title || 'YouTube Media',
              uploader: singleMeta.uploader || 'YouTube',
              itemCount: 1,
              items: [{
                id: singleMeta.id || vMatch[1],
                url: singleUrl,
                title: singleMeta.title || 'YouTube Media',
                duration: singleMeta.duration || 0,
                thumbnail: singleMeta.thumbnail || '',
                channel: singleMeta.uploader || '',
                uploader: singleMeta.uploader || '',
                index: 1,
                height: singleMeta.height || 0,
                resolution: singleMeta.resolution || (singleMeta.height ? `${singleMeta.height}p` : undefined)
              }],
              thumbnail: singleMeta.thumbnail || ''
            };
          }
        } catch (singleErr) {
          logger.warn('Single video fallback after playlist failure failed:', singleErr);
        }
      }
      throw classifyError(err, 'Failed to analyze playlist');
    }
  }

  isThreadsUrl(urlStr) {
    if (!this.isValidUrl(urlStr)) return false;
    return /threads\.(?:net|com)/i.test(urlStr);
  }

  isSpotifyUrl(urlStr) {
    if (!this.isValidUrl(urlStr)) return false;
    return /spotify\.(?:com|link)/i.test(urlStr);
  }

  isPinterestUrl(urlStr) {
    if (!this.isValidUrl(urlStr)) return false;
    const lower = urlStr.toLowerCase();
    return lower.includes('pinterest.com') || lower.includes('pin.it');
  }

  async expandPinterestUrl(urlStr) {
    if (!urlStr || !urlStr.includes('pin.it')) return urlStr;
    try {
      const res = await fetchHtml(urlStr);
      if (res.finalUrl && !res.finalUrl.includes('pin.it')) {
        return res.finalUrl;
      }
    } catch (e) {
      logger.warn('[Analyzer] Failed to expand pin.it with fetchHtml:', e.message);
    }
    return urlStr;
  }

  async analyzeThreads(url, timeoutMs = 20000) {
    logger.info(`Analyzing Threads post: ${url}`);
    try {
      const { body: html, finalUrl } = await fetchHtml(url, {
        'User-Agent': 'facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)'
      });

      let ogVideo = html.match(/<meta[^>]+property=["']og:video(?::secure_url)?["'][^>]+content=["']([^"']+)["']/i)?.[1]?.replace(/&amp;/g, '&');
      const ogTitle = html.match(/<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']/i)?.[1];
      const ogDesc = html.match(/<meta[^>]+property=["']og:description["'][^>]+content=["']([^"']+)["']/i)?.[1];
      const ogImage = html.match(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i)?.[1]?.replace(/&amp;/g, '&');

      let videoUrl = ogVideo || '';
      if (!videoUrl) {
        const clean = html.replace(/\\u0025/g, '%').replace(/\\u0026/g, '&').replace(/\\\//g, '/').replace(/&amp;/g, '&');
        const vids = clean.match(/https:\/\/[a-zA-Z0-9.\-_]+(?:fbcdn\.net|cdninstagram\.com)[^"\'><\s\\]+?\.mp4[^"\'><\s\\]*/g) || [];
        const valid = vids.filter(v => !v.includes('rsrc.php') && v.includes('oh=') && v.includes('oe='));
        if (valid.length > 0) {
          videoUrl = valid[0];
        } else if (vids.length > 0) {
          videoUrl = vids.find(v => !v.includes('rsrc.php')) || '';
        }
      }

      let author = 'Threads Creator';
      let title = 'Threads Post';
      let thumbnail = ogImage || 'https://images.unsplash.com/photo-1611605698335-8b1569810432?w=800';

      const urlAuthorMatch = (finalUrl || url).match(/@([a-zA-Z0-9._]+)/);
      if (urlAuthorMatch) {
        author = '@' + urlAuthorMatch[1];
      } else if (ogTitle) {
        const aMatch = ogTitle.match(/@([a-zA-Z0-9._]+)/);
        if (aMatch) author = '@' + aMatch[1];
      }

      if (ogDesc) {
        let cleanDesc = ogDesc
          .replace(/&amp;/g, '&')
          .replace(/&#x[0-9a-fA-F]+;/g, ' ')
          .replace(/&#[0-9]+;/g, ' ')
          .replace(/&quot;/g, '"')
          .replace(/https?:\/\/\S+/g, '')
          .trim();
        const firstLine = cleanDesc.split(/[\r\n]+/)[0]?.trim();
        if (firstLine && firstLine.length >= 3) {
          title = firstLine.length > 120 ? firstLine.substring(0, 117) + '...' : firstLine;
        } else if (cleanDesc.length >= 3) {
          title = cleanDesc.length > 120 ? cleanDesc.substring(0, 117) + '...' : cleanDesc;
        }
      }

      const isGenericThreadsTitle = !title || 
        title === 'Threads Post' ||
        title.toLowerCase().includes('log in') || 
        title.toLowerCase().includes('login') || 
        title.toLowerCase().includes('join threads') || 
        title.toLowerCase().includes('sign up');

      if (isGenericThreadsTitle) {
        title = (author && author !== 'Threads Creator') ? `Threads Video (${author})` : 'Threads Video';
      }

      const scMatch = (finalUrl || url).match(/post\/([a-zA-Z0-9_-]+)/) || url.match(/share\/([a-zA-Z0-9_-]+)/);
      const shortcode = scMatch ? scMatch[1] : '';

      const hasVideo = !!videoUrl;
      const formats = [];
      if (hasVideo) {
        formats.push({
          formatId: 'threads-best',
          ext: 'mp4',
          resolution: '1080x1920',
          height: 1080,
          width: 1920,
          vcodec: 'h264',
          acodec: 'aac',
          isAudioOnly: false,
          isVideoOnly: false,
          hasAudioAndVideo: true,
          qualityLabel: '1080p Full HD',
          url: videoUrl
        });
        formats.push({
          formatId: 'threads-720p',
          ext: 'mp4',
          resolution: '720x1280',
          height: 720,
          width: 1280,
          vcodec: 'h264',
          acodec: 'aac',
          isAudioOnly: false,
          isVideoOnly: false,
          hasAudioAndVideo: true,
          qualityLabel: '720p HD',
          url: videoUrl
        });
        formats.push({
          formatId: 'threads-audio',
          ext: 'mp3',
          isAudioOnly: true,
          isVideoOnly: false,
          hasAudioAndVideo: false,
          qualityLabel: 'Audio (MP3 320kbps)',
          url: videoUrl
        });
      } else if (ogImage) {
        formats.push({
          formatId: 'threads-image',
          ext: 'jpg',
          resolution: 'Original Photo',
          isAudioOnly: false,
          isVideoOnly: false,
          hasAudioAndVideo: false,
          qualityLabel: 'Original Photo (JPG)',
          url: ogImage
        });
      }

      return {
        id: shortcode || ('threads_' + Date.now()),
        url,
        directStreamUrl: videoUrl || ogImage,
        title,
        thumbnail,
        duration: hasVideo ? 30 : 0,
        uploader: author,
        channel: author,
        description: ogDesc,
        extractor: 'Threads',
        formats,
        availableResolutions: hasVideo ? [1080, 720] : [],
        hasAudio: hasVideo,
        hasVideo,
        hasImage: !hasVideo && !!ogImage,
        defaultProfile: {
          type: hasVideo ? 'video' : 'image',
          presetId: hasVideo ? 'best-available' : 'original-image',
          label: hasVideo ? 'Best Available Quality (Universal H.264)' : 'Original Photo (JPG)',
          container: hasVideo ? 'mp4' : 'jpg',
          remuxToMp4: hasVideo
        }
      };
    } catch (err) {
      logger.error('Threads analysis failed:', err);
      throw classifyError(err, 'Failed to analyze Threads media');
    }
  }

  async analyzeSpotify(url, timeoutMs = 35000) {
    if (this.isSpotifyPlaylistUrl(url)) {
      return await this.analyzePlaylist(url, timeoutMs);
    }
    logger.info(`Analyzing Spotify track: ${url}`);
    try {
      let trackTitle = '';
      let artist = '';
      let thumbnail = '';
      let durationSec = 0;
      const trackIdMatch = url.match(/track\/([a-zA-Z0-9]+)/);
      const trackId = trackIdMatch ? trackIdMatch[1] : '';

      // 1. Fetch Spotify SSR with bot crawler User-Agent (instant & reliable)
      try {
        const { body: ssrHtml, statusCode: ssrStatus } = await fetchHtml(url, {
          'User-Agent': 'facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)'
        });
        if (ssrStatus === 200) {
          const ogTitleMatch = ssrHtml.match(/<meta property=["']og:title["'] content=["']([^"']+)["']/i);
          const ogDescMatch = ssrHtml.match(/<meta property=["']og:description["'] content=["']([^"']+)["']/i);
          const ogImageMatch = ssrHtml.match(/<meta property=["']og:image["'] content=["']([^"']+)["']/i);
          const durationMatch = ssrHtml.match(/<meta property=["']music:duration["'] content=["']([^"']+)["']/i);

          if (ogTitleMatch && ogTitleMatch[1] && !ogTitleMatch[1].startsWith('Spotify')) {
            trackTitle = ogTitleMatch[1];
          }
          if (ogDescMatch && ogDescMatch[1]) {
            const parts = ogDescMatch[1].split('·').map(s => s.trim());
            if (parts.length > 0 && parts[0]) artist = parts[0];
          }
          if (ogImageMatch && ogImageMatch[1]) {
            thumbnail = ogImageMatch[1];
          }
          if (durationMatch && durationMatch[1]) {
            durationSec = parseInt(durationMatch[1], 10);
          }
        }
      } catch (ssrErr) {
        logger.warn('Spotify SSR scraper notice:', ssrErr);
      }

      // 2. Fetch Spotify Embed for artist and exact duration
      if (trackId) {
        try {
          const embedUrl = `https://open.spotify.com/embed/track/${trackId}`;
          const { body: embedHtml } = await fetchHtml(embedUrl);
          const nextDataMatch = embedHtml.match(/<script id="__NEXT_DATA__" type="application\/json">([\s\S]+?)<\/script>/);
          if (nextDataMatch) {
            const nextData = JSON.parse(nextDataMatch[1]);
            const entity = nextData.props?.pageProps?.state?.data?.entity;
            if (entity) {
              if (entity.name && (!trackTitle || trackTitle === 'Spotify Track')) {
                trackTitle = entity.name;
              }
              if (entity.artists && Array.isArray(entity.artists) && entity.artists.length > 0) {
                artist = entity.artists.map((a) => a.name).filter(Boolean).join(', ');
              }
              if (entity.duration) {
                durationSec = Math.round(entity.duration / 1000);
              }
              const coverImg = entity.visualIdentity?.image?.[1]?.url ||
                               entity.visualIdentity?.image?.[0]?.url ||
                               entity.coverArt?.sources?.[0]?.url;
              if (coverImg && (!thumbnail || thumbnail.includes('unsplash'))) {
                thumbnail = coverImg;
              }
            }
          }
        } catch (embErr) {
          logger.warn('Spotify embed parse notice:', embErr);
        }
      }

      // 3. Fallback to Spotify oEmbed
      if (!trackTitle) {
        try {
          const oembedUrl = `https://open.spotify.com/oembed?url=${encodeURIComponent(url)}`;
          const { body: oembedJson } = await fetchHtml(oembedUrl);
          const oembed = JSON.parse(oembedJson);
          if (oembed.title) trackTitle = oembed.title;
          if (oembed.thumbnail_url && !thumbnail) thumbnail = oembed.thumbnail_url;
        } catch (oeErr) {
          logger.warn('Spotify oembed notice:', oeErr);
        }
      }

      if (!trackTitle || trackTitle === 'Spotify Track') {
        throw new Error('This Spotify track could not be found, is region-locked, or has been removed from Spotify.');
      }
      if (!artist) artist = 'Spotify';
      if (!thumbnail) thumbnail = 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800';
      if (!durationSec) durationSec = 180;

      // 4. Search and pair YouTube high-fidelity audio stream
      const query = `ytsearch1:${trackTitle} ${artist} audio`.trim();
      logger.info(`Pairing Spotify track with YouTube stream query: ${query}`);
      const ytdlpPath = await dependencyManager.getYtDlpExecutablePath();
      const ytArgs = await youtubeTokenManager.getYtDlpExtractorArgs(url);
      const args = [
        '--dump-single-json',
        '--no-playlist',
        '--no-check-certificates',
        '--prefer-free-formats',
        ...ytArgs,
        '--add-header', 'User-Agent:Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        query
      ];

      let meta;
      try {
        const { stdout } = await execFileAsync(ytdlpPath, args, {
          windowsHide: true,
          timeout: Math.min(timeoutMs, 15000),
          maxBuffer: 30 * 1024 * 1024
        });
        const raw = JSON.parse(stdout);
        const entry = (raw.entries && raw.entries.length > 0) ? raw.entries[0] : raw;
        meta = this.parseYtDlpOutput(url, entry);
      } catch (ytSearchErr) {
        logger.warn('YouTube pairing search notice during Spotify analysis:', ytSearchErr.message);
        meta = {
          id: trackId || 'spotify_track',
          url,
          title: trackTitle,
          formats: [{
            format_id: 'audio_mp3_320',
            ext: 'mp3',
            resolution: 'audio only',
            note: 'MP3 320kbps High Quality Audio'
          }],
          duration: durationSec || 180,
          thumbnail
        };
      }

      meta.id = trackId || (meta.id || 'spotify_track');
      meta.url = url;
      meta.title = trackTitle;
      meta.thumbnail = thumbnail;
      meta.uploader = artist;
      meta.channel = artist;
      meta.extractor = 'Spotify';
      meta.platform = 'spotify';
      meta.isSpotify = true;
      meta.duration = durationSec > 0 ? durationSec : meta.duration;
      meta.downloadQuery = query;
      meta.downloadTarget = meta.webpage_url || query;
      delete meta.directStreamUrl;
      meta.defaultProfile = {
        type: 'audio',
        presetId: 'best-audio',
        label: 'Best Audio Quality (MP3 320kbps)',
        container: 'mp3'
      };

      return meta;
    } catch (err) {
      logger.error('Spotify analysis failed:', err);
      throw classifyError(err, 'Failed to analyze Spotify song');
    }
  }

  async analyzePinterest(url, timeoutMs = 35000) {
    logger.info(`Analyzing Pinterest URL: ${url}`);
    const targetUrl = await this.expandPinterestUrl(url);

    let title = '';
    let author = 'Pinterest Creator';
    let thumbnail = 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?w=800';
    let directImageUrl = '';
    let directVideoUrl = '';
    let durationSec = 0;
    let pinId = '';

    // Extract Pin ID
    const pinMat = targetUrl.match(/pin\/(?:[\w-]+--)?(\d+)/i);
    if (pinMat) {
      pinId = pinMat[1];
    } else {
      const numMat = targetUrl.match(/(\d{10,22})/);
      if (numMat) pinId = numMat[1];
    }

    // 1. Direct query to Pinterest official PinResource endpoint
    if (pinId) {
      try {
        const opts = { field_set_key: 'unauth_react_main_pin', id: pinId };
        const q = encodeURIComponent(JSON.stringify({ options: opts }));
        const apiUrl = `https://www.pinterest.com/resource/PinResource/get/?data=${q}`;
        const { body: apiBody, statusCode } = await fetchHtml(apiUrl, {
          'X-Pinterest-PWS-Handler': 'www/[username].js',
          'Accept': 'application/json, text/javascript, */*, q=0.01',
          'X-Requested-With': 'XMLHttpRequest',
          'Referer': 'https://www.pinterest.com/'
        });

        if (statusCode === 200 && apiBody) {
          const json = JSON.parse(apiBody);
          const data = json.resource_response?.data;
          if (data) {
            const parsedTitle = data.title || data.grid_title || data.closeup_unified_description || '';
            if (parsedTitle && parsedTitle.trim()) {
              title = parsedTitle.trim();
            }

            const pinner = data.pinner;
            if (pinner) {
              const pinnerName = pinner.full_name || pinner.username || '';
              if (pinnerName) author = pinnerName;
            }

            const images = data.images;
            const origImg = images?.orig?.url || images?.['736x']?.url || '';
            if (origImg) {
              directImageUrl = origImg;
              thumbnail = origImg;
            }

            // Check videos
            let vidList = data.videos?.video_list;
            if (!vidList && data.story_pin_data?.pages) {
              for (const page of data.story_pin_data.pages) {
                if (page.blocks) {
                  for (const blk of page.blocks) {
                    if (blk.video?.video_list) {
                      vidList = blk.video.video_list;
                      break;
                    }
                  }
                }
                if (vidList) break;
              }
            }

            if (vidList) {
              const preferredKeys = ['V_EXP7', 'V_720P', 'V_480P'];
              for (const pk of preferredKeys) {
                const vObj = vidList[pk];
                if (vObj?.url && vObj.url.includes('.mp4')) {
                  directVideoUrl = vObj.url;
                  if (vObj.duration) durationSec = Math.round(vObj.duration / 1000);
                  if (vObj.thumbnail) thumbnail = vObj.thumbnail;
                  break;
                }
              }
              if (!directVideoUrl) {
                for (const vk of Object.keys(vidList)) {
                  const vObj = vidList[vk];
                  if (vObj?.url && vObj.url.includes('.mp4')) {
                    directVideoUrl = vObj.url;
                    if (vObj.duration) durationSec = Math.round(vObj.duration / 1000);
                    if (vObj.thumbnail) thumbnail = vObj.thumbnail;
                    break;
                  }
                }
              }
            }
          }
        }
      } catch (apiErr) {
        logger.warn('[Analyzer] Pinterest PinResource query notice:', apiErr.message);
      }
    }

    // 2. Fallback HTML Scraping (if direct media or title missing)
    if (!directVideoUrl && !directImageUrl) {
      try {
        const { body: html } = await fetchHtml(targetUrl, {
          'Referer': 'https://www.google.com/'
        });
        const cleanHtml = html.replace(/\\\//g, '/').replace(/\\u002F/gi, '/').replace(/&amp;/g, '&');

        if (!title) {
          const ogTitleM = cleanHtml.match(/<meta\s+property=["']og:title["']\s+content=["'](.*?)["']/i) ||
                           cleanHtml.match(/<meta\s+content=["'](.*?)["']\s+property=["']og:title["']/i);
          if (ogTitleM && ogTitleM[1]) {
            title = ogTitleM[1].replace(/ \| Pinterest$/i, '').trim();
          } else {
            const pageTitleM = cleanHtml.match(/<title[^>]*>(.*?)<\/title>/i);
            if (pageTitleM && pageTitleM[1]) {
              title = pageTitleM[1].replace(/ \| Pinterest$/i, '').trim();
            }
          }
        }

        const vidPattern = /https?:\/\/[a-zA-Z0-9.-]*pinimg\.com\/videos\/[a-zA-Z0-9/_.-]+\.mp4/i;
        const vidM = cleanHtml.match(vidPattern);
        if (vidM) {
          directVideoUrl = vidM[0];
        } else {
          const ogvM = cleanHtml.match(/<meta\s+property=["']og:video(?::secure_url)?["']\s+content=["'](.*?)["']/i);
          if (ogvM && ogvM[1]) directVideoUrl = ogvM[1];
        }

        const imgPattern = /https:\/\/i\.pinimg\.com\/(?:originals|736x)\/[a-zA-Z0-9/_.-]+\.(?:jpg|png|webp|gif)/i;
        const imgM = cleanHtml.match(imgPattern);
        if (imgM) {
          directImageUrl = imgM[0];
          if (!thumbnail || thumbnail.includes('unsplash')) thumbnail = directImageUrl;
        } else {
          const ogImgM = cleanHtml.match(/<meta\s+property=["']og:image["']\s+content=["'](.*?)["']/i);
          if (ogImgM && ogImgM[1]) {
            directImageUrl = ogImgM[1];
            if (!thumbnail || thumbnail.includes('unsplash')) thumbnail = directImageUrl;
          }
        }
      } catch (htmlErr) {
        logger.warn('[Analyzer] Pinterest HTML fallback notice:', htmlErr.message);
      }
    }

    if (!title) {
      title = pinId ? `Pinterest Pin ${pinId}` : 'Pinterest Visual Media';
    }

    const isVideo = Boolean(directVideoUrl);
    const mediaStream = directVideoUrl || directImageUrl;

    const meta = {
      id: pinId || 'pinterest_pin',
      url: targetUrl,
      title: title,
      uploader: author,
      channel: author,
      thumbnail: thumbnail,
      duration: durationSec,
      extractor: 'pinterest',
      directStreamUrl: mediaStream,
      formats: isVideo ? [
        { formatId: 'best-video', label: 'Best Video (MP4)', ext: 'mp4', resolution: '1080p', type: 'video' },
        { formatId: 'best-audio', label: 'Audio Only (MP3)', ext: 'mp3', type: 'audio' }
      ] : [
        { formatId: 'original-image', label: 'High Resolution Photo', ext: 'jpg', type: 'image' }
      ],
      defaultProfile: isVideo ? {
        type: 'video',
        presetId: 'best-video',
        label: 'Best Video Quality',
        container: 'mp4'
      } : {
        type: 'image',
        presetId: 'original-image',
        label: 'Original Image',
        container: 'jpg'
      }
    };

    return meta;
  }

  isCloudStorageUrl(urlStr) {
    if (!this.isValidUrl(urlStr)) return false;
    const lower = urlStr.toLowerCase();
    if (lower.includes('/folders/') || lower.includes('folderview') || lower.includes('/scl/fo/')) return false;
    return lower.includes('drive.google.com') ||
           lower.includes('dropbox.com') ||
           lower.includes('1drv.ms') ||
           lower.includes('onedrive.live.com') ||
           lower.includes('sharepoint.com') ||
           /\.(mp4|mov|mkv|webm|avi|flv|m4v|mp3|wav|m4a|aac|flac|ogg|zip|rar|7z|tar|gz)(\?.*)?$/i.test(urlStr);
  }

  async analyzeCloudStorage(url, timeoutMs = 35000) {
    if (this.isPlaylistUrl(url)) {
      return await this.analyzePlaylist(url, timeoutMs);
    }
    logger.info(`Analyzing cloud storage / direct media URL: ${url}`);
    let directUrl = url;
    let title = 'Cloud Media';
    let isArchive = false;
    let isAudio = false;
    let isVideo = true;

    const lower = url.toLowerCase();
    if (lower.includes('drive.google.com')) {
      const driveMatch = url.match(/\/d\/([a-zA-Z0-9_-]+)/) || url.match(/id=([a-zA-Z0-9_-]+)/);
      if (driveMatch) {
        directUrl = `https://drive.google.com/uc?export=download&id=${driveMatch[1]}`;
        title = `Google Drive File (${driveMatch[1].substring(0, 8)})`;
      }
    } else if (lower.includes('dropbox.com')) {
      directUrl = url.replace('dl=0', 'dl=1');
      if (!directUrl.includes('dl=1')) {
        directUrl += (directUrl.includes('?') ? '&' : '?') + 'dl=1';
      }
      const nameMatch = url.match(/\/([^/?#]+)\?/);
      if (nameMatch) {
        try { title = decodeURIComponent(nameMatch[1]); } catch (_) {}
      }
    } else if (lower.includes('1drv.ms') || lower.includes('onedrive.live.com') || lower.includes('sharepoint.com')) {
      directUrl = url.includes('download=1') ? url : url + (url.includes('?') ? '&' : '?') + 'download=1';
      title = 'OneDrive File';
    } else {
      try {
        const u = new URL(url);
        const bname = path.basename(u.pathname);
        if (bname) title = decodeURIComponent(bname);
      } catch (_) {}
    }

    if (/\.(zip|rar|7z|tar|gz)(\?.*)?$/i.test(url) || /\.(zip|rar|7z|tar|gz)(\?.*)?$/i.test(directUrl)) {
      isArchive = true;
      isVideo = false;
      isAudio = false;
    } else if (/\.(mp3|wav|m4a|aac|flac|ogg)(\?.*)?$/i.test(url) || /\.(mp3|wav|m4a|aac|flac|ogg)(\?.*)?$/i.test(directUrl)) {
      isAudio = true;
      isVideo = false;
    }

    return {
      id: 'cloud_' + Date.now(),
      url: directUrl,
      directUrl: directUrl,
      directStreamUrl: directUrl,
      title: title,
      thumbnail: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800',
      duration: 0,
      uploader: 'Cloud Storage',
      channel: 'Cloud Storage',
      extractor: 'cloud',
      isArchive: isArchive,
      hasAudio: isAudio || isVideo,
      hasVideo: isVideo,
      availableResolutions: isVideo ? [1080, 720] : [],
      formats: isArchive ? [
        { format_id: 'archive_original', ext: 'zip', height: null, vcodec: 'none', acodec: 'none', url: directUrl }
      ] : (isVideo ? [
        { format_id: 'cloud_1080p', ext: 'mp4', height: 1080, vcodec: 'h264', acodec: 'aac', url: directUrl },
        { format_id: 'cloud_720p', ext: 'mp4', height: 720, vcodec: 'h264', acodec: 'aac', url: directUrl },
        { format_id: 'cloud_audio', ext: 'mp3', height: null, vcodec: 'none', acodec: 'mp3', url: directUrl }
      ] : [
        { format_id: 'cloud_audio', ext: 'mp3', height: null, vcodec: 'none', acodec: 'mp3', url: directUrl }
      ]),
      defaultProfile: isArchive ? {
        type: 'archive',
        presetId: 'original-archive',
        label: 'Original Archive (.zip)',
        container: 'zip'
      } : (isVideo ? {
        type: 'video',
        presetId: 'best-available',
        label: 'Direct Cloud Video (MP4)',
        container: 'mp4',
        remuxToMp4: true
      } : {
        type: 'audio',
        presetId: 'best-audio',
        label: 'Direct Audio Stream (MP3)',
        container: 'mp3'
      })
    };
  }

  async analyzeInstagram(url, timeoutMs = 25000) {
    logger.info(`Analyzing Instagram media with multi-slide/carousel extractor: ${url}`);
    // 1. Try Python with yt_dlp InstagramIE._real_extract
    try {
      const pyCode = `
import sys, json, yt_dlp
url = sys.argv[1]
ydl = yt_dlp.YoutubeDL({'quiet': True, 'no_warnings': True})
ie = yt_dlp.extractor.instagram.InstagramIE(ydl)
res = ie._real_extract(url)
t = res.get('_type')
title = res.get('title') or (res.get('description') or '')[:60] or 'Instagram Post'
uploader = res.get('uploader') or res.get('channel') or '@Instagram'
if t == 'playlist':
    entries = res.get('entries', [])
    slides = []
    for idx, e in enumerate(entries):
        formats = e.get('formats') or []
        vid_url = formats[-1].get('url') if formats else None
        thumbs = e.get('thumbnails') or []
        img_url = thumbs[-1].get('url') if thumbs else (e.get('thumbnail') or None)
        slide_url = vid_url or img_url
        if slide_url:
            slides.append({
                'index': idx + 1,
                'title': f"{title} (Slide {idx + 1})",
                'url': slide_url,
                'thumbnail': img_url or vid_url,
                'isVideo': bool(vid_url),
                'duration': e.get('duration') or 0
            })
    print(json.dumps({'type': 'playlist', 'title': title, 'uploader': uploader, 'itemCount': len(slides), 'items': slides}))
else:
    formats = res.get('formats') or []
    vid_url = formats[-1].get('url') if formats else None
    thumbs = res.get('thumbnails') or []
    img_url = thumbs[-1].get('url') if thumbs else res.get('thumbnail')
    print(json.dumps({'type': 'single', 'title': title, 'uploader': uploader, 'videoUrl': vid_url, 'photoUrl': img_url, 'thumbnail': img_url or vid_url, 'duration': res.get('duration') or 0}))
`.trim();

      const { stdout } = await execFileAsync('python', ['-c', pyCode, url], {
        windowsHide: true,
        timeout: timeoutMs,
        maxBuffer: 15 * 1024 * 1024
      });

      const parsed = JSON.parse(stdout.trim());
      if (parsed.type === 'playlist' && parsed.items && parsed.items.length > 0) {
        return {
          isPlaylist: true,
          isCarousel: true,
          url,
          title: parsed.title,
          uploader: parsed.uploader,
          itemCount: parsed.items.length,
          items: parsed.items.map((s) => ({
            url: s.url,
            title: s.title,
            thumbnail: s.thumbnail,
            duration: s.duration || 0,
            downloadQuery: s.url,
            uploader: parsed.uploader
          }))
        };
      } else if (parsed.photoUrl || parsed.videoUrl) {
        const isPhoto = !parsed.videoUrl;
        return {
          id: 'instagram_' + Date.now(),
          url,
          title: parsed.title,
          uploader: parsed.uploader,
          thumbnail: parsed.thumbnail,
          duration: parsed.duration || 0,
          formats: [
            {
              formatId: isPhoto ? 'photo_original' : 'video_original',
              ext: isPhoto ? 'jpg' : 'mp4',
              resolution: isPhoto ? 'Original High-Res Photo' : '1080p Full HD',
              url: parsed.videoUrl || parsed.photoUrl,
              isImage: isPhoto
            }
          ],
          isImage: isPhoto
        };
      }
    } catch (e) {
      logger.warn('[Instagram Carousel] Python extractor fallback failed:', e.message);
    }

    // 2. Fallback: Direct HTML / Embed scraping if Python is not installed or errored
    try {
      const shortcodeMatch = url.match(/(?:p|reel|tv)\/([a-zA-Z0-9_-]+)/);
      const shortcode = shortcodeMatch ? shortcodeMatch[1] : '';
      if (shortcode) {
        const embedUrl = `https://www.instagram.com/p/${shortcode}/embed/captioned/`;
        const { body } = await fetchHtml(embedUrl);
        const imgMat = body.match(/<img[^>]+class="[^"]*EmbeddedMediaImage[^"]*"[^>]+src="([^"]+)"/);
        const titleMat = body.match(/class="[^"]*Caption[^"]*"[^>]*>(.*?)<\/div>/s);
        const userMat = body.match(/class="[^"]*Username[^"]*"[^>]*>(.*?)<\/div>/s);
        const rawPhoto = imgMat ? imgMat[1].replace(/&amp;/g, '&') : '';
        const cap = titleMat ? titleMat[1].replace(/<[^>]+>/g, '').trim() : 'Instagram Post';
        const user = userMat ? userMat[1].replace(/<[^>]+>/g, '').trim() : 'Instagram';
        if (rawPhoto) {
          return {
            id: 'instagram_' + shortcode,
            url,
            title: cap,
            uploader: user,
            thumbnail: rawPhoto,
            duration: 0,
            formats: [{
              formatId: 'photo_embed',
              ext: 'jpg',
              resolution: 'Original Photo',
              url: rawPhoto,
              isImage: true
            }],
            isImage: true
          };
        }
      }
    } catch (embErr) {
      logger.warn('[Instagram Carousel] Embed fallback failed:', embErr.message);
    }

    throw new Error('Could not analyze Instagram carousel or photo post.');
  }

  async analyzeUrl(url, timeoutMs = 35000) {
    if (this.isPlaylistUrl(url)) {
      return await this.analyzePlaylist(url, timeoutMs);
    }
    if (this.isThreadsUrl(url)) {
      return await this.analyzeThreads(url, timeoutMs);
    }
    if (this.isSpotifyPlaylistUrl(url)) {
      return await this.analyzePlaylist(url, timeoutMs);
    }
    if (this.isSpotifyUrl(url)) {
      return await this.analyzeSpotify(url, timeoutMs);
    }
    if (this.isPinterestUrl(url)) {
      return await this.analyzePinterest(url, timeoutMs);
    }
    if (this.isCloudStorageUrl(url)) {
      return await this.analyzeCloudStorage(url, timeoutMs);
    }

    // Proactively check Instagram URLs for carousels / multi-slide posts
    if (url.includes('instagram.com/p/') || url.includes('instagram.com/reel/')) {
      try {
        const igResult = await this.analyzeInstagram(url, timeoutMs);
        if (igResult) return igResult;
      } catch (igErr) {
        logger.info(`Instagram custom handler deferred to yt-dlp: ${igErr.message}`);
      }
    }

    logger.info(`Analyzing URL with yt-dlp: ${url}`);
    const ytdlpPath = await dependencyManager.getYtDlpExecutablePath();
    const isMultiPost = url.includes('instagram.com') || url.includes('pinterest.com');
    const ytArgs = await youtubeTokenManager.getYtDlpExtractorArgs(url);
    const args = [
      '--dump-single-json',
      '--skip-download',
      '--no-warnings',
      ...(isMultiPost ? [] : ['--no-playlist']),
      '--no-check-certificates',
      '--match-filter', '!is_storyboard',
      ...ytArgs,
      '--add-header', 'User-Agent:Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
      url
    ];

    const localAppData = process.env.LOCALAPPDATA || (os.homedir ? path.join(os.homedir(), 'AppData', 'Local') : '');
    const cookiesFilePath = localAppData ? path.join(localAppData, 'MediaFetch', 'cookies.txt') : '';
    if (cookiesFilePath && fs.existsSync(cookiesFilePath) && fs.statSync(cookiesFilePath).size > 10) {
      args.push('--cookies', cookiesFilePath);
    } else {
      const cookiesBrowser = settingsManager.getSettings()?.engine?.cookiesBrowser || 'none';
      if (cookiesBrowser && cookiesBrowser !== 'none') {
        args.push('--cookies-from-browser', cookiesBrowser);
      }
    }

    try {
      const { stdout } = await execFileAsync(ytdlpPath, args, {
        windowsHide: true,
        timeout: timeoutMs,
        maxBuffer: 30 * 1024 * 1024
      });
      const raw = JSON.parse(stdout);
      return this.parseYtDlpOutput(url, raw);
    } catch (err) {
      // If yt-dlp failed because the Instagram post is a photo carousel with no video formats, fallback to Instagram handler
      if (url.includes('instagram.com') || (err && String(err).includes('No video formats found'))) {
        try {
          return await this.analyzeInstagram(url, timeoutMs);
        } catch (_) {}
      }
      logger.error('Metadata analysis failed:', err);
      throw classifyError(err, 'Failed to analyze media URL');
    }
  }

  resolveAuthenticTitle(raw, url) {
    let candidate = '';
    const isYouTube = (raw.extractor_key && raw.extractor_key.toLowerCase().includes('youtube')) || 
                      (raw.extractor && raw.extractor.toLowerCase().includes('youtube')) ||
                      (url && (url.includes('youtube.com') || url.includes('youtu.be')));
    
    const rawTitle = (raw.title || '').trim();
    const isGenericTitle = !rawTitle || 
      /^video by /i.test(rawTitle) || 
      /^post by /i.test(rawTitle) || 
      /^tweet by /i.test(rawTitle) || 
      /^tiktok video by /i.test(rawTitle) || 
      /^threads post by /i.test(rawTitle) || 
      /^photo by /i.test(rawTitle) || 
      /^media by /i.test(rawTitle) ||
      rawTitle.toLowerCase() === 'media' ||
      rawTitle.toLowerCase() === 'instagram' ||
      rawTitle.toLowerCase() === 'threads' ||
      rawTitle.toLowerCase() === 'twitter' ||
      rawTitle.toLowerCase() === 'tiktok' ||
      rawTitle.toLowerCase() === 'facebook' ||
      rawTitle.toLowerCase().includes('log in') ||
      rawTitle.toLowerCase().includes('login');

    if ((!isYouTube || isGenericTitle) && raw.description) {
      const lines = raw.description.split(/[\r\n]+/);
      for (let line of lines) {
        line = line.replace(/https?:\/\/\S+/g, '').replace(/[#@]\S+/g, '').trim();
        line = line.replace(/^["'“”‘]+|["'“”‘]+$/g, '').trim();
        if (line.length >= 3) {
          candidate = line;
          break;
        }
      }
      if (!candidate) {
        for (const line of lines) {
          const trimmed = line.trim();
          if (trimmed.length >= 3 && !trimmed.startsWith('http')) {
            candidate = trimmed;
            break;
          }
        }
      }
    }

    if (candidate) {
      if (candidate.length > 120) candidate = candidate.substring(0, 117).trim() + '...';
      return candidate;
    }
    if (raw.fulltitle && !isGenericTitle) return raw.fulltitle.trim();
    if (rawTitle && !isGenericTitle) return rawTitle;
    if (rawTitle && /^video by /i.test(rawTitle)) {
      const stripped = rawTitle.replace(/^video by /i, '').trim();
      if (stripped) return `Instagram Clip (${stripped})`;
    }
    if (raw.uploader) return `Media by ${raw.uploader}`;
    return 'Media';
  }

  parseYtDlpOutput(url, raw) {
    const formats = (raw.formats || []).map((f) => {
      const isAudioOnly = f.vcodec === 'none' && f.acodec !== 'none';
      const isVideoOnly = f.vcodec !== 'none' && f.acodec === 'none';
      const hasAudioAndVideo = f.vcodec !== 'none' && f.acodec !== 'none';
      let qualityLabel = '';
      if (f.height) {
        qualityLabel = `${f.height}p`;
        if (f.fps && f.fps > 30) qualityLabel += `${f.fps}`;
      } else if (f.abr) {
        qualityLabel = `${Math.round(f.abr)}kbps audio`;
      } else {
        qualityLabel = f.format_note || f.ext;
      }

      return {
        formatId: f.format_id,
        ext: f.ext,
        resolution: f.resolution || (f.height ? `${f.width || '?'}x${f.height}` : undefined),
        height: f.height,
        width: f.width,
        vcodec: f.vcodec,
        acodec: f.acodec,
        filesize: f.filesize,
        filesizeApprox: f.filesize_approx,
        fps: f.fps,
        tbr: f.tbr,
        vbr: f.vbr,
        abr: f.abr,
        isAudioOnly,
        isVideoOnly,
        hasAudioAndVideo,
        qualityLabel,
        protocol: f.protocol
      };
    });

    const heights = formats
      .map((f) => f.height)
      .filter((h) => typeof h === 'number' && h > 0 && h <= 2160); // Cap at 4K (2160p) - exclude 8K completely
    const availableResolutions = [...new Set(heights)].sort((a, b) => b - a);

    const hasAudio = formats.some((f) => f.acodec && f.acodec !== 'none');
    const hasVideo = formats.some((f) => f.vcodec && f.vcodec !== 'none');

    const meta = {
      id: raw.id || 'media',
      url,
      title: this.resolveAuthenticTitle(raw, url),
      thumbnail: (() => {
        let best = raw.thumbnail;
        if (Array.isArray(raw.thumbnails) && raw.thumbnails.length > 0) {
          const sorted = [...raw.thumbnails].sort((a, b) => ((b.width || 0) * (b.height || 0)) - ((a.width || 0) * (a.height || 0)));
          if (sorted[0]?.url) best = sorted[0].url;
        }
        if (raw.id && (raw.extractor_key === 'Youtube' || url.includes('youtu'))) {
          best = `https://i.ytimg.com/vi/${raw.id}/maxresdefault.jpg`;
        }
        return best || raw.thumbnails?.[0]?.url;
      })(),
      duration: raw.duration,
      uploader: raw.uploader || raw.channel || raw.creator,
      channel: raw.channel,
      description: raw.description ? raw.description.substring(0, 300) : undefined,
      extractor: raw.extractor_key || raw.extractor,
      formats,
      availableResolutions,
      hasAudio,
      hasVideo,
      defaultProfile: {
        type: 'video',
        presetId: 'best-available',
        label: 'Best Available Quality (Universal H.264)',
        container: 'mp4',
        remuxToMp4: true
      }
    };

    if (raw._type === 'playlist' || (raw.entries && Array.isArray(raw.entries) && raw.entries.length > 1)) {
      const entries = Array.isArray(raw.entries) ? raw.entries : [];
      meta.isPlaylist = true;
      meta.isCarousel = true;
      meta.itemCount = entries.length;
      meta.items = entries.map((entry, idx) => {
        const isEntryVideo = (entry.vcodec && entry.vcodec !== 'none') || (entry.formats && entry.formats.some((f) => f.vcodec && f.vcodec !== 'none'));
        const entryThumb = entry.thumbnail || entry.thumbnails?.[0]?.url || meta.thumbnail;
        const entryUrl = entry.url || entry.webpage_url || url;
        const entryTitle = entry.title || `${meta.title} (Slide ${idx + 1})`;
        return {
          id: entry.id || `slide_${idx + 1}`,
          title: entryTitle,
          thumbnail: entryThumb,
          duration: entry.duration || 0,
          url: entryUrl,
          downloadQuery: entryUrl,
          uploader: entry.uploader || meta.uploader || '@Instagram',
          mediaType: isEntryVideo ? 'video' : 'image',
          subFolderName: ''
        };
      });
      meta.carouselSlides = meta.items.map((item, idx) => ({
        index: idx + 1,
        id: item.id,
        mediaType: item.mediaType,
        label: `Slide ${idx + 1} • ${item.mediaType === 'video' ? 'Video' : 'Photo'}`,
        url: item.url,
        thumbnail: item.thumbnail,
        duration: item.duration
      }));
    }

    return meta;
  }

  getAvailableProfiles(metadata) {
    const profiles = [];
    if (metadata.hasVideo) {
      profiles.push({
        type: 'video',
        presetId: 'best-available',
        label: 'Best Available Quality (Universal H.264)',
        container: 'mp4',
        remuxToMp4: true
      });
      if (metadata.availableResolutions.includes(2160)) {
        profiles.push({ type: 'video', presetId: 'video-4k', label: '4K Ultra HD (2160p) • Studio Quality (Slower • Large File)', resolution: 2160, container: 'mp4', remuxToMp4: true });
      }
      if (metadata.availableResolutions.includes(1440)) {
        profiles.push({ type: 'video', presetId: 'video-1440p', label: '1440p Quad HD (2K) • High Quality (Moderate Speed)', resolution: 1440, container: 'mp4', remuxToMp4: true });
      }
      if (metadata.availableResolutions.includes(1080) || metadata.availableResolutions.some(r => r >= 1080)) {
        profiles.push({ type: 'video', presetId: 'video-1080p', label: '1080p Full HD • Recommended (Fast & Balanced)', resolution: 1080, container: 'mp4', remuxToMp4: true });
      }
      if (metadata.availableResolutions.includes(720) || metadata.availableResolutions.some(r => r >= 720)) {
        profiles.push({ type: 'video', presetId: 'video-720p', label: '720p HD • High Speed (Light File)', resolution: 720, container: 'mp4', remuxToMp4: true });
      }
      profiles.push({
        type: 'video',
        presetId: 'video-prores',
        label: 'Apple ProRes 422 HQ (Broadcast Master)',
        container: 'mov'
      });
    }

    if (metadata.hasAudio) {
      profiles.push({
        type: 'audio',
        presetId: 'best-audio',
        label: 'Best Audio Quality (MP3 320kbps)',
        container: 'mp3'
      });
      profiles.push({
        type: 'audio',
        presetId: 'audio-wav',
        label: 'Lossless Studio Audio (WAV 48kHz)',
        container: 'wav'
      });
    }

    return profiles;
  }
}

export const metadataAnalyzer = new MetadataAnalyzer();