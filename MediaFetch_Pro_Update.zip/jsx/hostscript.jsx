/**
 * MediaFetch & MediaSearch ExtendScript Host Bridge
 * Supports both Adobe Premiere Pro and Adobe After Effects
 */

var MediaFetchHost = (function () {
    if (typeof String.prototype.trim !== "function") {
        String.prototype.trim = function () {
            return this.replace(/^\s+|\s+$/g, "");
        };
    }

    function sanitizeFolderName(raw) {
        if (!raw) return "";
        var s = String(raw);
        var forbidden = ["\\", "/", ":", "\"", "*", "?", "<", ">", "|"];
        for (var i = 0; i < forbidden.length; i++) {
            while (s.indexOf(forbidden[i]) !== -1) {
                s = s.replace(forbidden[i], " ");
            }
        }
        return s.replace(/^\s+|\s+$/g, "");
    }

    function safeTrim(raw) {
        if (!raw) return "";
        return String(raw).replace(/^\s+|\s+$/g, "");
    }

    function isPremiere() {
        if (typeof BridgeTalk !== "undefined" && BridgeTalk.appName) {
            return BridgeTalk.appName.toLowerCase().indexOf("premiere") !== -1;
        }
        return (typeof app !== "undefined" && ((app.name && app.name.indexOf("Premiere") !== -1) || (app.project && typeof app.project.importFiles === "function")));
    }

    function isAfterEffects() {
        if (typeof BridgeTalk !== "undefined" && BridgeTalk.appName) {
            return BridgeTalk.appName.toLowerCase().indexOf("aftereffects") !== -1;
        }
        return (typeof app !== "undefined" && ((app.name && app.name.indexOf("After Effects") !== -1) || (typeof FolderItem !== "undefined")));
    }

    function getHostInfo() {
        var info = {
            appName: "Unknown",
            appVersion: "",
            projectOpen: false,
            projectName: "",
            projectPath: "",
            hasActiveTimeline: false
        };

        try {
            if (isPremiere()) {
                info.appName = "premierepro";
                info.appVersion = app.version || "";
                if (app.project) {
                    info.projectOpen = true;
                    var pName = app.project.name;
                    if (!pName && app.project.path) {
                        var pParts = app.project.path.replace(/\\/g, '/').split('/');
                        pName = pParts[pParts.length - 1];
                    }
                    info.projectName = pName || "Active Premiere Project";
                    info.projectPath = app.project.path || "";
                    info.hasActiveTimeline = !!(app.project.activeSequence);
                }
            } else if (isAfterEffects()) {
                info.appName = "aftereffects";
                info.appVersion = app.version || "";
                if (app.project) {
                    info.projectOpen = true;
                    if (app.project.file && app.project.file.exists) {
                        info.projectName = app.project.file.name;
                        info.projectPath = app.project.file.fsName;
                    } else {
                        info.projectName = "Active AE Project";
                        info.projectPath = "";
                    }
                    var activeItem = app.project.activeItem;
                    info.hasActiveTimeline = (activeItem && (activeItem instanceof CompItem));
                }
            }
        } catch (e) {
            info.error = e.toString();
        }

        return JSON.stringify(info);
    }

    function importFileToPremiere(filePath, insertAtPlayhead, optionsJson) {
        if (!app.project) return JSON.stringify({ success: false, error: "No active project in Premiere Pro." });

        var file = new File(filePath);
        if (!file.exists) {
            return JSON.stringify({ success: false, error: "File does not exist: " + filePath });
        }

        var opts = {};
        if (typeof optionsJson === "string" && optionsJson.length > 0) {
            try { opts = JSON.parse(optionsJson); } catch (_) {}
        } else if (typeof optionsJson === "object" && optionsJson !== null) {
            opts = optionsJson;
        }

        function getOrCreateBin(parentBin, binName) {
            if (!parentBin || !parentBin.children) return null;
            for (var i = 0; i < parentBin.children.numItems; i++) {
                var item = parentBin.children[i];
                if (item && item.type === 2 && item.name === binName) {
                    return item;
                }
            }
            return parentBin.createBin(binName);
        }

        var root = app.project.rootItem;
        var cleanPath = filePath.replace(/\\/g, '/');
        var isCustom = Boolean(opts.isCustomPath || opts.isCustom);
        var isCloud = Boolean(opts.isCloud || cleanPath.indexOf("Cloud Links") !== -1 || cleanPath.indexOf("Cloud") !== -1);
        var isPlaylist = Boolean(opts.isPlaylist || cleanPath.indexOf("Playlists") !== -1);
        var playlistTitle = sanitizeFolderName(opts.playlistTitle);
        var customFolderName = sanitizeFolderName(opts.customFolderName);
        var subFolderName = safeTrim(opts.subFolderName);

        var targetBin = null;

        if (isCustom) {
            // Custom folder selected: create root bin outside MediaFetch
            var rootBinName = customFolderName || (isPlaylist ? (playlistTitle || "Playlist") : (isCloud ? "Cloud Media" : ""));
            if (!rootBinName) {
                var pParts = cleanPath.split('/');
                rootBinName = pParts.length > 1 ? pParts[pParts.length - 2] : "Downloads";
            }
            var customRootBin = getOrCreateBin(root, rootBinName);
            if (subFolderName) {
                var sParts = subFolderName.replace(/\\/g, '/').split('/');
                var cur = customRootBin;
                for (var s = 0; s < sParts.length; s++) {
                    if (sParts[s] && sParts[s].length > 0) {
                        cur = getOrCreateBin(cur, sParts[s]);
                    }
                }
                targetBin = cur || customRootBin;
            } else {
                targetBin = customRootBin;
            }
        } else {
            // Default project folder: inside MediaFetch
            var mediaFetchBin = getOrCreateBin(root, "MediaFetch");

            if (isCloud) {
                var cloudRootBin = getOrCreateBin(mediaFetchBin || root, "Cloud Links");
                var cloudFolderBin = getOrCreateBin(cloudRootBin, customFolderName || "Cloud Media");
                if (subFolderName) {
                    var sParts2 = subFolderName.replace(/\\/g, '/').split('/');
                    var cur2 = cloudFolderBin;
                    for (var s2 = 0; s2 < sParts2.length; s2++) {
                        if (sParts2[s2] && sParts2[s2].length > 0) {
                            cur2 = getOrCreateBin(cur2, sParts2[s2]);
                        }
                    }
                    targetBin = cur2 || cloudFolderBin;
                } else {
                    targetBin = cloudFolderBin;
                }
            } else if (isPlaylist) {
                var playlistRootBin = getOrCreateBin(mediaFetchBin || root, "Playlists");
                var pName = playlistTitle || customFolderName || "Playlist 1";
                targetBin = getOrCreateBin(playlistRootBin, pName);
            } else {
                var isSearch = cleanPath.indexOf("SerachMediafetch") !== -1 || 
                               cleanPath.indexOf("MediaFetch Assets") !== -1 || 
                               cleanPath.indexOf("MediaSearch Assets") !== -1;
                var categoryBinName = isSearch ? "SerachMediafetch" : "LinkMediaFetch";
                var categoryBin = getOrCreateBin(mediaFetchBin || root, categoryBinName);

                var ext = cleanPath.split('.').pop().toLowerCase().split('?')[0];
                var isAudio = (ext === 'mp3' || ext === 'wav' || ext === 'm4a' || ext === 'flac' || ext === 'aac' || ext === 'ogg' || ext === 'opus' || ext === 'aiff');
                var isImage = (ext === 'jpg' || ext === 'jpeg' || ext === 'png' || ext === 'webp' || ext === 'gif' || ext === 'bmp' || ext === 'tiff' || ext === 'tif' || ext === 'svg');
                var typeBinName = isAudio ? "Audio" : (isImage ? "Image" : "Video");
                targetBin = getOrCreateBin(categoryBin || mediaFetchBin || root, typeBinName) || categoryBin || mediaFetchBin || root;
            }
        }

        // Import into project bin with resilient fallbacks
        var importTarget = targetBin || root;
        var nativePath = file.fsName;
        var imported = false;

        try {
            imported = app.project.importFiles([nativePath], true, importTarget, false);
        } catch (_) {}

        if (!imported) {
            try {
                imported = app.project.importFiles([filePath], true, importTarget, false);
            } catch (_) {}
        }

        if (!imported) {
            try {
                imported = app.project.importFiles([nativePath], true, root, false);
            } catch (_) {}
        }

        if (!imported) {
            try {
                imported = app.project.importFiles([filePath], true, root, false);
            } catch (_) {}
        }

        var isSingleLink = !isPlaylist && !isCloud && !Boolean(opts.isBatch);
        if (opts.isSingleLink !== undefined) {
            isSingleLink = Boolean(opts.isSingleLink);
        }
        if (!isSingleLink) {
            insertAtPlayhead = false;
        }

        var insertedToSeq = false;
        if (insertAtPlayhead) {
                var cleanNorm = filePath.replace(/\\/g, '/').replace(/^[\\\/]+\?[\\\/]+/, '').toLowerCase();
                var nativeNorm = nativePath.replace(/\\/g, '/').replace(/^[\\\/]+\?[\\\/]+/, '').toLowerCase();
                var fileNameOnly = "";
                try {
                    var lastSlash = Math.max(cleanNorm.lastIndexOf('/'), cleanNorm.lastIndexOf('\\'));
                    fileNameOnly = (lastSlash >= 0) ? cleanNorm.substring(lastSlash + 1) : cleanNorm;
                } catch (_) {}

                function findItemInBin(bin) {
                    if (!bin || !bin.children) return null;
                    for (var b = 0; b < bin.children.numItems; b++) {
                        var it = bin.children[b];
                        if (!it) continue;
                        if (it.type === 1) {
                            var p = it.getMediaPath ? it.getMediaPath() : "";
                            if (p) {
                                var pNorm = p.replace(/\\/g, '/').replace(/^[\\\/]+\?[\\\/]+/, '').toLowerCase();
                                if (pNorm === cleanNorm || pNorm === nativeNorm) {
                                    return it;
                                }
                            }
                            if (fileNameOnly && it.name && it.name.toLowerCase() === fileNameOnly) {
                                return it;
                            }
                        } else if (it.type === 2) {
                            var f = findItemInBin(it);
                            if (f) return f;
                        }
                    }
                    return null;
                }
                var targetItem = findItemInBin(importTarget) || findItemInBin(root);
                if (!targetItem && importTarget && importTarget.children && importTarget.children.numItems > 0) {
                    targetItem = importTarget.children[importTarget.children.numItems - 1];
                }
                if (targetItem) {
                    var seqName = targetItem.name || "MediaFetch Timeline";
                    var activeSeq = app.project.activeSequence;

                    function getTargetVideoTrack(seq, playheadTime) {
                        if (!seq || !seq.videoTracks || seq.videoTracks.numTracks === 0) return null;
                        var numTracks = seq.videoTracks.numTracks;
                        for (var t = 0; t < numTracks; t++) {
                            var trk = seq.videoTracks[t];
                            if (trk && trk.clips && trk.clips.numItems === 0) {
                                return trk;
                            }
                        }
                        var pSec = 0;
                        if (playheadTime) {
                            if (playheadTime.seconds !== undefined) pSec = playheadTime.seconds;
                            else pSec = parseFloat(playheadTime) || 0;
                        }
                        for (var t2 = numTracks - 1; t2 >= 0; t2--) {
                            var trk2 = seq.videoTracks[t2];
                            if (!trk2 || !trk2.clips) continue;
                            var collision = false;
                            for (var c = 0; c < trk2.clips.numItems; c++) {
                                var cl = trk2.clips[c];
                                if (cl && cl.start && cl.end) {
                                    if (cl.start.seconds <= pSec && cl.end.seconds > pSec) {
                                        collision = true;
                                        break;
                                    }
                                }
                            }
                            if (!collision) return trk2;
                        }
                        try {
                            if (typeof app.enableQE === "function") app.enableQE();
                            if (typeof qe !== "undefined" && qe.project) {
                                var qSeq = qe.project.getActiveSequence();
                                if (qSeq && typeof qSeq.addTracks === "function") {
                                    qSeq.addTracks(1, 0, 0, 0, 0);
                                    if (seq.videoTracks.numTracks > numTracks) {
                                        return seq.videoTracks[seq.videoTracks.numTracks - 1];
                                    }
                                }
                            }
                        } catch (_) {}
                        return seq.videoTracks[numTracks - 1];
                    }

                    function getTargetAudioTrack(seq, playheadTime) {
                        if (!seq || !seq.audioTracks || seq.audioTracks.numTracks === 0) return null;
                        var numTracks = seq.audioTracks.numTracks;
                        for (var t = 0; t < numTracks; t++) {
                            var trk = seq.audioTracks[t];
                            if (trk && trk.clips && trk.clips.numItems === 0) return trk;
                        }
                        var pSec = 0;
                        if (playheadTime) {
                            if (playheadTime.seconds !== undefined) pSec = playheadTime.seconds;
                            else pSec = parseFloat(playheadTime) || 0;
                        }
                        for (var t2 = numTracks - 1; t2 >= 0; t2--) {
                            var trk2 = seq.audioTracks[t2];
                            if (!trk2 || !trk2.clips) continue;
                            var collision = false;
                            for (var c = 0; c < trk2.clips.numItems; c++) {
                                var cl = trk2.clips[c];
                                if (cl && cl.start && cl.end) {
                                    if (cl.start.seconds <= pSec && cl.end.seconds > pSec) {
                                        collision = true;
                                        break;
                                    }
                                }
                            }
                            if (!collision) return trk2;
                        }
                        return seq.audioTracks[numTracks - 1];
                    }

                    // 1. Insert into active timeline if available on new/available track at playhead
                    if (activeSeq) {
                        try {
                            var playhead = activeSeq.getPlayerPosition();
                            if (isAudio) {
                                var aTrk = getTargetAudioTrack(activeSeq, playhead);
                                if (aTrk) {
                                    aTrk.insertClip(targetItem, playhead);
                                    insertedToSeq = true;
                                }
                            } else {
                                var vTrk = getTargetVideoTrack(activeSeq, playhead);
                                if (vTrk) {
                                    vTrk.insertClip(targetItem, playhead);
                                    insertedToSeq = true;
                                }
                            }
                        } catch (seqInsertErr) {}
                    }

                    // 2. If no active sequence, create from clip
                    if (!insertedToSeq) {
                        try {
                            if (typeof app.project.createNewSequenceFromClips === "function") {
                                var newSeq = app.project.createNewSequenceFromClips(seqName, [targetItem], targetBin || root);
                                if (newSeq) {
                                    insertedToSeq = true;
                                    if (app.project.openSequence) app.project.openSequence(newSeq.sequenceID);
                                }
                            }
                        } catch (_) {}
                    }

                    // 3. Generic sequence fallback
                    if (!insertedToSeq) {
                        try {
                            if (typeof app.project.createNewSequence === "function") {
                                app.project.createNewSequence(seqName, "");
                                var seq2 = app.project.activeSequence;
                                if (seq2) {
                                    if (isAudio && seq2.audioTracks && seq2.audioTracks.numTracks > 0) {
                                        seq2.audioTracks[0].insertClip(targetItem, "0");
                                        insertedToSeq = true;
                                    } else if (seq2.videoTracks && seq2.videoTracks.numTracks > 0) {
                                        seq2.videoTracks[0].insertClip(targetItem, "0");
                                        insertedToSeq = true;
                                    }
                                }
                            }
                        } catch (_) {}
                    }
                }
            } catch (prSeqErr) {}
        }

        return JSON.stringify({
            success: true,
            appName: "premierepro",
            imported: imported,
            insertedToSequence: insertedToSeq,
            filePath: filePath
        });
    }

    function importFileToAfterEffects(filePath, insertAtPlayhead, optionsJson) {
        if (!app.project) {
            try {
                app.newProject();
            } catch (pErr) {
                return JSON.stringify({ success: false, error: "No active project in After Effects. Please open or create a project first." });
            }
        }

        var cleanPath = filePath.replace(/\\/g, '/');
        var file = new File(cleanPath);
        if (!file.exists) {
            file = new File(filePath);
        }
        if (!file.exists) {
            file = new File(filePath.replace(/\//g, '\\'));
        }
        if (!file.exists) {
            return JSON.stringify({ success: false, error: "File does not exist: " + filePath });
        }

        var opts = {};
        if (typeof optionsJson === "string" && optionsJson.length > 0) {
            try { opts = JSON.parse(optionsJson); } catch (_) {}
        } else if (typeof optionsJson === "object" && optionsJson !== null) {
            opts = optionsJson;
        }

        app.beginUndoGroup("MediaFetch: Import Asset");

        try {
            function getOrCreateAeFolder(proj, parentFolder, folderName) {
                for (var i = 1; i <= proj.numItems; i++) {
                    var it = proj.item(i);
                    if (it && (it instanceof FolderItem || it.typeName === "Folder") && it.name === folderName) {
                        if (!parentFolder && (!it.parentFolder || it.parentFolder === proj.rootFolder)) {
                            return it;
                        }
                        if (parentFolder && it.parentFolder === parentFolder) {
                            return it;
                        }
                    }
                }
                var newFolder = proj.items.addFolder(folderName);
                if (parentFolder) {
                    newFolder.parentFolder = parentFolder;
                }
                return newFolder;
            }

            var proj = app.project;
            var cleanPath = filePath.replace(/\\/g, '/');
            var isCustom = Boolean(opts.isCustomPath || opts.isCustom);
            var isCloud = Boolean(opts.isCloud || cleanPath.indexOf("Cloud Links") !== -1 || cleanPath.indexOf("Cloud") !== -1);
            var isPlaylist = Boolean(opts.isPlaylist || cleanPath.indexOf("Playlists") !== -1);
            var playlistTitle = sanitizeFolderName(opts.playlistTitle);
            var customFolderName = sanitizeFolderName(opts.customFolderName);
            var subFolderName = safeTrim(opts.subFolderName);

            var targetFolder = null;

            if (isCustom) {
                // Custom folder selected: create root bin outside MediaFetch
                var rootBinName = customFolderName || (isPlaylist ? (playlistTitle || "Playlist") : (isCloud ? "Cloud Media" : ""));
                if (!rootBinName) {
                    var pParts = cleanPath.split('/');
                    rootBinName = pParts.length > 1 ? pParts[pParts.length - 2] : "Downloads";
                }
                var customRootFolder = getOrCreateAeFolder(proj, null, rootBinName);
                if (subFolderName) {
                    var sParts = subFolderName.replace(/\\/g, '/').split('/');
                    var cur = customRootFolder;
                    for (var s = 0; s < sParts.length; s++) {
                        if (sParts[s] && sParts[s].length > 0) {
                            cur = getOrCreateAeFolder(proj, cur, sParts[s]);
                        }
                    }
                    targetFolder = cur || customRootFolder;
                } else {
                    targetFolder = customRootFolder;
                }
            } else {
                // Default project folder: inside MediaFetch
                var mediaFetchFolder = getOrCreateAeFolder(proj, null, "MediaFetch");

                if (isCloud) {
                    var cloudRoot = getOrCreateAeFolder(proj, mediaFetchFolder, "Cloud Links");
                    var cloudFolder = getOrCreateAeFolder(proj, cloudRoot, customFolderName || "Cloud Media");
                    if (subFolderName) {
                        var sParts3 = subFolderName.replace(/\\/g, '/').split('/');
                        var cur3 = cloudFolder;
                        for (var s3 = 0; s3 < sParts3.length; s3++) {
                            if (sParts3[s3] && sParts3[s3].length > 0) {
                                cur3 = getOrCreateAeFolder(proj, cur3, sParts3[s3]);
                            }
                        }
                        targetFolder = cur3 || cloudFolder;
                    } else {
                        targetFolder = cloudFolder;
                    }
                } else if (isPlaylist) {
                    var playlistRoot = getOrCreateAeFolder(proj, mediaFetchFolder, "Playlists");
                    var pName = playlistTitle || customFolderName || "Playlist 1";
                    targetFolder = getOrCreateAeFolder(proj, playlistRoot, pName);
                } else {
                    var isSearch = cleanPath.indexOf("SerachMediafetch") !== -1 || 
                                   cleanPath.indexOf("MediaFetch Assets") !== -1 || 
                                   cleanPath.indexOf("MediaSearch Assets") !== -1;
                    var categoryFolderName = isSearch ? "SerachMediafetch" : "LinkMediaFetch";
                    var categoryFolder = getOrCreateAeFolder(proj, mediaFetchFolder, categoryFolderName);

                    var ext = cleanPath.split('.').pop().toLowerCase().split('?')[0];
                    var isAudio = (ext === 'mp3' || ext === 'wav' || ext === 'm4a' || ext === 'flac' || ext === 'aac' || ext === 'ogg' || ext === 'opus' || ext === 'aiff');
                    var isImage = (ext === 'jpg' || ext === 'jpeg' || ext === 'png' || ext === 'webp' || ext === 'gif' || ext === 'bmp' || ext === 'tiff' || ext === 'tif' || ext === 'svg');
                    var typeFolderName = isAudio ? "Audio" : (isImage ? "Image" : "Video");
                    targetFolder = getOrCreateAeFolder(proj, categoryFolder, typeFolderName) || categoryFolder || mediaFetchFolder;
                }
            }

            var importOptions = new ImportOptions(file);
            var footageItem = null;

            // Free fragmented image & frame cache buffers prior to importing high-res/4K footage
            try {
                if (typeof app.purge === "function" && typeof PurgeTarget !== "undefined" && PurgeTarget.IMAGE_CACHES) {
                    app.purge(PurgeTarget.IMAGE_CACHES);
                }
            } catch (pErr) {}

            try {
                footageItem = app.project.importFile(importOptions);
            } catch (impErr) {
                try {
                    footageItem = app.project.importFile(file);
                } catch (impErr2) {
                    app.endUndoGroup();
                    return JSON.stringify({
                        success: false,
                        error: "After Effects failed to import file (" + file.name + "): " + impErr.toString()
                    });
                }
            }
            if (footageItem && targetFolder) {
                try {
                    footageItem.parentFolder = targetFolder;
                } catch (_) {}
            }

            var isSingleLink = !isPlaylist && !isCloud && !Boolean(opts.isBatch);
            if (opts.isSingleLink !== undefined) {
                isSingleLink = Boolean(opts.isSingleLink);
            }
            if (!isSingleLink) {
                insertAtPlayhead = false;
            }

            var insertedToSeq = false;
            if (insertAtPlayhead && footageItem) {
                try {
                    var comp = app.project.activeItem;
                    if (!comp || !(comp instanceof CompItem)) {
                        for (var cIdx = 1; cIdx <= app.project.numItems; cIdx++) {
                            if (app.project.item(cIdx) instanceof CompItem) {
                                comp = app.project.item(cIdx);
                                break;
                            }
                        }
                    }
                    if (!comp || !(comp instanceof CompItem)) {
                        var w = (footageItem.width && footageItem.width > 0) ? footageItem.width : 1920;
                        var h = (footageItem.height && footageItem.height > 0) ? footageItem.height : 1080;
                        var dur = (footageItem.duration && footageItem.duration > 0) ? footageItem.duration : 30;
                        var fps = (footageItem.frameRate && footageItem.frameRate > 0) ? footageItem.frameRate : 30;
                        var rawName = footageItem.name || "MediaFetch Comp";
                        var dotIdx = rawName.lastIndexOf(".");
                        var cName = (dotIdx > 0) ? rawName.substring(0, dotIdx) : rawName;
                        comp = app.project.items.addComposition(cName, w, h, 1.0, dur, fps);
                    }
                    if (comp && comp instanceof CompItem) {
                        var playheadTime = (comp.time !== undefined && comp.time !== null) ? comp.time : 0;
                        var layer = comp.layers.add(footageItem);
                        if (layer) {
                            layer.startTime = playheadTime; // Always place video at the start where timeline indicator is!
                            layer.moveToBeginning(); // Always placed as the TOP NEW LAYER!
                            insertedToSeq = true;
                        }
                    }
                } catch (aeSeqErr) {}
            }

            // Clean up transient decoders and memory allocations after import
            try {
                if (typeof app.purge === "function" && typeof PurgeTarget !== "undefined" && PurgeTarget.IMAGE_CACHES) {
                    app.purge(PurgeTarget.IMAGE_CACHES);
                }
            } catch (pErr2) {}

            app.endUndoGroup();

            return JSON.stringify({
                success: true,
                appName: "aftereffects",
                insertedToSequence: insertedToSeq,
                filePath: filePath
            });
        } catch (e) {
            app.endUndoGroup();
            return JSON.stringify({ success: false, error: e.toString() });
        }
    }

    function selectDownloadFolder() {
        try {
            var f = Folder.selectDialog("Select MediaFetch Download Destination Folder");
            return f ? f.fsName : "";
        } catch (e) {
            return "";
        }
    }

    function importMedia(filePath, insertAtPlayhead, optionsJson) {
        try {
            if (isPremiere()) {
                return importFileToPremiere(filePath, insertAtPlayhead, optionsJson);
            } else if (isAfterEffects()) {
                return importFileToAfterEffects(filePath, insertAtPlayhead, optionsJson);
            } else {
                return JSON.stringify({ success: false, error: "Unsupported Adobe host application." });
            }
        } catch (err) {
            return JSON.stringify({ success: false, error: err.toString() });
        }
    }

    function importToTimeline(filePath, optionsJson) {
        return importMedia(filePath, true, optionsJson);
    }

    return {
        getHostInfo: getHostInfo,
        importMedia: importMedia,
        importToTimeline: importToTimeline,
        selectDownloadFolder: selectDownloadFolder
    };
})();

// Provide both namespaces for full backwards and forward compatibility
var MediaSearchHost = MediaFetchHost;
