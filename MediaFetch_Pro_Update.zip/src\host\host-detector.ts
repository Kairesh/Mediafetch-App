import { IHostAdapter } from './adapter-interface.js';
import { PremiereHostAdapter } from './premiere-adapter.js';
import { AfterEffectsHostAdapter } from './ae-adapter.js';
import { ProjectContext } from '../common/types.js';

export class StandaloneHostAdapter implements IHostAdapter {
  public async getProjectContext(): Promise<ProjectContext> {
    return {
      application: 'standalone',
      applicationVersion: '1.0.0',
      projectSaved: false
    };
  }

  public async revealInFinder(filePath: string): Promise<void> {
    console.log('Reveal in finder:', filePath);
  }

  public async openFile(filePath: string): Promise<void> {
    console.log('Open file:', filePath);
  }

  public async importToProject(filePath: string): Promise<boolean> {
    console.log('Import to project (standalone):', filePath);
    return false;
  }

  public getHostTheme(): 'dark' | 'light' | 'darkest' | 'lightest' {
    return 'dark';
  }

  public onThemeChanged(callback: (theme: string) => void): void {
    // No-op for standalone browser
  }
}

export function getHostAppId(): string {
  if (typeof window !== 'undefined') {
    if ((window as any).__adobe_cep__) {
      try {
        const raw = (window as any).__adobe_cep__.getHostEnvironment();
        const obj = typeof raw === 'string' ? JSON.parse(raw) : raw;
        const aid = ((obj && obj.appId) || '').toLowerCase();
        if (aid.includes('pr')) return 'ppro';
        if (aid.includes('ae') || aid.includes('fx')) return 'aeft';
      } catch (_) {}
    }
    if ((window as any).CSInterface) {
      try {
        const cs = new (window as any).CSInterface();
        const env = cs.getHostEnvironment();
        const aid = ((env && env.appId) || '').toLowerCase();
        if (aid.includes('pr')) return 'ppro';
        if (aid.includes('ae') || aid.includes('fx')) return 'aeft';
      } catch (_) {}
    }
    if ((window as any).__MF_HOST_ID__ && ((window as any).__MF_HOST_ID__ === 'ppro' || (window as any).__MF_HOST_ID__ === 'aeft')) {
      return (window as any).__MF_HOST_ID__;
    }
    if (typeof (window as any).hostAdapter !== 'undefined' && (window as any).hostAdapter && (window as any).hostAdapter.hostId) {
      return (window as any).hostAdapter.hostId;
    }
  }
  return '';
}

export function createHostAdapter(): IHostAdapter {
  let hostId = '';
  if (typeof window !== 'undefined') {
    if ((window as any).__adobe_cep__) {
      try {
        const rawEnv = (window as any).__adobe_cep__.getHostEnvironment();
        if (typeof rawEnv === 'string') {
          try {
            const parsed = JSON.parse(rawEnv);
            hostId = (parsed.appId || '').toLowerCase();
          } catch {}
        } else if (rawEnv && typeof rawEnv === 'object') {
          hostId = (rawEnv.appId || '').toLowerCase();
        }
        console.log('[HostDetector] Detected CEP host ID:', hostId);
      } catch (e) {
        console.warn('[HostDetector] Error reading CEP environment:', e);
      }
    }

    if (!hostId && (window as any).CSInterface) {
      try {
        const cs = new (window as any).CSInterface();
        const env = cs.getHostEnvironment();
        hostId = ((env && env.appId) || '').toLowerCase();
      } catch (_) {}
    }

    if (hostId.includes('pr') || hostId.includes('premiere')) {
      const adapter = new PremiereHostAdapter();
      (adapter as any).hostId = 'ppro';
      (window as any).__MF_HOST_ID__ = 'ppro';
      return adapter;
    } else if (hostId.includes('ae') || hostId.includes('fx') || hostId.includes('aftereffects')) {
      const adapter = new AfterEffectsHostAdapter();
      (adapter as any).hostId = 'aeft';
      (window as any).__MF_HOST_ID__ = 'aeft';
      return adapter;
    }

    if ((window as any).require) {
      try {
        const uxp = (window as any).require('uxp');
        const host = uxp?.host;
        const hostName = (host?.name || '').toLowerCase();
        if (hostName.includes('premiere') || hostName.includes('pr')) {
          const adapter = new PremiereHostAdapter();
          (adapter as any).hostId = 'ppro';
          (window as any).__MF_HOST_ID__ = 'ppro';
          return adapter;
        } else if (hostName.includes('aftereffects') || hostName.includes('ae') || hostName.includes('fx')) {
          const adapter = new AfterEffectsHostAdapter();
          (adapter as any).hostId = 'aeft';
          (window as any).__MF_HOST_ID__ = 'aeft';
          return adapter;
        }
      } catch {}
    }
  }

  const title = (typeof document !== 'undefined' && document.title ? document.title : '').toLowerCase();
  if (title.includes('ae') || title.includes('after effects')) {
    const fallbackAe = new AfterEffectsHostAdapter();
    (fallbackAe as any).hostId = 'aeft';
    (window as any).__MF_HOST_ID__ = 'aeft';
    return fallbackAe;
  }
  const fallbackPr = new PremiereHostAdapter();
  (fallbackPr as any).hostId = 'ppro';
  (window as any).__MF_HOST_ID__ = 'ppro';
  return fallbackPr;
}

export const hostAdapter = createHostAdapter();
