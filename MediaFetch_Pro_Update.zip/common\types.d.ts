export type ErrorCategory = 'NETWORK_ERROR' | 'UNSUPPORTED_URL' | 'AUTHENTICATION_REQUIRED' | 'FORMAT_UNAVAILABLE' | 'FFMPEG_ERROR' | 'PERMISSION_ERROR' | 'DISK_SPACE_ERROR' | 'ENGINE_ERROR' | 'UNKNOWN_ERROR';
export interface DownloadError {
    category: ErrorCategory;
    message: string;
    details?: string;
    isRetryable: boolean;
    code?: string;
    timestamp?: number;
}
export type QueueStatus = 'waiting' | 'analyzing' | 'downloading' | 'processing' | 'completed' | 'paused' | 'cancelled' | 'failed' | 'retrying';
export type PresetId = 'best-available' | 'best-mp4' | 'video-4k' | 'video-1440p' | 'video-1080p' | 'video-720p' | 'video-480p' | 'video-only' | 'best-audio' | 'audio-m4a' | 'audio-mp3' | 'audio-flac' | 'audio-only' | 'custom';
export interface DownloadProfile {
    type: 'video' | 'audio' | 'custom' | 'video-only' | 'image';
    presetId: PresetId | string;
    label: string;
    resolution?: number;
    container?: string;
    videoCodec?: string;
    audioCodec?: string;
    fps?: number;
    audioQuality?: string;
    customFormatId?: string;
    remuxToMp4?: boolean;
    customFilename?: string;
    timeRange?: { start?: string; end?: string };
    audioFx?: {
        vocalRemover?: boolean;
        bassBoost?: boolean;
        spatial8d?: boolean;
    };
}
export interface FormatOption {
    formatId: string;
    ext: string;
    resolution?: string;
    height?: number;
    width?: number;
    vcodec?: string;
    acodec?: string;
    filesize?: number;
    filesizeApprox?: number;
    fps?: number;
    tbr?: number;
    vbr?: number;
    abr?: number;
    isAudioOnly: boolean;
    isVideoOnly: boolean;
    hasAudioAndVideo: boolean;
    qualityLabel: string;
    protocol?: string;
}
export interface MediaMetadata {
    id: string;
    url: string;
    title: string;
    thumbnail?: string;
    duration?: number;
    uploader?: string;
    channel?: string;
    description?: string;
    extractor?: string;
    formats: FormatOption[];
    availableResolutions: number[];
    hasAudio: boolean;
    hasVideo: boolean;
    defaultProfile: DownloadProfile;
    carouselSlides?: Array<{
        slideIndex: number;
        url: string;
        thumbnail?: string;
        mediaType: 'image' | 'video';
    }>;
}
export interface DownloadItem {
    id: string;
    url: string;
    title: string;
    thumbnail?: string;
    duration?: number;
    profile: DownloadProfile;
    status: QueueStatus;
    progress: number;
    speed: string;
    eta: string;
    downloadedBytes: number;
    totalBytes: number;
    outputPath?: string;
    tempPath?: string;
    projectFolder?: string;
    targetFolder?: string;
    startTime?: number;
    completionTime?: number;
    error?: DownloadError;
    retryCount: number;
    maxRetries: number;
    stageDescription?: string;
}
export interface HistoryEntry {
    id: string;
    title: string;
    url: string;
    date: number;
    profileName: string;
    outputPath: string;
    fileSize: number;
    status: 'completed' | 'failed' | 'cancelled';
    duration?: number;
    thumbnail?: string;
}
export interface MediaFetchSettings {
    general: {
        theme: 'host' | 'dark' | 'light';
        notifications: boolean;
        confirmOverwrite: boolean;
        autoCleanupTemp: boolean;
    };
    downloads: {
        defaultPreset: PresetId;
        downloadLocationMode: 'project' | 'custom' | 'ask';
        customLocation: string;
        concurrency: number;
        maxRetries: number;
        retryDelayMs: number;
        filenamePattern: string;
    };
    engine: {
        autoUpdate: boolean;
        lastCheckedTime?: number;
        customYtDlpPath?: string;
        customFfmpegPath?: string;
    };
    advanced: {
        networkTimeoutMs: number;
        proxy?: string;
        rateLimit?: string;
        debugLogging: boolean;
    };
}
export interface SystemDiagnostics {
    version: string;
    os: string;
    arch: string;
    nodeVersion: string;
    adobeApp?: string;
    adobeVersion?: string;
    ytdlp: {
        available: boolean;
        version?: string;
        path?: string;
    };
    ffmpeg: {
        available: boolean;
        version?: string;
        path?: string;
    };
    ffprobe: {
        available: boolean;
        version?: string;
        path?: string;
    };
    diskSpace?: {
        freeBytes: number;
        totalBytes: number;
    };
    servicePort: number;
    uptime: number;
    activeDownloadsCount: number;
    queueLength: number;
}
export interface ProjectContext {
    application: 'premierepro' | 'aftereffects' | 'standalone';
    applicationVersion: string;
    projectSaved: boolean;
    projectName?: string;
    projectPath?: string;
    projectDirectory?: string;
}
