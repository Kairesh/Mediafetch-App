import { serviceClient } from './services/client.js';
import { hostAdapter } from '../host/host-detector.js';
import {
  DownloadItem,
  MediaMetadata,
  MediaFetchSettings,
  SystemDiagnostics,
  HistoryEntry,
  ProjectContext,
  DownloadProfile,
  PlaylistMetadata,
  PlaylistItem
} from '../common/types.js';
import { ServerMessage } from '../common/events.js';

export type AppMode = 'video-audio' | 'audio-only' | 'video-only' | 'image';

class MediaFetchApp {
  private projectContext: ProjectContext = {
    application: 'standalone',
    applicationVersion: '1.0.0',
    projectSaved: false
  };
  private currentMode: AppMode = 'video-audio';
  private currentMetadata: MediaMetadata | null = null;
  private currentPlaylist: PlaylistMetadata | null = null;
  private queue: DownloadItem[] = [];
  private settings: MediaFetchSettings | null = null;
  private history: HistoryEntry[] = [];
  private isAnalyzing = false;
  private analysisTimeout?: number;
  private pendingDownloadParams: any = null;
  private toastTimeout: any = null;
  private recentImportedPaths: Map<string, number> = new Map();
  private playlistCustomTargetDir: string = '';

  constructor() {
    this.init();
  }

  public async init() {
    this.bindDomEvents();
    this.setupTheme();
    this.setupServiceClient();
    this.updateDropdownsForMode(this.currentMode);
    this.updateProjectStatusUI();
    this.autoStartServiceIfInCep();
    serviceClient.connect();

    // Auto-focus input for instant typing/pasting
    setTimeout(() => {
      const urlInput = document.getElementById('url-input') as HTMLInputElement;
      urlInput?.focus();
    }, 100);

    // Refresh project context dynamically on window focus or action (never poll in background to avoid host lag)
    this.refreshProjectContext();
    window.addEventListener('focus', () => this.refreshProjectContext());
  }

  private async refreshProjectContext() {
    try {
      this.projectContext = await hostAdapter.getProjectContext();
      this.updateProjectStatusUI();
    } catch (e) {
      console.warn('Failed to resolve host project context:', e);
      this.updateProjectStatusUI();
    }
  }

  private autoStartServiceIfInCep() {
    try {
      if (typeof window === 'undefined') return;

      const nodeRequire = (window as any).require || (window as any).cep_node?.require || (typeof require !== 'undefined' ? require : null);
      let proc: any = null;
      try {
        proc = typeof process !== 'undefined' ? process : (nodeRequire ? nodeRequire('process') : null);
      } catch {}

      const appData = proc?.env?.APPDATA || '';
      const localAppData = proc?.env?.LOCALAPPDATA || '';

      // Determine extension path reliably from CEP or window.location
      let extDir = '';
      try {
        if ((window as any).__adobe_cep__?.getSystemPath) {
          extDir = (window as any).__adobe_cep__.getSystemPath('extension');
        } else if ((window as any).CSInterface) {
          extDir = new (window as any).CSInterface().getSystemPath('extension');
        }
      } catch {}

      if (!extDir && typeof window.location !== 'undefined' && window.location.pathname) {
        let p = window.location.pathname.replace(/^[\\\/]([A-Za-z]:)/, '$1');
        extDir = p.substring(0, Math.max(p.lastIndexOf('/'), p.lastIndexOf('\\')));
      }

      const candidatePaths = [
        extDir ? `${extDir}/service/server.bundle.js`.replace(/\//g, '\\') : '',
        extDir ? `${extDir}/service/server.js`.replace(/\//g, '\\') : '',
        appData ? `${appData}\\Adobe\\CEP\\extensions\\com.mediafetch.adobe.pro\\service\\server.bundle.js` : '',
        appData ? `${appData}\\Adobe\\CEP\\extensions\\com.mediafetch.adobe.pro\\service\\server.js` : '',
        appData ? `${appData}\\Adobe\\CEP\\extensions\\com.mediafetch.adobe\\service\\server.bundle.js` : '',
        appData ? `${appData}\\Adobe\\CEP\\extensions\\com.mediafetch.adobe\\service\\server.js` : '',
        localAppData ? `${localAppData}\\MediaFetchPro\\server.bundle.js` : '',
        localAppData ? `${localAppData}\\MediaFetchPro\\server.js` : ''
      ].filter(Boolean);

      const nodeExeCandidates = [
        'C:\\Program Files\\nodejs\\node.exe',
        'C:\\Program Files (x86)\\nodejs\\node.exe',
        'node'
      ];

      const startServiceScript = (scriptPath: string): boolean => {
        // 1. Try in-process require first if nodeRequire is available
        if (nodeRequire) {
          try {
            nodeRequire(scriptPath);
            console.log(`[MediaFetch Pro] In-process service started: ${scriptPath}`);
            setTimeout(() => serviceClient.connect(), 500);
            return true;
          } catch (e) {
            console.warn('[MediaFetch Pro] In-process require failed, trying spawn:', e);
          }

          // 2. Try child_process spawn
          try {
            const cp = nodeRequire('child_process');
            for (const nodeExe of nodeExeCandidates) {
              try {
                const child = cp.spawn(nodeExe, ['--max-old-space-size=48', '--optimize-for-size', scriptPath], {
                  detached: true,
                  stdio: 'ignore',
                  windowsHide: true,
                  env: { ...proc?.env, PORT: '48924' }
                });
                child.unref();
                console.log(`[MediaFetch Pro] Daemon spawned with ${nodeExe}: ${scriptPath}`);
                setTimeout(() => serviceClient.connect(), 800);
                return true;
              } catch {}
            }
          } catch {}
        }

        // 3. Fallback to Adobe CEP native createProcess
        if ((window as any).cep?.process?.createProcess) {
          try {
            for (const nodeExe of nodeExeCandidates) {
              const res = (window as any).cep.process.createProcess(nodeExe, scriptPath);
              if (res && res.err === 0) {
                console.log(`[MediaFetch Pro] CEP createProcess spawned daemon: ${nodeExe}`);
                setTimeout(() => serviceClient.connect(), 800);
                return true;
              }
            }
          } catch {}
        }
        return false;
      };

      // Check if service already responding on 48924
      if (nodeRequire) {
        try {
          const http = nodeRequire('http');
          const req = http.get('http://127.0.0.1:48924/health', (res: any) => {
            if (res.statusCode === 200) {
              console.log('[MediaFetch Pro] Service already running on port 48924.');
              serviceClient.connect();
            }
          });
          req.on('error', () => {
            for (const scriptPath of candidatePaths) {
              if (startServiceScript(scriptPath)) break;
            }
          });
          return;
        } catch {}
      }

      // If http check not possible or failed, start directly
      for (const scriptPath of candidatePaths) {
        if (startServiceScript(scriptPath)) break;
      }
    } catch (e) {
      console.warn('[MediaFetch] autoStartService error:', e);
    }
  }

  private setupTheme() {
    const applyTheme = (themeName: string) => {
      document.body.classList.remove('theme-light', 'theme-darkest');
      if (themeName === 'light' || themeName === 'lightest') {
        document.body.classList.add('theme-light');
      } else if (themeName === 'darkest') {
        document.body.classList.add('theme-darkest');
      }
    };

    hostAdapter.onThemeChanged((theme) => {
      if (this.settings?.general.theme === 'host') {
        applyTheme(theme);
      }
    });

    const initialHostTheme = hostAdapter.getHostTheme();
    applyTheme(initialHostTheme);
  }

  public showHeaderToast(message: string, durationMs: number = 6000) {
    const toast = document.getElementById('header-alert-toast');
    const textEl = document.getElementById('header-alert-text');
    if (!toast || !textEl) return;

    if (this.toastTimeout) {
      clearTimeout(this.toastTimeout);
      this.toastTimeout = null;
    }

    textEl.textContent = message;
    toast.style.display = 'flex';

    this.toastTimeout = setTimeout(() => {
      toast.style.display = 'none';
      this.toastTimeout = null;
    }, durationMs);
  }

  public dismissHeaderToast() {
    const toast = document.getElementById('header-alert-toast');
    if (toast) toast.style.display = 'none';
    if (this.toastTimeout) {
      clearTimeout(this.toastTimeout);
      this.toastTimeout = null;
    }
  }

  public dismissHeaderToastIf(keyword: string) {
    const textEl = document.getElementById('header-alert-text');
    if (textEl && textEl.textContent && textEl.textContent.includes(keyword)) {
      this.dismissHeaderToast();
    }
  }

  private pendingFolderCallback: ((folderPath: string) => void) | null = null;

  private selectFolderModern(callback: (folderPath: string) => void): void {
    // 1. Primary: Native Adobe CEP C++ file system dialog (modal to AE/PR, foreground, no console)
    try {
      const cepFs = (window as any).cep?.fs;
      if (cepFs && typeof cepFs.showOpenDialogEx === 'function') {
        const res = cepFs.showOpenDialogEx(false, true, 'Select MediaFetch Destination Folder', '', []);
        if (res && res.data && res.data.length > 0 && res.data[0]) {
          callback(res.data[0]);
          return;
        } else if (res && Array.isArray(res.data)) {
          // User explicitly cancelled dialog
          return;
        }
      }
      if (cepFs && typeof cepFs.showOpenDialog === 'function') {
        const res = cepFs.showOpenDialog(false, true, 'Select MediaFetch Destination Folder', '', []);
        if (res && res.data && res.data.length > 0 && res.data[0]) {
          callback(res.data[0]);
          return;
        } else if (res && Array.isArray(res.data)) {
          // User explicitly cancelled dialog
          return;
        }
      }
    } catch (e) {
      console.warn('[MediaFetch Pro] CEP showOpenDialog failed:', e);
    }

    // 2. Secondary: Host ExtendScript Folder.selectDialog
    try {
      if (this.csInterface && typeof this.csInterface.evalScript === 'function') {
        this.csInterface.evalScript('selectDownloadFolder()', (res: string) => {
          const cleaned = (res || '').trim();
          if (cleaned && cleaned !== 'undefined' && cleaned !== 'null' && cleaned !== 'false') {
            callback(cleaned);
          }
        });
        return;
      }
    } catch (e) {
      console.warn('[MediaFetch Pro] ExtendScript selectDownloadFolder failed:', e);
    }

    // 3. Fallback for non-CEP browser environment
    this.pendingFolderCallback = callback;
    serviceClient.openFolderDialog();
  }

  private updateProjectStatusUI() {
    const label = document.getElementById('project-status-label');
    const targetDirDisplay = document.getElementById('target-dir-display');

    if (!label) return;

    const pName = this.projectContext.projectName;
    const isSaved = this.projectContext.projectSaved && this.projectContext.projectDirectory;
    const appName = this.projectContext.application;

    if (pName && pName !== 'standalone' && pName !== 'Unknown') {
      label.textContent = `Project: ${pName}${isSaved ? '' : ' (Active)'}`;
      label.title = isSaved ? this.projectContext.projectDirectory! : 'Active Project - Downloads route to default MediaFetch folder';
      if (targetDirDisplay) {
        targetDirDisplay.textContent = isSaved 
          ? `Target: ${this.projectContext.projectDirectory}\\MediaFetch\\`
          : 'Target: Downloads\\MediaFetch\\';
      }
    } else if (isSaved) {
      label.textContent = `Project: ${this.projectContext.projectName || 'Active'}`;
      label.title = this.projectContext.projectDirectory;
      if (targetDirDisplay) {
        targetDirDisplay.textContent = `Target: ${this.projectContext.projectDirectory}\\MediaFetch\\`;
      }
    } else {
      const hostLabel = (appName && appName !== 'standalone') 
        ? `${appName === 'premierepro' ? 'Premiere Pro' : 'After Effects'} (Active)`
        : 'Active / Default Bin';
      label.textContent = `Project: ${hostLabel}`;
      label.title = 'Downloads saved to Downloads\\MediaFetch and auto-imported into host project';
      if (targetDirDisplay) {
        targetDirDisplay.textContent = 'Target: Downloads\\MediaFetch\\';
      }
    }
  }

  private checkUrlForPlatform(url: string) {
    const isSpotify = /spotify\.(?:com|link)/i.test(url);
    const videoAudioBtn = document.getElementById('mode-video-audio');
    const videoOnlyBtn = document.getElementById('mode-video-only');
    if (isSpotify) {
      if (videoAudioBtn) videoAudioBtn.style.display = 'none';
      if (videoOnlyBtn) videoOnlyBtn.style.display = 'none';
      if (this.currentMode === 'video-audio' || this.currentMode === 'video-only') {
        this.updateDropdownsForMode('audio-only');
      }
    } else {
      if (videoAudioBtn) videoAudioBtn.style.display = 'inline-flex';
      if (videoOnlyBtn) videoOnlyBtn.style.display = 'inline-flex';
    }
  }

  private updateDropdownsForMode(mode: AppMode) {
    this.currentMode = mode;

    // Synchronize active highlight on mode buttons
    document.querySelectorAll('.mode-icon-group .segment-icon-btn, .segment-btn[data-mode]').forEach((btn) => {
      const bMode = btn.getAttribute('data-mode');
      if (bMode === mode) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });



    // Dynamically update visual mode badge pill
    const badge = document.getElementById('current-mode-badge');
    if (badge) {
      if (mode === 'audio-only') {
        badge.textContent = '🎵 Audio Only';
        badge.style.background = '#8e44ad';
      } else if (mode === 'video-only') {
        badge.textContent = '📹 Video Only';
        badge.style.background = '#d35400';
      } else if (mode === 'image') {
        badge.textContent = '🖼️ Photo / Cover';
        badge.style.background = '#27ae60';
      } else {
        badge.textContent = '🎬 Video + Audio';
        badge.style.background = '#1473e6';
      }
    }

    const profileSelect = document.getElementById('profile-select') as HTMLSelectElement;
    const formatSelect = document.getElementById('format-select') as HTMLSelectElement;
    const formatGroup = document.getElementById('format-select-group') as HTMLElement;
    const formatLabel = document.getElementById('format-select-label') as HTMLElement;

    if (!profileSelect || !formatSelect) return;

    profileSelect.innerHTML = '';
    formatSelect.innerHTML = '';

    if (mode === 'image') {
      if (formatSelect) {
        formatSelect.disabled = false;
        formatSelect.title = '';
      }
      if (formatGroup) {
        formatGroup.style.opacity = '1';
        formatGroup.style.pointerEvents = 'auto';
      }
      if (formatLabel) formatLabel.textContent = 'Format / Container';

      // Photo / Cover Art Quality Options
      profileSelect.appendChild(new Option('🖼️ Original Thumbnail (Max Resolution / Ultra HD)', 'image-orig', true, true));
      profileSelect.appendChild(new Option('🖼️ Full HD Cover Art (1080p)', 'image-1080p'));
      profileSelect.appendChild(new Option('🖼️ WebP Cover Art (Compact)', 'image-webp'));
      profileSelect.appendChild(new Option('🖼️ Lossless PNG Cover Art', 'image-png'));

      // Image Format Containers
      formatSelect.appendChild(new Option('JPG Image', 'jpg', true, true));
      formatSelect.appendChild(new Option('PNG Image', 'png'));
      formatSelect.appendChild(new Option('WEBP Image', 'webp'));
    } else if (mode === 'audio-only') {
      // In Audio mode: lock and dull format dropdown - quality profile determines codec & bitrate!
      if (formatSelect) {
        formatSelect.disabled = true;
        formatSelect.title = 'Format is automatically determined by your selected Quality Profile.';
      }
      if (formatGroup) {
        formatGroup.style.opacity = '0.45';
        formatGroup.style.pointerEvents = 'none';
      }
      if (formatLabel) formatLabel.textContent = 'Format / Container (Auto-locked by Quality Profile)';

      // Audio Quality Options
      profileSelect.appendChild(new Option('🎵 Best Audio Quality (Auto)', 'best-audio', true, true));
      profileSelect.appendChild(new Option('🎵 MP3 Studio Master (320 kbps High Quality)', 'audio-mp3-320'));
      profileSelect.appendChild(new Option('🎵 MP3 Standard (192 kbps)', 'audio-mp3-192'));
      profileSelect.appendChild(new Option('🎵 MP3 Data Saver / Low Compressed (128 kbps)', 'audio-mp3-128'));
      profileSelect.appendChild(new Option('🎵 M4A (AAC 256 kbps)', 'audio-m4a'));
      profileSelect.appendChild(new Option('🎵 WAV (Uncompressed Studio Audio 1411 kbps)', 'audio-wav'));
      profileSelect.appendChild(new Option('🎵 FLAC (Lossless Audio)', 'audio-flac'));
      profileSelect.appendChild(new Option('🎵 Audio Only (Native Stream)', 'audio-only'));

      // Audio Format Containers (Mirror active profile)
      formatSelect.appendChild(new Option('MP3 (Auto from Profile)', 'mp3', true, true));
      formatSelect.appendChild(new Option('M4A (Auto from Profile)', 'm4a'));
      formatSelect.appendChild(new Option('WAV (Auto from Profile)', 'wav'));
      formatSelect.appendChild(new Option('FLAC (Auto from Profile)', 'flac'));

      profileSelect.onchange = () => {
        const pVal = profileSelect.value;
        if (pVal === 'audio-wav') formatSelect.value = 'wav';
        else if (pVal === 'audio-flac') formatSelect.value = 'flac';
        else if (pVal === 'audio-m4a') formatSelect.value = 'm4a';
        else formatSelect.value = 'mp3';
      };
    } else if (mode === 'video-only') {
      if (formatSelect) {
        formatSelect.disabled = false;
        formatSelect.title = '';
      }
      if (formatGroup) {
        formatGroup.style.opacity = '1';
        formatGroup.style.pointerEvents = 'auto';
      }
      if (formatLabel) formatLabel.textContent = 'Format / Container';

      // Video Only Options - Default to 1080p Full HD (Recommended)
      profileSelect.appendChild(new Option('📹 1080p Full HD (1080p) • Recommended (Fast & Balanced)', 'video-1080p', true, true));
      profileSelect.appendChild(new Option('📹 Best Video Only (Auto-Optimized)', 'video-only'));
      profileSelect.appendChild(new Option('📹 4K Ultra HD (2160p) • Studio Master (Slower • Largest File)', 'video-4k'));
      profileSelect.appendChild(new Option('📹 1440p Quad HD (2K) • High Quality (Moderate Speed)', 'video-1440p'));
      profileSelect.appendChild(new Option('📹 720p HD (720p) • Very Fast (Light File)', 'video-720p'));
      profileSelect.appendChild(new Option('📹 480p SD • Super Fast / Instant (Small File)', 'video-480p'));

      // Video Containers
      formatSelect.appendChild(new Option('MP4 (H.264 / AAC - Recommended for Adobe)', 'mp4', true, true));
      formatSelect.appendChild(new Option('MOV (QuickTime)', 'mov'));
      formatSelect.appendChild(new Option('MKV (Matroska)', 'mkv'));
      formatSelect.appendChild(new Option('WEBM (VP9 / Opus)', 'webm'));
    } else {
      if (formatSelect) {
        formatSelect.disabled = false;
        formatSelect.title = '';
      }
      if (formatGroup) {
        formatGroup.style.opacity = '1';
        formatGroup.style.pointerEvents = 'auto';
      }
      if (formatLabel) formatLabel.textContent = 'Format / Container';

      // Video + Audio (Default) - Default to 1080p Full HD (Recommended)
      profileSelect.appendChild(new Option('🎬 1080p Full HD (1080p) • Recommended (Fast & Balanced)', 'video-1080p', true, true));
      profileSelect.appendChild(new Option('🎬 Best Available Quality (Auto-Optimized)', 'best-available'));
      profileSelect.appendChild(new Option('🎬 4K Ultra HD (2160p) • Studio Master (Slower • Largest File)', 'video-4k'));
      profileSelect.appendChild(new Option('🎬 1440p Quad HD (2K) • High Quality (Moderate Speed)', 'video-1440p'));
      profileSelect.appendChild(new Option('🎬 720p HD (720p) • Very Fast (Light File)', 'video-720p'));
      profileSelect.appendChild(new Option('🎬 480p SD • Super Fast / Instant (Small File)', 'video-480p'));

      // Video Containers
      formatSelect.appendChild(new Option('MP4 (H.264 / AAC - Recommended for Adobe)', 'mp4', true, true));
      formatSelect.appendChild(new Option('MOV (Apple ProRes / QuickTime)', 'mov'));
      formatSelect.appendChild(new Option('MKV (Matroska)', 'mkv'));
      formatSelect.appendChild(new Option('WEBM (VP9 / Opus)', 'webm'));
    }
  }

  private setupServiceClient() {
    serviceClient.onStatusChanged((online) => {
      const dot = document.getElementById('connection-dot');
      if (dot) {
        dot.className = `connection-dot ${online ? 'online' : 'offline'}`;
        dot.title = online ? 'MediaFetch Pro service connected (Port 48924)' : 'Service offline (Click Diagnostics to check)';
      }
    });

    serviceClient.subscribe((msg: ServerMessage) => {
      switch (msg.type) {
        case 'ANALYSIS_STARTED':
          this.setAnalysisLoading(true);
          break;

        case 'ANALYSIS_SUCCESS':
        case 'METADATA_RESULT' as any:
          this.setAnalysisLoading(false);
          if (msg.payload?.isPlaylist || msg.payload?.isCarousel) {
            this.renderPlaylistModal(msg.payload);
          } else {
            this.renderMediaCard(msg.payload);
          }
          break;

        case 'ANALYSIS_ERROR':
        case 'ANALYSIS_FAILED' as any:
          this.setAnalysisLoading(false);
          this.showUrlError(`${msg.payload.error || 'Media analysis failed'} (${msg.payload.category || 'ERROR'})`);
          break;

        case 'PLAYLIST_ANALYSIS_SUCCESS':
        case 'PLAYLIST_METADATA_RESULT' as any:
          this.setAnalysisLoading(false);
          this.renderPlaylistModal(msg.payload);
          break;

        case 'PLAYLIST_ANALYSIS_ERROR':
        case 'PLAYLIST_ANALYSIS_FAILED' as any:
          this.setAnalysisLoading(false);
          this.showUrlError(`Playlist extraction failed: ${msg.payload.error}`);
          break;

        case 'QUEUE_UPDATED':
          this.queue = msg.payload;
          this.renderQueue();
          break;

        case 'DOWNLOAD_PROGRESS': {
          const idx = this.queue.findIndex((i) => i.id === msg.payload.id);
          if (idx >= 0) {
            this.queue[idx] = msg.payload.item;
            this.updateQueueItemDOM(msg.payload.item);
          }
          break;
        }

        case 'DOWNLOAD_COMPLETED': {
          const itemEdition = msg.payload.item?.edition || msg.payload.historyEntry?.edition;
          const isPro = (window as any).__MF_EDITION__ === 'pro' || window.location.pathname.includes('.pro') || document.title.includes('Pro');
          const myEdition = isPro ? 'pro' : 'standard';
          if (itemEdition && itemEdition !== myEdition) {
            // Ignore download events belonging to the other edition!
            break;
          }

          const idx = this.queue.findIndex((i) => i.id === msg.payload.id);
          if (idx >= 0) {
            this.queue[idx] = msg.payload.item;
            this.updateQueueItemDOM(msg.payload.item);
          }

          // Auto-import into Adobe Project Bin / Workspace / Timeline
          const targetFilePath = msg.payload.item?.outputPath || msg.payload.item?.downloadedPath || msg.payload.historyEntry?.outputPath;
          const mainAutoImportChk = document.getElementById('main-auto-import-chk') as HTMLInputElement;
          const mainAutoTimelineChk = document.getElementById('main-auto-timeline-chk') as HTMLInputElement;
          const autoImportEnabled = mainAutoImportChk ? mainAutoImportChk.checked : (this.settings?.general?.autoImportToProject ?? true);
          const autoTimelineEnabled = mainAutoTimelineChk ? mainAutoTimelineChk.checked : false;
          const isZip = Boolean(msg.payload.item?.zipPackage || msg.payload.item?.metadata?.zipPackage);
          const itemAutoImport = !isZip && msg.payload.item?.autoImport !== false && msg.payload.item?.metadata?.autoImport !== false;

          if (targetFilePath && (autoImportEnabled || autoTimelineEnabled) && itemAutoImport) {
            const now = Date.now();
            const lastImportTime = this.recentImportedPaths.get(targetFilePath) || 0;
            if (now - lastImportTime < 5000) {
              console.log('[MediaFetch] Skipping duplicate auto-import for recently imported file:', targetFilePath);
              break;
            }
            this.recentImportedPaths.set(targetFilePath, now);

            const item = msg.payload.item;
            const isCustomLocation = (this.settings?.downloads?.downloadLocationMode === 'custom') || Boolean(item?.targetDirectory);
            const isCloud = Boolean(item?.isCloud || item?.metadata?.isCloud || item?.customFolderName?.toLowerCase().includes('cloud') || item?.metadata?.uploader?.toLowerCase().includes('cloud'));
            const isPlaylist = Boolean(item?.isPlaylist || item?.metadata?.isPlaylist || item?.playlistTitle);
            const isBatch = Boolean(item?.isBatch || item?.metadata?.isBatch);
            const isSingleLink = !isPlaylist && !isCloud && !isBatch;
            const playlistTitle = item?.playlistTitle || item?.metadata?.playlistTitle || '';
            const customFolderName = item?.customFolderName || item?.metadata?.customFolderName || '';
            const subFolderName = item?.subFolderName || item?.metadata?.subFolderName || '';

            console.log('[MediaFetch] Triggering auto-import into Adobe project bin / timeline:', targetFilePath, { isCustomLocation, isCloud, isPlaylist, isSingleLink, playlistTitle, customFolderName, subFolderName, autoTimelineEnabled });
            hostAdapter.importToProject(targetFilePath, {
              isCustomPath: isCustomLocation,
              isCloud,
              isPlaylist,
              isSingleLink,
              playlistTitle,
              customFolderName,
              subFolderName,
              insertToTimeline: autoTimelineEnabled && isSingleLink
            })
              .then((success) => {
                console.log('[MediaFetch] Auto-import completed with status:', success);
              })
              .catch((err) => {
                console.warn('[MediaFetch] Auto-import error:', err);
              });
          }
          break;
        }

        case 'DOWNLOAD_FAILED': {
          const idx = this.queue.findIndex((i) => i.id === msg.payload.id);
          if (idx >= 0) {
            this.queue[idx] = msg.payload.item;
            this.updateQueueItemDOM(msg.payload.item);
          }
          break;
        }

        case 'SETTINGS_LOADED':
          this.settings = msg.payload;
          this.populateSettingsForm(msg.payload);
          break;

        case 'DIAGNOSTICS_RESULT':
          this.renderDiagnostics(msg.payload);
          this.updateSetupWizardStatus(msg.payload);
          break;

        case 'HISTORY_LOADED':
          this.history = msg.payload;
          this.renderHistoryList();
          break;

        case 'DUPLICATE_CHECK_RESULT':
          if (msg.payload.exists && this.pendingDownloadParams) {
            this.showDuplicateModal(msg.payload.existingFilePath || '');
          } else if (this.pendingDownloadParams) {
            this.executePendingDownload();
          }
          break;

        case 'DEPENDENCY_INSTALL_PROGRESS':
          this.showInstallProgress(msg.payload);
          break;

        case 'DEPENDENCY_INSTALL_RESULT':
          this.handleInstallResult(msg.payload);
          break;

        case 'ZIP_PACKAGE_COMPLETED' as any: {
          const zipPath = (msg as any).payload?.zipPath || (msg as any).zipPath;
          if (zipPath) {
            const fileName = zipPath.split(/[\\\/]/).pop();
            this.showHeaderToast(`📦 ZIP Archive created: ${fileName}`, 7000);
          }
          break;
        }

        case 'FOLDER_SELECTED' as any: {
          const folder = (msg as any).payload?.folderPath;
          if (folder && this.pendingFolderCallback) {
            this.pendingFolderCallback(folder);
            this.pendingFolderCallback = null;
          }
          break;
        }
      }
    });
  }

  private bindDomEvents() {
    const urlInput = document.getElementById('url-input') as HTMLInputElement;

    // URL Input Change & Platform Detection
    const onUrlChanged = (val: string) => {
      const trimmed = (val || '').trim();
      // If user typed/pasted a new URL that doesn't match the currently analyzed metadata, invalidate it immediately
      if (this.currentMetadata && this.currentMetadata.url !== trimmed && (this.currentMetadata as any).webpage_url !== trimmed) {
        this.currentMetadata = null;
        const cardSection = document.getElementById('media-card-section');
        if (cardSection) cardSection.style.display = 'none';
      }
      this.checkUrlForPlatform(trimmed);
    };
    urlInput?.addEventListener('input', (e) => onUrlChanged((e.target as HTMLInputElement).value));
    urlInput?.addEventListener('paste', () => setTimeout(() => onUrlChanged(urlInput?.value || ''), 50));

    // Mode Buttons Switching
    document.querySelectorAll('.mode-icon-group .segment-icon-btn, .segment-btn[data-mode]').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        document.querySelectorAll('.mode-icon-group .segment-icon-btn, .segment-btn[data-mode]').forEach((b) => b.classList.remove('active'));
        const target = e.currentTarget as HTMLElement;
        target.classList.add('active');
        const mode = (target.getAttribute('data-mode') || 'video-audio') as AppMode;
        this.updateDropdownsForMode(mode);
      });
    });

    // Format selection auto-sync (if user picks MP4/video container, auto-switch to video mode)
    const cardFormatSelect = document.getElementById('format-select') as HTMLSelectElement;
    cardFormatSelect?.addEventListener('change', () => {
      const val = (cardFormatSelect.value || '').toLowerCase();
      if (['mp4', 'mov', 'mkv', 'webm'].includes(val)) {
        if (this.currentMode === 'audio-only') {
          this.updateDropdownsForMode('video-audio');
        }
      } else if (['mp3', 'wav', 'm4a', 'flac'].includes(val)) {
        if (this.currentMode === 'video-audio' || this.currentMode === 'video-only') {
          this.updateDropdownsForMode('audio-only');
        }
      }
    });

    // Profile select listener: Displays helpful speed notice when 4K Studio quality is selected
    const cardProfileSelect = document.getElementById('profile-select') as HTMLSelectElement;
    cardProfileSelect?.addEventListener('change', () => {
      const pVal = cardProfileSelect.value || '';
      const is4K = pVal === 'res-2160' || pVal === 'video-4k' || pVal.includes('2160');
      if (is4K) {
        this.showHeaderToast(
          '⚡ 4K Ultra HD selected: Studio quality master. Note: 4K files take a bit longer to download and optimize.',
          4500
        );
      } else {
        this.dismissHeaderToastIf('4K');
      }
    });

    // Header notice banner dismiss button
    document.getElementById('btn-close-header-alert')?.addEventListener('click', () => {
      this.dismissHeaderToast();
    });

    // Timeline Checkbox Notice Listener
    const mainTimelineChk = document.getElementById('main-auto-timeline-chk') as HTMLInputElement;
    if (mainTimelineChk) {
      mainTimelineChk.addEventListener('change', () => {
        if (mainTimelineChk.checked) {
          const mainProjChk = document.getElementById('main-auto-import-chk') as HTMLInputElement;
          if (mainProjChk && !mainProjChk.checked) {
            mainProjChk.checked = true;
          }
          this.showHeaderToast(
            '⚡ Auto-Timeline: Files will import directly into your active timeline/top layer. Import may cause a brief pause.',
            6000
          );
        } else {
          this.dismissHeaderToastIf('Auto-Timeline');
        }
      });
    }

    // Download Location Mode Toggle Listener (Project vs Custom Folder)
    document.getElementById('setting-location-mode')?.addEventListener('change', () => {
      this.updateDownloadLocationModeUI();
    });

    // Folder Browse Picker
    document.getElementById('btn-browse-custom-location')?.addEventListener('click', () => {
      const modeSel = document.getElementById('setting-location-mode') as HTMLSelectElement;
      if (modeSel && modeSel.value !== 'custom') {
        modeSel.value = 'custom';
        this.updateDownloadLocationModeUI();
      }
      this.selectFolderModern((folderPath: string) => {
        const input = document.getElementById('setting-custom-location') as HTMLInputElement;
        if (input) input.value = folderPath;
        if (modeSel) modeSel.value = 'custom';
        this.updateDownloadLocationModeUI();
      });
    });

    // Main Panel Target Folder Clickable Browser
    document.getElementById('target-dir-display')?.addEventListener('click', () => {
      this.selectFolderModern((folderPath: string) => {
        serviceClient.updateSettings({
          downloads: {
            ...this.settings?.downloads,
            downloadLocationMode: 'custom',
            customLocation: folderPath
          } as any
        });
        const targetDirDisplay = document.getElementById('target-dir-display');
        if (targetDirDisplay) {
          targetDirDisplay.textContent = `Target: ${folderPath}`;
        }
        const customLocInput = document.getElementById('setting-custom-location') as HTMLInputElement;
        if (customLocInput) customLocInput.value = folderPath;
        const modeSel = document.getElementById('setting-location-mode') as HTMLSelectElement;
        if (modeSel) modeSel.value = 'custom';
        this.updateDownloadLocationModeUI();
      });
    });

    // URL Analyze Action
    document.getElementById('btn-analyze')?.addEventListener('click', () => this.handleAnalyze());
    urlInput?.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        this.handleAnalyze();
      }
    });

    // Paste Buttons (Both Bar and Header)
    document.getElementById('btn-paste')?.addEventListener('click', async () => {
      await this.handlePasteAction();
      onUrlChanged(urlInput?.value || '');
    });
    document.getElementById('btn-paste-url')?.addEventListener('click', async () => {
      await this.handlePasteAction();
      onUrlChanged(urlInput?.value || '');
    });

    // Close Media Card
    document.getElementById('btn-close-card')?.addEventListener('click', () => {
      const card = document.getElementById('media-card-section');
      if (card) card.style.display = 'none';
      this.currentMetadata = null;
    });

    // Direct Download Action Button
    document.getElementById('btn-download-action')?.addEventListener('click', async () => {
      await this.refreshProjectContext();
      this.handleDownloadClick();
    });

    // Queue Action Buttons
    document.getElementById('btn-pause-all')?.addEventListener('click', () => {
      for (const item of this.queue) {
        if (item.status === 'downloading' || item.status === 'waiting') {
          serviceClient.pauseDownload(item.id);
        }
      }
      serviceClient.send({ type: 'PAUSE_DOWNLOAD', payload: {} as any });
    });

    document.getElementById('btn-resume-all')?.addEventListener('click', () => {
      let count = 0;
      for (const item of this.queue) {
        if (item.status === 'paused' || item.status === 'failed' || item.status === 'downloading') {
          serviceClient.resumeDownload(item.id);
          count++;
        }
      }
      // Always broadcast fallback resume signal to daemon so any orphaned queue items resume
      serviceClient.send({ type: 'RESUME_DOWNLOAD', payload: {} as any });
    });

    document.getElementById('btn-clear-completed')?.addEventListener('click', () => {
      serviceClient.clearCompleted();
      this.queue = this.queue.filter((i) => i.status === 'downloading' || i.status === 'waiting');
      this.renderQueue();
    });

    // Queue Item Event Delegation (Bulletproof click capture for Pause, Resume, Cancel, Retry, Reveal, Import)
    const queueContainer = document.getElementById('queue-container');
    queueContainer?.addEventListener('click', (e) => {
      const btn = (e.target as HTMLElement).closest('button');
      if (!btn) return;
      const itemEl = btn.closest('.queue-item');
      const itemId = itemEl?.id?.replace('q-item-', '');
      if (!itemId) return;

      if (btn.classList.contains('btn-pause')) {
        serviceClient.pauseDownload(itemId);
      } else if (btn.classList.contains('btn-resume')) {
        serviceClient.resumeDownload(itemId);
      } else if (btn.classList.contains('btn-cancel')) {
        serviceClient.cancelDownload(itemId);
        // Optimistically remove from view immediately so card disappears instantly
        this.queue = this.queue.filter((i) => i.id !== itemId);
        this.renderQueue();
      } else if (btn.classList.contains('btn-retry')) {
        serviceClient.retryDownload(itemId);
      } else if (btn.classList.contains('btn-reveal')) {
        const item = this.queue.find((i) => i.id === itemId);
        if (item?.outputPath) hostAdapter.revealInFinder(item.outputPath);
      } else if (btn.classList.contains('btn-import')) {
        const item = this.queue.find((i) => i.id === itemId);
        if (item?.outputPath) {
          const isCustomLocation = (this.settings?.downloads?.downloadLocationMode === 'custom') || Boolean(item?.targetDirectory);
          const isCloud = Boolean(item?.isCloud || item?.metadata?.isCloud || item?.customFolderName?.toLowerCase().includes('cloud') || item?.metadata?.uploader?.toLowerCase().includes('cloud'));
          const isPlaylist = Boolean(item?.isPlaylist || item?.metadata?.isPlaylist || item?.playlistTitle);
          const isBatch = Boolean(item?.isBatch || item?.metadata?.isBatch);
          const isSingleLink = !isPlaylist && !isCloud && !isBatch;
          const autoTimelineEnabled = (document.getElementById('main-auto-timeline-chk') as HTMLInputElement)?.checked || false;
          hostAdapter.importToProject(item.outputPath, {
            isCustomPath: isCustomLocation,
            isCloud,
            isPlaylist,
            isSingleLink,
            playlistTitle: item?.playlistTitle || item?.metadata?.playlistTitle || '',
            customFolderName: item?.customFolderName || item?.metadata?.customFolderName || '',
            subFolderName: item?.subFolderName || item?.metadata?.subFolderName || '',
            insertToTimeline: autoTimelineEnabled && isSingleLink
          });
        }
      }
    });

    // Modal Triggers
    const openUnifiedSettings = () => {
      serviceClient.getSettings();
      serviceClient.getDiagnostics();
      if (typeof (window as any).Settings !== 'undefined') {
        const s = (window as any).Settings.load();
        const pexelsInput = document.getElementById('setting-studio-pexels-key') as HTMLInputElement;
        const pixabayInput = document.getElementById('setting-studio-pixabay-key') as HTMLInputElement;
        const unsplashInput = document.getElementById('setting-studio-unsplash-key') as HTMLInputElement;
        const giphyInput = document.getElementById('setting-studio-giphy-key') as HTMLInputElement;
        const timelineCheck = document.getElementById('setting-studio-auto-timeline') as HTMLInputElement;
        if (pexelsInput) pexelsInput.value = s.pexelsApiKey || '';
        if (pixabayInput) pixabayInput.value = s.pixabayApiKey || '';
        if (unsplashInput) unsplashInput.value = s.unsplashApiKey || '';
        if (giphyInput) giphyInput.value = s.giphyApiKey || '';
        if (timelineCheck) timelineCheck.checked = s.autoInsertTimeline !== false;
      }
      if (typeof (window as any).MediaFetchLicense?.updateBadge === 'function') {
        (window as any).MediaFetchLicense.updateBadge();
      }
      this.openModal('modal-settings');
    };

    document.getElementById('btn-top-settings')?.addEventListener('click', openUnifiedSettings);
    document.getElementById('btn-settings')?.addEventListener('click', openUnifiedSettings);

    document.getElementById('btn-history')?.addEventListener('click', () => {
      serviceClient.getHistory();
      this.openModal('modal-history');
    });

    document.getElementById('btn-diagnostics')?.addEventListener('click', () => {
      serviceClient.getDiagnostics();
      this.openModal('modal-diagnostics');
    });

    document.getElementById('btn-setup-wizard-trigger')?.addEventListener('click', () => {
      this.closeModal('modal-diagnostics');
      this.openModal('modal-setup');
      serviceClient.runSystemCheck();
    });

    // Modal Close Buttons
    document.querySelectorAll('.modal-close-btn').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        const overlay = (e.target as HTMLElement).closest('.modal-overlay');
        if (overlay) overlay.classList.remove('active');
      });
    });

    const modalApiGuide = document.getElementById('modal-api-guide');
    const btnOpenApiGuide = document.getElementById('btn-open-api-guide');
    const btnCloseApiGuide = document.getElementById('btn-close-api-guide');
    const btnDoneApiGuide = document.getElementById('btn-done-api-guide');

    const closeApiGuide = () => {
      if (modalApiGuide) {
        modalApiGuide.style.display = 'none';
        modalApiGuide.classList.remove('active');
      }
    };

    btnOpenApiGuide?.addEventListener('click', () => {
      if (modalApiGuide) {
        modalApiGuide.style.display = 'flex';
        modalApiGuide.classList.add('active');
      }
    });
    btnCloseApiGuide?.addEventListener('click', closeApiGuide);
    btnDoneApiGuide?.addEventListener('click', closeApiGuide);

    document.querySelectorAll('.btn-api-external-link').forEach((linkBtn) => {
      linkBtn.addEventListener('click', (e) => {
        const u = (e.currentTarget as HTMLElement).getAttribute('data-url');
        if (u) {
          if ((window as any).__adobe_cep__ && typeof (window as any).__adobe_cep__.openURLInDefaultBrowser === 'function') {
            (window as any).__adobe_cep__.openURLInDefaultBrowser(u);
          } else if ((window as any).cep?.util?.openURLInDefaultBrowser) {
            (window as any).cep.util.openURLInDefaultBrowser(u);
          } else {
            window.open(u, '_blank');
          }
        }
      });
    });

    // Settings Tabs
    document.querySelectorAll('.tab-btn').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        const targetTab = (e.currentTarget as HTMLElement).getAttribute('data-tab');
        document.querySelectorAll('.tab-btn').forEach((b) => b.classList.remove('active'));
        document.querySelectorAll('.tab-pane').forEach((p) => ((p as HTMLElement).style.display = 'none'));

        (e.currentTarget as HTMLElement).classList.add('active');
        if (targetTab) {
          const pane = document.getElementById(targetTab);
          if (pane) pane.style.display = 'block';
        }
      });
    });

    // Save Settings
    document.getElementById('btn-save-settings')?.addEventListener('click', () => {
      this.saveSettingsFromForm();
      this.closeModal('modal-settings');
    });

    // Update yt-dlp Engine
    document.getElementById('btn-update-ytdlp')?.addEventListener('click', () => {
      const btn = document.getElementById('btn-update-ytdlp') as HTMLButtonElement;
      const statusEl = document.getElementById('engine-update-status');
      if (btn) {
        btn.disabled = true;
        btn.textContent = '⏳ Checking for updates...';
      }
      if (statusEl) {
        statusEl.style.display = 'block';
        statusEl.style.color = 'var(--text-secondary, #aaa)';
        statusEl.textContent = 'Connecting to official yt-dlp repository...';
      }
      serviceClient.updateYtDlp();
    });

    // Setup Wizard Actions
    document.getElementById('btn-setup-install-all')?.addEventListener('click', () => {
      const progRow = document.getElementById('setup-progress-row');
      if (progRow) progRow.style.display = 'flex';
      serviceClient.installDependency('all');
    });

    // Duplicate Modal Actions
    document.getElementById('btn-dup-cancel')?.addEventListener('click', () => {
      this.pendingDownloadParams = null;
      this.closeModal('modal-duplicate');
    });

    document.getElementById('btn-dup-use-existing')?.addEventListener('click', () => {
      this.pendingDownloadParams = null;
      this.closeModal('modal-duplicate');
    });

    document.getElementById('btn-dup-download-new')?.addEventListener('click', () => {
      this.closeModal('modal-duplicate');
      this.executePendingDownload();
    });

    // Playlist Modal Actions
    document.getElementById('btn-playlist-select-all')?.addEventListener('click', () => {
      document.querySelectorAll('.playlist-checkbox').forEach((cb) => ((cb as HTMLInputElement).checked = true));
      this.updatePlaylistSelectedCount();
    });

    document.getElementById('btn-playlist-deselect-all')?.addEventListener('click', () => {
      document.querySelectorAll('.playlist-checkbox').forEach((cb) => ((cb as HTMLInputElement).checked = false));
      this.updatePlaylistSelectedCount();
    });

    document.querySelectorAll('input[name="playlist-mode"]').forEach((r) => {
      r.addEventListener('change', (e) => {
        const val = (e.target as HTMLInputElement).value;
        const wrapper = document.getElementById('playlist-items-wrapper');
        if (wrapper) {
          wrapper.style.display = val === 'selected' ? 'block' : 'none';
        }
        if (val === 'all') {
          document.querySelectorAll('.playlist-checkbox').forEach((cb) => ((cb as HTMLInputElement).checked = true));
        }
        this.updatePlaylistSelectedCount();
      });
    });

    document.getElementById('btn-playlist-confirm-download')?.addEventListener('click', () => {
      this.handlePlaylistDownloadSubmit();
    });

    // Playlist Destination Folder Browser
    document.getElementById('btn-playlist-browse-folder')?.addEventListener('click', () => {
      this.selectFolderModern((folderPath: string) => {
        this.playlistCustomTargetDir = folderPath;
        const pathEl = document.getElementById('playlist-destination-path');
        if (pathEl) pathEl.textContent = folderPath;
      });
    });

    // ZIP vs Auto-import synchronization (Images / videos cannot be auto-imported as .zip)
    const zipCb = document.getElementById('playlist-zip-package-cb') as HTMLInputElement | null;
    const autoImportCb = document.getElementById('playlist-auto-import-cb') as HTMLInputElement | null;
    const autoImportLabel = autoImportCb?.closest('label') as HTMLElement | null;

    zipCb?.addEventListener('change', () => {
      if (zipCb.checked) {
        if (autoImportCb) {
          autoImportCb.checked = false;
          autoImportCb.disabled = true;
        }
        if (autoImportLabel) {
          autoImportLabel.style.opacity = '0.45';
          autoImportLabel.title = 'Auto-import is disabled when packaging as ZIP archive';
        }
      } else {
        if (autoImportCb) {
          autoImportCb.disabled = false;
        }
        if (autoImportLabel) {
          autoImportLabel.style.opacity = '1';
          autoImportLabel.title = '';
        }
      }
    });

    autoImportCb?.addEventListener('change', () => {
      if (autoImportCb.checked && zipCb) {
        zipCb.checked = false;
      }
    });

    // Link Downloader Video/Audio Preview Trigger
    document.getElementById('btn-link-preview-play')?.addEventListener('click', (e) => {
      e.stopPropagation();
      this.openMediaPreview(this.currentMetadata);
    });
    document.getElementById('link-downloader-thumb-box')?.addEventListener('click', () => {
      this.openMediaPreview(this.currentMetadata);
    });
    document.getElementById('btn-close-media-preview')?.addEventListener('click', () => {
      this.closeMediaPreview();
    });

    // Trim Accordion Toggle
    const toggleTrimBtn = document.getElementById('btn-toggle-trim');
    if (toggleTrimBtn) {
      toggleTrimBtn.onclick = (e) => {
        if (typeof (window as any).toggleTrimPanel === 'function') {
          (window as any).toggleTrimPanel(e);
        }
      };
    }

    // Modal Background Clicks
    document.querySelectorAll('.modal-overlay').forEach((overlay) => {
      overlay.addEventListener('click', (e) => {
        if (e.target === overlay) {
          const id = (overlay as HTMLElement).id;
          if (id === 'modal-media-preview') {
            this.closeMediaPreview();
          } else {
            this.closeModal(id);
          }
        }
      });
    });

    // History Actions
    document.getElementById('btn-clear-history')?.addEventListener('click', () => {
      serviceClient.clearHistory();
    });

    // History Search
    document.getElementById('history-search-input')?.addEventListener('input', (e) => {
      const query = (e.target as HTMLInputElement).value;
      this.renderHistoryList(query);
    });
  }

  private closeCard() {
    const card = document.getElementById('media-card-section');
    if (card) card.style.display = 'none';
    this.currentMetadata = null;
  }

  private async handlePasteAction() {
    const urlInput = document.getElementById('url-input') as HTMLInputElement;
    if (!urlInput) return;

    try {
      if (navigator.clipboard && navigator.clipboard.readText) {
        const text = await navigator.clipboard.readText();
        if (text && text.trim().length > 0) {
          urlInput.value = text.trim();
          this.hideUrlError();
          return;
        }
      }
    } catch {}

    try {
      urlInput.focus();
      urlInput.select();
      const success = document.execCommand('paste');
      if (success && urlInput.value) {
        this.hideUrlError();
        return;
      }
    } catch {}

    urlInput.focus();
    this.showUrlError('Press Ctrl+V to paste into the URL box.');
  }

  private isPlaylistUrl(url: string): boolean {
    const lower = (url || '').toLowerCase();
    return lower.includes('list=') || 
           lower.includes('/playlist') || 
           lower.includes('/sets/') || 
           lower.includes('/album/') || 
           (lower.includes('spotify.') && (lower.includes('/playlist/') || lower.includes('/album/') || lower.includes('/artist/'))) ||
           lower.includes('drive.google.com/drive/folders/') ||
           lower.includes('drive.google.com/drive/u/') ||
           lower.includes('drive.google.com/folderview') ||
           (lower.includes('dropbox.com') && (lower.includes('/scl/fo/') || lower.includes('/sh/') || lower.includes('/folder/'))) ||
           lower.includes('1drv.ms') ||
           lower.includes('onedrive.live.com') ||
           lower.includes('sharepoint.com') ||
           lower.includes('box.com/s/') ||
           lower.includes('box.com/folder/') ||
           lower.includes('mega.nz/folder/') ||
           lower.includes('mega.nz/#f!') ||
           (lower.includes('pinterest.') && lower.includes('/boards/')) ||
           lower.includes('instagram.com/p/') ||
           lower.includes('instagram.com/reel/') ||
           lower.includes('instagram.com/reels/') ||
           lower.includes('instagram.com/stories/');
  }

  private handleAnalyze() {
    const input = document.getElementById('url-input') as HTMLInputElement;
    const url = input?.value?.trim();
    this.hideUrlError();

    if (!url) {
      this.showUrlError('Please enter or paste a valid media URL.');
      return;
    }

    this.setAnalysisLoading(true);

    if (this.analysisTimeout) clearTimeout(this.analysisTimeout);
    this.analysisTimeout = window.setTimeout(() => {
      if (this.isAnalyzing) {
        this.setAnalysisLoading(false);
        this.showUrlError('Analysis timed out. You can still click Download to Project directly.');
      }
    }, 60000);

    if (this.isPlaylistUrl(url)) {
      serviceClient.analyzePlaylist(url);
      return;
    }

    serviceClient.analyzeUrl(url);
  }

  private setAnalysisLoading(loading: boolean) {
    this.isAnalyzing = loading;
    if (!loading && this.analysisTimeout) {
      clearTimeout(this.analysisTimeout);
      this.analysisTimeout = undefined;
    }
    const btn = document.getElementById('btn-analyze') as HTMLButtonElement;
    const text = document.getElementById('analyze-btn-text');
    if (btn) {
      btn.disabled = loading;
    }
    if (text) {
      text.textContent = loading ? 'Analyzing…' : '🔍 Analyze';
    }
  }

  private showUrlError(msg: string) {
    const el = document.getElementById('url-error-msg');
    if (el) {
      el.textContent = msg;
      el.style.display = 'block';
    }
  }

  private hideUrlError() {
    const el = document.getElementById('url-error-msg');
    if (el) {
      el.style.display = 'none';
      el.textContent = '';
    }
  }

  private renderMediaCard(meta: MediaMetadata) {
    this.currentMetadata = meta;
    const cardSection = document.getElementById('media-card-section');
    if (!cardSection) return;

    cardSection.style.display = 'block';

    const titleEl = document.getElementById('media-card-title');
    const uploaderEl = document.getElementById('media-uploader-name');
    const extractorEl = document.getElementById('media-extractor-tag');
    const thumbImg = document.getElementById('media-thumb-img') as HTMLImageElement;
    const durationTag = document.getElementById('media-duration-tag');
    const resTag = document.getElementById('media-resolutions-tag');

    if (titleEl) titleEl.textContent = meta.title;
    if (uploaderEl) uploaderEl.textContent = meta.uploader || meta.channel || 'Unknown Creator';
    if (extractorEl) extractorEl.textContent = meta.extractor || 'Web';
    if (thumbImg) thumbImg.src = meta.thumbnail || '';
    if (durationTag) durationTag.textContent = this.formatDuration(meta.duration);

    const availableResolutions = Array.isArray(meta?.availableResolutions) ? meta.availableResolutions : [];
    if (resTag && availableResolutions.length > 0) {
      const realResolutions = availableResolutions.filter((r) => r >= 144 && r <= 2160);
      resTag.textContent = `Available Stream Resolutions: ${realResolutions.map((r) => r + 'p').join(', ')}`;

      // Dynamically add exact stream resolution options to profileSelect
      const profileSelect = document.getElementById('profile-select') as HTMLSelectElement;
      if (profileSelect && this.currentMode !== 'audio-only') {
        profileSelect.innerHTML = '';
        
        // Check if 4K (2160p) is available in stream
        const has4K = realResolutions.some((r) => r >= 2160);

        // Resolution Recommendation Rule:
        // Always default to 1080p if available. If video is lower than 1080p (e.g. 720p), select that lower max resolution.
        const has1080 = realResolutions.includes(1080);
        const recommendedRes = has1080
          ? 1080
          : (realResolutions.find((r) => r <= 1080) || realResolutions[realResolutions.length - 1]);

        for (const res of realResolutions) {
          let label = '';
          const isRec = (res === recommendedRes);

          if (res >= 2160) {
            label = `🎬 4K Ultra HD (${res}p) • Studio Master (Slower • Largest File)`;
          } else if (res >= 1440) {
            label = `🎬 1440p Quad HD (${res}p) • 2K Sharp (Moderate Speed)`;
          } else if (res >= 1080) {
            label = isRec
              ? `🎬 1080p Full HD (${res}p) • Recommended (Fast & Balanced)`
              : `🎬 1080p Full HD (${res}p) • Standard (Fast & Balanced)`;
          } else if (res >= 720) {
            label = isRec
              ? `🎬 720p HD (${res}p) • Recommended (Light File)`
              : `🎬 720p HD (${res}p) • Very Fast (Light File)`;
          } else {
            label = isRec
              ? `🎬 ${res}p • Recommended (Small File)`
              : `🎬 ${res}p • Super Fast / Instant (Small File)`;
          }

          const opt = new Option(label, `res-${res}`, isRec, isRec);
          profileSelect.appendChild(opt);
        }

        // Show 4K alert notice if 4K stream is detected
        if (has4K) {
          this.showHeaderToast(
            '⚡ 4K Ultra HD is available for this video! Auto-selected 1080p for fast editing. Select 4K in Quality Profile if you need master resolution.',
            7000
          );
        }

        // Trigger change handler to update container / warning if applicable
        profileSelect.dispatchEvent(new Event('change'));
      }
    }

    // Carousel Multi-Slide Ribbon
    const carouselWrapper = document.getElementById('media-carousel-wrapper');
    const carouselTrack = document.getElementById('carousel-track');
    const carouselCount = document.getElementById('carousel-slide-count');
    const btnCarouselDownloadAll = document.getElementById('btn-carousel-download-all');

    if (meta.carouselSlides && meta.carouselSlides.length > 0) {
      if (carouselWrapper) carouselWrapper.style.display = 'block';
      if (carouselCount) carouselCount.textContent = String(meta.carouselSlides.length);
      if (carouselTrack) {
        carouselTrack.innerHTML = '';
        meta.carouselSlides.forEach((slide) => {
          const slideCard = document.createElement('div');
          slideCard.style.cssText = 'position: relative; flex: 0 0 85px; height: 110px; border-radius: 4px; overflow: hidden; background: #222; border: 1px solid #444; display: flex; flex-direction: column;';
          const isVid = slide.mediaType === 'video';
          slideCard.innerHTML = `
            <div style="position: relative; flex: 1; overflow: hidden;">
              <img src="${slide.thumbnail || slide.url}" style="width: 100%; height: 100%; object-fit: cover;" onerror="this.src='data:image/svg+xml;utf8,<svg xmlns=\\'http://www.w3.org/2000/svg\\' width=\\'85\\' height=\\'80\\' fill=\\'%23333\\'><rect width=\\'100%\\' height=\\'100%\\'/></svg>'">
              <span style="position: absolute; top: 2px; left: 2px; background: rgba(0,0,0,0.7); font-size: 8px; padding: 1px 4px; border-radius: 3px; color: #fff;">#${slide.slideIndex} ${isVid ? '🎬' : '📸'}</span>
            </div>
            <button class="btn btn-primary btn-sm btn-slide-import" style="border-radius: 0; font-size: 9px; padding: 3px 2px; text-align: center; width: 100%; cursor: pointer;" title="Download & Import Slide #${slide.slideIndex}">
              ⬇ Import
            </button>
          `;
          slideCard.querySelector('.btn-slide-import')?.addEventListener('click', () => {
            this.handleDirectSlideDownload(slide, meta);
          });
          carouselTrack.appendChild(slideCard);
        });
      }

      if (btnCarouselDownloadAll) {
        btnCarouselDownloadAll.onclick = () => {
          this.handleDownloadAllSlides(meta);
        };
      }
    } else {
      if (carouselWrapper) carouselWrapper.style.display = 'none';
      if (carouselTrack) carouselTrack.innerHTML = '';
    }
  }

  private handleDirectSlideDownload(slide: any, meta: MediaMetadata) {
    const isVid = slide.mediaType === 'video';
    const profile: DownloadProfile = {
      type: isVid ? 'video' : 'image',
      presetId: isVid ? 'video-1080p' : 'best-available',
      label: isVid ? `Slide #${slide.slideIndex} Video` : `Slide #${slide.slideIndex} Photo`,
      container: isVid ? 'mp4' : 'jpg',
      remuxToMp4: isVid
    };
    serviceClient.startDownload(slide.url, profile, this.projectContext, undefined, {
      title: `${meta.title || 'Slide'} - Slide ${slide.slideIndex}`,
      thumbnail: slide.thumbnail || slide.url
    });
  }

  private handleDownloadAllSlides(meta: MediaMetadata) {
    if (!meta.carouselSlides || meta.carouselSlides.length === 0) return;
    for (const slide of meta.carouselSlides) {
      this.handleDirectSlideDownload(slide, meta);
    }
  }

  private renderPlaylistModal(playlist: PlaylistMetadata) {
    this.currentPlaylist = playlist;
    this.playlistCustomTargetDir = '';

    const isCloud = Boolean(
      (playlist as any).isCloud ||
      (playlist.uploader && playlist.uploader.toLowerCase().includes('cloud')) ||
      (playlist.url && (playlist.url.includes('drive.google.com') || playlist.url.includes('dropbox.com') || playlist.url.includes('onedrive') || playlist.url.includes('1drv.ms') || playlist.url.includes('mega.nz')))
    );

    const titleEl = document.getElementById('playlist-title');
    const countEl = document.getElementById('playlist-count');
    const uploaderEl = document.getElementById('playlist-uploader');
    const allCountEl = document.getElementById('playlist-all-count');
    const listContainer = document.getElementById('playlist-items-list');

    if (titleEl) titleEl.textContent = playlist.title;
    if (countEl) countEl.textContent = `${playlist.itemCount} items`;
    if (uploaderEl) uploaderEl.textContent = playlist.uploader || (isCloud ? 'Cloud Storage' : 'Creator');
    if (allCountEl) allCountEl.textContent = String(playlist.itemCount);

    const modalTitleHeader = document.getElementById('modal-playlist-title-header');
    if (modalTitleHeader) modalTitleHeader.textContent = isCloud ? 'Cloud Folder Detected' : 'Playlist Detected';

    const itemsHeaderLabel = document.getElementById('playlist-items-header-label');
    if (itemsHeaderLabel) itemsHeaderLabel.textContent = isCloud ? 'Cloud Files' : 'Playlist Items';

    const modeAllLabel = document.getElementById('playlist-mode-all-label');
    if (modeAllLabel) {
      modeAllLabel.innerHTML = isCloud
        ? `<strong>Download All Files</strong> in this folder (<span id="playlist-all-count">${playlist.itemCount}</span> files)`
        : `<strong>Download All Items</strong> in this playlist (<span id="playlist-all-count">${playlist.itemCount}</span> items)`;
    }

    const cloudStructureWrapper = document.getElementById('cloud-folder-structure-wrapper');
    if (cloudStructureWrapper) {
      cloudStructureWrapper.style.display = isCloud ? 'block' : 'none';
    }

    // Default Folder Name Input: Pre-fill with the genuine playlist or cloud folder name
    const folderNameInput = document.getElementById('playlist-folder-name') as HTMLInputElement;
    if (folderNameInput) {
      const plTitle = (playlist.title || '').trim();
      const defaultName = (plTitle && plTitle !== 'Playlist' && plTitle !== 'Media Playlist') 
        ? plTitle 
        : (playlist.uploader && !playlist.uploader.toLowerCase().includes('creator') ? `${playlist.uploader} - Playlist` : (isCloud ? 'Cloud Media' : 'Media Playlist'));
      folderNameInput.value = defaultName;
    }

    // Default Destination Folder Display: Show project path or custom setting
    const destPathEl = document.getElementById('playlist-destination-path');
    if (destPathEl) {
      const projDir = this.projectContext?.projectDirectory;
      if (projDir) {
        destPathEl.textContent = `${projDir}\\MediaFetch\\`;
      } else if (this.settings?.downloads?.downloadLocationMode === 'custom' && this.settings?.downloads?.customLocation) {
        destPathEl.textContent = this.settings.downloads.customLocation;
      } else {
        destPathEl.textContent = 'Active Adobe Project Folder';
      }
    }

    // Reset ZIP and Auto-import states
    const modalZipCb = document.getElementById('playlist-zip-package-cb') as HTMLInputElement | null;
    const modalAutoImportCb = document.getElementById('playlist-auto-import-cb') as HTMLInputElement | null;
    const modalAutoImportLabel = modalAutoImportCb?.closest('label') as HTMLElement | null;
    if (modalZipCb) {
      modalZipCb.checked = false;
      modalZipCb.onchange = () => {
        if (modalZipCb.checked) {
          if (modalAutoImportCb) {
            modalAutoImportCb.checked = false;
            modalAutoImportCb.disabled = true;
          }
          if (modalAutoImportLabel) {
            modalAutoImportLabel.style.opacity = '0.5';
            modalAutoImportLabel.title = 'Cannot auto-import ZIP files into Adobe timeline';
          }
        } else {
          if (modalAutoImportCb) {
            modalAutoImportCb.disabled = false;
            modalAutoImportCb.checked = true;
          }
          if (modalAutoImportLabel) {
            modalAutoImportLabel.style.opacity = '1';
            modalAutoImportLabel.title = '';
          }
        }
      };
    }
    if (modalAutoImportCb) {
      modalAutoImportCb.checked = true;
      modalAutoImportCb.disabled = false;
      modalAutoImportCb.onchange = () => {
        if (modalAutoImportCb.checked && modalZipCb) {
          modalZipCb.checked = false;
        }
      };
    }
    if (modalAutoImportLabel) {
      modalAutoImportLabel.style.opacity = '1';
      modalAutoImportLabel.title = '';
    }

    // Single video option: Only show when video URL in playlist is pasted (e.g. watch?v=...&list=...)
    const singleVideoWrapper = document.getElementById('playlist-single-video-wrapper');
    const hasSingleVideoInPlaylist = Boolean(
      playlist.url &&
      (playlist.url.includes('v=') || playlist.url.includes('/watch/')) &&
      playlist.url.includes('list=')
    );
    if (singleVideoWrapper) {
      singleVideoWrapper.style.display = hasSingleVideoInPlaylist ? 'block' : 'none';
    }

    const isSpotify = (playlist.uploader && playlist.uploader.toLowerCase().includes('spotify')) ||
                      (playlist.title && playlist.title.toLowerCase().includes('spotify')) ||
                      (playlist.url && playlist.url.toLowerCase().includes('spotify')) ||
                      playlist.items.some((it) => it.url && it.url.toLowerCase().includes('spotify'));

    const qualityPicker = document.getElementById('playlist-quality-picker') as HTMLSelectElement;
    if (qualityPicker) {
      qualityPicker.innerHTML = '';
      if (isSpotify) {
        // Audio-only options for Spotify Playlists
        qualityPicker.appendChild(new Option('🎵 MP3 Studio Master (320 kbps High Quality Audio)', 'audio_mp3_320', true, true));
        qualityPicker.appendChild(new Option('🎵 MP3 Standard (192 kbps Clean Audio)', 'audio_mp3_192'));
        qualityPicker.appendChild(new Option('🎵 MP3 Data Saver (128 kbps Low Compressed)', 'audio_mp3_128'));
        qualityPicker.appendChild(new Option('🎼 Lossless WAV (48kHz Uncompressed Audio)', 'audio_wav'));
        qualityPicker.appendChild(new Option('🖼️ High-Res Album Cover Art', 'image_cover'));
      } else {
        let maxKnownHeight = 0;
        let hasKnownHeight = false;
        for (const it of playlist.items) {
          const h = (it as any).height || (it as any).resolution || 0;
          if (typeof h === 'number' && h > 0) {
            hasKnownHeight = true;
            if (h > maxKnownHeight) maxKnownHeight = h;
          }
        }
        const isSub1080Only = hasKnownHeight && maxKnownHeight > 0 && maxKnownHeight < 1080;
        const recQuality = isSub1080Only ? (maxKnownHeight <= 480 ? '480p' : '720p') : '1080p';

        if (isCloud) {
        qualityPicker.appendChild(new Option(recQuality === '1080p' ? '🎬 1080p Full HD Video / Native Files • Recommended' : '🎬 1080p Full HD Video / Native Files', '1080p', recQuality === '1080p', recQuality === '1080p'));
        qualityPicker.appendChild(new Option('🎬 4K Ultra HD Video (Master Quality)', '4k'));
        qualityPicker.appendChild(new Option(recQuality === '720p' ? '🎬 720p HD Video • Recommended' : '🎬 720p HD Video • High Speed', '720p', recQuality === '720p', recQuality === '720p'));
        qualityPicker.appendChild(new Option(recQuality === '480p' ? '🎬 480p SD Video • Recommended' : '🎬 480p SD Video • Fast', '480p', recQuality === '480p', recQuality === '480p'));
        qualityPicker.appendChild(new Option('🎵 MP3 Studio Master (320 kbps Audio)', 'audio_mp3_320'));
        qualityPicker.appendChild(new Option('🎼 Lossless WAV (48kHz Uncompressed Audio)', 'audio_wav'));
      } else {
        // Video & Audio options for YouTube and other video playlists
        qualityPicker.appendChild(new Option(recQuality === '1080p' ? '🎬 1080p Full HD Video • Recommended (Fast & Balanced)' : '🎬 1080p Full HD Video • Standard (Fast & Balanced)', '1080p', recQuality === '1080p', recQuality === '1080p'));
        qualityPicker.appendChild(new Option('🎬 4K Ultra HD Video (2160p) • Studio Quality (Slower)', '4k'));
        qualityPicker.appendChild(new Option(recQuality === '720p' ? '🎬 720p HD Video • Recommended (Light File)' : '🎬 720p HD Video • High Speed (Light File)', '720p', recQuality === '720p', recQuality === '720p'));
        qualityPicker.appendChild(new Option(recQuality === '480p' ? '🎬 480p SD Video • Recommended (Small File)' : '🎬 480p Standard Definition • Fast', '480p', recQuality === '480p', recQuality === '480p'));
        qualityPicker.appendChild(new Option('🎵 MP3 Studio Master (320 kbps Audio)', 'audio_mp3_320'));
        qualityPicker.appendChild(new Option('🎵 MP3 Data Saver (128 kbps Audio)', 'audio_mp3_128'));
        qualityPicker.appendChild(new Option('🎼 Lossless WAV (48kHz Uncompressed Audio)', 'audio_wav'));
        qualityPicker.appendChild(new Option('🖼️ Video Cover Art / Thumbnail', 'image_cover'));
      }
    }
  }

    if (listContainer) {
      listContainer.innerHTML = '';
      let targetVideoId: string | null = null;
      if (playlist.url) {
        try {
          const parsedUrl = new URL(playlist.url);
          targetVideoId = parsedUrl.searchParams.get('v');
        } catch (_) {}
        if (!targetVideoId) {
          const vMatch = playlist.url.match(/(?:v=|\/watch\/|\/embed\/|youtu\.be\/)([a-zA-Z0-9_-]{11})/);
          if (vMatch) targetVideoId = vMatch[1];
        }
      }

      const hasMatchingSong = Boolean(
        targetVideoId && playlist.items.some((it) => {
          return (it.id && (it.id === targetVideoId || String(it.id).includes(targetVideoId))) ||
                 (it.url && (it.url.includes(`v=${targetVideoId}`) || it.url.includes(targetVideoId)));
        })
      );

      for (const it of playlist.items) {
        const row = document.createElement('label');
        row.style.cssText = 'display:flex; align-items:center; gap:6px; font-size:11px; padding:3px; border-bottom:1px solid var(--border-subtle); cursor:pointer;';

        let durationBadge = '';
        if (it.duration && it.duration > 0) {
          durationBadge = this.formatDuration(it.duration);
        } else {
          const extMatch = it.title.match(/\.([0-9a-z]+)$/i);
          durationBadge = extMatch ? extMatch[1].toUpperCase() : (isCloud ? 'CLOUD FILE' : 'MEDIA');
        }

        const isCurrentSong = Boolean(
          hasMatchingSong && targetVideoId && (
            (it.id && (it.id === targetVideoId || String(it.id).includes(targetVideoId))) ||
            (it.url && (it.url.includes(`v=${targetVideoId}`) || it.url.includes(targetVideoId)))
          )
        );
        const isChecked = hasMatchingSong ? isCurrentSong : true;
        const currentSongBadge = isCurrentSong ? '<span style="color:#0a84ff; font-weight:700; font-size:9.5px; background:rgba(10,132,255,0.18); border:1px solid rgba(10,132,255,0.35); padding:1px 5px; border-radius:3px; white-space:nowrap;">▶ Current Video</span>' : '';

        row.innerHTML = `
          <input type="checkbox" class="playlist-checkbox" data-url="${it.url}" data-title="${it.title.replace(/"/g, '&quot;')}" data-thumb="${it.thumbnail || ''}" data-dur="${it.duration || 0}" data-sub="${(it as any).subFolderName || ''}" data-query="${(it as any).downloadQuery || ''}" data-uploader="${(it as any).uploader || (it as any).channel || ''}" ${isChecked ? 'checked' : ''}>
          <span style="color:var(--text-muted); font-size:10px; width:20px;">#${it.index}</span>
          <span style="flex:1; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;" title="${it.title}">${it.title}</span>
          ${currentSongBadge}
          <span style="color:var(--text-muted); font-size:9.5px; background:rgba(255,255,255,0.06); padding:1px 5px; border-radius:3px; white-space:nowrap;">${durationBadge}</span>
        `;
        row.querySelector('input')?.addEventListener('change', () => this.updatePlaylistSelectedCount());
        listContainer.appendChild(row);
      }

      if (hasMatchingSong) {
        const radioSelected = document.querySelector('input[name="playlist-mode"][value="selected"]') as HTMLInputElement | null;
        if (radioSelected) radioSelected.checked = true;
        const itemsWrapper = document.getElementById('playlist-items-wrapper');
        if (itemsWrapper) itemsWrapper.style.display = 'block';
      }
    }

    this.updatePlaylistSelectedCount();
    this.openModal('modal-playlist');
  }

  private updatePlaylistSelectedCount() {
    const checked = document.querySelectorAll('.playlist-checkbox:checked');
    const selCountEl = document.getElementById('playlist-selected-count');
    if (selCountEl) selCountEl.textContent = String(checked.length);
    const radioSelCount = document.getElementById('playlist-selected-radio-count');
    if (radioSelCount) radioSelCount.textContent = String(checked.length);
  }

  private async handlePlaylistDownloadSubmit() {
    if (!this.currentPlaylist) return;

    if (typeof (window as any).MediaFetchLicense?.isAuthorized === 'function') {
      if (!(window as any).MediaFetchLicense.isAuthorized()) {
        (window as any).MediaFetchLicense.showModal?.('A valid commercial license is required to download media.');
        return;
      }
    }

    const qualityPicker = document.getElementById('playlist-quality-picker') as HTMLSelectElement;
    const chosenQuality = qualityPicker?.value || '1080p';

    let profileType: 'video' | 'audio' | 'video-only' | 'image' = 'video';
    let selectedPresetId: any = 'video-1080p';
    let container = 'mp4';
    let label = '🎬 1080p Full HD Video (Batch)';

    if (chosenQuality === '4k') {
      profileType = 'video';
      selectedPresetId = 'video-4k';
      container = 'mp4';
      label = '🎬 4K Ultra HD Video (Batch)';
    } else if (chosenQuality === '720p') {
      profileType = 'video';
      selectedPresetId = 'video-720p';
      container = 'mp4';
      label = '🎬 720p HD Video (Batch)';
    } else if (chosenQuality === '480p') {
      profileType = 'video';
      selectedPresetId = 'video-480p';
      container = 'mp4';
      label = '🎬 480p SD Video (Batch)';
    } else if (chosenQuality === 'audio_mp3_320') {
      profileType = 'audio';
      selectedPresetId = 'audio-mp3-320';
      container = 'mp3';
      label = '🎵 MP3 Studio Master 320kbps (Batch)';
    } else if (chosenQuality === 'audio_mp3_192') {
      profileType = 'audio';
      selectedPresetId = 'audio-mp3-192';
      container = 'mp3';
      label = '🎵 MP3 Standard 192kbps (Batch)';
    } else if (chosenQuality === 'audio_mp3_128') {
      profileType = 'audio';
      selectedPresetId = 'audio-mp3-128';
      container = 'mp3';
      label = '🎵 MP3 Data Saver 128kbps (Batch)';
    } else if (chosenQuality === 'audio_wav') {
      profileType = 'audio';
      selectedPresetId = 'audio-wav';
      container = 'wav';
      label = '🎵 Lossless WAV Audio (Batch)';
    } else if (chosenQuality === 'image_cover') {
      profileType = 'image';
      selectedPresetId = 'image-orig';
      container = 'jpg';
      label = '🖼️ Cover Art (Batch)';
    } else {
      profileType = 'video';
      selectedPresetId = 'video-1080p';
      container = 'mp4';
      label = '🎬 1080p Full HD Video (Batch)';
    }

    const profile: DownloadProfile = {
      type: profileType,
      presetId: selectedPresetId,
      label,
      container,
      remuxToMp4: container === 'mp4'
    };

    const mode = (document.querySelector('input[name="playlist-mode"]:checked') as HTMLInputElement)?.value || 'all';

    let selectedItems: { url: string; title: string; thumbnail?: string; duration?: number; subFolderName?: string; downloadQuery?: string; uploader?: string }[] = [];

    if (mode === 'single') {
      const first = this.currentPlaylist.items[0];
      if (first) {
        selectedItems = [{
          url: first.url,
          title: first.title,
          thumbnail: first.thumbnail,
          duration: first.duration,
          subFolderName: (first as any).subFolderName,
          downloadQuery: (first as any).downloadQuery,
          uploader: (first as any).uploader || (first as any).channel
        } as any];
      }
    } else {
      document.querySelectorAll('.playlist-checkbox:checked').forEach((cb) => {
        const el = cb as HTMLInputElement;
        selectedItems.push({
          url: el.getAttribute('data-url') || '',
          title: el.getAttribute('data-title') || 'Video',
          thumbnail: el.getAttribute('data-thumb') || undefined,
          duration: parseFloat(el.getAttribute('data-dur') || '0') || undefined,
          subFolderName: el.getAttribute('data-sub') || undefined,
          downloadQuery: el.getAttribute('data-query') || undefined,
          uploader: el.getAttribute('data-uploader') || undefined
        } as any);
      });
    }

    if (selectedItems.length === 0) {
      alert('Please select at least one item to download.');
      return;
    }

    const isCloud = Boolean(
      (this.currentPlaylist as any).isCloud ||
      (this.currentPlaylist.uploader && this.currentPlaylist.uploader.toLowerCase().includes('cloud')) ||
      (this.currentPlaylist.url && (this.currentPlaylist.url.includes('drive.google.com') || this.currentPlaylist.url.includes('dropbox.com') || this.currentPlaylist.url.includes('onedrive') || this.currentPlaylist.url.includes('1drv.ms') || this.currentPlaylist.url.includes('mega.nz')))
    );

    const folderNameInput = document.getElementById('playlist-folder-name') as HTMLInputElement;
    const customFolderName = folderNameInput?.value?.trim() || this.currentPlaylist.title || (isCloud ? 'Cloud Media' : 'Media Playlist');

    const structureMode = (document.querySelector('input[name="cloud-structure-mode"]:checked') as HTMLInputElement)?.value;
    const preserveSubfolders = structureMode !== 'flatten';

    const zipPackage = (document.getElementById('playlist-zip-package-cb') as HTMLInputElement)?.checked || false;
    const autoImport = zipPackage ? false : ((document.getElementById('playlist-auto-import-cb') as HTMLInputElement)?.checked !== false);

    // Refresh project context before initiating download
    try {
      this.projectContext = await hostAdapter.getProjectContext();
    } catch (_) {}

    serviceClient.startPlaylistDownload(
      selectedItems,
      profile,
      this.projectContext,
      this.playlistCustomTargetDir || undefined,
      {
        customFolderName,
        preserveSubfolders,
        autoImport,
        zipPackage,
        playlistTitle: this.currentPlaylist.title,
        isCloud
      }
    );
    this.closeModal('modal-playlist');

    const input = document.getElementById('url-input') as HTMLInputElement;
    if (input) input.value = '';

    this.showHeaderToast(`📥 Added ${selectedItems.length} items to download queue`, 5000);
  }

  private async handleDownloadClick() {
    // Refresh project context before initiating download
    try {
      this.projectContext = await hostAdapter.getProjectContext();
    } catch (_) {}

    if (typeof (window as any).MediaFetchLicense?.isAuthorized === 'function') {
      if (!(window as any).MediaFetchLicense.isAuthorized()) {
        (window as any).MediaFetchLicense.showModal?.('A valid commercial license is required to download media.');
        return;
      }
    }

    const urlInput = document.getElementById('url-input') as HTMLInputElement;
    const rawInput = urlInput?.value?.trim() || '';

    if (!rawInput) {
      this.showUrlError('Please enter or paste a media URL before downloading.');
      return;
    }

    // Support single or multiple URLs (separated by newlines, spaces, or commas)
    const urls = rawInput
      .split(/[\r\n,\s]+/)
      .map((u) => u.trim())
      .filter((u) => u.startsWith('http://') || u.startsWith('https://'));

    if (urls.length === 0) {
      this.showUrlError('Please enter a valid http/https URL.');
      return;
    }

    const profileSelect = document.getElementById('profile-select') as HTMLSelectElement;
    const formatSelect = document.getElementById('format-select') as HTMLSelectElement;

    const selectedPresetId = (profileSelect?.value || 'best-available') as any;
    const rawFormatValue = (formatSelect?.value || '').toLowerCase();
    const isExplicitVideoContainer = ['mp4', 'mov', 'webm', 'mkv', 'avi'].includes(rawFormatValue);
    const isExplicitAudioContainer = ['mp3', 'wav', 'm4a', 'flac', 'aac', 'ogg'].includes(rawFormatValue);

    const isImageMode = this.currentMode === 'image' || selectedPresetId.startsWith('image');
    let profileType: 'video' | 'audio' | 'video-only' | 'image' =
      isImageMode
        ? 'image'
        : (this.currentMode === 'audio-only' || selectedPresetId.startsWith('audio')
            ? 'audio'
            : (this.currentMode === 'video-only' ? 'video-only' : 'video'));

    // Critical: If user explicitly selected a video format (e.g. MP4), never allow audio-only extraction!
    if (isExplicitVideoContainer) {
      if (profileType === 'audio') {
        profileType = (this.currentMode === 'video-only') ? 'video-only' : 'video';
      }
    } else if (isExplicitAudioContainer && !isImageMode) {
      profileType = 'audio';
    }

    // Read custom filename
    const customFilenameInput = document.getElementById('custom-filename-input') as HTMLInputElement;
    const customFilename = customFilenameInput?.value?.trim() || undefined;

    // Read and validate optional clip trim range
    const trimStartInput = document.getElementById('trim-start-input') as HTMLInputElement;
    const trimEndInput = document.getElementById('trim-end-input') as HTMLInputElement;
    const rawStart = trimStartInput?.value?.trim() || undefined;
    const rawEnd = trimEndInput?.value?.trim() || undefined;

    let timeRange: { start?: string; end?: string } | undefined;
    if (rawStart || rawEnd) {
      const sSec = this.parseTimeToSec(rawStart);
      const eSec = this.parseTimeToSec(rawEnd);
      const start = rawStart ? this.formatDuration(sSec) : '00:00:00';
      const end = rawEnd ? this.formatDuration(eSec) : undefined;
      timeRange = { start, end };
    }

    let container = (rawFormatValue || (profileType === 'audio' ? 'mp3' : (profileType === 'image' ? 'jpg' : 'mp4'))) as any;
    if (isExplicitVideoContainer) {
      container = rawFormatValue;
    } else if (selectedPresetId === 'audio-wav' || rawFormatValue === 'wav') {
      container = 'wav';
    } else if (selectedPresetId === 'audio-flac' || rawFormatValue === 'flac') {
      container = 'flac';
    } else if (selectedPresetId === 'audio-m4a' || rawFormatValue === 'm4a') {
      container = 'm4a';
    } else if (selectedPresetId.startsWith('audio-mp3') || rawFormatValue === 'mp3') {
      container = 'mp3';
    }

    let explicitResolution: number | undefined;
    if (typeof selectedPresetId === 'string' && selectedPresetId.startsWith('res-')) {
      const parsed = parseInt(selectedPresetId.replace('res-', ''), 10);
      if (!isNaN(parsed) && parsed > 0) explicitResolution = parsed;
    } else if (selectedPresetId === 'video-4k') explicitResolution = 2160;
    else if (selectedPresetId === 'video-1440p') explicitResolution = 1440;
    else if (selectedPresetId === 'video-1080p') explicitResolution = 1080;
    else if (selectedPresetId === 'video-720p') explicitResolution = 720;
    else if (selectedPresetId === 'video-480p') explicitResolution = 480;


    const baseProfile: DownloadProfile = {
      type: profileType,
      presetId: selectedPresetId,
      resolution: explicitResolution,
      label: profileSelect?.selectedOptions[0]?.text || (profileType === 'audio' ? 'Audio Download' : profileType === 'video-only' ? 'Video Only Download' : 'Video Download'),
      container,
      remuxToMp4: container === 'mp4',
      customFilename,
      timeRange
    };

    // Resolve targetDirectory strictly when custom location mode is active
    let targetDirectory: string | undefined = undefined;
    const modeInput = document.getElementById('setting-location-mode') as HTMLSelectElement;
    const activeLocMode = modeInput?.value || this.settings?.downloads?.downloadLocationMode || 'project';
    if (activeLocMode === 'custom') {
      const customInput = document.getElementById('setting-custom-location') as HTMLInputElement;
      const customPath = customInput?.value?.trim() || this.settings?.downloads?.customLocation?.trim();
      if (customPath) {
        targetDirectory = customPath;
      }
    }

    // If multiple URLs were entered, start all concurrently in batch
    if (urls.length > 1) {
      for (const singleUrl of urls) {
        serviceClient.startDownload(singleUrl, { ...baseProfile }, this.projectContext, targetDirectory);
      }
      urlInput.value = '';
      this.closeCard();
      return;
    }

    const url = urls[0];

    // 1. If currently loaded metadata for this exact URL is already a multi-slide carousel, show popup modal!
    if (this.currentMetadata && (this.currentMetadata.url === url || (this.currentMetadata as any).webpage_url === url)) {
      if ((this.currentMetadata as any).isCarousel || (this.currentMetadata.carouselSlides && this.currentMetadata.carouselSlides.length > 1)) {
        const slides = this.currentMetadata.carouselSlides || [];
        this.renderPlaylistModal({
          id: this.currentMetadata.id || 'carousel_' + Date.now(),
          url: this.currentMetadata.url,
          title: this.currentMetadata.title || 'Instagram Carousel',
          uploader: this.currentMetadata.uploader || '@Instagram',
          itemCount: slides.length,
          items: slides.map((s, idx) => ({
            id: `slide_${idx + 1}`,
            title: s.title || `${this.currentMetadata?.title || 'Slide'} (Slide ${s.slideIndex || idx + 1})`,
            url: s.url,
            thumbnail: s.thumbnail || s.url,
            duration: s.duration || 0,
            downloadQuery: s.url,
            uploader: this.currentMetadata?.uploader
          }))
        });
        return;
      }
    }

    // 2. If currently loaded playlist is for this URL, show popup modal!
    if (this.currentPlaylist && (this.currentPlaylist.url === url || (this.currentPlaylist as any).webpage_url === url)) {
      this.renderPlaylistModal(this.currentPlaylist);
      return;
    }

    // 3. If clicking Download directly on any playlist, cloud link, or multi-item link:
    // Route to analyzer so the user gets the popup modal to choose items/quality/folder/ZIP!
    if (this.isPlaylistUrl(url)) {
      this.setAnalysisLoading(true);
      if (url.includes('instagram.com/p/') || url.includes('instagram.com/reel/')) {
        serviceClient.analyzeUrl(url);
      } else {
        serviceClient.analyzePlaylist(url);
      }
      return;
    }

    // Isolate metadata: NEVER inherit stale metadata from an earlier analyzed song/video!
    const isMatchingMeta = this.currentMetadata && 
      (this.currentMetadata.url === url || (this.currentMetadata as any).webpage_url === url);
    const validMeta = isMatchingMeta ? this.currentMetadata : null;

    const title = validMeta?.title || '';

    this.pendingDownloadParams = {
      url,
      profile: baseProfile,
      projectContext: this.projectContext,
      targetDirectory,
      metadata: validMeta ? {
        title,
        thumbnail: validMeta.thumbnail,
        duration: validMeta.duration,
        downloadQuery: (validMeta as any).downloadQuery,
        uploader: validMeta.uploader || validMeta.channel
      } : undefined
    };

    // Immediately dispatch download without blocking UI on duplicate check roundtrip
    this.executePendingDownload();
  }

  private executePendingDownload() {
    if (!this.pendingDownloadParams) return;
    serviceClient.startDownload(
      this.pendingDownloadParams.url,
      this.pendingDownloadParams.profile,
      this.pendingDownloadParams.projectContext,
      this.pendingDownloadParams.targetDirectory,
      this.pendingDownloadParams.metadata
    );
    this.pendingDownloadParams = null;

    // Reset input
    const input = document.getElementById('url-input') as HTMLInputElement;
    if (input) input.value = '';
    const card = document.getElementById('media-card-section');
    if (card) card.style.display = 'none';

    this.showHeaderToast('📥 Added item to download queue', 4000);
  }

  private getVisibleQueue(): DownloadItem[] {
    const isPro = (window as any).__MF_EDITION__ === 'pro' || window.location.pathname.includes('.pro') || document.title.includes('Pro');
    const myEdition = isPro ? 'pro' : 'standard';
    return (this.queue || []).filter((item: any) => {
      if (!item) return false;
      if (!item.edition) {
        return myEdition === 'pro';
      }
      return item.edition === myEdition;
    });
  }

  private renderQueue() {
    const container = document.getElementById('queue-container');
    const countEl = document.getElementById('queue-count');
    if (!container) return;

    const visibleItems = this.getVisibleQueue();

    if (countEl) countEl.textContent = String(visibleItems.length);

    if (visibleItems.length === 0) {
      container.innerHTML = '<div class="queue-empty-state">No active downloads. Paste a URL and click Download to start.</div>';
      return;
    }

    container.innerHTML = '';
    for (const item of visibleItems) {
      container.appendChild(this.createQueueItemElement(item));
    }
  }

  private createQueueItemElement(item: DownloadItem): HTMLElement {
    const el = document.createElement('div');
    el.className = 'queue-item';
    el.id = `q-item-${item.id}`;
    el.setAttribute('data-status', item.status);

    const badgeClass = `badge-${item.status}`;
    const fillClass = item.status === 'completed' ? 'success' : item.status === 'failed' ? 'error' : '';

    let statsText = item.stageDescription || item.status.toUpperCase();
    if (item.status === 'downloading') {
      const downMB = (item.downloadedBytes / (1024 * 1024)).toFixed(1);
      const totalMB = item.totalBytes > 0 ? (item.totalBytes / (1024 * 1024)).toFixed(1) + ' MB' : '…';
      const speed = item.speed || '';
      const eta = item.eta ? ` · ETA ${item.eta}` : '';
      const hasMeaningfulStage = item.stageDescription && (
        item.stageDescription.toLowerCase().includes('process') ||
        item.stageDescription.toLowerCase().includes('trim') ||
        item.stageDescription.toLowerCase().includes('optimi') ||
        item.stageDescription.toLowerCase().includes('remux') ||
        item.stageDescription.toLowerCase().includes('merg') ||
        item.stageDescription.toLowerCase().includes('wait') ||
        item.stageDescription.toLowerCase().includes('start')
      );

      if (hasMeaningfulStage) {
        statsText = `${item.stageDescription}${speed ? ` · ${speed}` : ''}${eta}`;
      } else if (item.downloadedBytes > 0 || speed) {
        statsText = `${downMB} MB / ${totalMB} · ${speed}${eta}`;
      } else {
        statsText = item.stageDescription || 'Downloading stream...';
      }
    }

    el.innerHTML = `
      <div class="queue-item-header">
        <span class="queue-item-title" title="${item.title}">${item.title}</span>
        <span class="queue-item-badge ${badgeClass}">${item.status}</span>
      </div>
      <div class="progress-bar-container">
        <div class="progress-bar-fill ${fillClass}" style="width: ${item.progress}%;"></div>
      </div>
      <div class="queue-item-stats">
        <span class="item-stats-text">${statsText}</span>
        <div class="queue-item-actions">
          ${this.renderItemActionButtons(item)}
        </div>
      </div>
    `;

    this.bindItemActionEvents(el, item);
    return el;
  }

  private renderItemActionButtons(item: DownloadItem): string {
    if (item.status === 'downloading' || item.status === 'waiting') {
      return `
        <button class="btn btn-icon btn-sm btn-pause" title="Pause">⏸</button>
        <button class="btn btn-icon btn-sm btn-cancel" title="Cancel">✕</button>
      `;
    } else if (item.status === 'paused') {
      return `
        <button class="btn btn-icon btn-sm btn-resume" title="Resume">▶</button>
        <button class="btn btn-icon btn-sm btn-cancel" title="Cancel">✕</button>
      `;
    } else if (item.status === 'failed') {
      return `
        <button class="btn btn-icon btn-sm btn-retry" title="Retry">↻</button>
        <button class="btn btn-icon btn-sm btn-cancel" title="Remove">✕</button>
      `;
    } else if (item.status === 'completed') {
      return `
        <button class="btn btn-icon btn-sm btn-reveal" title="Show in Folder">📁</button>
        <button class="btn btn-icon btn-sm btn-import" title="Import to Adobe Workspace Bin">📥</button>
      `;
    }
    return `<button class="btn btn-icon btn-sm btn-cancel" title="Remove">✕</button>`;
  }

  private bindItemActionEvents(_el: HTMLElement, _item: DownloadItem) {
    // Handled exclusively by robust container-level event delegation
  }

  private updateQueueItemDOM(item: DownloadItem) {
    if (typeof window !== 'undefined' && window.requestAnimationFrame) {
      window.requestAnimationFrame(() => this._applyQueueItemDOM(item));
    } else {
      this._applyQueueItemDOM(item);
    }
  }

  private _applyQueueItemDOM(item: DownloadItem) {
    const existing = document.getElementById(`q-item-${item.id}`);
    if (existing) {
      const title = existing.querySelector('.queue-item-title') as HTMLElement;
      const badge = existing.querySelector('.queue-item-badge') as HTMLElement;
      const fill = existing.querySelector('.progress-bar-fill') as HTMLElement;
      const stats = existing.querySelector('.item-stats-text') as HTMLElement;

      if (title && item.title) {
        title.textContent = item.title;
        title.title = item.title;
      }
      if (badge) {
        badge.className = `queue-item-badge badge-${item.status}`;
        badge.textContent = item.status;
      }
      if (fill) {
        fill.style.width = `${item.progress}%`;
        fill.className = `progress-bar-fill ${item.status === 'completed' ? 'success' : item.status === 'failed' ? 'error' : ''}`;
      }
      if (stats) {
        let statsText = item.stageDescription || item.status.toUpperCase();
        if (item.status === 'downloading') {
          const downMB = (item.downloadedBytes / (1024 * 1024)).toFixed(1);
          const totalMB = item.totalBytes > 0 ? (item.totalBytes / (1024 * 1024)).toFixed(1) + ' MB' : '…';
          const speed = item.speed || '';
          const eta = item.eta ? ` · ETA ${item.eta}` : '';
          const hasMeaningfulStage = item.stageDescription && (
            item.stageDescription.toLowerCase().includes('process') ||
            item.stageDescription.toLowerCase().includes('trim') ||
            item.stageDescription.toLowerCase().includes('optimi') ||
            item.stageDescription.toLowerCase().includes('remux') ||
            item.stageDescription.toLowerCase().includes('merg') ||
            item.stageDescription.toLowerCase().includes('wait') ||
            item.stageDescription.toLowerCase().includes('start')
          );

          if (hasMeaningfulStage) {
            statsText = `${item.stageDescription}${speed ? ` · ${speed}` : ''}${eta}`;
          } else if (item.downloadedBytes > 0 || speed) {
            statsText = `${downMB} MB / ${totalMB} · ${speed}${eta}`;
          } else {
            statsText = item.stageDescription || 'Downloading stream...';
          }
        }
        stats.textContent = statsText;
      }

      const prevStatus = existing.getAttribute('data-status');
      if (prevStatus !== item.status) {
        existing.setAttribute('data-status', item.status);
        const actions = existing.querySelector('.queue-item-actions') as HTMLElement;
        if (actions) {
          actions.innerHTML = this.renderItemActionButtons(item);
          this.bindItemActionEvents(existing, item);
        }
      }
    } else {
      this.renderQueue();
    }
  }

  private renderDiagnostics(diag: SystemDiagnostics) {
    const osEl = document.getElementById('diag-os');
    const nodeEl = document.getElementById('diag-node');
    const adobeEl = document.getElementById('diag-adobe');
    const portEl = document.getElementById('diag-port');
    const ytdlpEl = document.getElementById('diag-ytdlp');
    const ffmpegEl = document.getElementById('diag-ffmpeg');
    const logsBox = document.getElementById('diag-logs-box');

    if (osEl) osEl.textContent = diag.os;
    if (nodeEl) nodeEl.textContent = diag.nodeVersion;
    if (adobeEl) adobeEl.textContent = `${diag.adobeApp || 'Adobe App'} (${diag.adobeVersion || 'Auto'})`;
    if (portEl) portEl.textContent = String(diag.servicePort);
    if (ytdlpEl) ytdlpEl.textContent = diag.ytdlp.available ? `v${diag.ytdlp.version || 'OK'}` : 'Missing';
    if (ffmpegEl) ffmpegEl.textContent = diag.ffmpeg.available ? `v${diag.ffmpeg.version || 'OK'}` : 'Missing';

    // Populate Settings Engine Tab version labels
    const engineYtDlp = document.getElementById('engine-ytdlp-ver');
    const engineFfmpeg = document.getElementById('engine-ffmpeg-ver');
    if (engineYtDlp) {
      engineYtDlp.textContent = diag.ytdlp?.available ? `v${diag.ytdlp.version || 'OK'}` : 'Missing / Not Installed';
      engineYtDlp.style.color = diag.ytdlp?.available ? 'var(--status-success, #22c55e)' : 'var(--status-error, #ef4444)';
    }
    if (engineFfmpeg) {
      engineFfmpeg.textContent = diag.ffmpeg?.available ? `v${diag.ffmpeg.version || 'OK'}` : 'Missing / Not Installed';
      engineFfmpeg.style.color = diag.ffmpeg?.available ? 'var(--status-success, #22c55e)' : 'var(--status-error, #ef4444)';
    }

    fetch(`http://127.0.0.1:${diag.servicePort}/api/diagnostics/logs`)
      .then((r) => r.json())
      .then((data) => {
        if (logsBox && Array.isArray(data.logs)) {
          logsBox.textContent = data.logs.join('\n');
          logsBox.scrollTop = logsBox.scrollHeight;
        }
      })
      .catch(() => {});
  }

  private updateSetupWizardStatus(diag: SystemDiagnostics) {
    const ytdlpStat = document.getElementById('setup-status-ytdlp');
    const ffmpegStat = document.getElementById('setup-status-ffmpeg');

    if (ytdlpStat) {
      ytdlpStat.textContent = diag.ytdlp.available ? `✓ Ready (v${diag.ytdlp.version || ''})` : '✗ Missing';
      ytdlpStat.style.color = diag.ytdlp.available ? 'var(--status-success)' : 'var(--status-error)';
    }

    if (ffmpegStat) {
      ffmpegStat.textContent = diag.ffmpeg.available ? `✓ Ready (${diag.ffmpeg.version || ''})` : '✗ Missing';
      ffmpegStat.style.color = diag.ffmpeg.available ? 'var(--status-success)' : 'var(--status-error)';
    }

    const installBtn = document.getElementById('btn-setup-install-all') as HTMLButtonElement;
    if (installBtn) {
      if (diag.ytdlp.available && diag.ffmpeg.available) {
        installBtn.textContent = 'All Components Ready';
        installBtn.disabled = true;
      } else {
        installBtn.textContent = 'Install Missing Components';
        installBtn.disabled = false;
      }
    }
  }

  private showInstallProgress(payload: { name: string; stage: string; progress: number; message: string }) {
    const progRow = document.getElementById('setup-progress-row');
    const progLabel = document.getElementById('setup-progress-label');
    const progFill = document.getElementById('setup-progress-fill');

    if (progRow) progRow.style.display = 'flex';
    if (progLabel) progLabel.textContent = `[${payload.name}] ${payload.message}`;
    if (progFill) progFill.style.width = `${payload.progress}%`;

    const engineStatus = document.getElementById('engine-update-status');
    if (engineStatus) {
      engineStatus.style.display = 'block';
      engineStatus.style.color = 'var(--text-secondary, #aaa)';
      engineStatus.textContent = payload.message || 'Updating yt-dlp engine...';
    }
  }

  private handleInstallResult(payload: { name: string; success: boolean; error?: string; message?: string }) {
    const progLabel = document.getElementById('setup-progress-label');
    if (progLabel) {
      if (payload.success) {
        progLabel.textContent = `✓ ${payload.name} installation completed successfully.`;
      } else {
        progLabel.textContent = `✗ Failed to install ${payload.name}: ${payload.error}`;
      }
    }

    const btnUpdate = document.getElementById('btn-update-ytdlp') as HTMLButtonElement;
    if (btnUpdate) {
      btnUpdate.disabled = false;
      btnUpdate.textContent = '🔄 Check & Update yt-dlp';
    }

    const engineStatus = document.getElementById('engine-update-status');
    if (engineStatus) {
      engineStatus.style.display = 'block';
      if (payload.success) {
        engineStatus.style.color = 'var(--status-success, #22c55e)';
        engineStatus.textContent = payload.message || '✓ yt-dlp is up to date!';
      } else {
        engineStatus.style.color = 'var(--status-error, #ef4444)';
        engineStatus.textContent = `✗ Update notice: ${payload.error || 'Check network connection'}`;
      }
    }

    serviceClient.runSystemCheck();
    serviceClient.getDiagnostics();
  }

  private updateDownloadLocationModeUI() {
    const modeSel = document.getElementById('setting-location-mode') as HTMLSelectElement;
    const customLoc = document.getElementById('setting-custom-location') as HTMLInputElement;
    const customBrowseBtn = document.getElementById('btn-browse-custom-location') as HTMLButtonElement;
    const customGroup = document.getElementById('setting-custom-location-group') || customLoc?.parentElement?.parentElement;

    const isCustom = modeSel?.value === 'custom';
    if (customLoc) customLoc.disabled = !isCustom;
    if (customBrowseBtn) customBrowseBtn.disabled = !isCustom;
    if (customGroup) {
      customGroup.style.opacity = isCustom ? '1' : '0.45';
      customGroup.style.pointerEvents = isCustom ? 'auto' : 'none';
    }
  }

  private populateSettingsForm(s: MediaFetchSettings) {
    const themeSel = document.getElementById('setting-theme') as HTMLSelectElement;
    const autoImportChk = document.getElementById('setting-auto-import') as HTMLInputElement;
    const confirmChk = document.getElementById('setting-confirm-overwrite') as HTMLInputElement;
    const cleanupChk = document.getElementById('setting-auto-cleanup') as HTMLInputElement;
    const modeSel = document.getElementById('setting-location-mode') as HTMLSelectElement;
    const playlistSel = document.getElementById('setting-playlist-behavior') as HTMLSelectElement;
    const customLoc = document.getElementById('setting-custom-location') as HTMLInputElement;
    const concSel = document.getElementById('setting-concurrency') as HTMLSelectElement;
    const retriesSel = document.getElementById('setting-max-retries') as HTMLSelectElement;
    const timeoutInput = document.getElementById('setting-timeout') as HTMLInputElement;
    const debugChk = document.getElementById('setting-debug-logging') as HTMLInputElement;
    const cookiesSel = document.getElementById('setting-browser-cookies') as HTMLSelectElement;

    if (themeSel) themeSel.value = s.general.theme;
    if (autoImportChk) autoImportChk.checked = s.general.autoImportToProject ?? true;
    if (confirmChk) confirmChk.checked = s.general.confirmOverwrite;
    if (cleanupChk) cleanupChk.checked = s.general.autoCleanupTemp;
    if (modeSel) modeSel.value = s.downloads.downloadLocationMode;
    if (playlistSel) playlistSel.value = s.downloads.playlistBehavior || 'ask';
    if (customLoc) customLoc.value = s.downloads.customLocation;
    if (concSel) concSel.value = String(s.downloads.concurrency);
    if (retriesSel) retriesSel.value = String(s.downloads.maxRetries);
    if (timeoutInput) timeoutInput.value = String(s.advanced.networkTimeoutMs);
    if (debugChk) debugChk.checked = s.advanced.debugLogging;
    if (cookiesSel) cookiesSel.value = s.engine.browserCookies || 'none';

    this.updateDownloadLocationModeUI();
  }

  private saveSettingsFromForm() {
    const themeSel = document.getElementById('setting-theme') as HTMLSelectElement;
    const autoImportChk = document.getElementById('setting-auto-import') as HTMLInputElement;
    const confirmChk = document.getElementById('setting-confirm-overwrite') as HTMLInputElement;
    const cleanupChk = document.getElementById('setting-auto-cleanup') as HTMLInputElement;
    const modeSel = document.getElementById('setting-location-mode') as HTMLSelectElement;
    const playlistSel = document.getElementById('setting-playlist-behavior') as HTMLSelectElement;
    const customLoc = document.getElementById('setting-custom-location') as HTMLInputElement;
    const concSel = document.getElementById('setting-concurrency') as HTMLSelectElement;
    const retriesSel = document.getElementById('setting-max-retries') as HTMLSelectElement;
    const timeoutInput = document.getElementById('setting-timeout') as HTMLInputElement;
    const debugChk = document.getElementById('setting-debug-logging') as HTMLInputElement;
    const cookiesSel = document.getElementById('setting-browser-cookies') as HTMLSelectElement;

    const updated: Partial<MediaFetchSettings> = {
      general: {
        theme: (themeSel?.value as any) || 'host',
        notifications: true,
        confirmOverwrite: confirmChk?.checked ?? true,
        autoCleanupTemp: cleanupChk?.checked ?? true,
        autoImportToProject: autoImportChk?.checked ?? true
      },
      downloads: {
        defaultPreset: 'best-available',
        downloadLocationMode: (modeSel?.value as any) || 'project',
        customLocation: customLoc?.value || '',
        concurrency: parseInt(concSel?.value || '2', 10),
        maxRetries: parseInt(retriesSel?.value || '3', 10),
        retryDelayMs: 2000,
        filenamePattern: '%(title)s.%(ext)s',
        playlistBehavior: (playlistSel?.value as any) || 'ask'
      },
      engine: {
        autoUpdate: true,
        browserCookies: cookiesSel?.value || 'none'
      },
      advanced: {
        networkTimeoutMs: parseInt(timeoutInput?.value || '30000', 10),
        debugLogging: debugChk?.checked ?? false
      }
    };

    serviceClient.updateSettings(updated);

    if (typeof (window as any).Settings !== 'undefined') {
      const pexelsInput = document.getElementById('setting-studio-pexels-key') as HTMLInputElement;
      const pixabayInput = document.getElementById('setting-studio-pixabay-key') as HTMLInputElement;
      const unsplashInput = document.getElementById('setting-studio-unsplash-key') as HTMLInputElement;
      const giphyInput = document.getElementById('setting-studio-giphy-key') as HTMLInputElement;
      (window as any).Settings.save({
        downloadFolder: modeSel?.value === 'custom' ? (customLoc?.value?.trim() || '') : '',
        pexelsApiKey: pexelsInput ? pexelsInput.value.trim() : '',
        pixabayApiKey: pixabayInput ? pixabayInput.value.trim() : '',
        unsplashApiKey: unsplashInput ? unsplashInput.value.trim() : '',
        giphyApiKey: giphyInput ? giphyInput.value.trim() : '',
        autoInsertTimeline: false
      });
    }
  }

  private renderHistoryList(filterQuery = '') {
    const container = document.getElementById('history-list-container');
    if (!container) return;

    const isPro = (window as any).__MF_EDITION__ === 'pro' || window.location.pathname.includes('.pro') || document.title.includes('Pro');
    const myEdition = isPro ? 'pro' : 'standard';

    const filtered = this.history.filter((h: any) => {
      const matchEdition = !h.edition || h.edition === myEdition;
      const matchQuery = !filterQuery || h.title.toLowerCase().includes(filterQuery) || h.url.toLowerCase().includes(filterQuery);
      return matchEdition && matchQuery;
    });

    if (filtered.length === 0) {
      container.innerHTML = '<div style="font-size:11px; color:var(--text-muted); padding:12px; text-align:center;">No history records found.</div>';
      return;
    }

    container.innerHTML = '';
    for (const h of filtered) {
      const row = document.createElement('div');
      row.className = 'queue-item';
      const dateStr = new Date(h.date).toLocaleDateString();
      const mb = (h.fileSize / (1024 * 1024)).toFixed(1);

      row.innerHTML = `
        <div class="queue-item-header">
          <span class="queue-item-title" title="${h.title}">${h.title}</span>
          <span class="queue-item-badge badge-completed">${h.profileName}</span>
        </div>
        <div class="queue-item-stats">
          <span>${dateStr} · ${mb} MB</span>
          <div class="queue-item-actions">
            <button class="btn btn-icon btn-sm btn-hist-reveal" title="Show in Folder">📁</button>
            <button class="btn btn-icon btn-sm btn-hist-redl" title="Download Again">↻</button>
            <button class="btn btn-icon btn-sm btn-hist-del" title="Delete from history">✕</button>
          </div>
        </div>
      `;

      row.querySelector('.btn-hist-reveal')?.addEventListener('click', () => hostAdapter.revealInFinder(h.outputPath));
      row.querySelector('.btn-hist-redl')?.addEventListener('click', () => {
        const input = document.getElementById('url-input') as HTMLInputElement;
        if (input) {
          input.value = h.url;
          this.closeModal('modal-history');
          this.handleAnalyze();
        }
      });
      row.querySelector('.btn-hist-del')?.addEventListener('click', () => serviceClient.removeHistoryItem(h.id));

      container.appendChild(row);
    }
  }

  private showDuplicateModal(filePath: string) {
    const pathEl = document.getElementById('dup-file-path');
    if (pathEl) pathEl.textContent = filePath;
    this.openModal('modal-duplicate');
  }

  private openModal(id: string) {
    const m = document.getElementById(id);
    if (m) m.classList.add('active');
  }

  private closeModal(id: string) {
    if (id === 'modal-media-preview') {
      const viewport = document.getElementById('media-preview-viewport');
      if (viewport) viewport.innerHTML = '';
    }
    const m = document.getElementById(id);
    if (m) m.classList.remove('active');
  }

  private openMediaPreview(meta: MediaMetadata | null) {
    if (!meta) return;

    // Check if rich Pro Theater Player is available
    const isAudio = (meta as any).mediaType === 'audio' || (meta as any).profile?.type === 'audio';
    const isImage = (meta as any).mediaType === 'image' || (meta as any).profile?.type === 'image';
    const theaterItem = {
      id: meta.id || 'preview_' + Date.now(),
      videoId: meta.id,
      title: meta.title,
      author: meta.uploader || meta.channel || 'Media Creator',
      uploader: meta.uploader || meta.channel || 'Media Creator',
      thumbnail: meta.thumbnail,
      pageUrl: meta.url,
      sourceUrl: meta.url,
      url: meta.url,
      type: isAudio ? 'audio' : (isImage ? 'image' : 'video'),
      hoverPreviewUrl: (meta as any).directStreamUrl || '',
      downloadFormats: (meta as any).formats || []
    };

    if (typeof (window as any).openTheaterPreview === 'function') {
      try {
        (window as any).openTheaterPreview(theaterItem);
        return;
      } catch (err) {
        console.warn('Theater player delegate error:', err);
      }
    }

    const titleEl = document.getElementById('media-preview-title');
    const authorEl = document.getElementById('media-preview-author');
    const viewport = document.getElementById('media-preview-viewport');
    const openBrowserBtn = document.getElementById('btn-open-preview-browser');

    if (titleEl) titleEl.textContent = meta.title || 'Media Preview';
    if (authorEl) {
      authorEl.textContent = `${meta.uploader || meta.channel || 'Media'} • ${this.formatDuration(meta.duration)}`;
    }

    if (openBrowserBtn) {
      openBrowserBtn.onclick = () => {
        const u = meta.url;
        if (u) {
          if ((window as any).__adobe_cep__ && typeof (window as any).__adobe_cep__.openURLInDefaultBrowser === 'function') {
            (window as any).__adobe_cep__.openURLInDefaultBrowser(u);
          } else if ((window as any).cep?.util?.openURLInDefaultBrowser) {
            (window as any).cep.util.openURLInDefaultBrowser(u);
          } else {
            window.open(u, '_blank');
          }
        }
      };
    }

    if (viewport) {
      viewport.innerHTML = '';
      const url = meta.url || '';
      const isYouTube = url.includes('youtube.com') || url.includes('youtu.be');
      const isSpotify = url.includes('spotify.com');

      if (isYouTube) {
        let ytId = meta.id;
        if (!ytId || ytId.length !== 11) {
          const match = url.match(/(?:v=|youtu\.be\/|embed\/|live\/)([a-zA-Z0-9_-]{11})/);
          if (match) ytId = match[1];
        }
        if (ytId) {
          viewport.innerHTML = `<iframe src="http://127.0.0.1:48924/youtube-player.html?v=${encodeURIComponent(ytId)}&autoplay=1" style="width:100%; height:100%; border:none;" allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen></iframe>`;
        } else {
          viewport.innerHTML = `<div style="display:flex; flex-direction:column; align-items:center; justify-content:center; gap:8px; padding:20px; color:#aaa;"><span>Preview ready</span><button class="btn btn-primary btn-sm" id="btn-play-yt-browser">▶ Play in Browser</button></div>`;
          document.getElementById('btn-play-yt-browser')?.addEventListener('click', () => {
            if ((window as any).__adobe_cep__?.openURLInDefaultBrowser) (window as any).__adobe_cep__.openURLInDefaultBrowser(url);
            else window.open(url, '_blank');
          });
        }
      } else if (isSpotify) {
        const trackMatch = url.match(/track\/([a-zA-Z0-9]+)/);
        const sId = trackMatch ? trackMatch[1] : meta.id;
        if (sId) {
          viewport.innerHTML = `<iframe src="https://open.spotify.com/embed/track/${sId}?utm_source=generator" width="100%" height="100%" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"></iframe>`;
        }
      } else {
        // Direct stream or formats check
        let streamUrl = (meta as any).directStreamUrl || (meta as any).directUrl || '';
        if (!streamUrl && meta.formats && meta.formats.length > 0) {
          const streamFormat = meta.formats.find((f: any) => f.url && (f.hasAudioAndVideo || (f.ext === 'mp4' && f.vcodec !== 'none')));
          if (streamFormat) streamUrl = (streamFormat as any).url;
        }

        if (streamUrl && /\.(mp4|webm|m3u8|mov|ogg)($|\?)/i.test(streamUrl)) {
          viewport.innerHTML = `<video src="${streamUrl}" controls autoplay playsinline style="width:100%; height:100%; object-fit:contain;"></video>`;
        } else {
          viewport.innerHTML = `
            <div style="display:flex; flex-direction:column; align-items:center; justify-content:center; gap:10px; padding:20px; text-align:center; color:#ddd;">
              <div style="width:28px; height:28px; border:3px solid #00d1b2; border-top-color:transparent; border-radius:50%; animation:spin 0.8s linear infinite;"></div>
              <span style="font-size:12px; font-weight:600; color:#00d1b2;">Resolving stream preview...</span>
            </div>
          `;
          fetch(`http://127.0.0.1:48924/api/stream-url?v=${encodeURIComponent(url)}`)
            .then((r) => r.json())
            .then((data) => {
              if (data && data.success && data.streamUrl) {
                viewport.innerHTML = `<video src="${data.streamUrl}" controls autoplay playsinline style="width:100%; height:100%; object-fit:contain;"></video>`;
              } else {
                throw new Error('Stream URL not found');
              }
            })
            .catch(() => {
              viewport.innerHTML = `
                <div style="display:flex; flex-direction:column; align-items:center; justify-content:center; gap:8px; padding:16px; text-align:center;">
                  <img src="${meta.thumbnail || ''}" style="max-height:140px; border-radius:4px; box-shadow:0 4px 12px rgba(0,0,0,0.5);" alt="Thumb">
                  <span style="font-size:11px; color:#bbb;">Click below to stream in default browser</span>
                  <button type="button" class="btn btn-primary btn-sm" id="btn-play-external" style="padding:4px 12px; font-weight:600;">▶ Watch Stream</button>
                </div>
              `;
              document.getElementById('btn-play-external')?.addEventListener('click', () => {
                if ((window as any).__adobe_cep__ && typeof (window as any).__adobe_cep__.openURLInDefaultBrowser === 'function') {
                  (window as any).__adobe_cep__.openURLInDefaultBrowser(url);
                } else if ((window as any).cep?.util?.openURLInDefaultBrowser) {
                  (window as any).cep.util.openURLInDefaultBrowser(url);
                } else {
                  window.open(url, '_blank');
                }
              });
            });
        }
      }
    }

    this.openModal('modal-media-preview');
  }

  private closeMediaPreview() {
    const viewport = document.getElementById('media-preview-viewport');
    if (viewport) viewport.innerHTML = '';
    this.closeModal('modal-media-preview');
  }

  public parseTimeToSec(txt?: string): number {
    if (!txt) return 0;
    const clean = txt.trim();
    if (!clean) return 0;
    const parts = clean.split(':').map((p) => parseFloat(p.trim()) || 0);
    if (parts.length >= 3) {
      let sec = parts[0] * 3600 + parts[1] * 60 + parts[2];
      if (parts.length >= 4) sec += parts[3] / 30;
      return sec;
    }
    if (parts.length === 2) return parts[0] * 60 + parts[1];
    if (parts.length === 1) return parts[0];
    return 0;
  }

  private formatDuration(seconds?: number): string {
    if (!seconds || seconds <= 0) return '00:00';
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    if (h > 0) {
      return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
    }
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  }
}

// Auto-instantiate
if (typeof document !== 'undefined') {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => new MediaFetchApp());
  } else {
    new MediaFetchApp();
  }
}
