import { ClientMessage, ServerMessage } from '../../common/events.js';
import {
  DownloadItem,
  MediaMetadata,
  MediaFetchSettings,
  SystemDiagnostics,
  HistoryEntry,
  ProjectContext,
  DownloadProfile
} from '../../common/types.js';

export type ServerEventListener = (msg: ServerMessage) => void;

function cleanExt(p: string): string {
  if (!p) return '';
  let s = String(p);
  try { s = decodeURIComponent(s); } catch (_) {}
  s = s.replace(/^file:[\\\/]+/, '');
  if (/^[\\\/]?[A-Za-z]:/.test(s)) {
    s = s.replace(/^[\\\/]([A-Za-z]:)/, '');
    return s.replace(/\//g, '\\');
  }
  if (!s.startsWith('/') && !s.startsWith('\\')) s = '/' + s;
  return s;
}

export class ServiceClient {
  private ws?: WebSocket;
  private port = 48924;
  private isConnected = false;
  private listeners: ServerEventListener[] = [];
  private reconnectTimer?: number;
  private statusListeners: ((online: boolean) => void)[] = [];

  constructor(preferredPort = 48924) {
    this.port = preferredPort;
  }

  public isOnline(): boolean {
    return this.isConnected;
  }

  public onStatusChanged(cb: (online: boolean) => void) {
    this.statusListeners.push(cb);
    cb(this.isConnected);
  }

  public subscribe(listener: ServerEventListener) {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private notifyStatus(online: boolean) {
    this.isConnected = online;
    for (const cb of this.statusListeners) {
      cb(online);
    }
  }

  private notifyListeners(msg: ServerMessage) {
    for (const l of this.listeners) {
      try {
        l(msg);
      } catch (err) {
        console.error('Error in message listener:', err);
      }
    }
  }

  private pendingQueue: ClientMessage[] = [];

  public connect() {
    if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
      return;
    }

    try {
      this.ws = new WebSocket(`ws://127.0.0.1:${this.port}`);

      this.ws.onopen = () => {
        console.log('Connected to MediaFetch service daemon.');
        this.notifyStatus(true);
        this.autoStartAttempts = 0;
        if (this.reconnectTimer) {
          clearTimeout(this.reconnectTimer);
          this.reconnectTimer = undefined;
        }
        // Flush all pending messages queued while offline/connecting
        while (this.pendingQueue.length > 0) {
          const m = this.pendingQueue.shift();
          if (m) {
            try {
              this.ws?.send(JSON.stringify(m));
            } catch (_) {}
          }
        }
        try {
          if (typeof window !== 'undefined' && (window as any).mediaFetchApp?.checkPendingImports) {
            (window as any).mediaFetchApp.checkPendingImports();
          }
        } catch (_) {}
      };

      this.ws.onmessage = (event) => {
        try {
          const parsed = JSON.parse(event.data) as ServerMessage;
          this.notifyListeners(parsed);
        } catch (e) {
          console.error('Failed to parse WebSocket message:', e);
        }
      };

      this.ws.onclose = () => {
        this.notifyStatus(false);
        this.tryAutoStartDaemon();
        this.scheduleReconnect();
      };

      this.ws.onerror = () => {
        this.notifyStatus(false);
        this.tryAutoStartDaemon();
      };
    } catch {
      this.notifyStatus(false);
      this.tryAutoStartDaemon();
      this.scheduleReconnect();
    }
  }

  private autoStartAttempts = 0;
  private lastAutoStartReset = Date.now();

  private tryAutoStartDaemon(force = false) {
    if (force || Date.now() - this.lastAutoStartReset > 15000) {
      this.autoStartAttempts = 0;
      this.lastAutoStartReset = Date.now();
    }
    if (this.autoStartAttempts > 10) return;
    this.autoStartAttempts++;
    try {
      if (typeof window !== 'undefined') {
        const nodeRequire = (window as any).require || (window as any).cep_node?.require;
        if (nodeRequire) {
          const path = nodeRequire('path');
          const fs = nodeRequire('fs');

          let proc: any = null;
          try {
            proc = typeof process !== 'undefined' ? process : nodeRequire('process');
          } catch {}

          const appData = proc?.env?.APPDATA || '';
          const localAppData = proc?.env?.LOCALAPPDATA || '';

          function cleanExt(p: string): string {
            if (!p) return '';
            let s = String(p);
            try { s = decodeURIComponent(s); } catch (_) {}
            s = s.replace(/^file:[\\\/]+/, '');
            if (/^[\\\/]?[A-Za-z]:/.test(s)) {
              s = s.replace(/^[\\\/]([A-Za-z]:)/, '');
              return s.replace(/\//g, '\\');
            }
            if (!s.startsWith('/') && !s.startsWith('\\')) s = '/' + s;
            return s;
          }

          let extDir = '';
          try {
            if ((window as any).__adobe_cep__?.getSystemPath) {
              extDir = cleanExt((window as any).__adobe_cep__.getSystemPath('extension'));
            } else if ((window as any).CSInterface) {
              extDir = cleanExt(new (window as any).CSInterface().getSystemPath('extension'));
            }
          } catch {}

          if (!extDir && window.location && window.location.pathname) {
            let p = cleanExt(window.location.pathname);
            extDir = p.substring(0, Math.max(p.lastIndexOf('/'), p.lastIndexOf('\\')));
          }

          const candidates = [
            extDir ? path.join(extDir, 'service', 'server.bundle.js') : '',
            extDir ? path.join(extDir, 'service', 'server.js') : '',
            appData ? path.join(appData, 'Adobe', 'CEP', 'extensions', 'com.mediafetch.adobe.pro', 'service', 'server.bundle.js') : '',
            appData ? path.join(appData, 'Adobe', 'CEP', 'extensions', 'com.mediafetch.adobe.pro', 'service', 'server.js') : '',
            appData ? path.join(appData, 'Adobe', 'CEP', 'extensions', 'com.mediafetch.adobe', 'service', 'server.bundle.js') : '',
            appData ? path.join(appData, 'Adobe', 'CEP', 'extensions', 'com.mediafetch.adobe', 'service', 'server.js') : '',
            appData ? path.join(appData, 'Adobe', 'CEP', 'extensions', 'com.mediafetch.adobe.beta', 'service', 'server.bundle.js') : '',
            appData ? path.join(appData, 'Adobe', 'CEP', 'extensions', 'com.mediafetch.adobe.beta', 'service', 'server.js') : '',
            'C:\\Program Files (x86)\\Common Files\\Adobe\\CEP\\extensions\\com.mediafetch.adobe.pro\\service\\server.bundle.js',
            'C:\\Program Files (x86)\\Common Files\\Adobe\\CEP\\extensions\\com.mediafetch.adobe\\service\\server.bundle.js',
            'C:\\Program Files\\Common Files\\Adobe\\CEP\\extensions\\com.mediafetch.adobe.pro\\service\\server.bundle.js',
            'C:\\Program Files\\Common Files\\Adobe\\CEP\\extensions\\com.mediafetch.adobe\\service\\server.bundle.js',
            '/Library/Application Support/Adobe/CEP/extensions/com.mediafetch.adobe.pro/service/server.bundle.js',
            '/Library/Application Support/Adobe/CEP/extensions/com.mediafetch.adobe/service/server.bundle.js',
            localAppData ? path.join(localAppData, 'MediaFetchPro', 'server.bundle.js') : '',
            localAppData ? path.join(localAppData, 'MediaFetchPro', 'server.js') : ''
          ].filter(Boolean);

          const nodeExecutables = [
            localAppData ? path.join(localAppData, 'Programs', 'nodejs', 'node.exe') : '',
            appData ? path.join(appData, 'nvm', 'current', 'node.exe') : '',
            'C:\\Program Files\\nodejs\\node.exe',
            'C:\\Program Files (x86)\\nodejs\\node.exe',
            'C:\\ProgramData\\chocolatey\\bin\\node.exe',
            localAppData ? path.join(localAppData, 'Programs', 'scoop', 'shims', 'node.exe') : '',
            '/opt/homebrew/bin/node',
            '/usr/local/bin/node',
            '/usr/bin/node',
            'node'
          ].filter((exe) => {
            if (!exe) return false;
            if (exe === 'node') return true;
            try { return fs.existsSync(exe); } catch (_) { return false; }
          });

          const logDir = localAppData ? path.join(localAppData, 'MediaFetch', 'logs') : '';
          let outFd: any = 'ignore';
          if (logDir) {
            try { fs.mkdirSync(logDir, { recursive: true }); } catch (_) {}
            try { outFd = fs.openSync(path.join(logDir, 'service.log'), 'a'); } catch (_) {}
          }

          for (const candidate of candidates) {
            if (fs.existsSync(candidate)) {
              console.log('[MediaFetch] Attempting auto-start from:', candidate);
              try {
                const cp = nodeRequire('child_process');
                for (const nodeExe of nodeExecutables) {
                  if (nodeExe !== 'node') {
                    try {
                      if (!fs.existsSync(nodeExe)) continue;
                    } catch (_) {
                      continue;
                    }
                  }
                  try {
                    const child = cp.spawn(nodeExe, ['--expose-gc', '--max-old-space-size=512', candidate], {
                      detached: true,
                      stdio: ['ignore', outFd, outFd],
                      windowsHide: true,
                      env: { ...proc?.env, PORT: '48924' }
                    });
                    child.on('error', (err: any) => {
                      console.warn(`[MediaFetch] Daemon spawn error on ${nodeExe}:`, err);
                    });
                    child.unref();
                    console.log(`[MediaFetch] Spawned daemon with ${nodeExe}: ${candidate}`);
                    setTimeout(() => this.connect(), 600);
                    setTimeout(() => this.connect(), 1200);
                    return;
                  } catch {}
                }
              } catch {}
            
              // In-process fallback for buyers without node.exe
              if (nodeRequire) {
                try {
                  console.log('[MediaFetch] Starting embedded in-process service from client supervisor:', candidate);
                  nodeRequire(candidate);
                  setTimeout(() => this.connect(), 400);
                  setTimeout(() => this.connect(), 1000);
                  return;
                } catch (err) {
                  console.error('[MediaFetch] In-process start failed:', err);
                }
              }
            }
          }
        }
      }
    } catch (e) {
      console.warn('[MediaFetch] Auto-start daemon error:', e);
    }
  }

  private supervisorInterval?: number;

  public startSupervisor() {
    if (this.supervisorInterval) return;
    this.supervisorInterval = window.setInterval(async () => {
      if (!this.isConnected) {
        this.tryAutoStartDaemon();
        this.connect();
      } else {
        try {
          const res = await fetch(`http://127.0.0.1:${this.port}/api/health`, { cache: 'no-store' }).catch(() => null);
          if (!res || !res.ok) {
            console.warn('[MediaFetch] Service health ping failed, attempting restart...');
            this.tryAutoStartDaemon(true);
          }
        } catch (_) {}
      }
    }, 10000);
  }

  private scheduleReconnect() {
    if (this.reconnectTimer) return;
    this.reconnectTimer = window.setTimeout(() => {
      this.reconnectTimer = undefined;
      this.connect();
    }, 1200);
  }

  public send(msg: ClientMessage) {
    (msg as any).edition = 'pro';
    if (msg.payload && typeof msg.payload === 'object') {
      (msg.payload as any).edition = 'pro';
    }
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      try {
        this.ws.send(JSON.stringify(msg));
        return;
      } catch (err) {
        console.warn('[MediaFetch] ws.send error, queueing message:', err);
      }
    }
    // Queue message and trigger immediate reconnect / daemon check
    this.pendingQueue.push(msg);
    this.connect();
    this.tryAutoStartDaemon(true);
  }

  public markItemImported(id: string, ok: boolean, error?: string) {
    this.send({
      type: 'ITEM_IMPORTED',
      payload: { id, ok, error }
    } as any);
  }

  private inProcessAnalysisActive = false;

  private async runInProcessAnalysis(url: string, timeoutMs = 25000) {
    if (this.inProcessAnalysisActive) return;
    if (typeof window === 'undefined') return;
    const nodeRequire = (window as any).require || (window as any).cep_node?.require;
    if (!nodeRequire) return;

    this.inProcessAnalysisActive = true;
    try {
      let extDir = '';
      try {
        if ((window as any).__adobe_cep__?.getSystemPath) {
        extDir = cleanExt((window as any).__adobe_cep__.getSystemPath('extension'));
        } else if ((window as any).CSInterface) {
        extDir = cleanExt(new (window as any).CSInterface().getSystemPath('extension'));
        }
      } catch (_) {}
      if (!extDir && window.location && window.location.pathname) {
        let p = cleanExt(window.location.pathname);
        extDir = p.substring(0, Math.max(p.lastIndexOf('/'), p.lastIndexOf('\\')));
      }

      const path = nodeRequire('path');
      const fs = nodeRequire('fs');
      const candidates = [
        extDir ? path.join(extDir, 'service', 'server.bundle.js') : '',
        extDir ? path.join(extDir, 'service', 'server.js') : '',
        extDir ? path.join(extDir, 'service', 'analyzer.js') : ''
      ].filter(Boolean);

      let analyzer: any = null;
      for (const cand of candidates) {
        if (fs.existsSync(cand)) {
          try {
            const mod = nodeRequire(cand);
            if (mod && (mod.metadataAnalyzer || mod.MetadataAnalyzer)) {
              analyzer = mod.metadataAnalyzer || (mod.MetadataAnalyzer ? new mod.MetadataAnalyzer() : null);
              break;
            }
          } catch (_) {}
        }
      }

      if (!analyzer) return;

      console.log('[MediaFetch] Running high-speed in-process analysis for:', url);
      this.notifyListeners({ type: 'ANALYSIS_STARTED', payload: { url } } as any);

      if (analyzer.isPlaylistUrl(url)) {
        const playlist = await analyzer.analyzePlaylist(url, timeoutMs);
        this.notifyListeners({ type: 'PLAYLIST_ANALYSIS_SUCCESS', payload: playlist } as any);
        this.notifyListeners({ type: 'PLAYLIST_METADATA_RESULT', payload: playlist } as any);
      } else {
        const meta = await analyzer.analyzeUrl(url, timeoutMs);
        if (meta.isPlaylist || meta.isCarousel) {
          this.notifyListeners({ type: 'PLAYLIST_ANALYSIS_SUCCESS', payload: meta } as any);
          this.notifyListeners({ type: 'PLAYLIST_METADATA_RESULT', payload: meta } as any);
        } else {
          this.notifyListeners({ type: 'ANALYSIS_SUCCESS', payload: meta } as any);
          this.notifyListeners({ type: 'METADATA_RESULT', payload: meta } as any);
        }
      }
    } catch (err: any) {
      console.warn('[MediaFetch] In-process analysis notice:', err?.message || err);
      if (!this.isConnected) {
        this.notifyListeners({
          type: 'ANALYSIS_ERROR',
          payload: { url, error: err?.message || 'Analysis failed', details: err?.details, category: err?.category || 'EXTRACTION_ERROR' }
        } as any);
      }
    } finally {
      this.inProcessAnalysisActive = false;
    }
  }

  public analyzeUrl(url: string, timeoutMs?: number) {
    this.send({ type: 'ANALYZE_URL', payload: { url, timeoutMs } });
    if (!this.isConnected) {
      this.runInProcessAnalysis(url, timeoutMs);
    }
  }

  public analyzePlaylist(url: string, timeoutMs?: number) {
    this.send({ type: 'ANALYZE_PLAYLIST', payload: { url, timeoutMs } });
    if (!this.isConnected) {
      this.runInProcessAnalysis(url, timeoutMs);
    }
  }

  public startDownload(
    url: string,
    profile: DownloadProfile,
    projectContext?: ProjectContext,
    targetDirectory?: string,
    metadata?: Partial<MediaMetadata>
  ) {
    const isPro = (window as any).__MF_EDITION__ === 'pro' || window.location.pathname.includes('.pro') || document.title.includes('Pro');
    const edition = isPro ? 'pro' : 'standard';
    const targetHost = (window as any).__MF_HOST_ID__ || (typeof (window as any).hostAdapter !== 'undefined' && (window as any).hostAdapter.hostId) || 'ppro';
    this.send({
      type: 'START_DOWNLOAD',
      payload: { url, profile, projectContext, targetDirectory, metadata: { ...(metadata || {}), edition, targetHost }, edition, targetHost }
    });
  }

  public startPlaylistDownload(
    items: { url: string; title: string; thumbnail?: string; duration?: number; subFolderName?: string; downloadQuery?: string; uploader?: string }[],
    profile: DownloadProfile,
    projectContext?: ProjectContext,
    targetDirectory?: string,
    options?: {
      customFolderName?: string;
      preserveSubfolders?: boolean;
      autoImport?: boolean;
      zipPackage?: boolean;
      playlistTitle?: string;
      isCloud?: boolean;
    }
  ) {
    const isPro = (window as any).__MF_EDITION__ === 'pro' || window.location.pathname.includes('.pro') || document.title.includes('Pro');
    const edition = isPro ? 'pro' : 'standard';
    const targetHost = (window as any).__MF_HOST_ID__ || (typeof (window as any).hostAdapter !== 'undefined' && (window as any).hostAdapter.hostId) || 'ppro';
    this.send({
      type: 'START_PLAYLIST_DOWNLOAD',
      payload: {
        items,
        profile,
        projectContext,
        targetDirectory,
        customFolderName: options?.customFolderName,
        preserveSubfolders: options?.preserveSubfolders,
        autoImport: options?.autoImport,
        zipPackage: options?.zipPackage,
        playlistTitle: options?.playlistTitle,
        isCloud: options?.isCloud,
        edition,
        targetHost
      }
    });
  }

  public pauseDownload(id: string) {
    this.send({ type: 'PAUSE_DOWNLOAD', payload: { id } });
  }

  public resumeDownload(id: string) {
    this.send({ type: 'RESUME_DOWNLOAD', payload: { id } });
  }

  public cancelDownload(id: string) {
    this.send({ type: 'CANCEL_DOWNLOAD', payload: { id } });
  }

  public retryDownload(id: string) {
    this.send({ type: 'RETRY_DOWNLOAD', payload: { id } });
  }

  public clearCompleted() {
    const isPro = (window as any).__MF_EDITION__ === 'pro' || window.location.pathname.includes('.pro') || document.title.includes('Pro');
    const edition = isPro ? 'pro' : 'standard';
    this.send({ type: 'CLEAR_COMPLETED', payload: { edition }, edition });
  }

  public clearAll() {
    const isPro = (window as any).__MF_EDITION__ === 'pro' || window.location.pathname.includes('.pro') || document.title.includes('Pro');
    const edition = isPro ? 'pro' : 'standard';
    this.send({ type: 'CLEAR_ALL', payload: { edition }, edition });
  }

  public getSettings() {
    this.send({ type: 'GET_SETTINGS' });
  }

  public updateSettings(settings: Partial<MediaFetchSettings>) {
    this.send({ type: 'UPDATE_SETTINGS', payload: settings });
  }

  public getDiagnostics() {
    this.send({ type: 'GET_DIAGNOSTICS' });
  }

  public runSystemCheck() {
    this.send({ type: 'RUN_SYSTEM_CHECK' });
  }

  public installDependency(name: 'ytdlp' | 'ffmpeg' | 'all') {
    this.send({ type: 'INSTALL_DEPENDENCY', payload: { name } });
  }

  public updateYtDlp() {
    this.send({ type: 'UPDATE_YTDLP' });
  }

  public getHistory() {
    this.send({ type: 'GET_HISTORY' });
  }

  public clearHistory() {
    this.send({ type: 'CLEAR_HISTORY' });
  }

  public removeHistoryItem(id: string) {
    this.send({ type: 'REMOVE_HISTORY_ITEM', payload: { id } });
  }

  public checkDuplicate(title: string, container: string, targetDirectory: string) {
    this.send({
      type: 'CHECK_DUPLICATE',
      payload: { title, container, targetDirectory }
    });
  }

  public openFolderDialog() {
    this.send({ type: 'OPEN_FOLDER_DIALOG' } as any);
  }
}

export const serviceClient = new ServiceClient();
