import { ClientMessage, ServerMessage } from '../../common/events.js';
import {
  DownloadItem,
  MediaMetadata,
  MediaFetchSettings,
  SystemDiagnostics,
  HistoryEntry,
  ProjectContext,
  DownloadProfile
} from '../../common/types.js';

export type ServerEventListener = (msg: ServerMessage) => void;

export class ServiceClient {
  private ws?: WebSocket;
  private port = 48924;
  private isConnected = false;
  private listeners: ServerEventListener[] = [];
  private reconnectTimer?: number;
  private statusListeners: ((online: boolean) => void)[] = [];

  constructor(preferredPort = 48924) {
    this.port = preferredPort;
  }

  public isOnline(): boolean {
    return this.isConnected;
  }

  public onStatusChanged(cb: (online: boolean) => void) {
    this.statusListeners.push(cb);
    cb(this.isConnected);
  }

  public subscribe(listener: ServerEventListener) {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private notifyStatus(online: boolean) {
    this.isConnected = online;
    for (const cb of this.statusListeners) {
      cb(online);
    }
  }

  private notifyListeners(msg: ServerMessage) {
    for (const l of this.listeners) {
      try {
        l(msg);
      } catch (err) {
        console.error('Error in message listener:', err);
      }
    }
  }

  public connect() {
    if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
      return;
    }

    try {
      this.ws = new WebSocket(`ws://127.0.0.1:${this.port}`);

      this.ws.onopen = () => {
        console.log('Connected to MediaFetch service daemon.');
        this.notifyStatus(true);
        if (this.reconnectTimer) {
          clearTimeout(this.reconnectTimer);
          this.reconnectTimer = undefined;
        }
      };

      this.ws.onmessage = (event) => {
        try {
          const parsed = JSON.parse(event.data) as ServerMessage;
          this.notifyListeners(parsed);
        } catch (e) {
          console.error('Failed to parse WebSocket message:', e);
        }
      };

      this.ws.onclose = () => {
        this.notifyStatus(false);
        this.tryAutoStartDaemon();
        this.scheduleReconnect();
      };

      this.ws.onerror = () => {
        this.notifyStatus(false);
        this.tryAutoStartDaemon();
      };
    } catch {
      this.notifyStatus(false);
      this.tryAutoStartDaemon();
      this.scheduleReconnect();
    }
  }

  private autoStartAttempts = 0;

  private tryAutoStartDaemon() {
    if (this.autoStartAttempts > 3) return;
    this.autoStartAttempts++;
    try {
      if (typeof window !== 'undefined') {
        const nodeRequire = (window as any).require || (window as any).cep_node?.require;
        if (nodeRequire) {
          const path = nodeRequire('path');
          const fs = nodeRequire('fs');

          let proc: any = null;
          try {
            proc = typeof process !== 'undefined' ? process : nodeRequire('process');
          } catch {}

          const appData = proc?.env?.APPDATA || '';
          const localAppData = proc?.env?.LOCALAPPDATA || '';

          let extDir = '';
          try {
            if ((window as any).__adobe_cep__?.getSystemPath) {
              extDir = (window as any).__adobe_cep__.getSystemPath('extension');
            } else if ((window as any).CSInterface) {
              extDir = new (window as any).CSInterface().getSystemPath('extension');
            }
          } catch {}

          if (!extDir && window.location && window.location.pathname) {
            let p = window.location.pathname.replace(/^[\\\/]([A-Za-z]:)/, '$1');
            extDir = p.substring(0, Math.max(p.lastIndexOf('/'), p.lastIndexOf('\\')));
          }

          const candidates = [
            extDir ? path.join(extDir, 'service', 'server.js') : '',
            extDir ? path.join(extDir, 'service', 'server.bundle.js') : '',
            appData ? path.join(appData, 'Adobe', 'CEP', 'extensions', 'com.mediafetch.adobe.pro', 'service', 'server.js') : '',
            localAppData ? path.join(localAppData, 'MediaFetchPro', 'server.js') : ''
          ].filter(Boolean);

          const nodeExecutables = [
            'C:\\Program Files\\nodejs\\node.exe',
            'C:\\Program Files (x86)\\nodejs\\node.exe',
            'node'
          ];

          for (const candidate of candidates) {
            if (fs.existsSync(candidate)) {
              console.log('[MediaFetch] Attempting auto-start from:', candidate);
              // Try in-process require first
              try {
                nodeRequire(candidate);
                console.log('[MediaFetch] Started service in-process.');
                setTimeout(() => this.connect(), 500);
                return;
              } catch {}

              // Try child_process spawn with explicit node paths
              try {
                const cp = nodeRequire('child_process');
                for (const nodeExe of nodeExecutables) {
                  try {
                    const child = cp.spawn(nodeExe, ['--max-old-space-size=48', '--optimize-for-size', candidate], {
                      detached: true,
                      stdio: 'ignore',
                      windowsHide: true,
                      env: { ...proc?.env, PORT: '48924' }
                    });
                    child.unref();
                    console.log(`[MediaFetch] Spawned daemon with ${nodeExe}: ${candidate}`);
                    setTimeout(() => this.connect(), 800);
                    return;
                  } catch {}
                }
              } catch {}
            }
          }
        }
      }
    } catch (e) {
      console.warn('[MediaFetch] Auto-start daemon error:', e);
    }
  }

  private scheduleReconnect() {
    if (this.reconnectTimer) return;
    this.reconnectTimer = window.setTimeout(() => {
      this.reconnectTimer = undefined;
      this.connect();
    }, 1500);
  }

  public send(msg: ClientMessage) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      (msg as any).edition = 'pro';
      if (msg.payload && typeof msg.payload === 'object') {
        (msg.payload as any).edition = 'pro';
      }
      this.ws.send(JSON.stringify(msg));
    } else {
      console.warn('Cannot send message: service not connected.');
    }
  }

  public analyzeUrl(url: string, timeoutMs?: number) {
    this.send({ type: 'ANALYZE_URL', payload: { url, timeoutMs } });
  }

  public analyzePlaylist(url: string) {
    this.send({ type: 'ANALYZE_PLAYLIST', payload: { url } });
  }

  public startDownload(
    url: string,
    profile: DownloadProfile,
    projectContext?: ProjectContext,
    targetDirectory?: string,
    metadata?: Partial<MediaMetadata>
  ) {
    const isPro = (window as any).__MF_EDITION__ === 'pro' || window.location.pathname.includes('.pro') || document.title.includes('Pro');
    const edition = isPro ? 'pro' : 'standard';
    this.send({
      type: 'START_DOWNLOAD',
      payload: { url, profile, projectContext, targetDirectory, metadata: { ...(metadata || {}), edition }, edition }
    });
  }

  public startPlaylistDownload(
    items: { url: string; title: string; thumbnail?: string; duration?: number; subFolderName?: string; downloadQuery?: string; uploader?: string }[],
    profile: DownloadProfile,
    projectContext?: ProjectContext,
    targetDirectory?: string,
    options?: {
      customFolderName?: string;
      preserveSubfolders?: boolean;
      autoImport?: boolean;
      zipPackage?: boolean;
      playlistTitle?: string;
      isCloud?: boolean;
    }
  ) {
    const isPro = (window as any).__MF_EDITION__ === 'pro' || window.location.pathname.includes('.pro') || document.title.includes('Pro');
    const edition = isPro ? 'pro' : 'standard';
    this.send({
      type: 'START_PLAYLIST_DOWNLOAD',
      payload: {
        items,
        profile,
        projectContext,
        targetDirectory,
        customFolderName: options?.customFolderName,
        preserveSubfolders: options?.preserveSubfolders,
        autoImport: options?.autoImport,
        zipPackage: options?.zipPackage,
        playlistTitle: options?.playlistTitle,
        isCloud: options?.isCloud,
        edition
      }
    });
  }

  public pauseDownload(id: string) {
    this.send({ type: 'PAUSE_DOWNLOAD', payload: { id } });
  }

  public resumeDownload(id: string) {
    this.send({ type: 'RESUME_DOWNLOAD', payload: { id } });
  }

  public cancelDownload(id: string) {
    this.send({ type: 'CANCEL_DOWNLOAD', payload: { id } });
  }

  public retryDownload(id: string) {
    this.send({ type: 'RETRY_DOWNLOAD', payload: { id } });
  }

  public clearCompleted() {
    const isPro = (window as any).__MF_EDITION__ === 'pro' || window.location.pathname.includes('.pro') || document.title.includes('Pro');
    const edition = isPro ? 'pro' : 'standard';
    this.send({ type: 'CLEAR_COMPLETED', payload: { edition }, edition });
  }

  public clearAll() {
    const isPro = (window as any).__MF_EDITION__ === 'pro' || window.location.pathname.includes('.pro') || document.title.includes('Pro');
    const edition = isPro ? 'pro' : 'standard';
    this.send({ type: 'CLEAR_ALL', payload: { edition }, edition });
  }

  public getSettings() {
    this.send({ type: 'GET_SETTINGS' });
  }

  public updateSettings(settings: Partial<MediaFetchSettings>) {
    this.send({ type: 'UPDATE_SETTINGS', payload: settings });
  }

  public getDiagnostics() {
    this.send({ type: 'GET_DIAGNOSTICS' });
  }

  public runSystemCheck() {
    this.send({ type: 'RUN_SYSTEM_CHECK' });
  }

  public installDependency(name: 'ytdlp' | 'ffmpeg' | 'all') {
    this.send({ type: 'INSTALL_DEPENDENCY', payload: { name } });
  }

  public updateYtDlp() {
    this.send({ type: 'UPDATE_YTDLP' });
  }

  public getHistory() {
    this.send({ type: 'GET_HISTORY' });
  }

  public clearHistory() {
    this.send({ type: 'CLEAR_HISTORY' });
  }

  public removeHistoryItem(id: string) {
    this.send({ type: 'REMOVE_HISTORY_ITEM', payload: { id } });
  }

  public checkDuplicate(title: string, container: string, targetDirectory: string) {
    this.send({
      type: 'CHECK_DUPLICATE',
      payload: { title, container, targetDirectory }
    });
  }

  public openFolderDialog() {
    this.send({ type: 'OPEN_FOLDER_DIALOG' } as any);
  }
}

export const serviceClient = new ServiceClient();
