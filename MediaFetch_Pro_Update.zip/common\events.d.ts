import { DownloadItem, DownloadProfile, MediaMetadata, MediaFetchSettings, SystemDiagnostics, HistoryEntry, ProjectContext } from './types.js';
export type ClientMessage = {
    type: 'ANALYZE_URL';
    payload: {
        url: string;
        timeoutMs?: number;
    };
} | {
    type: 'START_DOWNLOAD';
    payload: {
        url: string;
        profile: DownloadProfile;
        projectContext?: ProjectContext;
        targetDirectory?: string;
        metadata?: Partial<MediaMetadata>;
    };
} | {
    type: 'PAUSE_DOWNLOAD';
    payload: {
        id: string;
    };
} | {
    type: 'RESUME_DOWNLOAD';
    payload: {
        id: string;
    };
} | {
    type: 'CANCEL_DOWNLOAD';
    payload: {
        id: string;
    };
} | {
    type: 'RETRY_DOWNLOAD';
    payload: {
        id: string;
    };
} | {
    type: 'CLEAR_COMPLETED';
} | {
    type: 'CLEAR_ALL';
} | {
    type: 'GET_QUEUE';
} | {
    type: 'GET_SETTINGS';
} | {
    type: 'UPDATE_SETTINGS';
    payload: Partial<MediaFetchSettings>;
} | {
    type: 'GET_DIAGNOSTICS';
} | {
    type: 'RUN_SYSTEM_CHECK';
} | {
    type: 'INSTALL_DEPENDENCY';
    payload: {
        name: 'ytdlp' | 'ffmpeg' | 'all';
    };
} | {
    type: 'UPDATE_YTDLP';
} | {
    type: 'GET_HISTORY';
} | {
    type: 'CLEAR_HISTORY';
} | {
    type: 'REMOVE_HISTORY_ITEM';
    payload: {
        id: string;
    };
} | {
    type: 'CHECK_DUPLICATE';
    payload: {
        title: string;
        container: string;
        targetDirectory: string;
    };
} | {
    type: 'PING';
};
export type ServerMessage = {
    type: 'ANALYSIS_STARTED';
    payload: {
        url: string;
    };
} | {
    type: 'ANALYSIS_SUCCESS';
    payload: MediaMetadata;
} | {
    type: 'ANALYSIS_ERROR';
    payload: {
        url: string;
        error: string;
        details?: string;
        category: string;
    };
} | {
    type: 'QUEUE_UPDATED';
    payload: DownloadItem[];
} | {
    type: 'DOWNLOAD_PROGRESS';
    payload: {
        id: string;
        item: DownloadItem;
    };
} | {
    type: 'DOWNLOAD_COMPLETED';
    payload: {
        id: string;
        item: DownloadItem;
        historyEntry: HistoryEntry;
    };
} | {
    type: 'DOWNLOAD_FAILED';
    payload: {
        id: string;
        item: DownloadItem;
    };
} | {
    type: 'SETTINGS_LOADED';
    payload: MediaFetchSettings;
} | {
    type: 'DIAGNOSTICS_RESULT';
    payload: SystemDiagnostics;
} | {
    type: 'DEPENDENCY_INSTALL_PROGRESS';
    payload: {
        name: string;
        stage: string;
        progress: number;
        message: string;
    };
} | {
    type: 'DEPENDENCY_INSTALL_RESULT';
    payload: {
        success: boolean;
        name: string;
        error?: string;
    };
} | {
    type: 'HISTORY_LOADED';
    payload: HistoryEntry[];
} | {
    type: 'DUPLICATE_CHECK_RESULT';
    payload: {
        exists: boolean;
        existingFilePath?: string;
        existingFileSize?: number;
    };
} | {
    type: 'LOG_ENTRY';
    payload: {
        level: string;
        message: string;
        timestamp: number;
    };
} | {
    type: 'PONG';
    payload: {
        timestamp: number;
    };
};
